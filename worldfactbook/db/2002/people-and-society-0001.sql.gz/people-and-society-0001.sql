SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6969027a67db23299cecbc1ee3336b5e7efecceb0ab34094e3db68fe9851cd',2002,'AU','Australia','people-and-society',18,'Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS -deaths
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People -note
Population: 27,755,775 (July 2002 est.)
Age structure:
0-1 4 years: 42% (male 5,953,291 ; female 5,706,542)
15-64 years: 55.2% (male 7,935,101; female
7,382,101)
65 years and over: 2.8% (male 410,278; female
368,462) (2002 est.)
Population growth rate: 3.43%
note: this rate reflects the continued return of refugees
from Iran (2002 est.)
Birth rate: 41.03 births/1 ,000 population (2002 est.)
Death rate: 1 7.43 deaths/1 ,000 population
(2002 est.)
Net migration rate: 10.7 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 1.11 male(s)/female
total population^ .06 male(s)/female (2002 est.)
Infant mortality rate: 144.76 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.6 years
male: 47.32 years
female: 45.85 years (2002 est.)
Total fertility rate: 5.72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 44%, Tajik 25%, Hazara
10%, minor ethnic groups (Aimaks, Turkmen, Baloch,
and others) 13%, Uzbek 8%
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
Turkmen) 1 1 %, 30 minor languages (primarily Baloch i
and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 36%
male: 51%
female: 21% (1999 est.)
People - note: large numbers of Afghan refugees
create burdens on neighboring states
Population: 3,544,841 (July 2002 est.)
Age structure:
0-14 years: 28.8% (male 528,678; female 493,531 )
15-64 years: 64% (male 1,094,034; female
1,175,024)
65 years and over: 7.2% (male 1 1 1 ,524; female
142,050) (2002 est.)
Population growth rate: 1.06% (2002 est.)
Birth rate: 1 8.59 births/1 ,000 population (2002 est.)
Death rate: 6.49 deaths/1 1000 population (2002 est.)
Net migration rate: -1.46 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/fema!e
under 1 5 years: \\, 07 male(s)/fema!e
15-64 years: 0.93 ma!e(s)/female
65 years and over: 0.79 ma!e(s)/female
total population: 0.96 male(s)/fema!e (2002 est.)
Infant mortality rate: 38.64 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.1 years
male: 69.27 years
female: 75.14 years (2002 est.)
Total fertility rate: 2.27 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(2000 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greek 3%, other 2%
(Vlach, Gypsy, Serb, and Bulgarian) (1989 est.)
note: in 1989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
nofe; all mosques and churches were closed in 1967
and religious observances prohibited; in
November 1990, Albania began allowing private
religious practice
Languages: Albanian (Tosk is the official dialect),
Greek
Literacy:
definition: age 9 and over can read and write
total population: 93% (1997 est.)
male: NA%
female: NA%
Population: 32,277,942 (July 2002 est.)
Age structure:
0-14 years: 33.5% (male 5,512,369; female
5,311,914)
15-64 years: 62.4% (male 10,175,135; female
9,950,315)
65 years and over: 4.1% (male 610,643; female
717,566) (2002 est.)
Population growth rate: 1.68% (2002 est.)
Birth rate: 22.34 births/1 ,000 population (2002 est.)
Death rate: 5.15deaths/1 ,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.02 male(s)/fema1e (2002 est.)
Infant mortality rate: 39.1 5 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.24 years
male: 68.87 years
female: 71 .67 years (2002 est.)
Total fertility rate: 2.63 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
not/n: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%.
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 61 .6%
male: 73,9%
female: 49% (1995 est.)
Population: 19,546,792 (July 2002 est)
Age structure:
0-14 years: 20.4% (male 2,046,052; female
1,949,725)
15-64 years: 67% (male 6,610,840; female
6,480,354)
65 years and over. 12,6% (male 1,078,506; female
1,381 ,315) (2002 est.)
Population growth rate: 0.96% (2002 est.)
Birth rate: 1271 births/1,000 population (2002 est.)
Death rate: 7.25 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.12 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 maie(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 4.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80 years
ma/e;77.15years
female: 83 years (2002 est)
Total fertility rate: 1.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est)
HIV/AIDS -deaths: 100 (1999 est)
Nationality:
ram''Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 11%, other
12.6%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 100%
mate: 100%
female: 100% (1980 est)
Population: 8,1 69,929 (July 2002 est.)
Age structure:
0-14 years: 16.4% (male 686,205; female 652,840)
15-64 years: 68.2% (male 2,814,866; female
2,756,777)
65 years and over: 15.4% (male 484,313; female
774,928) (2002 est.)
Population growth rate: 0.23% (2002 est.)
Birth rate: 9.58 births/1,000 population (2002 est.)
Death rate: 9.73 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.45 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af b/rt/?; 1 ,05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.62 male(s)/female
totai population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 4.39 deaths/1 ,000 live births
(2002 est.)
33
Austria (continued)
Life expectancy at birth:
total population: 78 years
male: 74.85 years
female: 81.31 years (2002 est.)
Total fertility rate: 1 .4 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 843
(2001 est.)
HIV/AIDS -deaths: 8 (2001 est)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 88%, non-nationals 9.3%
(includes Croatians, Slovenes, Hungarians, Czechs,
Slovaks, Roma), naturalized 2% (includes those who
have lived in Austria at least three generations)
Religions: Roman Catholic 78%, Protestant 5%,
Muslim and other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 98%
ma/e:NA%
fema/e:NA%
Population: uninhabited (July 2002 est.)
Population: 77,311 (July 2002 est.)
Age structure:
0-14 years: 23.4% (male 9,208; female 8,902)
15-64 years: 74.8% (male 27,041; female 30,781)
65 years and over: 1 .8% (male 690; female 689)
(2002 est.)
Population growth rate: 3.49% (2002 est.)
Birth rate: 20.29 births/1,000 population (2002 est.)
Death rate: 2.42 deaths/1 ,000 population (2002 est.)
Net migration rate: 17.02 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.88 mate(s)/fema!e
65 years and over: 1 male(s)/female
total population: 0.92 male(s)/female (2002 est.)
Infant mortality rate: 5.61 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.95 years
male: 72.85 years
female: 79.23 years (2002 est.)
Total fertility rate: 1 .76 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: NA
adjective: NA''
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Filipino, Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 1 5 and over can read and write
total population: Q7%
male: 97%
fema/e:96%(1980est.)','4479c60331b35e6073622b12fae4111e6aa95c7f08f9e4ef250f14f00890d9ba','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca533dd229cb309a72b4fe77a36b634489a1e6a638cc451f104c8a555821b67c',2002,'NZ','New Zealand','people-and-society',29,'Population: 68,688 (July 2002 est.)
Age structure:
014 years: 38.1% (male 13,445; female 12,688)
15-64 years: 567% (male 19,228; female 19,741)
65 years and over: 5.2% (male 1 ,931 ; female 1 ,655)
(2002 est.)
Population growth rate: 2.31% (2002 est.)
Birth rate: 24.04 births/1,000 population (2002 est.)
Death rate: 4.34 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.42 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/fema!e
under 15 years: 1.06 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over 1.17 male(s)/fema!e
total population: 1 .02 ma!e(s)/female (2002 est.)
Infant mortality rate: 10.09 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.53 years
wale: 71 .12 years
female: 80.21 years (2002 est.)
Total fertility rate: 3.4 children born/woman
(2002 est)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions: Christian Congregationalist50%, Roman
Catholic 20%, Protestant and other 30%
Languages: Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
Literacy:
definition: age 15 and over can read and write
total population: 97%
ma/e:98%
female: 97% (1980 est.)
Population: 3,908,037 (July 2002 est.)
Age structure:
0-14 years: 22.2% (male 443,921; female 422,804)
15-64 years: 66.3% (male 1,299,973; female
1,290,097)
65year$and over: 11.5% (male 196,640; female
254,602) (2002 est.)
Population growth rate: 1 .12% (2002 est.)
Birth rate: 14.23 births/1 ,000 population (2002 est.)
Death rate: 7.55 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.48 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af to* 1.04 male(s)/fema1e
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 6.18 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.1 5 years
male: 75.17 years
female: 81 .27 years (2002 est.)
Total fertility rate: 1.8 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,200
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 1 8%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1 986)
Languages: English (official), Maori (official)
Literacy:
definition: age 15 and over can read and write
total population; 99% (1980 est.)
male: NA%
female: NA%
Population: 106,137 (July 2002 est.)
Age structure:
0-14 years: 39.5% (male 21 ,374; female 20,555)
15-64 years: 56.4% (male 29,519; female 30,322)
65 years and over: 4.1% (male 1,945; female 2,422)
(2002 est.)
Population growth rate: 1.85% (2002 est.)
Birth rate: 24.08 births/1,000 population (2002 est.)
Death rate: 5.63 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,0G0 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 ,04 male(s)/female
15-64 years: 0.97 ma!e(s)/fema!e
65 years and over: 0.8 ma!e(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 1 3.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.56 years
male: 66.13 years
female: 71.11 years (2002 est.)
Total fertility rate: 3 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS; NA
HIV/AIDS -deaths: NA
Nationality:
/?oun:Tongan{s)
ad/ecf/Ve: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
tofa/popt//af/on:98.5%
mate: 98.4%
. female: 98.7% (1996 est.)
512
Tonga (continued)
Population: 1,163,724 (July 2002 est.)
Age structure:
0-14 years: 23% (mate 136,807; female 131,177)
15-64 years: 70.2% (mate 419,847; female 396,643)
65 years andover:§&% (male 35,146; female
44,104) (2002 est.)
Population growth rate: -0.52% (2002 est.)
Birth rate: 13.66 births/1 ,000 population (2002 est.)
Death rate: 8.8 1 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 0.02 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .06 ma!e(s)/female
65 years and over: 0.8 ma!e(s)/female
total population: 1.04 male(s)/female (2002 est.)
Infant mortality rate: 24.2 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.59 years
male: 66.04 years
female: 71 .25 years (2002 est.)
Total fertility rate: 1 .8 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 1 .05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,800
(1999 est.)
HIV/AIDS -deaths: 530 (1999 est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic groups: black 39.5%, East Indian (a local
term - primarily immigrants from northern India)
40.3%, mixed 18.4%, white 0.6%, Chinese and
other 1.2%
Religions: Roman Catholic 29.4%, Hindu 23.8%,
Anglican 10.9%, Muslim 5.8%, Presbyterian 3.4%,
other 26.7%
514
Trinidad and Tobago (continued)
Languages: English (official), Hindi, French,
Spanish, Chinese
Literacy:
definition: age 15 and over can read and write
. total population: 94% (2000)
male: 95.9% (1999)
femafe; 91 .7% (1999)
Population: uninhabited (July 2002 est.)
Population: 15,585 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: UA%
65 years and over: NA%
Population growth rate: NA (2002 est.)
Birthrate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
mafe:NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIWAIDS- deaths: NA
Nationality:
noun: Watiisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, of Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy;
definition: age 15 and over can read and write
total population: 50%
male: 50%
fema/e:50%(1969 est.)','3f7cf1899c22906bf6e41fbfb2db9e6c1c85dfac227c8b83e04a0c10eda65ce3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5a38e799ec1738ba619288cd3ee1c1789f3f0cf92b020fa6e938067b92bd7f',2002,'ES','Spain','people-and-society',38,'Population: 68,403 (July 2002 est.)
Age structure:
0-14 years: 15.2% (male 5,456; female 4,951)
15-64 years: 71 .9% (male 25,855; female 23,31 1 )
65 years and over: 12.9% (male 4,425; female 4,405)
(2002 est.)
Population growth rate: 1.11% (2002 est.)
Birth rate: 9.97 births/1 ,000 population (2002 est)
Death rate: 5.57 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.74 migrant(s)/1,000
population (2002 est,)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.1 male{s)/female
15-64 years: 1.11 ma1e(s)/female
65 years and over:] male(s)/female
totai population: 1.09 male(s)/female (2002 est.)
Infant mortality rate: 4.07 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 83.48 years
wale: 80.58 years
female: 86.58 years (2002 est.)
Total fertility rate: 1.26 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Andorran(s)
acf/ecf/Ve: Andorran
Ethnic groups: Spanish 43%, Andorran 33%,
Portuguese 11%, French 7%, other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy:
definition:
total population: 100%
ma/e:NA%
female: NA%
Population: 27,714 (July 2002 est.)
Age structure:
0-14 years: 18.5% (male 2,633; female 2,509)
15-64 years: 66.3% (male 9,456; female 8,907)
65 years and over: 1 5.2% (male 1 ,803; female 2,406)
(2002 est)
Population growth rate: 0.23% (2002 est.)
Birth rate: 1 1 .19 births/1 ,000 population (2002 est.)
Death rate: 8.88 deaths/1 ,000 population (2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.01 male(s)/female (2002 est)
Infant mortality rate: 5.4 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 79.23 years
male: 76.37 years
female: 82.25 years (2002 est.)
Total fertility rate: 1 .65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Spanish, Italian, English, Maltese,
Portuguese
Religions: Roman Catholic 76.9%, Church of
England 6.9%, Muslim 6.9%, Jewish 2.3%, none or
other 7% (1991)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 80%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)
Population: 40,077,100 (July 2002 est.)
Age structure:
0-14 years: 14.5% (male 2,993,747; female
2,812,498)
15-64 years: 68.1% (male 13,699,383; female
13,592,717)
65 years and over: 17.4% (male 2,922,452; female
4,056,303) (2002 est.)
Population growth rate: 0.09% (2002 est.)
Birth rate: 9.29 births/1,000 population (2002 est.)
Death rate: 9.22 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.87 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/fema!e
under 15 years: 1.06 ma!e(s)/female
15-64 years: 1 .01 ma!e(s)/female
65 years and over: 0.72 male(s)/female
fofafpopu/af/on: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 4.85 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.08 years
male: 75.63 years
female: 82.76 years (2002 est.)
Total fertility rate: 1 .16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.58%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: 120,000
(1999 est.)
HIV/AIDS -deaths: 2,000 (1999 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 94%, other 6%
Languages: Castilian Spanish (official) 74%,
Catalan 17%, Galician 7%, Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: NA%
female: NA%','310d4a2953099c48a851a18057c11756ead4a3892747277f06a91a7448569bb6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8adb04a27764acec95ea5bbc2e1751aeb8e90579a14415972e5bb457d42d207f',2002,'AO','Angola','people-and-society',47,'Population: 10,593,171 (July 2002 est)
Age structure:
0-14 years: 43.3% (male 2,318,326; female
2,272,726)
15-64 years: 53.9% (male 2,904,595; female
2,806,430)
65 years and over: 2.8% (male 131 ,316; female
159,778) (2002 est.)
Population growth rate: 2.18% (2002 est.)
Birth rate: 46.18 births/1 ,000 population (2002 est.)
Death rate: 24.35 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population .
(2002 est.)
Sex ratio:
at birth: 1.05 mate(s)/female
under 15 years: 1.02 ma!e(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.82 male(s)/female
total population:] .02 male(s)/female (2002 est.)
Infant mortality rate: 1 91 ,66 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 38. 87 years
male: 37.62 years
female: 40,1 8 years (2002 est.)
Total fertility rate: 6.43 children born/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 2.78%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 160,000
(1999 est)
HIV/AIDS - deaths: 1 5,000 (1 999 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (1998 est)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
mate: 56%
femate:28%(1998est.)','55153d50b7964daac4a604566e5e08208b91b57b9cf07aeb6d59653493411025','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0c2f0296aa5e95e1900d38033cea7f40b2fb9445b827ddc1752f4772ac4aa9c',2002,'AI','Anguilla','people-and-society',57,'Population: 1 2,446 (July 2002 est.)
Age structure:
014 years: 25% (male 1,575; female 1,529)
15-64 years: 68.1 % (male 4,356; female 4,124)
65 years and over: 6.9% (male 383; female 479)
(2002 est.)
Population growth rate: 2.44% (2002 est.)
Birth rate: 14.94 births/1 ,000 population (2002 est)
Death rate: 5.54 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 5.02 mlgrant(s)/1 ,000
population (2002 est.)
Sex ratio:
afWrtf?;1.02male(s)flemale
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .06 male(s)/fema!e
65 years and oven 0.8 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 23.68 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.5 years
male: 73.6 years
female: 79.5 years (2002 est.)
Total fertility rate: 1 .77 children bom/woman
(2002 est)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS -people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Anguillan(s)
atfjecf/Ve: Anguilian
Ethnic groups: black (predominant), mulatto, white
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
mate: 95%
female: 95% (1984 est.)','2df2eb1f6ba7462549d41adbeb93182e3cf869930466c21679dc6f586fad4e0c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6e7b48a676dba5873441fba42ecbaa5474693f960ba6aca221b579cc0802743',2002,'AQ','Antarctica','people-and-society',65,'Population: no indigenous inhabitants, but there are
seasonally staffed research stations
note: approximately 27 nations, all signatory to the
Antarctic Treaty, send personnel to perform seasonal
(summer) and year-round research on the continent
and in its surrounding oceans; the population of
persons doing and supporting science on the
continent and its nearby islands south of 60 degrees
south latitude (the region covered by the Antarctic
Treaty) varies from approximately 4,000 in summer to
1 ,000 in winter; in addition, approximately 1 ,000
personnel including ship''s crew and scientists doing
onboard research are present in the waters of the
treaty region; summer (January) population - 3,687
total; Argentina 302, Australia 201 , Belgium 1 3, Brazil
80, Bulgaria 16, Chile 352, China 70, Finland 11,
France 100, Germany 51 , India 60, Italy 106, Japan
136, South Korea 14, Netherlands 10, NZ60, Norway
40, Peru 28, Poland 70, Russia 254, South Africa 80,
Spain 43, Sweden 20, UK 192, US 1,378 (1998-99);
winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France
33, Germany 9, India 25, Japan 40, South Korea 14,
NZ 10, Poland 20, Russia 102, South Africa 10, UK
39, US 248 (1998-99); year-round stations - 42 total;
Argentina 6, Australia 4, Brazil 1, Chile 4, China 2,
Finland 1 , France 1 , Germany 1 , India 1 , Italy 1 , Japan
1 , South Korea 1 , NZ 1 , Norway 1 , Poland 1 , Russia
6, South Africa 1, Spain 1, Ukraine 1, UK 2, US 3,
Uruguay 1 (1998-99); summer-only stations - 32 total;
Argentina 3, Australia 4, Bulgaria 1 , Chile 7, Germany
1, India 1, Japan 3, NZ 1, Peru 1, Russia 3, Sweden
2, UK 5 (1998-99); in addition, during the austral
summer some nations have numerous occupied
locations such as tent camps, summer-long
temporary facilities, and mobile traverses in support of
research (July 2002 est.)','0f8fa887430b0f5af0719989659444f62e1c1b3b8cf7d234a1fd59c7bf1693f9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c61e5e2f29346d589efab9b9b0db8ae9da2fd315acdd04ad0c165cd876cafb',2002,'AG','Antigua and Barbuda','people-and-society',74,'Population: 67,448 (July 2002 est.)
Age structure:
0-14 years: 28% (male 9,618; female 9,293)
15-64 years: 67.3% (male 22,695; female 22,682)
65 years and over: 4.7% (male 1,289; female 1,871)
(2002 est.)
Population growth rate: 0.69% (2002 est.)
Birth rate: 18,84 births/1,000 population (2002 est.)
Death rate: 5.75 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.23 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years:) male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
infant mortality rate: 21.61 deaths/1,000 live births
(2002 est)
Life expectancy at birth:
total population: 71 .02 years
male: 68.72 years
female: 73.45 years (2002 est.)
Total fertility rate: 2.29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Antiguan(s), Barbudan(s)
ad/ecf/Ve.''Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant,
some Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
mate: 90%
female: 88% (1960 est.)','8f4232943c20d6f699bd82af1504ccad57d7a5e631c21b70bf59406d9490a43e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('123ec4d2253a7ea0f423edc61e4c8ac0f7d1748124b02f913339e810440a1ce3',2002,'AR','Argentina','people-and-society',87,'Population: 37,812,817 (July 2002 est.)
Age structure:
0-14 years: 26.3% (male 5,090,046; female
4,854,761)
15-64 years: 63.2% (male 11,968,135; female
11,937,709)
65 years and over: 1 0.5% (male 1 ,636,332; female
2,325,834) (2002 est.)
Population growth rate: 1.13% (2002 est.)
Birth rate: 18.23 births/1 ,000 population (2002 est.)
Death rate: 7.57 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 ma(e(s)/female
1 5-64 years: 1 male(s)/female
65 years and over: 07 male(s)/fema!e
total population: 0.98 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 17.2 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.48 years
male: 72.1 years
female: 79.03 years (2002 est.)
Total fertility rate: 2.41 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.69%
(1999 est.)
HIV/AIDS - people living with HIWAIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 1,800 (1999 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian)
97%, mestizo, Amerindian, or other nonwhite
groups 3%
Religions: nominally Roman Catholic 92% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 4%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
mate: 96.2%
fema/e;96.2%-{1995 est.)
Population: 5,884,491 (July 2002 est.)
Age structure:
0-74 yea/s: 38.7% (male 1,156,366; female
1,119,558)
15-64 years: 56.6% (male 1,671,721; female
1,658,683)
65 years and over: 4.7% (male 128,137; female
150,026) (2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 30.5 births/1 ,000 population (2002 est.)
Death rate: 4.69 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.09 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years:] .03 male(s)/female
15*64 years: t01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1, 01 male(s)/female (2002 est.)
infant mortality rate: 28.75 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.16 years
male: 71. 67 years
female: 7677 years (2002 est.)
Total fertility rate: 4.07 children bom/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 0. 1 1 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS -deaths: 220 (1999 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%
Religions: Roman Catholic 90%, Mennonite, and
other Protestant
Languages: Spanish (official), Guarani (official)
Literacy:
definition: age 15 and over can read and write
total population: 92.1%
ma/e;93,5%
fema/e: 90.6% (1995 est.)
Population: 27,949,639 (July 2002 est.)
Age structure:
0-14 years: 34% (male 4,820,892; female 4,671 ,205)
15-64 years: 61.1% (male 8,598,328; female
8,492,830)
65 years and over: 4.9% (male 627,601 ; female
738,783) (2002 est.)
Population growth rate: 1.66% (2002 est.)
Birth rate: 23.36 births/1,000 population (2002 est.)
Death rate: 5.74 deaths/1 ,000 population (2002 est.)
Net migration rate:'' -1.05 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 101 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 38.18 deaths/1 ,000 live births
(2002 est.)
409
Peru (continued)
Life expectancy at birth:
total population: 70.59 years
male: 68. 18 years
female: 73.1 2 years (2002 est.)
Total fertility rate: 2.89 children bomAwoman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 48,000
(1999 est.)
HIV/AIDS - deaths: 4,100 (1999 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic 90%
Languages: Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 15 and over can read and write
total population: 88. 3%
mate; 94.5%
femate; 83% (1995 est)
Population: 84,525,639 (July 2002 est.)
Age structure:
0-14 years: 36.6% (male 15,731 ,451; female
15,169,264)
15-64 years: 59.7% (male 24,990,500; female
25,478,245)
65 years and over: 3.7% (male 1 ,399,862; female
1,756,317) (2002 est.)
Population growth rate: 1.99% (2002 est.)
Birth rate: 26.88 births/1 ,000 population (2002 est.)
Death rate: 5.95 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 migrant(s)/1 ,000 population
■ (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/iemale
under 15 years: 1.04 maie(s)/female
15-64 years: 0.98 male(s)/fema1e
65 years and over: 0.8 ma!e(s)/fema!e
total population: 0.99 male(s)/fema!e (2002 est.)
Infant mortality rate: 27.87 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.1 2 years
male: 65.26 years
fe/nafe; 71. 12 years (2002 est.)
Total fertility rate: 3.35 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 28,000
(1999 est.)
HIV/AIDS -deaths: 1,200 (1999 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91 .5%, Muslim
Malay 4%, Chinese 1.5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: two official languages - Filipino (based
on Tagalog) and English; eight major dialects -
•Tagalog, Cebuano, llocan, Hiligaynon or llonggo,
Bicol, Waray, Pampango, and Pangasinense
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)
Population: 47 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -1.32% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio; NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: HA years
female: HA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 1 00%
Languages: English (official), Pitcairnese (mixture of
an 1 8th century English dialect and a Tahitian dialect)
Literacy: NA','ebb30e15c76def113e70edfd50f5ef7fa6d99c1f2261ede547bb735d2f661561','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bdc0a43f46507be0920aa9d0205957427c2846051b9f72d4b08286ea49be0e1',2002,'AM','Armenia','people-and-society',93,'Population: 3,330,099
note: Armenia''s first census since independence was
conducted in October 2001 , but official figures have
not yet been released (July 2002 est.)
Age structure:
0-14 years: 22.2% (male 374,597; female 363,115)
15-64 years: 67.7% (male 1,104,100; female
1,150,282)
65 years and over: 10.1% (male 141,330; female
196,675) (2002 est.)
Population growth rate: -0.15% (2002 est.)
Birth rate: 12 births/1 ,000 population (2002 est.)
Death rate: 9.94 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.51 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 41 .07 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.59 years
ma/e: 62.27 years
female: 71 .12 years (2002 est.)
Total fertility rate: 1 .53 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Apostolic 94%, other
Christian 4%, Yezidi (Zoroastrian/animist) 2%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
Population: 70,441 (July 2002 est.)
Age structure:
0-14 years: 21% (male 7,635; female 7,169)
15-64 years: 68.4% (male 23,270; female 24,906)
65 years and over: 1 0.6% (male 3,081 ; female 4,380)
(2002 est)
Population growth rate: 0.59% (2002 est.)
Birth rate: 12.22 births/1 ,000 population (2002 est.)
Death rate: 6.29 deaths/1 ,000 population (2002 est,)
Net migration rate: NEGL migrant(s)/1,000
population (2002 est.)
Sex ratio:
atbirtfrA.05 male(s)/female
under 1 5 years:!. 07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 6.26 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.67 years
male: 75.32 years
female: 82.1 9 years (2002 est.)
Total fertility rate: 1 .8 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Aruban(s)
adjective: Aruban; Dutch
Ethnic groups: mixed white/Caribbean
Amerindian 80%
Religjbns: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy;
definition: NA
total population: 97%
male:NA%
female: NA%
Population: no indigenous inhabitants
note: Indonesian fishermen are allowed access to the
lagoon and fresh waster at Ashmore Reef''s West
island
People - note: the landing of illegal immigrants from
Indonesia''s Rote Island has become an ongoing
problem','1a05e5032a971a93785bafc58bdc03223484d59fe249b2bd39ddc6ee86e7b459','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('476457f81d5d5b719a243bec61dea7f04eeac2058f21a2b91b03f8bb024181dc',2002,'AZ','Azerbaijan','people-and-society',101,'Population: 7,798,497 (July 2002 est.)
Age structure:
0-14 years: 28.3% (male 1 ,122,340; female 1,082,355)
15-64 years: 64.3% (male 2,441,830; female
2,577,109)
65 years and over, 7.4% (male 228,735; female
346,128) (2002 est.)
Population growth rate: 0.38% (2002 est.)
Birth rate: 18.84 births/1,000 population (2002 est.)
Death rate: 9.61 deaths/1,000 population (2002 est.)
Net migration rate: -5.41 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/fema!e
under 15 years: 1.04 mate(s)/femate
15-64 years: 0.95 male(s)/female
65 years and over: 0.66 ma!e(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 82.74 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.06 years
male: 58.8 years
female: 67.53 years (2002 est.)
Total fertility rate: 2.29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
/ron:Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90% t Dagestani 3,2%,
Russian 2.5%, Armenian 2%, other 2.3% (1998 est.)
note: almost ail Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
lower
Languages: Azerbaijani (Azeri) 89%, Russian 3%,
Armenian 2%, other 6% (1995 est.)
Literacy:
definition: aye 15 and over can read and write
total population: 97%
male: 99%
fema/e;96%(1989est.)
Population: 300,529
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 29% (male 43,964; female 43,250)
15-64 years: 64.7% (male 95,508; female 98,859)
65 years and over: 6.3% (male 7,948; female 1 1 ,000)
(2002 est.)
Population growth rate: 0.86% (2002 est.)
Birth rate: 1 8.69 births/1 ,000 population (2002 est.)
Death rate: 7.49 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.63 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .02 ma!e(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 17.08 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.87 years
mate; 66.32 years
female: 73.49 years (2002 est.)
Total fertility rate: 2.28 children born/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 4. 1 3%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 6,900
(1999 est.)
HIV/AIDS - deaths: 500 (1 999 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 12%, Asian and
Hispanic 3%
Religions: Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages: English, Creole (among Haitian
immigrants)
Literacy:
definition: age 15 and over can read and write
total population: 98.2%
male: 98.5%
female: 98% (1995 est.)','a27a82e529fb8fd7cb30f1e71413720c28a37239565351765bc5d74ce7cbccaf','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b99b4e660cd8e29dd29be3799fdfdd1d30715b20d589b50b0be2410f9ea2766',2002,'BH','Bahrain','people-and-society',116,'Population: 656,397
note: includes 228,424 non-nationals (July 2002 est.)
Age structure:
0-14 years: 29.2% (male 97,022; female 94,605)
15-64 years: 67.7% (male 261 ,91 9; female 1 82,727)
65 years and over: 3.1 % (male 10,230; female 9,894)
(2002 est.)
Population growth rate: 1 .67% (2002 est.)
Birth rate: 1 9.53 births/1 ,000 population (2002 est.)
Death rate: 3.95 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .09 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
''under 15 years: 1 .03 male(s)/female
15-64 years: 1 .43 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.29 male(s)/female (2002 est.)
Infant mortality rate: 1 9.1 8 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.47 years
male: 71 .05 years
female: 75.96 years (2002 est.)
Total fertility rate: 2.75 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1 999 est)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noua''Bahraini(s)
adjective: Bahra\\n\\
Ethnic groups: Bahraini 63%, Asian 19%, other
Arab 10%, Iranian 8%
Religions: Shi''a Muslim 70%, Sunni Muslim 30%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 15 and over can read and write
total population: 88.5%
mate; 91 .6%
female: 84.2% (2002 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; a cemetery and remnants of structures
from early settlement are located near the middle of
the west coast; visited annually by US Fish and
Wildlife Service (July 2002 est)
Population: 133,376,684 (July 2002 est.)
Age structure:
0-14 years: 33.8% (male 23,069,242; female
21,995,457)
15-64 years: 62,8% (male 42,924,778; female
40,873,077)
65 years and over: 3.4% (male 2,444,314; female
2,069,816) (2002 est.)
Population growth rate: 1.59% (2002 est.)
Birth rate: 25,12 births/1,000 population (2002 est.)
Death rate: 8.47 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.75 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af£i/rfrt:1.06ma!e(s)/female
under 15 years: 1 .05 male(s)/femate
15-64 years: 1 .05 male(s)/female
65 years and oven 1 .18 male(s)/female
total population-Am male(s)/female (2002 est.)
Infant mortality rate: 68.05 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.92 years
male: 61 .08 years
female: 60.74 years (2002 est.)
Total fertility rate: 2.72 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 0.02%
(1999 est.)
. HIV/AIDS - people living with HiV/AIDS: 13,000
(1999 est.)
HIV/AIDS -deaths: 1,000 (1999 est.)
43
Bangladesh (continued)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladeshi
Ethnic groups: Bengali 98%, tribal groups,
non-Bengali Muslims (1998)
Religions: Muslim 83%, Hindu 16%, other 1%
(1998)
Languages: Bangla (official, also known as Bengali),
English
Literacy:
definition: age 15 and over can read and write
total population: 56%
mate: 63%
female: 49% (2000 est.)','2c3e29273e880fef4f994e9c04262c7b5649414543ee96140855afcf19471f7e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ee43f8a721f37bd5f1d994a712235eb06e15ba625bcc770e09ce1e5899c8ad5',2002,'BB','Barbados','people-and-society',131,'Population: 276,607 (July 2002 est.)
Age structure:
0-14 years: 21 .4% (male 29,888; female 29,338)
15-64 years: 69.8% (male 94,214; female 98,81 1)
65 years and over: 8.8% (male 9,378; female 14,978)
(2002 est.)
Population growth rate: 0.46% (2002 est.)
Birth rate: 13.32 births/1 ,000 population (2002 est.)
Death rate: 8.38 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.31 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.01 ma!e(s)/femate
under 15 years: 1.02 mate(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.63 male(s)/fema!e
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 1 1 .71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.49 years
male: 70.9 years
female: 76.12 years (2002 est.)
Total fertility rate: 1 .64 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,800
(1999 est.)
HIV/AIDS -deaths: 130 (1999 est.)
Nationality:
noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 90%, white 4%, Asian and
mixed 6%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97.4%
male: 98%
female: 96.8% (1995 est.)','0925fee25a0fbd161c1ac83577d1de34d264e1502a429438dfbd5317d82815ec','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fef5aa9cd71622326fe60bda5faed4b9b1ef9dbf3749de79a6fa29af616a670',2002,'MZ','Mozambique','people-and-society',142,'Population: uninhabited (July 2002 est.)
Population: 614,382 (July 2002 est)
Age structure:
0-14 years: 42.9% (male 132,013; female 131 ,282)
15-64 years: 54.2% (male 164,245; female 168,793)
65 years and over: 2.9% (male 8,588; female 9,461 )
(2002 est.)
Population growth rate: 2.99% (2002 est.)
Birth rate: 39.01 births/1,000 population (2002 est.)
Death rate: 9.1 deaths/1 ,000 population (2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/fema!e
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 ma1e(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 81 .79 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.79 years
male: 58.56 years
female: 63.09 years (2002 est.)
Total fertility rate: 5.26 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1 2%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Comoran(s)
atffeclfve: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 98%, Roman Catholic 2%
Languages: Arabic (official), French (official),
Shikomoro (a blend of Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
fofa/popt//af/on:57.3%
male: 64.2%
female: 50.4% (1995 est.)
Population: 55,225,478
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 48.2% (male 13,369,493; female
13,256,174)
15-64 years: 49.3% (mate 13,343,303: female
13,860,996)
118
Congo, Democratic Republic of the (continued)
65 years and over: 2.5% (male 581 ,568; female
813,944) (2002 est.)
Population growth rate: 2.79% (2002 est.)
Birth rate: 45.55 births/1,000 population (2002 est.)
Death rate: 14.93 deaths/1 ,000 population
(2002 est)
Net migration rate: -2.75 migrant(s)/1 ,000
population
note: one million refugees fled into Zaire (now called
the Democratic Republic of the Congo or DROC) in
1994 as a result of the ethnic fighting in Rwanda;
fighting in the DROC between rebels and government
forces in October 1996 caused 875,000 refugees to
return to Rwanda in late 1996 and early 1997 and
additional refugees have returned in subsequent
years; fighting between the Congolese government
and Uganda- and Rwanda-backed Congolese rebels
spawned a regional war in DROC in August 1998,
which left 1.8 million Congolese displaced in DROC
and caused 300,000 Congolese refugees to flee to
surrounding countries (2002 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 98.05 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.13 years
male: 47.19 years
female: 51 .1 3 years (2002 est.)
Total fertility rate: 6.77 children bom/woman
(2002 est.)
HIV/AIDS- adult prevalence rate: 5.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .1
million (1999 est.)
HIV/AIDS - deaths: 95,000 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and indigenous beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili orSwahili), Kikongo, Tshiluba
Literacy:
definition: age 1 5 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 11 ''.3%
male: 86.6%
female: 67.7% (1995 est.)
Population: no indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)
Population: no indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)
Population: 22,548,009 (July 2002 est.)
Age structure:
0-14 years: 21% (male 2,464,290; female 2,268,627)
15-64 years: 70% (male 8,010,014; female
7,774,296)
65 years and over: 9% (male 1 ,053,975; female
976,807) (2002 est.)
Population growth rate: 078% (2002 est.)
Birth rate: 14.21 births/1,000 population (2002 est.)
Death rate: 6.08 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.3 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1 .09 male(s)/female
15-64 years: 1,03 male(s)/female
65 years and over: 1 .0B male(s)/fema!e
total population:). OS mate(s)/fema!e (2002 est.)
Infant mortality rate: 6.8 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.74 years
male: 73.99 years
female: 79.71 years (2002 est.)
Total fertility rate: 1 .76 children born/woman
(2002 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
Literacy:
definition: age 15 and over can read and write
total population: 86% (1980 est.)
male: 93% (1980 est.)
female: 79% (1980 est)
note: literacy for the total population has reportedly
increased to 94% (1 998 est.)','fbc0fabb3de3eef89717a1e896585c328d4582d5857b7f6b56991c848596edfb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f68c9237f5b4d26c33a958e6cd18d0abe5ec8c7128f11a383dba4075e691f3c',2002,'FR','France','people-and-society',150,'Population: 1 0,335,382 (July 2002 est.)
Age structure:
014 years: 17.3% (mate 914,579; female 876;346)
15-64 years: 68.6% (male 3,443,859; female
3,643,628)
65 years and over: 14.1% (male 482,624; female
974,346) (2002 est.)
Population growth rate: -0.14% (2002 est.)
Birth rate: 9.86 births/1 ,000 population (2002 est.)
Death rate: 13.99 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.78 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 mate(s)/f emale
total pdpulation:0.W ma!e(s)/female (2002 est.)
Infant mortality rate: 14.12 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.28 years
male: 62.3 years
female: 74.56 years (2002 est.)
Total fertility rate: 1 .31 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.28%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS -deaths: 400 (1999 est)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Belarusian 81 .2%, Russian 1 1 .4%,
Polish, Ukrainian, and other 7.4%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Belarusian, Russian, other
48
Belarus (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 9B%
male: 99%
female: 97% (1989 est.)
Population: 1 0,274,595 (July 2002 est.)
Age structure:
OA A years: 17.3% (male 91 1 ,729; female 871 ,470)
15-64 years: 65.6% (male 3,395,885; female
3,341,536)
65 years and over. 17.1% (male 71 6,673; female
1,037,302) (2002 est.)
Population growth rate: 0.15% (2002 est.)
Birth rate: 10.58 births/1,000 population (2002 est.)
Death rate: 10.08 deaths/1,000 population
(2002 est.)
Net migration rate: 0.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 4.64 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 78.1 3 years
male: 74.8 years
female: 81 .62 years (2002 est.)
Total fertility rate: 1 .61 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,700
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun;Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 58%, Walloon 31%, mixed
or other 11%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Dutch 60%, French 40%, German less
than 1%, legally bilingual (Dutch and French)
Literacy:
definition: age 1 5 and over can read and write
tofa/popu/af/on:98%
mate:NA%
female: NA%
Population: 262,999 (July 2002 est.)
Age structure:
0*14 years: 41 .6% (male 55,716; female 53,581)
15-64 years: 54.9% (male 73,068; female 71,368)
65 years and over: 3.5% (male 4,51 1 ; female 4,755)
(2002 est.)
Population growth rate: 2.65% (2002 est.)
Birth rate: 31.08 births/1,000 population (2002 est.)
Death rate: 4,6 deaths/1,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 24.31 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .46 years
male: 69.17 years
female: 73.87 years (2002 est.)
Total fertility rate: 3.96 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS -deaths: 170 (1999 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo48.7%, Creole 24.9%, Maya
10.6%, Garifuna 6.1%, other 9.7%
53
Belize (continued)
Religions: Roman Catholic 49.6%, Protestant 27%
(Anglican 5.3%, Methodist 3.5%, Mennonite 4.1%,
Seventh-Day Adventist 5.2%, Pentecostal 7.4%,
Jehovah''s Witnesses 1.5%), none 9.4%, other 14%
(2000)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib), Creole
Literacy:
definition: age 15 and over can read and write
total population: 70.3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as 75%
Population: 632 (July 2002 est.)
Age structure:
0- 14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -0,22% (2002 est.)
Birthrate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 80%, other 20% (2002 est.)
Languages: Malay (Cocos dialect), English
Population: 2,967 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 2.44% (2002 est)
Birthrate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Population: no indigenous inhabitants (July
2002 est.)
note: in 1 997, there were about 100 researchers
whose numbers vary from winter (July) to summer
(January)
Population: 1,233,353
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 33.3% (male 205,559; female 204,796)
15-64 years: 60.6% (male 376,103; female 371,422)
65 years and over: 6.1 % (male 37,220; female
38,253) {2002 est)
Population growth rate: 0.97% (2002 est.)
Birth rate: 27.24 births/1 ,000 population (2002 est.)
Death rate: 17.59 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over. 0.97 male(s)/female
total population: 1.01 maie(s)/female (2002 est.)
Infant mortality rate: 93.5 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.11 years
male: 48.01 years
female: 50.25 years (2002 est.)
Total fertility rate: 3.65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 9% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 23,000
(1999 est.)
HIV/AIDS - deaths: 2,000 (1 999 est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major
tribal groupings (Fang, Bapounou, Nzebi, Obamba),
other Africans and Europeans 154,000, including
10,700 French and 1 1 ,000 persons of dual nationality
Religions: Christian 55%-75%, animist, Muslim less
than 1%
Languages: French (official), Fang, Myene, Nzebi,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 15 and over can read and write
total population:
male: 737%
fema/e: 53.3% (1995 est.)
Population: 2,694,432 (July 2002 est.)
Age structure:
0-14 years: 32% (male 438,176; female 422,960)
75-04 yearc: 64.1% (male 864,033; female 865,172)
65 years and over: 3.9% (male 45,080; female
59,011X2002 est.)
Population growth rate: 1 .48% (2002 est.)
Birth rate: 21 .8 births/1 ,000 population (2002 est.)
Death rate: 7.01 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est)
Sex ratio:
at birth: 1.05 ma!e(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0,76 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 51 .97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.62 years
male: 62.47 years
female: 66.87 years (2002 est.)
Total fertility rate: 2.37 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS -deaths: NA
Nationality:
rtoun;Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol (predominantly Khalkha)
85%, Turkic (of which Kazakh is the largest group)
7%, Tungusic 4,6%, other (including Chinese and
Russian) 3.4% (1998)
Religions: Tibetan Buddhist Lamaism 96%, Muslim
(primarily in the southwest), Shamanism, and
Christian 4% (1998)
Languages: Khalkha Mongol 90%, Turkic, Russian
(1999)
Literacy:
definition: age 15 and over can read and write
total population: 97.8%
mate: 98%
female: 97.5% (2000)
Population: 8,437
note: an estimated 8,000 refugees left the island
following the resumption of volcanic activity in
July 1995; some have returned (July 2002 est.)
Age structure:
0-14 years: 23.6% (male 1,001; female 986)
15-64 years: 65% (male 2,624; female 2,864)
65 years and over: 1 1 .4% (male 508; female 454)
(2002 est.)
Population growth rate: 8.43% (2002 est.)
Birth rate: 17,54 births/1 ,000 population (2002 est.)
Death rate: 7.47 deaths/1 ,000 population (2002 est.)
Net migration rate: 74.2 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0,92 male(s)/female
65 years and over: 1 .12 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 7.98 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population:78.2 years
male: 76.1 years
female: 80.4 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)
Population: 1 1 6,394 (July 2002 est.)
Age structure:
0-14 years: 28.9% (male 17,093; female 16,497)
15-64 years: 64.8% (male 38,71 8; female 36,689)
65 years and over: 6.3% (male 3,188; female 4,209)
(2002 est.)
Population growth rate: 0.37% (2002 est.)
Birth rate: 17.54 births/1,000 population (2002 est.)
Death rate: 6.1 2 deaths/1 ,000 population (2002 est.)
Net migration rate: -7.69 migrant(s)''1,000
population (2002 est.)
Sex ratio:
afWrf/j:1.03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .06 male(s)/f emale
65 years and over: 0.76 mate(s)/female
total population: 1.03 maie(s)/female (2002 est.)
Infant mortality rate: 16.15 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.82 years
mate: 71 .07 years
female: 74.63 years (2002 est.)
Total fertility rate: 2.01 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groiips: black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%, other 7%
Religions: Anglican 47%, Methodist 28%, Roman
Catholic 13%, Hindu Seventh-Day Adventist, other
Protestant
Languages: English, French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 96%
mate: 96%
fema/e:96%(1970 est.)
Disputes - international: none
444
Saint Vincent and the Grenadines (continued)
Population: 59,778,002 (July 2002 est.)
Age structure:
0- 14 years: 1 8.7% (male 5,732,385; female
5,443,900)
15-64 years: 65.5% (male 19,803,478; female
19,381,734)
65 years and over: 1 5.8% (male 3,931 ,463; female
5,485,042) (2002 est.)
Population growth rate: 0.21% (2002 est.)
Birth rate: 1134 births/1,000 population (2002 est.)
Death rate: 10.3 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .06 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over 0.72 male(s)/female
total population: 0.97 male(s)/femafe (2002 est.)
Infant mortality rate: 5.45 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.99 years
male: 75.29 years
female: 80.84 years (2002 est.)
Total fertility rate: 1.73 children born/woman
{2002 est.)
HIV/AIDS -adult prevalence rate: 0.11%
(1999 est.)
HIV/AIDS - people living with HfV/AIDS: 20,800
(1999)
HIV/AIDS - deaths: 450 (1 999 est.)
Nationality:
noun: Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish
2.4%, Welsh 1.9%, Ulster 1.8%, West Indian, Indian,
Pakistani, and other 2.8%
Religions: Anglican and Roman Catholic 40 million,
Muslim 1.5 million, Presbyterian 800,000, Methodist
760,000, Sikh 500,000, Hindu 500,000, Jewish
350,000
Languages: English, Welsh (about 26% of the
population of Wales), Scottish form of Gaelic (about
60,000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99% (2000 est.)
male: NA%
female: NA%
Population: 2,163,667 (July 2002 est.)
note: in addition, there are about 182,000 Israeli
settlers in the West Bank and about 176,000 in East
Jerusalem (August 2001 est.)
Age structure:
0-14 years: 44.4% (male 492,446; female 468,321)
15-64 years: 52% (male 575,282; female 550,793)
65 years and over: 3.6% (male 33,1 63; female
43,662) (2002 est.)
Population growth rate: 3.39% (2002 est.)
Birth rate: 34.94 births/1,000 population (2002 est.)
Death rate: 4.26 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.18 migrant(s)/1,000
population (2002 est.)
Sex ratio:
affr/rfA:1.06male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 .04 ma!e(s)/fema!e
65 years and over: 0.76 male(s)/female
total population: 1.04 ma!e(s)/femate (2002 est.)
Infant mortality rate: 21 .24 deaths/1 .000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.47 years
ma/e; 70.76 years
female: 74.29 years (2002 est.)
Total fertility rate: 4.77 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','4ee7fefc0188d6cac438401945c6b9644fd3bbcba6839b1f3791332fc2d7e179','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3514ef65834cfcecdf7e27659a7376c725a595b0d8b44012ec0245f5b329d7b7',2002,'TG','Togo','people-and-society',163,'Population: 6,787,625
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 1,616,138; female
1,585,463)
15-64 years: 50.5% (male 1,665,439; female
1,764,966)
65 years and over: 2.3% (male 65,877; female
89,742) (2002 est.)
Population growth rate: 2.91% (2002 est.)
Birth rate: 43.66 births/1,000 population (2002 est.)
Death rate: 1 4.52 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/femate
under 15 years: 1. 02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 88.52 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.69 years
male: 48.81 years
female: 50.61 years (2002 est.)
Total fertility rate: 6.14 children born/woman
(2002 est.)
HIV/AIDS - aduit prevalence rate: 4.1% (2002)
HIV/AIDS - people living with HIV/AIDS: 160,000
(2002)
HIV/AIDS ■ deaths: 37,000 (2002)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese 1
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 1 5 and over can read and write
total population: 37.5%
male: 52.2%
female: 23.6% (2000)','4ff34278aa586fc1b11819f08623706de9162b7e1a67062fd26de3177428952b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab372a2651c10190a02a213fc2f0d58fd7b5762c0f3ee27b8e12dffa69e10fec',2002,'BM','Bermuda','people-and-society',172,'Population: 63,960 (July 2002 est.)
Age structure:
0-14 years: 19.2% (male 6,058; female 6,225)
15-64 years: 69,4% (male 21 ,950; female 22,442)
65 years and over: 1 1 .4% (male 3,1 63; female 4, 1 22)
(2002 est.)
Population growth rate: 0.69% (2002 est.)
Birth rate: 1 1 .82 births/1 ,000 population (2002 est.)
Death rate: 7.49 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.61 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 0.94 male(s)/fema!e
under 15 years: 0.97 male(s)/female
15-64 years: 0.98 ma!e(s)/femate
65 years and over: 0.77 ma!e(s)/f emale
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 9.28 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.3 years
mate: 75.21 years
female: 79.27 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Bermudian(s)
arf/ecr7Ve:Bermudian
Ethnic groups: black 58%, white 36%, other 6%
Religions: non-Anglican Protestant 39%, Anglican
27%, Roman Catholic 15%, other 19%
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1970 est.)','62684ad5980f0b5042c9b7294d3a30b227ae1ab641b752bfe8d777833f46f317','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fc89cd3bc783c7b1ed868af1df573f7f54840f86ece83a17e96db6f56c5d9a2',2002,'CN','China','people-and-society',181,'Population: 2,094,176
note: other estimates range as low as 810,000
(July 2002 est.)
Age structure:
0-14 years: 39.8% (male 431 ,883; female 401 ,386}
15-64 years: 56.2% (mate 606,184; female 571,310)
65 years and over: 4% (male 42,1 93; female 41 ,220)
(2002 est.)
Population growth rate: 2.15% (2002 est.)
Birth rate: 35.26 births/1 ,000 population (2002 est.)
Death rate: 13.74 deaths/1,000 population
(2002 est.)
Net migration rate: O migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1,08 male(s)/female
15-64 years: 1.06 mate(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.07 male(s)/female (2002 est.)
Infant mortality rate: 106.79 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 53.1 9 years
mate: 53.53 years
female: 52.83 years (2002 est.)
Total fertility rate: 5 children bom/woman
(2002 est.)
HiV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%
(includes Lhotsampas-one of several Nepalese
ethnic groups), indigenous or migrant tribes 15%
Religions: Lamaistic Buddhist 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 15 and over can read and write
fofa/popyfatfon; 42,2%
mate: 56.2%
fema/e:28.1%(1995 est.)
Population: 1 ,284,303,705 (July 2002 est.)
Age structure:
0-14 years: 24.3% (male 163,821,081; female
148,855,387)
15-64 years: 68.4% (male 452,354,428; female
426,055,713)
65 years and over: 7.3% (male 43,834,528; female
49,382,568) (2002 est.)
Population growth rate: 0.87% (2002 est.)
Birth rate: 15.85 births/1,000 population (2002 est.)
Death rate: 6.77 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.38 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1 .1 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 27.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .86 years
male: 70.02 years
female: 73.86 years (2002 est.)
Total fertility rate: 1 .82 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.2%
(2000-01 est.)
HIV/AIDS - people living with HIV/AIDS: 1.25
million (January 2001)
HIV/AIDS - deaths: 1 7,000 (1 999 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 .9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoist (Taoist), Buddhist, Muslim
1%-2%, Christian 3%-4%
note: officially atheist (2002 est.)
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic groups entry)
Literacy:
definition: age 15 and over can read and write
total population: 81 .5%
mate: 89.9%
female: 72.7% (1995 est.)
Population: 7,303,334 (July 2002 est.)
Age structure:
0-14 years: 17.5% (male 679,311; female 599,811)
15-64 years: 71. 6% (male 2,587,509; female
2,641,418)
65 years and over: ''10.9% (male 364,864; female
430,421) (2002 est.)
Population growth rate: 1.26% (2002 est.)
Birth rate: 10.92 births/1 ,000 population (2002 est.)
Death rate: 6.1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: 7.76 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 0.98 mate(s)/female
65 years and over: 0.85 male(s)/fema!e
total population: 0.99 male(s)/fema!e (2002 est.)
Infant mortality rate: 5.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.8 years
male: 77 A years
female: 82.69 years (2002 est.)
Total fertility rate: 1 .3 children bom/woman
(2002 est.) :
HIV/AIDS - adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - deaths: less than 100 (1 999 est)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English; both are
official
Literacy:
definition: age 1 5 and over has ever attended school
total population: 92.2%
male: 96%
femafe: 88.2% (1996 est.)
232
Hong Kong (continued)
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2002 est.)
Population: 10,075,034 (July 2002 est.)
Age structure:
0-Uyears: 16.4% (male 847,081; female 802,340)
15-64 years: 68.8% (male 3,406,701; female
3,528,087)
65 years and over: 14.8% (male 544,956; female
945,869) (2002 est.)
Population growth rate: -0.3% (2002 est.)
Birth rate: 9.34 births/1,000 population (2002 est.)
Death rate: 13.09 deaths/1,000 population
(2002 est.)
Net migration rate: 0.76 migrant(s)/1,000
population (2002 est.)
235
Hungary (continued)
Sex ratio:
at birth: 1.07 ma!e(s)/fema!e
under 15 years: 1.06 ma!e(s)/fema!e
15-64 years: 0.97 ma!e(s)/female
65 years and over: 0.58 male(s)/fema!e
total population: ''0.91 maie(s)/female (2002 est.)
Infant mortality rate: 8.77 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 71 .9 years
mate: 67.55 years
female: 76.55 years (2002 est.)
Total fertility rate: 1.25 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Roma 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 96.2%, other 1 .8%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
mate: 99%
female: 98% (1980 est.)
Population: 4,822,166 (July 2002 est.)
Age structure:
0-14 years: 34.4% (male 838,224; female 821,230)
15-64 years: 59.4% (male 1 ,403,328; female
1,459,914)
65 years and over 6.2% (male 1 1 3,861 ; female
185,609) (2002 est.)
Population growth rate: 1.45% (2002 est.)
Birth rate: 26.11 births/1,000 population (2002 est.)
Death rate: 9.1 deaths/1,000 population (2002 est.)
Net migration rate: -2.51 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/fema!e
65 years and over: 0.61 male(s)/female
totai population: 0.96 mate(s)/female (2002 est.)
Infant mortality rate: 75.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.56 years
male: 59.35 years
female: 67.98 years (2002 est.)
Total fertility rate: 3.16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kyrgyz 52.4%, Russian 1 8%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kyrgyz - official language, Russian -
official language
note: in December 2001 , the Kyrgyzstani legislature
made Russian an official language, equal in status to
Kyrgyz
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 99%
female: 96% (1969 est.)
Population: 461,833 (July 2002 est.)
Age structure:
0-14 years: 21. 8% (male 52,262; female 48,439)
15-64 years: 70.9% (male 154,942; female 172,647)
65 years and over; 7 ''.3% (male 13,616; female
19,927) (2002 est.)
Population growth rate: 1 .75% (2002 est.)
Birth rate: 12.19 births/1 ,000 population (2002 est)
Death rate: 3.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.08 migrant(s)/1 ,000
population (2002 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 0.9 ma1e(s)/female
65 years and over: 0,68 male(s)/fema!e
total population: 0.92 male(s)/fema!e (2002 est.)
Infant mortality rate: 4.44 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 81.78 years
male: 78.97 years
female: 84.73 years (2002 est.)
Total fertility rate: 1.31 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, Macanese (mixed
Portuguese and Asian ancestry), Portuguese, other
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Portuguese, Chinese (Cantonese)
310
Macau (continued)
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 93%
female: 86% (1981 est.)
Population: 2,054,800
note: a Framework Agreement ratified by Macedonia
on 16 November 2001 calls for a new census in 2002
(July 2002 est.)
Age structure:
0-14 years: 22.4% (male 239,638; female 221,446)
15-64 years: 67.2% (male 694,368; female 686,450)
65 years and over: 10.4% (male 94,214; female
118,684) (2002 est.)
Population growth rate: 0.41% (2002 est.)
Birth rate: 13.35 births/1 ,000 population (2002 est.)
Death rate: 7.74 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .49 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth:). 0B ma!e(s)/femate
under 15 years: 1.08 mafe(s)/female
75-64 years: 1 .01 ma!e(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 12.54 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.26 years
male: 72.01 years
female: 76.68 years (2002 est.)
Total fertility rate: 1.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 66.6%, Albanian
22.7%, Turkish 4%, Roma 2.2%, Serb 2.1%, other
2.4% (1994)
312
Macedonia, The Former Yugoslav Republic of (continued)
Religions: Macedonian Orthodox 67%, Muslim 30%,
other 3%
Languages: Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy:
definition:
total population: NA%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there are scattered garrisons occupied by
personnel of several claimant states (July 2002 est.)','5970d268fac7a8bde3921a8bae10d1f8a157748479f555385ea291a1b3444a33','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48ae2e48322a922eff493d11d5628775ae8e044cb70aa7fcfde93916bba1bcf7',2002,'NP','Nepal','people-and-society',192,'Population: 8,445,134 (July 2002 est.)
Age structure:
0-14 years: 37,8% (male 1,626,596; female
1,565,124)
15-64 years: 57.7% (male 2,383,852; female
2,491,823)
65 years and over: 4.5% (male 169,583; female
208,156) (2002 est.)
Population growth rate: i.69% (2002 est.)
Birth rate: 26.41 births/1,000 population (2002 est.)
Death rate: 8.05 deaths^ ,000 population (2002 est.)
Net migration rate: -1.42 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/femate
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.96 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 57.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.42 years
male: 61 .86 years
femate:67.1 years (2002 est.)
Total fertility rate: 3.37 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,200
(1999 est.)
HIV/AIDS - deaths: 380 (1 999 est.)
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, mestizo (mixed
white and Amerindian ancestry) 30%, Aymara 25%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 1 5 and over can read and write
tofa/popu/af/on: 83.1%
male: 90.5%
femate; 76% (1995 est.)','b6e11fb3ae91bd02f198e23ed43058a3fd97a1a1264f6c6e8ac76c57e5169be4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e287a4409f2af1d58858f728cab3429b8ab52cc94da65e6bd8ae0d3e7deec89c',2002,'PY','Paraguay','people-and-society',202,'Population: 3,964,388
note: all data dealing with population are subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2002 est)
Age structure:
0-14years: 19.8% (male 403,391; female 382,037)
15-64 years: 70.6% (male 1,432,559; female
1,366,224)
65 years and over 9.6% (male 161,659; female
218,518) (2002 est.)
Population growth rate: 0.76% (2002 est.)
Birth rate: 12.76 births/1,000 population (2002 est.)
Death rate: 8.1 deaths/1,000 population (2002 est.)
Net migration rate: 2.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.05 ma!e(s)/female
65 years and over: 0.74 male(s)/female
total population^ .02 male(s)/female (2002 est.)
Infant mortality rate: 23.53 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.02 years
ma/e: 69.3 years
female: 74.93 years (2002 est.)
Total fertility rate: 1.71 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun; Bosnian®
adjective: Bosnian
Ethnic groups: Serb 31 %, Bosniak 44%, Croat
17%, Yugoslav 5.5%, other 2.5% (1991)
note: Bosniak has replaced Muslim as an ethnic term
in part to avoid confusion with the religious term
Muslim - an adherent of Islam
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, Protestant 4%, other 10%
Languages: Croatian, Serbian, Bosnian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','e7a2b6e9cd1964bcb90c95634e6f68eefb3dfe49d77b501461dfc9de03628395','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab105d1b4d1b90e46bd8bf38cf1febade0675c195586ad309b69ebbfb5ac6d55',2002,'IT','Italy','people-and-society',213,'Population: 1,591,232
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 40% (male 319,988; female 316,961)
15-64 years: 55.8% (male 428,638; female 458,777)
65 years and over: 4.2% (male 26,965; female
39,903) (2002 est.)
Population growth rate: 0.18% (2002 est.)
Birth rate: 28.04 births/1,000 population (2002 est.)
Death rate: 26.26 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/fema!e
15-64 years: 0.93 male(s)/fema!e
65 years and oven 0.68 mate(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 64.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 35.29 years
ma/e: 35.1 5 years
female: 35.43 years (2002 est.)
Total fertility rate: 3.6 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 35.8%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 290,000
(1999 est.)
HIV/AIDS -deaths: 24,000 (1999 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Tswana (or Setswana) 79%,
Kalanga 11%, Basarwa 3%, other, including
Kgalagadi and white 7%
Religions: indigenous beliefs 85%, Christian 15%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total population: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Population: 900 (July 2002 est.)
Population growth rate: 1.15% (2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, French, various other
languages
Literacy:
definition:
total population: 100%
male: NA%
female: NA%
Population: 6,560,608
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 41 .8% (male 1 ,400,778; female
1,340,834)
15-64 years: 54.6% (male 1 ,774,61 9; female
1,806,568)
65 years and over: 3.6% (mate 1 12,1 00; female
125,709) (2002 est.)
Population growth rate: 2.34% (2002 est.)
Birthrate: 31.21 births/1 ,000 population (2002 est.)
Death rate: 5.74 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema1e
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0,89 ma!e(s)/female
total population: 1 male(s}/female (2002 est.)
Infant mortality rate: 30.48 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.77 years
male: 67.11 years
female: 70.51 years (2002 est.)
Total fertility rate: 4.03 children born/woman
(2002 est)
HIV/AIDS • adult prevalence rate: 1 .92%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 63,000
(1999 est.)
HIV/AIDS -deaths: 4,200 (1999 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 1 5 and over can read and write
fofa/popt//af/on:74%
mate: 74%
female: 74.1% (1999)
Population: 27,730 (July 2002 est.)
Age structure:
0-14 years: 161% (male 2,300; female 2,161)
15-64 years: 67.5% (male 9,102; female 9,625)
65 years and over: 1 6.4% (male 1 ,956; female 2,586)
(2002 est.)
Population growth rate: 1.41% (2002 est.)
Birth rate: 10.64 births/1 ,000 population (2002 est.)
Death rate: 7.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 1 .29 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
afW^;1.09male(s)/femate
under 15 years: 1 .06 ma!e(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.76 ma!e(s)/female
total population: 0.93 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 6.09 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 81 .33 years
male: 77.79 years
female: 85.18 years (2002 est.)
Total fertility rate: 1 .3 children bom/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: %%
mate: 97%
female: 95% (1976 est.)
Population: 7,301 ,994 (July 2002 est.)
Age structure:
0-14 years: 16.8% (male 629,513; female 597,472)
15-64 years: 67 7% (male 2,512,273; female
2,433,396)
65 years and over. 15.5% (male 461,722; female
667,618) (2002 est.)
Population growth rate: 0.24% (2002 est.)
Birth rate: 9.84 births/1,000 population (2002 est.)
Death rate: 8.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .37 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 ma!e(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.69 male(s)/female
total poputation: 0.97 male(s)/fema!e (2002 est.)
Infant mortality rate: 4.42 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.86 years
male: 76.98 years
female: 82.89 years (2002 est.)
Total fertility rate: 1 .47 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.46%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 17,000
(1999 est)
HIV/AIDS -deaths: 150 (1999 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, none 8.9% (1990)
Languages: German (official) 63.7%, French
(official) 19.2%, Italian (official) 7.6%, Romansch
0.6%, other 8.9%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
/ra?fe:NA%
female: NA%
Population: 17,155,814 (July 2002 est.)
note: in addition, about 40,000 people live in the
Israeli-occupied Golan Heights - 20,000 Arabs
(18,000 Druze and 2,000 Alawites) and about 20,000
Israeli settlers (August 2001 est.)
Age structure:
0-14 years: 39.3% (male 3,467,267; female
3,264,639)
15-64 years: 57.5% (male 5,052,841; female
4,817,662)
65 years and over: 3.2% (male 267,803; female
285,602) (2002 est.)
Population growth rate: 2.5% (2002 est.)
Birth rate: 30.1 1 births/1 ,000 population (2002 est.)
Death rate: 5.12 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/femafe
under 15 years: 1 .06 male(s)/female
15-64 years: 1.05 ma1e(s)/female
65 years and over. 0.94 male(s)/female
total population: 1.05 male(s)/female (2002 est.)
Infant mortality rate: 32.73 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.08 years
male: 67.9 years
female: 70.32 years (2002 est.)
Total fertility rate: 3.84 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noi/n: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and
other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French,
English somewhat understood
Literacy:
definition: a§e 15 and over can read and write
tote/ popu/afta 70.8%
male: 85.7%
female: 55.8% (1997 est.)','05f1ab0278d9709e959ffed3633e79ff55876ff7aba30b6fd1345ad259110973','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd4509f9ea19f4cef12bb52247daee7eb649357203ad018d191a8dc801f7149',2002,'CO','Colombia','people-and-society',224,'Population: 176,029,560
note: Brazil took an intercensal count in August 1996
which reported a population of 157,079,573; that
figure was about 5% lower than projections by the US
Census Bureau, which is close to the implied
underenumeration of 4.6% for the 1991 census;
estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can
result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates,
and changes in the distribution of population by age
and sex than would otherwise be expected
(July 2002 est.)
Age structure:
0-14 years: 28% {male 25,140,954; female
24,199,276)
15-64 years: 66.4% (male 57,424,151; female
59,409,928)
65 years and over: 5.6% (male 3,992,017; female
5,863,234) (2002 est.)
Population growth rate: 0.87% (2002 est.)
Birth rate: 18.08 births/1 ,000 population (2002 est.)
Death rate: 9.32 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.03 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1,04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/fema!e
totai population: 0.97 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 35.87 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.55 years
male: 59.4 years
female: 67 .91 years (2002 est.)
Total fertility rate: 2.05 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS -deaths: 18,000 (1999 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 80%
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 15 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)
Population: 41 ,008,227 (July 2002 est)
Age structure:
0-14 years: 31 .6% (male 6,552,961 ; female
6,399,666)
15-64 years: 63.6% (male 12,694,293; female
13,375,425)
65 years and over: 4.8% (male 886,921; female
1,098,961) (2002 est.)
Population growth rate: 1 .6% (2002 est.)
Birth rate: 21.99 births/1,000 population (2002 est)
Death rate: 5.66 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/femate
65 years and over: 0.81 male(s)/female
total population: 0.97 ma!e(s)/female (2002 est.)
113
Colombia (continued)
Infant mortality rate: 23.21 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70 .85 years
male: 67 years
female: 74.83 years (2002 est.)
Total fertility rate: 2.64 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.31 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 71,000
(1999 est.)
HIV/AIDS -deaths: 1,700 (1999 est.)
Nationality:
noun:Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 90%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: M 3%
ma/e:91,2%
female: 91.4% (1995 est.)
Population: 2,882,329 (July 2002 est.)
Age structure:
0-H years: 29.6% (male 433,494; female 418,120)
75-64 years: 64.3% (male 939,550; female 91 4,646)
SSyears and over: 6.1% (male 84,130; female
92,389) (2002 est.)
Population growth rate: 1.26% (2002 est.)
Birth rate: 18.6 births/1,000 population (2002 est.)
Death rate: 4.96 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .04 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 ma!e(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .02 male(s)/fema!e (2002 est.)
Infant mortality rate: 19.57 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.89 years
male: 73.14 years
female: 78.74 years (2002 est.)
Total fertility rate: 2.22 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 1 .54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 24,000
(1999 est.)
HIV/AIDS - deaths: 1 ,200 (1 999 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 15 and over can read and write
total population: 90.8%
ma/e: 91 .4%
female: 90.2% (1995 est.)','5815a02de0d544e5e86048335cd4d4b9200eecdf0034fbe9ac7fe515f2dd480d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6a9b4b92a460e754bab34eac0d74a06bf314bcc22101fd4f13c4a0c9a2aecc8',2002,'ID','Indonesia','people-and-society',231,'Population: no indigenous inhabitants
note: approximately 1 ,200 former agricultural workers
resident in the Chagos Archipelago, often referred to
as Chagossians or Hois, were relocated to Mauritius
and the Seychelles around the time of the construction
of UK-US military facilities; in 2001, there were
approximately 1 ,500 UK and US military personnel
and 2,000 civilian contractors living on the island of
Diego Garcia (July 2002 est.)
Population: 952,618 (July 2002 est.)
note: other estimates range as low as 800,000
(2002 est.)
Age structure: NA
Population growth rate: 7.26% (2002 est.)
Birth rate: 28.07 births/1 ,000 population (2002 est.)
Death rate: 6.52 deaths/1 ,000 population (2002 est.)
Net migration rate: 51 .07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio: NA
Infant mortality rate: 51 .99 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.85 years
male: 62.64 years
female: 67.17 years (2002 est.)
Total fertility rate: 3.88 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun; Timorese
adjective: Timorese
Ethnic groups: Austronesian (Malayo-Polynesian),
Papuan, small Chinese minority
Religions: Roman Catholic 90%, Muslim 4%,
Protestant 3%, Hindu 0.5%, Buddhist, Animist
(1992 est.)
Languages: Tetum (official), Portuguese (official),
Indonesian, English
note: there are a total of about 16 indigenous
languages, of which Tetum, Galole, Mambae, and
Kemak are spoken by significant numbers of people
151
East Timor (continued)
Literacy:
definition: age 15 and over can read and write
total population: 48% (2001)
male: NA%
female: NA%
Population: 231 ,328,092 (July 2002 est.)
Age structure:
0- 14 years: NA
15-64 years: NA
65 years and over: HA
Population growth rate: 1.54% (2002 est.)
Birth rate: 21.87 births/1,000 population (2002 est,)
Death rate: 6.28 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.21 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: HA
under15years:HA
15-64 years: HA
65 years and over: N A
total population: NA
Infant mortality rate: 39.4 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.63 years
mate: 66.24 years
female: 71.13 years (2002 est.)
Total fertility rate: 2.54 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 0.05% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 52,000
(1999 est.)
HIV/AIDS -deaths: 3,100 (1999 est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7,5%, coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%. Roman
Catholic 3%, Hindu 2%, Buddhist 1%, other 1% (1998)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which is Javanese
Literacy:
definition: age 1 5 and over can read and write
total population: 83.8%
male: 89.6%
fema/e:78%(1995 est.)
Population: 66,622,704 (July 2002 est.)
Age structure:
0-74 years: 31 .6% (male 10,753,21 8; female
10,273,015)
15-64 years: 63.7% (male 21,383,542; lemale
21,096,307)
65 years and over: 4.7% (male 1,633,016; female
1,483,606) (2002 est.)
Population growth rate: 0.77% (2002 est.)
Birth rate: 17.54 births/1,000 population (2002 est.)
Death rate: 5.39 deaths/1 ,000 population (2002 est.)
Net migration rate: -4,46 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 1 .1 male(s)/female
total population: "\\. 03 ma1e(s)/fema1e (2002 est.)
Infant mortality rate: 28.07 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.25 years
male: 68.87 years
female: 71 .69 years (2002 est.)
Total fertility rate: 2.01 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azeri 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur2%, Baloch
2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Banal 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
fofa/popu/atio/r 72.1%
male: 78.4%
femafe:65.8% (1994 est.)
Population: 24,001,816 (July 2002 est.)
Age structure:
0-14 years: 41 .1% (male 5,003,755; female
4,849,238)
15-64 years: 55.9% (male 6,794,265; female
6,624,662)
65 years and over: 3% (male 341 ,520; female
388,376) (2002 est.)
Population growth rate: 2.82% (2002 est.)
Birth rate: 34.2 births/1,000 population (2002 est,)
Death rate: 6.02 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
afWrtft:1.Q5 male(s)/female
under 15 years: 1 .03 male(s)/femate
15-64 years: 1 .03 male(s)/femate
65 years and over: 0.88 male(s)/female
total population^. 02 male(s)/female (2002 est.)
Infant mortality rate: 57.61 deaths/1,000 live births
(2002 est.)
249
Iraq (continued)
Life expectancy at birth:
total population: 67.38 years
male: 66.31 years
female: 68.5 years (2002 est.)
Total fertility rate: 4.63 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 58%
/na/e: 70.7%
female: 45% (1995 est.)
Population: 22,662,365 (July 2002 est.)
Age structure:
0-Myears:34.1% (male 3,974,532; female
3,753,407)
15-64 years: 61 .6% (male 6,995,451 ; female
6,969,435)
65 years and over: 4.3% (male 424,776; female
544,764) (2002 est.)
Population growth rate: 1.91% (2002 est.)
Birth rate: 24.22 births/1,000 population (2002 est.)
Death rate: 5. 16 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
nore: does not reflect net flow of an unknown number
of illegal immigrants from other countries in the region
(2002 est.)
319
Malaysia (continued)
Sex ratio:
at birth:]. 07 mate(s)/female
under 15 years: 1.06 ma!e(s)/female
15-64 years: 1 male(s)/fema!e
65 years and over: 0.78 ma!e(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 19.66 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .39 years
mate: 6875 years
female: 74.21 years (2002 est.)
Total fertility rate: 3,18 children bom/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 0.42%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 49,000
(1999 est.)
HtV/AIDS- deaths: 1,900 (1999 est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%,
Chinese 24%, Indian 8%, others 10% (2000)
Religions: Muslim, Buddhist, Daoist, Hindu,
Christian, Sikh; note - in addition, Shamanism is
practiced in East Malaysia
Languages: Bahasa Melayu (official), English,
Chinese dialects (Cantonese, Mandarin, Hokkien,
Hakka, Hainan, Foochow), Tamil, Telugu, Malayalam,
Panjabi. Thai: note • in addition, in East Malaysia
several indigenous languages are spoken, the largest
of which are Iban and Kadazan
Literacy:
definition: age 15 and over can read and write
total population: 83.5%
mate: 89.1%
female: 78.1% (1995 est.)
Population: 135,869 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA% (2002 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Chuukese, Kosrae(s),
Pohnpeian(s), Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean,
Ulithian, Woleaian, Nukuoro, Kapingamarangi
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
fe/7)a/e:88%(1980 est.)
Population: 4,452,732 (July 2002 est.)
Age structure:
0-14 years: 17.6% (male 404,212; female 378,660)
15-64 years: 75.3% (male 1 ,630,696; female
1724,532)
65 years and over: 7 A% (male 137,512; female
177,120) (2002 est.)
Population growth rate: 3.46% (2002 est.)
Birth rate: 1278 births/1 ,000 population (2002 est.)
Death rate: 4.28 deaths/1 ,000 population (2002 est.)
Net migration rate: 26.11 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 ma!e(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 078 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 3.6 dealhs/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80.29 years
mate: 77.34 years
female: 83.47 years (2002 est.)
Total fertility rate: 1 ,23 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1 9%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,000
(1999 est.)
HIV/AIDS - deaths: 210 (1999 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 767%, Malay 14%, Indian
7.9%, other 1.4%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 93.5%
mate: 97%
female: 89.8% (1999)','a2be984c527b721a3cfe977932d3c662cdf0426a576cbd285cd3da532969687d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('441524094b143978804da1d83eea3751a40599a909299fb791eb953f9208e206',2002,'IO','British Indian Ocean Territory','people-and-society',242,'Population: 21,272 (July 2002 est.)
Age structure:
0-14 years: 22.4% (male 2,401 ; female 2,351)
15-64 years: 72.7% (male 7,962; female 7,509)
65 years and over: 4.9% (male 565; female 484)
(2002 est.)
Population growth rate: 2.16% (2002 est.)
Birth rate: 15.09 births/1 ,000 population (2002 est.)
Death rate: 4.42 deaths/1 ,000 population (2002 est.)
Net migration rate: 10.91 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.02 ma!e(s)/female
15-64 years: 1 .06 mate(s)/female
65 years and over: 1.17 male(s)/fema!e
total population^. ,06 male(s)/female (2002 est.)
Infant mortality rate: 1 9.55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.85 years
male: 74.9 years
female: 76.84 years (2002 est.)
Total fertility rate: 1 .72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 83%, white, Indian, Asian and
mixed
Religions: Protestant 86% (Methodist 33%, Anglican
17%, Church of God 9%, Seventh-Day Adventist 6%,
Baptist 4%, Jehovah''s Witnesses 2%, other 2%),
Roman Catholic 10%, none 2%, other2% (1991)
Languages: English (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 97.8% (1991 est.)
male: NA%
female: NA%','3634931fd4a5d312a029387a5aacc8e90f1d9f3afcdfbfc0e9e9da1d82988c7f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('743393aa40af70705a3a338fbf3c93368f3ead51b7ce03d08b817328b84ab7e9',2002,'MY','Malaysia','people-and-society',246,'Population: 350,898 (July 2002 est.)
Age structure:
0-14 years: 30.2% (mate 54,038; female 51 ,833)
15-64 years: 67% (male 125,051 ; female 1 10,257)
65 years and over: 2.B% (male 4,609; female 5,110)
(2002 est.)
Population growth rate: 2.06% (2002 est.)
Birth rate: 20.06 births/1 ,000 population (2002 est.)
Death rate: 3.38 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.91 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 mate(s)/female
under 15 years: MM male(s)/female
15-64 years: 1.13 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.1 ma!e(s)/femate (2002 est.)
Infant mortality rate: 1 3.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.06 years
male: 71 .68 years
female: 76.56 years (2002 est.)
Total fertility rate: 2.4 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Bruneian(s)
ad/ecf/Ve: Bruneian
Ethnic groups: Malay 67%, Chinese 15%,
indigenous 6%, other 12%
Religions: Muslim (official) 67%, Buddhist 13%,
Christian 10%, indigenous beliefs and other 10%
Languages: Malay (official), English, Chinese
Literacy:
definition: age 1 5 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)','63c8760e7a95afab71f6ddd48c370215b40eef20ead095ebb52972d3e1eb9e64','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb7588f80c395426fa27eeb24e6f7337cd54b57825c43db6f636d15f6e6cfb3',2002,'BG','Bulgaria','people-and-society',255,'Population: 7,621 ,337 (July 2002 est.)
Age structure:
0-14 years: 14.6% (male 572,961 ; female 543,004)
15-64 years: 68.5% (male 2,569,199; female
2,648,461)
65 years and over: 1 6.9% (male 540,1 09; female
747,603) (2002 est.)
Population growth rate: -1.11 % (2002 est.)
Birth rate: 8.05 births/1,000 population (2002 est.)
Death rate: 14.42 deaths/1 ,000 population
(2002 est.)
Net migration rate: -4.74 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
afWrfh:1.06male(s)/female
under 15 years: 1.06 ma!e(s)/female
15-64 years: 0.97 male(s)/fema!e
65 years and over: 0.72 male(s)/fema!e
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 14.18 deaths/1,000 live births
(2002 est.)
78
Bulgaria (continued)
Life expectancy at birth:
total population: 71 .5 years
male: 67.98 years
female: 75.22 years (2002 est.)
Total fertility rate: 1.13 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 346
(2000)
HIV/AIDS - deaths: less than 1 00 (1999 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 83.6%, Turk 9.5%, Roma
4.6%, other 2.3% (including Macedonian, Armenian,
Tatar, Circassian) (1998)
Religions: Bulgarian Orthodox 83.8%, Muslim
12.1%, Roman Catholic 1.7%, Jewish 0.8%,
Protestant, Gregorian-Armenian, and other 1.6%
(1998)
Languages: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 98% (1999)
Population: 12,603,185
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.3% (male 3,007,675; female
2,960,697)
15-64 years: 49.8% (male 3,000,411; female
3,271,594)
65 years and over: 2.9% (male 1 51 ,976; female
210,832) (2002 est.)
Population growth rate: 2.64% (2002 est.)
Birth rate: 44.34 births/1 ,000 population (2002 est.)
Death rate: 1 7.07 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.84 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/femafe (2002 est.)
Infant mortality rate: 105.3 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 46.11 years
male: 45.45 years
female: 46.78 years (2002 est.)
Total fertility rate: 6.26 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 6.44%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 350,000
(1999 est.)
HIV/AIDS -deaths: 43,000 (1999 est)
Nationality:
noun: Burkinabe (singular and plural)
aojf''ec//Ve:Burkinabe
Ethnic groups: Mossi over 40%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), native African
languages belonging to Sudanlc family spoken by
90% of the population
Literacy:
definition: age 15 and over can read and write
total population: 36% (2001 )
male:Hk%
female: NA%','ffd0c2acf11aa3652d1c10f91926e427292cff99d5fdb7ddf9c2daddda2e31eb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117b4fc431795b933487bd2887739cf7f7bf8b46a99cad4ebc75cf2e0810408a',2002,'ET','Ethiopia','people-and-society',268,'Population: 42,238,224
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 28.6% (male 6,158,039; female
5,905,314)
15-64 years: 66.6% (male 13,976,047; female
14,162,467)
65 years and over 4.8% (male 905,476; female
1,130,881) (2002 est.)
Population growth rate: 0.56% (2002 est.)
Birth rate: 19.65 births/1 ,000 population (2002 est.)
83
Burma (continued)
Death rate: 12.25 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1.83 migran!(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 ma!e(s)/femal e
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/fema1e (2002 est.)
Infant mortality rate: 72.1 1 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 55.41 years
mate: 53.85 years
female: 57.07 years (2002 est.)
Total fertility rate: 2.23 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .99%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 530,000
(1999 est.)
HIV/AIDS -deaths: 48,000 (1999 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Indian 2%, Mon 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist 1%, other
2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 1 5 and over can read and write
total population: 83A%
mate: 88.7%
female: 77.7% (1995 est.)
note: these are official statistics; estimates of
functional literacy are likely closer to 30% (1 999 est.)
Population: 23,513,330
nofe; includes 5,360,526 non-nationals (July
2002 est.)
Age structure:
0-14 years: 42.4% (male 5,086,541 ; female
4,883,942)
15-64 years: 54.8% (male 7,493,304; female
5,396,985)
65 years and over. 2.8% (male 362,780; female
289,778) (2002 est.)
Population growth rate: 3.27% (2002 est.)
Birth rate: 37.25 births/1 ,000 population (2002 est.)
Death rate: 5.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.39 male(s)/femate
65 years and over: 1 .25 male(s)/female
total population: 1.22 male(s)/female (2002 est.)
Infant mortality rate: 49.59 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.4 years
male: 66.7 years
female: 70.2 years (2002 est.)
Total fertility rate: 6.21 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 78%
male: 84.2%
female: 69.5% (2002 est.)','e1cc46a928fa7b775331408217ab904c95c49f294ac6964839d43c0678dab15a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('910bea80c05881f3355790307ccff9fa0e67cda885b18c71a24480bb74bbd10d',2002,'TH','Thailand','people-and-society',277,'Population: 6,373,002
nofe: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 46.5% (male 1 ,497,865; female
1,466,455)
15-64 years: 50.7% (male 1,592,253; female
1,640,254)
65 years and over: 2.8% (male 71 ,91 5; female
104,260) (2002 est.)
Population growth rate: 2,36% (2002 est.)
Birth rate: 39.87 births/1,000 population (2002 est.)
Death rate: 1 6,3 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1.0$ male(s)/female
under 15 years: 1.02 male(s)/femate
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 69.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 45.94 years
male: 45.08 years
female: 46.83 years (2002 est.)
Total fertility rate: 6.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 1 .32%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 360,000
(1999 est.)
HIV/AIDS - deaths: 39,000 (1 999 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 23%, Muslim 10%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 1 5 and over can read and write
total population: 35.3%
mate: 49.3%
female: 22.5% (1995 est.)
Population: 5,777,180 (July 2002 est.)
Age structure:
0-14 years: 42,5% (male 1,233,659; female
1,219,872)
15-64 years: 54.2% (mate 1,543,246; female
1,591,419)
65 years and over: 3.3% (male 86,375; female
102,609) (2002 est.)
Population growth rate: 2.47% (2002 est.)
Birth rate: 37.39 births/1 ,000 population (2002 est.)
Death rate: 12.71 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at births. 03 male(s)/female
under 15 years: 1.01 mate{s)/fema!e
15-64 years: 0.97 ma!e(s)/femate
65 years and over. 0.84 ma!e(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 90.98 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 53.88 years
mate: 51 .95 years
female: 55.87 years (2002 est.)
Total fertility rate: 5.03 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS -people living with HIV/AIDS: 1,400
(1999 est.)
HIV/AIDS -deaths: 130 (1999 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
(including various Christian denominations 1.5%)
languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
fofa/popi/fetfon;57%
male: 70%
female: 44% (1999 est.)','a0134ef7bfb47c32cfbceadbf85d34eaa4cd4d3b1acf5f884656544e4721b158','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4ae05d58bc3e3478a9b8e286a86f1b3ca852fce4be74fcf4a0086778d44e6f',2002,'UG','Uganda','people-and-society',282,'Population: 12,775,324
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 40.7% (male 2,646,883; female
2,550,015)
15-64 years: 55.8% (male 3,373,692; female
3,758,736)
65 years and over: 3.5% (male 182,149; female
263,849) (2002 est.)
Population growth rate: 2.24% (2002 est.)
Birth rate: 32.93 births/1,000 population (2002 est.)
Death rate: 10.51 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 ma)e(s)/fema!e (2002 est.)
88
Cambodia (continued)
Infant mortality rate: 64 deaths/1,000 live births
{2002 est.)
Life expectancy at birth:
total population: 57 ''.1 years
male: 54.81 years
female: 59.5 years (2002 est.)
Total fertility rate: 4.66 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 4.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 220,000
(1999 est.)
HIV/AIDS -deaths: 14,000(1999651)
Nationality:
noun:Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhist 95%, other 5%
Languages: Khmer (official) 95%, French, English
Literacy:
definition: age 15 and over can read and write
total population: 35%
mate: 48%
female: 22% (1990 est.)
Population: 16,184,748
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 42.1% (male 3,443,505; female
3,367,571)
15-64 years: 54,5% (male 4,431,524; female
4,392,155)
65 years and over: 3.4% (male 253,242; female
296,751) (2002 est.)
Population growth rate: 2.36% (2002 est.)
Birth rate: 35.66 births/1,000 population (2002 est.)
Death rate: 1 2,08 deaths/1 ,000 population
(2002 est.)
Net migration rate: NA migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over. 0.85 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 68.79 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 54.36 years
ma/e: 53.51 years
female: 55.23 years (2002 est.)
Total fertility rate: 4.72 children bom/woman
(2002 est.)
HIWAIDS - adult prevalence rate: 7.73%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS -deaths: 52,000 (1999 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: indigenous beliefs 40%, Christian 40%.
Muslim 20%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
^ definition: age 1 5 and over can read and write
* total population: 63.4%
male: 75%
female: 52.1% (1995 est.)
Population: 7,317 (July 2002 est.)
Age structure:
0-14 years: 18.8% (male 698; female 678)
15-64 years: 71 .9% (male 2,727; female 2,531 )
65 years and over. 9.3% (male 296; female 387)
(2002 est.)
Population growth rate: 0.7% (2002 est.)
Birth rate: 13.26 births/1,000 population (2002 est.)
Death rate: 6.29 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over. 0.77 male(s)/female
total population: 1 ,04 male(s)/female (2002 est.)
Infant mortality rate: 21 .54 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.2 years
mate: 74.31 years
female: 80.23 years (2002 est.)
Total fertility rate: 1 .53 children bom/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent 50%, white 25%,
Chinese 25%
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
fema/e;98%(1987 est.)','e44519ef8ea9bd9324c800364f111c4f52104e99a169d23d0774a7a171447b12','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aa5410badf541a55cc9ca568d4fe07a8f8809a23625a055d81e50c6a8710690',2002,'CA','Canada','people-and-society',292,'Population: 31,902,268 (July 2002 est)
Age structure:
0-14 years: 18.7% (mate 3,059,023; female
2,910,203)
15-64 years: 68.4% (male 10,975,701; female
10,857,869)
65 years and over: 12.9% (male 1 ,743,654; female
2,355,818) (2002 est.)
Population growth rate: 0.96% (2002 est.)
Birth rate: 1 1 .09 births/1 ,000 population (2002 est.)
Death rate: 7,54 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth:). OS ma!e(s)/female
under 15 years: 1. 05 male(s)/female
15-64 years: 1.01 male(s)/fema!e
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 4.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.69 years
mate: 76.3 years
female: 83.25 years (2002 est.)
Total fertility rate: 1 .6 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.3% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 49,000
(1999 est.)
HIV/AIDS - deaths: 400 (1999 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 28%, French
origin 23%, other European 1 5%, Amerindian 2%,
other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions: Roman Catholic 46%, Protestant 36%,
other 18%
note: based on the 1991 census
Languages: English 59.3% (official), French 23.2%
(official), other 17.5%
Literacy:
definition: age 15 and over can read and write
total population: $7% (1986 est.)
ma/e;NA%
fema/e:NA%
Population: 408,760 (July 2002 est.)
Age structure:
0-14 years: 41 .9% (male 86,466; female 84,918)
15-64 years: 51 .5% (male 100,684; female 109,841)
65 years and over: 6.6% (male 10,363; lemale
16,488) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 27.81 births/1,000 population (2002 est.)
Death rate: 7.01 deaths/1 ,000 population (2002 est.)
Net migration rate: -12.26 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1. 02 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 51 .86 deaths/1 ,000 five births
(2002 est.)
Life expectancy at birth:
total population: 69.52 years
mate: 66.23 years
female: 72.91 years (2002 est.)
Total fertility rate: 3.91 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 775
(2001)
HIV/AIDS -deaths: 225 (as of 2001)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crtoulo (a blend of
Portuguese and West African words)
Literacy:
definition: age 15 and over can read and write
total population: 71 .6%
mate: 81 .4%
female: 63.8% (1995 est.)','d0cebee17f2c18a83927a72e05fc6bb5a3b1e1abb00a6dcc8b8cf59e9313ea28','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fceadda3ef47d5ba0bc9277081b2589d369f07b8ac7df7fccda41c58ad01659',2002,'HN','Honduras','people-and-society',307,'Population: 36,273 (July 2002 est.)
Age structure:
0-74 years: 22% (male 3,836; female 4,156)
15-64 years: 697% (male 12,335; female 12,929)
65 years and over: 8.3% (male 1 ,399; female 1 ,61 8)
(2002 est.)
Population growth rate: 2.03% (2002 est.)
Birth rate: 13.45 births/1 ,000 population (2002 est.)
Death rate: 5.24 deaths/1 ,000 population (2002 est.)
Net migration rate: 12.08 migrant(s)/1 ,000
population
note: major destination for Cubans trying to migrate to
the US (2002 est.)
Sex ratio:
at birth: 0.86 male(s)/female
under 15 years: 0.92 male(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.86 mate(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 9.89 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.18 years
male: 76.38 years
female: 81 .59 years (2002 est.)
Total fertility rate: 2.03 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun:Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Church of God,
other Protestant, Roman Catholic
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
mate: 98%
femate:98%(1970est.)
Population: 3,642,739
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than woufd otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 43% (male 788,417; female 776,721)
15-64 years: 53.2% (male 951 ,908; female 986,947)
65 years and over: 3.8% (male 60,395; female
78,351) (2002 est.)
Population growth rate: 1 .8% (2002 est.)
Birth rate: 36.6 births/1,000 population (2002 est.)
Death rate: 18.62 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.77 ma!e(s)/female
total population: 0.98 male(s)/fema!e (2002 est.)
Infant mortality rate: 103.81 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 43.58 years
male: 42.08 years
/ema/e: 45. 13 years (2002 est.)
Total fertility rate: 4.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 3.84%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS - deaths: 23,000 (1999 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 33%, Banda 27%, Mandjia
13%, Sara 10%, Mboum 7%, M''Baka 4%, Yakoma
4%, other 2%
Religions: indigenous beliefs 35%, Protestant 25%,
Roman Catholic 25%, Muslim 15%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), tribal languages
Literacy:
definition: age 15 and over can read and write
total population: 60%
ma/e: 68.5%
female: 52.4% (1995 est.)
Population: 8,997,237 (July 2002 est.)
Age structure:
0-14 years: 47.8% (male 2,162,732; female
2,135,354)
15-64 years: 49.4% (male 2,108,1 34; female
2,340,189)
65 years and over. 2.8% (male 103,683; female
147,145) (2002 est.)
Population growth rate: 3.27% (2002 est.)
Birth rate: 47.74 births/1 ,000 population (2002 est.)
Death rate: 15.06 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.04 ma!e(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over. 0.7 male(s)/fema1e
total population: 0.95 male(s)/fema!e (2002 est.)
Infant mortality rate: 93.46 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .27 years
male: 49.22 years
female: 53.4 years (2002 est.)
Total fertility rate: 6.5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5%-7% (2001)
HIV/AIDS - people living with HIV/AIDS: 300,000
(2001)
HIV/AIDS - deaths: 14,000 (confirmed AIDS cases,
actual number far higher but difficult to estimate)
(2001)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: 200 distinct groups; in the north and
center: Arabs, Gorane (Toubou, Daza, Kreda),
Zaghawa, Kanembou, Ouaddai, Baguirmi, Hadjerai,
Fulbe, Kotoko, Hausa, Boulala, and Maba, most of
whom are Muslim; in the south: Sara (Ngambaye,
Mbaye, Goulaye), Moundang, Moussei, Massa, most
of whom are Christian or animist; about 1 ,000 French
citizens live in Chad
Religions: Muslim 51%, Christian 35%, animist 7%,
other 7%
Languages: French (official), Arabic (official). Sara
(in south), more than 120 different languages and
dialects
Literacy:
definition: age 15 and over can read and write French
or Arabic
total population: 40%
wale: 49%
female: 31% (1998) .
Population: 6,353,681 (July 2002 est.)
Age structure:
0-74 years: 37.4% (male 1,211,156; female
1,162,317)
15-64 years: 57.5% (male 1,735,744; female
1,922,395)
65 years and over: 5.1% (male 144,864; female
177,205) (2002 est.)
Population growth rate: 1.83% (2002 est.)
Birth rate: 28.3 births/1 ,000 population (2002 est.)
Death rate: 6.1 deaths/1,000 population (2002 est.)
Net migration rate: -3.88 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male (s)/female
under 15 years: 1 .04 male(s)tfemale
15-64 years: 0.9 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0,95 ma!e(s)/fema1e (2002 est.)
Infant mortality rate: 27.58 deaths/1 ,000 live births
(2002 est.)
158
El Salvador (continued)
Life expectancy at birth:
total population: 70.32 years
mate: 6672 years
female: 74.11 years (2002 est.)
Total fertility rate: 3,29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.6% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 25,000
(2000 est.)
HIV/AIDS -deaths: 1,300 (1999 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 90%, Amerindian 1%,
white 9%
Religions: Roman Catholic 83%
note: there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 10 and over can read and write
total population: 71 .5%
mate: 73.5%
female: 69.8% (1995 est.)','2fa20ab583eb055793b3c4a2e594d2937a19e44a1fa177d7a9ee6bc74a064d56','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2829d9392bd178a0ec662fa8e09215f0a976b379dc08bb27ea6611ad9b1a63b1',2002,'PE','Peru','people-and-society',318,'Population: 15,498,930 (July 2002 est.)
Age structure:
0-14 years: 26.9% (male 2,127,696; female
2,033,201)
15-64 years: 65.6% (male 5,070,476; female
5,103,490)
65 years and over: 7. ,5% (male 482,846; female
681,221) (2002 est.)
Population growth rate: 1 .09% (2002 est.)
Birth rate: 16.46 births/1,000 population (2002 est.)
Death rate: 5.59 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
104
Chile (continued)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 9.12 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.14 years
male: 72.83 years
female: 79.62 years (2002 est.)
Total fertility rate: 2.13 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est)
HIV/AIDS - deaths: 1 ,000 (1999 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 1 1 %,
Jewish NEGL%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.2%
mate: 95.4%
female: 95% (1995 est.)
Population: 1 3,447,494 (July 2002 est.)
Age structure:
0-14 years: 35.4% (male 2,415,764; female
2,337,095)
15-64 years: 60.2% (male 4,007,495; female
4,090,957)
65 years and over: 4.4% (male 276,482; female
319,701) (2002 est.)
Population growth rate: 1 .96% (2002 est.)
Birth rate: 25.47 births/1,000 population (2002 est.)
Death rate: 5.36 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.53 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 ma!e(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.99 ma!e(s)/female (2002 est.)
Infant mortality rate: 33.02 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .61 years
mate: 68.79 years
female: 74.57 years (2002 est.)
Total fertility rate: 3.05 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2001)
HIV/AIDS - people living with HIV/AIDS: 20,000
(2001 est.)
HIV/AIDS -deaths: 232(2001)
Nationality;
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and
white) 65%, Amerindian 25%, Spanish and others 7%,
black 3%
Religions: Roman Catholic 95%
153
Ecuador (continued)
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 15 and over can read and write
total population: §0A%
mate: 92%
female: 88.2% (1995 est.)','cf82940412eb0cfeadbd78e51f2604de623b4d387e484ec4ba7babf0a7f87bce','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a19bd09d6ade0acd8a53c0600b149e457b9d1a03d9ee06fa5cc3c37a89ad78c',2002,'CX','Christmas Island','people-and-society',327,'Population: 474 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -9% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 70%, European 20%,
Malay 10%
nofe: no indigenous population (2001)
Religions: Buddhist 36%, Muslim 25%, Christian
18%, other 21% (1997)
Languages: English (official), Chinese, Malay
Literacy: NA','3ac1fa5da917834ef6e89c40a78434e29b011199cdb9cda38e058b8af0f77910','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ff1ddc6db2f9224f20a63fd4b6ece57ffe3bcdbc8d84843fa1e78ca9308e581',2002,'CG','Congo','people-and-society',341,'Population: 2,958,448
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 42.4% (male 630,985; female 622,024)
15-64 years: 54.3% (male 783,238; female 823,882)
65 years and over: 3.3% (mate 39,369; female
58,950) (2002 est.)
Population growth rate: 2.18% (2002 est.)
Birth rate: 37.91 births/1,000 population (2002 est.)
Death rate: 1 6.1 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 97.91 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47.71 years
mate; 44.27 years
female: 51 .24 years (2002 est.)
Total fertility rate: 4.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 6.43%
(1999 est.)
HiV/AIDS - people living with HIV/AIDS: 86,000
(1999 est.)
HIV/AIDS - deaths: 8,600 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi
12%, Teke 17%, Europeans and other 3%
note: Europeans estimated at 8,500, mostly French,
before the 1997 civil war; may be half that in 1998,
following the widespread destruction of foreign
businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Ltngala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 15 and over can read and write
total population: 74.9%
male: 83.1%
female: 67.2% (1995 est.)','8e9470ab8289811e0257572df85a8c690751074d3cf1c9567d40e947c33d4090','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('319ddb8da93aa26d2dbb7b529632b7104b10955e320fccc53ac8fe19e00377d3',2002,'CK','Cook Islands','people-and-society',345,'Population: 20,81 1 (July 2002 est)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA% (2002 est.)
Birthrate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate; NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81.3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0.9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy:
definition: NA
5%''''
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station (July 2002 est.).','41b6c849f82807b25a83cc50327f3005a2c064f1d97024ea9254ecdae09531e3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c05ea180389cfce6354126521dd1a2be57d3791eca1ae39e94d67fdbeba6484',2002,'CR','Costa Rica','people-and-society',354,'Population: 3,834,934 (July 2002 est.)
Age structure:
0-14 years: 30.8% (male 603,270; female 575,766)
15-64 years: 63.9% (male 1 ,239,618; female
1,211,641)
65 years and over: 5,3% (male 95,1 82; female
109,457) (2002 est)
Population growth rate: 1 .61% (2002 est.)
Birth rate: 19.83 births/1 ,000 population (2002 est.)
Death rate: 4.31 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.52 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/fema!e
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/femaie
65 years and over: 0.87 male(s)/female
total population: 1 .02 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 10.87 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.22 years
male: 73.68 years
female: 78.89 years (2002 est.)
Total fertility rate: 2.42 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 2,000
(1999 est.)
HIV/AIDS -deaths: 750 (1999 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white (including mestizo) 94%, black
3%, Amerindian 1%, Chinese 1%, other 1%
Religions: Roman Catholic 76.3%, Evangelical
13.7%, other Protestant 0.7%, Jehovah''s Witnesses
1 .3%, other 4.8%, none 3.2%
Languages: Spanish (official), English spoken
around Puerto Limon
Literacy:
definition: age 15 and over can read and write
total population: 95.5%
ma/e:95.5%
female: 95.5% (1999 est.)','48e27e0aa60fcf5bd2d08f8a1dce4c991379d022bd1a8a3169220d9ae5ee2728','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f87f5acd4db200f7d324f221c04e35f5cb966c294bae83bba8b524025fab16c9',2002,'NI','Nicaragua','people-and-society',363,'Population: 16,804,784
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in tower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14years: 46% (male 3,874,651; female 3,847,080)
15-64 years: 51 .8% (male 4,468,242; female
4,238,998)
65 years and over: 2.2% (male 185,306; female
190,507) (2002 est.) ''
Population growth rate: 2.45% (2002 est.)
Birth rate: 39.99 births/1 ,000 population (2002 est.)
Death rate: 1674 deaths/1,000 population
(2002 est.)
Net migration rate: 122 migrant(s)/1 ,000
population
note: after Liberia''s civil war started in 1990, more
than 350,000 refugees fled to Cote d''ivoire; by the end
of 1 999 most Liberian refugees were assumed to have
returned (2002 est.)
128
Cote d''lvoire (continued)
Sex ratio:
afb/rf/i: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .05 male(s)/fema!e
65 years and over: 0.97 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 92.23 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 4472 years
male: 43.45 years
female: 46.03 years (2002 est.)
Total fertility rate: 5.61 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 10.76%
. (1999 est.)
HIV/AIDS -people living with HIV/AIDS: 1 million
(2000)
HIV/AIDS -deaths: 72,000 (1999 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Akan 42.1%, Voltaiques or Gur
17.6%, Northern Mandes 16.5%, Krous 11%,
Southern Mandes 10%, other 2.8% (includes 130,000
Lebanese and 20,000 French) (1998)
Religions: Christian 20-30%, Muslim 35-40%,
indigenous 25-40% (2001)
note: the majority of foreigners (migratory workers)
are Muslim (70%) and Christian (20%)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 1 5 and over can read and write
fo/a/popu/ate48.5%
male: 57%
female: 40%
Population: 5,023,818 (July 2002 est.)
Age structure:
0-14 years: 38.3% (male 980,621 ; female 945,386)
15-64 years: 58.7% (male 1,464,468; female
1,483,082)
65 years and over: 3% (male 65,61 0; female 84,651 )
(2002 est.)
Population growth rate: 2.09% (2002 est.)
Birth rate: 26.98 births/1 ,000 population (2002 est.)
Death rate: 4.76 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .3 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.78 male(s)/fema!e
total population: 1 male(s)/femaie (2002 est.)
Infant mortality rate: 32.52 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.37 years
male: 67.39 years
female: 71 .44 years (2002 est.)
Total fertility rate: 3,09 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2000/
01 est.)
HIV/AIDS - people living with HIV/AIDS: 4,800
(2000/01 est.)
HIV/AIDS -deaths: 360 (1999 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
377
Nicaragua (continued)
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 85%, Protestant
Languages: Spanish (official)
note: English and indigenous languages on Atlantic
coast
Literacy:
definition: age 15 and over can read and write
total population: 68.2% (1 999)
male: 67.1%
female: 70.5% (2000 est.)','48db564e8d7b8378526a7852c84673db1ff0f98374171ee2bbccc839360f32e9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3057769393a5a354555466c63b5802e8313ce0afc0d9a71af77dca5be0d29a2',2002,'SI','Slovenia','people-and-society',366,'Population: 4,390,751 (July 2002 est)
Age structure:
0-14 years: 1 8.3% (male 41 1 ,847; female 390,797)
15-64 years: 66.3% (male 1,461,305; female
1,448,973)
65 years and over: 1 5.4% (male 252,970; female
424,859) (2002 est.)
Population growth rate: 1.12% (2002 est.)
Birth rate: 1 2.8 births/1 ,000 population (2002 est.)
Death rate: 11.31 deaths/1,000 population
(2002 est.)
Net migration rate: 9.72 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years:]. OS male(s)/female
15-64 years: 1,01 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 7.06 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74. 1 3 years
mate: 70.52 years
female: 77.96 years (2002 est.)
Total fertility rate: 1 .93 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 350
(1999 est)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noi/n: Croat(s), Croatian(s)
adjective: Croatian
Ethnic groups: Croat 78.1%, Serb 12.2%, Bosniak
0.9%, Hungarian 0.5%, Slovene 0.5%, Czech 0.4%,
Albanian 0.3%, Montenegrin 0.3%, Roma 0.2%,
others 6,6% (1991)
Religions: Roman Catholic 76.5%, Orthodox 1 1 .1%,
Muslim 1.2%, Protestant 0.4%, others and unknown
10.8% (1991)
Languages: Croatian 96%, other 4% (including
Italian, Hungarian, Czech, Slovak, and German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
fema/e:95%(1991 est)','ba97eb66cf8776a96b6d53c60d6699ead4228b874e4cd397328dcc9441bbc48d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00a876a5d2a0ca738ebe287a06b222575b953fc68960783703c3b3bf92a92a75',2002,'CU','Cuba','people-and-society',376,'Population: 11,224,321 (July 2002 est,)
Age structure:
0-14 years: 20.6% (male 1,188,125; female
1,125,743)
15-64 years: 69.3% (male 3,902,162; female
3,880,531)
65 years and over: 10.1% (male 520,849; female
606,911) (2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 12,08 births/1 ,000 population (2002 est.)
Death rate: 7.35 deaths/1,000 population (2002 est.)
Net migration rate: -1.21 migrant(s)/1:000
population (2002 est.)
Sex ratio:
at birth: male(s)/femaie
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 ma1e(s)/fema!e
65 years and over: 0.86 ma!e(s)/female
total population: 1 ma!e(s)/female (2002 est.)
Infant mortality rate: 7.27 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 76.6 years
/ra/e:74.2 years
female: 79.15 years (2002 est.)
Total fertility rate: 1 .6 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.03%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 2,800
(2001 est.)
HIV/AIDS - deaths: 120 (1999 est)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51%, white 37%, black 1 1%,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 95.7%
ma/e:96.2%
female: 95.3% (1995 est.)
People - note: illicit migration is a continuing
problem; Cubans attempt to depart the island and
enter the US using homemade rafts, alien smugglers,
direct flights, or falsified visas; some 3,000 Cubans
took to the Straits of Florida in 2001 ; the US Coast
Guard interdicted about 25% of these migrants;
Cubans also use non-maritime routes to enter the US;
some 2,400 Cubans arrived overland via the
southwest border and direct flights to Miami in 2000
Population: 767,314 (July 2002 est.)
Age structure:
0-14 years: 22.4% (male 87,981 ; female 84,1 68)
15-64 years: 66.6% (male 258,414; female 252,778)
65 years and over: 1 1 % (male 36,607; female
47,366) (2002 est.)
Population growth rate: 0.57% (2002 est.)
Birth rate: 12.91 births/1,000 population (2002 est.)
Death rate: 7.63 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.43 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 105 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 7.71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.08 years
male: 74.77 years
female: 79.5 years (2002 est.)
Total fertility rate: 1.9 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400
(1999 est.)
HIV/AIDS -deaths: NA
Nationality:
rt(>wrCypriot(s)
adjective: Cypriot
Ethnic groups: Greek 85.2%, Turkish 1 1 .6%, other
3.2% (2000)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98.7%
female: 95% (1999)
Population: 10,256,760 (July 2002 est.)
Age structure:
0-14 years: 15.7% (male 828,273; female 786,617)
15-64 years: 70.3% (male 3,605,766; female
3,603,058)
65 years and over: 14% (male 551,852; female
881,194) (2002 est.)
Population growth rate: -0.07% (2002 est.)
Birth rate: 9.08 births/1,000 population (2002 est.)
Death rate: 1 0.76 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.96 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/fema!e
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 maie(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 ma1e(s)/female (2002 est.)
Infant mortality rate: 5.46 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 74 .95 years ■
mate: 71.46 years
female: 78.65 years (2002 est.)
Total fertility rate: 1.18 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1 999 est.)
Nationality:
noun: Czech(s)
adjective: Czech
Ethnic groups: .Czech 81.2%, Moravian 13.2%,
Slovak 3.1%, Polish 0.6%, German 0.5%, Silesian
0.4%), Roma 0.3%, Hungarian 0.2%, other 0.5%
(1991)
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech
Literacy:
definition: NA
total population: 99.9% (1999 est.)
male: NA%
female: NA%','92503dbbc395d54061ad9e5ae48418e710a99ab0e7d70ee99b8ae55ccaf02ceb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70c9d7f0f47efe63472034d13c03d61040795909bd88d6a8a022a384f58a71ec',2002,'SE','Sweden','people-and-society',387,'Population: 5,368,854 (July 2002 est.)
Age structure:
0-14 years: 18.7% (male 514,589; female 488,121)
15-64 years: 66.4% (male 1 ,806,722; female
1,760,149)
65 years and over: 14.9% (male 334,599; female
464,674) (2002 est.)
Population growth rate: 0.29% (2002 est.)
Birth rate: 1 1 .74 births/1 ,000 population (2002 est.)
Death rate: 10.81 deaths/1,000 population
(2002 est.)
Net migration rate: 2.01 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .06 male (s)/fem ale
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 .03 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 4.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.91 years
142
Denmark (continued)
male: 74.3 years
female: 79 .67 years (2002 est.)
Total fertility rate: 1 .73 children born/woman
(2002 est.)
HiV/AIDS * adult prevalence rate: 0.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,300
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun; Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Inuit, Faroese,
German, Turkish, Iranian, Somali
Religions: Evangelical Lutheran 95%, other
Protestant and Roman Catholic 3%, Muslim 2%
Languages: Danish, Faroese, Greenlandic (an Inuit
dialect), German (small minority)
note: English is the predominant second language
Literacy:
definition: age 15 and over can read and write
total population: 100%
mate:NA%
female: NA%
Population: 8,876,744 (July 2002 est.)
Age structure:
0-14 years: 18% (male 817,688; female 776,018)
15-64 years: 64.7% (male 2,922,095; female
2,824,770)
65 years and over: 1 7.3% (male 651 ,120; female
885,053) (2002 est.)
Population growth rate: 0.02% (2002 est.)
Birth rate: 9.81 births/1,000 population (2002 est.)
Death rate: 1 0.6 deaths/1 ,000 population (2002 est.)
492
Sweden (continued)
Net migration rate: 0.95 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.% mate(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 074 male(s)/female
total population: 0.98 male(s)/femafe (2002 est,)
Infant mortality rate: 3.44 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.84 years
mate: 77.1 9 years
female: 82.64 years (2002 est.)
Total fertility rate: 1 .54 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIWAIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: indigenous population: Swedes and
Finnish and Sami minorities; foreign-born or
first-generation immigrants: Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks
Religions: Lutheran 87%, Roman Cathofic,
Orthodox, Baptist, Muslim, Jewish, Buddhist
Languages: Swedish
note: small Sami- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%','4d42389a8ab1dd1af358c52790ecbd83ddbf27d90f7265940bfd0769cb656a40','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c694db168458697501b0b160c16ba9009cb4f2c36eafcce60c53d1e4b0966bf8',2002,'DJ','Djibouti','people-and-society',394,'Population: 472,810 (July 2002 est.)
Age structure:
0-14 years: 42.6% (male 100,903; female 100,420)
15-64 years: 54.5% (male 135,409; female 122,209)
65 years and over: 2.9% (male 7,220; female 6,649)
(2002 est.)
Population growth rate: 2.59% (2002 est.)
Birth rate: 40.33 births/1 ,000 population (2002 est.)
Death rate: 14.43 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1 ,09 ma!e(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 99.7 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .6 years
mate: 49.73 years
female: 53.52 years (2002 est.)
Total fertility rate: 5.64 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 1 .75%
(1999 est.)
HIV/AIDS - people living wHh HIV/AIDS: 37,000
(1999 est.)
HIV/AIDS -deaths: 4,400 (2002 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 1 5 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)
Population: 70,158 (July 2002 est.)
Age structure:
0-14 years: 28.3% (male 10,052; female 9,800)
15-64 years: 63.8% (male 23,01 1; female 21,782)
65 years and over: 7.9% (male 2,245; female 3,268)
(2002 est.)
Population growth rate: -0.81% (2002 est.)
Birth rate: 17.3 births/1 ,000 population (2002 est.)
Death rate: 7.1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: -18.26 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
aftfrf/?;1.05mate(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over. 0.69 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 15.94 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.86 years
male: 70.98 years
female: 76.88 years (2002 est.)
Total fertility rate: 2,01 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, mixed black and European,
European, Syrian, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), none 2%,
other 6%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
fema/e:94%(1970est.)','69d7b2526c302cb7396db502cfcd99fc52acee9822c027a52fd6d6c7ac39879e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('554969078c95376c86167f612120d1b668a390b409c53ba46c9af26b3422e360',2002,'DO','Dominican Republic','people-and-society',404,'Population: 8,721 ,594 (July 2002 est.)
Age structure:
0-14 years: 33.7% (male 1,503,344; female
1,439,157)
15-64 years: 61 .3% (male 2,720,308; female
2,621,539)
65 years and over: 5% (male 206,556; female
230,690) (2002 est.)
Population growth rate: 1.61% (2002 est.)
Birth rate: 24.4 births/1 ,000 population (2002 est)
Death rate: 4.68 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.59 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 33.41 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.68 years
male: 71. 57 years
. female: 75.91 years (2002 est.)
Total fertility rate: 2.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.8% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 4,900 (1999 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 82.1%
male: 82%
female: 82.2% (1995 est.)
Population: 3,957,988 (July 2002 est.)
Age structure:
0-14 years: 23.5% (male 476,726; female 453,782)
15-64 years: 65.8% (male 1,249,850; female
1,353,438)
65 years and over: 10.7% (male 180,053; female
244,139) (2002 est.)
Population growth rate: 0.51% (2002 est.)
Birth rate: 15.04 births/1,000 population (2002 est.)
Death rate: 7.82 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
afWrfft:1.05 male{s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 9.3 deaths/1 ,000 live births
(2002 est.)
422
Life expectancy at birth:
total population: 75.96 years
male: 71 .5 years
female: 80.66 years (2002 est.)
Total fertility rate: 1 .9 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: 7,397
(1997)
HIV/AIDS - deaths: NA
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: white (mostly Spanish origin) 80.5%,
black 8%, Amerindian 0.4%, Asian 0.2%, mixed and
other 10.9%
Religions: Roman Catholic 85%, Protestant and
other 15%
Languages: Spanish, English
Literacy:
definition: age 15 and over can read and write
totalpopuiation:W%
ma/e:90%
female: 88% (1980 est.)','6f91067bd1806a63fdad8151e3b1855b9d2051e38f139bf69f6f1f394efb869f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12d1bff9d37522882e4b609e08e2839a935920f6c33850d619289faba9a26957',2002,'LY','Libya','people-and-society',421,'Population: 70,712,345 (July 2002 est.)
Age structure:
0-14 years: 33.96% (male 12,292,185; female
11,721,469)
15-64 years: 62.18% (male 22.190,637; female
21,775,504)
65 years and over: 3.86% (male 1 ,1 91 ,091 ; female
1,541,459) (2002 est.)
Population growth rate: 1 .66% (2002 est.)
Birth rate: 24.41 births/1,000 population (2002 est.)
Death rate: 7.58 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.24 migrant(s)fl ,000
population (2002 est.)
Sex ratio:
at birth: ''\\.Q5 male(s)/femafe
under 15 years: 1 .05 mate(s)/femate
15-64 years: 1 .02 ma1e(s)/female
65 years and over: 0,77 male(s)/female
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 58.6 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.05 years
male: 61 .96 years
female: 66.24 years (2002 est.)
Total fertility rate: 2.99 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions: Muslim (mostly Sunni) 94%, Coptic
Christian and other 6%
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 1 5 and over can read and write
total population: 51 .4%
male: 63.6%
female: 38.8% (1995 est.)','4ecfa2b72f91f2ddf0c5d981e306a896b2aac37a45e99f5d7024c874a0291e73','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143fef6e633b9e39b8a98def80669b72840c05f4794547ada7145007beceb580',2002,'GA','Gabon','people-and-society',431,'Population: 498,144 (July 2002 est.)
Age structure:
0-14 years: 42.4% (male 106,061; female 105,071)
15-64 years: 53.8% (male 128,489; female 139,732)
65 years and over: 3.8% (male 8,385; female 10,406)
(2002 est.)
Population growth rate: 2.45% (2002 est.)
Birth rate: 37.33 births/1 ,000 population (2002 est.)
Death rate: 12.83 deaths/1 ,000 population
(2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/iema!e
under 15 years: 1.01 maie(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 90.96 deaths/1 ,000 live births
{2002 est.)
Life expectancy at birth:
total population: 54.35 years
mate; 52.26 years
female: 56.5 years (2002 est.)
Total fertility rate: 4.81 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.51%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,100
(1999 est.)
HIV/AIDS - deaths: 1 20 (1 999 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1 ,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 15 and over can read and write
total population: 78.5%
/na/e;89.6%
female: m% (1995 est.)','d5b7ffa1a28cf0e4d3f21c2efefacaeddde16047e3e08b9bd2838d8772e713ab','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77bab361426eb35f1fc53f0d7f3f353ce245c0b339f5282b26861bbb0e054677',2002,'GN','Guinea','people-and-society',440,'Population: 4,465,651 (July 2002 est.)
Age structure:
0-14 years: 42.9% (male 958,564; female 955,625)
15-64 years: 53,9% (male 1,192,454; female
1,213,313) .
65 years and over: 3.2% (male 73,017; female
72,678) (2002 est)
Population growth rate: 3.8% (2002 est.)
Birth rate: 42.25 births/1,000 population (2002 est.)
Death rate: 1 1 .82 deaths/1 ,000 population
(2002 est.)
Net migration rate: 7.61 migrant(s)/1,000
population
note: UNHCR began repatriating about 150,000
Eritrean refugees from Sudan in 2001 following the
restoration of diplomatic relations between the two
countries in 2000 (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: ) male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over:) male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 73.62 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 56.57 years
male: 54.09 years
female: 59.13 years (2002 est.)
Total fertility rate: 5.8 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.87%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%, other 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, other Cushitic languages
Literacy:
definition: NA
total population: 25%
male: NA%
female: UA%
Population: 129,934,911
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 43.6% (male 28,503,21 1 ; female
28,156,976)
15-64 years: 53.6% (male 35,418,1 19; female
34,179,802)
65 years and over: 2.8% (male 1 ,832,682; female
1,844,121) (2002 est.)
Population growth rate: 2.54% (2002 est.)
Birth rate: 39.22 births/1 ,000 population (2002 est.)
Death rate: 14.1 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.27 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/fema!e
15-64 years: 1.04 mate(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 72.49 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 50.59 years
male: 50.58 years
female: 50.6 years (2002 est.)
Total fertility rate: 5.49 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2 Jmillion
(1999 est.)
HIV/AIDS - deaths: 250,000 (1999 est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Nigeria, which is Africa''s most
populous country, is composed of more than 250
ethnic groups; the following are the most populous
and politically influential: Hausa and Fulani 29%,
Yoruba 21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri 4%,
Ibibio 3.5%, Tiv
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa. Yoruba, Igbo
(Ibo), Fulani
Literacy:
definition: age 1 5 and over can read and write
total population: 57 A%
male: 67.3%
female: 47.3% (1995 est.)
Population: 170,372 (July 2002 est)
Age structure:
0-14 years: 47.7% (male 41,159; female 40,125)
15-64 years: 48.3% (male 39,701 ; female 42,586)
65 years and over: 4% (male 3,1 1 5; female 3,686)
(2002 est.)
Population growth rate: 3.18% (2002 est,)
Birth rate: 42.3 births/1,000 population (2002 est.)
Death rate: 7.32 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.03 mate(s)/female
15-64 years: 0.93 ma!e(s)/femate
65 years and over: 0.85 ma!e(s)/female
total population: 0.97 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 47.5 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 65.93 years
male: 64.47 years
female: 67.45 years (2002 est.)
Total fertility rate: 5.95 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - peopte living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angotares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola.
Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), Europeans (primarily
Portuguese)
Religions: Christian 80% (Roman Catholic,
Evangelical Protestant, Seventh-Day Adventist)
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 79 .3%
male: 85%
female: 62% (1991 est.)','8ec3393af3163c8ee2f5a10ad6d9e89cc662807956badf5f354952e976a86141','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2370e29042bde1c9c278ff82a30dd9ea3c07d3174c412aeae6507906341d5e6',2002,'EE','Estonia','people-and-society',449,'Population: 67,673,031
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 16,098,191; female
15,879,065)
15-64 years: 50% (male 17,005,387; female
16,801,536)
65 years and over: 2.8% (male 854,023; female
1,034,829) (2002 est.)
Population growth rate: 2.64% (2002 est.)
Birth rate: 44.31 births/1 ,000 population (2002 est.)
Death rate: 1 8.04 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0,11 migrant(s)/1, 000
population
note: repatriation of Ethiopians who fled to Sudan for
refuge from war and famine in earlier years is
expected to continue for several years; some
Sudanese and Somali refugees, who fled to Ethiopia
from the fighting or famine in their own countries,
continue to return to their homes (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .01 mafe(s)/female
65 years and over: 0.83 male{s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 98.63 deaths/1 ,000 live births
(2002 est.)
167
Ethiopia (continued)
Life expectancy at birth:
total population: 44.21 years
mate: 43.36 years
female: 45.09 years (2002 est.)
Total fertility rate: 6.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 10.63%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3 million
(1999 est.)
HIV/AIDS - deaths: 280;000 (1999 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigre
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Oromigna,
Guaragigna, Somali, Arabic, other local languages,
English (major foreign language taught in schools)
Literacy:
definition: aqe 15 and over can read and write
total population: 35.5%
mate: 45.5%
female: 25.3% (1995 est.)','27c0b72e2240e8cbdcf8b55889f7640d39432e138f6c2998ef0716a76bdb852f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94856273b5bb9657e0b5da1848f3707f9dab8ffaa272dac1e9bf1b9724433f3a',2002,'FO','Faroe Islands','people-and-society',453,'Population: 46,011 (July 2002 est.)
Age structure:
0-14 years: 22.3% (male 5,149; female 5,110)
15-64 years: 64% (male 15,650; female 13,801)
65 years and over: 13.7% (male 2,818; female 3,483)
(2002 est.)
Population growth rate: 0.74% (2002 est.)
Birth rate: 1374 births/1,000 population (2002 est.)
Death rate: 8.69 deaths/1 ,000 population (2002 est.)
Net migration rate: 2,39 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at births male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .13 male(s)/fema!e
65 years and over: 0,81 male(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 6.66 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.74 years
mate: 75.28 years
female: 82.21 years (2002 est.)
Total fertility rate: 2.27 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: similar to Denmark proper','851515f7e35fa8ffbece352fd93b1063b73328a63d3be3a808e1c03b2421f48a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77ab330f526e64bc13d6f1c4cb66a85fb3147512acfee305d5b387c97b0bd4f0',2002,'JE','Jersey','people-and-society',462,'Population: 856,346 (July 2002 est.)
Age structure:
0-14 years: 32.5% (male 141 ,757; female 136,198)
15-64 years: 63.8% (male 273,658: female 273,100)
€5 years and over: 3.7% (male 14,648; female
16,985) (2002 est.)
Population growth rate: 1.41% (2002 est.)
Birth rate: 23.2 births/1,000 population (2002 est.)
Death rate: 5.72 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 1 male(s)/female
65 years and over: 0.86 male(s)/fema!e
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 13.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.56 years
male: 66. 13 years
female: 71.11 years (2002 est.)
Total fertility rate: 2.83 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 85
(2000 est.)
HIV/AIDS -deaths: NA
174
Fiji (continued)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51% (predominantly
Melanesian with a Polynesian admixture),
Indian 44%, European, other Pacific Islanders,
overseas Chinese, and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages; English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
total population: 92.5%
mate: 90%
female: %% (1999 est.)
Population: 5,183,545 (July 2002 est.)
Age structure:
0-Uyears: 17.9% (male 471,920; female 454,082)
15-64 years: 66.9% (male 1,752,493; female
1,717,544)
65 years and over: 1 5.2% (male 306,21 6; female
481,290) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 1 0.6 births/1 ,000 population (2002 est.)
Death rate: 9.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.62 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.02 ma!e(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 3.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.75 years
male: 74.1 years
female: 81.52 years (2002 est.)
Total fertility rate: 1 .7 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,100
(1999 est.)
HIV/AIDS ■ deaths: less than 100 (1999 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Sami 0.1 1%,
Roma 0.1 2%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Russian
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.4% (official), Swedish 5.9%
(official), small Lapp- and Russian-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 1 00% (1 980 est.)
male: NA%
female: NA%
Population: 59,765,983 (July 2002 est.)
Age structure:
0-14 years: 18.5% (male 5,675,269; female
5,401,661)
15-64 years: 65.2% (male 19,503,556; female
19,479,646)
65 years and over. 16.3% (male 3,948,433; female
5,757,418) (2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 1 1 .94 births/1 ,000 population (2002 est.)
Death rate: 9.04 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.64 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 ma!e(s)/female
15-64 years:) male(s)/female
65 years and over: 0.69 maie(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 4.41 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.05 years
male: 75.17 years
female: 83.14 years (2002 est.)
Total fertility rate: 1 .74 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.44%
(1999 est.)
HiV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 2,000(1999 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 83%-88%, Protestant
2%, Jewish 1%, Muslim 5%-10%, unaffiliated 4%
Languages: French 1 00%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1980 est.)
Population: 6,029,529 (July 2002 est.)
note: includes about 182,000 Israeli settlers in the
West Bank, about 20,000 in the Israeli-occupied
Golan Heights, fewer than 7,000 in the Gaza Strip,
254
Israel (continued)
and about 1 76,000 in East Jerusalem
(August 2001 est.)
Age structure:
0-14 years: 27.1% (male 837,491 ; female 798,695)
15-64 years: 63% (male 1,905,677; female
1,889,525)
65 years and over: 9.9% (male 257,066; female
341,075) (2002 est.)
Population growth rate; 1 .48% (2002 est.)
Birth rate: 18.91 births/1,000 population (2002 est.)
Death rate: 6.21 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.11 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male($)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 7.55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.86 years
male: 76.82 years
female: 81 .01 years (2002 est.)
Total fertility rate: 2.54 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/
America-born 32.1%, Israel-bom 20.8%, Africa-born
14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Jewish 80.1%, Muslim 14.6% (mostly
Sunni Muslim), Christian 2.1%, other 3.2% (1996 est.)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
mate: 97%
femate;93%(1992est.)
Population: 89,775 (July 2002 est.)
Age structure:
0-14 years: 17.9% (male 8,287; female 7,729)
15-64 years: 67.3% (mate 30,099; female 30,347)
65 years and over: 14.8% (male 5,729; female 7,584)
(2002 est.)
Population growth rate: 0.44% (2002 est,)
Birth rate: 10.86 births/1 ,000 population (2002 est.)
Death rate: 9.22 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.78 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.99 male(s)/fema!e
65 years and over: 0.76 ma!e(s)/femaie
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 5.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.78 years
male: 76.34 years
female: MA years (2002 est.)
Total fertility rate: 1 .57 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist, Presbyterian
Languages: English (official), French (official),
Norman-French dialect spoken in country districts
Literacy:
definition: NA
total population: Kb
male: NA
female: NA
Population: 2,111,561
note: includes 1,159,913 non-nationals (July
2002 est.)
Age structure:
0-14 years: 28.3% (male 304,200; female 292,900)
75-64 years: 69.2% (male 934,1 15; female 527,331)
65 years and over: 2.5% (male 34,106; female
18,909) (2002 est.)
Population growth rate: 3.33%
note: this rate reflects a return to pre-Gulf crisis
immigration of expatriates (2002 est.)
Birth rate: 21 .84 births/1 ,000 population (2002 est.)
Death rate: 2.46 deaths/1 ,000 population (2002 est.)
Net migration rate: 13.88 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .77 male(s)/female
65 years and over: 1 .8 male(s)/female
total population: 1.52 male(s)/female (2002@est.)
Infant mortality rate: 1 0.87 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.46 years
mate: 75.56 years
female: 77.39 years (2002 est.)
Total fertility rate: 3.14 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 70%, Shi''a 30%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 78.6%
male: B2.2%
female: 74.9% (1995 est.)
Population: 207,858 (July 2002 est.)
Age structure:
0-14 years: 30% (male 31,862; female 30,577)
15-64 years; 64.1% (male 67,043; female 66,102)
65 years and over; 5.9% (male 5,777; female 6.497)
(2002 est.)
Population growth rate: 1 .43% (2002 est.)
Birthrate: 19.91 births/1 ,000 population (2002 est.)
Death rate: 5.62 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1.0b male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.89 male(s)/fema!e
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 8.23 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
totai population: 73.27 years
male: 70.32 years
female: 76.36 years (2002 est.)
Total fertility rate: 2.44 children born/woman
(2002 est.)
HtV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1 .6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
mate: 92%
female: 90% (1976 est.)
Population: 1 ,932,917 (July 2002 est.)
Age structure:
0-14 years: 15.7% (male 155,989; female 147,707)
15-64 years: 69.8% (male 684,354; female 663,884)
65 years and over: 14,5% (male 1 03,790; female
177,193) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 9.27 births/1,000 population (2002 est.)
Death rate: 1 0.07 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.24 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .03 ma!e(s)/fema!e
65 years and over: 0.59 male(s)/female
total population: 0.96 ma1e(s)/fema!e (2002 est.)
Infant mortality rate: 4.47 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.29 years
male: 71. 42 years
female: 79.37 years (2002 est.)
Total fertility rate: 1.28 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 88%, Croat 3%, Serb 2%,
Bosniak 1%, Yugoslav 0,6%, Hungarian 0.4%, other
5% (1991)
Religions: Roman Catholic (Uniate 2%) 70.8%,
Lutheran 1%, Muslim 1%, atheist 4.3%, other 22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
ma/e:NA%
female: NA%
Population: 1,123,605
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years; 45.5% (male 254,573; female 256,677)
15-64 years: 51 .9% (male 281 ,645; female 301 ,071 )
65 years and over: 2.6% (male 12,027; female
17,612) (2002 est.)
Population growth rate: 1 .63% (2002 est.)
Birth rate: 39.59 births/1,000 population (2002 est.)
Death rate: 23.26 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
afb/rf/i:1.03male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.68 male(s)/female
tofaf population: 0.95 male(s)/fema!e (2002 est.)
Infant mortality rate: 109.43 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 37 years
male: 36.35 years
female: 37.66 years (2002 est.)
Total fertility rate: 5.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 35.6%
(2002 est.)
HIV/AIDS - people living with HIV/AIDS: 212,000
(2002 est.)
HIV/AIDS - deaths: 7,100 (1999 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Zionist (a blend of Christianity and
indigenous ancestral worship) 40%, Roman Catholic
20%, Muslim 10%, Anglican, Bahai, Methodist,
Mormon, Jewish and other 30%
Languages: English (official, government business
conducted in English), siSwati (official)
490
Swaziland (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 78.3
male: 78%
female: 78.4% (1999 est)','850b25ae1a9823d055184082ed2307c05c46033ab8bb7577ab307dda763e300e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c42cf5e4be6cb357999270f9347c869d503a69629ec7a4fb7e65c6f545b6195a',2002,'GF','French Guiana','people-and-society',481,'Population: 182,333 (July 2002 est.)
Age structure:
0-14 years: 30.2% (male 28,140; female 26,876)
15-64 years: 64.2% (male 63,183; female 53,902)
65 years and over: 5.6% (male 5,192; female 5,040)
(2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 21.66 births/1 ,000 population (2002 est.)
Death rate: 4.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 8.78 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/femafe
under 1 5 years: 1.05 male(s)/female
15-64 years: 1.17 mate(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.13 male(s)/fema1e (2002 est.)
Infant mortality rate: 13.22 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.49 years
male: 73.1 6 years
female: 79.99 years (2002 est.)
Total fertility rate: 3.13 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 1 2%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 84%
fema/e; 82% (1982 est.)','1c2a9e41f189d26701d888ea77f74f520f55b1858d9fd07d15815afde6f8d559','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5456337598fd6e41c3887395b935b44a0c5e26ba9864f6da9c534f2c4a02387',2002,'NR','Nauru','people-and-society',486,'Population: 257,847 (July 2002 est.)
Age structure:
0-14 years: 29% (mate 38,184; female 36,631)
15-64 years: 65.7% (male 88,250; female 81,165)
65 years and over: 5.3% (male 6,850; female 6,767)
(2002 est.)
Population growth rate: 1.67% (2002 est.)
Birth rate: 18.17 births/1 ,000 population (2002 est.)
Death rate: 4,49 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.04 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 ma!e(s)/fema!e
15-64 years: 1 .09 male(s)/fema!e
65 years and over: 1 .01 male(s)/fema1e
total population: 1 .07 mate(s)/femafe (2002 est.)
Infant mortality rate: 8.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.23 years
male: 72.88 years
female: 77.69 years (2002 est.)
Total fertility rate: 2.1 8 children bom/woman
(2002 est.)
HIV/AIDS * adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
. Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
female: 98% (1977 est.)','fa92e36bd7b2fe5f72d799394c3f2ca423304d96eacd7610d32e9124072ebd8d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe4fee6aed86ba5508a626137716ade4bc6a304ce40443c56c21c51dd5e5e933',2002,'GW','Guinea-Bissau','people-and-society',495,'Population: 1,455,842 (July 2002 est.)
Age structure:
0-14 years: 45.1% (male 329,530; female 326,627)
15-64 years: 52.3% (male 377,357; female 383,548)
65 years and over: 2.6% (male 20,237; female
18,543) (2002 est.)
Population growth rate: 3.09% (2002 est.)
Birth rate: 41 .25 births/1 ,000 population (2002 est.)
Death rate: 12.63 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.23 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0 .98 male(s)/female
65 years and over: 1 .09 male(s)/female
total population: 1 male(s)/female (2002 est.)
189
Gambia, The (continued)
Infant mortality rate: 76.39 deaths/1 1000 live births
(2002 est.)
Life expectancy at birth:
total population: 53.98 years
male: 52.02 years
female: 56.01 years (2002 est.)
Total fertility rate: 5.61 children born/woman
(2002 est.)
HIV/AIDS * adult prevalence rate: 1 .95%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 13,000
(1999 est.)
HIV/AIDS -deaths: 1,400 (1999 est.)
Nationality:
nci/n: Gambian(s)
adjective: Gambm
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1%
Religions: Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages: English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy:
definition: age 15 and over can read and write
fofa/pop{//a//''on:47.5%
ma/e: 58.4%
female: 37.1% (2001 est.)
Population: 1 ,345,479 (July 2002 est.)
Age structure:
0-14 years: 4). 9% (male 281,394; female 282,641)
15-64 years: 55.2% (male 353,755; female 388,968)
65 years and over: 2.9% (male 17,130; female
21,591X2002 est.)
Population growth rate: 2.23% (2002 est.)
Birth rate: 38.95 births/1,000 population (2002 est.)
Death rate: 15.05 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1 .62 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years''^ male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 108.54 deaths/1 ,000 live
births (2002 est)
Life expectancy at birth:
total population: 49.8 years
male: 47.47 years
female: 52.2 years (2002 est.)
Total fertility rate: 5.13 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.5% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS - deaths: 1 ,300 (1 999 est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 34%
male: 50%
female: 18% (2000 est.)','8bbef3f8a031f34b98a8bd94e382ab545affb1904c50a1213369e20e852537bd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('349038f6a11a815794a1a713af55c6e0a32c605ee7ab5d6a18dab80ceb76eeca',2002,'IL','Israel','people-and-society',505,'Population: 1 ,225,91 1 (July 2002 est.)
note: in addition, there are fewer than 7,000 Israeli
settlers in the Gaza Strip (August 2001 est)
Age structure:
0-14 years: 49.7% (male 312,253; female 297,008)
15-64 years: 47.5% (male 296,488; female 286,393)
65 years and over: 2.8% (male 14,407; female
19,362) (2002 est.)
Population growth rate: 3.95% (2002 est.)
Birth rate: 41.85 births/1,000 population (2002 est.)
Death rate: 4.12 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .73 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 24.76 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .2 years
ma/e: 69.95 years
female: 72.52 years (2002 est.)
191
Gaza Strip (continued)
Total fertility rate: 6.29 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HiV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 07%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition:
totai population: NA%
mate: NA%
femate;NA%','3913e92726b2a58e0d7afd7032ed546edecb3523d4c44cdb4e1065c7526478e4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7825ee99a69a7f9daab53b68b8edf04499867f64cdcc91a20bb776a13768420d',2002,'GE','Georgia','people-and-society',513,'Population: 4,960,951 (July 2002 est.)
Age structure:
0-U years: 19% (male 481,669; female 462,966)
15-64 years: 68.2% (male 1 ,631 ,351 ; female
1,752,230)
65 years and oven 12.8% (male 246,663; female
386,072) (2002 est.)
Population growth rate: -0.55% (2002 est.)
Birth rate: 1 1 .48 births/1 ,000 population (2002 est.)
Death rate: 14.61 deaths/1 ,000 population
(2002 est.)
193
Net migration rate: -2.39 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.64 ma!e(s)/female
total population: 0.91 male(s)/female (2002 est.)
Infant mortality rate: 51 .81 dealhs/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.67 years
male: 61 .19 years
female: 68.32 years (2002 est.)
Total fertility rate: 1.48 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%,
Russian 6.3%, Azeri 5.7%, Ossetian 3%,
Abkhaz1.8%,other5%
Religions: Georgian Orthodox 65%, Muslim 11%,
Russian Orthodox 10%, Armenian Apostolic 8%,
unknown 6%
Languages: Georgian 71% (official), Russian 9%,
Armenian 7%, Azeri 6%, other 7%
note: Abkhaz is the official language in Abkhazia
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est)
Population: 83,251,851 (July 2002 est.)
Age structure:
0-14 years: 15.4% (male 6,568,699; female
6,227,148)
15-64 years: 67.6% (male 28,606,964; female
27,695,539)
65 years and over: 17% (male 5,546,140; female
8,607,361X2002 651.)
Population growth rate: 0.26% (2002 est.)
Birth rate: 8.99 births/1 ,000 population (2002 est.)
Death rate: 10.36 deaths/1 ,000 population
(2002 est.)
Net migration rate: 3.99 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/fema!e
under 15 years: 1 .05 male(s)/femafe
15-64 years: 1 .03 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 4.65 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 11 78 years
male: 74.64 years
female: 81. 09 years (2002 est.)
Total fertility rate: 1.39 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 37,000
(1999 est.)
HIV/AIDS -deaths: 600 (1999 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, Turkish 2.4%, other
6.1% (made up largely of Serbo-Croatian, Italian,
Russian, Greek, Polish, Spanish)
Religions: Protestant 34%, Roman Catholic 34%,
Muslim 3.7%, unaffiliated or other 28.3%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1977 est.)
male: NA%
female: NA%
Population: 20,244,164
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July
2002 est.)
Age structure:
0-14 years: 40.4% (male 4,1 16,600; female
4,063,654)
15-64 years: 56.1% (male 5,625,397; female
5,723,786)
65 years and over: 3.5% (male 338,352; female
376,365) (2002 est.)
Population growth rate: 1.7% (2002 est.)
Birth rate: 28.08 births/1 ,000 population (2002 est.)
Death rate: 10.31 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.74 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 55.64 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 57.06 years
mate: 55.66 years
female: 58.51 years (2002 est.)
Total fertility rate: 3.69 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 3.6% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 340,000
(1999 est.)
HIV/AIDS -deaths: 33,000 (1999 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 98.5% (major tribes -
Akan 44%, Moshi-Dagomba 16%, Ewe 13%, Ga 8%,
Gurma 3%, Yoruba 1%), European and other 1.5%
(1998)
Religions: indigenous beliefs 21%, Muslim 16%,
Christian 63%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 15 and over can read and write
total population: 64.5%
male: 75.9%
female: 53.5% (1995 est.)
People - note: there are 9,500 Liberians, 2,000
Sierra Leoneans, and 1 ,000 Togolese refugees
residing in Ghana (2002)','4e78d0b096a764e7cd0f39778c26c940a12d46e4135d72ed1d64fe0da8e92c4d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d708b3d1d7e280154787901bc4b1a8e4694f9cb4039ac8fbf9c4bdf39e3f2199',2002,'GR','Greece','people-and-society',524,'Population: 10,645,343 (July 2002 est.)
Age structure:
0-14 years: 14.8% (male 814,605; female 765,613)
15-64 years: 67.1% (male 3,579,945; female
3,564,068)
65 years and over: 1 8.1 % (male 851 ,087; female
1,070,025) (2002 est.)
Population growth rate: 0.2% (2002 est.)
Birth rate: 9.82 births/1 ,000 population (2002 est.)
Death rate: 9.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .96 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/fema!e
under 15 years: 1 .06 male(s)/female
15-64 years: "\\ male(s)/female
years and over: 0.8 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 6.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.74 years
male: 76. 17 years
female: 81 .48 years (2002 est.)
Total fertility rate: 1 ,34 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.16%
(1999 est.)
203
Greece (continued)
HIV/AIDS - people living with HIV/AIDS: 8,000
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%, other
07%
Languages: Greek 99% (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: 97%
mate: 98.5%
female: 96% (1999)','e41c2659b3ffd398dda7a09c663f55b562f50f5382e0f14e8b81bd541c666132','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bda96caea55fa3621db8a256fb39004738040a696dcf4b80a06563e03595611',2002,'GL','Greenland','people-and-society',532,'Population: 56,376 (July 2002 est.)
Age structure:
0-14 years: 26.3% (male 7,561 ; female 7,284)
15-64 years: 68.1% (male 20,880; female 17,489)
65 years and over: 5.6% (male 1 ,442; female 1 ,720)
(2002 est.)
Population growth rate: 0.03% (2002 est.)
Birth rate: 16.27 births/1,000 population (2002 est.)
Death rate: 7.61 deaths/1 ,000 population (2002 est.)
Net migration rate: -8.37 migrant(s)/1,000
population {2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years:]. OA male(s)/female
15-64 years: 1 .19 male(s)/female
65 years and over: 0.84 male(s)/f emale
total population: 1.13 male(s)/female (2002 est.)
Infant mortality rate: 17.28 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.69 years
male: 65.13 years
female: 72.32 years (2002 est.)
Total fertility rate: 2.43 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: 100
(1999)
HIV/AIDS -deaths: NA
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 88% (Inuit and
Greenland-born whites), Danish and others 12%
(January 2000)
Religions: Evangelical Lutheran
Languages: Greenlandic (East Inuit), Danish,
English
Literacy:
definition: NA
total population: NA%
ma/e:NA%
female: NA%
nofe: similar to Denmark proper','46714f05c5ecd322a7054990c17603d4de524b54b2fb439997425a354372e819','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f31c034affccf9463f9c3e080333ef4abce1ded3c9ada64387cf1b0b9014cfc',2002,'GD','Grenada','people-and-society',541,'Population: 89,211 (July 2002 est.)
Age structure:
0-14 years: 35.9% (male 16,213; female 15,863)
15-64 years: 60.3% (male 28,460; female 25,307)
65 years and over: 3.8% (male 1 ,546; female 1 ,822)
(2002 est.)
Population growth rate: 0.02% (2002 est.)
Birth rate: 23.05 births/1,000 population (2002 est.)
Death rate: 7.63 deaths/1 ,000 population (2002 est.)
Net migration rate: -15.21 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1,12 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.08 male(s)/female (2002 est.)
Infant mortality rate: 1 4.63 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 64.52 years
male: 62.74 years
female: 66.31 years (2002 est.)
Total fertility rate: 2.5 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: "black 82%, mixed black and
European 13%, European and East Indian 5% , and
trace of Arawak/Carib Amerindian
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 9S%
mate: 98%
female: 98% (1970 est.)','0b97e4aed083925f1e0ecaa763a8f0318fb6ed0c11590cd85b1b8175a4cd9e1d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d90dde06eaf855f9966df20400726335da6159fb19df62b053807abfba2b5a5',2002,'GP','Guadeloupe','people-and-society',547,'Population: 435,739 (July 2002 est.)
Age structure:
0-14 years: 24.9% (male 55,393; female 53,047)
15-64 years: 66.2% (male 142,945; female 145,757)
65 years and over: 8.9% (male 1 6, 1 68; female
22,429) (2002 est.)
Population growth rate: 1.04% (2002 est.)
Birth rate: 16.53 births/1 ,000 population (2002 est.)
Death rate: 6.03 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.72 maie(s)/f emale
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 9.3 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.35 years
male: 74.19 years
female: 80.66 years (2002 est.)
Total fertility rate: 1.92 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 90%
female: 90% (1982 est.)','f44bc9101e21ea60a7fc28ac176d291912b47c931f75e32135320c6aba755f03','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8183fd41b1d88c2a881735298e05829a045cad93468dc044f6e9517127009b9',2002,'GU','Guam','people-and-society',552,'Population: 160,796 (July 2002 est.)
Age structure:
0-14 years: 35.1% (male 29,706; female 26,813)
15-64 years: 58.6% (male 49,457; female 44,697)
65 years and over: 6.3% (male 5,070; female 5,053)
(2002 est.)
Population growth rate: 1.99% (2002 est.)
Birth rate: 24.09 births/1 ,000 population (2002 est.)
Death rate: 4.24 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.11 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1 male(s)/female
total population: 1 .1 ma!e(s)/female (2002 est.)
Infant mortality rate: 6.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.11 years
male: 75.81 years
female: 80.72 years (2002 est.)
Total fertility rate: 3.73 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 37%, Filipino 26%, white
10%, Chinese, Japanese, Korean, and other 27%
Religions: Roman Catholic 85%, other 15%
(1999 est.)
Languages: English, Chamorro, Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 9Q%
male: 99%
female: 99% (1990 est.)
Population: 13,314,079 (July 2002 est.)
Age structure:
0-14 years: 41 .8% (male 2,841 ,486; female
2,725,343)
15-64 years: 54.5% (male 3,629,363; female
3,630,273)
€5 years and over: 3.7% (mate 227,369; female
260,245) (2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 34.17 births/1 ,000 population (2002 est.)
Death rate: 6.67 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .79 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/femate
under 15 years: 1 .04 male(s)/femate
15-64 years: 1 ma!e(s)/femate
65 years and over: 0.87 male(s)/female
total population: 1 .01 ma!e(s)/female (2002 est.)
Infant mortality rate: 44.55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.85 years
male: 64.1 6 years
female: 69.66 years (2002 est.)
Total fertility rate: 4.51 children bom/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 1.38%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 73,000
(1999 est.)
HIV/AIDS -deaths: 3,600 (1999 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish
or assimilated Amerindian - in local Spanish called
Ladino), approximately 55%, Amerindian or
predominantly Amerindian, approximately 43%,
whites and others 2%
Religions: Roman Catholic, Protestant, indigenous
Mayan beliefs
Languages: Spanish 60%, Amerindian languages
40% (more than 20 Amerindian languages, including
Quiche, Cakchiquel, Kekchi, Mam, Garifuna, and
Xinca)
Literacy:
definition: age 15 and over can read and write
total population: 63.6%
mate: 68,7%
female: 58.5% (2000 est.)','c0f9bf3ffdca56f978a3d2f5c929bcbb3a55541299980843ca1832c5cf4c9273','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('016173969406c8a82dc5f1b750f6af2bf6edd07fb14534559e6c91d3a7163f93',2002,'GG','Guernsey','people-and-society',561,'Population: 64,587 (July 2002 est.)
Age structure:
0-14 years: 16% (male 5,250; female 5,101)
15-64 years: 66.7% (male 21 ,356; female 21 ,728)
65 years and over: 17.3% (male 4,622; female 6,530)
(2002 est.)
Population growth rate: 0.37% (2002 est.)
Birth rate: 9.69 births/1 ,000 population (2002 est.)
Death rate: 9.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.87 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years: 0.98 male(s)/fema!e
65 years and over: 071 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.9 years
male: 76.91 years
female: 83.01 years (2002 est.)
Total fertility rate: 1.36 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy:
definition:
total population: NA%
mafe:NA%
female: NA%
Population: 7,775,065 (July 2002 est.)
Age structure:
0-14 years: 42.8% (male 1 ,660,795; female
1,669,850)
15-64 years: 54.5% (male 2,067,991; female
2,165,625)
65 years and over: 2.7% (male 86,968; female
123,836) (2002 est.)
Population growth rate: 2.23% (2002 est.)
Birth rate: 39.49 births/1 ,000 population (2002 est.)
Death rate: 17.24 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
nofe: as a result of civil war in neighboring countries,
Guinea is host to approximately 1 50,000 Liberian and
Sierra Leonean refugees (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 mate(s)/female
65 years and over: 0.7 male(s)/fema!e
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 127.08 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.28 years
ma/e: 43.81 years
female: 48.82 years (2002 est.)
Total fertility rate: 5.32 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.54%
(1999 est.)
HIV/AIDS ■ people living wilh HIV/AIDS: 55,000
(1999 est.)
HIV/AIDS -deaths: 5,600 (1999 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
218
Guinea (continued)
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller ethnic groups 1 0%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each ethnic group has
its own language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
ma/e:49.9% .
femafe: 21 .9% (1995 est.)','80284726b776fcedea94e523b6a1e895c0199884e4b7d1ad0a105db2163a0e6c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('150be8849790debefbe8375ec9c133b81acfca4648ed956bd7cce9cd3dbb8727',2002,'BR','Brazil','people-and-society',570,'Population: 698,209
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July
2002 est.)
Age structure:
Q-14 years: 27.6% (male 98,198; female 94,397)
15-64 years: $7 A% (male 237,324; female 233,400)
65 years and oven 5% (male 15,510; female 19,380)
(2002 est.)
Population growth rate: 0.23% (2002 est.)
Birth rate: 17.89 births/1 ,000 population (2002 est.)
Death rate: 9.33 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 ,02 male(s)/female
65 years and over: 0.8 ma!e(s)/female
total population: 1.01 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 38.37 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.59 years
mate: 59.96 years
female: 65.34 years (2002 est.)
Total fertility rate: 2,09 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 3.01 %
(1999 est.)
HIV/AIDS - people living with HiV/AIDS: 15,000
(1999 est.)
HIWAIDS- deaths: 900 (1999 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 50%, black 36%,
Amerindian 7%, white, Chinese, and mixed 7%
Religions: Christian 50%, Hindu 35%, Muslim 10%,
other 5%
Languages: English, Amerindian dialects, Creole,
Hindi, Urdu
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98.1%
male: 98.6%
female: 97.5% (1995 est.)','1b267de3ec48d4820955d9e24acb44a921afddaf7b165713424081f873982c9c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3bb00664f81f39da5b05ca1aeb8e490852693927c3244cf1b54df6544ae56fd',2002,'HT','Haiti','people-and-society',580,'Population: 7,063,722
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 39.5% (male 1 ,41 4,052; female
1,377,693)
15-64 years: 56.3% (male 1 ,924,867; female
2,049,952)
65 years and over: 4.2% (male 142,657; female
154,501) (2002 est.)
Population growth rate: 1.42% (2002 est.)
Birth rate: 31.42 births/1,000 population (2002 est.)
Death rate: 14.88 deaths/1 ,000 population
(2002 est.)
Net migration rate: -2.31 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 0.97 ma!e(s)/fernale (2002 est.)
Infant mortality rate: 93.35 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.55 years
male: 47.88 years
female: 51 .29 years (2002 est.)
225
Haiti (continued)
Total fertility rate: 4.3 children bom/woman
(2002 esl.)
HIV/AIDS - adult prevalence rate: 5.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 210,000
(1999 est.)
HIV/AIDS -deaths: 23,000 (1999 est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto and white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%,
other 1%), none 1%, other 3% (1982)
note: roughly half of the population also practices
Voodoo
Languages: French (official), Creole (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 45%
male: 48%
female: 42.2% (1995 est.)','c11ae0382fb9e6af2da3d6fbf8636d3397f44622d9a90599ae455bf6dbdf4c5d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26367d689c9abe2e06bcece1d55e93562f674bbcacca5860e957cca7b8eaa41d',2002,'IS','Iceland','people-and-society',595,'Population: 279,384 (July 2002 est.)
Age structure:
0-14 years: 23% (male 33,189; female 31,155)
15-64 years: &A% (male 91,704; female 90,199)
65 years and over: 1 1 .9% (male 14,828; female
18,309) (2002 est.)
Population growth rate: 0.52% (2002 est.)
Birth rate: 14.37 births/1 ,000 population (2002 est.)
Death rate: 6.93 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.27 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 1 5 years: 1.07 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.81 male(s)/fema!e
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 3.53 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.66 years
male: 77.42 years
female: 82.07 years (2002 est.)
Total fertility rate: 1 .99 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.14%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norse and Celts
Religions: Evangelical Lutheran 93%, other
Protestant and Roman Catholic, none (1997)
Languages: Icelandic
Literacy:
definition: age 15 and over can read and write
total population: §9.9% (1997 est.)
male: NA%
female: NA%
Population: no indigenous inhabitants
note: personnel operate the Long Range Navigation
(Loran-C) base and the weather and coastal services
radio station (July 2002 est.)','b86ddf1e44f7fe4a9e4cb8473e6fd2b393b94542d702651efbac564b133e705a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8237a8f48b0413712075742e3ada53d8788ad81d98c861081204db69460088d1',2002,'IN','India','people-and-society',603,'Population: 1,045,845,226 (July 2002 est.)
Age structure:
0-14 years: 32.7% (male 175,858,386; female
165,724,901)
15-64 years: 62.6% (male 338,957,463; female
316,063,497)
65 years and over: 4.7% (male 24,975,465; female
24,265,514) (2002 est.)
Population growth rate: 1 .51 % (2002 est.)
Birth rate: 23.79 births/1,000 population (2002 est.)
Death rate: 8.62 deaths/1 ,000 population (2002 est.)
240
India (continued)
Net migration rate: -0.07 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1 ,03 male(s)/female
total population: 1 .07 male(s)/female (2002 est.)
Infant mortality rate: 61 .47 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.23 years
wale: 62.55 years
female: 63.93 years (2002 est.)
Total fertility rate: 2.98 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.7% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 3.7 million
(1999 est.)
HIV/AIDS - deaths: 310,000 (1999 est.)
Nationality:
now Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3% (2000)
Religions: Hindu 81.3%, Muslim 12%, Christian
2.3%, Sikh 1.9%, other groups including Buddhist,
Jain, Parsi 2.5% (2000)
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication; Hindu is the national
language and primary tongue of 30% of the people;
there are 1 4 other official languages: Bengali, Telugu,
Marathi, Tamil, Urdu, Gujarati, Malayalam, Kannada,
Oriya, Punjabi, Assamese, Kashmiri, Sindhi, and
Sanskrit; Hindustani is a popular variant of Hindi/Urdu
spoken widely throughout northern India but is not an
official language
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
female: 37.7% (1995 est.)','5a4e6cb85a40337e340422c9fb993beba6b9cf13cea267e6e796807bb3a17035','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09feae339ead397d0ae920d15854cf9045b7839d3c54b4d7b95c61b64b6ca61b',2002,'IE','Ireland','people-and-society',612,'Population: 3,883,159 (July 2002 est.)
Age structure:
0-14 years: 21 .3% (mate 425,366; female 403,268)
15-64 years: 67.3% (male 1,307,469; female
1,305,038)
65 years and over: 1 1 .4% (male 1 91 ,927; female
250,091) (2002 est.)
Population growth rate: 1.07% (2002 est.).
Birth rate: 14.62 births/1 ,000 population (2002 est.)
Death rate: 8.01 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.12 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 5.43 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77 M years
male: 74,41 years
female: 80.12 years (2002 est.)
Total fertility rate: 1 .9 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: trishman(men), Irishwoman (women), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 91 .6%, Church of Ireland
2.5%, other 5.9% (1998)
Languages: English is the language generally used,
Irish (Gaelic) spoken mainly in areas located along the
western seaboard
Literacy:
definition: age 15 and over can read and write
total population: 98% (1 981 est,)
mate:NA%
female: NA%','ae68d4169fa2dec29b1146cdea42af07f79597426cb3dcc1f05c459d212b5373','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a42e648e4256cf1995025af3ec506cf60a89049cf0e49f92fb7726c73e8ad01b',2002,'TN','Tunisia','people-and-society',622,'Population: 57,715,625 (July 2002 est.)
Age structure:
0-14 years: 14.1% (male 4,1 98,569; female
3,954,159)
15-64 years: 67.3% (male 19,334,208; female
19,492,048)
65 years and over: 18.6% (male 4,436,073; female
6,300,568) (2002 est.)
Population growth rate: 0.05% (2002 est.)
Birth rate: 8.93 births/1,000 population (2002 est.)
Death rate: 10.1 3 deaths/1 ,000 population
(2002 est.)
Net migration rate: 1.73 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/fema!e
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 5.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.25 years
male: 76.08 years
female: 82.63 years (2002 est.)
Total fertility rate: 1.19 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 95,000
(1999 est.)
HIV/AIDS -deaths: 1,000 (1999 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-Italians in the north
and Albanian-Italians and Greek-Italians in the south)
Religions: predominately Roman Catholic with
mature Protestant and Jewish communities and a
growing Muslim immigrant community
Languages: Italian (official), German (parts of
Trentino-Alto Adige region are predominantly German
speaking), French (small French-speaking minority in
Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 98% (1 998)
male: NA%
female: NA%
Population: 9,815,644 (July 2002 est.)
Age structure:
0-14 years: 27 ''.8% (male 1,412,625; female
1,320,729)
15-64 years: 65.9% (male 3,234,770; female
3,233,149)
65 years and over: 6.3% (male 303,093; female
311,278) (2002 est.)
Population growth rate: 1.12% (2002 est.)
Birth rate: 16.83 births/1 ,000 population (2002 est.)
Death rate: 5 deaths/1,000 population (2002 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
affwrf/i:1.08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 27.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.1 6 years
male: 72.56 years
female: 75.89 years (2002 est.)
Total fertility rate: 1.94 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy:
definition: age 1 5 and over can read and write
fofa/popu/ata66.7%
male: 78.6%
female: 54.6% (1995 est.)
Population: 67,308,928 (July 2002 est.)
Age structure:
0-14 years; 27.8% (mate 9,520,030; female
9,178,423)
15-64 years: 65.9% (male 22,552,253; female
21,827,002)
65 years and over: 6.3% (male 1 ,946,523; female
2,284,697) (2002 est.)
Population growth rate: 1.2% (2002 est.)
Birth rate: 17.95 births/1,000 population (2002 est.)
Death rate: 5.95 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1. 04 male(s)/female
15-64 years: 1.03 ma!e(s)/fema1e
65 years and over: 0.85 male(s)/female
total population: 1 .02 male(s)/femate (2002 est.)
Infant mortality rate: 45.77 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .52 years
male: 69.1 5 years
female: 74.01 years (2002 est.)
Total fertility rate: 2.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
/jourt:Turk(s)
adjective: Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(mostly Christians and Jews)
Languages: Turkish (official), Kurdish, Arabic,
Armenian, Greek
Literacy:
definition: age 15 and over can read and write
total population: 85%
mate: 94%
fema/e: 77% (2000)','9cc4e9a5bdfea3379cd056d8649d5daf4add963e2635cff9bf0e141c3bb227a4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14ebefbc41e2298d93691f5c529de8936329e941d742d295536144db3908267',2002,'JM','Jamaica','people-and-society',632,'Population: 2,680,029 (July 2002 est.)
Age structure:
0-14 years: 29.1% (male 399,249; female 380,864)
15-64 years: 64.1% (male 858,433; female 859,174)
65 years and over: 6.8% (male 81 ,321 ; female
100,988) (2002 est.)
Population growth rate: 0.56% (2002 est.)
Birth rate: 1774 births/1,000 population (2002 est.)
Death rate: 5.45 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.65 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 ma!e(s)/femafe
15-64 years''A male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 1 371 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.64 years
male: 73,65 years
female: 7773 years (2002 est.)
Total fertility rate: 2.05 children born/woman
(2002 est.)
HIV/AIDS - adutt prevalence rate: 0.71%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 9,900
(1999 est.)
HIV/AIDS - deaths: 650 (1999 est.)
Nationality;
noun: Jamaican (s)
adjective: Jamaican
Ethnic groups: black 90.9%, East Indian 1.3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.1%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 27%, United
Church 27%, Brethren 1 .1%, Jehovah''s Witness
1.6%, Moravian 1.1%), Roman Catholic 4%, other,
including some spiritual cults 347%
Languages: English, patois English
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
male: 80.8%
female: 89.1% (1995 est.)','8e2c7aebb814a97d27b2cfd56b3113185701993ca9c583960e5f1d0edcc17ce5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01eca0ae0513415bc54df5590dc79ff5b11e9223aae4e3b456771f307fb6f538',2002,'NO','Norway','people-and-society',640,'Population: 126,974,628 (July 2002 est.)
Age structure:
0-14 years: 14.5% (male 9,465,282; female
8,999,888)
15-64 years: 67.5% (male 43,027,320; female
42,586,112)
65 years and over. 1 8% (male 9,664,1 1 2; female
13,231,914) (2002 est.)
Population growth rate: 0.15% (2002 est.)
Birth rate: 1 0.03 births/1 ,000 population (2002 est.)
Death rate: 8.53 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/fema!e
under 15 years: 1 .05 male(s)/femaie
15-64 years: 1.01 male(s)/female
65 years and over: 0.73 ma(e(s)/female
total population: 0.96 male(s)/fema!e (2002 est.)
Infant mortality rate: 3.84 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80.91 years
male: 77, 73 years
female: 84.25 years (2002 est.)
Total fertility rate: 1 .42 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est,)
HIV/AIDS - people living with HIV/AIDS: 10,000
(1999 est.)
HIV/AIDS- deaths: 150 (1999 est)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99%, others 1% (Korean
511,262, Chinese 244,241, Brazilian 182,232, Filipino
89,851 .other 237,91 4) (2000)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 970 est.)
male: NA%
female: NA%
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2002 est.)','58e06d61bf95fe11fd90f71944d8b471a32afffb53e8ca64b95b1e60bd634e9c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0108a9d428163e6e497de4b94b79178d061bbe74f5da134333fabff69a8182be',2002,'MH','Marshall Islands','people-and-society',647,'Population: no indigenous inhabitants
note: in previous years, there was an average of 1 ,1 00
US military and civilian contractor personnel present;
as of 1 September 2001 , population had decreased
significantly when US Army Chemical Activity Pacific
(USACAP) departed (July 2002 est.)
Population: 5,307,470 (July 2002 est.)
Age structure:
0-14 years: 36.6% (male 991 ,370; female 949,247)
15-64 years: 60% (male 1 ,698,568; female
1,485,261)
65 years and over: 3.4% (male 90,1 86; female
92,838) (2002 est.)
Population growth rate: 2.89% (2002 est.)
Birth rate: 24.58 births/1 ,000 population (2002 est.)
Death rate: 2.62 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .14 male(s)/female
65 years and over: 0.97 ma!e(s)/female
total population^ .1 male(s)/female (2002 est.)
Infant mortality rate: 19,61 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.71 years
ma/e; 75.26 years
female: 80.3 years (2002 est.)
Total fertility rate: 3.15 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1%,
Armenian 1%
Religions: Sunni Muslim 92%, Christian 6%
(majority Greek Orthodox, but some Greek and
Roman Catholics, Syrian Orthodox, Coptic Orthodox,
Armenian Orthodox, and Protestant denominations),
other 2% (several small Shi''a Muslim and Druze
populations) (2001 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 15 and over can read and write
total population:
mate: 93.4%
female: 79 A% (1995 est.)
Population: 73,630 (July 2002 est.)
Age structure:
0-14 years: 49.1% (male 18,443: female 17,704)
15-64 years: 48.9% (male 18,347; female 17,628)
65 years and over: 2% (male 720; female 788)
(2002 est.)
Population growth rate: 3.89% (2002 est.)
Birth rate: 44.98 births/1,000 population (2002 est.)
Death rate: 6.07 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant (s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years: 1 ,04 male(s)/fema!e
65 years and over: 0.91 mate(s)/female
total population: 1 .04 ma!e(s)/female (2002 est.)
Infant mortality rate: 38.68 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.1 8 years
male: 64.35 years
female: 68.09 years (2002 est.)
Total fertility rate: 6.49 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (widely spoken as a second
language, both English and Marshallese are official
languages), two major Marshallese dialects from the
Malayo-Polynesian family, Japanese
330
Marshall Islands (continued)
Literacy:
definition: age 15 and over can read and write
total population: 03.7
male: 93.6%
female: 93.7% (1999)','44034a8f3099b4428e8dda355de0e19442663ecec39d2a844ef365e381a2c696','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ffc82ddafbe1b9888b4e7a21120fdfb2aab77dd17fa782215e04233b0725942',2002,'KZ','Kazakhstan','people-and-society',659,'Population: 16,741,519 (July 2002 est.)
Age structure:
0-14 years: 26% (male 2,212,985; female 2,141,392)
15-64 years: 66.5% (male 5,393,281 ; female
5,731,288)
65 years and over: 7.5% (male 434,879; female
827,694) (2002 est.)
Population growth rate: 0.1% (2002 est.)
Birth rate: 17.83 births/1,000 population (2002 est.)
Death rate: 10.69 deaths/1 ,000 population
(2002 est.)
Net migration rate: -6.16 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.03 ma!e(s)/female
15-64 years: 0.94 male(s)/fema!e
65 years and over: 0.53 male(s)/fema!e
total population: 0.92 male(s)/female (2002 est.)
Infant mortality rate: 58.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.38 years
male: 58.02 years
female: 69.01 years (2002 est.)
Total fertility rate: 2.12 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,500
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
m>un:Kazakhstani(s)
adjective: Kazakhstan''!
Ethnic groups: Kazakh (Qazaq) 53.4%, Russian
30%, Ukrainian 3.7%, Uzbek 2.5%, German 2.4%,
Uighur 1 .4%, other 6.6% (1999 census)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq, state language)
64.4%, Russian (official, used in everyday business,
designated the "language of interethnic
communication") 95% (2001 est.)
Literacy:
definition: age 15 and over can read and write
fofa/popu/affon:98.4%
ma/e:99.1%
female: 97.7% (1999 est.)
Population: 31,138,735
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 41.1% (male 6,462,430; female
6,327,457)
15-64 years: 56.1% (male 8,769,546; female
8,694,329)
65 years and over. 2.8% (male 385,361 ; female
499,612) (2002 est.)
Population growth rate: 1.15% (2002 est.)
Birth rate: 27.61 births/1,000 population (2002 est.)
Death rate: 14.68 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1 .48 migrant(s)/1 ,000
population
note: according to UNHCR, by the end of 2001 Kenya
was host to 220,000 refugees from neighboring
countries, including: Somalia 145,000 and Sudan
68,000 (2002 est.)
Sex ratio:
af birth: 1 .03 ma!e(s)/female
under 15 years: 1.02 male(s)/female
75-64 years: 1 .01 male(s)/female
65 years and over: 0.77 ma!e(s)/fema!e
total populations .01 male(s)/female (2002 est.)
Infant mortality rate: 67.24 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47.02 years
male: 46.2 years
female: 47.85 years (2002 est,)
Total fertility rate: 3.34 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 13.5%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2,2 million
(2000 est)
HIV/AIDS - deaths: 180,000 (1999 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab)1%
Religions: Protestant 45%, Roman Catholic 33%,
indigenous beliefs 10%, Muslim 10%, other 2%
note: a large majority of Kenyans are Christian, but
estimates for the percentage of the population that
adheres to Islam or indigenous beliefs vary widely
Languages: English (official), Kiswahili (official),
numerous indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 78.1%
ma/e:86.3%
female: 70% (1995 est.)
Population: uninhabited (July 2002 est.)','77162de55dbaa2939a1f76cbbc5b16a0e73173b3d93c2911fb24097b98633a9c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd3b7b9c707a4174cb071732ff5099c644f442a61df1cce1dfd8ce4426ca33de',2002,'KI','Kiribati','people-and-society',669,'Population: 96,335 (July 2002 est.)
Age structure:
0-14 years: 40.2% (male 19,588; female 19,092)
15-64 years: 56.6% (male 26,905; female 27,625)
65 years and over: 3.2% (male 1 ,339; female 1 ,786)
(2002 est.)
Population growth rate: 2.28% (2002 est.)
Birth rate: 31 .58 births/1 ,000 population (2002 est.)
Death rate: 8.76 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/femate
under 15 years: 1.03 male(s)/lemale
15-64 years: 0.97 ma!e(s)/fema1e
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 52.63 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.54 years
male: 57.61 years
female: 63.62 years (2002 est.)
Total fertility rate: 4.32 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: l-Kiribati (singular and plural)
ad/ecf/Ve; l-Kiribati
Ethnic groups: predominantly Micronesian with
some Polynesian
Religions: Roman Catholic 52%, Protestant
(Congregational) 40%, some Seventh-Day Adventist,
Muslim, Baha''i, Latter-day Saints, and Church of God
(1999)
Languages: l-Kiribati, English (official)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 22,224,195 (July 2002 est.)
Age structure:
0-14 years: 25.4% (male 2,888,478; female
2,747,133)
15-64 years: 67.4% (male 7,380,183; female
7,612,275)
65 years and over: 7.2% (male 527,256; female
1,068,870) (2002 est.)
Population growth rate: 1.1% (2002 est.)
Birth rate: 1 7.95 births/1 ,000 population (2002 est.)
Death rate: 6.96 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/fema!e
under 15 years:]. 05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.49 male(s)/fema!e
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 22.8 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .3 years
male: 68.31 years
female: 74.44 years (2002 est.)
Total fertility rate: 2.22 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions: traditionally Buddhist and Confucianist,
some Christian and syncretic Chondogyo (Religion of
the Heavenly Way)
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Literacy:
definition: age 1 5 and over can read and write Korean
tofa/popu/af/on: 99%
mate: 99%
fema/e:99%(1990 est.)
Population: 48.324 million (July 2002 est.) .
Age structure:
0-74 years: 21 .4% (male 5,488,808; female
4,875,379)
15-64 years: 71% (male 17,404,645; female
16,894,361)
65 years and over; 7.6% (male 1,434,873; female
2,225,934) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 14.55 births/1 ,000 population (2002 est,)
Death rate: 6.02 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .1 1 male(s)/f emale
under 15 years: 1.13 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 7.58 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population:74.BS years
ma/e:71.2 years
282
Korea, South (continued)
female: 78.95 years (2002 est.)
Total fertility rate: 1 .72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,800
(1999 est)
HIV/AIDS -deaths: 180 (1999 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christian 49%, Buddhist 47%,
Confucianist 3%, Shamanist, Chondogyo (Religion of
the Heavenly Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 15 and over can read and write
tote/ popiMon: 98%
mate; 99.3%
female: 96.7% (1995 est.)','f642d0e20ed78423138b7c064f59f65afffad68ab8c6f10872713637cea05b70','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca9be48438602c50d53a8e5c3e819a0f23387a4789fc81c4fd40e30efaa2fd09',2002,'LV','Latvia','people-and-society',681,'Population: 2,366,515 (July 2002 est.)
Age structure:
0-74 years: 15.8% (male 191,116; female 182,692)
15-64 years: 68.6% (male 775,481; female 847,261)
65 years and over: 15.6% (male 120,304; female
249,661) (2002 est.)
Population growth rate: -0.77% (2002 est.)
Birth rate: 8.27 births/1 ,000 population (2002 est.)
Death rate: 14.74 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1 .23 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 0.92 ma!e(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.85 male(s)/fema!e (2002 est.)
Infant mortality rate: 14.96 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69 years
male: 63.13 years
female: 75.17 years (2002 est.)
Total fertility rate: 1 .18 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(2001 est.)
HIV/AIDS - people living with HIWAIDS: 1 ,792
(15 January 2002)
HIV/AIDS - deaths: 36 (15 January 2002)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 57.7%, Russian 29.6%,
Belarusian 4.1%, Ukrainian 2.7%, Polish 2.5%,
Lithuanian 1.4%, other 2%
Religions: Lutheran, Roman Catholic, Russian
Orthodox
Languages: Latvian (official), Lithuanian, Russian,
other
Literacy:
definition: age 15 and over can read and write
total population: 99.8%
male: NA%
female: NA%
Population: 3,677,780 (July 2002 est.)
Age structure:
0-14 years: 27.3% (male 51 1 ,902; female 491 ,804)
15-64 years: 65.9% (male 1,157,688; female
1,267,106)
65 years and over: 6.8% (male 1 1 3,341 ; female
135,939) (2002 est.)
Population growth rate: 1 .36% (2002 est.)
Birth rate: 1 9.96 births/1 ,000 population (2002 est.)
Death rate: 6.35 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 ma!e(s)/femaie
65 years and over: 0.83 ma!e(s)/f emale
total population: 0.94 male(s)/femate (2002 est.)
Infant mortality rate: 27.39 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
totai population: 71 ,79 years
male: 69.38 years
female: 74.32 years (2002 est.)
Total fertility rate: 2.02 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Muslim 70% (including Shi''a, Sunni,
Druze, Isma''ilite, Alawite or Nusayri), Christian 30%
(including Orthodox Christian, Catholic, Protestant),
Jewish NEGL%
Languages: Arabic (official), French, English,
Armenian
Literacy:
definition: age 15 and over can read and write
total population: 86 A%
male: 90.8%
female: 82.2% (1997 est.)
Population: 2,207,954
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 39% (male 433,229; female 427,926)
15-64 years: 56.3% (male 600,476; female 642,538)
65 years and over: 4,7% (male 43,691; female
60,094) (2002 est.)
Population growth rate: 1.33% (2002 est.)
Birth rate: 30.72 births/1,000 population (2002 est.)
Death rate: 1 6.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 82.57 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47 years
male: 46.3 years
female: 47.8 years (2002 est.)
Total fertility rate: 4.01 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 23.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS - deaths: 1 6, 000 (1 999 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians,
and other 0.3%,
Religions: Christian 80%, indigenous beliefs 20%
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 83%
mate; 72%
female: 93% (1999 est.)','a4cc6414b67375735b8d6b6ce40aaee2fe035f041248fdbc7ef159dba964328d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff7a6a4d092ee4991a5f127012621237fc39d602fed8015f223559e7c33441f5',2002,'ZA','South Africa','people-and-society',694,'Population: 3,288,198 (July 2002 est.)
Age structure:
0-14 years: 43.3% (male 714,563; female 709,582)
15-64 years: 53.2% (male 854,324; female 894,753)
65 years and over. 3.5% (male 57,925; female
57,051) (2002 est.)
Population growth rate: 1 .91% (2002 est.)
Birth rate: 45.95 births/1 ,000 population (2002 est.)
Death rate: 16.05 deaths/1 ,000 population
(2002 est.)
Net migration rate: -10.8 migrant(s)/1 ,000
population
note: by the end of 1999, all Liberian refugees who
had fled the domestic strife were assumed to have
returned (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 130.21 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 51 .8 years
ma/e: 50.33 years
female: 53.33 years (2002 est.)
Total fertility rate: 6.29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 9% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 125,000
(2001 est.)
HIV/AIDS -deaths: 13,000(2001 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves), Congo People
2.5% (descendants of immigrants from the Caribbean
who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: English 20% (official), some 20 ethnic
group languages, of which a few can be written and
are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1995 est.)
note: these figures are increasing because of the
improving school system
Population: 5,368,585
note: includes 662,669 non-nationals, of which an
estimated 500,000 or more are Africans living in Libya
(July 2002 est.)
Age structure:
0-14 years: 35% (male 958,243; female 917,940)
15-64 years: 61 % (male 1 ,694,986; female
1,581,400)
65 years and over: 4% (male 105,500; female
110,516) (2002 est.)
Population growth rate: 2.41% (2002 est.)
Birth rate: 27.59 births/1,000 population (2002 est.)
Death rate: 3.5 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.07 male(s)/femafe
65 years and over: 0.95 male(s)/female
total population: 1.06 ma!e(s)/female (2002 est.)
Infant mortality rate: 27.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.86 years
male: 73.71 years
female: 78.11 years (2002 est)
Total fertility rate: 3.57 children born/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
301
Libya (continued)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 76.2%
male: 87.9%
female: 63% (1995 est.)','d6a71c66c0797dc34bcddd0c9a7e08ea66e01424b233a4fad4ac2272ecbffd0d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b0bdfc8d2a78b65a121af998a4ebd7e6213fc9484551ad385f1ee3569928cf',2002,'CH','Switzerland','people-and-society',698,'Population: 32,842 (July 2002 est.)
Age structure:
0-14 years: 18.3% (male 3,003; female 3,001)
15-64 years: 70.5% (male 1 1 ,530; female 1 1 ,639)
65 years and over: 1 1 .2% (male 1 ,494; female 2,1 75)
(2002 est.)
Population growth rate: 0.94% (2002 est.)
Birth rate: 1 1 .24 births/1 ,000 population (2002 est.)
Death rate: 6.76 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.93 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
a/fc/rf/7:1.01 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.95 ma!e(s)/fema1e (2002 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79. 1 years
male: 75 .47 years
female: 82.74 years (2002 est.)
Total fertility rate: 1 .5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HiV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun:Liechtensteiner(s)
arf/ecf/va* Liechtenstein
Ethnic groups: Alemannic87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7,7%, other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 10 and over can read and write
total population: 100%
male: 100%
female: 100% (1981 est.)
Population: 3,601,138 (July 2002 est.)
Age structure:
0*14 years: 18.2% (male 333,966; female 319,992)
15-64 years: 68% (male 1,184,969; female
1,265,711)
65 years and over 13.8% (male 167,789; female
328,711) (2002 est.)
Population growth rate: -0.25% (2002 est.)
Birth rate: 1 0.22 births/1 ,000 population (2002 est.)
Death rate: 12.87 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 ma1e(s)/femate
15-64 years: 0.94 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0M ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 1 4.34 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.42 years
ma/e: 63.54 years
female: 75.6 years (2002 est.)
Total fertility rate: 1 .4 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Belarusian 1 .6%, other 2.1%
Religions: Roman Catholic (primarily), Lutheran,
Russian Orthodox, Protestant, Evangelical Christian
Baptist, Muslim, Jewish
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 15 and over can read and write
total population: 98%
mate: 99%
female: 98% (1989 est.)','5557d3949e91c96820565523dc72ba0149ff5824370cda16c7795e521ff364c2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('781063dee8ce9f8996f9e668266264bd3aa77a4fe40dd3411c26ab3bbd74f2ee',2002,'DE','Germany','people-and-society',712,'Population: 448,569 (July 2002 est.)
Age structure:
0-14years: 18.9% (male 43,634; female 41,164)
15-64 years: 67% (male 151 ,364; female 149,156)
65 years and over: 14.1% (male 25,486; female
37,765) (2002 est.)
Population growth rate: 1.25% (2002 est.)
Birth rate: 12.06 births/1 ,000 population (2002 est.)
Death rate: 8.83 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.26 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.67 ma!e(s)/female
total population: 0.97 male(s)/femate (2002 est.)
infant mortality rate: 4.71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77 AB years
mate: 74.2 years
female: 80.97 years (2002 est.)
Total fertility rate: 1 .7 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.16%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: less than 100 (1999 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, Slavs (from
Montenegro, Albania, and Kososvo) and European
(guest and resident workers)
Religions: the greatest preponderance of the
population is Roman Catholic with a very few
Protestants, Jews, and Muslims
note: 1979 legislation forbids the collection of religious
statistics
Languages: Luxembourgish (national language),
German (administrative language), French
(administrative language)
Literacy:
definition: age 1 5 and over can read and write
total population: 100%
male: 100%
female: 100% (2000 est.)','86cd585be8a816fb6cab7b2796f3fa2b8ea59472be0035667fa0b4141f2a53aa','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19aa3dc0deea586ceefa8e6f31eb5255aa9a2c38b73e6412b0710423c631a914',2002,'YT','Mayotte','people-and-society',721,'Population: 16,473,477 (July 2002 est.)
Age structure:
0-14 years: 45% (male 3,713,700; female 3,696,478)
15-64 years: 51.8% (male 4,227,931; female
4,313,940)
65 years and over: 3.2% (male 241 ,699; female
279,729) {2002 est.)
Population growth rate: 3.03% (2002 est.)
Birth rate: 42.41 births/1,000 populalion (2002 est.)
Death rate: 12.15 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 81 .9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 55.74 years
male: 53.45 years
female: 58.1 1 years (2002 est.)
Total fertility rate: 5.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 1 ,000
(1999 est)
HIV/AIDS -deaths: 870 (1999 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-lndonesian (Merinaand
related Betsileo), Cotiers (mixed African,
Malayo-lndonesian, and Arab ancestry -
Betsimtsaraka, Tsimihety, Antaisaka, Sakalava);
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
mate; 88%
female: 73% (1990 est)
Population: 10,701,824
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-/4 years: 44% (male 2,358,730; female 2,347,017)
15-64 years: 53.2% (male 2,810,478; female
2,884,601)
65 years and over: 2.8% (male 120,761; female
180,237) (2002 est.)
Population growth rate: 1.39% (2002 est.)
Birth rate: 37.13 births/1 ,000 population (2002 est.)
Death rate: 23.2 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0-98 male(s)/female (2002 est.)
Infant mortality rate: 1 1 9.96 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 36.59 years
male: 36.05 years
female: 37.15 years (2002 est.)
Total fertility rate: 5.04 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 5.96%
(1999 est.)
HiV/AIDS - people living with HIV/AIDS: 800,000
(1999 est.)
HIV/AIDS -deaths: 70,000 (1999 est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuka, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian,
European
Religions: Protestant 55%, Roman Catholic 20%,
Muslim 20%, indigenous beliefs 3%, other 2%
Languages: English (official), Chichewa (official),
other languages important regionally
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 72.8%
female: 43.4% (1999 est.)
Population: 170,879 (July 2002 est.)
Age structure:
0-14 years: 46.6% (male 39,927; female 39,628)
15-64 years: 51 .7% (male 48,237; female 40,21 0)
65 years and over: 1 .7% (male 1 ,429; female 1 ,448)
(2002 est.)
Population growth rate: 4.41% (2002 est.)
Birth rate; 43.59 births/1 ,000 population (2002 est.)
Death rate: 8.58 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.1 1 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth:]. 03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.2 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .1 male(s)/female (2002 est.)
Infant mortality rate: 67.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.21 years
male: 58.12 years
female: 62.37 years (2002 est.)
Total fertility rate: 6.15 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 97%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
(official language) spoken by 35% of the population
Literacy:
definition: NA
total population: NA%
male: NA%
female; Uk%','cedbb9ded88d84a00e1d19457339ade06f8bc83109c3d5ea33da6a57706e1fa0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe6703c207f9b6cd6a06a291acb28b42e6fb7bc0c93474203265631d30a6ae94',2002,'MV','Maldives','people-and-society',730,'Population: 320,165 (July 2002 est.)
Age structure:
0-14 years: 45.3% (male 74,493; female 70,394)
15-64 years: 51 .7% (male 84,548; female 81 ,092)
65 years and over: 3% (male 4,944; female 4,694)
(2002 est.)
Population growth rate: 2.95% (2002 est.)
Birth rate: 37.41 births/1 ,000 population (2002 est.)
Death rate: 7.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years:}, 0B mate(s)/female
15-64 years: 1 .04 male(s)/female
BSyears and over: 1.05 male(s)/female
total population: 1. 05 male(s)/female (2002 est.)
Infant mortality rate: 61 .93 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.93 years
ma/e:61.72years
female: 64.2 years (2002 est.)
Total fertility rate: 5.38 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: South Indians, Sinhalese, Arabs
Religions: Sunni Muslim
Languages: Maldivian Dhivehi (dialect of Sinhata,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 1 5 and over can read and write
total population: 93.2%
male: 93.3%
femate:93%(1995 est.)
322
Maldives (continued)
Population: 1 1 ,340,480 (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 2,687,998; female
2,658,605)
15-64 years: 49.8% (male 2,698,789; female
2,950,276)
65 years and over: 3% (male 160,604; female
184,208) (2002 est.)
Population growth rate: 2.97% (2002 est.)
Birth rate: 48.37 births/1 ,000 population (2002 est.)
Death rate: 18.32 deaths/1 ,000 population -
(2002 est.)
Net migration rate: -0.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1 .01 male(s)/female
15-64 years: 0.91 male(s)/femate
65 years and over: 0.87 male(s)/fema!e
total population: 0.96 ma!e(s)/female (2002 est.)
Infant mortality rate: 1 19.63 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 47.39 years
mate: 46. 18 years
female: 48.64 years (2002 est.)
Total fertility rate: 6.73 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2001 est.)
HIV/AIDS -deaths: 9,900 (1999 est.)
324
Mali (continued)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke,
Soninke), Peul 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 15 and over can read and write
total population: 38%
mate: 45%
fema/e:31%(1998 est.)','2be46c1d95799d4b85ca7cc399db54346e45b0de669ae996138752119caa8bc3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c15842564e9893aed32a217e2f2a9dcac89ee0435dc12b3df3bf895e753cab91',2002,'MT','Malta','people-and-society',739,'Population: 397,499 (July 2002 est.)
Age structure:
0-14 years: 197% (male 40,609; female 37,882)
15-64 years: 67.5% (male 135,047; female 133,207)
65 years and over: 12.8% (mate 21 ,215; female
29,539) (2002 est.)
Population growth rate: 0.73% (2002 est.)
Birth rate: 12.76 births/1 ,000 population (2002 est.)
Death rate: 7.77 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.36 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1.07 mate(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 ma1e(s)/female (2002 est.)
Infant mortality rate: 5.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.26 years
mate: 75.78 years
female: 80.96 years (2002 est.)
Total fertility rate: 1.91 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 0.52%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 91%
Languages: Maltese (official), English (official)
Literacy:
definition: age 10 and over can read and write
total population: 88.76%
male: 86.91%
female: 89.55% (1995 census)
Population: 73,873 (July 2002 est.)
Age structure:
0-14 years: 17.5% (male 6,601; female 6,324)
15-64 years: 65.3% (male 24,206; female 24,010)
65 years and over: 1 7.2% (male 5,097; female 7,635)
(2002 est,)
Population growth rate: 0.52% (2002 est.)
Birth rate: 1 1 .49 births/1 ,000 population (2002 est.)
Death rate: 1 1 .68 deaths/1 ,000 population
(2002 est.)
Net migration rate: 5.41 migrant(s)/1,000
'' population (2002 est.)
Sex ratio:
a^/ri/i:1.05male(s)/female
under 15 years: 1,04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 6.3 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: JIM years
mate: 74.44 years
female: 81 .36 years (2002 est.)
Total fertility rate: 1.65 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HJV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Manxman (men), Manxwoman (women)
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy:
definition: NA
fofa/popi//atfon:NA%
male:HA%
female: NA%','d9acbd0082ef8357f239c3a3e25e13c14323846ddf22129b1c536ba45ae5db26','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e1557f836db4f464f9aef2a721c065fefec36d1792d9ca58c6bdd11e4440c5a',2002,'MQ','Martinique','people-and-society',748,'Population: 422,277 (July 2002 est.)
Age structure:
0-14 years: 23% (male 49,261 ; female 47,843)
15-64 years: 66.8% (male 140,616; female 141,460)
65 years and over: 10.2% (male 19,274; female
23,823) (2002 est)
Population growth rate: 0.89% (2002 est.)
Birth rate: 15.37 births/1 ,000 population (2002 est.)
Death rate: 6.4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/fema!e
65 years and over: 0.81 ma1e(s)/fema!e
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 7.62 deaths/1 .000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.56 years
male: 79. 19 years
female: 77.92 years (2002 est,)
Total fertility rate: 1.79 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV7A1DS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-Indian
mixture 90%, white 5%, East Indian, Chinese less
than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 93%
male: 92%
female: 93% (1982 est.)
Population: 6,954 (July 2002 est.)
Age structure:
0-14 years: 25.4% (male 904; female 864)
15-64 years: 64.4% (male 2,288; female 2,193)
65 years and over: 1 0.2% (male 303; female 402)
(2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 1 4.96 births/1 ,000 population (2002 est.)
Death rate: 6.61 deaths/1 ,000 population (2002 est.)
Net migration rate: -4.89 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 8.18 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.93 years
male: 75.66 years
female: 80.32 years (2002 est.)
Total fertility rate: 2.1 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: $9%
/na/e;99%
fema/e: 99% (1982 est.)','b8c8e424de3e40b47fc01342d5e8505969e3a268a8bc3b249e8a2d8dc6514d71','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58cc9f3158854662d5e3b8871d6fb937dcbf99d490799f650d668ead85ea1df6',2002,'MR','Mauritania','people-and-society',752,'Population: 2,828,858 (July 2002 est.)
Age structure:
0-14 years: 46.1% (male 653,005; female 650,530)
15-64 years: 51 .7% (male 720,473; female 741 ,094)
65 years and over: 2.2% (male 26,251 ; female
37,505) (2002 est.)
Population growth rate: 2.92% (2002 est.)
Birth rate: 42.54 births/1 ,000 population (2002 est.)
Death rate: 13.34 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 ma1e(s)/female *
total population: 0.98 male(s)/femate (2002 est.)
Infant mortality rate: 75.25 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .53 years
male: 49.42 years
female: 53.71 years (2002 est.)
Total fertility rate: 6.15 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.8% (2000 est.)
HIV/AIDS * people living with HIV/AIDS: 6,600
(1999 est.)
334
Mauritania (continued)
HIV/AIDS -deaths: 610 (1999 est.)
Nationality:
noun: Mauritanian(s)
ao)''ecf/Ve; Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%,
, black 30%
Religions: Muslim 100%
Languages: Hassaniya Arabic (official), Pulaar,
Soninke, Wolof (official), French
Literacy:
definition: age 1 5 and over can read and write
total population: 41 .2%
male: 51 .5%
female: 31 .3% (2002 est.)','7f9280e5854ef0611131f09f10b0265f28bcd16d3e9b7741c6537f26743601f2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9cac8898694b480c7266f44d8fc4eb9edf740c1b22923c8aba4edcc961e1adb',2002,'MU','Mauritius','people-and-society',762,'Population: 1 ,200,206 (July 2002 est.)
Age structure:
0-74 years: 25.4% (male 153,810; female 150,464)
15-64 years: 68.3% (male 409,028; female 41 1 ,070)
65 years and over: 6.3% (male 30,1 70; female
45,654) (2002 est.)
Population growth rate: 0.86% (2002 est.)
Birth rate: 16.34 births/1 ,000 population (2002 est.)
Death rate: 6.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.92 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .02 mafe(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 1 6.65 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .53 years
male: 67.54 years
female: 75.58 years (2002 est.)
Total fertility rate: 2 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%,
other 3.1%
Languages: English (official), Creole, French
(official), Hindi, Urdu, Hakka, Bhojpuri
Literacy:
definition: age 1 5 and over can read and write
total population: 82.9%
ma/e:87.1%
female: 78.8% (1995 est.)','b55cc960296a2ccc4a48e45dc5aa0ff652ded728b9212aad890dc69354bb6b17','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48fa6318d45837c0420f65c1bd97ade3eb38d618cdc590b730572083e88afbeb',2002,'MX','Mexico','people-and-society',773,'Population: 103,400,165 (July 2002 est.)
Age structure:
0-14 years; 32.8% (male 17,310,230; female
16,630,935)
15-64 years: 627% (male 31 ,552,877; female
33,246,668)
65 years and over: 4.5% (male 2,069,826; female
2,589,629) (2002 est.)
Population growth rate: 1.47% (2002 est,)
Birth rate: 22.36 births/1 ,000 population (2002 est.)
Death rate: 4.99 deaths/1 ,000 population (2002 est)
Net migration rate: -2.71 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
affwrfh: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.8 male(s)/female .
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 24.52 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: 72.03 years
mate: 68.99 years
female: 75.21 years (2002 est.)
Total fertility rate: 2.57 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 0.29%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 150,000
(1999 est)
HIV/AIDS -deaths: 4,700 (1999 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%, other 5%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
mate; 91.8%
femate: 87.4% (1995 est)
Population: 38,625,478 (July 2002 est.)
Age structure:
0-14 years: 17.9% (male 3,535,701; female
3,361,515)
15-64 years: 69.5% (male 13,358,128; female
13,500,443)
65 years and over: 1 2.6% {male 1 ,860,274; female
3,009,417) (2002 est.)
Population growth rate: -0.02% (2002 est.)
Birth rate: 10.29 births/1 ,000 population (2002 est.)
Death rate: 9.97 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.49 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0,99 ma!e(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 9.17 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.66 years
male: 69.52 years
female: 78.05 years (2002 est.)
Total fertility rate: 1 .37 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1.3%,
Ukrainian 0.6%, Belarusian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant, and
other 5%
Languages: Polish
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
fema/e:98%(1978 est.)','d42ea2ab7836accb4fbf1eb5fc967b1d77d2d7ef66e64c6696b34b3ab948fae6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('effadb5089672427162d1a2991bef9dd2642ece7ee1a0b169dc31360f8cdd63a',2002,'FM','Micronesia, Federated States of','people-and-society',781,'Population: no indigenous inhabitants;
approximately 40 people make up the staff of US Fish
and Wildlife Service and their services cooperator
living at the atoll (April 2002 est.)
Population growth rate: NA','f1d5a16b6f323b751bb1bbb0df44505f7198f5c5ed74b3a7bde92583da25c3b5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec4c5a7ce8d228a4c45680674d8420e1d85a4c18ce731e267b33e93183ce2bc',2002,'UA','Ukraine','people-and-society',787,'Population: 4,434,547 (July 2002 est.)
Age structure:
(M4 years: 21 .7% {male 490,414; female 472.912)
15-64 years: 68.2% (male 1 ,451 ,962; female
1,572,561)
65 years and over: 10.1% (male 165,860: female
280,838) (2002 est.)
Population growth rate: 0.09% (2002 est.)
Birth rate: 13.82 births/1 ,000 population (2002 est.)
Death rate: 1 2.64 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 ma!e(s)/fema!e
total population: 0.91 male(s)/female (2002 est.)
Infant mortality rate: 42.16 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.74 years
male: 60.39 years
female: 69.31 years (2002 est.)
Total fertility rate: 1.71 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,500
(1999 est.)
346
Moldova (continued)
HIV/AIDS « deaths: less than 100 (1999 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldovan/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%f Jewish 1.5%,
Bulgarian 2%, Gagauz and other 5.2% (1989 est.)
note: internal disputes with ethnic Slavs in the
Transnistrian region
Religions: Eastern Orthodox 98.5%, Jewish 1.5%,
Baptist (only about 1,000 members) (1991)
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian (official), Gagauz
(a Turkish dialect)
Literacy:
definition: age 15 and over can read and write
total population: 96%
mate: 99%
femate:94%(1989est.)
Population: 22,317,730 (July 2002 est.)
Age structure:
0- 14 years: 1 7.4% (male 1 ,992,505; female
1,898,122)
'' 15-64 years: 68.8% (male 7,618,801; female
7,726,300)
65 years and over: 1 3.8% (male 1 ,274,881 ; female
1,807,121) (2002 est.)
Population growth rate: -0.21% (2002 est.)
Birth rate: 10.81 births/1 ,000 population (2002 est.)
Death rate: 12.27 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.6 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.06 male(s)/fema!e
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/fema!e
total population: 0.95 ma!e(s)/female (2002 est.)
Infant mortality rate: 18.88 deaths/1,000 live births
(2002 est.)
428
Romania (continued)
Life expectancy at birth:
total population: 70.39 years
male: 66,62 years
female: 74.39 years (2002 est.)
Total fertility rate: 1 .35 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,000
(1999 est.)
HIV/AIDS -deaths: 350 (1999 est)
Nationality:
noun: Romanian (s)
adjective: Romanian
Ethnic groups: Romanian 89.5%, Hungarian 7.1%,
Roma 1.8%, German 0.5%, Ukrainian 0.3%,
other 0.8% (1992)
Religions: Romanian Orthodox 70%, Roman
Catholic 6%, Protestant 6%, unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 1 44,978,573 (July 2002 est.)
Age structure:
0-14 years: 16.7% (male 12,334,659; female
11,840,058}
15-64 years: 70.2% (male 49,330,660; female
52,402,610)
65 years and over: 13.1% (male 6,150,775; female
12,919,811) (2002 est.)
Population growth rate: -0.33% (2002 est.)
Birthrate: 9.71 births/1 ,000 population (2002 est,)
Death rate: 13.91 deaths/1,000 population
(2002 est.)
Net migration rate: 0.94 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 ,04 male(s)/fema!e
15-64 years: 0.94 male(s)/female
65 years and over: 0.48 ma!e(s)/female
total population: 0.88 male(s)/female (2002 est.)
Infant mortality rate: 19.78 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 67.5 years
male: 62.29 years
female: 72.97 years (2002 est.)
Total fertility rate: 1 .3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 850 (1999 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1.2%, Bashkir 0.9%,
Belarusian 0.8%, Moldavian 07%, other 8. 1 %
431
Russia (continued)
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy:
definition: age 15 and over can read and write
total popuia Hon: 98%
male: 100%
fema/e:97%(1989 est.)
Population: 7,398,074
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July .
2002 est.)
Age structure:
0-14 years: 41 .7% (male 1,550,141 ; female
1,539,375)
15-64 years: 55.4% (male 2,039,573; female
2,057,059)
65 years and over: 2.9% (male 84,030; female
127,896) (2002 est.)
Population growth rate: 1 .16% (2002 est.)
Birth rate: 33.28 births/1 ,000 population (2002 est.)
Death rate: 21 .39 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/femate
65 years and over: 0.66 male(s)/female
total population: 0.99 mate(s)/female (2002 est.)
Infant mortality rate: 1 17.79 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 38.66 years
male: 38.14 years
female: 39.2 years (2002 est.)
Total fertility rate: 4.72 children bom/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 1 1 .21%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400,000
(1999 est.)
HIV/AIDS -deaths: 40,000 (1999 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 84%, Tutsi 15%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 56.5%, Protestant 26%,
Adventist 11.1%, Muslim 4.6%, indigenous beliefs
0.1%, none 1.7% (2001)
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 1 5 and over can read and write
total population: 48%
male: 52%
female: 45% (1995 est.)
Population: 48,396,470 (July 2002 est)
Age structure:
0-14 years: 16.8% (male 4,147,344; female
3,970,343)
15-64 years: 68.7% (male 15,881,821; female
17,366,172)
65 years and over: 1 4.5% (male 2,341 ,885; female
4,688,905) (2002 est)
Population growth rate: -0.72% (2002 est.)
Birth rate: 9.59 births/1,000 population (2002 est.)
Death rate: 1 6.4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 ma!e(s)/female
65 years and over: 0.5 ma!e(s)/female
total population: 0.86 male(s)/female (2002 est.)
Infant mortality rate: 21 .14 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.33 years
male: 60.86 years
female: 72.06 years {2002 est)
Total fertility rate: 1.32 children born/woman
(2002 est)
HIV/AIDS - adult prevalence rate: 0.96%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est)
HIV/AIDS - deaths: 4,000 (1 999 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow
Patriarchate, Ukrainian Orthodox - Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 15 and over can read and write
total population: QB%
ma/e:100%
female: 97% (1989 est)','b7223f3c4dfe9385d3d4641cb28ef2cde351f6a0daa826ea2cf091bf1c445a30','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79fa4bbf3319dd55e3a657cf462aeb7b0c1ea77cc10cc55dc242abb83a55e152',2002,'MC','Monaco','people-and-society',796,'Population: 31 ,987 (July 2002 est.)
Age structure:
0-14 years: 15.5% (male 2,545; female 2,418)
15-64 years: 62.1 % (male 9,762; female 1 0,093)
65 years and over: 22.4% (male 2,922; female 4,247)
(2002 est.)
Population growth rate: 0.45% (2002 est.)
Birth rate: 9.6 births/1 ,000 population (2002 est.)
Death rate: 12.91 deaths/1 ,000 population
(2002 est)
Net migration rate: 7.82 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 ma1e(s)/female
total population: 0.91 male(s)/female (2002 est.)
Infant mortality rate: 5.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population:79A2 years
mate: 75.21 years
female: 83.25 years (2002 est.)
Total fertility rate: 1 .76 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 90%
Languages: French (official), English, Italian,
Monegasque
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%','693ad39abb87c98c3cf9116ff3203e324b96270c0b055bab355503b6e0d4f006','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2705a46da4a96b8071f200c6dc828a7f70f99964facf6132ff4876cce4c2755',2002,'GI','Gibraltar','people-and-society',802,'Population: 31 ,1 67,783 (July 2002 est.)
Age structure:
0-14 years: 33.8% (male 5,364,948; female
5,166,666)
15-64 years: 61 .5% (male 9,51 8,503; female
9,640,292)
65 years and over: 47% (male 661 ,054; female
816,320) (2002 est.)
Population growth rate: 1 .68% (2002 est,)
Birth rate: 23.69 births/1,000 population (2002 est.)
Death rate: 5.86 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.09 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 ,05 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.81 mate(s)/female
totai population: 1 male(s)/female (2002 est.)
Infant mortality rate: 46.49 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
totai population: 69.73 years
male: 67,49 years
female: 72.08 years (2002 est.)
Total fertility rate: 2.97 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.03%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0,2%
Religions: Muslim 98.7%, Christian 1 .1%,
Jewish 0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
tote/ popu/ato; 43.7%
male: 56.6%
female: 31% (1995 est.)
Population: 19,607,519
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected; the 1997 Mozambican census reported a
population of 16,099,246 (July 2002 est.)
Age structure:
0-14 years: 42.5% (male 4,162,413; female
4,176,295)
15-64 years: 54.7% (male 5,313,51 1 ; female
5,407,052)
65 years and over: 2.8% (male 227,761 ; female
320,487) (2002 est.)
Population growth rate: 1 .13% (2002 est.)
Birthrate: 36.41 births/1 ,000 population (2002 est.)
Death rate: 25.13 deaths/1 ,000 population
(2002 est.)
357
Mozambique (continued)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est)
Sex ratio:
at birth:]. 03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 071 ma!e(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 138.55 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 35.46 years
male: 36.25 years
female: 34.65 years (2002 est.)
Total fertility rate: 4.71 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 12.6 to 16.4%,
estimates vary (2001)
HIV/AIDS - people living with HIV/AIDS:
1,546,643(2001)
HIV/AIDS -deaths: 114,111 (2001 est.)
Nationality:
noun:Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Shangaan, Chokwe, Manyika, Sena, Makua. and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.3 %
male: 58.4%
female: 27% (1998 est.)','93758b57a60fc04f540c0a8ccdb8fd6d4728c167c445bf75d4806bdad4ef398a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb32a737f620c0a6407fe9caec983e59e09e31b7dd668bf484013e5cd388f047',2002,'BW','Botswana','people-and-society',815,'Population: 1,820,916
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in tower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected {July 2002 est.)
Age structure:
0-14 years: 42.6% (male 392,706; female 382,690)
15-64 years: 53.7% (male 490,151; female 488,052)
65 years and over: 3.7% (male 29,345; female
37,972) (2002 est.)
Population growth rate: 1.19% (2002 est.)
Birth rate: 34.17 births/1,000 population (2002 est.)
Death rate: 22.28 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est)
Sex ratio:
at birth: 1 .03 male(s)/female
under 1 5 years: 1.03 male(s)/fema!e
15-64 years: 1 male(s)/femafe
65 years and over: 0.77 mate(s)/fema!e
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 72.43 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 38.97 years
male: 40.81 years
female: 37.07 years (2002 est.)
Total fertility rate: 477 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 19.54%
(1999 est.)
HIWAIDS - people living with HIV/AIDS: 160,000
(1999 est.)
HIV/AIDS • deaths: 18,000 (1999 est.)
Nationality:
not/n: Namibian(s)
adjective: Namibian
Ethnic groups: black 87.5%, white 6%, mixed 6.5%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero 7%, Damara 7%, Nama 5%,
Caprivian 4%: Bushmen 3%, Baster 2%,
Tswana 0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
feast), indigenous beliefs 10% to 20%
Languages: English 7% (official). Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 1 5 and over can read and write
total population: 38%
ma/e:45%
fe/T?afe;31%(1960 est.)
Population: 12,329 (July 2002 est.)
Age structure:
0-14 years: 39.6% (male 2,515; female 2,366)
15-64 years: 58.7% (male 3,578; female 3,656)
65 years and over: 1 .7% (male 1 08; female 1 06)
(2002 est)
Population growth rate: 1.96% (2002 est.)
Birth rate: 26.6 births/1 ,000 population (2002 est.)
Death rate: 7.06 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant($)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .02 mate(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 10.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .57 years
mate: 58.05 years
female: 65.26 years (2002 est.)
Total fertility rate: 3.5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy:
definition: NA
362
Nauru (continued)
total population: NA%
male: NA%
female: NA%
Population: uninhabited
note: transient Haitian fishermen and others camp on
the island (July 2002 est.)
Population: 25,873,917 (July 2002 est)
Age structure:
0-14 years: 40% (male 5,346,422; female 5,007,416)
15-64 years: 56.4% (male 7,476,202; female
7,125,471)
65 years and over: 3.6% (male 453,263; female
465,143) (2002 est.)
Population growth rate: 2.29% (2002 est.)
Birth rate: 32.94 births/1,000 population (2002 est.)
Death rate: 10.03 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .05 male(s)/fema!e
65 years and over: 0.97 ma!e(s)/female
total populations. 05 male(s)/female (2002 est.)
Infant mortality rate: 72.36 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 58.61 years
male: 59.01 years
female: 58.2 years (2002 est.)
Total fertility rate: 4.48 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 34,000
(1999 est.)
HIWAIDS - deaths: 2,500 (1 999 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Brahman, Chetri, Newar, Gurung,
Magar, Tamang, Rai, Limbu, Sherpa, Tharu, and
others (1995)
Religions: Hinduism 86.2%, Buddhism 7.8%, Islam
3.8%, other 2.2%
note: only official Hindu state in the world (1995)
Languages: Nepali (official; spoken by 90% of the
population), about a dozen other languages and about
30 major dialects; note - many in government and
business also speak English (1 995)
Literacy:
definition: age 1 5 and over can read and write
total population: 27.5%
mate: 40.9%
female: 14% (1995 est.)','b8d4d5f11ca20fe4e84eb7f602434837abb447777b922f952e182929a6456134','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89dc90f0a94f30d88bb91003266dcf9d595fbfdc308ca260dbf8d9a94241d7ce',2002,'NL','Netherlands','people-and-society',823,'Population: 1 6,067,754 (July 2002 est.)
Age structure:
0-14 years: 1 8.3% (mate 1 ,502,687; female
1,437,141)
15-64 years: 67,9% (male 5,548,188; female
5,362.412)
65 years and over: 13.8% (male 913,020; female
1,304,306) (2002 est,)
Population growth rate: 0.53% (2002 est.)
Birth rate: 1 1 .58 births/1 ,000 population (2002 est.)
Death rate: 8.67 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.35 migrant(syi,000
population (2002 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 .03 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 4.31 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.58 years
male: 75.7 years
female: 81 .59 years (2002 est.)
Total fertility rate: 1 .65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0. 1 9%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 5,000
(1999 est.)
HIV/AIDS -deaths: 100 (1999 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 83%, other 1 7% (of which 9%
are non-western origin mainly Turks, Moroccans,
Antilleans, Surinamese and Indonesians) (1999 est.)
Religions: Roman Catholic 31%, Protestant 21%,
Muslim 4.4%, other 3.6%, unaffiliated 40% (1998)
Languages: Dutch
Literacy:
definition: age 15 and over can read and write
total population: 99% (2000 est.)
ma/e:NA%
female: NA%
Population: 214,258 (July 2002 est.)
Age structure:
0-14 years: 25% (male 27,351; female 26,135)
15-64 years: 67.1% (male 68,431; female 75,312)
65 years and over: 7.9% (male 7,049: female 9,980)
(2002 est.)
Population growth rate: 0.93% (2002 est.)
Birth rate: 1 6.16 births/1 ,000 population (2002 est.)
Death rate: 6.4 deaths/1,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at births. 05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.71 ma!e(s)/female
total population: 0.92 male(s)/female (2002 est.)
Infant mortality rate: 1 1 .06 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.1 5 years
male: 72.96 years
female: 77 AG years (2002 est.)
Total fertility rate: 2.06 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Dutch Antillean(s)
adjective: Dutch Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Portuguese-Dutch-English dialect)
predominates, English widely spoken, Spanish
370
Netherlands Antilles (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est)','b6612699577a0b3273c439c36fc4f8c26f77b06356222f593b9cbc543eabcb23','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d437bbb61061753105be96e8a5c7eaeb01af8c496640b37e51f9010900a0eb7',2002,'NE','Niger','people-and-society',841,'Population: 10,639,744 (July 2002 est.)
Age structure:
0-14 years: 47.9% (male 2,594,932; female
2,503,867)
15-64 years: 49.8% (male 2,594,307; female
2,706,164)
65 years and over: 2.3% (male 1 25,898; female
114,576) (2002 est.)
Population growth rate: 2.7% (2002 est.)
Birth rate: 49.95 births/1 ,000 population (2002 est.)
Death rate: 22.25 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.71 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 mate(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over:) .1 ma!e(s)/fema!e
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 122.23 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 4 1.91 years
male: 42.04 years .
female: 41 .77 years (2002 est.)
Total fertility rate: 7 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: 4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: 17,700 (2002est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christian
Languages: French (official), Hausa; Djerma
Literacy:
definition: age 15 and over can read and write
total population: 15.3%
male: 21.2%
female: 9.4% (2002)','650bbbc9bd739ed6948b739085efd346fae19f1ae1503eea8e0fc6e3da445654','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d9abd39ea9e055f3eece2370b3fa54536b71c32a0daf87081eea4f558e30a62',2002,'NU','Niue','people-and-society',850,'Population: 2,134 (July 2002 est.)
Age structure:
0-14 years: NA%
15*64 years: NA%
65 years and over: NA%
Population growth rate: 0.5% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church - a
Protestant church closely related to the London
Missionary Society) 75%, Latter-Day Saints 10%,
other 15% (mostly Roman Catholic, Jehovah''s
Witnesses, Seventh-Day Adventist)
Languages: Niuean, a Polynesian language closely
related toTongan and Samoan; English
Literacy:
definition: NA .
total population: 95%
male: NA%
fema/e:NA%','4833ce2ecd76fd36c814f3ee8334611fd43c67666de79455362443e499a104c2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0875231227dc2b397089b8b223c0ddf502bb30541155b3f71d45684f6ef3b5e',2002,'NF','Norfolk Island','people-and-society',856,'Population: 1 ,866 (July 2002 est.)
Age structure:
0-14 years: 20.2%
15-64 years: 63.9%
65 years and over: 1 5.9% (1 996)
Population growth rate: -0.69% (2002 est.)
Birthrate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA mlgrant(s)/1 ,000 population
Sex ratio:
at birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA mate(s)/female
65 years and over: NA maie(s)/fema!e
total population: NA male(s)/female
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
ma/e: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 37.4%, Uniting Church in
Australia 14.5%, Roman Catholic 11.5%,
Seventh-Day Adventist 3.1%, none 12.2%, unknown
17.4%, other 3.9% (1996)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian
Literacy: NA','50b93129009e33f1cee5f166f480b0453eac4351d5dbb8540e7c4ceef8ceda48','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e8e6f50a66f12403fcd35a850c9cfa4159a2e7dd32312b11ad87e304039ca9',2002,'MP','Northern Mariana Islands','people-and-society',868,'Population: 4,525,1 16 (July 2002 est.)
Age structure:
0-14 years: 20% (male 464,789; female 439,1 17)
15-64 years: 65% (male 1,491,720; female
1,451,450)
65 years and over: 1 5% (male 281 ,551 ; female
396,489) (2002 est.)
Population growth rate: 0.47% (2002 est.)
Birth rate: 12.39 births/1 ,000 population (2002 est.)
Death rate: 9.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.1 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/femaie
under 15 years: 1.06 mate(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0,98 male(s)/female (2002 est.)
Infant mortality rate: 3.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.94 years
male: 76.01 years
female: 82.07 years (2002 est.)
Total fertility rate: 1 .8 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA% (1 999 est.)
HIV/AIDS - people living with HiWAIDS: 1 ,600
(1999 est.)
HIV/AIDS -deaths: 8(1999)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Norwegian, Sami 20,000
Religions: Evangelical Lutheran 86% (state church),
other Protestant and Roman Catholic 3%, other 1%,
none and unknown 10% (1997)
Languages: Norwegian (official)
note: small Sami- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
tofa/popu/atfon; 100%
male: NA%
female: NA%
Population: 2,713,462
note: includes 527,078 non-nationals (July 2002 est.)
Age structure:
0-14 years: 41 .9% (male 579,065; female 556,923)
15-64 years: 55.7% (mate 914,494; female 597,948)
65 years and over: 2.4% (male 34,555; female
30,477) (2002 est.)
Population growth rate: 3.41% (2002 est.)
Birth rate: 37,76 births/1,000 population (2002 est.)
Death rate: 4.03 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 1.53 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1 .29 male(s)/female (2002 est.)
Infant mortality rate: 21 .77 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.31 years
male: 70.1 5 years
female: 74.57 years (2002 est.)
Total fertility rate: 5.99 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1 1%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Omani(s)
aoJectfve:Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: US military personnel have left the island, but
civilian personnel remain; as of December 2000, one
US Army civilian and 123 contractor personnel were
present (July 2002 est.)','9adbf9c8316bf4b8686c6bb04300aa633855681eae7be2e5f07a769c461088a8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('332e3f781949936b3e46a510c4d50ce6b4c85d512f24aab33ff172eef8bd417b',2002,'PK','Pakistan','people-and-society',871,'Population: 147,663,429 (July 2002 est.)
Age structure:
0*14 years: 39.9% (male 30,321,217; female
28,581,334)
15-64 years: 56% (male 42,254,996; female
40,392,092)
65 years and over: 4.1% (male 2,984,391 ; female
3,129,399) (2002 est.)
Population growth rate: 2.06% (2002 est.)
Birth rate: 30.4 births/1,000 population (2002 est.)
Death rate: 9.02 deaths/1 ,000 population (2002 est.)
Net migration rate: -079 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at births. OS male(s)/female
under 1 5 years: 1.06 ma!e(s)/fema!e
15-64 years: 1.05 male(s)/female
65 years and over: 0.95 male(s)/female
total populations. OS male(s)/fema!e (2002 est.)
Infant mortality rate: 78.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .82 years
male: 60.96 years
female: 62.73 years (2002 est.)
Total fertility rate: 4.25 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 74,000
(1999 est.)
HIV/AIDS -deaths: 6,500 (1999 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India at the time of
partition and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 42.7%
male: 55.3%
female: 29% (1998)','abc45ae57f27dabb9e71e849a61df76f03a4d126f204766ad8a175b67bd49ca1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93b53f5bcc852766d6e7e48ad104c33b06f278adef16c3309464307b20b7d11e',2002,'PW','Palau','people-and-society',881,'Population: 19,409 (July 2002 est.)
Age structure:
0-14 years: 26.8% (male 2,678; female 2,522)
15-64 years: 68.6% (male 7,241 ; female 6,074)
65 years and over: 4.6% (male 426; female 468)
(2002 est.)
Population growth rate: 1.61% (2002 est.)
Birth rate: 19.32 births/1 ,000 population (2002 est.)
Death rate: 7. 1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.86 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .1 9 male(s)/fema!e
65 years and over: 0.91 male(s)/female
total population: 1.14 male(s)/female (2002 est.)
Infant mortality rate: 16.21 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.1 9 years
male: 66.07 years
female: 72.5 years (2002 est.)
Total fertility rate: 2.47 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauan (Micronesian with Malayan
and Melanesian admixtures) 70%, Asian (mainly
Filipinos, followed by Chinese, Taiwanese, and
Vietnamese) 28%, white 2% (2000 est.)
Religions: Christian (Roman Catholics 49%,
Seventh-Day Adventists, Jehovah''s Witnesses, the
Assembly of God, the Liebenzell Mission, and
Latter-Day Saints), Modekngei religion (one-third of
the population observes this religion which is
indigenous to Palau)
Languages: English and Palauan official in all states .
except Sonsoral (Sonsorolese and English are
official), Tobi (Tobi and English are official), and
Angaur (Angaur, Japanese, and English are official)
Literacy:
definition: age 15 and over can read and write
total population: 92%
mate: 93%
femafe:90%(1980est.)
Population: no indigenous inhabitants; 4 to 20
Nature Conservancy staff, US Fish and Wildlife staff
(July 2002 est.)','b8ea83a7c8849bfbb2d60bbd74342a434b23ac11922c75ae69709cc1f9b3014c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8bbe62ab47b089f1314cd1b16820a64570ef7df8a8bfd907f445fbced3cdda8',2002,'PG','Papua New Guinea','people-and-society',890,'Population: 5,172,033 (July 2002 est.)
Age structure:
0-14 years: 38.6% (male 1,013,936; female 980,841)
15-64 years: 57,7% (male 1 ,544,650; female
1,440,628)
65 years and over: 3.7% (male 90,661 ; female
101 ,317) (2002 est.)
Population growth rate: 2.39% (2002 est.)
Birth rate: 31.61 births/1,000 population (2002 est.)
Death rate: 7.75 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1,05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.05 male(s)/female (2002 est.)
Infant mortality rate: 56.53 deaths/1,000 live births
{2002 est.)
Life expectancy at birth:
total population: 63.83 years
mate: 61 .73 years
female: 66.03 years (2002 est.)
Total fertility rate: 4.21 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.22%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 5,400
(1999 est.)
HIV/AIDS -deaths: 450 (1999 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary
Society 8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant 10%,
indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin
English widespread, Motu spoken in Papua region
note: 715 indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 64.5%
male: 72%
female: 57% (2000)','7fcf5fb63583bc25af0cdc29056ce54fb72d04883d623c49d197cbf02966b4b5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3d574e77f7eba99e7d76e3e99d8ace3486e43ca04e1767b48e0e775ec3b9ae8',2002,'PH','Philippines','people-and-society',893,'Population: no indigenous inhabitants
note: there are scattered Chinese garrisons
(July 2002 est.)','944252eeb965db01a7d2d51268fef8d710eab697ed3bd1ea91b8b6f81c45cb81','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('473734825d77310c685e70e8ad718120fb9c9852942e0a121169c60c55a4cd15',2002,'PT','Portugal','people-and-society',905,'Population: 10,084,245 (July 2002 est.)
Age structure:
0-14 years: 16.9% (male 875,485; female 827,670)
15-64 years: 67.3% (mafe 3,324,215; female
3,463,301)
65 years and over: 1 5.8% (male 644,761 ; female
948,813) (2002 est.)
Population growth rate: 0.18% (2002 est.)
Birth rate: 1 1 .5 births/1 ,000 population (2002 est.)
Death rate: 10.21 deaths/1,000 population
(2002 est.)
Net migration rate: 0.5 migrant(s)/1,000 population
(2002 est.)','adc06c834b4711f649a21e99265d628cdb9c66292b4dae3af9504efb0ec574fa','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ab336a0127ca3a739a1d43a8bf0a1ccd476c3783998ea66546bba0c3cc9f0fc',2002,'QA','Qatar','people-and-society',913,'Population: 793,341 (July 2002 est.)
Age structure:
0-14 years: 25.2% (male 102,1 10; female 98,053)
15-64 years: 72.1% (male 403,508; female 168,428)
65 years and over: 2.7% (male 15,299; female 5,943)
(2002 est.)
Population growth rate: 3.02% (2002 est.)
Birth rate: 15,78 births/1 ,000 population (2002 est.)
Death rate: 4.34 deaths/1 ,000 population (2002 est.)
Net migration rate: 18.75 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)rtemale
15-64 years: 2.4 ma!e(s)/female
65 years and over: 2.57 male(s)/fema!e
total population: 1.91 male(s)/female (2002 est.)
Infant mortality rate: 20.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.88 years
mate: 70.4 years
424
Qatar (continued)
female: 75.48 years (2002 est.)
Total fertility rate: 3.1 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Qatari(s)
acjrecftVe: Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 1 5 and over can read and write
total population: 79%
ma/e;79%
/ema/e:80%(1995 est.)
Population: 743,981 (July 2002 est.)
Age structure:
0-14 years: 31 .7% (male 120,864; female 1 1 5,251)
15-64 years: 62.5% (male 228.864; female 235,991)
65 years and over: 5.8% (mate 17,459; female
25,552) (2002 est.)
Population growth rate: 1 .52% (2002 est.)
Birth rate: 20.7 births/1 ,000 population (2002 est.)
Death rate: 5.51 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est,)
Sex ratio:
af Jb/rf/?: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 8.31 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.18 years
male: 69.78 years
female: 76.74 years (2002 est.)
Totat fertility rate: 2.55 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 86%, Hindu, Muslim,
Buddhist (1995)
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)','ccec662bc3335d18e42d073ce304ec70f05064a2e1d66c998f4350ddb6290ab1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ca42172f2dfa5b6f53fd2ca23aeba04b15630686af5d10e1aa8cafdc78de051',2002,'TT','Trinidad and Tobago','people-and-society',920,'Population: 38,736 (July 2002 est.)
Age structure:
0-14 years: 29.4% (male 5,827; female 5,571)
15-64 years: 61 .9% (mate 1 1 ,980; female 1 2,005)
65 years and over. 8.7% (male 1 ,383; female 1 ,970)
(2002 est.)
Population growth rate: 0.01% (2002 est.)
Birth rate: 18,61 births/1,000 population (2002 est.)
Death rate: 9.04 deaths/1 ,000 population (2002 est.)
Net migration rate: -9.5 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth:). OS male(s)/female
under 15 years: 1.05 male(s)/lema!e
15-64 years:] ma!e(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 1 5.83 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .29 years
male: 68.49 years
female: 74.26 years (2002 est.)
Total fertility rate: 2.39 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: predominantly black some British,
Portuguese, and Lebanese
Religions: Anglican, other Protestant, Roman
Catholic
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
fema/e:98%(1980est.)','3c0102c382ae5cfcd537a107b5bbc0edf609f0ecd9bff99ebc3ce120a0702309','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160e20e999aab02a065b8414dbe6e1e3046e728571eec8fa420b10fb68b8cde8',2002,'LC','Saint Lucia','people-and-society',929,'Population: 160,145 (July 2002 est.)
Age structure:
0- 14 years: 3 1 .6% (male 25,879; female 24,695)
15-64 years: 63.1 % (male 49,667; female 51 ,482)
65 years and over 5.3% (male 3,134; female 5,288)
(2002 est.)
Population growth rate: 1 .24% (2002 est.)
Birth rate: 21,37 births/1 ,000 population (2002 est.)
Death rate: 5.3 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.64 migrant(s)/1t000
population (2002 est.)
Sex ratio:
at birth:} SSI male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 14.8 deaths/1 ,000 live births
(2002 est,)
Life expectancy at birth:
total population: 72.82 years
male: 69.26 years
female: 76.64 years (2002 est.)
Total fertility rate: 2.34 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East
Indian 3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 67%
male: 65%
fema/e:69%(1980est.)','f04afed6031284a592306b4afbbe68d243c130278d256590691fa1aff2240e3f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88cdd4990aec6bd714debb27db9e3af4be5f53a942f8e6e9633134394d320cd4',2002,'WS','Samoa','people-and-society',941,'Population: 178,631 (July 2002 est.)
Age structure:
0-14 years: 30.6% (mate 27,774; female 26,854)
15-64 years: 63.5% (male 71 ,358; female 42,150)
65 years and over: 5.9% (male 4,859; female 5,636)
(2002 est.)
Population growth rate: -0.25% (2002 est.)
Birth rate: 15.53 births/1 ,000 population (2002 est.)
Death rate: 6.35 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 1 .64 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 ma!e(s)/female
15-64 years: 1.69 ma!e(s)/fema!e
65 years and over: 0.86 ma!e(s)/female
total population: 1 .39 ma!e(s)/femate (2002 est.)
Infant mortality rate: 30.74 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.8 years
male: 67,06 years ''
female: 72.69 years (2002 est.)
Total fertility rate: 3.3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
446
Samoa (continued)
HIV/AIDS -deaths: NA
Nationality:
noun: Samoan(s)
adjective: Smoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-half of
population associated with the London Missionary
Society; includes Congregational, Roman Catholic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 1 5 and over can read and write
total population: B0%
ma/e: 81%
female: 79% (1999)','3b17b9711f0cca29ec03621ab1ec94eab74b4e4b8967dfd5a39df98ee16f87d3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa6f3c8b805a61d855b6bba8c47cdd86b9646923b2196c57418ede2d76732564',2002,'SN','Senegal','people-and-society',946,'Population: 10,589,571 (July 2002 est.)
Age structure:
0-14 years: 43.5% (male 2,321 ,789; female
2,290,105)
15-64 years: 53.4% (male 2,710,178; female
2,943,554)
65 years and over: 3.1% (male 159,445; female
164,500) (2002 est.)
Population growth rate: 2.91% (2002 est.)
Birth rate: 36.99 births/1,000 population (2002 est.)
Death rate: 8.14 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.21 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
a/b/rfh:1.03male(s)/female
under 15 years: 1 .01 mate(s)/fema!e
15-64 years: 0.92 ma!e(s)/female
65 years and over: 0.97 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 55.41 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.93 years
male: 61 .29 years
female: 64.61 years (2002 est.)
Total fertility rate: 5.03 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 95,000
(2001 est.)
HIV/AIDS - deaths: 10,000 (2001 est.)
454
Senegal (continued)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer
14,7%, Jola 37%, Mandinka 3%, Sontnke 1 .1%,
1 European and Lebanese 1 %, other 9.4%
Religions: Muslim 94%, indigenous beliefs 1%,
Christian 5% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Jota,
Mandinka
Literacy:
definition: age 1 5 and over can read and write
total population: $9A%
mate; 51.1%
female: 28.9% (2001 est.)','099404267b533a5d6c4821055782420791e8965af605f718fef0b2e79047829d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a3b7ecf16b5f670e4aff1e2876119f886cefe2d5aebdfee2ed0cff661fd206',2002,'SC','Seychelles','people-and-society',956,'Population: 80,098 (July 2002 est.)
Age structure:
0-14 years: 27. 8% (male 11,238; female 11,002)
15-64 years: 66% (male 25,763; female 27,086)
65 years and over: 6.2% (male 1 ,667; female 3,342)
(2002 est)
Population growth rate: 0.47% (2002 est.)
Birth rate: 17.27 births/1 ,000 population (2002 est.)
Death rate: 6.57 deaths/1,000 population
(2002 est.)
Net migration rate: -5.99 migrant(s)/l ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 ma!e{s)/female
under 15 years: 1 .02 ma!e(s)/female
15-64 years: 0.95 male(s)/female
65 years and over 0.5 mate(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 1 6.86 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.97 years
mate: 65.48 years
female: 76.63 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychellois
Ethnic groups: mixed French, African, Indian,
Chinese, and Arab
Religions: Roman Catholic 86.6%, Anglican 6.8%,
other Christian 2.5%, other 4.1%
Languages: English (official), French (official),
Creole
Literacy:
definition: age 1 5 and over can read and write
total population: 58%
mate: 56%
female: 60% (1971 est)','866a6b2363fe04d80069f43cb1a0e834f470e27dbb5452485d480089da4dcb11','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('032716803516367cfdae2636582b7e9ff346956556fd9c274ecefed83df49837',2002,'SL','Sierra Leone','people-and-society',965,'Population: 5,614,743 (July 2002 est.)
Age structure:
0-14 years: 447% (male 1 ,230,530; female
1,280,084)
15-64 years: 52.1% (male 1 ,397,070; female
1,528,986)
65 years and over: 3.2% (male 87,256; female
90,817) (2002 est.)
Population growth rate: 3.21% (2002 est.)
Birth rate: 44.58 births/1,000 population (2002 est.)
Death rate: 18.83 deaths/1 ,000 population
(2002 est.)
Net migration rate: 6.32 migrant(s)/1 ,000
population
note: by the end of 1999 refugees from Sierra Leone
are assumed to be returning (2002 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 0.96 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 0.94 male(s)/fema!e (2002 est.)
Infant mortality rate: 144.38 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 45.96 years
mate: 43.01 years
female: 49.01 years (2002 est.)
Total fertility rate: 5.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 68,000
(1999 est.)
HIV/AIDS - deaths: 8,200 (1 999 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole (Krio) 10%
(descendants of freed Jamaican slaves who were
settled in the Freetown area in the late-18th century),
refugees from Liberia''s recent civil war, small
numbers of Europeans, Lebanese, Pakistanis, and
Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creolet spoken by the descendants of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English ,
Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
female: 18.2% (1995 est.)','d08a9e6ef51eef6a33da09ad78e24958167ec92d64ee4ea9f83d5d86ece62521','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c50d91ac08e66aef7d7efd65a4bc9feb679faffae94a9fc9b19fc2b8d5a6dc9',2002,'HU','Hungary','people-and-society',979,'Population: 5,422,366 (July 2002 est.)
Age structure: .
0-14 years: 1 8.3% (male 508,256; female 484,739)
15-64 years: 70.1% (male 1 ,888,705; female
1,910,842)
65 years and over: 1 1 .6% (male 237,770; female
392,054) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 10.09 births/1 ,000 population (2002 est.)
Death rate: 9.22 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.53 migrant(s)/1 ,000
population (2002 est.)
463
Slovakia (continued)
Sex ratio:
at birth:!. OS male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 ma!e(s)/female
65 years and over: 0.61 male(s)/fema!e
total population: 0.95 ma!e(s)/female (2002 est.)
Infant mortality rate: 8.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.2 years
male: 70.19 years
female: 78.41 years (2002 est.)
Total fertility rate: 1 .25 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.6%,
Roma 1 .6% (the 1 992 census figures underreport the
Gypsy/Romany community, which is about 500,000),
Czech, Moravian, Silesian 1.1%, Ruthenian and
Ukrainian 0.6%, German 0.1%, Polish 0.1%, other
0.2% (1996)
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy:
definition: NA
fofa/popu/af/on: NA%
male: NA%
female: NA%','f0a48c8ddcb2483db48e334d02328e09b82b736be604aa2079dc48d5313dd077','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c10a549b8515e69f4fad9be7e6c1187c7c3e7e558c3baf886c7253606fcd2e5',2002,'SB','Solomon Islands','people-and-society',989,'Population: 494,786 (July 2002 est.)
Age structure:
0-14 years: 43.4% (male 109,339; female 105,170)
15-64 years: 53.5% (male 134,125; female 130,804)
65 years and over: 3.1% (male 7,467; female 7,881)
(2002 est.)
Population growth rate: 2.91% (2002 est)
Birth rate: 33.26 births/1,000 population (2002 est.)
Death rate: 4. 1 9 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 23.68 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .82 years
mate: 69.38 years
female: 74.39 years (2002 est.)
Total fertility rate: 4.5 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%,
Micronestan 1.5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions: Anglican 45%, Roman Catholic 18%,
United (Methodist/Presbyterian) 12%, Baptist 9%,
Seventh-Day Adventist 7%, other Protestant 5%,
indigenous beliefs 4%
Languages: Melanesian pidgin in much of the
country is lingua franca; English is official but spoken
by only 1%-2% of the population
note: 120 indigenous languages
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','2cc240e81f34227d4d4dee54e7e60d0f65e3f2b89908965796033fdadeebcfcf','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efdc4f3196d27064a3dd62f0cf2196bffc50b1accba4be53150021efb13e76a6',2002,'SO','Somalia','people-and-society',998,'Population: 7,753,310
note: this estimate was derived from an official census
taken in 1975 by the Somali Government; population
counting In Somalia is complicated by the large
number of nomads and by refugee movements in
response to famine and clan warfare (July 2002 est.)
Age structure:
0-14 years: 44.7% (male 1 ,737,491 ; female 1 ,730,237)
15-64 years: 52.6% (male 2,054,243; female
2,019,980)
65 years and over: 2.7% (male 92,617; female
118,742) (2002 est.)
Population growth rate: 3.46% (2002 est.)
Birth rate: 46.83 births/1 ,000 population (2002 est.)
Death rate: 17.99 deaths/1,000 population
(2002 est.)
Net migration rate: 5.75 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 ,03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 122.15 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.96 years
male: 45.33 years
female: 48.65 years (2002 est.)
Total fertility rate: 7.05 children bom/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu and other
non-Somali 15% (including Arabs 30,000)
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 15 and over can read and write
total population: 37.8%
ma/e: 49.7%
female: 25.8% (2001 est.)
Population: 43,647,658
note: South Africa took a census October 1 996 that
showed a population of 40,583,611 (after an official
adjustment for a 6.8% underenumeration based on a
postenumeration survey); estimates for this country
explicitly take into account the effects of excess
mortality due to AIDS; this can result in lower fife
expectancy, higher infant mortality and death rates,
lower population and growth rates, and changes in the
distribution of population by age and sex than would
otherwise be expected (July 2002 est.)
Age structure:
0- 14 years: 31 .6% (male 6,943.761 ; female
6,849,745)
15-64 years: 63.4% (male 13,377,01 1 ; female
14,300,850)
65 years and over: 5% (male 816,222; female
1,360,069) (2002 est.)
Population growth rate: 0.02% (2002 est.)
Birth rate: 20.63 births/1 ,000 population (2002 est.)
Death rate: 1 8.86 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1.56 migrant(s)/1 ,000
population (2002 est.)
Population: no indigenous inhabitants
note: the small military garrison on South Georgia
withdrew in March 2001 , to be replaced by a
permanent group of scientists of the British Antarctic
Survey, which also has a biological station on Bird
Island; the South Sandwich Islands are uninhabited
(July 2002 est)','ef6c68888e132918417e804cb76b75024dc3727cc88bff2549ca817c204e7d48','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b0fcf60306add1e6fb1957aa645f603499dcd1617aa8e86cae974f86c7cf5bd',2002,'LK','Sri Lanka','people-and-society',1007,'Population: 19,576,783
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island; as of mid-1999, approximately
66,000 were housed in 133 refugee camps in south
India, another 40,000 lived outside the Indian camps,
and more than 200,000 Tamils have sought refuge in
the West (July 2002 est.)
Age structure:
0-14 years: 25.6% (male 2,559,246; female
2,446,393)
15-64 years: 67.7% (mate 6,446,320; female
6,802,515)
65 years and over: 6.7% (male 628,398; female
693,911) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 16.36 births/1,000 population (2002 est.)
Death rate: 6.45 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .39 migrant(s)/1 ,000 -
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/fema1e
under 15 years: 1.05 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and oven 0.91 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 15.65 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.35 years
male: 69.83 years
female: 75 years (2002 est.)
Total fertility rate: 1 .93 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,500
(1999 est.)
HIV/AIDS -deaths: 490 (1999 est.)
Nationality:
not//?: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 70%, Hindu 15%, Christian 8%,
Muslim 7% (1999)
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%, other 8%
note: English is commonly used in government and is
spoken competently by about 10% of the population
Literacy:
definition: age 15 and over can read and write
total population: 90.2%
male: 93.4%
female: 87.2% (1995 est.)
Population: 37,090,298 (July 2002 est.)
Age structure:
0-14 years: 44.2% (male 8,385,554; female
8,023,847)
15-64 years: 53.6% (male 9,945,683; female
9,933,383)
65 years and over: 2.2% (male 447,214; female
354,617) (2002 est.)
Population growth rate: 2.73% (2002 est.)
Birth rate: 37.21 births/1 ,000 population (2002 est.)
Death rate: 9.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
a/ b/rfn: 1.05 male(s)/femate
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 male(s)/female
65 years and over: 1.26 ma!e(s)/female
total population: "\\. 03 male(s)/female (2002 est.)
Infant mortality rate: 67,14 deaths/1 1000 live births
(2002 est.)
Life expectancy at birth:
total population: 57.33 years
male: 56.22 years
female: 58.5 years (2002 est.)
Total fertility rate: 5.22 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 186,000
(1998)
HIV/AIDS -deaths: NA
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
nofe: program of "Arabization" in process
Literacy:
definition: age 15 and over can read and write
tofafpopu/afon:46.1%
male: 57.7%
female: 34.6% (1995 est.)','ab824decb6848a044876434a6bd209db09913a941e333a60bc9323f06d66137f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38f05208041c310b70fc42260ba7269766badef45b72215d861b1de3d441772d',2002,'GY','Guyana','people-and-society',1014,'Population: 436,494 (July 2002 est.)
Age structure:
0-14 years: 31 .1% (male 69,642; female 66,262)
15-64 years: 63.1% (male 140,745; female 134,494)
65 years and over: 5.8% (male 1 1 ,480; female
13,871) (2002 est.)
Population growth rate: 0.55% (2002 est.)
Birth rate: 19.97 births/1 ,000 population (2002 est.)
Death rate: 5.67 deaths/1 ,000 population (2002 est.)
Net migration rate: -8.82 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.83 mate(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 23.48 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .9 years
male: 69.23 years
female: 74.7 years (2002 est.)
Total fertility rate: 2.44 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .26%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: 210(1 999 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 19th
century) 37%, Creole (mixed white and black) 31%,
Javanese 15%, "Maroons" (their African ancestors
were brought to the country in the 17th and 18th
centuries as slaves and escaped to the interior) 10%,
Amerindian 2%, Chinese 2%, white 1%, other 2%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely spoken),
Sranang Tongo (Surinamese, sometimes called
Taki-Taki, is native language of Creoles and much of
the younger population and is lingua franca among
others), Hindustani (a dialect of Hindi), Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
mate; 95%
female: 91% (1995 est.)
Population: 2,868 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -1 .99% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: 0% (2001 )
HIV/AIDS - people living with HIV/AIDS: 0 (2001 )
HIV/AIDS -deaths: 0(2001)
Ethnic groups: Norwegian 55.4%, Russian and
Ukrainian 44.3%, other 0.3% (1998)
Languages: Russian, Norwegian
Literacy: NA','d27fa2c8afb5a23dd848cc0aed7ab6f617564c68de46a4606de07f0831f35cc3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f2ad1b92f505cf612845715e88fc66b75d14f86b5a3c197a62f1132c6336619',2002,'AF','Afghanistan','people-and-society',1017,'Population: 6,719,567 (July 2002 est.)
Age structure:
0-14 years: 40.4% (male 1,370,314; female
1,346,465)
15-64 years: 54.9% (male 1 ,835,573; female
1,854,677)
65 years and over: 4,7% (male 136,033; female
176,505) (2002 est.)
Population growth rate: 2.12% (2002 est.)
500
Tajikistan (continued)
Birth rate: 32.99 births/1,000 population (2002 est.)
Death rate: 8.51 deaths/1 1000 population (2002 est.)
Net migration rate: -3.27 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 1 14.77 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 64.28 years
male: 61.24 years
female: 67.46 years (2002 est.)
Total fertility rate: 4.23 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1 999 est.)
Nationality:
noun: Tajikistant(s)
adjective: Tajikistan!
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 85%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
femafe:97%(1989 est.)
Population: 37,187,939
nofe; estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates., and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 44.6% (male 8,338,764; female
8,247,789)
15-64 years: 52.5% (male 9,674,951 ; female
9,847,084)
65 years and over: 2.9% (male 483,760; female
595,591) (2002 est.)
Population growth rate: 2.6% (2002 est.)
Birth rate: 39.12 births/1 ,000 population (2002 est.)
Death rate: 13.02 deaths/1,000 population
(2002 est.)
Net migration rate: -0.08 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over. 0.81 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 77.85 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .7 years
male: 50.76 years
female: 52.67 years (2002 est.)
Total fertility rate: 5.33 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 8.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1.3miilion
(1999 est.)
HIV/AIDS - deaths: 140,000 (1 999 est.)
Nationality:
noun; Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar ■ Arab, native African, mixed Arab
and native African
Religions: mainland - Christian 30%, Muslim 35%,
indigenous beliefs 35%; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of centra! and eastern Africa; the first
language of most people is one of the local languages
Literacy:
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67.8%
male: 79.4%
female: 56.8% (1995 est.)
Population: 62,354,402
. note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 23.3% (male 7,404,227; female
7,121,083)
15-64 years: 69.9% (male 21,469,186; female
22,090,520)
65 years and over: 6.8% (male 1 ,868,632; female
2,400,754) (2002 est.)
Population growth rate: 0.88% (2002 est.) ''
Birth rate: 16.39 births/1 ,000 population (2002 est.)
Death rate: 7.55 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.04 mafe(s)/female
15-64 years: 0.97 male(s)/fema!e
65 years and over: 0.78 maie(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 29.5 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69. 1 8 years
ma/e: 66 years
female: 72.51 years (2002 est.)
Total fertility rate: 1 .86 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.15%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 755,000
(1999 est.)
HIV/AIDS -deaths: 66,000(1999 est.)
Nationality:
noun; Thai (singular and plural)
arf/ecf/Ve;Thai
Ethntc groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.8%
male: 96%
femate; 91 .6% (1995 est.)
Population: 5,285,50''1
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 45.1% (male 1,195,052; female
1,187,014)
15-64 years: 52.4% (male 1,351,345; female
1,420,617)
65 years and over: 2.5% (mate 56,270; female
75,203) (2002 est.)
Population growth rate: 2.48% (2002 est.)
Birth rate: 36.1 1 births/1 ,000 population (2002 est.)
Death rate: 1 1 .3 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
508
Togo (continued)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 69.32 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 54.02 years
mate; 52.03 years
female: 56,07 years (2002 est.)
Total fertility rate: 5.14 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5.98%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 14,000 (1999 est.)
Nationality:
nc-ur?: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 51%, Christian 29%,
Muslim 20%
Languages: French (official and the language of
commerce), Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
mate: 67%
femate;37%(1995est.)
Population: 18,738 (July 2002 est.)
Age structure:
0-U years: 32,6% (male 3,101; female 3,004)
15-64 years: 63.6% (male 6,266; female 5,651)
65 years and over: 3.8% (male 31 9; female 397)
(2002 est.)
Population growth rate: 3.28% (2002 est.)
Birth rate: 24.18 births/1,000 population (2002 est.)
Death rate: 4.38 deaths/1 ,000 population (2002 est.)
Net migration rate: 12.97 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.07 male(s)/female (2002 est.)
Infant mortality rate: 17.46 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.76 years
male: 71.59 years
female: 76.03 years (2002 est.)
Total fertility rate: 3.18 children bom/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: none
:tive: none
Ethnic groups: black
Religions: Baptist 40%, Methodist 16%, Anglican
18%, Church of God 12%, other 14% (1990)
Languages: English (official)
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)
People - note: destination and transit point for illegal
Haitian immigrants bound for the Turks and Caicos
Islands, Bahamas, and US','e3728dafd4b0dfd876bd4d95f3504426592da71ec25948626054ad5dc8f987c4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('135bb9f3c91ffbffb261cd59569135343d0170515b62444ba0313d9c5439f502',2002,'TK','Tokelau','people-and-society',1026,'Population: 1,431 (July 2002 est)
Age structure:
0-14 years: 42%
15-64 years: 53%
65 years and over: 5% (1996 est)
Population growth rate: -0.92% (2002 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: 38 deaths/1 ,000 live births
(2002 est)
Life expectancy at birth:
total population: NA years
male: 68 years (2001)
female: 70 years (2001)
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Tokelauan(s)
ad/ecftVe: Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English
Literacy: NA','9c0048e7fb788c37597128603a91b05c77da7c2991ee9d3e0ca4d0ca9e0aa294','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('738ea413a7efc19ece705aadac5a3d2a110a085aa4712038f89f14fe001184c8',2002,'TM','Turkmenistan','people-and-society',1035,'Population: 4,688,963 (July 2002 est.)
Age structure:
0-14 years: 37.3% (male 895,536; female 853,301)
15-64 years: 58.6% (male 1 ,350,1 42; female
1,399,879)
65 years and over: 4.1% (male 72,784; female
117,321) (2002 est.)
Population growth rate: 1.84% (2002 est.)
Birth rate: 28.27 births/1 ,000 population (2002 est.)
Death rate: 8.92 deaths/1 ,000 population (2002 est.)
Net migration rate: -0,98 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 0.96 male(s)/female
522
Turkmenistan (continued)
65 years and over: 0.62 mate(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 73.21 deaths/1,000 live births
(2002 est)
Life expectancy at birth:
total population: MA years
mate: 57.57 years
femate:64.8 years (2002 est.)
Total fertility rate: 3.54 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun:Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%,
Russian 6.7%, Kazakh 2%, other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%,
Uzbek 9%, other 7%
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
mate: 99%
female: 97% (1989 est.)','c837cc0e876f27d46bc79534a32c87735d414029f66e58e957e226f308447e45','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b8783cba87ec75be233bf86fbe0d4a6bfbd05299864b9e01c5855ccdf4c00dc',2002,'TV','Tuvalu','people-and-society',1044,'Population: 11 ,146 (July 2002 est.)
Age structure:
0-14 years: 32.6% (mate 1,851; female 1,785)
15-64 years: 62.3% (male 3,335; female 3,607)
65 years and over: 5.1 % (male 233; female 335)
(2002 est.)
Population growth rate: 1 .4% (2002 est.)
Birth rate: 21 .44 births/1 ,000 population (2002 est.)
Death rate: 7.45 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 22 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.98 years
mate: 64.83 years
female: 69,23 years (2002 est.)
Total fertility rate: 3.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Tuvaluan(s)
ad/ecf/Ve: Tuvaluan
Ethnic groups: Polynesian 96%, Micronesian 4%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1.4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English, Samoan, Kiribati (on
the island of Nui)
Literacy:
definition: percentage of people over the age of 15
who can read and write
total population: 55% (1996)
male: NA%
fema/e:NA%
Population: 24,699,073
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 50.9% (male 6,314,371 ; female
6,265,681)
1&64 years: 47% (male 5,803,430; female
5,789,713)
65 years and over: 2.1% (male 247,798; female
278,080) (2002 est)
Population growth rate: 2.94% (2002 est.)
Birth rate: 47.15 births/1,000 population (2002 est.)
Death rate: 17.53 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.28 migrant(s)/1 ,000
population
note: according to the UNHCR, by the end of 2001 ,
Uganda was host to 178,815 refugees from a number
of neighboring countries, including: Sudan 155,996,
Rwanda 14,375, and Democratic Republic of the
Congo 7,459 (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: \\ male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 89.35 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 43.81 years
male: 42.97 years
female: 44.67 years (2002 est.)
Total fertility rate: 6.8 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 6.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1.1 million
(2001 est.)
HIV/AIDS - deaths: 1 1 0,000 (1 999 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Ankole 8%, Basoga
8%, Iteso 8%, Bakiga 7%, Lang! 6%, Rwanda 6%,
Bagisu 5%, Acholi 4%, Lugbara 4%, Batoro 3%,
Bunyoro 3%, Alur 2%, Bagwere 2%, Bakonjo 2%,
Jopodhola 2%, Karamojong 2%, Rundi 2%,
non-African (European, Asian, Arab) 1%, other 8%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications in the capital and may be taught
in school), other Niger-Congo languages,
Nilo-Saharan languages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.7%
male: 74%
female: 54% (2000 est)','f6f6d62c2d560e8780d19389f997bfbd856e415dd32ff8352f118742acb41fdb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cd9ef043b26f5ccc076bd75b28a77336aabd586ac3b604f08ede7d0ea8a3b70',2002,'OM','Oman','people-and-society',1055,'Population: 2,445,989
nofe: includes 1 ,576,472 non-nationals (July
2002 est.)
Age structure:
0-14 years: 27.7% (male 345,077; female 331,545)
15-64 years: 69.7% (male 1,069,443; female
635,275)
65 years and over: 2.6% (male 45,989; female
18,660) (2002 est.)
Population growth rate: 1.58% (2002 est.)
Birth rate: 18.3 births/1,000 population (2002 est.)
Death rate: 3.9 deaths/1 ,000 population (2002 est.)
Net migration rate: 1.41 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/f emale
under 15 years: 1 .04 male(s)/f emale
15-64 years: 1.68 male(s)/fema!e
65 years and over: 2.46 male(s)/female
total population: 1.48 male(s)/female (2002 est.)
Infant mortality rate: 16.12 deaths/1,000 live births
(2002 est.)
534
United Arab Emirates (continued)
Life expectancy at birth:
total population: 74.52 years
male: 72.06 years
female: 77 A years (2002 est)
Total fertility rate: 3.16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths; NA
Nationality:
noun: Emirati(s)
adjective: Emirati
Ethnic groups: Emirati 1 9%. other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write
total population: 79.2%
male: 78.9%
female: 79.8% (1995 est.)','34ac09829f0e34ce2581245e0f9dc6dd196d301e34455be09933f1be75b38b83','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0df12c318d45db0e6658d271429b826f870c10d7640af7b3ffe8cc9188c41aa5',2002,'US','United States','people-and-society',1063,'Population: 280,562,489 (July 2002 est.)
Age structure:
0-14 years: 21% (male 30,116,782; female
28,765,183)
15-64 years: 66.4% (male 92,391,120; female
93,986,468)
65 years andover: 12.6% (male 14,748,522; female
20,554,414) (2002 est.)
Population growth rate: 0.89% (2002 est.)
Birth rate: 14.1 births/1 ,000 population (2002 est.)
Death rate: 8.7 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.5 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years:), 05 male(s)/female
15-64 years: 0.98 male(s)/f emate
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 6.69 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77 A years
male: 74.5 years
female: 80.2 years (2002 est.)
Total fertility rate: 2.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.61%
(1999 est.)
HIV/AIDS -people living with HIV/AIDS: 850,000
(1999 est.)
HIV/AIDS -deaths: 20,000 (1999 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 77.1%, black 12.9%, Asian
4.2%, Amerindian and Alaska native 1.5%, native
Hawaiian and other Pacific islander 0.3%, other 4%
(2000)
note: a separate listing for Hispanic is not included
because the US Census Bureau considers Hispanic
to mean a person of Latin American descent
... PfudhoeBay
c Anchorage* . j
NORTH PACIFIC
OCEAN
HAWAIIAN ISLANDS
Honolulu
^
% Denver
Death
Los Angelas, phoenix
San Diego1
JJosfon
Jie<N York
•^Philadelphia
WASHINGTON, D.C
SOO lOOOkm
Detroit
Chicago*
Oklahoma Wianapolis
City. i Mem phis
Dallas. New /''
Houston OrJeans ^Jacksonville north
Miami ocean
BAH
''.''CUBA ,
540
United States (continued)
(especially of Cuban, Mexican, or Puerto Rican origin)
living in the US who may be of any race or ethnic
group (white, black, Asian, etc.)
Religions: Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
fema/e;97%(1979est.)
People -note:
note: data for the US are based on projections that do
not take into consideration the results of the 2000
census
Population: 3,386,575 (July 2002 est.)
Age structure:
0-14 years: 24.4% (male 422,826; female 402,324)
15-64 years: 62.6% (male 1,047,740; female
1,072,032)
65 years and over: 1 3% (male 1 81 ,522; female
260,131) (2002 est.)
Population growth rate: 0.79% (2002 est.)
Birth rate: 17.28 births/1 ,000 population (2002 est.)
Death rate: 9 deaths/1,000 population (2002 est.)
Net migration rate: -0,41 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years:). 0b male(s)/female
15-64 years: 0.98 rhale(s)/femafe
65 years and over: 0.7 ma!e(s)/female
total population: 0.95 male(s)/femaie (2002 est.)
Infant mortality rate: 14.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.66 years
male: 72.32 years
female: 79.17 years (2002 est.)
Total fertility rate: 2.35 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.33%
(1999 est.)
543
Uruguay (continued)
HIV/AIDS - people living with HIV/AIDS: 6,000
(1999 est.)
HIV/AIDS -deaths: 150 (1999 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than half of
the adult population attends church regularly),
Protestant 2%, Jewish 1%, nonprofessing or
other 31%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
female: 977% (1995 est.)','8cb06879c68118dfec36a98459a7c405181e3aa1659b6183f212e2139138597f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1910beaa0a1b83dc4d8504e186292ed68a71d7bc3fe4a4873259effe8edafb8b',2002,'UZ','Uzbekistan','people-and-society',1072,'Population: 25,563,441 (July 2002 est.)
Age structure:
0-14 years: 35.5% (male 4,617,110; female
4,457,065)
15-64 years: 59.8% (male 7,567,510; female
7,726,753)
65 years and over: 4.7% (male 482,137; female
712,866) (2002 est.)
Population growth rate: 1.62% (2002 est.)
Birth rate: 26.09 births/1 ,000 population (2002 est.)
Death rate: 7.98 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.94 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 0.98 male(s)/female
65 years and over:0.68 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 71 .72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.9 years
male: 60.38 years
female: 67.6 years (2002 est.)
Total fertility rate: 3.03 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistan
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1 .5%, other
2,5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1 996)','cb358e3d4e1cbd17bce5d117e3be77136dc21ba0c5e01dbbeeef22541446446a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7600961f8425152c374efe78d8fc05db7c0d11cdbe87ab5dbd4374f63d14a2d4',2002,'VU','Vanuatu','people-and-society',1082,'Population: 196,178 (July 2002 est.)
Age structure:
0-14 years: 35.6% (male 35,681 ; female 34,164)
1 5-64 years: 61.1% (male 61,384; female 58,473)
65 years and over: 3.3% (male 3,473; female 3,003)
(2002 est.)
Population growth rate: 1 .66% (2002 est.)
Birth rate: 24.83 births/1 ,000 population (2002 est.)
Death rate: 8.25 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/l ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15*64 years: 1 .05 male(s)7fema!e
65 years and over: 1.16 male(s)/female
total population: 1.05 male(s)/fema!e (2002 est.)
Infant mortality rate: 59.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .33 years
male: 59,93 years
female: 62.8 years (2002 est.)
Total fertility rate: 3.08 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Ni-Vanuatu (singular and plural)
ad/ecf/Ve:Ni-Vanuatu
Ethnic groups: indigenous Melanesian 98%,
French, Vietnamese, Chinese, other Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Roman Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of Christ 3.8%,
other 15.7% (including Jon Frum Cargo cult)
Languages: three official languages: English,
French, pidgin (known as Bislama or Bichelama), plus
more than 100 local languages
Literacy:
definition: age 15 and over can read and write
tofa/popu/af/on:53%
mate; 57%
female: 48% (1979 est.)
Population: 24,287,670 (July 2002 est.)
Age structure:
Q-14year$:to&% (male 3,955,132; female
3,710,159)
15-64 years: 63.6% (male 7,756,362; female
7,695,738)
65 years and over: 4.8% (male 533,559; female
636,720) (2002 est.) ''
Population growth rate: 1 .52% (2002 est.)
Birth rate: 20.22 births/1 ,000 population (2002 est.)
Death rate: 4.91 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.11 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/f emale
total population^. 02 male(s)/female (2002 est.)
Infant mortality rate: 24.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.56 years
male: 70.53 years
female: 76.81 years (2002 est)
Total fertility rate: 2.41 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.49%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 62,000
(1999 est.)
HIV/AIDS -deaths: 2,000 (1999 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions: nominally Roman Catholic 96%,
Protestant 2%, other 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 1 5 and over can read and write
tote/ populate 91.1%
mate: 91.8%
female: 90.3% (1995 est.)
Population: 81,098,416 (July 2002 est.)
Age structure:
0-14 years: 31 .6% (male 1 3,259,1 52; female
12,392,089)
15-64 years: 62.9% (male 24,938,098; female
26,083,681)
65 years and over: 5.5% (male 1 ,749,531 ; female
2,675,865) (2002 est.)
Population growth rate: 1 .43% (2002 est.)
Birth rate: 20.89 births/1,000 population (2002 est.)
Death rate: 6.1 4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.47 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/fema!e
under 15 years: 1.07 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.97 male(s)/fema!e (2002 est.)
Infant mortality rate: 29.34 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.86 years
male: 67.4 years
female: 72.5 years (2002 est.)
Total fertility rate: 2.44 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.24%
(1999 est)
HIV/AIDS - people living with HIV/AIDS: 100,000
(1999 est.)
HIV/AIDS - deaths: 2,500 (1 999 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese,
Hmong, Thai, Khmer, Cham, mountain groups
Religions: Buddhist, Hoa Hao, Cao Dai, Christian
(predominantly Roman Catholic, some Protestant),
indigenous beliefs, Muslim
Languages: Vietnamese (official), English
(increasingly favored as a second language), some
French, Chinese, and Khmer; mountain area
languages (Mon-Khmer and Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
female: 91 .2% (1995 est.)','958144d7d56f4959af1468450248f4a429afcf4356f8c8c5af6562e645d15498','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a61249d7907a5112ef2f3da3a69b165d33bb3e1be6d513048e1dfef62faa4c9',2002,'PR','Puerto Rico','people-and-society',1088,'Population: 123,498 (July 2002 est.)
Age structure:
0-14 years: 267% (male 16,926; female 16,012)
15-64 years: 64.2% (male 35,801 ; female 43,443)
65 years and over: 9.1% (male 4,851 ; female 6,465)
(2002 est.)
Population growth rate: 1.04% (2002 est.)
Birth rate: 15.85 births/1,000 population (2002 est.)
Death rate: 5.58 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/femafe
under 15 years: 1.06 male(s)/female
15-64 years: 0.82 male(s)/female
65 years and over: 0.75 male(s)/fema!e
total population: 0.87 male(s)/femaie (2002 est.)
Infant mortality rate: 9.21 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.43 years
ma/e: 74.55 years
female: 82.53 years (2002 est.)
Total fertility rate: 2.24 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic groups: black 80%; white 1 5%, other 5%
note: West Indian (45% bom in the Virgin Islands and
29% born elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy:
definition: NA
total population: Nk%
male: NA%
fema/e:NA%','c9227502905edf3071290e220d1c9afa836813373919d330b9d9f705c4b557bc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3651849cf1636b7c0884f061dadbad488aeedd712e704a6c66297ad4994d06d9',2002,'DZ','Algeria','people-and-society',1100,'Population: 256,177 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA (2002 est.)
Birth rate: NA births/1 1000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 6,233,821 ,945 (July 2002 est.)
Age structure:
0-14 years: 29.2% (male 932,581,592; female
885,688,851)
15-64 years: 63.7% (male 2,009,997,089; female
1,964,938,201)
65 years and over: 1 ''.1% (male 193,549,180; female
247,067,032) (2002 est.)
Population growth rate: 1.23% (2002 est.)
Birth rate: 21 .16 births/1 ,000 population (2002 est,)
Death rate: 8.93 deaths/1 ,000 population (2002 est.)
Sex ratio:
atWrffr1.05male(s)/fema!e
under 15 years: 1.05 male (s)/fem ale
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.01 ma!e(s)/female (2002 est.)
Infant mortality rate: 51 .55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.94 years
ma/e: 62.28 years
female: 65.67 years (2002 est.)
Total fertility rate: 2.7 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Religions: Christians 32.88% (of which Roman
Catholics 17.39%, Protestants 5.62%, Orthodox
3.54%, Anglicans 1.31%), Muslims 19.54%, Hindus
13.34%, Buddhists 5.92%, Sikhs 0.38%, Jews 0.24%,
other religions 12.6%, non-religious 12.63%, atheists
2.47% (2000 est.)
Languages: Chinese, Mandarin 14.37%, Hindi
6.02%, English 5.61%, Spanish 5.59%, Bengali 3.4%,
Portuguese 2.63%, Russian 2.75%, Japanese 2.06%,
German, Standard 1.64%, Korean 1.28%, French
1.27% (2000 est.)
note: percents are for "first language" speakers only
Literacy:
definition: age 1 5 and over can read and write
total population: 77%
male: 83%
female: 71% (1995 est.)
564
World (continued)
Population: 18,701 ,257 (July 2002 est.)
Age structure:
0-14 years: 47% (mate 4,468,928; female 4,317,648)
15-64 years: 50.1% (male 4,783,769; female
4,587,309)
65 years and over: 2.9% (male 273,282; female
270,321) (2002 est.)
Population growth rate: 3.4% (2002 est.)
Birth rate: 43.3 births/1,000 population (2002 est.)
Death rate: 9.31 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1.01 male(s)/fema!e
total population: 1.04 male(s)/female (2002 est.)
Infant mortality rate: 66.78 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.59 years
male: 58.81 years
female: 62.46 years (2002 est.)
Total fertility rate: 6.9 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
/?oun:Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; but also
Afro-Arab, South Asians, Europeans
Religions: Muslim including Shafi (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)
Population: 10,656,929
nofe: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2002 est.)
Age structure:
0-1 4 years: 19.6% (male 1 ,077,581 ; female 1 ,005,379)
568
Yugoslavia (continued)
15-64 years: 65.3% (male 3,41 5,929; female
3,546,410)
65 years and over: 15.1% (male 690,014; female
921 ,61 6) (2002 est)
Population growth rate: -0.12% (2002 est.)
Birth rate: 12.8 births/1,000 population (2002 est.)
Death rate: 10.59 deaths/1 ,000 population
(2002 est.)
Net migration rate: -3.38 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: tOB male(s)/female
under 15 years: 1.07 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.75 male(s)/femafe
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 1 7.36 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
totaf population: 73.72 years
male: 70.78 years
female: 76.89 years (2002 est.)
Total fertility rate: 1 .78 children born/woman
(2002 est.)
HIV/AIDS -adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serb 62.6%, Albanian 16.5%,
Montenegrin 5%, Hungarian 3.3%, other 12.6%
(1991)
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbian 95%, Albanian 5%
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 97.2%
female: 88.9% (1991)
Population: 9,959,037
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14years:47A% (male 2,357,581; female
2,335,644)
15-64 years: 50.4% (male 2,497,360; female
2,519,227)
65 years and over: 2.5% (male 106,160; female
143,065) (2002 est.) ■■
Population growth rate: 1 .9% (2002 est.)
Birthrate: 41.01 births/1 ,000 population (2002 est.)
Death rate: 21.89 deaths/1,000 population
(2002 est.)
Net migration rate: -0.16 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 ma!e(s)/femate
65 years and over: 0.74 male(s)/female
total population: 0.99 ma!e(s)/female (2002 est.)
Infant mortality rate: 89.39 deaths/1 ,000 live births
(2002 est.)
571
Zambia (continued)
Life expectancy at birth:
total population: 37.35 years
male: 37.05 years
female: 37.66 years (2002 est.)
Total fertility rate: 5.43 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 19.95%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: 870,000
(1999 est.)
HIV/AIDS -deaths: 99,000 (1999 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 1 5 and over can read and write English
total population: 78.9%
mate: 85.7%
female: 72 .6%','d4359eaacbaf21f214e61369f1a566098d1f22adfedd49eaad6755a728fa93bb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1b6503deb7f5d56476dc9f73e9fa0cf6af701ed6bbb7672714476b89924aebb',2002,'ZW','Zimbabwe','people-and-society',1108,'Population: 11,376,676
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 37.9% (male 2,178,073; female •
2,128,287)
15-64 years: 58.4% (male 3,376,850; female
3,268,315)
65 years and over: 3.7% (male 213,286; female
21 1,865) (2002 est.)
Population growth rate: 0,05% (2002 est.)
Birth rate: 24.59 births/1 ,000 population (2002 est.)
Death rate: 24.06 deaths/1,000 population
(2002 est.)
Net migration rate: NEGL migrant(s)/1,000
population
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
(2002 est.)
Sex ratio:
at birth: 1 ,03 male(s)/femate
under 15 years: 1.02 male(s)/femate
15-64 years: 1.03 ma!e(s)/female
65 years and over: 1.01 ma!e(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 62.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 36.5 years
ma/e: 37.87 years
female: 35.1 years (2002 est.)
Total fertility rate: 3.21 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 25.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .Smiltion
(1999 est.)
HIV/AIDS - deaths: 160,000 (1999 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 82%, Ndebele
14%, other 2%), mixed and Asian 1%, white less
than 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 1 5 and over can read and write English
total population: 85%
mate: 90%
femafe; 80% (1995 est.)','bd0a04229e346539397e093476ae06fbcbeb3a4449f89255d4fa63d2923e3889','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9742a7047066fd27600c2c05752f024b2d9d3dbaad60845f6b78610fd2ad755f',2002,'AU','Australia','people-and-society',35,'Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS -deaths
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People -note
Population: 19,546,792 (July 2002 est.)
Age structure:
0-14 years: 20.4% (male 2,046,052; female
1,949,725)
15-64 years: 67% (male 6,610,840; female
6,480,354)
65 years and over. 12.6% (male 1,078,506; female
1,381 ,315) (2002 est.)
Population growth rate: 0.96% (2002 est.)
Birth rate: 12.71 births/1,000 population (2002 est.)
Death rate: 7.25 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 4.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80 years
male: 77,15 years
female: 83 years (2002 est.)
Total fertility rate: 1 .77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS -deaths: 100 (1999 est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 1 1%, other
12.6%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 100%
mate: 100%
female: 100% (1980 est.)
Population: uninhabited (July 2002 est.)
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station (July 2002 est.).
Population: 1 ,866 (July 2002 est.)
Age structure:
0-14 years: 20.2%
15-64 years: 63.9%
65 years and over: 1 5.9% (1996)
Population growth rate: -0.69% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: N A migrant(s)/1 ,000 population
Sex ratio:
af birth: NA male(s)/female
under 15 years: NA male(s)/female
15-64 years: NA male(s)/female
65 years and over: NA male(s)/female
total population: NA male(s)/female
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 37.4%, Uniting Church in
Australia 14.5%, Roman Catholic 11.5%,
Seventh-Day Adventist 3.1%, none 12.2%, unknown
17.4%, other 3.9% (1996)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian
Literacy: NA
Population: 77,31 1 (July 2002 est.)
Age structure:
0-14 years: 23.4% (male 9,208; female 8,902)
15-64 years: 74.8% (male 27,041; female 30,781)
65 years and over: 1 .8% (male 690; female 689)
(2002 est.)
Population growth rate: 3.49% (2002 est.)
Birth rate: 20.29 births/1 ,000 population (2002 est.)
Death rate: 2,42 deaths/1 ,000 population (2002 est.)
Net migration rate: 17.02 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 male(s)/femate
under 15 years: 1.03 male(s)/female
15-64 years: 0.88 mate(s)/female
65 years and over: 1 male(s)/female
total population: 0.92 ma!e(s)/female (2002 est.)
Infant mortality rate: 5.61 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.95 years
male: 72,85 years
female: 79.23 years (2002 est.)
Total fertility rate: 1.76 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS -people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA
adjective: NA''
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Filipino, Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97%
female: 96% (1980 est.)','7247777fe39b029cf015737b2fb2cb24c2ce9bb1604601e8e2074282ee4e211a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8283bd9bac4a12ce1201b75126160a005c24788f4599ec2f56ef1c4bd7788b46',2002,'AF','Afghanistan','people-and-society',45,'Population: 27,755,775 (July 2002 est.)
Age structure:
0-14 years: 42% (male 5,953,291 ; female 5,706,542)
15-64 years: 55.2% (male 7,935,101; female
7,382,101)
65 years and over: 2,8% (male 410,278; female
368,462) (2002 est.)
Population growth rate: 3.43%
note: this rate reflects the continued return of refugees
from Iran (2002 est.)
Birth rate: 41.03 births/1 ,000 population (2002 est.)
Death rate: 1 7.43 deaths/1 ,000 population
(2002 est.)
Net migration rate: 10.7 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 1.11 male(s)/femaie
total population: 1 .06 male(s)/fema!e (2002 est.)
Infant mortality rate: 144.76 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.6 years
male: 47.32 years
female: 45.85 years (2002 est.)
Total fertility rate: 5.72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun.-Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 44%, Tajik 25%, Hazara
1 0%, minor ethnic groups (Aimaks, T urkmen, Baloch,
and others) 13%, Uzbek 8%
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
Turkmen) 1 1 %, 30 minor languages (primarily Balochi
and Pashai) 4%, much bilingualism
Literacy:
definition: age 1 5 and over can read and write
total population: 36%
male: 51%
female: 21% (1999 est.)
People - note: large numbers of Afghan refugees
create burdens on neighboring states
border countries: Afghanistan 1 ,206 km, China 41 4
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamir and Alay Mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Population: 6,719,567 (July 2002 est.)
Age structure:
0-14 years: 40.4% (male 1,370,314; female
1,346,465)
15-64 years: 54.9% (male 1 ,835,573; female
1,854,677)
65 years and over: 4.7% (male 1 36,033; female
176,505) (2002 est.)
Population growth rate: 2.12% (2002 est.)
500
Tajikistan (continued)
Birth rate: 32.99 births/1,000 population (2002 est.)
Death rate: 8,51 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.27 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af birth: 1. 05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/fema!e (2002 est.)
Infant mortality rate: 1 14.77 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 64.28 years
male: 61 .24 years
female: 67.46 years (2002 est.)
Total fertility rate: 4.23 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistan!
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 85%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 37,187,939
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 44.6% (male 8,338,764; female
8,247,789)
15-64 years: 52.5% (male 9,674,951 ; female
9,847,084)
65 years and over: 2.9% (male 483,760; female
595,591) (2002 est.)
Population growth rate: 2.6% (2002 est.)
Birth rate: 39.12 births/1 ,000 population (2002 est.)
Death rate: 13.02 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.08 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/femate
15-64 years: 0.98 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 77.85 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .7 years
male: 50.76 years
female: 52.67 years (2002 est.)
Total fertility rate: 5.33 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 8.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1.3million
(1999 est.)
HIV/AIDS - deaths: 140,000 (1999 est.)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar - Arab, native African, mixed Arab
and native African
Religions: mainland - Christian 30%, Muslim 35%,
indigenous beliefs 35%; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local languages
Literacy:
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67.8%
male: 79.4%
female: 56.8% (1995 est.)
Population: 18,738 (July 2002 est.)
Age structure:
0-14 years: 32.6% (male 3,101 ; female 3,004)
15-64 years: 63.6% (male 6,266; female 5,651)
65 years and over: 3.8% (male 31 9; female 397)
(2002 est.)
Population growth rate: 3.28% (2002 est.)
Birth rate: 24.18 births/1,000 population (2002 est.)
Death rate: 4.38 deaths/1 ,000 population (2002 est.)
Net migration rate: 12.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 ,03 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.07 male(s)/female (2002 est.)
Infant mortality rate: 17.46 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.76 years
male: 71 .59 years
female: 76.03 years (2002 est.)
Total fertility rate: 3.18 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: black
Religions: Baptist 40%, Methodist 16%, Anglican
18%, Church of God 12%, other 14% (1990)
Languages: English (official)
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)
People - note: destination and transit point for illegal
Haitian immigrants bound for the Turks and Caicos
Islands, Bahamas, and US
Population: 196,178 (July 2002 est.)
Age structure:
0-M years: 35.6% (male 35,681; female 34,164)
15-64 years: 61 .1% (male 61 ,384; female 58,473)
65 years and over: 3.3% (male 3,473; female 3,003)
(2002 est.)
Population growth rate: 1 .66% (2002 est.)
Birth rate: 24.83 births/1 ,000 population (2002 est.)
Death rate: 8.25 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/l ,000 population
(2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1.16 male(s)/female
total population: 1.05 male(s)/fema!e (2002 est.)
Infant mortality rate: 59.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .33 years
male: 59.93 years
female: 62.8 years (2002 est.)
Total fertility rate: 3.08 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 98%,
French, Vietnamese, Chinese, other Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Roman Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of Christ 3.8%,
other 15.7% (including Jon Frum Cargo cult)
Languages: three official languages: English,
French, pidgin (known as Bislamaor Bichelama), plus
more than 100 local languages
Literacy:
definition: age 1 5 and over can read and write
total population: 53%
male: 57%
fema/e:48%(1979est.)','2e9cd6dc687227ed0f8e2a8a1d4e640dbd7919223dad65a7d92e9b68765d9444','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62398ee0151a30360e808a38a4675fdab9725d7b912b7a1ff4284abbe5923ef8',2002,'AL','Albania','people-and-society',54,'Population: 3,544,841 (July 2002 est.)
Age structure:
0-14 years: 28.8% (male 528,678; female 493,531 )
15-64 years: 64% (male 1 ,094,034; female
1,175,024)
65 years and over: 7.2% (male 1 1 1 ,524; female
142,050) (2002 est.)
Population growth rate: 1.06% (2002 est.)
Birth rate: 1 8.59 births/1 ,000 population (2002 est.)
Death rate: 6.49 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .46 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.79 ma!e(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 38.64 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.1 years
male: 69.27 years
female: 75.14 years (2002 est.)
Total fertility rate: 2.27 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(2000 est.)
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greek 3%, other 2%
(Vlach, Gypsy, Serb, and Bulgarian) (1989 est.)
note: in 1 989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: all mosques and churches were closed in 1967
and religious observances prohibited; in
November 1990, Albania began allowing private
religious practice
Languages: Albanian (Tosk is the official dialect),
Greek
Literacy:
definition: age 9 and over can read and write
total population: 93% (1997 est.)
male: NA%
female: NA%
Population: 32,277,942 (July 2002 est.)
Age structure:
0-14 years: 33.5% (male 5,512,369; female
5,311,914)
15-64 years: 62.4% (mate 10,175,135; female
9,950,315)
65 years and over: 4.1% (male 610,643; female
717,566) (2002 est.)
Population growth rate: 1 .68% (2002 est.)
Birth rate: 22.34 births/1,000 population (2002 est.)
Death rate: 5.1 5 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 mate(s)/female
under 15 years: 1.04 male(s)/fema1e
15-64 years: 1.02 male(s)/fema1e
65 years and over: 0.85 male(s)/female
total population: 1.02 male(s)/fema1e (2002 est.)
Infant mortality rate: 39.1 5 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.24 years
male: 68.87 years
female: 71 .67 years (2002 est.)
Total fertility rate: 2.63 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 61.6%
male: 73.9%
female: 49% (1995 est.)','6f808a76b681221061edbfdab9cc3f70835b28616dbc08450315eaa2199f8af5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4893845830e2bb3b421b07ddcc8ce1fa95f6800c6e66503e408a6fd312ee00e4',2002,'NZ','New Zealand','people-and-society',65,'Population: 68,688 (July 2002 est.)
Age structure:
0-14 years: 38.1% (male 13,445; female 12,688)
15-64 years: 56.7% (male 19,228; female 19,741)
65 years and over: 5.2% (male 1 ,931 ; female 1 ,655)
(2002 est.)
Population growth rate: 2.31% (2002 est.)
Birth rate: 24.04 births/1 ,000 population (2002 est.)
Death rate: 4.34 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.42 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 1.17 ma!e(s)/female
total population: 1.02 ma!e(s)/female (2002 est.)
Infant mortality rate: 10.09 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.53 years
male: 71. 12 years
female: 80.21 years (2002 est.)
Total fertility rate: 3.4 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions: Christian Congregationalist 50%, Roman
Catholic 20%, Protestant and other 30%
Languages: Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
Population: 106,137 (July 2002 est.)
Age structure:
0-14 years: 39.5% (male 21 ,374; female 20,555)
15-64 years: 56.4% (male 29,519; female 30,322)
65 years and over: 4.1% (male 1 ,945; female 2,422)
(2002 est.)
Population growth rate: 1.85% (2002 est.)
Birth rate: 24.08 births/1 ,000 population (2002 est.)
Death rate: 5.63 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 13.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.56 years
mate: 66.13 years
female: 71.11 years (2002 est.)
Total fertility rate: 3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
female: 98.7% (1996 est, )
512
Tonga (continued)
Population: 1,163,724 (July 2002 est.)
Age structure:
0-14 years: 23% (male 136,807; female 131,177)
15-64 years: 70.2% (male 419,847; female 396,643)
65 years and over: 6.8% (male 35,146; female
44,104) (2002 est.)
Population growth rate: -0.52% (2002 est.)
Birth rate: 13.66 births/1 ,000 population (2002 est.)
Death rate: 8.81 deaths/1,000 population (2002 est.)
Net migration rate: -10.02 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 .04 male(s)/female (2002 est.)
Infant mortality rate: 24.2 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.59 years
male: 66.04 years
lemate: 71 .25 years (2002 est.)
Total fertility rate: 1 .8 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,800
(1999 est.)
HIV/AIDS -deaths: 530 (1999 est.)
Nationality:
noizn:Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic groups: black 39.5%, East Indian (a local
term - primarily immigrants from northern India)
40.3%, mixed 18.4%, white 0.6%, Chinese and
other 1.2%
Religions: Roman Catholic 29.4%, Hindu 23.8%,
Anglican 10.9%, Muslim 5.8%, Presbyterian 3.4%,
other 26.7%
514
Trinidad and Tobago (continued)
Languages: English (official), Hindi, French,
Spanish, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 94% (2000)
male: 95.9% (1999)
female: 91 .7% (1999)
Population: uninhabited (July 2002 est.)
Population: 15,585 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA (2002 est.)
Birthrate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Wallisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy:
definition: age 15 and over can read and write
total population: 50%
male: 50%
female: 50% (1969 est.)','b19f47237d2b806175e4a369901d53005fb87d0b172b10cf047f53b7710102bc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea2d1c438d654aa8815e1db4a84c6e85796bf7bf44f6567717004a45ddbc4a98',2002,'AD','Andorra','people-and-society',74,'Population: 68,403 (July 2002 est.)
Age structure:
0-14years: 15.2% (male 5,456; female 4,951)
15-64 years: 71 .9% (male 25,855; female 23,31 1 )
65 years and over: 12.9% (male 4,425; female 4,405)
(2002 est.)
Population growth rate: 1.11% (2002 est.)
Birth rate: 9.97 births/1 ,000 population (2002 est.)
Death rate: 5.57 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.74 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and overt male(s)/female
total population: 1.09 male(s)/fema!e (2002 est.)
Infant mortality rate: 4.07 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 83.48 years
male: 80.58 years
female: 86.58 years (2002 est.)
Total fertility rate: 1.26 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran 33%,
Portuguese 11%, French 7%, other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy:
definition: NA
total population: 1 00%
male: NA%
female: NA%','8c185381f5dd9987e5797b1c872be20dcc8697759f8ba56ec97130fe34c9de94','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('071cd93a2c26a1a4070c1c2cc94f080b74b58c0945684af4835400399e692ff6',2002,'AO','Angola','people-and-society',83,'Population: 10,593,171 (July 2002 est.)
Age structure:
0-14 years: 43.3% (male 2,318,326; female
2,272,726)
15-64 years: 53.9% (male 2,904,595; female
2,806,430)
65 years and over: 2.8% (male 131 ,316; female
159,778) (2002 est.)
Population growth rate: 2.18% (2002 est.)
Birth rate: 46.18 births/1 ,000 population (2002 est.)
Death rate: 24.35 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 1 91 .66 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 38.87 years
male: 37.62 years
female: 40. 18 years (2002 est.)
Total fertility rate: 6.43 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.78%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000
(1999 est.)
HIV/AIDS - deaths: 15,000 (1 999 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (1998 est.)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
fema/e: 28% (1998 est.)
Population: 1 2,446 (July 2002 est.)
Age structure:
0-14 years: 25% (male 1,575; female 1,529)
15-64 years: 68.1% (male 4,356; female 4,124)
65 years and over: 6.9% (male 383; female 479)
(2002 est.)
Population growth rate: 2.44% (2002 est.)
Birth rate: 14.94 births/1 ,000 population (2002 est.)
Death rate: 5.54 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 5.02 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and oven 0.8 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 23.68 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.5 years
male: 73.6 years
female: 79.5 years (2002 est.)
Total fertility rate: 1.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black (predominant), mulatto, white
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)','e6b6338bc368b194708e1a53b9aed6c190baa9597fd540dd3d91b1326a9230f9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12c6595f3a8e634abc5043e1e2564d017522e5573dd7a33f8d2170dfc8cdb304',2002,'AQ','Antarctica','people-and-society',93,'Population: no indigenous inhabitants, but there are
seasonally staffed research stations
note: approximately 27 nations, all signatory to the
Antarctic Treaty, send personnel to perform seasonal
(summer) and year-round research on the continent
and in its surrounding oceans; the population of
persons doing and supporting science on the
continent and its nearby islands south of 60 degrees
south latitude (the region covered by the Antarctic
Treaty) varies from approximately 4,000 in summer to
1 ,000 in winter; in addition, approximately 1 ,000
personnel including ship''s crew and scientists doing
onboard research are present in the waters of the
treaty region; summer (January) population - 3,687
total; Argentina 302, Australia 201, Belgium 13, Brazil
80, Bulgaria 16, Chile 352, China 70, Finland 1 1 ,
France 100, Germany 51 , India 60, Italy 106, Japan
136, South Korea 14, Netherlands 10, NZ 60, Norway
40, Peru 28, Poland 70, Russia 254, South Africa 80,
Spain 43, Sweden 20, UK 192, US 1,378 (1998-99);
winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France
33, Germany 9, India 25, Japan 40, South Korea 14,
NZ 10, Poland 20, Russia 102, South Africa 10, UK
39, US 248 (1998-99); year-round stations - 42 total;
Argentina 6, Australia 4, Brazil 1, Chile 4, China 2,
Finland 1 , France 1 , Germany 1 , India 1 , Italy 1 , Japan
1 , South Korea 1 , NZ 1 , Norway 1 , Poland 1 , Russia
6, South Africa 1, Spain 1, Ukraine 1, UK 2, US 3,
Uruguay 1 (1998-99); summer-only stations - 32 total;
Argentina 3, Australia 4, Bulgaria 1 , Chile 7, Germany
1 , India 1 , Japan 3, NZ 1 , Peru 1 , Russia 3, Sweden
2, UK 5 (1998-99); in addition, during the austral
summer some nations have numerous occupied
locations such as tent camps, summer-long
temporary facilities, and mobile traverses in support of
research (July 2002 est.)
Population: 3,330,099
note: Armenia''s first census since independence was
conducted in October 2001 , but official figures have
not yet been released (July 2002 est.)
Age structure:
0-14 years: 22.2% (male 374,597; female 363,115)
15-64 years: 67.7% (male 1 ,104,1 00; female
1,150,282)
65 years and over: 10.1 % (male 141 ,330; female
196,675) (2002 est.)
Population growth rate: -0.15% (2002 est.)
Birth rate: 12 births/1 ,000 population (2002 est.)
Death rate: 9.94 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.51 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.96 male(s)/fema!e
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (2002 est,)
Infant mortality rate: 41 .07 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.59 years
male: 62.27 years
female: 71 .12 years (2002 est.)
Total fertility rate: 1 .53 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
/)oi/n:Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1 989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Apostolic 94%, other
Christian 4%, Yezidi (Zoroastrian/animist) 2%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
Population: 70,441 (July 2002 est.)
Age structure:
0-14 years: 21% (male 7,635; female 7,169)
15-64 years: 68.4% (male 23,270; female 24,906)
65 years and over: 1 0.6% (male 3,081 ; female 4,380)
(2002 est.)
Population growth rate: 0.59% (2002 est.)
Birth rate: 1 2.22 births/1 ,000 population (2002 est.)
Death rate: 6.29 deaths/1 ,000 population (2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 6.26 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.67 years
male: 75.32 years
female: 82.19 years (2002 est.)
Total fertility rate: 1 .8 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Aruban(s)
adjective: Aruban; Dutch
Ethnic groups: mixed white/Caribbean
Amerindian 80%
Religjbns: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy:
definition: NA
total population: 97%
male: NA%
female: NA%','34fa45b73ae4cbd6d0e8e8f1a8e4d9803b9b7b7a15dc17063080471190e0f8a3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bc501477f6ac82d38a51d8a9dc6957b2a9b7954e650bb33f0aaf6407d767730',2002,'AG','Antigua and Barbuda','people-and-society',101,'Population: 67,448 (July 2002 est.)
Age structure:
0-14 years: 28% (male 9,618; female 9,293)
15-64 years: 67.3% (male 22,695; female 22,682)
65 years and over: 4.7% (male 1,289; female 1,871)
(2002 est.)
Population growth rate: 0.69% (2002 est.)
Birth rate: 18.84 births/1,000 population (2002 est.)
Death rate: 5.75 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.23 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 21 .61 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .02 years
male: 68.72 years
female: 73.45 years (2002 est.)
Total fertility rate: 2,29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun; Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant,
some Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
male: 90%
female: 88% (1960 est.)','a8d90252a082cba1fb476505e9c4b82d2fd0c7ddbeb7f63fc35cb8ca6c795fd2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e9b7830ab023cf11762a96582c4f302a6e120475c55c8ed23100980dc2c4409',2002,'AR','Argentina','people-and-society',114,'Population: 37,812,817 (July 2002 est.)
Age structure:
0-14 years: 26.3% (male 5,090,046; female
4,854,761)
15-64 years: 63.2% (male 11,968,135; female
11,937,709)
65 years and over: 10.5% (male 1 ,636,332; female
2,325,834) (2002 est.)
Population growth rate: 1.13% (2002 est.)
Birth rate: 18.23 births/1 ,000 population (2002 est.)
Death rate: 7.57 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .05 ma!e(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 mate(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 17.2 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.48 years
male: 72.1 years
female: 79.03 years (2002 est.)
Total fertility rate: 2.41 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.69%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 1 ,800 (1999 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian)
97%, mestizo, Amerindian, or other nonwhite
groups 3%
Religions: nominally Roman Catholic 92% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 4%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 1 5 and over can read and write
total population: 96.2%
male: 96.2%
female: 96.2% -(1995 est.)
Population: 5,884,491 (July 2002 est.)
Age structure:
0-14 years: 38.7% (male 1,156,366; female
1,119,558)
15-64 years: 56.6% (male 1,671,721; female
1,658,683)
65 years and over: 4.7% (male 128,137; female
150,026) (2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 30.5 births/1 ,000 population (2002 est.)
Death rate: 4.69 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.09 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/fema!e (2002 est.)
Infant mortality rate: 28.75 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.16 years
male: 71 .67 years
female: 76.77 years (2002 est.)
Total fertility rate: 4.07 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0. 1 1 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS -deaths: 220 (1999 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%
Religions: Roman Catholic 90%, Mennonite, and
other Protestant
Languages: Spanish (official), Guarani (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 92.1%
male: 93.5%
female: 90.6% (1995 est.)','3bdf0889e9770999d95a322bff45356aae453cc9a6235e10bca4d060a453e8d7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b4513b49ecd9f21aad25eaf2ca560e4dc25b6076eb9c1a36dd9b81cca33cfeb',2002,'AT','Austria','people-and-society',119,'Population: 8,1 69,929 (July 2002 est.)
Age structure:
0-14 years: 16.4% (male 686,205; female 652,840)
15-64 years: 68.2% (male 2,814,866; female
2,756,777)
65 years and over: 15.4% (male 484,313; female
774,928) (2002 est.)
Population growth rate: 0.23% (2002 est.)
Birth rate: 9.58 births/1,000 population (2002 est.)
Death rate: 9.73 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.45 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1,05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 4.39 deaths/1 ,000 live births
(2002 est.)
33
Austria (continued)
Life expectancy at birth:
total population: 78 years
wale: 74.85 years
female: 81.31 years (2002 est.)
Total fertility rate: 1 .4 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 643
(2001 est.)
HIV/AIDS -deaths: 8 (2001 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 88%, non-nationals 9.3%
(includes Croatians, Slovenes, Hungarians, Czechs,
Slovaks, Roma), naturalized 2% (includes those who
have lived in Austria at least three generations)
Religions: Roman Catholic 78%, Protestant 5%,
Muslim and other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: NA%
female: NA%','4d7051967d5f4815029f4afa602c0dde2374adbd797a83b9ad5191c8371d59f6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b09601aded0a0ec9efd17b93e7d224a06ce816f12ff812416f207bd52299d397',2002,'AZ','Azerbaijan','people-and-society',127,'Population: 7,798,497 (July 2002 est.)
Age structure:
0- 14 years : 28.3% (male 1 ,122,340; female 1 ,082,355)
15-64 years: 64.3% (male 2,441 ,830; female
2,577,109)
65 years and over: 7.4% (male 228,735; female
346,128) (2002 est.)
Population growth rate: 0.38% (2002 est.)
Birth rate: 18.84 births/1,000 population (2002 est.)
Death rate: 9,61 deaths/1 ,000 population (2002 est.)
Net migration rate: -5.41 migrant(s)/1 ,000
population (2002 est,)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 0.95 male(s)/fema!e
65 years and over: 0.66 ma!e(s)/female
total population: 0.95 mate(s)/female (2002 est.)
Infant mortality rate: 82.74 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.06 years
male: 58.8 years
female: 67.53 years (2002 est.)
Total fertility rate: 2.29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani 3.2%,
Russian 2.5%, Armenian 2%, other 2.3% (1998 est.)
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
tower
Languages: Azerbaijani (Azeri) 89%, Russian 3%,
Armenian 2%, other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)','90d45f2ee7eb815ab5d009de6e0f38dd38af386ad32c320e569ec535969c092c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95f550ec8ed472b88227b3a3aab887f88d504fe5e9b6ad577e5bb919755fdfad',2002,'CU','Cuba','people-and-society',137,'Population: 300,529
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 29% (male 43,964; female 43,250)
15-64 years: 64.7% (male 95,508; female 98,859)
65 years and over: 6.3% (male 7,948; female 1 1 ,000)
(2002 est.)
Population growth rate: 0.86% (2002 est.)
Birth rate: 1 8.69 births/1 ,000 population (2002 est.)
Death rate: 7.49 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .02 ma!e(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 17.08 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.87 years
male: 66.32 years
female: 73.49 years (2002 est.)
Total fertility rate: 2.28 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 4.13%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 6,900
(1999 est.)
HIV/AIDS - deaths: 500 (1 999 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 12%, Asian and
Hispanic 3%
Religions: Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages: English, Creole (among Haitian
immigrants)
Literacy:
definition: age 1 5 and over can read and write
total population: 98.2%
male: 98.5%
female: 98% (1995 est.)','29ac87c7b848cdc09611bd5efebf7f9b484ed3bfb580f6073acab14b433406e2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d431e892223acaaaff6a5aa37b0b13a0b866574504c606f0c26c6c5aabcd7c3',2002,'BH','Bahrain','people-and-society',147,'Population: 656,397
note: includes 228,424 non-nationals (July 2002 est.)
Age structure:
0-14 years: 29.2% (male 97,022; female 94,605)
15-64 years: 67.7% (male 261 ,91 9; female 1 82,727)
65 years and over: 3.1% (male 10,230; female 9,894)
(2002 est.)
Population growth rate: 1 .67% (2002 est.)
Birth rate: 1 9.53 births/1 ,000 population (2002 est.)
Death rate: 3.95 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .09 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .43 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1 .29 male(s)/female (2002 est.)
Infant mortality rate: 19.18 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.47 years
male: 71 .05 years
female: 75.96 years (2002 est.)
Total fertility rate: 2.75 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 19%, other
Arab 10%, Iranian 8%
Religions: Shi''a Muslim 70%, Sunni Muslim 30%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 1 5 and over can read and write
total population: 88.5%
male: 91.6%
female: 84.2% (2002 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; a cemetery and remnants of structures
from early settlement are located near the middle of
the west coast; visited annually by US Fish and
Wildlife Service (July 2002 est.)','baf3daaa2c059f5746a078cdeaa041c7210ffbc8666c53f1249626aef9168037','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1928061b5df64472c8ffb0fb9b20284ce3eb7b7d0fc7a57b1ec3027665e755df',2002,'BD','Bangladesh','people-and-society',155,'Population: 133,376,684 (July 2002 est.)
Age structure:
0-14 years: 33.8% (male 23,069,242; female
21,995,457)
15-64 years: 62.8% (male 42,924,778; female
40,873,077)
65 years and over: 3.4% (male 2,444,314; female
2,069,816) (2002 est.)
Population growth rate: 1 .59% (2002 est.)
Birth rate: 25.12 births/1,000 population (2002 est.)
Death rate: 8.47 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.75 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over 1.18 male(s)/female
total population: 1 .05 male(s)/female (2002 est.)
Infant mortality rate: 68.05 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.92 years
male: 61 .08 years
female: 60.74 years (2002 est.)
Total fertility rate: 2.72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIWAIDS - people living with HiV/AIDS: 13,000
(1999 est.)
HIWAIDS - deaths: 1 ,000 (1 999 est.)
43
Bangladesh (continued)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladeshi
Ethnic groups: Bengali 98%, tribal groups,
non-Bengali Muslims (1998)
Religions: Muslim 83%, Hindu 16%, other 1%
(1998)
Languages: Bangla (official, also known as Bengali),
English
Literacy:
definition: age 15 and over can read and write
total population: 56%
mafe:63%
female: 49% (2000 est.)
Population: 276,607 (July 2002 est.)
Age structure:
0-14 years: 21 .4% (male 29,888; female 29,338)
15-64 years: 69.8% (male 94,214; female 98,811)
65 years and over: 8.8% (male 9,378; female 14,978)
(2002 est.)
Population growth rate: 0.46% (2002 est.)
Birth rate: 13.32 births/1 ,000 population (2002 est.)
Death rate: 8.38 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.31 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.01 male(s)/female
under 15 years: 1.02 mate(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.93 male(s)/femate (2002 est.)
Infant mortality rate: 1 1 .71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.49 years
male: 70.9 years
female: 76.12 years (2002 est.)
Total fertility rate: 1.64 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,800
(1999 esl.)
HIV/AIDS -deaths: 130 (1999 est.)
Nationality:
noun: Barbadian(s) or Baj''an (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 90%, white 4%, Asian and
mixed 6%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 97.4%
male: 98%
female: 96.8% (1995 est.)','66a917abbe232c62fcb9857417abca9f6ec49f8ba8931baa11105b839c7d6221','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2204c0e3054fbb2bc76e39fb55462d32663eee9da42687dfa5cfc3a2ad591ea9',2002,'LC','Saint Lucia','people-and-society',168,'Population: uninhabited (July 2002 est.)
Population: 160,145 (July 2002 est.)
Age structure:
0-14 years: 31 .6% (male 25,879; female 24,695)
15-64 years: 63.1 % (male 49,667; female 51 ,482)
65 years and over: 5.3% (male 3,1 34; female 5,288)
(2002 est.)
Population growth rate: 1 .24% (2002 est.)
Birth rate: 21 .37 births/1 ,000 population (2002 est.)
Death rate: 5,3 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.64 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 14.8 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.82 years
male: 69.26 years
female: 76.64 years (2002 est.)
Total fertility rate: 2.34 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East
Indian 3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 67%
male: 65%
female: 69% (1980 est.)','a36d21ac0119eff469a321b9a6c6c27a8f1f70657d105dae40bb8a7d8c7722ff','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e6e9948537d8867808543892c336671873b8b494a837c1c1d188febc00277c',2002,'BY','Belarus','people-and-society',174,'Population: 1 0,335,382 (July 2002 est.)
Age structure:
0-14 years: 17.3% (male 914,579; female 876,346)
15-64 years: 68.6% (male 3,443,859; female
3,643,628)
65 years and over: 14.1% (male 482,624; female
974,346) (2002 est.)
Population growth rate: -0.14% (2002 est.)
Birth rate: 9.86 births/1 ,000 population (2002 est.)
Death rate: 13.99 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.78 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total pdpulation: 0.88 ma!e(s)/female (2002 est.)
Infant mortality rate: 14.12 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.28 years
male: 62.3 years
female: 74.56 years (2002 est.)
Total fertility rate: 1.31 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.28%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS -deaths: 400 (1999 est, )
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Belarusian 81 .2%, Russian 1 1 .4%,
Polish, Ukrainian, and other 7.4%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Belarusian, Russian, other
48
Belarus (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 1 0,274,595 (July 2002 est.)
Age structure:
0-14 years: 17.3% (male 91 1 ,729; female 871 ,470)
15-64 years: 65.6% (male 3,395,885; female
3,341,536)
65 years and over. 1 7.1 % (male 71 6,673; female
1,037,302) (2002 est.)
Population growth rate: 0.15% (2002 est.)
Birth rate: 10.58 births/1,000 population (2002 est.)
Death rate: 10.08 deaths/1,000 population
(2002 est.)
Net migration rate: 0.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.69 ma!e(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 4.64 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.13 years
male: 74.8 years
female: 81 .62 years (2002 est.)
Total fertility rate: 1.61 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,700
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 58%, Walloon 31%, mixed
or other 11%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Dutch 60%, French 40%, German less
than 1%, legally bilingual (Dutch and French)
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: NA%
female: NA%
Population: 2,366,515 (July 2002 est.)
Age structure:
0-14 years: 15.8% (male 191,116; female 182,692)
15-64 years: 68.6% (male 775,481; female 847,261)
65 years and over: 15.6% (male 1 20,304; female
249,661) (2002 est.)
Population growth rate: -0.77% (2002 est.)
Birth rate: 8.27 births/1 ,000 population (2002 est.)
Death rate: 14.74 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1.23 migrant(s)/1 ,000
population (2002 est.)','8ac134861ab09e24e00c8c8babfd3c3366016e9137a2a4514b734089a7022f40','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d246ae7e93ede96fb8b3420138e36a0a005e3a6f19690a1d2ef7b6a9e1265c4',2002,'BZ','Belize','people-and-society',183,'Population: 262,999 (July 2002 est.)
Age structure:
0-14 years: 41 .6% (male 55,716; female 53,581)
15-64 years: 54.9% (male 73,068; female 71 ,368)
65 years and over: 3.5% (male 4,51 1 ; female 4,755)
(2002 est.)
Population growth rate: 2.65% (2002 est.)
Birth rate: 31.08 births/1,000 population (2002 est.)
Death rate: 4.6 deaths/1,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 24.31 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .46 years
male: 69.17 years
female: 73.87 years (2002 est.)
Total fertility rate: 3.96 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS -deaths: 170 (1999 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo48.7%, Creole 24.9%, Maya
10.6%, Garifuna 6.1%, other 9.7%
53
Belize (continued)
Religions: Roman Catholic 49.6%, Protestant 27%
(Anglican 5.3%, Methodist 3.5%, Mennonite 4.1%,
Seventh-Day Adventist 5.2%, Pentecostal 7.4%,
Jehovah''s Witnesses 1.5%), none 9.4%, other 14%
(2000)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib), Creole
Literacy:
definition: age 15 and over can read and write
total population: 70.3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as 75%','4a40545cc0257a344afd43e82176d8e7393c533b3261af57ae7d99dea7cb4ee6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95ec3a44127ccc0eff7453967b57a6dc461fc699166fa42bef9ae00f08b6c762',2002,'BJ','Benin','people-and-society',191,'Population: 6,787,625
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 1,616,138; female
1,585,463)
15-64 years: 50.5% (male 1,665,439; female
1,764,966)
65 years and over: 2.3% (male 65,877; female
89,742) (2002 est.)
Population growth rate: 2.91% (2002 est.)
Birth rate: 43.66 births/1 ,000 population (2002 est.)
Death rate: 1 4.52 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/fema!e
under 15 years: 1.02 mate(s)/fema!e
15-64 years: 0.94 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.97 male(s)/fema1e (2002 est.)
Infant mortality rate: 88.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.69 years
mate: 48.81 years
female: 50.61 years (2002 est.)
Total fertility rate: 6.1 4 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 4.1% (2002)
HIV/AIDS - people living with HIV/AIDS: 160,000
(2002)
HIV/AIDS -deaths: 37,000(2002)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese ■
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 15 and over can read and write
total population: 37.5%
male: 52.2%
female: 23.6% (2000)
Population: 63,960 (July 2002 est.)
Age structure:
0-14 years: 19.2% (male 6,058; female 6,225)
15-64 years: 69.4% (male 21 ,950; female 22,442)
65 years and over: 1 1 .4% (male 3,1 63; female 4,122)
(2002 est.)
Population growth rate: 0.69% (2002 est.)
Birth rate: 1 1 .82 births/1 ,000 population (2002 est.)
Death rate: 7.49 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.61 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 0.94 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 0.98 ma!e(s)/female
65 years and over: 0.77 ma!e(s)/femate
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 9.28 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.3 years
male: 75.21 years
female: 79.27 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Bermudian (s)
adjective: Bermudian
Ethnic groups: black 58%, white 36%, other 6%
Religions: non-Anglican Protestant 39%, Anglican
27%, Roman Catholic 15%, other 19%
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
mafe:98%
femafe:99%(1970est.)','e5cf147065865d97aed57ff246f0492836dceb28a589d3a6cd9f4e55351a0b34','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2187decfdadab432de2e271b9ef3d8633ec52fed31b48949569e58815604b8b8',2002,'BT','Bhutan','people-and-society',200,'Population: 2,094,176
nofe; other estimates range as low as 810,000
(July 2002 est.)
Age structure:
0-14 years: 39.8% (male 431 ,883; female 401 ,386)
15-64 years: 56.2% (male 606,184; female 571,310)
65 years and over: 4% (male 42,1 93; female 41 ,220)
(2002 est.)
Population growth rate: 2.15% (2002 est.)
Birth rate: 35.26 births/1,000 population (2002 est.)
Death rate: 13.74 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.08 mate(s)/female
15-64 years: 1.06 mate(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.07 male(s)/female (2002 est.)
Infant mortality rate: 106.79 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 53.19 years
male: 53.53 years
female: 52.83 years (2002 est.)
Total fertility rate: 5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100(1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%
(includes Lhotsampas-one of several Nepalese
ethnic groups), indigenous or migrant tribes 15%
Religions: Lamaistic Buddhist 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.2%
male: 56.2%
female: 28.1% (1995 est.)','cc2d676af75753d66083ce844a100b9542b08f25c902e0c142291c112c31aacd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daedbcc31ec4bbcc17993a4590829ee36040ed34389e15caff1e2763e4281729',2002,'NP','Nepal','people-and-society',209,'Population: 8,445,134 (July 2002 est.)
Age structure:
0-14 years: 37.8% (mate 1 ,626,596; female
1,565,124)
15-64 years: 57.7% (male 2,383,852; female
2,491,823)
65 years and over: 4.5% (male 1 69,583; female
208,156) (2002 est.)
Population growth rate: 1.69% (2002 est.)
Birth rate: 26,41 births/1,000 population (2002 est.)
Death rate: 8.05 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.42 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1.04 ma!e(s)/fema!e
15-64 years: 0.96 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.98 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 57.52 deaths/1 ,000 live births
(2002 est, )
Life expectancy at birth:
total population: 64.42 years
male: 61 .86 years
female: 67.1 years (2002 est.)
Total fertility rate: 3.37 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,200
(1999 est.)
HIV/AIDS -deaths: 380 (1999 est.)
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, mestizo (mixed
white and Amerindian ancestry) 30%, Aymara 25%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 15 and over can read and write
total population: 83.1%
male: 90.5%
female: 76% (1995 est.)
Population: 25,873,917 (July 2002 est.)
Age structure:
0-14 years: 40% (male 5,346,422; female 5,007,41 6)
15-64 years: 56.4% (male 7,476,202; female
7,125,471)
65 years and over: 3.6% (male 453,263; female
465,143) (2002 est.)
Population growth rate: 2.29% (2002 est.)
Birth rate: 32.94 births/1 ,000 population (2002 est.)
Death rate: 10.03 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .05 male(s)/femate
65 years and over: 0.97 ma!e(s)/female
total population: 1.05 male(s)/female (2002 est.)
Infant mortality rate: 72.36 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 58.61 years
male: 59.01 years
female: 58.2 years (2002 est.)
Total fertility rate: 4.48 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 34,000
(1999 est.)
HIV/AIDS - deaths: 2,500 (1 999 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Brahman, Chetri, Newar, Gurung,
Magar, Tamang, Rai, Limbu, Sherpa, Tharu, and
others (1995)
Religions: Hinduism 86.2%, Buddhism 7.8%, Islam
3.8%, other 2.2%
note: only official Hindu state in the world (1995)
Languages: Nepali (official; spoken by 90% of the
population), about a dozen other languages and about
30 major dialects; note - many in government and
business also speak English (1995)
Literacy:
definition: age 1 5 and over can read and write
total population: 27.5%
mate: 40.9%
female: 14% (1995 est.)','3442830dbc664dab8c30c33a81a72697e8c1a010ccabb098fd5b4d4ef1f04317','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70059f631aea1631f312a22deb0e3d378f66d3f2412142787360b7b3eadd1899',2002,'PY','Paraguay','people-and-society',218,'Population: 3,964,388
note: all data dealing with population are subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2002 est.)
Age structure:
0-14years: 19.8% (male 403,391; female 382,037)
15-64 years: 70.6% (male 1,432,559; female
1,366,224)
65 years and over: 9.6% (male 1 61 ,659; female
21 8,518) (2002 est.)
Population growth rate: 0.76% (2002 est.)
Birth rate: 12.76 births/1 ,000 population (2002 est.)
Death rate: 8.1 deaths/1,000 population (2002 est.)
Net migration rate: 2.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 ma!e(s)/female
65 years and over: 0,74 male(s)/female
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 23.53 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.02 years
male: 69.3 years
female: 74.93 years (2002 est.)
Total fertility rate: 1.71 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Bosnian(s)
adjective: Bosnian
Ethnic groups: Serb 31 %, Bosniak 44%, Croat
17%, Yugoslav 5.5%, other 2.5% (1991)
note: Bosniak has replaced Muslim as an ethnic term
in part to avoid confusion with the religious term
Muslim - an adherent of Islam
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, Protestant 4%, other 10%
Languages: Croatian, Serbian, Bosnian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','e9579686ecff0332f549f9e8bd20a6ee6de982b0db3df90775ecae004753c9cc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddea4b7933962355fe954955308b61473b8b5697a46ce92d6a58a4a278515a77',2002,'IT','Italy','people-and-society',229,'Population: 1,591,232
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 40% (male 319,988; female 316,961)
15-64 years: 55.8% (male 428,638; female 458,777)
65 years and over: 4.2% (male 26,965; female
39,903) (2002 est.)
Population growth rate: 0.18% (2002 est.)
Birth rate: 28.04 births/1,000 population (2002 est.)
Death rate: 26.26 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.03 ma!e(s)/!emale
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/fema!e
65 years and oven 0,68 male(s)/female
total population: 0.95 male(s)/fema!e (2002 est.)
Infant mortality rate: 64.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 35.29 years
male: 35.1 5 years
female: 35.43 years (2002 est.)
Total fertility rate: 3.6 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 35.8%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 290,000
(1999 est.)
HIV/AIDS • deaths: 24,000 (1999 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Tswana (or Setswana) 79%,
Kalanga 11%, Basarwa 3%, other, including
Kgalagadi and white 7%
Religions: indigenous beliefs 85%, Christian 15%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total population: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Population: uninhabited (July 2002 est.)
Population: 7,301 ,994 (July 2002 est.)
Age structure:
0-14 years: 16.8% (male 629,513; female 597,472)
15-64 years: 67.7% (male 2,512,273; female
2,433,396)
65 years and over: 15.5% (male 461,722; female
667,618) (2002 est.)
Population growth rate: 0.24% (2002 est.)
Birth rate: 9.84 births/1,000 population (2002 est.)
Death rate: 8.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1.37 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 4.42 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.86 years
male: 76.98 years
female: 82.89 years (2002 est.)
Total fertility rate: 1 .47 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.46%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 17,000
(1999 est.)
HIV/AIDS -deaths: 150 (1999 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, none 8.9% (1990)
Languages: German (official) 63.7%, French
(official) 19.2%, Italian (official) 7.6%, Romansch
0.6%, other 8.9%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 17,155,814 (July 2002 est.)
note: in addition, about 40,000 people live in the
Israeli-occupied Golan Heights - 20,000 Arabs
(18,000 Druze and 2,000 Alawites) and about 20,000
Israeli settlers (August 2001 est.)
Age structure:
0-14 years: 39.3% (male 3,467,267; female
3,264,639)
15-64 years: 57.5% (male 5,052,841; female
4,817,662)
65 years and over: 3.2% (male 267,803; female
285,602) (2002 est.)
Population growth rate: 2.5% (2002 est.)
Birth rate: 30.1 1 births/1 ,000 population (2002 est.)
Death rate: 5.12 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over. 0.94 male(s)/female
total population: 1 .05 male(s)/fema!e (2002 est.)
Infant mortality rate: 32.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.08 years
male: 67.9 years
female: 70.32 years (2002 est.)
Total fertility rate: 3.84 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and
other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French,
English somewhat understood
Literacy:
definition: age 15 and over can read and write
total population: 70.8%
mate: 85.7%
female: 55.8% (1997 est.)','311054dcec7bcfc988c25cb20d1a87ee19d1309b8551e82905273179f9acb862','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fac49d94637b54b842a7e11f215b1088f96154598f61e8608bfd31fb28ba80c5',2002,'NO','Norway','people-and-society',238,'Population: 176,029,560
note: Brazil took an intercensal count in August 1996
which reported a population of 157,079,573; that
figure was about 5% lowerthan projections by the US
Census Bureau, which is close to the implied
underenumeration of 4.6% for the 1991 census;
estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can
result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates,
and changes in the distribution of population by age
and sex than would otherwise be expected
(July 2002 est.)
Age structure:
0-14 years: 28% (male 25,140,954; female
24,199,276)
15-64 years: 66.4% (male 57,424,151; female
59,409,928)
65 years and over: 5.6% (male 3,992,017; female
5,863,234) (2002 est.)
Population growth rate: 0.87% (2002 est.)
Birth rate: 18.08 births/1 ,000 population (2002 est.)
Death rate: 9.32 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/fema!e (2002 est.)
Infant mortality rate: 35.87 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.55 years
male: 59.4 years
female: 67.91 years (2002 est.)
Total fertility rate: 2.05 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS - deaths: 1 8,000 (1999 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 80%
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 15 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)
Population: 126,974,628 (July 2002 est.)
Age structure:
0-14 years: 14.5% (male 9,465,282; female
8,999,888)
15-64 years: 67.5% (male 43,027,320; female
42,586,112)
65 years and over: 18% (male 9,664,112; female
13,231,914) (2002 est.)
Population growth rate: 0.15% (2002 est.)
Birth rate: 1 0.03 births/1 ,000 population (2002 est.)
Death rate: 8.53 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.96 male(s)/femaie (2002 est.)
Infant mortality rate: 3.84 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80.91 years
ma/e: 77.73 years
female: 84.25 years (2002 est.)
Total fertility rate: 1 .42 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 10,000
(1999 est.)
HIV/AIDS -deaths: 150 (1999 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99%, others 1% (Korean
511,262, Chinese 244, 241, Brazilian 182,232, Filipino
89,851, other 237, 91 4) (2000)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99% (1970 est.)
male: NA%
female: NA%
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2002 est.)','1e798b3ef5e5bab9f4d1bd9d36121680c19be555ccacdf826586a2de1e0cab67','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9944696f9f6300153bc174d3c9f2cae5fe99815f80461e8f3ae77a674569a55',2002,'ID','Indonesia','people-and-society',245,'Population: no indigenous inhabitants
note: approximately 1 ,200 former agricultural workers
resident in the Chagos Archipelago, often referred to
as Chagossians or Hois, were relocated to Mauritius
and the Seychelles around the time of the construction
of UK-US military facilities; in 2001, there were
approximately 1 ,500 UK and US military personnel
and 2,000 civilian contractors living on the island of
Diego Garcia (July 2002 est.)
Population: 231 ,328,092 (July 2002 est.)
Age structure:
0-14 years: NA
15-64 years : NA
65 years and over: NA
Population growth rate: 1.54% (2002 est.)
Birth rate: 21.87 births/1,000 population (2002 est.)
Death rate: 6.28 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.21 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: N A
under 15 years: NA
15-64 years: NA
65 years and over: NA
total population: HA
Infant mortality rate: 39.4 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.63 years
male: 66.24 years
female: 71.13 years (2002 est.)
Total fertility rate: 2.54 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 52,000
(1999 est.)
HIV/AIDS -deaths: 3,100 (1999 est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7.5%, coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%, Roman
Catholic 3%, Hindu 2%, Buddhist 1%, other 1% (1998)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which is Javanese
Literacy:
definition: age 15 and over can read and write
total population: 83.8%
male: 89.6%
female: 78% (1995 est.)
Population: 66,622,704 (July 2002 est.)
Age structure:
0-14 years: 31.6% (male 10,753,218; female
10,273,015)
15-64 years: 63.7% (male 21,383,542; female
21,096,307)
65 years and over: 4.7% (male 1 ,633,01 6; female
1,483,606) (2002 est.)
Population growth rate: 0.77% (2002 est.)
Birth rate: 17.54 births/1,000 population (2002 est.)
Death rate: 5.39 deaths/1 ,000 population (2002 est.)
Net migration rate: -4.46 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .05 male($)/fema!e
15-64 years: 1 .01 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1.03 ma1e(s)/female (2002 est.)
Infant mortality rate: 28.07 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.25 years
male: 68.87 years
female: 71 .69 years (2002 est.)
Total fertility rate: 2.01 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azeri 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur2%, Baloch
2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population : 72.1 %
male: 78.4%
female: 65.8% (1994 est.)
Population: 135,869 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA% (2002 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Chuukese, Kosrae(s),
Pohnpeian(s), Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean,
Ulithian, Woleaian, Nukuoro, Kapingamarangi
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
Population: 84,525,639 (July 2002 est.)
Age structure:
0-14years: 36.6% (male 15,731,451; female
15,169,264)
15-64 years: 59.7% (male 24,990,500; female
25,478,245)
65 years and over: 3.7% (male 1 ,399,862; female
1,756,317) (2002 est.)
Population growth rate: 1.99% (2002 est.)
Birth rate: 26.88 births/1 ,000 population (2002 est.)
Death rate: 5.95 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/fema1e
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 27.87 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.12 years
male: 65.26 years
female: 71.12 years (2002 est.)
Total fertility rate: 3.35 children born/woman
(2002 est.)
HIV/AIDS * adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 28,000
(1999 est.)
HIV/AIDS -deaths: 1,200 (1999 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91 .5%, Muslim
Malay 4%, Chinese 1.5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: two official languages - Filipino (based
on Tagalog) and English; eight major dialects -
■Tagalog. Cebuano, llocan, Hiligaynon or llonggo,
Bicol, Waray, Pampango, and Pangasinense
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)
Population: 47 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -1.32% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 100%
Languages: English (official), Pitcairnese (mixture of
an 1 8th century English dialect and a Tahitian dialect)
Literacy: NA
Population: 4,452,732 (July 2002 est.)
Age structure:
0-14 years: 17,6% (male 404,212; female 378,660)
15-64 years: 75.3% (male 1 ,630,696; female
1,724,532)
65 years and over: 7.1% (male 137,512; female
177,120) (2002 est.)
Population growth rate: 3.46% (2002 est.)
Birth rate: 12.78 births/1 ,000 population (2002 est.)
Death rate: 4.28 deaths/1 ,000 population (2002 est.)
Net migration rate: 26.11 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 ma!e(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.95 male(s)/fema1e (2002 est.)
Infant mortality rate: 3.6 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 80,29 years
male: 77.34 years
female: 83.47 years (2002 est.)
Total fertility rate: 1 .23 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.1 9%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,000
(1999 est.)
HIV/AIDS -deaths: 210 (1999 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.7%, Malay 14%, Indian
7.9%, other 1.4%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 93.5%
male: 97%
female: 89.8% (1999)','868264046e44e7722cbc3817ac3fc7a962a4d2fc0e164c77150d591467f39d70','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35feb15f6acf27b1e836372557a4ec1167fe794faa50d901d94308e38a24967',2002,'IO','British Indian Ocean Territory','people-and-society',256,'Population: 21 ,272 (July 2002 est.)
Age structure:
0-14 years: 22.4% (male 2,401 ; female 2,351)
15-64 years: 72.7% (male 7,962; female 7,509)
65 years and over: 4.9% (male 565; female 484)
(2002 est.)
Population growth rate: 2.16% (2002 est.)
Birth rate: 15.09 births/1,000 population (2002 est.)
Death rate: 4.42 deaths/1 ,000 population (2002 est.)
Net migration rate: 10.91 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.04 mate(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1.17 male(s)/female
total population: 1 .06 male(s)/female (2002 est.)
Infant mortality rate: 19.55 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population : 75.85 years
male: 74.9 years
female: 76.84 years (2002 est.)
Total fertility rate: 1.72 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 83%, white, Indian, Asian and
mixed
Religions: Protestant 86% (Methodist 33%, Anglican
17%, Church of God 9%, Seventh-Day Adventist 6%,
Baptist 4%, Jehovah''s Witnesses 2%, other 2%),
Roman Catholic 10%, none 2%, other2% (1991)
Languages: English (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 97.8% (1991 est.)
male: NA%
female: NA%
Population: 350,898 (July 2002 est.)
Age structure:
0-14 years: 30.2% (male 54,038; female 51 ,833)
15-64 years : 67% (male 125,051; female 1 10,257)
65 years and over: 2.8% (male 4,609; female 5,110)
(2002 est.)
Population growth rate: 2.06% (2002 est.)
Birth rate: 20.06 births/1 ,000 population (2002 est.)
Death rate: 3.38 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.91 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 ma!e(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.13 ma!e(s)/female
65 years and over: 0.9 male(s)/female
total population: 1,1 ma!e(s)/female (2002 est.)
Infant mortality rate: 1 3.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74,06 years
male: 71.68 years
female: 76.56 years (2002 est.)
Total fertility rate: 2.4 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIOS - deaths: NA
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 67%, Chinese 15%,
indigenous 6%, other 12%
Religions: Muslim (official) 67%, Buddhist 13%,
Christian 10%, indigenous beliefs and other 10%
Languages: Malay (official), English, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)
Country name:
conventional tong form: Negara Brunei Darussalam
conventional short form: Brunei
Government type: constitutional sultanate
Capital: Bandar Seri Begawan
Administrative divisions: 4 districts
(daerah-daerah, singular • daerah); Belait, Brunei and
Muara, Temburong, Tutong
Independence: 1 January 1984 (from UK)
National holiday: National Day, 23 February (1984);
note - 1 January 1984 was the date of independence
from the UK, 23 February 1984 was the date of
independence from British protection
Constitution: 29 September 1959 (some provisions
suspended under a State of Emergency since
December 1962, others since Independence on
1 January 1984)
Legal system: based on English common law; for
Muslims, Islamic Shari''a law supersedes civil law in a
number of areas
Suffrage: none
Executive branch:
chief of state: Sultan and Prime Minister Sir
HASSANAL Bolkiah (since 5 October 1967); note -
the monarch is both the chief of state and head of','1d62abccb69c0d185c164f56385f0662a8a16c0d2ff235c8f0b1095e73d4cd83','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc3824eb697b4484a3f48016b18eb3fb53be604d498c405bb12e0c2b233fcf37',2002,'BG','Bulgaria','people-and-society',259,'Population: 7,621,337 (July 2002 est.)
Age structure:
0-14 years: 14.6% (male 572,961 ; female 543,004)
15-64 years: 68.5% (male 2,569,199; female
2,648,461)
65 years and over: 1 6.9% (male 540,109; female
747,603) (2002 est.)
Population growth rate: -1.11 % (2002 est.)
Birth rate: 8.05 births/1,000 population (2002 est.)
Death rate: 14,42 deaths/1 ,000 population
(2002 est.)
Net migration rate: -4.74 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/fema!e
under 15 years: 1.06 ma!e(s)/female
15-64 years: 0.97 ma!e(s)/female
65 years and over : 0.72 male(s)/female
total population: 0.94 male(s)/fema!e (2002 est.)
Infant mortality rate: 14.18 deaths/1,000 live births
(2002 est.)
78
Bulgaria (continued)
Life expectancy at birth:
total population: 71 .5 years
male: 67.98 years
female: 75.22 years (2002 est.)
Total fertility rate: 1.13 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 346
(2000)
HIV/AIDS - deaths: less than 1 00 (1999 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 83.6%, Turk 9.5%, Roma
4.6%, other 2.3% (including Macedonian, Armenian,
Tatar, Circassian) (1998)
Religions: Bulgarian Orthodox 83.8%, Muslim
12.1%, Roman Catholic 1 .7%, Jewish 0.8%,
Protestant, Gregorian-Armenian, and other 1.6%
(1998)
Languages: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 98% (1999)
Population: 12,603,185
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.3% (male 3,007,675; female
2,960,697)
15-64 years: 49.8% (male 3,000,411; female
3,271,594)
65 years and over: 2.9% (mate 151,976; female
210,832) (2002 est.)
Population growth rate: 2.64% (2002 est.)
Birth rate: 44.34 births/1,000 population (2002 est.)
Death rate: 17.07 deaths/1,000 population
(2002 est.)
Net migration rate: -0.84 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 105.3 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 46.11 years
male: 45.45 years
female: 46.78 years (2002 est.)
Total fertility rate: 6.26 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 6.44%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 350,000
(1999 est.)
HIV/AIDS - deaths: 43,000 (1999 est.)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi over 40%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%,
Chrisfian (mainly Roman Catholic) 10%
Languages: French (official), native African
languages belonging to Sudanic family spoken by
90% of the population
Literacy:
definition: age 1 5 and over can read and write
total population: 36% (2001)
male: NA%
female: NA%','8ca89007ae13e60a5ff08a00e77e565f088e2639d85668f887663f70026802d6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0bd02ff2b3cb33f323712e6812d7415c02e9c0898359ea4bb3ef2a412ef752c',2002,'ET','Ethiopia','people-and-society',272,'Population: 42,238,224
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 28.6% (male 6,1 58,039; female
5,905,314)
15-64 years: 66.6% (male 13,976,047; female
14,162,467)
65 years and over: 4.8% (male 905,476; female
1,130,881) (2002 est.)
Population growth rate: 0.56% (2002 est.)
Birth rate: 19.65 births/1 ,000 population (2002 est.)
83
Burma (continued)
Death rate: 1 2.25 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1.83 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.8 male(s)/female
lota! population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 72.1 1 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 55.41 years
male: 53.85 years
female: 57.07 years (2002 est.)
Total fertility rate: 2.23 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 530,000
(1999 est.)
HIV/AIDS - deaths: 48,000 (1999 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Indian 2%, Mon 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist 1%, other
2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 15 and over can read and write
total population: 83.1%
male: 88.7%
female: 77. 7% (1995 est.)
note: these are official statistics; estimates of
functional literacy are likely closer to 30% (1 999 est.)
Population: 67,673,031
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 16,098,191; female
15,879,065)
15-64 years: 50% (male 17,005,387; female
16,801,536)
65 years and over: 2.8% (male 854,023; female
1,034,829) (2002 est.)
Population growth rate: 2.64% (2002 est.)
Birthrate: 44.31 births/1 ,000 population (2002 est.)
Death rate: 1 8.04 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.11 migrant(s)/1 ,000
population
note: repatriation of Ethiopians who fled to Sudan for
refuge from war and famine in earlier years is
expected to continue for several years; some
Sudanese and Somali refugees, who fled to Ethiopia
from the fighting or famine in their own countries,
continue to return to their homes (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .01 male(s)/female (2002 est.)
Infant mortality rate: 98.63 deaths/1 ,000 live births
(2002 est.)
167
Ethiopia (continued)
Life expectancy at birth:
total population: 44.21 years
male: 43.36 years
female: 45.09 years (2002 est.)
Total fertility rate: 6.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 0.63%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3 million
(1999 est.)
HIV/AIDS - deaths: 280.000 (1999 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigre
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Oromigna,
Guaragigna, Somali, Arabic, other local languages,
English (major foreign language taught in schools)
Literacy:
definition: age 1 5 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)
Population: no indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)','db9a215002ea29acb86d21d4a5cd8d8e0ecf89b44405a0706af1bb0e4baae181','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a12be96a0bf9c29bade9a9669c1f1914604496090a006ff314bc8b505dda80',2002,'TH','Thailand','people-and-society',281,'Population: 6,373,002
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 46.5% (male 1 ,497,865; female
1,466,455)
15-64 years: 50.7% (male 1,592,253; female
1,640,254)
65 years and over: 2.8% (male 71 ,91 5; female
104,260) (2002 est.)
Population growth rate: 2.36% (2002 est.)
Birth rate: 39.87 births/1,000 population (2002 est.)
Death rate: 16.3 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years'': 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 69.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 45.94 years
male: 45.08 years
female: 46.83 years (2002 est.)
Total fertility rate: 6.07 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 1 1 .32%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 360,000
(1999 est.)
HIV/AIDS • deaths: 39,000 (1999 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 23%, Muslim 10%
Languages: Kirundi (official), French (official),
Swahili (along Lake T anganyika and in the Bujumbura
area)
Literacy:
definition: age 1 5 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
Population: 5,777,180 (July 2002 est.)
Age structure:
0-14 years: 42.5% (male 1,233,659; female
1,219,872)
15-64 years: 54.2% (male 1 ,543,246; female
1,591,419)
65 years and over: 3.3% (male 86,375; female
102,609) (2002 est.)
Population growth rate: 2.47% (2002 est.)
Birth rate: 37.39 births/1 ,000 population (2002 est.)
Death rate: 12.71 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 mate(s)/female
15-64 years: 0.97 mate(s)/fema!e
65 years and oven 0.84 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 90.98 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 53.88 years
male: 51 .95 years
female: 55.87 years (2002 est.)
Total fertility rate: 5.03 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,400
(1999 est.)
HIV/AIDS -deaths: 130 (1999 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong (“Meo'') and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
(including various Christian denominations 1.5%)
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
total population: 57%
male: 70%
female: 44% (1999 est.)
Population: 62,354,402
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 23.3% (male 7,404,227; female
7,121,083)
15-64 years: 69.9% (male 21 ,469,186; female
22,090,520)
65 years and over: 6.8% (male 1 ,868,632; female
2,400,754) (2002 est.)
Population growth rate: 0.88% (2002 est.) ''
Birth rate: 16.39 births/1 ,000 population (2002 est.)
Death rate: 7.55 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 0.97 ma!e(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 29.5 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69. 1 8 years
male: 66 years
female: 72.51 years (2002 est.)
Total fertility rate: 1 .86 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 755,000
(1999 est.)
HIV/AIDS - deaths: 66,000 (1999 est.)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 1 1 %
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 93.8%
male: 96%
female: 91 ,6% (1995 est.)
Population: 5,285,501
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 45.1% (male 1,195,052; female
1,187,014)
15-64 years: 52.4% (male 1 ,351 ,345; female
1,420,617)
65 years and over: 2.5% (male 56,270; female
75,203) (2002 est.)
Population growth rate: 2.48% (2002 est.)
Birth rate: 36,1 1 births/1 ,000 population (2002 est.)
Death rate: 11.3 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
508
Togo (continued)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 ma!e(s)/female
15-64 years: 0,95 ma!e(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/fema!e (2002 est.)
Infant mortality rate: 69.32 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 54.02 years
male: 52.03 years
female: 56.07 years (2002 est.)
Total fertility rate: 5.14 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5.98%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 14,000 (1999 est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 51%, Christian 29%,
Muslim 20%
Languages: French (official and the language of
commerce), Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
male: 67%
fema/e; 37% (1995 est.)','90adec70227b5918a39fe440c8bad4a359a00517e4220121edddc0e5f85569c6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a69d3965ccbc9e6559a2dcecfbba01cbed423e432774a791a9dcf2cc54c4ce1',2002,'KH','Cambodia','people-and-society',285,'Population: 12,775,324
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 40.7% (male 2,646,883; female
2,550,015)
15-64 years: 55.8% (male 3,373,692; female
3,758,736)
65 years and over: 3.5% (male 182,149; female
263,849) (2002 est.)
Population growth rate: 2.24% (2002 est.)
Birth rate: 32.93 births/1,000 population (2002 est.)
Death rate: 10.51 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.9 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 male(s)/fema!e (2002 est.)
88
Cambodia (continued)
Infant mortality rate: 64 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 57 .1 years
male: 54.81 years
female: 59.5 years (2002 est.)
Total fertility rate: 4.66 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 4.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 220,000
(1999 est.)
HIV/AIDS • deaths: 14,000 (1999 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhist 95%, other 5%
Languages: Khmer (official) 95%, French, English
Literacy:
definition: age 1 5 and over can read and write
total population: 35%
male: 48%
female: 22% (1990 est.)
Population: 16,184,748
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 42.1% (male 3,443,505; female
3,367,571)
15-64 years: 54.5% (male 4,431,524; female
4,392,155)
65 years and over: 3.4% (male 253,242; female
296,751) (2002 est.)
Population growth rate: 2.36% (2002 est.)
Birth rate: 35.66 births/1,000 population (2002 est.)
Death rate: 1 2.08 deaths/1 ,000 population
(2002 est.)
Net migration rate: NA migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 68.79 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 54.36 years
male: 53.51 years
female: 55.23 years (2002 est.)
Total fertility rate: 4.72 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 7.73%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 540,000
(1999 est.)
HIV/AIDS - deaths: 52,000 (1999 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 1 5 and over can read and write
" total population: 63.4%
male: 75%
fe/rtafe: 52.1 % (1 995 est.)','5ef786c68cd27bd4f1e60dae9edc94250ba9a9034760bb9cb6e7e05a3c3b5c59','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99cb54838c9aff95492ee0de624779b04cdbeca6f85056549ced66006867edb4',2002,'US','United States','people-and-society',296,'Population: 31,902,268 (July 2002 est.)
Age structure:
0-14 years: 18.7% (male 3,059,023; female
2,910,203)
15-64 years: 68.4% (male 10,975,701; female
10,857,869)
65 years and over: 1 2.9% (male 1 ,743,654; female
2,355,818) (2002 est.)
Population growth rate: 0.96% (2002 est )
Birth rate: 1 1 .09 births/1 ,000 population (2002 est.)
Death rate: 7.54 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 4.95 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.69 years
mate: 76.3 years
lemale: 83.25 years (2002 est.)
Total fertility rate: 1 .6 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.3% (1999 est.)
HIV/AIDS • people living with HIV/AIDS: 49,000
(1999 est.)
HIV/AIDS -deaths: 400 (1999 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 28%, French
origin 23%, other European 15%, Amerindian 2%,
other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions: Roman Catholic 46%, Protestant 36%,
other 18%
note: based on the 1991 census
Languages: English 59.3% (official), French 23.2%
(official), other 17.5%
Literacy:
definition: age 15 and over can read and write
total population: 97% (1986 est.)
mate: NA%
female: NA%
Population: 408,760 (July 2002 est.)
Age structure:
0-14 years: 41. 9% (male 86,466; female 84,918)
15-64 years: 51 .5% (male 100,684; female 109,841)
65 years and over: 6.6% (male 10,363; female
16,488) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 27.81 births/1,000 population (2002 est.)
Death rate: 7.01 deaths/1 ,000 population (2002 est.)
Net migration rate: -12.26 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/femate
under 15 years: 1 .02 ma!e(s)/female
15-64 years : 0.92 ma!e(s)/female
65 years and over: 0.63 mate(s)/fema!e
total population: 0,94 ma!e(s)/female (2002 est.)
Infant mortality rate: 51 .86 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.52 years
male: 66.23 years
female: 72.91 years (2002 est.)
Total fertility rate: 3.91 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 775
(2001)
HIV/AIDS -deaths: 225 (as of 2001)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of
Portuguese and West African words)
Literacy:
definition: age 15 and over can read and write
total population: 71. 6%
male: 81.4%
female: 63.8% (1995 est.)
Population: 280,562,489 (July 2002 est.)
Age structure:
0-14 years: 21% (male 30,116,782; female
28,765,183)
15-64 years: 66.4% (male 92.391,120; female
93,986,468)
65 years and over: 12.6% (male 14,748,522; female
20,554,414) (2002 est.)
Population growth rate: 0.89% (2002 est.)
Birth rate: 14.1 births/1 ,000 population (2002 est.)
Death rate: 8.7 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.5 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 6.69 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.4 years
male: 74.5 years
female: 80.2 years (2002 est.)
Total fertility rate: 2.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.61%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 850,000
(1999 est.)
HIV/AIDS - deaths: 20,000 (1999 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 77.1%, black 12.9%, Asian
4.2%, Amerindian and Alaska native 1.5%, native
Hawaiian and other Pacific islander 0.3%, other 4%
(2000)
note: a separate listing for Hispanic is not included
because the US Census Bureau considers Hispanic
to mean a person of Latin American descent
United States (continued)
(especially of Cuban, Mexican, or Puerto Rican origin)
living in the US who may be of any race or ethnic
group (white, black, Asian, etc.)
Religions: Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
Literacy:
definition: age 15 and over can read and write
total population: 97%
wale: 97%
female: 97% (1979 est.)
People - note:
note: data for the US are based on projections that do
not take into consideration the results of the 2000
census','c7484ab2ee48c6d65581471c229aa038204d5b8380323ab0c57f4f59e10261a9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20d7246060b0bf51b99bd3d333058208bd1a4e4fac11ad1e2010f0e0a6d378ca',2002,'HN','Honduras','people-and-society',312,'Population: 36,273 (July 2002 est.)
Age structure:
0-14 years: 22% (male 3,836; female 4,156)
15-64 years: 69.7% (male 12,335; female 12,929)
65 years and over : 8.3% (male 1 ,399; female 1 ,61 8)
(2002 est.)
Population growth rate: 2.03% (2002 est.)
Birth rate: 13.45 births/1,000 population (2002 est.)
Death rate: 5.24 deaths/1 ,000 population (2002 est.)
Net migration rate: 12.08 migrant(s)/1,000
population
note: major destination for Cubans trying to migrate to
the US (2002 est.)
Sex ratio:
at birth: 0.86 male(sj/female
under 15 years: 0.92 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.86 mate(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 9.89 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.18 years
male: 76.38 years
female: 81 .59 years (2002 est.)
Total fertility rate: 2.03 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Church of God,
other Protestant, Roman Catholic
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 3,642,739
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 43% (male 788,417; female 776,721)
15-64 years: 53.2% (male 951,908; female 986,947)
65 years and over: 3.8% (male 60,395; female
78,351) (2002 est.)
Population growth rate: 1 .8% (2002 est.)
Birth rate: 36.6 births/1 ,000 population (2002 est.)
Death rate: 18.62 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 ma1e(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/fema!e
65 years and over: 0.77 male(s)/female
total population: 0.98 male(s)/fema!e (2002 est.)
Infant mortality rate: 103.81 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 43.58 years
male: 42.08 years
female: 45. 13 years (2002 est.)
Total fertility rate: 4.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 3.84%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS • deaths: 23,000 (1999 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 33%, Banda 27%, Mandjia
13%, Sara 10%, Mboum 7%, M''Baka 4%, Yakoma
4%, other 2%
Religions: indigenous beliefs 35%, Protestant 25%,
Roman Catholic 25%, Muslim 15%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), tribal languages
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 68.5%
female: 52.4% (1 995 est.)
Population: 8,997,237 (July 2002 est.)
Age structure:
0-14 years: 47.8% (male 2,162,732; female
2,135,354)
15-64 years: 49.4% (male 2,108,134; female
2,340,189)
65 years and oven 2.8% (male 103,683; female
147,145) (2002 est.)
Population growth rate: 3.27% (2002 est.)
Birth rate: 47.74 births/1,000 population (2002 est.)
Death rate: 15.06 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 ma!e(s)/female
65 years and over. 0.7 ma1e(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 93.46 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .27 years
male: 49.22 years
female: 53.4 years (2002 est.)
Total fertility rate: 6.5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5%-7% (2001)
HIV/AIDS - people living with HIV/AIDS: 300,000
(2001)
HIV/AIDS - deaths: 14,000 (confirmed AIDS cases,
actual number far higher but difficult to estimate)
(2001)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: 200 distinct groups; in the north and
center: Arabs, Gorane (Toubou, Daza, Kreda),
Zaghawa, Kanembou, Ouaddai, Baguirmi, Hadjerai,
Fulbe, Kotoko, Hausa, Boulala, and Maba, most of
whom are Muslim; in the south: Sara (Ngambaye,
Mbaye, Goulaye), Moundang, Moussei, Massa, most
of whom are Christian or animist; about 1 ,000 French
citizens live in Chad
Religions: Muslim 51%, Christian 35%, animist 7%,
other 7%
Languages: French (official), Arabic (official). Sara
(in south), more than 120 different languages and
dialects
Literacy:
definition: age 15 and over can read and write French
or Arabic
total population: 40%
male: 49%
femate: 31% (1998)
Population: 1 5,498,930 (July 2002 est.)
Age structure:
0-14 years: 26.9% (male 2,127,696; female
2,033,201)
15-64 years: 65.6% (male 5,070,476; female
5,103,490)
65 years and over: 7.5% (male 482,846; female
681,221) (2002 est.)
Population growth rate: 1 .09% (2002 est.)
Birth rate: 16.46 births/1,000 population (2002 est.)
Death rate: 5.59 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
104
Chile (continued)
Sex ratio:
at birth: 1. 05 ma!e(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male{s)/female
total population: 0.98 male{s)/female (2002 est.)
Infant mortality rate: 9.12 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.1 4 years
male: 72.83 years
female: 79.62 years (2002 est.)
Total fertility rate: 2.13 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est.)
HIV/AIDS -deaths: 1,000 (1999 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 1 1 %,
Jewish NEGL%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 95.2%
mate: 95.4%
female: 95% (1995 est.)
Population: 6,560,608
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 41.8% (male 1,400,778; female
1,340,834)
15-64 years: 54.6% (male 1,774,619; female
1,806,568)
65 years and over: 3.6% (male 1 1 2, 1 00; female
125,709) (2002 est.)
Population growth rate: 2.34% (2002 est.)
Birthrate: 31.21 births/1 ,000 population (2002 est.)
Death rate: 5.74 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/fema1e
under 15 years: 1 .04 ma1e(s)/female
15-64 years: 0.98 ma!e(s)/female
65 years and over: 0.89 ma!e(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 30.48 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.77 years
mate: 67 .11 years
female: 70.51 years (2002 est.)
Total fertility rate: 4.03 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 1 .92%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 63,000
(1999 est.)
HIV/AIDS - deaths: 4,200 (1999 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 74%
mate: 74%
female: 74.1% (1999)','4d0b467f27b99e84a59acde7bf6e2290f4481d8ed95007bcf04cf56aaaae23b0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1585ef176c2c12b40263d66e101b1bfe512ba425f775b017a7e7a7bd6e602ba',2002,'CN','China','people-and-society',322,'Population: 1 ,284,303,705 (July 2002 est.)
Age structure:
0-14 years: 24.3% (male 163,821,081; female
148,855,387)
15-64 years: 68.4% (male 452,354,428; female
426,055,713)
65 years and over: 7.3% (male 43,834,528; female
49,382,568) (2002 est.)
Population growth rate: 0.87% (2002 est.)
Birth rate: 15.85 births/1,000 population (2002 est.)
Death rate: 6.77 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.38 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 27.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth;
total population: 71 .86 years
male: 70.02 years
female: 73.86 years (2002 est.)
Total fertility rate: 1 .82 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.2%
(2000-01 est.)
HIV/AIDS - people living with HIV/AIDS: 1.25
million (January 2001)
HIV/AIDS - deaths: 1 7,000 (1999 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 ,9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoist (Taoist), Buddhist, Muslim
1%-2%, Christian 3%-4%
note: officially atheist (2002 est.)
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic groups entry)
Literacy:
definition: age 15 and over can read and write
total population: 81 .5%
male: 89.9%
female: 72.7% (1995 est.)
Population: 7,303,334 (July 2002 est.)
Age structure:
0-14 years: 17.5% (male 679,311; female 599,811)
15-64 years: 71.6% (male 2,587,509; female
2,641,418)
65 years and over: 1 0.9% (male 364,864 ; female
430,421) (2002 est.)
Population growth rate: 1.26% (2002 est.)
Birth rate: 10.92 births/1 ,000 population (2002 est.)
Death rate: 6.1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: 7.76 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 5.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.8 years
male: 77.1 years
female: 82.69 years (2002 est.)
Total fertility rate: 1.3 children bom/woman
(2002 est.) i
HIV/AIDS - adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English; both are
official
Literacy:
definition: age 1 5 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)
232
Hong Kong (continued)
Population: no indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)','fd94ead77c635174f350a1e990124104d5e6b210da574b64062a671065329a77','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55e5c321f54367c3f77374dafab596037d23fb73a329849e79f4ced90d28a386',2002,'CX','Christmas Island','people-and-society',331,'Population: 474 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -9% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Christmas Istander(s)
adjective: Christmas Island
Ethnic groups: Chinese 70%, European 20%,
Malay 10%
note: no indigenous population (2001)
Religions: Buddhist 36%, Muslim 25%, Christian
18%, other 21% (1997)
Languages: English (official), Chinese, Malay
Literacy: NA','e9a84b403303eebaba68941338a6e2e8606a12a2ceb9a1121036864610b71f45','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb3d195cdd9f202876fbc7294d8cfba661aac0dbfbc586f37331c5adaaedc85',2002,'FR','France','people-and-society',338,'Population: 632 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -0.22% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 80%, other 20% (2002 est.)
Languages: Malay (Cocos dialect), English
Population: 2,967 (July 2002 est.)
Age structure:
0-f4years:NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 2.44% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Population: no indigenous inhabitants (July
2002 est.)
note: in 1 997, there were about 1 00 researchers
whose numbers vary from winter (July) to summer
(January)
Population: 2,694,432 (July 2002 est.)
Age structure:
0-14 years: 32% (male 438,176; female 422,960)
15-64 years: 64,1% (male 864,033; female 865,172)
65 years and over: 3.9% (male 45,080; female
59,011) (2002 est.)
Population growth rate: 1 .48% (2002 est.)
Birth rate: 21 .8 births/1 ,000 population (2002 est.)
Death rate: 7.01 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 51 .97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.62 years
male: 62.47 years
female: 66.87 years (2002 est.)
Total fertility rate: 2.37 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol (predominantly Khalkha)
85%, Turkic (of which Kazakh is the largest group)
7%, Tungusic 4.6%, other (including Chinese and
Russian) 3.4% (1998)
Religions: Tibetan Buddhist Lamaism 96%, Muslim
(primarily in the southwest), Shamanism, and
Christian 4% (1998)
Languages: Khalkha Mongol 90%, Turkic, Russian
(1999)
Literacy:
definition: age 1 5 and over can read and write
total population: 97.8%
male: 98%
female: 97.5% (2000)
Population: 9,81 5,644 (July 2002 est.)
Age structure:
0-14 years: 27.8% (male 1,412,625; female
1,320,729)
15-64 years: 65.9% (male 3,234,770; female
3,233,149)
65 years and over: 6.3% (male 303,093; female
31 1,278) (2002 est.)
Population growth rate: 1.12% (2002 est.)
Birth rate: 16.83 births/1,000 population (2002 est.)
Death rate: 5 deaths/1,000 population (2002 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 27.97 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.1 6 years
male: 72.56 years
female: 75.89 years (2002 est.)
Total fertility rate: 1.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages ol commerce), French (commerce)
Literacy:
definition: age 15 and over can read and write
total population: 66.7%
male: 78.6%
female: 54.6% (1995 est.)
Population: 67,308,928 (July 2002 est.)
Age structure:
0 - 14 years ; 27.8% (male 9,520,030; female
9,178,423)
15-64 years: 65.9% (male 22,552,253; female
21,827,002)
65 years and over: 6.3% (male 1 ,946,523; female
2,284,697) (2002 est.)
Population growth rate: 1.2% (2002 est.)
Birth rate: 17.95 births/1,000 population (2002 est.)
Death rate: 5.95 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at bidh: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 45.77 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .52 years
male: 69.1 5 years
female: 74.01 years (2002 est.)
Total fertility rate: 2.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Turk(s)
adjective .''Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(mostly Christians and Jews)
Languages: Turkish (official), Kurdish, Arabic,
Armenian, Greek
Literacy:
definition: age 1 5 and over can read and write
total population: 85%
mate: 94%
female: 77% (2000)
Population: 2,163,667 (July 2002 est.)
note: in addition, there are about 182,000 Israeli
settlers in the West Bank and about 176,000 in East
Jerusalem (August 2001 est.)
Age structure:
0-14 years: 44,4% (male 492,446; female 468,321)
15-64 years: 52% (male 575,282; female 550,793)
65 years and over: 3.6% (male 33,1 63; female
43,662) (2002 est.)
Population growth rate: 3.39% (2002 est.)
Birth rate: 34.94 births/1,000 population (2002 est.)
Death rate: 4.26 deaths/1 ,000 population (2002 est.)
Net migration rate: 3. 18 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/fema!e
65 years and over: 0.76 male(s)/female
total population: 1.04 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 21 .24 deaths/1 .000 live births
(2002 est.)
Life expectancy at birth:
total population: 72 .47 years
male: 70.76 years
female: 74.29 years (2002 est.)
Total fertility rate: 4.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','b0f9225d1327cea0e22f8bda00ea408680ccb89d2d04954c3464306ef775942b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0937ac95f7defc1175c64a09b5a32454a64c00368caeeff5ef0050ef828982',2002,'CO','Colombia','people-and-society',348,'Population: 41 ,008,227 (July 2002 est.)
Age structure:
0-14 years: 31 .6% (male 6,552,961 ; female
6,399,666)
15-64 years: 63.6% (male 12,694,293; female
13,375,425)
65 years and over: 4.8% (male 886,921 ; female
1,098,961) (2002 est.)
Population growth rate: 1 .6% (2002 est.)
Birth rate: 21.99 births/1,000 population (2002 est.)
Death rate: 5.66 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 ma!e(s)/female (2002 est.)
113
Colombia (continued)
Infant mortality rate: 23.21 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.85 years
male: 67 years
female: 74.83 years (2002 est.)
Total fertility rate: 2.64 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.31%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 71 ,000
(1999 est.)
HIV/AIDS -deaths: 1,700 (1999 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 90%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 91.3%
mate: 91. 2%
female: 91.4% (1995 est.)','9199cd6dab515ee1717cf1f7e6aaab0be99b2c5b886703db71d8c30a302fe254','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37fb388bfd3fd2ebf3022899eca2446f4bf8b71978e29445ef0aac47f0553f5c',2002,'MZ','Mozambique','people-and-society',359,'Population: 614,382 (July 2002 est.)
Age structure:
0- 14 years: 42.9% (male 1 32,01 3; female 131 ,282)
15-64 years: 54,2% (male 164,245; female 168,793)
65 years and over: 2,9% (male 8,588; female 9,461 )
(2002 est.)
Population growth rate: 2.99% (2002 est.)
Birth rate: 39.01 births/1,000 population (2002 est.)
Death rate: 9.1 deaths/1,000 population (2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 ma!e(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 81 .79 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60,79 years
male: 58.56 years
female: 63,09 years (2002 est.)
Total fertility rate: 5.26 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 98%, Roman Catholic 2%
Languages: Arabic (official), French (official),
Shikomoro (a blend of Swahili and Arabic)
Literacy:
definition: age 1 5 and over can read and write
total population: 57.3%
mate: 64.2%
female: 50.4% (1995 est.)
Population: 55,225,478
nofe: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 48.2% (male 13,369,493; female
13,256,174)
15-64 years: 49.3% (male 13,343,303: female
13,860,996)
118
Congo, Democratic Republic of the (continued)
65 years and over: 2.5% (male 581 ,568; female
813,944) (2002 est.)
Population growth rate: 2.79% (2002 est.)
Birth rate: 45.55 births/1,000 population (2002 est.)
Death rate: 14.93 deaths/1 ,000 population
(2002 est.)
Net migration rate: -2.75 migrant(s)/1 ,000
population
note: one million refugees fled into Zaire (now called
the Democratic Republic of the Congo or DROC) in
1994 as a result of the ethnic fighting in Rwanda;
fighting in the DROC between rebels and government
forces in October 1996 caused 875,000 refugees to
return to Rwanda in late 1996 and early 1997 and
additional refugees have returned in subsequent
years; fighting between the Congolese government
and Uganda- and Rwanda-backed Congolese rebels
spawned a regional war in DROC in August 1998,
which left 1.8 million Congolese displaced in DROC
and caused 300,000 Congolese refugees to flee to
surrounding countries (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 98.05 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49. 1 3 years
male: 47.19 years
female: 51 .1 3 years (2002 est.)
Total fertility rate: 6.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1.1
million (1999 est.)
HIV/AIDS - deaths: 95,000 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and indigenous beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 1 5 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 77. 3%
male: 86.6%
fema/e: 67.7% (1995 est.)
Population: 19,607,519
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected; the 1997 Mozambican census reported a
population of 16,099,246 (July 2002 est.)
Age structure:
0-14 years: 42.5% (male 4,162,413; female
4,176,295)
15-64 years: 54.7% (male 5,313,51 1 ; female
5,407,052)
65 years and over: 2.8% (male 227,761 ; female
320,487) (2002 est.)
Population growth rate: 1 .13% (2002 est.)
Birth rate: 36.41 births/1,000 population (2002 est.)
Death rate: 25.13 deaths/1 ,000 population
(2002 est.)
357
Mozambique (continued)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.03 ma!e(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 138.55 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 35.46 years
male: 36.25 years
female: 34.65 years (2002 est.)
Total fertility rate: 4.71 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 12.6 to 16.4%,
estimates vary (2001)
HIV/AIDS - people living with HiV/AIDS:
1,546,643(2001)
HIV/AIDS -deaths: 114,111 (2001 est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Shangaan, Chokwe, Manyika, Sena, Makua. and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 42.3%
male: 58.4%
fema/e: 27% (1998 est.)
Population: 22,548,009 (July 2002 est.)
Age structure:
0-14 years: 21% (male 2,464,290; female 2,268,627)
15-64 years: 70% (male 8,01 0,01 4; female
7,774,296)
65 years and over: 9% (male 1 ,053,975; female
976,807) (2002 est.)
Population growth rate: 0.78% (2002 est.)
Birth rate: 14.21 births/1,000 population (2002 est.)
Death rate: 6.08 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.3 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.08 male(s)/female
under 15 years: 1,09 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 1 .08 mate(s)/fema!e
total population: 1 .05 male(s)/fema!e (2002 est.)
Infant mortality rate: 6.8 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.74 years
male: 73.99 years
female: 79.71 years (2002 est.)
Total fertility rate: 1.76 children born/woman
(2002 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
Literacy:
definition: age 15 and over can read and write
total population: 86% (1980 est.)
male: 93% (1980 est.)
female: 79% (1980 est.)
note: literacy for the total population has reportedly
increased to 94% (1998 est.)','18ebb98605bebee108b3248e8cadff771b114abd9a549e93b2eb18059323f25c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2e27a4f06acc3428902b7e5ca482e5438a9585edeebad1fabd1cb71902c2d92',2002,'CG','Congo','people-and-society',374,'Population: 2,958,448
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 4 2.4% (male 630,985; female 622,024)
15-64 years: 54.3% (male 783,238; female 823,882)
65 years and over: 3.3% (male 39,369; female
58,950) (2002 est.)
Population growth rate: 2.18% (2002 est.)
Birth rate: 37.91 birlhs/1 ,000 population (2002 est.)
Death rate: 16.1 deaths/1,000 population (2002 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 97.91 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47.71 years
male: 44.27 years
female: 51.24 years (2002 est.)
Total fertility rate: 4.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 6.43%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 86,000
(1999 est.)
HIWAIDS - deaths: 8,600 (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M’Bochi
note: Europeans estimated at 8,500, mostly French,
before the 1997 civil war; may be half that in 1998,
following the widespread destruction of foreign
businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 15 and over can read and write
total population: 74.9%
male: 83.1%
female: 67.2% (1995 est.)','379d5e71808cc519bd9e1a969a4599b83f98349e3360f5cc3a0833c39e8b1e31','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee0ca4492729f22b85173fb95b8897fa7a966ce37b3c6c081bc257516b5ea829',2002,'CK','Cook Islands','people-and-society',378,'Population: 20,81 1 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81 .3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0.9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','fdb8efd46bd0bf0720e7f8aa74ac7b58eb4cfc75e1e71ae79aa4276aeb79309e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('996484dbb065703a052bad5c7d12b2e68fd87c3fa7576b6ae6e2b86bafef313c',2002,'CR','Costa Rica','people-and-society',386,'Population: 3,834,934 (July 2002 est.)
Age structure:
0-14 years: 30.8% (male 603,270; female 575,766)
15-64 years: 63.9% (male 1 ,239,618; female
1,211,641)
65 years and over: 5.3% (male 95,182; female
109,457) (2002 est.)
Population growth rate: 1.61% (2002 est.)
Birth rate: 19.83 births/1,000 population (2002 est.)
Death rate: 4.31 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.52 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/fema!e
under 15 years : 1 .05 male(s)/(emale
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.87 male(s)/female
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 10.87 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.22 years
male: 73.68 years
female: 78.89 years (2002 est.)
Total fertility rate: 2.42 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.54%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: 12,000
(1999 est.)
HIV/AIDS -deaths: 750 (1999 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white (including mestizo) 94%, black
3%, Amerindian 1%, Chinese 1%, other 1%
Religions: Roman Catholic 76.3%, Evangelical
13.7%, other Protestant 0.7%, Jehovah’s Witnesses
1 .3%, other 4.8%, none 3.2%
Languages: Spanish (official). English spoken
around Puerto Limon
Literacy:
definition: age 15 and over can read and write
total population: 95.5%
male: 95.5%
fema/e: 95.5% (1999 est.)
Population: 10,639,744 (July 2002 est.)
Age structure:
0-14 years: 47.9% (male 2,594,932; female
2,503,867)
15-64 years: 49.8% (male 2,594,307; female
2,706,164)
65 years and over: 2.3% (male 1 25,898; female
11 4,576) (2002 est.)
Population growth rate: 2.7% (2002 est.)
Birth rate: 49.95 births/1,000 population (2002 est.)
Death rate: 22.25 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.71 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 1.1 male(s)/fema!e
total population: 1 ma!e(s)/female (2002 est.)
Infant mortality rate: 122.23 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 41.91 years
male: 42.04 years
female: 41 .77 years (2002 est.)
Total fertility rate: 7 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: 17,700 (2002est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christian
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 15.3%
mate: 21.2%
female: 9.4% (2002)','ffc68823a50fa7ea645c07c796ab48a3343c6b5540b0b60241b8e2eaf68ed3f0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('710ff76180c9e70165f1a0b74d94d6e03f239516b8b76088e283fad56f45be65',2002,'NI','Nicaragua','people-and-society',395,'Population: 16,804,784
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 46% (male 3,874,651; female 3,847,080)
15-64 years: 51 .8% (male 4,468,242; female
4,238,998)
65 years and over: 2.2% (male 1 85,306; female
190,507) (2002 est.)
Population growth rate: 2.45% (2002 est.)
Birth rate: 39.99 births/1 ,000 population (2002 est.)
Death rate: 16.74 deaths/1,000 population
(2002 est.)
Net migration rate: 1.22 migrant(s)/1 ,000
population
note: after Liberia''s civil war started in 1990, more
than 350,000 refugees fled to Cote d''Ivoire; by the end
of 1 999 most Liberian refugees were assumed to have
returned (2002 est.)
Cote d''Ivoire (continued)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .05 ma!e(s)/fema!e
65 years and over: 0.97 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 92.23 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 44.72 years
male: 43.45 years
female: 46.03 years (2002 est.)
Total fertility rate: 5.61 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 10.76%
(1999 est.)
HIV/AIDS -people living with HIV/AIDS: 1 million
(2000)
HIV/AIDS - deaths: 72,000 (1999 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Akan 42.1%, Voltaiques or Gur
17.6%, Northern Mandes 16.5%, Krous 11%,
Southern Mandes 10%, other 2.8% (includes 130,000
Lebanese and 20,000 French) (1998)
Religions: Christian 20-30%, Muslim 35-40%,
indigenous 25-40% (2001)
note: the majority of foreigners (migratory workers)
are Muslim (70%) and Christian (20%)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 48.5%
male: 57%
female: 40%','2dfd723e7eab939fe34362c53a1eddb5118e2ba3020671650ec93f05e210f260','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d9aec8c81f9c72a4248d5e1db60034377871e4b26df23d399dff3de65ff8da',2002,'SI','Slovenia','people-and-society',398,'Population: 4,390,751 (July 2002 est.)
Age structure:
0-14 years: 1 8.3% (male 41 1 ,847; female 390,797)
15-64 years: 66.3% (male 1 ,461 ,305; female
1,448,973)
65 years and over: 1 5.4% (male 252,970; female
424,859) (2002 est.)
Population growth rate: 1.12% (2002 est.)
Birth rate: 12.8 births/1 ,000 population (2002 est.)
Death rate: 11.31 deaths/1,000 population
(2002 est.)
Net migration rate: 9.72 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 ma!e(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 7.06 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74, 1 3 years
male: 70.52 years
female: 77.96 years (2002 est.)
Total fertility rate: 1 .93 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 350
(1999 est.)
HiV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Croat(s), Croatian(s)
adjective: Croatian
Ethnic groups: Croat 78.1%, Serb 12.2%, Bosniak
0.9%, Hungarian 0.5%, Slovene 0.5%, Czech 0.4%,
Albanian 0.3%, Montenegrin 0.3%, Roma 0.2%,
others 6.6% (1991)
Religions: Roman Catholic 76.5%, Orthodox 1 1 .1%,
Muslim 1.2%, Protestant 0.4%, others and unknown
10.8% (1991)
Languages: Croatian 96%, other 4% (including
Italian, Hungarian, Czech, Slovak, and German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
femafe; 95% (1 991 est.)','73be8647424a19bc49f607731480fda6ae0504621cf1c51dbe36a695a72c2037','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b42aae9e54fd6fc98904e5dd011514ff3dac652658e47a525b5c1635f9eb8563',2002,'MX','Mexico','people-and-society',408,'Population: 11,224,321 (July 2002 est.)
Age structure:
0-14 years: 20.6% (male 1,188,125; female
1,125,743)
15-64 years: 69.3% (male 3,902,1 62; female
3,880,531)
65 years and over: 10.1% (male 520,849; female
606,911) (2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 12.08 births/1 ,000 population (2002 est.)
Death rate: 7.35 deaths/1,000 population (2002 est.)
Net migration rate: -1.21 migrant(s)/1 .000
population (2002 est.)
Sex ratio:
at birth: 1.06 ma!e(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/fema!e
65 years and over: 0.86 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 7.27 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.6 years
male: 74.2 years
female: 79.15 years (2002 est.)
Total fertility rate: 1 .6 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.03%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,800
(2001 est.)
HIV/AIDS - deaths: 120 (1999 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51 %, white 37%, black 11%,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah’s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 95.7%
male: 96.2%
female: 95.3% (1995 est.)
People - note: illicit migration is a continuing
problem; Cubans attempt to depart the island and
enter the US using homemade rafts, alien smugglers,
direct flights, or falsified visas; some 3,000 Cubans
took to the Straits of Florida in 2001 ; the US Coast
Guard interdicted about 25% of these migrants;
Cubans also use non-maritime routes to enter the US:
some 2,400 Cubans arrived overland via the
southwest border and direct flights to Miami in 2000
Population: 103,400,165 (July 2002 est.)
Age structure:
0-14 years: 32.8% (male 17,310,230; female
16,630,935)
15-64 years: 62.7% (male 31 ,552,877; female
33,246,668)
65 years and over: 4.5% (male 2,069,826; female
2,589,629) (2002 est.)
Population growth rate: 1.47% (2002 est.)
Birth rate: 22.36 births/1 ,000 population (2002 est.)
Death rate: 4.99 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.71 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.8 male(s)/female .
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 24.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.03 years
male: 68.99 years
female: 75.21 years (2002 est.)
Total fertility rate: 2.57 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.29%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 150,000
(1999 est.)
HIV/AIDS -deaths: 4,700 (1999 est.)
Nationality:
noun : Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%, other 5%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 89.6%
mate: 91.8%
female: 87 A% (1995 est.)
Population: 38,625,478 (July 2002 est.)
Age structure:
0-14 years: 17.9% (male 3,535,701 ; female
3,361,515)
15-64 years: 69.5% (male 13,358,128; female
13,500,443)
65 years and over: 1 2.6% (male 1 ,860,274; female
3,009,417) (2002 est.)
Population growth rate: -0.02% (2002 est.)
Birth rate: 10.29 births/1 ,000 population (2002 est.)
Death rate: 9.97 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.49 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 9.17 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.66 years
male: 69.52 years
female: 78.05 years (2002 est.)
Total fertility rate: 1 .37 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1.3%,
Ukrainian 0.6%, Belarusian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant, and
other 5%
Languages: Polish
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1978 est.)','99633e1dc4fc1a36864f5a0e78fde4b9a0efc18578ec14628d1c51aedd465d46','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c15bce6664dd2484885e4b088f77b944e9c862e4b28105ae6492f9a963da75d0',2002,'CY','Cyprus','people-and-society',417,'Population: 767,314 (July 2002 est.)
Age structure:
0-14 years: 22.4% (male 87,981 ; female 84,1 68)
15-64 years: 66.6% (male 258,414; female 252,778)
65 years and over: 1 1 % (male 36,607; female
47,366) (2002 est.)
Population growth rate: 0.57% (2002 est.)
Birth rate: 12.91 births/1 ,000 population (2002 est.)
Death rate: 7.63 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.43 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.05 maie(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 7.71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.08 years
male: 74.77 years
female: 79.5 years (2002 est.)
Total fertility rate: 1 .9 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1 % (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 400
(199? est.)
HIV/AIDS - deaths: NA
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 85.2%, Turkish 1 1 .6%, other
3.2% (2000)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98.7%
female: 95% (1999)
Population: 10,256,760 (July 2002 est.)
Age structure:
0-14 years: 15.7% (male 828,273; female 786,617)
15-64 years: 70.3% (male 3,605,766; female
3,603,058)
65 years and over: 14% (male 551 ,852; female
881,194) (2002 est.)
Population growth rate: -0.07% (2002 est.)
Birth rate: 9.08 births/1,000 population (2002 est.)
Death rate: 1 0.76 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.96 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/fema1e
under 15 years: 1.05 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 ma1e(s)/female (2002 est.)
Infant mortality rate: 5.46 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74 ,95 years •
male: 71 .46 years
female: 78.65 years (2002 est.)
Total fertility rate: 1.18 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1 999 est.)
Nationality:
noun: Czech(s)
adjective: Czech
Ethnic groups: Czech 81.2%, Moravian 13.2%,
Slovak 3.1%, Polish 0.6%, German 0.5%, Silesian
0.4%, Roma 0.3%, Hungarian 0.2%, other 0.5%
(1991)
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech
Literacy:
definition: NA
total population: 99.9% (1999 est.)
male: NA%
female: NA%','16dc9d7c4f05706026fd831f3faacc0588045025c44d3595e0e15f192689cd51','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155650cc24f1dc304626b9aabf3404ce1cd99172012e3176a85d5e9e0e5c7703',2002,'SE','Sweden','people-and-society',428,'Population: 5,368,854 (July 2002 est.)
Age structure:
0-14 years: 18.7% (male 514,589; female 488,121)
15-64 years: 66.4% (male 1 ,806,722; female
1,760,149)
65 years and over: 14.9% (male 334,599; female
464,674) (2002 est.)
Population growth rate: 0.29% (2002 est.)
Birth rate: 1 1 .74 births/1 ,000 population (2002 est.)
Death rate: 10.81 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.01 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.06 ma!e(s)/female
under 15 years: 1.05 ma!e(s)/female
15-64 years: 1 .03 ma!e(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 4.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.91 years
142
Denmark (continued)
male: 74.3 years
female: 79.67 years (2002 est.)
Total fertility rate: 1 .73 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1 7%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,300
(1999 est.)
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Inuit, Faroese,
German, Turkish, Iranian, Somali
Religions: Evangelical Lutheran 95%, other
Protestant and Roman Catholic 3%, Muslim 2%
Languages: Danish, Faroese, Greenlandic (an Inuit
dialect), German (small minority)
note: English is the predominant second language
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: NA%
female: NA%
Population: 472,810 (July 2002 est.)
Age structure:
0-14 years: 42.6% (male 100,903; female 100,420)
15-64 years: 54.5% (male 135,409; female 122,209)
65 years and over: 2.9% (male 7,220; female 6,649)
(2002 est.)
Population growth rate: 2.59% (2002 est.)
Birth rate: 40.33 births/1,000 population (2002 est.)
Death rate: 14.43 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years:! male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1 .09 male(s)/female
total population: 1 .06 male(s)/female (2002 est.)
Infant mortality rate: 99.7 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .6 years
male: 49.73 years
female: 53.52 years (2002 est.)
Total fertility rate: 5.64 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 1 .75%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 37,000
(1999 est.)
HIV/AIDS - deaths: 4,400 (2002 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 1 5 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)
Population: 70,158 (July 2002 est.)
Age structure:
0- 14 years: 28.3% (male 1 0,052; female 9,800)
15-64 years: 63.8% (male 23,01 1 ; female 21 ,782)
65 years and over: 7.9% (male 2,245; female 3,268)
(2002 est.)
Population growth rate: -0.81% (2002 est.)
Birth rate: 17.3 births/1 ,000 population (2002 est.)
Death rate: 7.1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: -18.26 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over. 0.69 male(s)/fema!e
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 15.94 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.86 years
male: 70.98 years
female: 76.88 years (2002 est.)
Total fertility rate: 2,01 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, mixed black and European,
European, Syrian, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), none 2%,
other 6%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
fema/e: 94% (1970 est.)','5a1c76f4c8da4434306b25df7dc39305c54bd7e29900600ce6bfd38812b41d80','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3da25a35d6980495b11e4b364cbf35d71730e6983b7dfec6726f043ade582d76',2002,'DO','Dominican Republic','people-and-society',436,'Population: 8,721 ,594 (July 2002 est.)
Age structure:
0-14 years: 33.7% (male 1 ,503,344; female
1,439,157)
15-64 years: 61 .3% (male 2,720,308; female
2,621,539)
65 years and over: 5% (male 206,556; female
230,690) (2002 est.)
Population growth rate: 1.61% (2002 est.)
Birth rate: 24.4 births/1,000 population (2002 est.)
Death rate: 4.68 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.59 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 maie(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.9 ma!e(s)/fema!e
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 33.41 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.68 years
male: 71.57 years
female: 75.91 years (2002 est.)
Total fertility rate: 2.94 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.8% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 4,900 (1999 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 82.1%
male: 82%
female: 82.2% (1995 est.)
Population: 952,618 (July 2002 est.)
note: other estimates range as low as 800,000
(2002 est.)
Age structure: NA
Population growth rate: 7.26% (2002 est.)
Birth rate: 28.07 births/1 ,000 population (2002 est.)
Death rate: 6.52 deaths/1 ,000 population (2002 est.)
Net migration rate: 51 .07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio: NA
Infant mortality rate: 51 .99 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.85 years
male: 62.64 years
female: 67.17 years (2002 est.)
Total fertility rate: 3.88 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Timorese
adjective: Timorese
Ethnic groups: Austronesian (Malayo-Polynesian),
Papuan, small Chinese minority
Religions: Roman Catholic 90%, Muslim 4%,
Protestant 3%, Hindu 0.5%, Buddhist, Anlmist
(1992 est.)
Languages: Tetum (official), Portuguese (official),
Indonesian, English
note: there are a total of about 16 indigenous
languages, of which Tetum, Galole, Mambae, and
Kemak are spoken by significant numbers of people
151
East Timor (continued)
Literacy:
definition: age 15 and over can read and write
total population: 48% (2001)
male: NA%
female: NA%
Population: 3,957,988 (July 2002 est.)
Age structure:
0-14 years: 23.5% (male 476,726; female 453,782)
15-64 years: 65.8% (male 1,249,850; female
1,353,438)
65 years and over: 10.7% (male 180,053; female
244,139) (2002 est.)
Population growth rate: 0.51% (2002 est.)
Birth rate: 15.04 births/1 ,000 population (2002 est.)
Death rate: 7.82 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1.05male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 9.3 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.96 years
male: 71 .5 years
female: 80.66 years (2002 est.)
Total fertility rate: 1.9 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: 7,397
(1997)
HIV/AIDS -deaths: NA
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: white (mostly Spanish origin) 80.5%,
black 8%, Amerindian 0.4%, Asian 0.2%, mixed and
other 10.9%
Religions: Roman Catholic 85%, Protestant and
other 15%
Languages: Spanish, English
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 90%
female: 88% (1980 est.)','9d5b7c218a86e264e0d0e60d657043f2ed82e7e8c15e5e5b9e321418ce98851f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2e96844918726c9c98f1a76a67354f214399523a36575fac34ffe8d286e2cd7',2002,'PE','Peru','people-and-society',450,'Population: 13,447,494 (July 2002 est.)
Age structure:
0-14 years: 35.4% (male 2,41 5,764; female
2,337,095)
15-64 years: 60.2% (male 4,007,495; female
4,090,957)
65 years and over: 4.4% (male 276,482; female
319,701) (2002 est.)
Population growth rate: 1.96% (2002 est.)
Birth rate: 25.47 births/1,000 population (2002 est.)
Death rate: 5.36 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.53 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 33.02 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71.61 years
male: 68. 79 years
female: 74.57 years (2002 est.)
Total fertility rate: 3.05 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2001)
HIV/AIDS - people living with HIV/AIDS: 20,000
(2001 est.)
HIV/AIDS -deaths: 232(2001)
Nationality;
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and
white) 65%, Amerindian 25%, Spanish and others 7%,
black 3%
Religions: Roman Catholic 95%
i
Ecuador (continued)
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 15 and over can read and write
total population: 90.1%
male: 92%
female: 88.2% (1995 est.)
Population: 70,712,345 (July 2002 est.)
Age structure:
0-14 years: 33.96% (male 12.292,185; female
11,721,469)
15-64 years: 62.18% (male 22.190,637; female
21,775,504)
65 years and over: 3.86% (male 1 ,1 91 ,091 ; female
1,541,459) (2002 est.)
Population growth rate: 1 .66% (2002 est.)
Birth rate: 24.41 births/1,000 population (2002 est.)
Death rate: 7.58 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.24 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 ,05 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.77 male(s)/fema!e
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 58.6 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.05 years
male: 61 .96 years
female: 66.24 years (2002 est.)
Total fertility rate: 2.99 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions: Muslim (mostly Sunni) 94%, Coptic
Christian and other 6%
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 15 and over can read and write
total population: 51.4%
male: 63.6%
female: 36.6% (1995 est.)
Population: 27,949,639 (July 2002 est.)
Age structure:
0-14 years: 34% (male 4,820,892; female 4,671 ,205)
15-64 years: 61.1% (male 8,598,328; female
8,492,830)
65 years and over: 4.9% (male 627,601 ; female
738,783) (2002 est.)
Population growth rate: 1.66% (2002 est.)
Birth rate: 23.36 births/1,000 population (2002 est.)
Death rate: 5.74 deaths/1,000 population (2002 est.)
Net migration rate: -1.05 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 ma!e(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 38.18 deaths/1 ,000 live births
(2002 est.)
409
Peru (continued)
Life expectancy at birth:
total population: 70.59 years
male: 68. 18 years
female: 73.1 2 years (2002 est.)
Total fertility rate: 2.89 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 48,000
(1999 est.)
HIV/AIDS - deaths: 4,100 (1999 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic 90%
Languages: Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 15 and over can read and write
total population: 88.3%
male: 94.5%
female: 83% (1995 est.)','710bb584b135090038e2085d7cba685ba8c8416b2f9b91a841d9500576bfbcdb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d3053a3c577e780369c35d0d074dcd02cfd952f53fc90e1f7271f836c657b1',2002,'GQ','Equatorial Guinea','people-and-society',460,'Population: 498,144 (July 2002 est.)
Age structure:
0-14 years: 42.4% (male 106,061; female 105.071)
15-64 years: 53.8% (male 128,489; female 139,732)
65 years and over: 3.8% (male 8,385; female 10,406)
(2002 est.)
Population growth rate: 2.45% (2002 est.)
Birth rate: 37.33 births/1 ,000 population (2002 est.)
Death rate: 12.83 deaths/1 ,000 population
(2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1.01 mate(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 90.96 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 54.35 years
male: 52.26 years
female: 56.5 years (2002 est.)
Total fertility rate: 4.81 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.51%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,100
(1999 est.)
HIV/AIDS -deaths: 120 (1999 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 1 5 and over can read and write
total population: 78.5%
male: 89.6%
female: 68.1% (1995 est.)','601e0825961379253abbfc0dcd4106394393d28371c1e66084487d0f40d746de','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6467632fe4c571cc7670420e8703ecace8af00c1929b2390a0766b3be939e9',2002,'GN','Guinea','people-and-society',468,'Population: 4,465,651 (July 2002 est.)
Age structure:
0-14 years: 42.9% (male 958,564; female 955,625)
15-64 years: 53.9% (male 1,192,454; female
1,213,313) .
65 years and over: 3.2% (male 73,017; female
72,678) (2002 est.)
Population growth rate: 3.8% (2002 est.)
Birth rate: 42.25 births/1 ,000 population (2002 est.)
Death rate: 1 1 .82 deaths/1 ,000 population
(2002 est.)
Net migration rate: 7.61 migrant(s)/1 ,000
population
note: UNHCR began repatriating about 150,000
Eritrean refugees from Sudan in 2001 following the
restoration of diplomatic relations between the two
countries in 2000 (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 male(s)/fema!e
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 73.62 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 56.57 years
male: 54.09 years
female: 59.13 years (2002 est.)
Total fertility rate: 5.8 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.87%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%, other 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, other Cushitic languages
Literacy:
definition: NA
total population: 25%
male: NA%
female: NA%
Population: 7,775,065 (July 2002 est.)
Age structure:
0-14 years: 42.8% (male 1 ,660,795; female
1,669,850)
15-64 years: 54.5% (male 2,067,991 ; female
2,165,625)
65 years and over: 2.7% (male 86,968; female
123,836) (2002 est.)
Population growth rate: 2.23% (2002 est.)
Birth rate: 39.49 births/1 ,000 population (2002 est.)
Death rate: 17.24 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
note: as a result of civil war in neighboring countries,
Guinea is host to approximately 1 50,000 Liberian and
Sierra Leonean refugees (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 ma!e(s)/female (2002 est.)
Infant mortality rate: 127.08 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.28 years
male: 43.81 years
female: 48.82 years (2002 est.)
Total fertility rate: 5.32 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 55,000
(1999 est.)
HIV/AIDS -deaths: 5,600 (1999 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
218
Guinea (continued)
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller ethnic groups 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each ethnic group has
its own language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
male: 49.9%
female: 21 .9% (1995 est.)
Population: 129,934,911
note: estimates for this country explicitly lake into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 43.6% (male 28,503,21 1; female
28,156,976)
15-64 years: 53.6% (mate 35,418,119; female
34,179,802)
65 years and over: 2.8% (male 1 ,832,682; female
1,844,121) (2002 est.)
Population growth rate: 2.54% (2002 est.)
Birth rate: 39.22 births/1 ,000 population (2002 est.)
Death rate: 14.1 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.27 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 ,03 male(s)/female
under 15 years: 1.01 ma!e(s)/fema!e
15-64 years: 1.04 ma!e(s)/fema!e
65 years and over: 0.99 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 72,49 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 50.59 years
male: 50.58 years
female: 50.6 years (2002 est.)
Total fertility rate: 5.49 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 5.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2.7million
(1999 est.)
HIV/AIDS - deaths: 250,000 (1999 est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Nigeria, which is Africa’s most
populous country, is composed of more than 250
ethnic groups; the following are the most populous
and politically influential: Hausa and Fulani 29%,
Yoruba 21%, Igbo (Ibo) 18%, Ijaw 10%, Kanuri 4%,
Ibibio 3.5%, Tiv 2.5%
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa. Yoruba, Igbo
(Ibo), Fulani
Literacy:
definition: age 1 5 and over can read and write
total population: 57.1%
male: 67.3%
female: 47.3% (1995 est.)
Population: 170,372 (July 2002 est.)
Age structure:
0-14 years: 47.7% (male 41,159; female 40,125)
15-64 years: 48.3% (male 39,701 ; female 42,586)
65 years and over: 4% (male 3,1 1 5; female 3,686)
(2002 est.)
Population growth rate: 3.18% (2002 est.)
Birth rate: 42.3 births/1,000 population (2002 est.)
Death rate: 7.32 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.93 ma!e(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.97 ma!e(s)/female (2002 est.)
Infant mortality rate: 47.5 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 65.93 years
male: 64.47 years
female: 67.45 years (2002 est.)
Total fertility rate: 5.95 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of
Angolan slaves) , forros (descendants of freed slaves) ,
servicais (contract laborers from Angola.
Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), Europeans (primarily
Portuguese)
Religions: Christian 80% (Roman Catholic,
Evangelical Protestant, Seventh-Day Adventist)
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 79.3%
male: 85%
female: 62% (1991 est.)','496420bb2026591fa3943c66cd02c0dea789b6c8747416aeb4e2054bb5bc2b1f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987a4456a25378cfde8c1b395c5f93b358b47ff6b517356f2098d33953b9dfe7',2002,'EE','Estonia','people-and-society',471,'Population: 1,415,681 (July 2002 est.)
Age structure:
0-14 years: 1 6.4% (male 1 1 8,603; female 1 1 4,1 02)
15-64 years: 68.5% (male 466,882; female 502,343)
65 years and over: 1 5.1 % (male 70,085; female
143,666) (2002 est.)
Population growth rate: -0.52% (2002 est.)
Birth rate: 8.96 births/1 ,000 population (2002 est.)
Death rate: 13.44 deaths/1,000 population
(2002 est.)
Net migration rate: -0.73 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0,49 male(s)/female
total population: 0.86 male(s)/fema!e (2002 est.)
Infant mortality rate: 12.32 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.02 years
male: 64.03 years
female: 76.31 years (2002 est.)
Total fertility rate: 1 .24 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HiV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 65.3%, Russian 28.1%,
Ukrainian 2.5%, Belarusian 1.5%, Finn 1%, other
1.6% (1998)
Religions: Evangelical Lutheran, Russian Orthodox,
Estonian Orthodox, Baptist, Methodist, Seventh-Day
Adventist, Roman Catholic, Pentecostal, Word of Life,
Jewish
Languages: Estonian (official), Russian, Ukrainian,
Finnish, other
Literacy:
definition: age 1 5 and over can read and write
total population: 100%
male: 100%
female: 100% (1998 est.)','99a4a7b1bc598afe47fe2b5ca0b5c9fa940211ee382e6116e3a130541ee95b5c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c226af4a2adedf93c4a4c600e6ca286e5f2994e8316df6ed1b2a0ac50417ce6',2002,'FO','Faroe Islands','people-and-society',481,'Population: 46,01 1 (July 2002 est.)
Age structure:
0-14 years: 22.3% (male 5,149; female 5,110)
15-64 years: 64% (male 15,650; female 13,801)
65 years and over: 1 3.7% (male 2,81 8; female 3,483)
(2002 est.)
Population growth rate: 0.74% (2002 est.)
Birth rate: 13.74 births/1,000 population (2002 est.)
Death rate: 8.69 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.39 mrgrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth : 1 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .13 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 6.66 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.74 years
male: 75.28 years
female: 82.21 years (2002 est.)
Total fertility rate: 2.27 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: similar to Denmark proper','33e2168c46343e0517b870f294ef816a5d433fc2aaa19f40dedfb4d1aad13e5f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfff32b57c39d6ebc407fd0e549f9df76be954b6ab781cf454c876b3885972b1',2002,'JE','Jersey','people-and-society',489,'Population: 856,346 (July 2002 est.)
Age structure:
0-14 years: 32.5% (male 141,757; female 136,198)
15-64 years: 63.8% (male 273,658: female 273,100)
65 years and over: 3.7% (male 1 4,648; female
16,985) (2002 est.)
Population growth rate: 1.41% (2002 est.)
Birth rate: 23.2 births/1 ,000 population (2002 est.)
Death rate: 5.72 deaths/1 ,000 population (2002 est.)
Net migration rate: -3.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .01 male(s)/female (2002 est.)
Infant mortality rate: 13.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.56 years
ma/e: 66.13 years
female: 71 .1 1 years (2002 est.)
Total fertility rate: 2.83 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 85
(2000 est.)
HIV/AIDS -deaths: NA
174
Fiji (continued)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51% (predominantly
Melanesian with a Polynesian admixture),
Indian 44%, European, other Pacific Islanders,
overseas Chinese, and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
total population: 92.5%
mate: 90%
female: 95% (1999 est.)
Population: 6,029.529 (July 2002 est.)
note: includes about 182,000 Israeli settlers in the
West Bank, about 20,000 in the Israeli-occupied
Golan Heights, fewer than 7,000 in the Gaza Strip,
254
Israel (continued)
and about 176,000 in East Jerusalem
(August 2001 est.)
Age structure:
0-14 years: 27.1% (male 837,491; female 798,695)
15-64 years: 63% (male 1,905,677; female
1,889,525)
65 years and over: 9.9% (mate 257,066; female
341 ,075) (2002 est.)
Population growth rate: 1 .48% (2002 est.)
Birth rate: 18.91 births/1,000 population (2002 est.)
Death rate: 6.21 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.11 migrant(s)/1,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 7.55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.86 years
male: 76.82 years
female: 81 .01 years (2002 est.)
Total fertility rate: 2.54 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,400
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Israeli®
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/
America-born 32.1%, Israel-born 20.8%, Africa-born
14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Jewish 80.1%, Muslim 14.6% (mostly
Sunni Muslim), Christian 2.1%, other 3.2% (1 996 est.)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)
Population: 89,775 (July 2002 est.)
Age structure:
0-14 years: 17.9% (male 8,287; female 7,729)
15-64 years: 67.3% (male 30,099; female 30,347)
65 years and over: 14.8% (male 5,729; female 7,584)
(2002 est.)
Population growth rate: 0.44% (2002 est.)
Birth rate: 1 0.86 births/1 ,000 population (2002 est.)
Death rate: 9.22 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.78 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.76 ma!e(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 5.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.78 years
male: 76.34 years
female: 81 .4 years (2002 est.)
Total fertility rate: 1 .57 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist. Presbyterian
Languages: English (official), French (official),
Norman-French dialect spoken in country districts
Literacy:
definition: NA
total population: NA
male: NA
female: NA
Population: 2,111,561
note: includes 1,159, 91 3 non-nationals (July
2002 est.)
Age structure:
0-14 years: 28.3% (male 304,200; female 292,900)
15-64 years: 69.2% (male 934,1 15; female 527,331)
65 years and over: 2.5% (male 34,106; female
18,909) (2002 est.)
Population growth rate: 3.33%
note: this rate reflects a return to pre-Gulf crisis
immigration of expatriates (2002 est.)
Birth rate: 21 .84 births/1 ,000 population (2002 est.)
Death rate: 2,46 deaths/1 ,000 population (2002 est.)
Net migration rate: 13.88 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .77 male(s)/femate
65 years and over: 1 .8 male(s)/female
total population: 1.52 male(s)/female (2002@est.)
Infant mortality rate: 1 0.87 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.46 years
male: 75.56 years
female: 77.39 years (2002 est.)
Total fertility rate: 3,14 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 70%, Shi''a 30%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 1 5 and over can read and write
total population: 78.6%
male: 82.2%
female: 74.9% (1995 est.)
Population: 207,858 (July 2002 est.)
Age structure:
0-14 years: 30% (male 31,862; female 30,577)
15-64 years: 64.1% (male 67,043; female 66,102)
65 years and over: 5.9% (male 5,777; female 6,497)
(2002 est.)
Population growth rate: 1.43% (2002 est.)
Birthrate: 19.91 births/1 ,000 population (2002 est.)
Death rate: 5.62 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 8.23 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.27 years
male: 70.32 years
female: 76.36 years (2002 est.)
Total fertility rate: 2.44 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun : New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1 .6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
Population: 1 ,932,917 (July 2002 est.)
Age structure:
0-14 years: 15.7% (male 155,989; female 147,707)
15-64 years: 69.8% (male 684,354; female 663,884)
65 years and over: 14.5% (male 103,790; female
177,193) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 9.27 births/1,000 population (2002 est.)
Death rate: 1 0.07 deaths/1 ,000 population
(2002 est.)
Net migration rate: 2.24 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .06 ma!e(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.96 ma!e(s)/female (2002 est.)
Infant mortality rate: 4.47 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.29 years
mate: 71. 42 years
female: 79.37 years (2002 est.)
Total fertility rate: 1.28 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 88%, Croat 3%, Serb 2%,
Bosniak 1 %, Yugoslav 0.6%, Hungarian 0.4%, other
5% (1991)
Religions: Roman Catholic (Uniate 2%) 70.8%,
Lutheran 1%, Muslim 1%, atheist 4.3%, other 22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
mate: NA%
female : NA%
Population: 494,786 (July 2002 est.)
Age structure:
0-74 years: 43.4% (male 109,339; female 105,170)
15-64 years: 53.5% (male 134,125; female 130,804)
65 years and over: 3.1 % (male 7,467; female 7,881 )
(2002 est.)
Population growth rate: 2.91% (2002 est.)
Birth rate: 33.26 births/1,000 population (2002 est.)
Death rate: 4. 1 9 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .03 male(s)/female (2002 est.)
Infant mortality rate: 23.68 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .82 years
male: 69.38 years
female: 74.39 years (2002 est.)
Total fertility rate: 4.5 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%,
Micronesian 1 .5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions: Anglican 45%, Roman Catholic 18%,
United (Methodist/Presbyterian) 12%, Baptist 9%,
Seventh-Day Adventist 7%, other Protestant 5%,
indigenous beliefs 4%
Languages: Melanesian pidgin in much of the
country is lingua franca; English is official but spoken
by only 1%-2% of the population
note: 120 indigenous languages
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 1,123,605
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 45.5% (male 254,573; female 256,677)
15-64 years: 51 .9% (male 281 ,645; female 301 ,071 )
65 years and over: 2.6% (male 12,027; female
17,612) (2002 est.)
Population growth rate: 1.63% (2002 est.)
Birth rate: 39.59 births/1 ,000 population (2002 est.)
Death rate: 23.26 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/fema!e
15-64 years: 0.94 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 109.43 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 37 years
male: 36.35 years
female: 37.66 years (2002 est.)
Total fertility rate: 5.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 35.6%
(2002 est.)
HIV/AIDS - people living with HIV/AIDS: 212,000
(2002 est.)
HIV/AIDS -deaths: 7,100 (1999 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Zionist (a blend of Christianity and
indigenous ancestral worship) 40%, Roman Catholic
20%, Muslim 10%, Anglican, Bahai, Methodist,
Mormon, Jewish and other 30%
Languages: English (official, government business
conducted in English), siSwati (official)
490
Swaziland (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 78.3%
male: 78%
female: 78.4% (1999 est.)','857a2b645d5624a7098f298b8987a881c2c5a0e1f32d24bece6509f8124611e2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('547d8c3982920f0c9e2e07eb99dc36db9ad9fa259968825b6719a5f66e7f94f2',2002,'FI','Finland','people-and-society',499,'Population: 5,183,545 (July 2002 est.)
Age structure:
0-14 years: 17.9% (male 471,920; female 454,082)
15-64 years: 66.9% (male 1,752,493; female
1,717,544)
65 years and over: 1 5.2% (male 306,21 6; female
481 ,290) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 1 0.6 births/1 ,000 population (2002 est.)
Death rate: 9.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.62 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 3.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.75 years
male: 74.1 years
female: 81 .52 years (2002 est.)
Total fertility rate: 1 .7 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,100
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Sami 0.1 1%,
Roma 0.12%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Russian
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.4% (official), Swedish 5.9%
(official), small Lapp- and Russian-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%
Population: 4,525,116 (July 2002 est.)
Age structure:
0-14 years: 20% (male 464,789; female 439,1 17)
15-64 years: 65% (mate 1 ,491 ,720; female
1,451,450)
65 years and over: 15% (male 281 ,551 ; female
396,489) (2002 est.)
Population growth rate: 0.47% (2002 est.)
Birth rate: 12.39 births/1 ,000 population (2002 est.)
Death rate: 9.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.1 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.07 male(s)/female
under 15 years: 1.06 ma1e(s)/female
15-64 years: 1 .03 ma!e(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 3.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.94 years
male: 76.01 years
female: 82.07 years (2002 est.)
Total fertility rate: 1 .8 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,600
(1999 est.)
HIV/AIDS -deaths: 8(1999)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Norwegian, Sami 20.000
Religions: Evangelical Lutheran 86% (state church),
other Protestant and Roman Catholic 3%, other 1%,
none and unknown 10% (1997)
Languages: Norwegian (official)
note: small Sami- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: NA%
female: NA%
Population: 2,713,462
note: includes 527,078 non-nationals (July 2002 est.)
Age structure:
0-14 years: 41 .9% (male 579,065; female 556,923)
15-64 years: 55.7% (male 914,494; female 597,948)
65 years and over: 2.4% (male 34,555; female
30,477) (2002 est.)
Population growth rate: 3.41% (2002 est.)
Birth rate: 37.76 births/1 ,000 population (2002 est.)
Death rate: 4.03 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .53 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1 .29 male(s)/female (2002 est.)
Infant mortality rate: 21 .77 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.31 years
male: 70.1 5 years
female: 74.57 years (2002 est.)
Total fertility rate: 5.99 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.11%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%','d7a2595c376956e7dff4ee172109c61fb36ea6951ac20c961633cc40afa52f9f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('028532ebeed03a368afa07a035d01a5ca2d016f9006a7f34355a7c5d40232a04',2002,'ES','Spain','people-and-society',508,'Population: 59,765,983 (July 2002 est.)
Age structure:
0-14 years: 18.5% (male 5,675,269; female
5,401,661)
15-64 years: 65.2% (male 19,503,556; female
19,479,646)
65 years and over. 16.3% (male 3,948,433; female
5,757,418) (2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 1 1 .94 births/1 ,000 population (2002 est.)
Death rate: 9.04 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.64 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1,06 ma!e(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 4.41 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.05 years
male: 75.17 years
female: 83. 14 years (2002 est.)
Total fertility rate: 1 .74 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.44%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS - deaths: 2,000 (1999 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 83%-88%, Protestant
2%, Jewish 1%, Muslim 5%-10%, unaffiliated 4%
Languages: French 100%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1980 est.)','5aaada7fea9449ff37b3e843d4ea65465ec2aadfd0e4c6ff95fc57e54a315269','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a6805dd7f70b09b3e5e550206826b526b83586784caadbb3bea6f8ed7d16359',2002,'GF','French Guiana','people-and-society',518,'Population: 182,333 (July 2002 est.)
Age structure:
0-14 years: 30.2% (male 28,140; female 26,876)
15-64 years: 64.2% (mate 63,183; female 53,902)
65 years and over: 5.6% (male 5,192; female 5,040)
(2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 21 .66 births/1 ,000 population (2002 est.)
Death rate: 4.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 8.78 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 1.17 ma!e(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.13 male(s)/fema1e (2002 est.)
Infant mortality rate: 13.22 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.49 years
male: 73.1 6 years
female: 79.99 years (2002 est.)
Total fertility rate: 3.13 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 1 2%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 84%
female: 82% (1982 est.)','90542eea5e79288cfa92ed40d15586aada7d3ff2683d3f54b7fea78f8ba2d53b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45c3887b4b653a737f82601aefad0f4e37a4d0177d31393cf352ae602ad9d142',2002,'NR','Nauru','people-and-society',523,'Population: 257,847 (July 2002 est.)
Age structure:
0-14 years: 29% (male 38,184; female 36,631)
15-64 years: 65.7% (male 88,250; female 81,165)
65 years and over: 5.3% (male 6,850; female 6,767)
(2002 est.)
Population growth rate: 1.67% (2002 est.)
Birth rate: 18.17 births/1 ,000 population (2002 est.)
Death rate: 4.49 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.04 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 ,04 ma!e(s)/female
15-64 years: 1 .09 maie(s)/female
65 years and over: 1.01 ma1e(s)/female
total population: 1.07 ma!e(s)/female (2002 est.)
Infant mortality rate: 8.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.23 years
male: 72.88 years
female : 77.69 years (2002 est.)
Total fertility rate: 2.18 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
. Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
female: 98% (1977 est.)','bd2fe0db1ed40f80cb98b808e762ec7ffba047c3df0da6aebf3d746d0a4d3b03','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('971665fd322d5f7fbbaebb13582adc8040da5b9a88ef10a8d958d7b9aa3dbfec',2002,'GA','Gabon','people-and-society',532,'Population: 1,233,353
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes In the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 33.3% (male 205,559; female 204,796)
15-64 years: 60.6% (male 376,103; female 371,422)
65 years and over: 6.1 % (male 37,220; female
38,253) (2002 est.)
Population growth rate: 0.97% (2002 est.)
Birth rate: 27.24 births/1 ,000 population (2002 est.)
Death rate: 1 7.59 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 ma!e(s)/fema!e
15-64 years: 1.01 ma!e(s)/female
65 years and over. 0.97 male(s)/fema!e
total population: 1 .01 male(s)/female (2002 est,)
Infant mortality rate: 93.5 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.11 years
male: 48.01 years
female: 50.25 years (2002 est.)
Total fertility rate: 3.65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 9% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 23,000
(1999 est.)
HIV/AIDS - deaths: 2,000 (1999 est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major
tribal groupings (Fang, Bapounou, Nzebi, Obamba),
other Africans and Europeans 154,000, including
10,700 French and 1 1 ,000 persons of dual nationality
Religions: Christian 55%-75%, animist, Muslim less
than 1%
Languages: French (official), Fang, Myene, Nzebi,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 1 5 and over can read and write
total population: 63.2%
male: 73.7%
female: 53.3% (1 995 est.)
Population: 1 ,225,91 1 (July 2002 est.)
note: in addition, there are fewer than 7,000 Israeli
settlers in the Gaza Strip (August 2001 est.)
Age structure:
0-14 years: 49.7% (male 31 2,253; female 297,008)
15-64 years: 47.5% (male 296,488; female 286,393)
65 years and over: 2.8% (male 14,407; female
19,362) (2002 est.)
Population growth rate: 3.95% (2002 est.)
Birth rate: 41.85 births/1,000 population (2002 est.)
Death rate: 4.1 2 deaths/1 ,000 population (2002 est.)
Net migration rate: 1.73 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 24.76 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .2 years
male: 69,95 years
female: 72.52 years (2002 est.)
Gaza Strip (continued)
Total fertility rate: 6.29 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun : NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 0.7%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','a096004d71a37951998e1a721ccc385374beb01d598b89d3c2570ccd46d6f63a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15616cccbd6e2b87ccb3da7c1272fcbc9745328c8acc00fac98bf670f7faf1d7',2002,'DE','Germany','people-and-society',548,'Population: 83,251,851 (July 2002 est.)
Age structure:
0-14 years: 15.4% (male 6,568,699; female
6,227,148)
15-64 years: 67.6% (male 28,606,964; female
27,695,539)
65 years and over: 17% (male 5,546,140; female
8,607.361) (2002 est.)
Population growth rate: 0.26% (2002 est.)
Birth rate: 8.99 births/1 ,000 population (2002 est.)
Death rate: 10.36 deaths/1 ,000 population
(2002 est.)
Net migration rate: 3.99 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/fema!e
under 15 years: 1 .05 male(s)/femate
15-64 years : 1 .03 ma!e(s)/fema!e
65 years and over: 0.64 male(s)/female
total population: 0.96 male(s)/femate (2002 est.)
Infant mortality rate: 4.65 deaths/1 ,000 live births
(2002 est.)
Lite expectancy at birth:
total population: 77.78 years
mate: 74.64 years
female: 81 .09 years (2002 est.)
Total fertility rate: 1 .39 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 37,000
(1999 est.)
HIV/AIDS -deaths: 600 (1999 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, Turkish 2.4%, other
6.1% (made up largely of Serbo-Croatian, Italian,
Russian, Greek, Polish, Spanish)
Religions: Protestant 34%, Roman Catholic 34%,
Muslim 3.7%, unaffiliated or other 28.3%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1977 est.)
male: NA%
female: NA%
Population: 20,244,154
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July
2002 est.)
Age structure:
0-14 years: 40.4% (male 4,1 16,600; female
4,063,654)
15-64 years: 56.1% (male 5,625,397; female
5,723,786)
65 years and over: 3.5% (male 338,352; female
376,365) (2002 est.)
Population growth rate: 1.7% (2002 est.)
Birth rate: 28.08 births/1 ,000 population (2002 est.)
Death rate: 10.31 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.74 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 098 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 55.64 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 57.06 years
male: 55.66 years
female: 58.51 years (2002 est.)
Total fertility rate: 3.69 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 3.6% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 340,000
(1999 est.)
HIV/AIDS - deaths: 33,000 (1 999 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 98.5% (major tribes -
Akan 44%, Moshi-Dagomba 16%, Ewe 13%, Ga 8%,
Gurma 3%, Voruba 1%), European and other 1.5%
(1998)
Religions: indigenous beliefs 21%, Muslim 16%,
Christian 63%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition : age 15 and over can read and write
total population: 64.5%
male. ''75.9%
female: 53.5% (1995 est.)
People • note: there are 9,500 Liberians, 2,000
Sierra Leoneans, and 1,000 Togolese refugees
residing in Ghana (2002)
Population: 448,569 (July 2002 est.)
Age structure:
0-14 years: 18.9% (male 43,634; female 41 ,164)
15-64 years: 67% (male 151,364; female 149,156)
65 years and over: 14.1% (male 25,486; female
37,765) (2002 est.)
Population growth rate: 1.25% (2002 est.)
Birth rate: 12.06 births/1 ,000 population (2002 est.)
Death rate: 8.83 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.26 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.06 mate(s)/fema1e
15-64 years: 1.01 male(s)/fema!e
65 years and over: 0.67 ma!e(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 4.71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.48 years
male: 74.2 years
female: 80.97 years (2002 est.)
Total fertility rate: 1.7 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.16%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, Slavs (from
Montenegro, Albania, and Kososvo) and European
(guest and resident workers)
Religions: the greatest preponderance of the
population is Roman Catholic with a very few
Protestants, Jews, and Muslims
nofe: 1979 legislation forbids the collection of religious
statistics
Languages: Luxembourgish (national language),
German (administrative language), French
(administrative language)
Literacy:
definition: age 15 and over can read and write
total population: 100%
mate: 100%
female: 100% (2000 est.)
Population: 461,833 (July 2002 est.)
Age structure:
0-14 years: 21. 8% (male 52,262; female 48,439)
15-64 years: 70.9% (male 154,942; female 172,647)
65 years and over: 7. Z% (male 13,616; female
19,927) (2002 est.)
Population growth rate: 1 .75% (2002 est.)
Birth rate: 12.19 births/1,000 population (2002 est.)
Death rate: 3.78 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.08 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .08 ma!e(s)/female
15-64 years: 0.9 ma!e(s)/female
65 years and over: 0.68 male(s)/fema!e
total population: 0.92 male(s)flemale (2002 est.)
Infant mortality rate: 4.44 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 81 .78 years
male: 78.97 years
female: 84.73 years (2002 est.)
Total fertility rate: 1.31 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, Macanese (mixed
Portuguese and Asian ancestry), Portuguese, other
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Portuguese, Chinese (Cantonese)
310
Macau (continued)
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 93%
female: 86% (1981 est.)
Population: 2,054,800
note: a Framework Agreement ratified by Macedonia
on 16 November 2001 calls for a new census in 2002
(July 2002 est.)
Age structure:
0-14 years: 22.4% (male 239,638; female 221,446)
15-64 years: 67.2% (male 694,368; female 686,450)
65 years and over: 10.4% (male 94,214; female
118,684) (2002 est.)
Population growth rate: 0.41% (2002 est.)
Birth rate: 13.35 births/1 ,000 population (2002 est.)
Death rate: 7.74 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .49 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
atbidh: 1.08 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 12.54 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.26 years
male: 72.01 years
female: 76.68 years (2002 est.)
Total fertility rate: 1.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 66.6%, Albanian
22.7%, Turkish 4%, Roma 2.2%, Serb 2.1%, other
2.4% (1994)
312
Macedonia, The Former Yugoslav Republic of (continued)
Religions: Macedonian Orthodox 67%, Muslim 30%,
other 3%
Languages: Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','b1824bb762e31c4bc07d730818e23f98cd040c88002af7c5f48eacb9e19680da','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4db276cec83b63897536ff265eaca10c5b7db992c4f8e1c5d69d2191dd7d7dd2',2002,'GI','Gibraltar','people-and-society',556,'Population: 27,714 (July 2002 est.)
Age structure:
0-14 years: 18.5% (male 2,633; female 2,509)
15-64 years: 66.3% (male 9,456; female 8,907)
65 years and over: 15.2% (male 1 ,803; female 2 ,406)
(2002 est.)
Population growth rate: 0.23% (2002 est.)
Birth rate: 1 1 .19 births/1 ,000 population (2002 est.)
Death rate: 8.88 deaths/1 ,000 population (2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 5.4 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.23 years
male: 76.37 years
female: 82.25 years (2002 est.)
Total fertility rate: 1 .65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Spanish, Italian, English, Maltese,
Portuguese
Religions: Roman Catholic 76.9%, Church of
England 6.9%, Muslim 6,9%, Jewish 2.3%, none or
other 7% (1991)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 80%
male: NA%
female: NA%
Population: no Indigenous inhabitants
note: there is a small French military garrison
(July 2002 est.)
Population: 31 ,1 67,783 (July 2002 est.)
Age structure:
0-14 years: 33.8% (male 5,364,948; female
5,166,666)
15-64 years: 61 .5% (male 9,51 8,503; female
9,640,292)
65 years and over: 4.7% (male 661 ,054; female
816,320) (2002 est.)
Population growth rate: 1 .68% (2002 est.)
Birth rate: 23.69 births/1,000 population (2002 est.)
Death rate: 5.86 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .09 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 46.49 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.73 years
male: 67.49 years
female: 72.08 years (2002 est.)
Total fertility rate: 2.97 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.03%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
Religions: Muslim 98.7%, Christian 1 .1%,
Jewish 0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 43.7%
male: 56.6%
female: 31% (1995 est.)','4a4f3615b636ecd1ef700a1dcad42ddb2e76fe50d3cb42db1b8ba9c23366a2ed','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2cc275cd419759b6c53c37fa73c91efbcef9424b1b67c351605b77e2442bd46',2002,'GR','Greece','people-and-society',565,'Population: 10,645,343 (July 2002 est.)
Age structure:
0-14 years: 14.8% (male 814,605; female 765,613)
15-64 years: 67.1% (male 3,579,945; female
3,564,068)
65 years and over: 18.1% (male 851,087; female
1,070,025) (2002 est.)
Population growth rate: 0.2% (2002 est.)
Birth rate: 9.82 births/1 ,000 population (2002 est.)
Death rate: 9.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .96 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 6.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.74 years
male: 76. 17 years
female: 81 .48 years (2002 est.)
Total fertility rate: 1.34 children born/woman
(2002 est.)
HiV/AIDS - adult prevalence rate: 0.16%
(1999 est.)
203
Greece (continued)
HIV/AIDS - people living with HIV/AIDS: 8,000
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox98%, Muslim 1.3%, other
0.7%
Languages: Greek 99% (official). English. French
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98.5%
female: 96% (1999)','9efdd556a37d23d2fd98d19d1c29366465c4152669103ba4f36c63670c549576','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea21fa5360569ac8e6ccc4827c1c6fa6830632a2100c6143c5244667d29df41f',2002,'GL','Greenland','people-and-society',574,'Population: 56,376 (July 2002 est.)
Age structure:
0-14 years: 26.3% (male 7,561 ; female 7,284)
15-64 years: 68.1 % (male 20,880; female 17,489)
65 years and over: 5.6% (male 1 ,442; female 1 ,720)
(2002 est.)
Population growth rate: 0.03% (2002 est.)
Birth rate: 16.27 births/1 ,000 population (2002 est.)
Death rate: 7.61 deaths/1 ,000 population (2002 est.)
Net migration rate: -8.37 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 1 .19 male(s)/female
65 years and over: 0.84 ma!e(s)/female
total population: 1.13 male(s)/female (2002 est.)
Infant mortality rate: 17.28 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.69 years
male: 65.13 years
female: 72.32 years (2002 est.)
Total fertility rate: 2.43 children born/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: 100
(1999)
HIV/AIDS -deaths: NA
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 88% (Inuit and
Greenland-born whites), Danish and others 12%
(January 2000)
Religions: Evangelical Lutheran
Languages: Greenlandic (East Inuit), Danish,
English
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: similar to Denmark proper
Population: no indigenous inhabitants
note: personnel operate the Long Range Navigation
(Loran-C) base and the weather and coastal services
radio station (July 2002 est.)','002accabc7d65073cd3566521d55554ec185d32551150bfda714d73c6923cdd5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8f66b377d3c2bd7ac18e8d7d19c548424dd5024b4828e7015b7cd55775ae39d',2002,'GD','Grenada','people-and-society',582,'Population: 89,211 (July 2002 est.)
Age structure:
0-14 years: 35.9% (male 16,213; female 15,863)
15-64 years: 60.3% (male 28,460; female 25,307)
65 years and over: 3.8% (male 1 ,546; female 1 ,822)
(2002 est.)
Population growth rate: 0.02% (2002 est.)
Birth rate: 23.05 births/1,000 population (2002 est.)
Death rate: 7.63 deaths/1 ,000 population (2002 est.)
Net migration rate: -15.21 miorant(s)/1,000
population (2002 est.)
Sex ratio:
af birth: 1 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .12 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.08 male(s)/female (2002 est.)
Infant mortality rate: 1 4.63 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.52 years
male: 62.74 years
female: 66.31 years (2002 est.)
Total fertility rate: 2.5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black 82%, mixed black and
European 13%, European and East Indian 5% , and
trace of Arawak/Carib Amerindian
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 435,739 (July 2002 est.)
Age structure:
0-14 years: 24.9% (male 55,393; female 53,047)
15-64 years: 66.2% (male 142,945; female 145,757)
65 years and over: 8.9% (male 16,168; female
22,429) (2002 est.)
Population growth rate: 1.04% (2002 est.)
Birth rate: 16.53 births/1 ,000 population (2002 est.)
Death rate: 6.03 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male{s)/female
65 years and over: 0.72 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 9.3 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.35 years
male: 74. 19 years
female: 80.66 years (2002 est.)
Total fertility rate: 1.92 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Guadetoupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 90%
femate:90% (1982 est.)
Population: 1 16,394 (July 2002 est.)
Age structure:
0-14 years: 28.9% (male 17,093; female 16,497)
15-64 years: 64.8% (male 38,718; female 36,689)
65 years and over: 6.3% (male 3,1 88; female 4,209)
(2002 est.)
Population growth rate: 0.37% (2002 est.)
Birth rate: 17.54 births/1,000 population (2002 est.)
Death rate: 6.1 2 deaths/1 ,000 population (2002 est.)
Net migration rate: -7.69 migrant(s)rt,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 16.15 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.82 years
ma/e:71.07years
female: 74.63 years (2002 est.)
Total fertility rate: 2.01 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%, other 7%
Religions: Anglican 47%, Methodist 28%, Roman
Catholic 13%, Hindu Seventh-Day Adventist, other
Protestant
Languages: English, French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 96%
male: 96%
female: 96% (1970 est.)
444
Saint Vincent and the Grenadines (continued)','29a3654f6fad6998afa8b5078e98c8177f7b610c612d79d05a018bc8f1c341bd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb220472e5943dc01c6e1db3f213cdb838069cc60c4c3e9ef290d43ef942039c',2002,'GU','Guam','people-and-society',591,'Population: 160,796 (July 2002 est.)
Age structure:
0-14 years: 35.1% (male 29,706; female 26,813)
15-64 years: 58.6% (male 49,457; female 44,697)
65 years and over: 6.3% (male 5,070; female 5,053)
(2002 est.)
Population growth rate: 1.99% (2002 est.)
Birth rate: 24.09 births/1,000 population (2002 est.)
Death rate: 4.24 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.14 male(s)/fema!e
under 15 years: 1.11 male(s)/female
15-64 years: 1.11 ma!e(s)/female
65 years and over: 1 male(s)/female
total population: 1.1 male(s)/female (2002 est.)
Infant mortality rate: 6.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78 .11 years
male: 75.81 years
female: 80.72 years (2002 est.)
Total fertility rate: 3.73 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 37%, Filipino 26%, white
10%, Chinese, Japanese, Korean, and other 27%
Religions: Roman Catholic 85%, other 15%
(1999 est.)
Languages: English, Chamorro, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 13,314,079 (July 2002 est.)
Age structure:
0-14 years: 41 .8% (male 2,841 ,486; female
2,725,343)
15-64 years: 54.5% (male 3,629,363; female
3,630,273)
65 years and over: 3.7% (male 227,369; female
260,245) (2002 est.)
Population growth rate: 2.57% (2002 est.)
Birth rate: 34.17 births/1 ,000 population (2002 est.)
Death rate: 6.67 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.79 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years : 1 .04 male(s)/female
15-64 years: 1 male(s)/fema1e
65 years and oven 0.87 ma!e(s)/lemale
total population: 1 .01 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 44.55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.85 years
male: 64.1 6 years
female: 69.66 years (2002 est.)
Total fertility rate: 4.51 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.38%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 73,000
(1999 est.)
HIV/AIDS - deaths: 3,600 (1 999 est.)
Nationality:
noun.-Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish
or assimilated Amerindian - in local Spanish called
Ladino), approximately 55%, Amerindian or
predominantly Amerindian, approximately 43%,
whites and others 2%
Religions: Roman Catholic, Protestant, indigenous
Mayan beliefs
Languages: Spanish 60%, Amerindian languages
40% (more than 20 Amerindian languages, including
Quiche, Cakchiquel, Kekchi, Mam, Garifuna, and
Xinca)
Literacy:
definition: age 15 and over can read and write
total population: 63.6%
male: 68.7%
female: 58.5% (2000 est.)','96299950b6a083c323d49b13a2b8cc1d582600729d0c6be46e80c03714b4f326','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efaaf9179e62f546025104f1c05ae1b177ceed1aecefcf739c069eee7b77e177',2002,'GG','Guernsey','people-and-society',600,'Population: 64,587 (July 2002 est.)
Age structure:
£7- 74 years: 1 6% (male 5,250; female 5,101)
15-64 years: 66.7% (male 21 ,356; female 21 ,728)
65 years and over 17.3% (male 4,622; female 6,530)
(2002 est.)
Population growth rate: 0.37% (2002 est.)
Birth rate: 9.69 births/1,000 population (2002 est.)
Death rate: 9.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.87 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years; 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.9 years
male: 76.91 years
female: 83.01 years (2002 est.)
Total fertility rate: 1 .36 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','a5227d2eb0465b8479a1c23ba868e3c1f73c48a410a9d47b85364bb4fcc52bee','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f61aec59b689342b875b48dc36a677258fbc96a4504a89af53531923507c8b30',2002,'GW','Guinea-Bissau','people-and-society',611,'Population: 1 ,345,479 (July 2002 est.)
Age structure:
0-14 years: 41 .9% (male 281,394; female 282,641)
15-64 years: 55.2% (male 353,755; female 388,968)
65 years and over: 2.9% (male 17,130; female
21,591) (2002 est.)
Population growth rate: 2.23% (2002 est.)
Birth rate: 38.95 births/1,000 population (2002 est.)
Death rate: 15.05 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1 .62 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 1 08.54 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 49.8 years
male: 47.47 years
female: 52.2 years (2002 est.)
Total fertility rate: 5.13 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.5% (1 999 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(1999 est.)
HIV/AIDS -deaths: 1,300 (1999 est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 34%
male: 50%
female: 18% (2000 est.)','ab0a3b460cc7be8a8c31bc72ffa09d1fa47242f8d010e1fc78452b1733c1e183','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0972179972b2145469098231bff6fecec70b0004a8f368ed98f87d2d184b0ccd',2002,'BR','Brazil','people-and-society',616,'Population: 698,209
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July
2002 est.)
Age structure:
0-14 years: 27.6% (male 98,198; female 94,397)
15-64 years: 67.4% (male 237,324; female 233,400)
65 years and oven 5% (male 15,510; female 19,380)
(2002 est.)
Population growth rate: 0.23% (2002 est.)
Birth rate: 17.89 births/1 ,000 population (2002 est.)
Death rate: 9.33 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1. 05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.8 male(s)/fema1e
total population: 1.01 ma!e(s)/female (2002 est.)
Infant mortality rate: 38.37 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.59 years
male: 59.96 years
female: 65.34 years (2002 est.)
Total fertility rate: 2.09 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 3.01 %
(1999 est.)
HIV/AIDS - people living with HiV/AIDS: 15,000
(1999 est.)
HIV/AIDS -deaths: 900 (1999 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 50%, black 36%,
Amerindian 7%, white, Chinese, and mixed 7%
Religions: Christian 50%, Hindu 35%, Muslim 10%,
other 5%
Languages: English, Amerindian dialects, Creole,
Hindi, Urdu
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98.1%
male: 98.6%
female: 97.5% (1995 est.)','e702954c011a709970d913214088d8b04bd83e76c47258c712e9cbc72487beb8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b667d61994098024a38e89bda9022af8a0e7dabacb89fc3768926bbff071b41c',2002,'HT','Haiti','people-and-society',625,'Population: 7,063,722
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0- 14 years : 39.5% (male 1 ,41 4,052; female
1,377,693)
15-64 years: 56.3% (male 1 ,924,867; female
2,049,952)
65 years and over: 4.2% (male 142,657; female
154,501) (2002 est.)
Population growth rate: 1 .42% (2002 est.)
Birth rate: 31.42 births/1 ,000 population (2002 est.)
Death rate: 14.88 deaths/1 ,000 population
(2002 est.)
Net migration rate: -2.31 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 93.35 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 49.55 years
male: 47.88 years
female: 51 .29 years (2002 est.)
225
Haiti (continued)
Total fertility rate: 4.3 children bom/woman
(2002 esl.)
HIV/AIDS - adult prevalence rate: 5.17%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 210,000
(1999 est.)
HIV/AIDS - deaths: 23,000 (1999 est.)
Nationality:
noun : Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto and white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%,
other 1%), none 1%, other 3% (1982)
note: roughly half of the population also practices
Voodoo
Languages: French (official), Creole (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 45%
male: 48%
female: 42.2% (1995 est.)','06a30fad1e144ff14ec2dd5c6652dda289d58928f905c50579c3898b3f5a142f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf1aca8b7a79fccdfa22c2cf0b3e6b3faec33558a90706810f09f3f8361cf43',2002,'HM','Heard Island and McDonald Islands','people-and-society',633,'Population: uninhabited (July 2002 est.)
Population: 900 (July 2002 est.)
Population growth rate: 1.15% (2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, French, various other
languages
Literacy:
definition: NA
total population: 100%
male: NA%
female: NA%','739ad7f1024dfa5743e07e63e65c38f2bad12b0f4d7b4a4b56998728e2f7b6bb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cce150274f7b7220730eacfe4aabbe4ba49fb39dc42f6240315cb1a1a1babe5',2002,'HU','Hungary','people-and-society',643,'Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2002 est.)
Population: 10,075,034 (July 2002 est.)
Age structure:
0-14 years: 16.4% (male 847,081; female 802,340)
15-64 years: 68.8% (male 3,406,701; female
3,528,087)
65 years and over: 14.8% (male 544,956; female
945,869) (2002 est.)
Population growth rate: -0,3% (2002 est.)
Birth rate: 9.34 births/1,000 population (2002 est.)
Death rate: 1 3.09 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.76 migrant(s)/1 ,000
population (2002 est.)
235
Hungary (continued)
Sex ratio:
at birth: 1 .07 male(s)/fema!e
under 15 years: 1.06 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over : 0.58 male(s)/female
total population: 0.91 male(s)/fema!e (2002 est.)
Infant mortality rate: 8.77 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71.9 years
male: 67.55 years
female: 76.55 years (2002 est.)
Total fertility rate: 1.25 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Roma 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 98.2%, other 1 .8%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1980 est.)
Population: 279,384 (July 2002 est.)
Age structure:
0-14 years: 23% (male 33,189; female 31,155)
15-64 years: 65.1% (male 91,704; female 90,199)
65 years and over: 1 1 .9% (male 14,828; female
18,309) (2002 est.)
Population growth rate: 0.52% (2002 est.)
Birth rate: 14.37 births/1 ,000 population (2002 est.)
Death rate: 6.93 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.27 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .08 male(s)/female
under 15 years: 1.07 ma!e(s)/female
15-64 years : 1.02 ma1e(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 3.53 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.66 years
male: 71.42 years
female : 82.07, years (2002 est.)
Total fertility rate: 1 .99 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.14%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 200
(1999 est.)
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norse and Celts
Religions: Evangelical Lutheran 93%, other
Protestant and Roman Catholic, none (1997)
Languages: Icelandic
Literacy:
definition: age 15 and over can read and write
total population: 99.9% (1997 est.)
male: NA%
female: NA%','f9ce6404131aeb629e965e6e5541b8b9063189ca0a2602acc78c7f00beee8a67','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('144f646aadfe224044076e481f9a9e97470604093de63ae448e91a91dff5b575',2002,'IN','India','people-and-society',653,'Population: 1,045,845,226 (July 2002 est.)
Age structure:
0-14 years: 32.7% (male 175,858,386; female
165,724,901)
15-64 years: 62.6% (male 338,957,463; female
316,063,497)
65 years and over: 4.7% (male 24,975,465; female
24,265,514) (2002 est.)
Population growth rate: 1 .51 % (2002 est.)
Birth rate: 23.79 births/1 ,000 population (2002 est.)
Death rate: 8.62 deaths/1 ,000 population (2002 est.)
240
India (continued)
Net migration rate: -0.07 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1 ,03 male(s)/female
total population: 1 .07 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 61 .47 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.23 years
male: 62.55 years
female: 63.93 years (2002 est.)
Total fertility rate: 2.98 children bom/woman
(2002 est.)
HIV/AIDS ■ adult prevalence rate: 0.7% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3.7million
(1999 est.)
HIV/AIDS - deaths: 310,000 (1999 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3% (2000)
Religions: Hindu 81.3%, Muslim 12%, Christian
2.3%, Sikh 1.9%, other groups including Buddhist,
Jain, Parsi 2.5% (2000)
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication; Hindu is the national
language and primary tongue of 30% of the people;
there are 1 4 other official languages: Bengali, Telugu,
Marathi, Tamil, Urdu, Gujarati, Malayalam, Kannada,
Oriya, Punjabi, Assamese, Kashmiri, Sindhi, and
Sanskrit; Hindustani is a popular variant of Hindi/Urdu
spoken widely throughout northern India but is not an
official language
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
female: 37.7% (1995 est.)','ae92fb003e17cb9e6b91219a01201e9578056f32c78f827e2bf9e8343365b5bf','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b9e96de826add14fa4b9d24e89dae82d3759c945aeb5f77aae267baacced0cd',2002,'IQ','Iraq','people-and-society',663,'Population: 24,001 ,81 6 (July 2002 est.)
Age structure:
0-14 years: 41 .1% (male 5,003,755; female
4,849,238)
15-64 years: 55.9% (male 6,794,265; female
6,624,662)
65 years and over: 3% (male 341 ,520; female
388,376) (2002 est.)
Population growth rate: 2.82% (2002 est.)
Birth rate: 34.2 births/1,000 population (2002 est.)
Death rate: 6.02 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth : 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.88 male(s)/1emale
total population: 1.02 male(s)/female (2002 est.)
Infant mortality rate: 57.61 deaths/1,000 live births
(2002 est.)
I
Iraq (continued)
Life expectancy at birth:
total population: 67. 38 years
male: 66.31 years
female: 68.5 years (2002 est.)
Total fertility rate: 4.63 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 1 5%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 70.7%
female: 45% (1995 est.)','cf8227e549bc31986a6de9a6019e024ef91650f49ffc4c42d05c7a08478aa28a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07943e58a82edfe1c5d4cf979a2f8a6576da611d971b39daa7f08416b17cc4d5',2002,'IE','Ireland','people-and-society',673,'Population: 3,883,159 (July 2002 est.)
Age structure:
0-14 years : 21 .3% (male 425,366; female 403,268)
15-64 years: 67.3% (male 1 ,307,469; female
1,305,038)
65 years and over: 11.4% (male 191,927; female
250,091) (2002 est.)
Population growth rate: 1.07% (2002 est.).
Birth rate: 14.62 births/1 ,000 population (2002 est.)
Death rate: 8.01 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.07 ma!e(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 1 ma!e(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.98 male(s)/fema!e (2002 est.)
Infant mortality rate: 5.43 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.17 years
male: 74.41 years
female: 80.12 years (2002 est.)
Total fertility rate: 1 .9 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.1% (1999 est.)
HiV/AIDS - people living with HIV/AIDS: 2,200
(1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Irishman(men), Irishwoman(women), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 91 .6%, Church of Ireland
2.5%, other 5.9% (1998)
Languages: English is the language generally used,
Irish (Gaelic) spoken mainly in areas located along the
western seaboard
Literacy:
definition : age 15 and over can read and write
total population: 98% (1981 est.)
male: NA%
female: NA%','d89940f56dc10574347a8ada96ddb76c0533f84198dc866aeb2bb707ef7aad7d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc784de6cc5cb882eb66c6a678efc90a172faef7081eff13bd92e651efc0915',2002,'TN','Tunisia','people-and-society',683,'Population: 57,715,625 (July 2002 est.)
Age structure:
0-14 years: 14.1% (male 4,198,569; female
3,954,159)
15-64 years: 67. 3% (male 19,334,208; female
19,492,048)
65 years and over: 1 8.6% (male 4,436,073; female
6,300,568) (2002 est.)
Population growth rate: 0.05% (2002 est.)
Birth rate: 8.93 births/1 ,000 population (2002 est.)
Death rate: 10.1 3 deaths/1 ,000 population
(2002 est.)
Net migration rate: 1.73 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 5.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.25 years
male: 76.08 years
female: 82.63 years (2002 est.)
Total fertility rate: 1.19 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.35%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 95,000
(1999 est.)
HIV/AIDS -deaths: 1,000 (1999 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-ltalians in the north
and Albanian-ttalians and Greek-ltaiians in the south)
Religions: predominately Roman Catholic with
mature Protestant and Jewish communities and a
growing Muslim immigrant community
Languages: Italian (official), German (parts of
Trentino-Alto Adige region are predominantly German
speaking), French (small French-speaking minority in
Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 98% (1998)
male: NA%
female: NA%','aa5e61138847c5973b4959f478c231204d900c29da3ccaede5d6e7f8a422d089','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c956e41d366976b9ef7ec9c3d0e958c8e39658a5cb4310011fa7e4b558604d4',2002,'JM','Jamaica','people-and-society',692,'Population: 2,680,029 (July 2002 est.)
Age structure:
0-14 years: 29.1% (male 399,249; female 380,864)
T5-64 years: 64.1% (male 858,433; female 859,174)
65 years and over: 6.8% (male 81 ,321 ; female
100,988) (2002 est.)
Population growth rate: 0.56% (2002 est.)
Birth rate: 17.74 births/1 ,000 population (2002 est.)
Death rate: 5.45 deaths/1 ,000 population (2002 est.)
Net migration rate: -6.65 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 mate(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 ma!e(s)/female
65 years and over: 0.81 ma!e(s)/female
total population: 1 ma!e(s)/female (2002 est.)
Infant mortality rate: 13.71 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.64 years
male: 73.65 years
female: 77.73 years (2002 est.)
Total fertility rate: 2.05 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.71%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: 9,900
(1999 est.)
HIV/AIDS - deaths: 650 (1999 est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.9%, East Indian 1.3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.1%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 2.7%, United
Church 2.7%, Brethren 1 .1%, Jehovah''s Witness
1.6%, Moravian 1.1%), Roman Catholic 4%, other,
including some spiritual cults 34.7%
Languages: English, patois English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 85%
male: 80.8%
female: 89.1% (1995 est.)','6a916f5cd6860e53cd174b15df5992aa801a32cb43b2e614f8e622617ca5ea6b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f09361f44617c4791cf93ab2decc2a0c2d2b16b4f885762fa61ba53ccfbb12f',2002,'MH','Marshall Islands','people-and-society',703,'Population: no indigenous inhabitants
note: in previous years , there was an average of 1 ,1 00
US military and civilian contractor personnel present;
as of 1 September 2001, population had decreased
significantly when US Army Chemical Activity Pacific
(USACAP) departed (July 2002 est.)
Population: 5,307,470 (July 2002 est.)
Age structure:
0-14 years: 36.6% (male 991,370; female 949,247)
15-64 years: 60% (male 1 ,698,568; female
1,485,261)
65 years and over: 3.4% (male 90,186; female
92,838) (2002 est.)
Population growth rate: 2.89% (2002 est.)
Birth rate: 24.58 births/1,000 population (2002 est.)
Death rate: 2.62 deaths/1 ,000 population (2002 est.)
Net migration rate: 6.97 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .14 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.1 ma!e(s)/female (2002 est.)
Infant mortality rate: 19.61 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.71 years
male: 75.26 years
female: 80.3 years (2002 est.)
Total fertility rate: 3.15 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS - people living with HIWAIDS: NA
HIV/AIDS- deaths: NA
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1%,
Armenian 1%
Religions: Sunni Muslim 92%, Christian 6%
(majority Greek Orthodox, but some Greek and
Roman Catholics, Syrian Orthodox, Coptic Orthodox,
Armenian Orthodox, and Protestant denominations),
other 2% (several small Shi''a Muslim and Druze
populations) (2001 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 15 and over can read and write
total population: 86.6%
male: 93.4%
female: 79.4% (1995 est.)','04f1d48f43de91d4b0563793fbc93870137205ba8d1c60388bcf576b24018b62','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05b7bde638828cf7f0471684710a5584665dd266cecae6f67aacc0be3137d6c5',2002,'KZ','Kazakhstan','people-and-society',714,'Population: 16,741,519 (July 2002 est.)
Age structure:
0-14 years: 26% (male 2,212,985; female 2,141,392)
15-64 years: 66.5% (male 5,393,281 ; female
5,731,288)
65 years and over: 7.5% (male 434,879; female
827,694) (2002 est.)
Population growth rate: 0.1% (2002 est.)
Birth rate: 17.83 births/1 ,000 population (2002 est.)
Death rate: 10.69 deaths/1 ,000 population
(2002 est.)
Net migration rate: -6.16 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male (s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.53 male(s)/female
total population: 0.92 male(s)/female (2002 est.)
Infant mortality rate: 58.95 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.38 years
male: 58.02 years
female: 69.01 years (2002 est.)
Total fertility rate: 2.12 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.04%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,500
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 53.4%, Russian
30%, Ukrainian 3.7%, Uzbek 2.5%, German 2.4%,
Uighur 1 .4%, other 6.6% (1999 census)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq, state language)
64.4%, Russian (official, used in everyday business,
designated the "language of interethnic
communication") 95% (2001 est.)
Literacy:
definition : age 1 5 and over can read and write
total population: 98 .4%
male: 99.1%
female: 97.7% (1999 est.)','e4639ccba493b0c0910b2b34c6d0b2b53d932401545c161240fa1408aa6a1acc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc6432df399daca4167fb3c7710aadd897782ce4e528b8b93f8189eff13392ec',2002,'KE','Kenya','people-and-society',723,'Population: 31,138,735
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 41 .1% (male 6,462,430; female
6,327,457)
15-64 years: 56.1% (male 8,769,546; female
8,694,329)
65 years and over 2.8% (male 385,361 ; female
499,612) (2002 est.)
Population growth rate: 1.15% (2002 est.)
Birth rate: 27.61 births/1 ,000 population (2002 est.)
Death rate: 14.68 deaths/1,000 population
(2002 est.)
Net migration rate: -1 .48 mrgrant(s)/1 ,000
population
note: according to UNHCR, by the end of 2001 Kenya
was host to 220,000 refugees from neighboring
countries, including: Somalia 145,000 and Sudan
68,000 (2002 est.)
Sex ratio:
at birth: 1 .03 ma!e(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.77 ma!e(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 67.24 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47.02 years
male: 46.2 years
female: 47.85 years (2002 est.)
Total fertility rate: 3.34 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 3.5%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2.2million
(2000 est.)
HIV/AIDS - deaths: 180,000 (1999 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant 45%, Roman Catholic 33%,
indigenous beliefs 10%, Muslim 10%, other 2%
note: a large majority of Kenyans are Christian, but
estimates for the percentage of the population that
adheres to Islam or indigenous beliefs vary widely
Languages: English (official), Kiswahili (official),
numerous indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 78.1%
male: 86.3%
female: 70% (1995 est.)
Population: uninhabited (July 2002 est.)','9bf32e246ad971eeed234cf900701ca620685d439e5ede119656804427755563','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('025ec2a09ac30614e28d19403776a04c89d021e2431ef4274970a4ff84a8e752',2002,'KI','Kiribati','people-and-society',729,'Population: 96,335 (July 2002 est.)
Age structure:
0-14 years: 40.2% (male 19,588; female 19,092)
15-64 years: 56.6% (male 26,905; female 27,625)
65 years and over: 3.2% (male 1 ,339; female 1 ,786)
(2002 est.)
Population growth rate: 2.28% (2002 est.)
Birth rate: 31 .58 births/1 ,000 population (2002 est.)
Death rate: 8.76 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1 .05 ma!e(s)/femate
under 15 years: 1 .03 male(s)/female
15-64 years : 0.97 male(s)/lemale
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 52.63 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.54 years
male: 57.61 years
female: 63.62 years (2002 est.)
Total fertility rate: 4.32 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: l-Kiribati (singular and plural)
adjective: l-Kiribati
Ethnic groups: predominantly Micronesian with
some Polynesian
Religions: Roman Catholic 52%, Protestant
(Congregational) 40%, some Seventh-Day Adventist,
Muslim, Baha''i, Latter-day Saints, and Church of God
(1999)
Languages: l-Kiribati, English (official)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 22,224,195 (July 2002 est.)
Age structure:
0-14 years: 25.4% (male 2,888,478; female
2,747,133)
15-64 years: 67.4% (male 7,380,183; female
7,612,275)
65 years and over: 7.2% (male 527,256; female
1,068,870) (2002 est.)
Population growth rate: 1.1% (2002 est.)
Birth rate: 17.95 births/1,000 population (2002 est.)
Death rate: 6,96 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1,05 male(s)/fema!e
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 ma!e(s)/female
65 years and over: 0.49 male(s)/fema!e
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 22.8 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .3 years
male: 68.31 years
female: 74.44 years (2002 est.)
Total fertility rate: 2.22 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions: traditionally Buddhist and Confucianist,
some Christian and syncretic Chondogyo (Religion of
the Heavenly Way)
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Literacy:
definition: age 1 5 and over can read and write Korean
total population: 99%
mate: 99%
female: 99% (1990 est.)
Population: 48.324 million (July 2002 est.)
Age structure:
0-1 4 years: 21.4% (male 5,488,808; female
4,875,379)
15-64 years: 71% (male 17,404,645; female
16,894,361)
65 years and over: 7. 6% (male 1,434,873; female
2,225,934) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 14,55 births/1 ,000 population (2002 est.)
Death rate: 6.02 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.11 mate(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 1.03 male(s)/fema!e
65 years and over: 0.65 male(s)/female
total population: 1,01 male(s)/female (2002 est.)
Infant mortality rate: 7.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.88 years
male: 71.2 years
282
Korea, South (continued)
female: 78.95 years (2002 est.)
Total fertility rate: 1.72 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,800
(1999 est.)
HIV/AIDS -deaths: 180 (1999 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christian 49%, Buddhist 47%,
Confucianist 3%, Shamanist, Chondogyo (Religion of
the Heavenly Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99.3%
female: 96.7% (1995 est.)','a66dfd18a8c9ee309790157c128d8b6c46d3b2aad5f4d548a09305f8b46ac61a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cb92ac1a4310f5a17d6789bf486da4d8cc6555d80f7027bf86d0ee0cc22e4d0',2002,'KG','Kyrgyzstan','people-and-society',737,'Population: 4,822,1 66 (July 2002 est.)
Age structure:
0-14 years: 34.4% (male 838,224; female 821,230)
15-64 years: 59 .4% (male 1 ,403,328; female
1,459,914)
65 years and oven 6.2% (male 1 1 3,861 ; female
185,609) (2002 est.)
Population growth rate: 1.45% (2002 est.)
Birth rate: 26.11 births/1,000 population (2002 est.)
Death rate: 9.1 deaths/1 ,000 population (2002 est.)
Net migration rate: -2.51 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 ma!e(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
infant mortality rate: 75.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.56 years
male: 59.35 years
female: 67.98 years (2002 est.)
Total fertility rate: 3.16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kyrgyz 52.4%, Russian 1 8%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kyrgyz - official language, Russian -
official language
note: in December 2001 , the Kyrgyzstani legislature
made Russian an official language, equal in status to
Kyrgyz
Literacy:
definition: age 15 and over can read and write
total population: 97%
mate: 99%
female: 96% (19B9 est.)','0702345de1c986aad8c36bd3a00161334c5b0d2892f3964a22d5bf93d088bf54','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cda72432890d4935fa34cfdb6adddd848bd37be2d5192743957a6937f327012',2002,'LB','Lebanon','people-and-society',748,'Population: 3,677,780 (July 2002 est.)
Age structure:
0-14 years: 27.3% (male 51 1 ,902; female 491 ,804)
15-64 years: 65.9% (male 1,157,688; female
1,267,106)
65 years and over: 6.8% (male 1 1 3,341 ; female
135,939) (2002 est.)
Population growth rate: 1 .36% (2002 est.)
Birth rate: 19.96 births/1,000 population (2002 est.)
Death rate: 6.35 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.83 male(s)/fema!e
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 27.39 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 ,79 years
mate: 69.38 years
female: 74.32 years (2002 est.)
Total fertility rate: 2.02 children bom/woman
(2002 est, )
HIV/AIDS • adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Muslim 70% (including Shi''a, Sunni,
Druze, Isma''ilite, Alawite or Nusayri), Christian 30%
(including Orthodox Christian, Catholic, Protestant),
Jewish NEGL%
Languages: Arabic (official), French, English,
Armenian
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)
Population: 2,207,954
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 39% (male 433,229; female 427,926)
15-64 years: 56.3% (male 600,476; female 642,538)
65 years and over: 4.7% (male 43,691 ; female
60,094) (2002 est.)
Population growth rate: 1.33% (2002 est.)
Birth rate: 30.72 births/1,000 population (2002 est.)
Death rate: 1 6.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1. 03 male(s)/fema!e
under 15 years: 1 .01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 82.57 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 47 years
male: 46.3 years
female: 47.8 years (2002 est.)
Total fertility rate: 4.01 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 23.57%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS - deaths: 1 6,000 (1 999 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians,
and other 0.3%,
Religions: Christian 80%, indigenous beliefs 20%
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 72%
female: 93% (1999 est.)','46250388f077198e7d4d4c9a8529a1692fe1e8873d85942f3e9b641e8ded4eb5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ef6e82e13481130683d2d50237895d702b2463fc88874005adf0d53f6c9abe',2002,'ZA','South Africa','people-and-society',761,'Population: 3,288,198 (July 2002 est.)
Age structure:
0-14 years: 43.3% (male 714,563; female 709,582)
15-64 years: 53.2% (male 854,324; female 894,753)
65 years and over. 3.5% (mate 57,925; female
57,051) (2002 est.)
Population growth rate: 1.91% (2002 est.)
Birth rate: 45.95 births/1,000 population (2002 est.)
Death rate: 16.05 deaths/1,000 population
(2002 est.)
Net migration rate: -10.8 migrant(s)/1 ,000
population
note: by the end of 1 999, all Liberian refugees who
had fled the domestic strife were assumed to have
returned (2002 est.)
Sex ratio:
af birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years : 0.95 male(s)/fema!e
65 years and over: 1 .02 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 130.21 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth;
total population: 51 .8 years
ma/e: 50.33 years
female: 53.33 years (2002 est.)
Total fertility rate: 6.29 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 9% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 125,000
(2001 est.)
HIV/AIDS- deaths: 13,000(2001 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves), Congo People
2.5% (descendants of immigrants from the Caribbean
who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: English 20% (official), some 20 ethnic
group languages, of which a few can be written and
are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1995 est.)
note: these figures are increasing because of the
improving school system
Population; 43,647,658
note: South Africa took a census October 1996 that
showed a population of 40,583,611 (after an official
adjustment for a 6.8% underenumeration based on a
postenumeration survey); estimates for this country
explicitly take into account the effects of excess
mortality due to AIDS; this can result in lower life
expectancy, higher infant mortality and death rates,
lower population and growth rates, and changes in the
distribution of population by age and sex than would
otherwise be expected (July 2002 est.)
Age structure:
0-14 years: 31 .6% (male 6,943,761 ; female
6,849,745)
15-64 years: 63.4% (male 13,377,011; female
14,300,850)
65 years and over: 5% (male 816,222; female
1,360,069) (2002 est.)
Population growth rate: 0.02% (2002 est.)
Birth rate: 20.63 births/1 ,000 population (2002 est.)
Death rate: 18.86 deaths/1 ,000 population
(2002 est.)
Net migration rate: -1.56 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.94 ma!e(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 61 .78 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 45.43 years
male: 45.19 years
female: 45.68 years (2002 est.)
Total fertility rate: 2.38 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 9.94%
(2000 est.)
HIV/AIDS ■ people living with HIV/AIDS: 5.2million
(2000 est.)
HIV/AIDS - deaths: 300,000 (2000 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored
8,6%, Indian 2.6%
Religions: Christian 68% (includes most whites and
Coloreds, about 60% of blacks and abouf 40% of
Indians), Muslim 2%, Hindu 1.5% (60% of Indians),
indigenous beliefs and animisf 28.5%
Languages: 11 official languages, including
Afrikaans, English, Ndebele, Pedi, Sotho, Swazi,
Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy:
definition: age 1 5 and over can read and write
total population: 85%
male: 86%
female: 85% (2000 est.)
Population: no indigenous inhabitants
note: the small military garrison on South Georgia
withdrew in March 2001 , to be replaced by a
permanent group of scientists of the British Antarctic
Survey, which also has a biological station on Bird
Island; the South Sandwich Islands are uninhabited
(July 2002 est.)','edc488a213b1c6501d456874e2a6d8f460a5859a43fa48d7c93029175e14a55c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3f8814deb1dd8644c002e80b1349f3a5a6ba17f92b4a5640b97c83197c6201e',2002,'LY','Libya','people-and-society',765,'Population: 5,368,585
note: includes 662,669 non-nationals, of which an
estimated 500,000 or more are Africans living in Libya
(July 2002 est.)
Age structure:
0-14 years: 35% (male 958,243; female 917,940)
15-64 years : 61 % (male 1 ,694,986; female
1,581,400)
65 years and over: 4% (male 105,500; female
110,516) (2002 est.)
Population growth rate: 2.41% (2002 est.)
Birth rate: 27.59 births/1,000 population (2002 est.)
Death rate: 3.5 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1.04 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 0,95 male(s)/female
total population: 1.06 male(s)/female (2002 est.)
Infant mortality rate: 27.9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.86 years
male: 73.71 years
female: 78.1 1 years (2002 est.)
Total fertility rate: 3.57 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
Libya (continued)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 76,2%
mate: 87.9%
fema/e: 63% (1995 est.)','474796f51a44865fe6fe04df2b34d3b4996a85591407aba24cfaac0b3e6b5750','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6adc3b827970b9586fa91e5bc09007248abf369e31f0ccbe23be96c257713207',2002,'CH','Switzerland','people-and-society',774,'Population: 32,842 (July 2002 est.)
Age structure:
0-14 years: 18.3% (male 3,003; female 3,001)
15-64 years: 70.5% (male 1 1 ,530; female 1 1 ,639)
65 years and over: 1 1 .2% (male 1 ,494; female 2,175)
(2002 est.)
Population growth rate: 0.94% (2002 est.)
Birth rate: 1 1 .24 births/1 ,000 population (2002 est.)
Death rate: 6.76 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.93 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.01 ma1e(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.99 male(s)/fema!e
65 years and over: 0.69 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 4.92 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79. 1 years
male: 75.47 years
female: 82.74 years (2002 est.)
Total fertility rate: 1 .5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7.7%, other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 10 and over can read and write
total population: 100%
male: 100%
female: 100% (1981 est.)','2e0f6e1a359975e2821ac48a5066f86407463df5abc4d66a14679436d7e86eb6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff86eaa0638a12cc8647e5740ced3cda550e5d045587e2e728f8aa5b8de4cd3c',2002,'LT','Lithuania','people-and-society',783,'Population: 3,601,138 (July 2002 est.)
Age structure:
0-14 years: 18.2% (male 333,966; female 319,992)
15-64 years: 68% (male 1,184,969; female
1.265.711)
65 years and oven 1 3.8% (male 1 67,789; female
328.711) (2002 est.)
Population growth rate: -0.25% (2002 est.)
Birth rate: 10.22 births/1,000 population (2002 est.)
Death rate: 12.87 deaths/1 ,000 population
(2002 est.)
Net migration rate: 0.15 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1.04 ma1e(s)/femate
15-64 years: 0.94 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.88 male(s)/female (2002 est.)
Infant mortality rate: 1 4.34 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.42 years
male: 63.54 years
female: 75.6 years (2002 est.)
Total fertility rate: 1 .4 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.02%
(1999 est.)
HIV/AIDS • people living with HIV/AIDS: less than
500 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Lithuanian(s)
aoO''ecfrVe: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Belarusian 1.6%, other 2.1%
Religions: Roman Catholic (primarily), Lutheran,
Russian Orthodox, Protestant, Evangelical Christian
Baptist, Muslim, Jewish
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 98% (1989 est.)','fd4fccd61e07049523e90584ac97604d4914ff2d6fd5bc998a403612f677a800','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbc113b077c88e1ed8737fb85576b84b3b4052b6d3d1885aae406e8414a37ec1',2002,'KM','Comoros','people-and-society',790,'Population: 1 6,473,477 (July 2002 est.)
Age structure:
0-14 years: 45% (male 3,713,700; female 3,696,478)
15-64 years: 51 .8% (male 4,227,931 ; female
4,313,940)
65 years and over: 3.2% (male 241 ,699; female
279,729) (2002 est.)
Population growth rate: 3.03% (2002 est.)
Birth rate: 42.41 births/1,000 population (2002 est.)
Death rate: 12.15 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0,99 male(s)/female (2002 est.)
Infant mortality rate: 81 .9 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 55.74 years
male: 53,45 years
female: 58,1 1 years (2002 est.)
Total fertility rate: 5.77 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.15%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 1 ,000
(1999 est.)
HIV/AIDS -deaths: 870 (1999 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-lndonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-lndonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy;
delinition: age 15 and over can read and write
total population: 80%
male: 88%
female: 73% (1990 est.)','73d3f50537ee0a695ffa4fd38ea9ad98549631899e00f2f42a5fed187643ffaf','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a38bfad64496d5ebd761f6d9a6941645daff10c2f2c83a812d2487c4bf3863f',2002,'MW','Malawi','people-and-society',798,'Population: 10,701,824
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 44% (male 2,358,730; female 2,347,017)
15-64 years: 53.2% (male 2,810,478; female
2,884,601)
65 years and over: 2.8% (male 120,761 ; female
180,237) (2002 est.)
Population growth rate: 1.39% (2002 est.)
Birth rate: 37. 1 3 births/1 ,000 population (2002 est.)
Death rate: 23.2 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/fema!e
15-64 years: 0.97 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 1 1 9.96 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 36.59 years
mate: 36.05 years
female: 37.15 years (2002 est.)
Total fertility rate: 5.04 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 5.96%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 800,000
(1999 est.)
HIV/AIDS - deaths: 70,000 (1999 est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuka, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian,
European
Religions: Protestant 55%, Roman Catholic 20%,
Muslim 20%, indigenous beliefs 3%, other 2%
Languages: English (official), Chichewa (official),
other languages important regionally
Literacy:
definition: age 1 5 and over can read and write
total population: 58%
mate: 72.8%
female: 43.4% (1999 est.)','4fd4a15fe6abb5d78d005df8338b82fb10c3de85700fb61b4df88c15c3578f58','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46d5c0851f7a1e4fe537f158c288375b960177b8ecd5701ae674a3bcb07b2241',2002,'MV','Maldives','people-and-society',807,'Population: 320,165 (July 2002 est.)
Age structure:
0-14 years: 45.3% (male 74,493; female 70,394)
15-64 years: 51.7% (male 84,548; female 81,092)
65 years and over: 3% (male 4,944; female 4,694)
(2002 est.)
Population growth rate: 2.95% (2002 est.)
Birth rate: 37.41 births/1 ,000 population (2002 est.)
Death rate: 7.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 .05 ma!e(s)/female
total population: 1 .05 male(s)/female (2002 est.)
Infant mortality rate: 61 .93 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.93 years
male: 61 .72 years
female: 64.2 years (2002 est.)
Total fertility rate: 5.38 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.05%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: South Indians, Sinhalese, Arabs
Religions: Sunni Muslim
Languages: Maldivian Dhivehi (dialect of Sinhata,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 15 and over can read and write
total population: 93.2%
male: 93.3%
female: 93% (1995 est.)
322
Maldives (continued)','63c2e04fd1ab2a052e6273aee34b86e9331e696b94a463e5fa92ba3d2ef09b6a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36fc6b7a9e9751f9971773b65fe68a206305be6dce94a0b142b1a32656ab2ca1',2002,'ML','Mali','people-and-society',815,'Population: 1 1 ,340,480 (July 2002 est.)
Age structure:
0-14 years: 47.2% (male 2,687,998; female
2,658,605)
15-64 years: 49.8% (male 2,698,789; female
2,950,276)
65 years and over: 3% (male 160,604; female
184,208) (2002 est.)
Population growth rate: 2.97% (2002 est.)
Birth rate: 48.37 births/1 ,000 population (2002 est.)
Death rate: 18.32 deaths/1 ,000 population -
(2002 est.)
Net migration rate: -0.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.96 ma1e(s)/female (2002 est.)
Infant mortality rate: 1 19.63 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 47.39 years
mate: 46.18 years
female: 48.64 years (2002 est.)
Total fertility rate: 6.73 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2001 est.)
HIV/AIDS - deaths: 9,900 (1999 est.)
324
Mali (continued)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke,
Soninke), Peul 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 45%
female: 31% (1998 est.)
Population: 397,499 (July 2002 est.)
Age structure:
0-14 years: 19.7% (male 40,609; female 37,882)
15-64 years: 67.5% (male 135,047; female 133,207)
65 years and over: 12.8% (male 21,215; female
29,539) (2002 est.)
Population growth rate: 0.73% (2002 est.)
Birth rate: 12.76 births/1 ,000 population (2002 est.)
Death rate: 7.77 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.36 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.09 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 5.72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.26 years
male: 75.78 years
female: 80.96 years (2002 est.)
Total fertility rate: 1.91 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.52%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 91%
Languages: Maltese (official), English (official)
Literacy:
definition: age 1 0 and over can read and write
total population : 88.76%
male: 86.91%
female: 89.55% (1995 census)
Population: 73,873 (July 2002 est.)
Age structure:
0-14 years: 17.5% (male 6,601; female 6,324)
15-64 years: 65.3% (male 24,206; female 24,01 0)
65 years and over: 1 7.2% (male 5,097; female 7,635)
(2002 est.)
Population growth rate: 0.52% (2002 est.)
Birth rate: 1 1 .49 births/1 ,000 population (2002 est.)
Death rate: 1 1 .68 deaths/1 ,000 population
(2002 est.)
Net migration rate: 5.41 migrant(s)/1,000
'' population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1,04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 6.3 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.81 years
male: 74.44 years
female: 81 .36 years (2002 est.)
Total fertility rate: 1 .65 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Manxman (men), Manxwoman (women)
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy:
detinition: NA
total population: NA%
male: NA%
female: NA%
Population: 73,630 (July 2002 est.)
Age structure:
0-14 years: 49.1% (male 18,443: female 17,704)
15-64 years: 48.9% (male 18,347; female 17,628)
65 years and over: 2% (male 720; female 788)
(2002 est.)
Population growth rate: 3.89% (2002 est.)
Birth rate: 44.98 births/1,000 population (2002 est.)
Death rate: 6.07 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/fema1e
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1.04 ma!e(s)/female (2002 est.)
Infant mortality rate: 38.68 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.18 years
male: 64,35 years
female: 68.09 years (2002 est.)
Total fertility rate: 6.49 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (widely spoken as a second
language, both English and Marshallese are official
languages), two major Marshallese dialects from the
Malayo-Polynesian family, Japanese
330
Marshall Islands (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 93.7%
mate: 93.6%
female: 93.7% (1999)','4249477370dc18231283c1eca11a387094a4230768ff06f247bd2b32197206f8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('334f2d156b859757f6b5f8381bc7fb1062ddd629ba2362b794352cafdc676304',2002,'MQ','Martinique','people-and-society',825,'Population: 422,277 (July 2002 est.)
Age structure:
0-14 years: 23% (male 49,261 ; female 47,843)
15-64 years: 66.8% (male 140,616; female 141,460)
65 years and over: 10.2% (male 19,274; female
23,823) (2002 est.)
Population growth rate: 0.89% (2002 est.)
Birth rate: 15.37 births/1 ,000 population (2002 est.)
Death rate: 6.4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 7.62 deaths/1 .000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.56 years
male: 79. 19 years
female: 77.92 years (2002 est.)
Total fertility rate: 1 .79 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-lndian
mixture 90%, white 5%, East Indian, Chinese less
than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 93%
male: 92%
female: 93% (1982 est.)
Population: 6,954 (July 2002 est.)
Age structure:
0-14 years: 25.4% (male 904; female 864)
15-64 years: 64.4% (male 2,288; female 2,193)
65 years and over: 1 0.2% (male 303; female 402)
(2002 est.)
Population growth rate: 0.35% (2002 est.)
Birth rate: 14.96 births/1,000 population (2002 est.)
Death rate: 6.61 deaths/1 ,000 population (2002 est.)
Net migration rate: -4.89 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1,04 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 8.18 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.93 years
male: 75.66 years
female: 80.32 years (2002 est.)
Total fertility rate: 2.1 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)','6505608031ab67c119ab4b5d8762b5046ee3783b39ab4cfb763aec457ba4d720','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7168d7169b81639f07f25b1456511eb1964420c700da6958abe1f8d175119cfe',2002,'MR','Mauritania','people-and-society',829,'Population: 2,828,858 (July 2002 est.)
Age structure:
0-14 years: 46.1% (male 653,005; female 650,530)
15-64 years: 51 .7% (male 720,473; female 741 ,094)
65 years and over: 2.2% (male 26,251 ; female
37,505) (2002 est.)
Population growth rate: 2.92% (2002 est.)
Birth rate: 42.54 births/1 ,000 population (2002 est.)
Death rate: 13.34 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years:! male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 ma1e(s)/female (2002 est.)
Infant mortality rate: 75.25 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 51 .53 years
male: 49.42 years
female: 53.71 years (2002 est.)
Total fertility rate: 6.15 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.8% (2000 est.)
HIV/AIDS • people living with HIV/AIDS: 6,600
(1999 est.)
334
Mauritania (continued)
HIV/AIDS -deaths: 610 (1999 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%,
, black 30%
Religions: Muslim 100%
Languages: Hassaniya Arabic (official), Pulaar,
Soninke, Wolof (official), French
Literacy:
definition: age 15 and over can read and write
total population: 41. 2%
male: 51 .5%
fema/e: 31 .3% (2002 est.)','651b9c201477df6eca1017179936cd5a4092b6d7b32e5d0ba78649a229d97607','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565b15585a16a343ce9fe494a1f0de289240b0d6a721920bc7c85b448c829a27',2002,'MU','Mauritius','people-and-society',838,'Population: 1,200,206 (July 2002 est.)
Age structure:
0-14 years: 25 .4% (male 153,810; female 150,464)
15-64 years: 68.3% (male 409,028; female 41 1 ,070)
65 years and over: 6.3% (male 30,1 70; female
45,664) (2002 est.)
Population growth rate: 0.86% (2002 est.)
Birth rate: 16.34 births/1 ,000 population (2002 est.)
Death rate: 6.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.92 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.98 ma!e(s)/female (2002 est.)
Infant mortality rate: 1 6.65 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .53 years
male: 67.54 years
female: 75.58 years (2002 est.)
Total fertility rate: 2 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.08%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIWAIDS- deaths: NA
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%,
other 3.1%
Languages: English (official), Creole, French
(official), Hindi, Urdu, Hakka, Bhojpuri
Literacy:
definition: age 1 5 and over can read and write
total population: 82.9%
male: 87.1%
female: 78.8% (1995 est.)
Population: 170,879 (July 2002 est.)
Age structure:
0-14 years: 46.6% (male 39,927; female 39,628)
15-64 years: 51 .7% (male 48,237; female 40,21 0)
65 years and over: 1 ,7% (male 1 ,429; female 1 ,448)
(2002 est.)
Population growth rate: 4.41% (2002 est.)
Birth rate: 43.59 births/1 ,000 population (2002 est.)
Death rate: 8.58 deaths/1 ,000 population (2002 est.)
Net migration rate: 9.1 1 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1: 03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.2 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1.1 male(s)/female (2002 est.)
Infant mortality rate: 67.76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.21 years
male: 58,12 years
female: 62.37 years (2002 est.)
Total fertility rate: 6.15 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Mahorals (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 97%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
(official language) spoken by 35% of the population
Literacy:
definition: NA
total population: NA%
male: NA%
lemale: NA%','58639ecfe7af22766301766faa469019e566f10904c45a6a1e1e431e0bc05d2c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f3468f8859b45048336d5869535e69703218a0bcfb395311d722c15ad1d28d',2002,'FM','Micronesia, Federated States of','people-and-society',855,'Population: no indigenous inhabitants;
approximately 40 people make up the staff of US Fish
and Wildlife Service and their services cooperator
living at the atoll (April 2002 est.)
Population growth rate: NA
Population: 4,434,547 (July 2002 est.)
Age structure:
0-14 years: 21.7% (male 490,414; female 472.912)
15-64 years : 68.2% (male 1 ,451 ,962; female
1,572,561)
65 years and over: 10.1% (male 165,860: female
280,838) (2002 est.)
Population growth rate: 0.09% (2002 est.)
Birth rate: 13.82 births/1 ,000 population (2002 est.)
Death rate: 12.64 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 ma1e(s)/fema!e
total population: 0.91 male(s)/female (2002 est.)
Infant mortality rate: 42.16 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 64.74 years
male: 60.39 years
female: 69.31 years (2002 est.)
Total fertility rate: 1.71 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 4,500
(1999 est.)
Moldova (continued)
HIV/AIDS • deaths: less than 100 (1999 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldovan/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%, Jewish 1.5%,
Bulgarian 2%, Gagauz and other 5.2% (1989 est.)
note: internal disputes with ethnic Slavs in the
Transnislrian region
Religions: Eastern Orthodox 98.5%, Jewish 1.5%,
Baptist (only about 1,000 members) (1991)
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian (official), Gagauz
(a Turkish dialect)
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 99%
female: 94% (1989 est.)','5411a2c5d3aef3abdbda9f7d9d212090321cac110acb4f553499eac2ebf6a65b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9635a395264c01fa99058881d769682209b799178bf8241fd4684211c158b93',2002,'MC','Monaco','people-and-society',861,'Population: 31 ,987 (July 2002 est.)
Age structure:
0-14 years: 15.5% (male 2,545; female 2,418)
15-64 years: 62.1 % (male 9,762; female 1 0,093)
65 years and over: 22.4% (male 2,922; female 4,247)
(2002 est.)
Population growth rate: 0.45% (2002 est.)
Birth rate: 9.6 births/1 ,000 population (2002 est.)
Death rate: 12.91 deaths/1 ,000 population
(2002 est.)
Net migration rate: 7.82 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.91 male(s)/female (2002 est.)
Infant mortality rate: 5.73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.12 years
male: 75.21 years
female: 83.25 years (2002 est.)
Total fertility rate: 1 .76 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS. deaths: NA
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 90%
Languages: French (official), English, Italian,
Monegasque
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%','a3a3fd4ddb91b7f2b84d0babe85930404cdfa8c6aec4c6bf71efff7f6570a187','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ecc2825be3d3ce085ae77a3ba17dc4f6b862d40b9385ebd78c45c59e55d97d',2002,'MS','Montserrat','people-and-society',868,'Population: 8,437
note: an estimated 8,000 refugees left the island
following the resumption of volcanic activity in
July 1995; some have returned (July 2002 est.)
Age structure:
0-14 years: 23.6% (male 1,001; female 986)
15-64 years: 65% (male 2,624; female 2,864)
65 years and over: 1 1 .4% (male 508; female 454)
(2002 est.)
Population growth rate: 8.43% (2002 est.)
Birth rate: 17,54 births/1 ,000 population (2002 est.)
Death rate: 7.47 deaths/1 ,000 population (2002 est.)
Net migration rate: 74.2 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 7.98 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.2 years
male: 76.1 years
female: 80.4 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)','213829110957045bfca23cdf91c6442af7080958b8ef9ecaa6b65d487a37becc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f48a0eab7c4f1faa4553b035d19d5e5953c4f07584102e9e0f8ed065d5dc2f77',2002,'NA','Namibia','people-and-society',878,'Population: 1,820,916
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 42.6% (male 392,706; female 382,690)
15-64 years: 53.7% (male 490,151; female 488,052)
65 years and over: 3.7% (male 29,345; female
37,972) (2002 est.)
Population growth rate: 1.19% (2002 est.)
Birth rate: 34.17 births/1 ,000 population (2002 est.)
Death rate: 22,28 deaths/1,000 population
(2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/fema!e
under 15 years: 1.03 male(s)/fema!e
15-64 years: 1 male(s)/femate
65 years and over: 0.77 ma!e(s)/fema!e
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 72.43 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 38.97 years
male: 40.81 years
female: 37.07 years (2002 est.)
Total fertility rate: 4.77 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 19.54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000
(1999 est.)
HIV/AIDS -deaths: 18,000 (1999 est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 87.5%, white 6%, mixed 6.5%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero 7%, Damara 7%, Nama 5%,
Caprivian 4%. Bushmen 3%, Baster 2%,
Tswana 0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
least), indigenous beliefs 10% to 20%
Languages: English 7% (official). Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
tola! population: 38%
male: 45%
female: 31% (1960 est.)
Population: 12,329 (July 2002 est.)
Age structure:
0-14 years: 39.6% (male 2,515; female 2,366)
15-64 years: 58.7% (male 3,578; female 3,656)
65 years and over: 1 .7% (male 1 08; female 1 06)
(2002 est.)
Population growth rate: 1.96% (2002 est.)
Birth rate: 26.6 births/1 ,000 population (2002 est.)
Death rate: 7.06 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .06 male(s)/ female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1.01 male(s)/fema!e (2002 est.)
Infant mortality rate: 10.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .57 years
male: 58.05 years
female: 65.26 years (2002 est.)
Total fertility rate: 3.5 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy:
definition: NA
362
Nauru (continued) ,
total population: NA%
male: NA%
female: NA%
Population: uninhabited
note: transient Haitian fishermen and others camp on
the island (July 2002 est.)','4164df23e735a3672799880ad1f789dad5cec8c2897c03b6515a523fcd7ba841','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb3f69ca58d8eaccb21a12f6a80a43b115e690c72895754f74c2a8458a2bc781',2002,'NL','Netherlands','people-and-society',889,'Population: 16,067,754 (July 2002 est.)
Age structure:
0-14years: 18.3% (male 1,502,687; female
1,437,141)
15-64 years: 67. 9% (male 5,548,188; female
5,362.412)
65 years and over: 13.8% (male 913.020; female
1,304.306) (2002 est.)
Population growth rate: 0.53% (2002 est.)
Birth rate: 1 1 .58 births/1 ,000 population (2002 est.)
Death rate: 8.67 deaths/1 ,000 population (2002 est.)
Net migration rate: 2.35 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.04 male(s)/female
under 15 years: 1 .05 male(s)/fema1e
15-64 years: 1 .03 male(s)/femaie
65 years and over: 0.7 male(s)/female
total population: 0.98 ma!e(s)/femaie (2002 est.)
Infant mortality rate: 4.31 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.58 years
male: 75.7 years
female: 81 .59 years (2002 est.)
Total fertility rate: 1 .65 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.19%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(1999 est.)
HIV/AIDS -deaths: 100 (1999 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 83%, other 17% (of which 9%
are non-western origin mainly Turks, Moroccans,
Antilleans, Surinamese and Indonesians) (1999 est.)
Religions: Roman Catholic 31%, Protestant 21%,
Muslim 4.4%, other 3.6%, unaffiliated 40% (1998)
Languages: Dutch
Literacy:
definition: age 15 and over can read and write
total population : 99% (2000 est.)
male: NA%
female: NA%
Population: 214,258 (July 2002 est.)
Age structure:
0-14 years: 25% (male 27,351 ; female 26,135)
15-64 years: 67.1% (male 68,431; female 75,312)
65 years and over: 7.9% (male 7,049: female 9,980)
(2002 est.)
Population growth rate: 0.93% (2002 est.)
Birth rate: 1 6.16 births/1 ,000 population (2002 est.)
Death rate: 6.4 deaths/1,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.71 ma!e(s)/fema!e
total population: 0.92 male(s)/female (2002 est.)
Infant mortality rate: 1 1 .06 deaths/1 ,000 live bidhs
(2002 est.)
Life expectancy at birth:
total population: 75.1 5 years
male: 72.96 years
female: 77.46 years (2002 est.)
Total fertility rate: 2.06 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Dutch Antillean(s)
adjective: Dutch Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Poduguese-Dutch-English dialect)
predominates, English widely spoken, Spanish
370
Netherlands Antilles (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est.)','a8173842111ddfc1d99395e76e64b554f410204310022eb7bcbab799bf5985cc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d832584f80a787a7999362edb014da598f9b51654d96eb3113473c986bd9c478',2002,'VU','Vanuatu','people-and-society',898,'Population: 3,908,037 (July 2002 est.)
Age structure:
0-14 years: 22.2% (male 443,921 ; female 422,804)
15-64 years: 66.3% (male 1,299,973; female
1,290,097)
65 years and over: 1 1 .5% (male 1 96,640; female
254,602) (2002 est.)
Population growth rate: 1.12% (2002 est.)
Birth rate: 14.23 births/1 ,000 population (2002 est.)
Death rate: 7.55 deaths/1 ,000 population (2002 est.)
Net migration rate: 4.48 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/fema!e
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/femaie
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 6.18 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.1 5 years
male: 75.17 years
female: 81 .27 years (2002 est.)
Total fertility rate: 1.8 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.06%
(1999 est.)
HIV/AIDS ■ people living with HIV/AIDS: 1 ,200
(1999 est.)
HIV/AIDS ■ deaths: less than 1 00 (1 999 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 1 8%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1986)
Languages: English (official), Maori (official)
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 5,023,818 (July 2002 est.)
Age structure:
0-14 years: 38.3% (male 980,621 ; female 945,386)
15-64 years: 58.7% (male 1,464,468; female
1,483,082)
65 years and over: 3% (male 65,61 0; female 84,651 )
(2002 est.)
Population growth rate: 2.09% (2002 est.)
Birth rate: 26.98 births/1 ,000 population (2002 est.)
Death rate: 4.76 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.3 migrant(s)/1 ,000popuiation
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.78 ma!e(s)/female
total population: 1 male(s)/fema!e (2002 est.)
Infant mortality rate: 32.52 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.37 years
male: 67.39 years
female: 71 .44 years (2002 est.)
Total fertility rate: 3.09 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2000/
01 est.)
HIV/AIDS • people living with HIV/AIDS: 4,800
(2000/01 est.)
HIV/AIDS -deaths: 360 (1999 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
377
Nicaragua (continued)
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 85%, Protestant
Languages: Spanish (official)
note: English and indigenous languages on Atlantic
coast
Literacy:
definition: age 15 and over can read and write
total population: 68.2% (1 999)
male: 67.1%
female: 70.5% (2000 est.)
Population: 24,287,670 (July 2002 est.)
Age structure:
0-14 years: 31. 6% (male 3,955,132; female
3,710,159)
15-64 years: 63.6% (male 7,756,362; female
7,695,738)
65 years and over: 4.8% (male 533,559; female
636,720) (2002 est.)
Population growth rate: 1 .52% (2002 est.)
Birth rate: 20.22 births/1 ,000 population (2002 est.)
Death rate: 4.91 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.11 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.02 ma!e(s)/fema!e (2002 est.)
Infant mortality rate: 24.58 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.56 years
male: 70.53 years
female: 76.81 years (2002 est.)
Total fertility rate: 2.41 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.49%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 62,000
(1999 est.)
HIV/AIDS - deaths: 2,000 (1999 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions: nominally Roman Catholic 96%,
Protestant 2%, other 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 91.8%
female: 90.3% (1995 est.)
Population: 81,098,416 (July 2002 est.)
Age structure:
0-14 years: 31 .6% (male 13,259,152; female
12,392,089)
15-64 years: 62.9% (male 24,938,098; female
26,083,681)
65 years and oven 5.5% (male 1 ,749,531 ; female
2,675,865) (2002 est.)
Population growth rate: 1 .43% (2002 est.)
Birth rate: 20.89 births/1,000 population (2002 est.)
Death rate: 6.1 4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.47 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.07 male(s)/fema!e
under 15 years: 1 .07 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.65 ma!e(s)/female
total population: 0.97 male(s)/female (2002 est.)
Infant mortality rate: 29.34 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.86 years
male: 67.4 years
female: 72.5 years (2002 est.)
Total fertility rate: 2.44 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.24%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 100,000
(1999 est.)
HIV/AIDS - deaths: 2,500 (1 999 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese,
Hmong, Thai, Khmer, Cham, mountain groups
Religions: Buddhist, Hoa Hao, Cao Dai, Christian
(predominantly Roman Catholic, some Protestant),
indigenous beliefs, Muslim
Languages: Vietnamese (official), English
(increasingly favored as a second language), some
French, Chinese, and Khmer; mountain area
languages (Mon-Khmer and Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
female: 91 .2% (1 995 est.)','0988de1a0ad955781981d7b459ad78aaaf0cf59f92e9108e03c60a242bbfff9c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad6e8a602010c579fc6e5d99aa8d0d47e595b60faabf040bb59534386d20e20',2002,'NU','Niue','people-and-society',912,'Population: 2,134 (July 2002 est.)
Age structure:
0-U years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 0.5% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Niuean(s)
adjective : Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church - a
Protestant church closely related to the London
Missionary Society) 75%, Latter-Day Saints 10%,
other 15% (mostly Roman Catholic, Jehovah''s
Witnesses, Seventh-Day Adventist)
Languages: Niuean, a Polynesian language closely
related to Tongan and Samoan; English
Literacy:
definition: NA .
total population: 95%
male: NA%
female: NA%','438d55435d0bc9d30a07236ce414031db3203dff3433bb83c69a2056fde969b1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9555341b483c8367602a0b2fc772a356b96eba84fe8a53253d80936e4085850',2002,'PK','Pakistan','people-and-society',925,'Population: 147,663,429 (July 2002 est.)
Age structure:
0-14 years: 39.9% (male 30,321,217; female
28,581,334)
15-64 years: 56% (male 42.254,996; female
40,392,092)
65 years and over: 4.1% (male 2,984,391; female
3,129,399) (2002 est.)
Population growth rate: 2.06% (2002 est.)
Birth rate: 30.4 births/1,000 population (2002 est.)
Death rate: 9.02 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.79 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .06 ma!e(s)/fema!e
15-64 years: 1 .05 male(s)/fema!e
65 years and over: 0.95 ma!e(s)/female
total population: 1.05 male(s)/femate (2002 est.)
Infant mortality rate: 78.52 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 61 .82 years
male: 60.96 years
female: 62.73 years (2002 est.)
Total fertility rate: 4.25 children born/woman
(2002 est.)
HIV/AIDS * adult prevalence rate: 0.1% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: 74,000
(1999 est.)
HIV/AIDS -deaths: 6,500 (1999 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India at the time of
partition and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries). Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 42.7%
male: 55.3%
female: 29% (1998)','3ec8b2d4f84df6f2cb5125bd9368d2a2deb7ce2f461bde782a28629e0fe0e149','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce6b39cb78373b19c81df70d2256a465993b39ab74b53a4defca5400a940d085',2002,'PW','Palau','people-and-society',933,'Population: 19,409 (July 2002 est.)
Age structure:
0-14 years: 26.8% (male 2,678; female 2,522)
15-64 years: 68.6% (male 7,241 ; female 6,074)
65 years and over: 4.6% (male 426; female 468)
(2002 est.)
Population growth rate: 1.61% (2002 est.)
Birth rate: 19.32 births/1,000 population (2002 est.)
Death rate: 7. 1 1 deaths/1 ,000 population (2002 est.)
Net migration rate: 3.86 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.19 male(s)/fema!e
65 years and over: 0.91 male(s)/female
total population: 1.14 male(s)/female (2002 est.)
Infant mortality rate: 16.21 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.1 9 years
male: 66.07 years
female: 72.5 years (2002 est.)
Total fertility rate: 2.47 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauan (Micronesian with Malayan
and Melanesian admixtures) 70%, Asian (mainly
Filipinos, followed by Chinese, Taiwanese, and
Vietnamese) 28%, white 2% (2000 est.)
Religions: Christian (Roman Catholics 49%,
Seventh-Day Adventists, Jehovah''s Witnesses, the
Assembly of God, the Liebenzell Mission, and
Latter-Day Saints), Modekngei religion (one-third of
the population observes this religion which is
indigenous to Palau)
Languages: English and Palauan official in all states .
except Sonsoral (Sonsorolese and English are
official), Tobi (Tobi and English are official), and
Angaur (Angaur, Japanese, and English are official)
Literacy:
definition: age 15 and over can read and write
total population: 92%
male: 93%
female: 90% (1980 est.)
Population: no indigenous inhabitants; 4 to 20
Nature Conservancy staff, US Fish and Wildlife staff
(July 2002 est.)','99fd8ca0281dd46d38b0182c9d0e3b2f4c86c4b6e7e12828d43b7ef5db9382b5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf98478876286439cee98f9900aeb75820884a39cc347cba829fe104eadcec09',2002,'PA','Panama','people-and-society',941,'Population: 2,882,329 (July 2002 est.)
Age structure:
0-14 years: 29.6% (male 433,494; female 418,120)
15-64 years : 64.3% (male 939,550; female 91 4,646)
65 years and over: 6. 1 % (male 84,1 30; female
92,389) (2002 est.)
Population growth rate: 1.26% (2002 est.)
Birth rate: 18.6 births/1,000 population (2002 est.)
Death rate: 4.96 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .04 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .02 male(s)/female (2002 est.)
Infant mortality rate: 19.57 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.89 years
male: 73.14 years
female: 78.74 years (2002 est.)
Total fertility rate: 2.22 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .54%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 24,000
(1999 est.)
HIV/AIDS -deaths: 1,200 (1999 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 15 and over can read and write
total population: 90.8%
male: 91 .4%
female: 90.2% (1995 est.)','a3b075656f5eb3383a05e70cb431ab2ed4d6889dee96d6f989055f5d3c8d18b0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2fe10d2c891150fd129c6bf355e4279bdc47cd6a7af6162829e231e52e7ca77',2002,'PH','Philippines','people-and-society',950,'Population: no indigenous inhabitants
note: there are scattered Chinese garrisons
(July 2002 est.)','944252eeb965db01a7d2d51268fef8d710eab697ed3bd1ea91b8b6f81c45cb81','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd9a6e7fedc8f768c4126a3ab9c14ee15aff168855291cc6cbbbb512d0a43eb4',2002,'PT','Portugal','people-and-society',962,'Population: 10,084,245 (July 2002 est.)
Age structure:
0-14 years: 16.9% (male 875,485; female 827,670)
15-64 years: 67.3% (male 3,324,215; female
3,463,301)
65 years and over: 1 5.8% (male 644,761 ; female
948,813) (2002 est.)
Population growth rate: 0.18% (2002 est.)
Birth rate: 1 1 .5 births/1 ,000 population (2002 est.)
Death rate: 10.21 deaths/1,000 population
(2002 est.)
Net migration rate: 0.5 migrant(s)/1 ,000 population
(2002 est.)
419
Portugal (continued)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 5.84 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 76.14 years
mate: 72.65 years
female: 79.87 years (2002 est.)
Total fertility rate: 1 .48 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.74%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 36,000
(1999 est.)
HIV/AIDS -deaths: 280 (1999 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock;
citizens of black African descent who immigrated to
mainland during decolonization number less than
100,000; since 1990 East Europeans have entered
Religions: Roman Catholic 94%, Protestant (1995)
Languages: Portuguese
Literacy:
definition: age 1 5 and over can read and write
total population: 87.4%
male: NA%
female: NA%','fe8c8a97aade8be117813f388ba225762f492c21bd5980f583f1a1c379ee114f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cb23834ebea9b0f7b69f8f9b9336ecb509e1d3eb5c23305a5e0eb70e8313ad5',2002,'QA','Qatar','people-and-society',969,'Population: 793,341 (July 2002 est.)
Age structure:
0-14 years: 25.2% (male 102,1 10; female 98,053)
15-64 years: 72.1% (male 403,508; female 168,428)
65 years and over: 2.7% (mate 15,299; female 5,943)
(2002 est.)
Population growth rate: 3.02% (2002 est.)
Birth rate: 15,78 births/1 ,000 population (2002 est.)
Death rate: 4.34 deaths/1 ,000 population (2002 est.)
Net migration rate: 18.75 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 2.4 male(s)/female
65 years and over: 2.57 male(s)/female
total population: 1.91 male(s)/fema!e (2002 est.)
Infant mortality rate: 20,73 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.88 years
male: 70 .4 years
424
Qatar (continued)
female: 75.48 years (2002 est.)
Total fertility rate: 3,1 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.09%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 1 5 and over can read and write
total population: 79%
male: 79%
female: 80% (1995 est.)
Population: 743,981 (July 2002 est.)
Age structure:
0-14 years: 31 .7% (male 120,864; female 115,251)
15-64 years: 62.5% (male 228.864; female 235,991)
65 years and over: 5.8% (male 17,459; female
25,552) (2002 est.)
Population growth rate: 1.52% (2002 est.)
Birth rate: 20.7 births/1 ,000 population (2002 est.)
Death rate: 5.51 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2002 est.)
Sex ratio:
af birth: 1.05 mate(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 8.31 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.18 years
mate: 69.78 years
female: 76.74 years (2002 est.)
Total fertility rate: 2.55 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 86%, Hindu, Muslim,
Buddhist (1995)
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)','2782458f1f73fb74167a938da2b141a7ba3d43e484421f2899b51906d7fabd21','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('868caf09df93915f74cbc63c622e93fc297187a50d55af848fd1d5e0037e3858',2002,'UA','Ukraine','people-and-society',977,'Population: 22,317,730 (July 2002 est.)
Age structure:
0-14 years: 17.4% (male 1 ,992,505; female
1,898,122)
15-64 years: 68.8% (male 7,618,801; female
7,726,300)
65 years and over: 13.8% (male 1 ,274,881 ; female
1,807,121) (2002 est.)
Population growth rate: -0.21% (2002 est.)
Birth rate: 10.81 births/1 ,000 population (2002 est.)
Death rate: 12.27 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.6 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/fema!e
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/fema!e
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 18.88 deaths/1,000 live births
(2002 est.)
428
Romania (continued)
Life expectancy at birth:
total population: 70.39 years
male: 66.62 years
female: 74.39 years (2002 est.)
Total fertility rate: 1 .35 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate; 0.02%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,000
(1999 est.)
HIV/AIDS - deaths: 350 (1999 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.5%, Hungarian 7.1%,
Roma 1.8%, German 0.5%, Ukrainian 0.3%,
other 0.8% (1992)
Religions: Romanian Orthodox 70%, Roman
Catholic 6%, Protestant 6%, unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 1 44,978,573 (July 2002 est.)
Age structure:
0-14 years: 16.7% (male 12,334,659; female
11,840,058)
15-64 years: 70.2% (male 49,330,660; female
52,402,610)
65 years and over: 13.1% (male 6,150,775; female
12,919,811) (2002 est.)
Population growth rate: -0.33% (2002 est.)
Birthrate: 9.71 births/1,000 population (2002 est.)
Death rate: 13.91 deaths/1,000 population
(2002 est.)
Net migration rate: 0.94 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.88 male(s)/female (2002 est.)
Infant mortality rate: 19.78 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 67.5 years
male: 62.29 years
female: 72.97 years (2002 est.)
Total fertility rate: 1 .3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 130,000
(1999 est.)
HIV/AIDS -deaths: 850 (1999 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1.2%, Bashkir 0.9%,
Belarusian 0.8%, Moldavian 0.7%, other 8.1%
431
Russia (continued)
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)
Population: 7,398,074
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected (July .
2002 est.)
Age structure:
0-14 years: 41 .7% (male 1,550,141 ; female
1,539,375)
15-64 years: 55.4% (male 2,039,573; female
2,057,059)
65 years and over: 2.9% (male 84,030; female
127,896) (2002 est.)
Population growth rate: 1 ,16% (2002 est.)
Birth rate: 33.28 births/1 ,000 population (2002 est.)
Death rate: 21 .39 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.32 migrant(s)/1 ,000
population (2002 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 ma!e(s)/fema!e
65 years and over: 0.66 ma!e(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 1 1 7.79 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 38.66 years
male: 38.14 years
female: 39.2 years (2002 est.)
Total fertility rate: 4,72 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 1 .21 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400,000
(1999 est.)
HIV/AIDS - deaths: 40,000 (1999 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 84%, Tutsi 15%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 56.5%, Protestant 26%,
Adventist 11.1%, Muslim 4.6%, indigenous beliefs
0.1%, none 1.7% (2001)
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 1 5 and over can read and write
total population: 48%
male: 52%
fema/e:45%(1995est.)
Population: 48,396,470 (July 2002 est.)
Age structure:
0-14 years: 1 6.8% (male 4,147,344; female
3,970,343)
15-64 years: 68.7% (male 15,881 ,821 ; female
17,366,172)
65 years and over: 1 4.5% (male 2,341 ,885; female
4,688,905) (2002 est.)
Population growth rate: -0.72% (2002 est.)
Birth rate: 9.59 births/1,000 population (2002 est.)
Death rate: 1 6.4 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.42 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/iemale
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 ma!e(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.86 male(s)/female (2002 est.)
Infant mortality rate: 21 .14 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.33 years
male: 60.86 years
female: 72.06 years (2002 est.)
Total fertility rate: 1.32 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.96%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(1999 est.)
HIV/AIDS - deaths: 4,000 (1999 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow
Patriarchate, Ukrainian Orthodox - Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 15 and over can read and write
fofaf population: 98%
male: 100%
fema/e: 97% (1989 est.)','c96bdc81c5dcdf3fdb435f9806387baa37dbf8207ce08b34ceecf95fa413c8bf','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ec56b000dd0ea11c2bec3c391d7df96b748c3c79d1c1c84339aa743004b11a7',2002,'UG','Uganda','people-and-society',988,'Population: 7,317 (July 2002 est.)
Age structure:
0-14 years: 18.8% (male 698; female 678)
15-64 years: 71 .9% (male 2,727; female 2,531 )
65 years and over: 9.3% (male 296; female 387)
(2002 est.)
Population growth rate: 0.7% (2002 est.)
Birth rate: 13.26 births/1 ,000 population (2002 est.)
Death rate: 6.29 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
af birth: 1 .04 male(s)/female
under 15 years: 1.03 ma!e(s)/female
15-64 years: 1.08 male(s)/female
65 years and over. 0.77 male(s)/female
total population: 1 .04 male(s)/female (2002 est.)
Infant mortality rate: 21 .54 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 77.2 years
male: 74.31 years
female: 80.23 years (2002 est.)
Total fertility rate: 1 .53 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent 50%, white 25%,
Chinese 25%
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
female: 98% (1987 est.)','3252fe0d992976fae17e201e1ec11160ecd463f37239c9dc9358785e1f4b15cc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a0245d70f6c07308d13c41504bb85ab1cba9a7f9fcbea7c10e5a233340761f0',2002,'TT','Trinidad and Tobago','people-and-society',994,'Population: 38,736 (July 2002 est.)
Age structure:
0-14 years: 29.4% (male 5,827; female 5,571)
15-64 years: 61 .9% (male 1 1 ,980; female 1 2,005)
65 years and over: 8.7% (male 1 ,383; female 1 ,970)
(2002 est.)
Population growth rate: 0.01% (2002 est.)
Birth rate: 18.61 births/1,000 population (2002 est.)
Death rate: 9.04 deaths/1 ,000 population (2002 est.)
Net migration rate: -9.5 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/lemale
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2002 est.)
Infant mortality rate: 1 5.83 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71.29 years
male: 68.49 years
female: 74.26 years (2002 est.)
Total fertility rate: 2.39 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: predominantly black some British,
Portuguese, and Lebanese
Religions: Anglican, other Protestant, Roman
Catholic
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 97%
male: 97%
female: 98% (1980 est,)','3e2268924e4a68789081993de999d25b37f6ff644dc8eb5f73c74cbef656282e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ca902ac04961dfdff15b63443664b27b37d0cf223ae12a89074f12810fda05',2002,'WS','Samoa','people-and-society',1009,'Population: 178,631 (July 2002 est.)
Age structure:
0-14 years: 30.6% (male 27,774; female 26,854)
15-64 years: 63.5% (male 71 ,358; female 42,150)
65 years and over: 5.9% (male 4,859; female 5,636)
(2002 est.)
Population growth rate: -0.25% (2002 est.)
Birth rate: 15.53 births/1 ,000 population (2002 est.)
Death rate: 6.35 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 1 .64 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 ,05 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years: 1 .69 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .39 ma!e(s)/female (2002 est.)
Infant mortality rate: 30.74 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 69.8 years
male: 67.06 years
female: 72.69 years (2002 est.)
Total fertility rate: 3.3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
446
Samoa (continued)
HIV/AIDS ■ deaths: NA
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-haif of
population associated with the London Missionary
Society; includes Congregational, Roman Catholic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 15 and over can read and write
total population: 80%
male: 81%
female: 79% (1999)','cf4dfccb145420542ae5d927c5b64ed64ec98ccb86db643e2fa93109f880b982','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('054652dcf2b7de44c07f68dadc72d8ee3ae133b2d643445754c6a1d4bb781d14',2002,'SM','San Marino','people-and-society',1017,'Population: 27,730 (July 2002 est.)
Age structure:
0-14 years: 16.1% (male 2,300; female 2,161)
15-64 years: 67.5% (male 9,102; female 9,625)
65 years and over: 16.4% (male 1 ,956; female 2,586)
(2002 est.)
Population growth rate: 1.41% (2002 est.)
Birth rate: 10.64 births/1,000 population (2002 est.)
Death rate: 7.79 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 1 ,29 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth A. 09 male(s)/female
under 15 years: 1 .06 mate(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.76 ma!e(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 6.09 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 81.33 years
male: 77.79 years
female: 85.18 years (2002 est.)
Total fertility rate: 1 .3 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
female: 95% (1976 est.)','ef908a699176d813b2fe648f501bbc81cf6626380f53feaec9cc91f3ca2908bb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef3a2880368f86e6672c9f423aad9b9327f820847b79d14f15c38d8adfadd619',2002,'SA','Saudi Arabia','people-and-society',1026,'Population: 23,513,330
note: includes 5,360,526 non-nationals (July
2002 est.)
Age structure:
0-14 years: 42.4% (male 5,086,541 ; female
4,883,942)
15-64 years: 54.8% (male 7,493,304; female
5,396,985)
65 years and over. 2.8% (male 362,780; female
289,778) (2002 est.)
Population growth rate: 3.27% (2002 est.)
Birth rate: 37.25 births/1 ,000 population (2002 est.)
Death rate: 5.86 deaths/1 ,000 population (2002 est.)
Net migration rate: 1 .28 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .05 ma!e(s)/female
under 15 years: 1.04 male(s)/fema!e
15-64 years: 1.39 male(s)/female
65 years and over: 1 .25 male(s)/female
total population: 1.22 ma!e(s)/female (2002 est.)
Infant mortality rate: 49.59 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 68.4 years
male: 66.7 years
female: 70.2 years (2002 est.)
Total fertility rate: 6.21 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 78%
male: 84.2%
female: 69.5% (2002 est.)','58360e4ec23e07a1a78085ee629634f4e4332a5d8a0917e1041f1014eba7184b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b0f8c8e67057652948338af7bad727956c913061e3244fada4ca2068acd315',2002,'SN','Senegal','people-and-society',1034,'Population: 10,589,571 (July 2002 est.)
Age structure:
0-14 years: 43.5% (male 2,321,789; female
2,290,105)
15-64 years: 53.4% (male 2,710,178; female
2,943,554)
65 years and over: 3.1% (male 159,445; female
164,500) (2002 est.)
Population growth rate: 2.91% (2002 est.)
Birth rate: 36.99 births/1,000 population (2002 est.)
Death rate: 8.14 deaths/1 ,000 population (2002 est.)
Net migration rate: 0,21 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 55.41 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 62.93 years
male: 61 .29 years
female: 64.61 years (2002 est.)
Total fertility rate: 5.03 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1.4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 95,000
(2001 est.)
HIV/AIDS - deaths: 10,000 (2001 est.)
454
Senegal (continued)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer
147%, Jola 3.7%, Mandinka 3%, Soninke 1 .1%,
• European and Lebanese 1%, other 9.4%
Religions: Muslim 94%, indigenous beliefs 1%,
Christian 5% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Jola,
Mandinka
Literacy:
definition: age 1 5 and over can read and write
total population: 39.1%
male: 51.1%
female: 28.9% (2001 est.)','a49c577c19d2a2d86414c49d1bd94f427672bda90d63ebbb350fafdf1bbdee3b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529d22ec28ee45be2b70c73b7d706c69561c2b226b284b72289707e684ca03fe',2002,'SC','Seychelles','people-and-society',1043,'Population: 80,098 (July 2002 est.)
Age structure:
0-14 years: 27, 8% (male 11,238; female 11,002)
15-64 years: 66% (male 25,763; female 27,086)
65 years and over: 6.2% (male 1 ,667; female 3,342)
(2002 est.)
Population growth rate: 0.47% (2002 est.)
Birth rate: 17.27 births/1 ,000 population (2002 est.)
Death rate: 6.57 deaths/1,000 population
(2002 est.)
Net migration rate: -5.99 migrant(s)/l ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.93 male(s)/female (2002 est.)
Infant mortality rate: 1 6.86 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 70.97 years
male: 65.48 years
female: 76.63 years (2002 est.)
Total fertility rate: 1.81 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychellois
Ethnic groups: mixed French, African, Indian,
Chinese, and Arab
Religions: Roman Catholic 86.6%, Anglican 6.8%,
other Christian 2.5%, other 4.1%
Languages: English (official), French (official),
Creole
Literacy:
definition: age 1 5 and over can read and write
total population: 58%
male: 56%
female: 60% (1971 est.)','c23e105720fd33485e8b52ce8a80433230c21945f5d19a58b6ba170d5f95acfa','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0855203be783cdc1414ad67b729b3a6cf7049afbcaad490602a17f991c5cffe3',2002,'SL','Sierra Leone','people-and-society',1051,'Population: 5,614,743 (July 2002 est.)
Age structure:
0-14 years: 44.7% (male 1 ,230,530; female
1,280,084)
15-64 years: 52.1 % (male 1 ,397,070; female
1,528,986)
65 years and over: 3.2% (male 87,256; female
90,817) (2002 est.)
Population growth rate: 3.21% (2002 est.)
Birth rate: 44.58 births/1 ,000 population (2002 est.)
Death rate: 18.83 deaths/1 ,000 population
(2002 est.)
Net migration rate: 6.32 migrant(s)/1 ,000
population
note: by the end of 1999 refugees from Sierra Leone
are assumed to be returning (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.96 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
Infant mortality rate: 144.38 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 45.96 years
male: 43.01 years
female: 49.01 years (2002 est.)
Total fertility rate: 5.94 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 2.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 68,000
(1999 est.)
HIV/AIDS -deaths: 8,200 (1999 est.)
Nationality:
noun: Sierra Leonean (s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole (Krio) 10%
(descendants of freed Jamaican slaves who were
settled in the Freetown area in the late-18th century),
refugees from Liberia''s recent civil war, small
numbers of Europeans, Lebanese, Pakistanis, and
Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendants of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English ,
Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
female: 18.2% (1995 est.)','fbc3e7cd154f5387636c856326f5cee6151c589a271799ff496a9ad275312cd9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c556e0052624767cfd3028961230a7ac6fe240b46ca5832806705d212191831',2002,'SK','Slovakia','people-and-society',1061,'Population: 5,422,366 (July 2002 est.)
Age structure:
0-14 years: 18.3% (male 508,256; female 484,739)
15-64 years: 70.1% (male 1 ,888,705; female
1,910,842)
65 years and over: 1 1 .6% (male 237,770; female
392,054) (2002 est.)
Population growth rate: 0.14% (2002 est.)
Birth rate: 10.09 births/1 ,000 population (2002 est.)
Death rate: 9,22 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.53 migrant(s)/1 ,000
population (2002 est.)
463
Slovakia (continued)
Sex ratio:
at birth: 1.05 male(s)/(emale
under 15 years: 1.05 male(s)/female
15-64 years: 0,99 male(s)/female
65 years and over: 0.61 ma!e(s)/fema1e
total population: 0.95 ma1e(s)/fema!e (2002 est.)
Infant mortality rate: 8,76 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 74.2 years
male: 70.19 years
female: 78.41 years (2002 est.)
Total fertility rate: 1 .25 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01 %
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 400
(1999 est.)
HIV/AIDS - deaths: less than 1 00 (1 999 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.6%,
Roma 1 .6% (the 1 992 census figures underreport the
Gypsy/Romany community, which is about 500,000),
Czech, Moravian, Silesian 1.1%, Ruthenian and
Ukrainian 0.6%, German 0.1%, Polish 0.1%, other
0.2% (1996)
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','7c2e9479a7d61baf844ce07f7df882419cf0f3430d59dc04db82de1ea088a5e9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15852c3b7691ad840d034dd83206ac7947b6dd9880db917f4295c61de616e701',2002,'SO','Somalia','people-and-society',1069,'Population: 7,753,310
note: this estimate was derived from an official census
taken in 1975 by the Somali Government; population
counting in Somalia is complicated by the large
number of nomads and by refugee movements in
response to famine and clan warfare (July 2002 est.)
Age structure:
0-14 years: 44.7% (male 1 ,737,491 ; female 1 ,730,237)
15-64 years: 52.6% (male 2,054,243; female
2,019,980)
65 years and over. 2.7% (mate 92,617; female
118,742) (2002 est.)
Population growth rate: 3.46% (2002 est.)
Birth rate: 46.83 births/1,000 population (2002 est.)
Death rate: 1 7.99 deaths/1 ,000 population
(2002 est.)
Net migration rate: 5.75 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/fema!e
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 122.15 deaths/1 ,000 live
births (2002 est.)
Life expectancy at birth:
total population: 46.96 years
male: 45.33 years
female: 48.65 years (2002 est.)
Total fertility rate: 7.05 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu and other
non-Somali 1 5% (including Arabs 30,000)
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 15 and over can read and write
total population: 37,8%
male: 49.7%
female: 25.8% (2001 est.)','22dc15f696a1bf89424f1b3c0e4a64b9c6daaa8d1ee9db9babc97a2a33dfea90','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ea9dae0517cc6efed595506a19c5d8415c3404efd77dac8b99e778916cf88b',2002,'DZ','Algeria','people-and-society',1080,'Population: 40,077,100 (July 2002 est.)
Age structure:
0-14 years: 14.5% (male 2,993,747; female
2,812,498)
15-64 years: 68. 1% (male 1 3,699,383; female
13,592,717)
65 years and over: 17.4% (male 2,922,452; female
4,056,303) (2002 est.)
Population growth rate: 0.09% (2002 est.)
Birth rate: 9.29 births/1,000 population (2002 est.)
Death rate: 9.22 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.87 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/fema!e
15-64 years: 1 .01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 4.85 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 79.08 years
male: 75.63 years
female: 82,76 years (2002 est.)
Total fertility rate: 1.16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.58%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 120,000
(1999 est.)
HIV/AIDS -deaths: 2,000 (1999 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 94%, other 6%
Languages: Castilian Spanish (official) 74%,
Catalan 17%, Galician 7%, Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 97%
mate: NA%
female: NA%
Population: no indigenous inhabitants
note: there are scattered garrisons occupied by
personnel of several claimant states (July 2002 est.)
Population: 19,576,783
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island; as of mid-1999, approximately
66,000 were housed in 133 refugee camps in south
India, another 40,000 lived outside the Indian camps,
and more than 200,000 Tamils have sought refuge in
the West (July 2002 est.)
Age structure:
0-14 years: 25.6% (male 2,559,246; female
2,446,393)
15-64 years: 67.7% (mate 6,446,320; female
6,802,515)
65 years and over: 6.7% (male 628,398; female
693,911) (2002 est.)
Population growth rate: 0.85% (2002 est.)
Birth rate: 16.36 births/1,000 population (2002 est.)
Death rate: 6.45 deaths/1 ,000 population (2002 est.)
Net migration rate: -1 .39 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 ma!e(s)/female
under 15 years: 1.05 ma!e(s)/fema!e
15-64 years: 0.95 male(s)/fema!e
65 years and over. 0.91 male(s)/fema!e
total population: 0.97 male(s)/fema!e (2002 est.)
Infant mortality rate: 15.65 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 72.35 years
mate: 69.83 years
female: 75 years (2002 est.)
Total fertility rate: 1 .93 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.07%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 7,500
(1999 est.)
HIV/AIDS -deaths: 490 (1999 est.)
Nationality:
noun: Srj Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 70%, Hindu 15%, Christian 8%,
Muslim 7% (1999)
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%, other 8%
note: English is commonly used in government and is
spoken competently by about 10% of the population
Literacy:
definition: age 15 and over can read and write
total population: 90.2%
male: 934%
female: 87.2% (1995 est.)','74d200f45b9536caac7c88b0f35e10829e8d5316855bfaca11e3433a86851a3f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7168449c2e3defe49624be9a35664a91b5c626b8954bf5a08b0834c247a6d34c',2002,'SD','Sudan','people-and-society',1088,'Population: 37,090,298 (July 2002 est.)
Age structure:
0-14 years: 44.2% (male 8,385,554; female
8,023,847)
15-64 years: 53.6% (mate 9,945,683; female
9,933,383)
65 years and over: 2.2% (male 447,214; female
354,617) (2002 est.)
Population growth rate: 2.73% (2002 est.)
Birth rate: 37.21 births/1 ,000 population (2002 est.)
Death rate: 9.81 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.07 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/femate
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .26 ma!e(s)/female
total population: 1.03 ma!e(s)/female (2002 est.)
Infant mortality rate: 67.14 deaths/1,000 live births
(2002 est.)
Life expectancy at birth:
total population: 57.33 years
male: 56.22 years
female: 58.5 years (2002 est.)
Total fertility rate: 5.22 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.99%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 186,000
(1998)
HIV/AIDS -deaths: NA
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of "Arabization" in process
Literacy:
definition: age 15 and over can read and write
total population: 46.1%
male: 57.7%
female: 34.6% (1995 est.)','9801cea2c85a95f3a7d3b5d5a17cdb5a8db6fd62885693e8ef64b8216e622dcb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06819609b138fa46d66e5e070f7c113c93e4b9cd28e477c05bc0bde5a7e2259',2002,'GY','Guyana','people-and-society',1093,'Population: 436,494 (July 2002 est.)
Age structure:
0-14 years: 31 .1 % (male 69,642; female 66,262)
15-64 years: 63.1% (male 140,745; female 134,494)
65 years and over: 5.8% (male 1 1 ,480; female
13,871) (2002 est.)
Population growth rate: 0.55% (2002 est.)
Birth rate: 1 9.97 births/1 ,000 population (2002 est.)
Death rate: 5.67 deaths/1 ,000 population (2002 est.)
Net migration rate: -8.82 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 ma!e(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.03 male(s)/female (2002 est.)
Infant mortality rate: 23.48 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 71 .9 years
male: 69.23 years
female: 74.7 years (2002 est.)
Total fertility rate: 2.44 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 .26%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS- deaths: 210 (1999 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 19th
century) 37%, Creole (mixed white and black) 31%,
Javanese 15%, "Maroons'' (their African ancestors
were brought to the country in the 17th and 18th
centuries as slaves and escaped to the interior) 10%,
Amerindian 2%, Chinese 2%, white 1%, other 2%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely spoken),
Sranang Tongo (Surinamese, sometimes called
Taki-Taki, is native language of Creoles and much of
the younger population and is lingua franca among
others), Hindustani (a dialect of Hindi), Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 95%
female: 91% (1995 est.)
Population: 2,868 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: -1.99% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children bom/woman
HIV/AIDS - adult prevalence rate: 0% (2001 )
HIV/AIDS - people living with HIV/AIDS: 0 (2001 )
HIV/AIDS -deaths: 0(2001)
Ethnic groups: Norwegian 55.4%, Russian and
Ukrainian 44.3%, other 0.3% (1998)
Languages: Russian, Norwegian
Literacy: NA','6ee331714c03876be879de83c314e16c69f85095e1c818d1364b77b3496bc724','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('172abc9fadbf3d4ff1baebae6d155387d31a9e42784bffdff191c1a966447ada',2002,'TK','Tokelau','people-and-society',1105,'Population: 1,431 (July 2002 est.)
Age structure:
0-14 years: 42%
15-64 years: 53%
65 years and over: 5% (1996 est.)
Population growth rate: -0.92% (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate: 38 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: NA years
male: 68 years (2001)
female: 70 years (2001)
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Tokelauan(s)
ad/ecf/ve:Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English
Literacy: NA','c196f327fa19f1b8e0f62f6b87fded689eea31c68989555c806bec315f78cb0f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa0ac727ffc0446c4350419435a14b2aa62eba087074ed3f1f82159798885e0e',2002,'TM','Turkmenistan','people-and-society',1116,'Population: 4,688,963 (July 2002 est.)
Age structure:
0-14 years: 37.3% (male 895,536; female 853,301 )
15-64 years: 58.6% (male 1 ,350,1 42; female
1,399,879)
65 years and over: 4.1% (male 72,784; female
117,321) (2002 est.)
Population growth rate: 1.84% (2002 est.)
Birth rate: 28.27 births/1 ,000 population (2002 est.)
Death rate: 8.92 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.98 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.96 male(s)/female
522
Turkmenistan (continued)
65 years and over: 0.62 male(s)/female
total population: 0.98 male(s)/fema1e (2002 est.)
Infant mortality rate: 73.21 deaths/1,000 live births
(2002 esl.)
Life expectancy at birth:
total population: 61 .1 years
male: 57.57 years
female: 64.8 years (2002 est.)
Total fertility rate: 3.54 children born/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%,
Russian 6.7%, Kazakh 2%, other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%,
Uzbek 9%, other 7%
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: Wo
female: 97% (1989 est.)','2756804f6a33cf38951848e169d694f8fe63303152047f2811ac2a60b3503c4a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb7560b9c06202ceffd5f22fcb5fce2e9cbe5ad6536ab824f5535acd89e90445',2002,'TV','Tuvalu','people-and-society',1126,'Population: 11,146 (July 2002 est.)
Age structure:
0-14 years: 32,6% (male 1,851; female 1,785)
15-64 years: 62.3% (male 3,335; female 3,607)
65 years and over: 5.1 % (male 233; female 335)
(2002 est.)
Population growth rate: 1 .4% (2002 est.)
Birth rate: 21 .44 births/1 ,000 population (2002 est.)
Death rate: 7.45 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 22 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 66.98 years
male: 64.83 years
female: 69.23 years (2002 est.)
Total fertility rate: 3.07 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%, Micronesian 4%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1.4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English, Samoan, Kiribati (on
the island of Nui)
Literacy:
definition: percentage of people over the age of 15
who can read and write
total population: 55% (1 996)
male: NA%
female: NA%
Population: 24,699,073
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 50.9% (male 6,31 4,371 ; female
6,265,681)
15-64 years: 47% (male 5,803,430; female
5,789,713)
65 years and over: 2.1% (male 247,798; female
278,080) (2002 est.)
Population growth rate: 2.94% (2002 est.)
Birth rate: 47.15 births/1 ,000 population (2002 est.)
Death rate: 17.53 deaths/1 ,000 population
(2002 est.)
Net migration rate: -0.28 migrant(s)/1 ,000
population
note: according to the UNHCR, by the end of 2001 ,
Uganda was host to 178,815 refugees from a number
of neighboring countries, including: Sudan 155,996,
Rwanda 14,375, and Democratic Republic of the
Congo 7,459 (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 male(s)/female (2002 est.)
Infant mortality rate: 89.35 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 43.81 years
male: 42.97 years
female: 44.67 years (2002 est.)
Total fertility rate: 6.8 children bom/woman
(2002 est.)
HIV/AIDS • adult prevalence rate: 6.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1.1 million
(2001 est.)
HIV/AIDS - deaths: 1 1 0,000 (1 999 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Ankole 8%, Basoga
8%, Iteso 8%, Bakiga 7%, Langi 6%, Rwanda 6%,
Bagisu 5%, Acholi 4%, Lugbara 4%, Batoro 3%,
Bunyoro 3%, Alur 2%, Bagwere 2%, Bakonjo 2%,
Jopodhola 2%, Karamojong 2%, Rundi 2%,
non-African (European, Asian, Arab) 1%, other 8%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications in the capital and may be taught
in school), other Niger-Congo languages,
Nilo-Saharan languages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.7%
male: 74%
female: 54% (2000 est.)','073e832f5872dcfd878f0bc999b1aa2a2c22588aad4bd435f7f2c3c964bc6215','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e521c7fcf8952fbc8b57cdd4971b14da3aa215dba4908470b849a8be06d4c8',2002,'OM','Oman','people-and-society',1136,'Population: 2,445,989
note: includes 1 ,576,472 non-nationals (July
2002 est.)
Age structure:
0-14 years: 27.7% (male 345,077; female 331 ,545)
15-64 years: 69.7% (male 1,069,443; female
635,275)
65 years and over: 2.6% (male 45,989; female
18,660) (2002 est.)
Population growth rate: 1.58% (2002 est.)
Birth rate: 18.3 births/1,000 population (2002 est.)
Death rate: 3.9 deaths/1,000 population (2002 est.)
Net migration rate: 1.41 migrant(s)M,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 maie(s)/fema!e
under 15 years: 1.04 male(s)/fema!e
15-64 years: 1 .68 ma1e(s)/fema!e
65 years and over: 2.46 male(s)/female
total population: 1.48 male(s)/fema!e (2002 est.)
Infant mortality rate: 1 6. 1 2 deaths/1 ,000 live births
(2002 est.)
534
United Arab Emirates (continued)
Life expectancy at birth:
total population: 74.52 years
male: 72.06 years
female: 77 ,1 years (2002 est.)
Total fertility rate: 3.16 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Emirati(s)
adjective: Emirati
Ethnic groups: Emirati 1 9%; other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1 982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 1 5 and over can read and write
total population: 79.2%
male: 78.9%
female: 79.8% (1995 est.)','fd48e071320e0726c08d7f9ba890ebf08960b8153556b31341b0452b1fce9da0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e86044fe74936281d9f5ce31c029281250fc442a87c461a53a82e0bbdf0de4',2002,'UY','Uruguay','people-and-society',1145,'Population: 3,386,575 (July 2002 est.)
Age structure:
0-14 years: 24.4% (male 422,826; female 402,324)
15-64 years: 62.6% (male 1,047,740; female
1,072,032)
65 years and over: 1 3% (male 1 81 ,522; female
260,131) (2002 est.)
Population growth rate: 0.79% (2002 est.)
Birth rate: 17.28 births/1 ,000 population (2002 est.)
Death rate: 9 deaths/1 ,000 population (2002 est.)
Net migration rate: -0.41 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 ma!e(s)/female
total population: 0.95 male(s)/femaie (2002 est.)
Infant mortality rate: 14.25 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 75.66 years
male: 72.32 years
female: 79.17 years (2002 est.)
Total fertility rate: 2.35 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.33%
(1999 est.)
543
Uruguay (continued)
HIV/AIDS - people living with HIV/AIDS: 6,000
(1999 est.)
HIV/AIDS -deaths: 150 (1999 est.)
Nationality:
noun : Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than half of
the adult population attends church regularly),
Protestant 2%, Jewish 1%, nonprofessing or
other 31%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
female: 97.7% (1995 est.)','7ef6a7cee5ac38f8a1c8b3cc402414144a7a9413334154568cdcbc86497d309f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e1ab85c4f1e262728a036cbb2789eb1ebecd14bb9a87449715cad0e43bac9b',2002,'UZ','Uzbekistan','people-and-society',1154,'Population: 25,563,441 (July 2002 est.)
Age structure:
0-14 years: 35.5% (male 4,617,110; female
4,457,065)
15-64 years: 59.8% (male 7,567,510; female
7,726,753)
65 years and over: 4.7% (male 482,137; female
712,866) (2002 est.)
Population growth rate: 1.62% (2002 est.)
Birth rate: 26.09 births/1,000 population (2002 est.)
Death rate: 7.98 deaths/1 ,000 population (2002 est.)
Net migration rate: -1.94 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/fema!e
15-64 years: 0.98 male(s)/female
65 years and over: 0.68 male(s)/female
total population : 0.98 male(s)/female (2002 est.)
Infant mortality rate: 71 .72 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.9 years
male: 60.38 years
female: 67.6 years (2002 est.)
Total fertility rate: 3.03 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistan
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1 .5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1996)','56fc6f4200a82206662b55bb0b3fb539ad16e0fe045461f63f4143ae728e434e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd5fbee33508baf8643695be882155deef0329e2e6a387d996e010d92e49e372',2002,'PR','Puerto Rico','people-and-society',1160,'Population: 123,498 (July 2002 est.)
Age structure:
0-14 years: 26,7% (male 16,926; female 16,012)
15-64 years: 64.2% (male 35,801 ; female 43,443)
65 years and over: 9.1% (male 4,851 ; female 6,465)
(2002 est.)
Population growth rate: 1 .04% (2002 est.)
Birth rate: 1 5.85 births/1 ,000 population (2002 est.)
Death rate: 5.58 deaths/1 ,000 population (2002 est.)
Net migration rate: 0.12 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
af birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.82 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.87 male(s)/female (2002 est.)
Infant mortality rate: 9.21 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 78.43 years
male: 74.55 years
female: 82.53 years (2002 est.)
Total fertility rate: 2.24 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic groups: black 80%, white 1 5%, other 5%
note: West Indian (45% bom in the Virgin Islands and
29% bom elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy:
definition: NA
total population: NA%
mate: NA%
female: NA%','722deaad65574dab4740257c1a76ab07d26391552d16aafe0e52524b364adac9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4279d459349a252250e6e212f2aba687d7351853e35fa4afa410b8835c9893d',2002,'MP','Northern Mariana Islands','people-and-society',1167,'Population: no indigenous inhabitants
note: US military personnel have left the island, but
civilian personnel remain; as of December 2000, one
US Army civilian and 123 contractor personnel were
present (July 2002 est.)','594e96b33afb53b19b21c3ffbcbdd08c1cb911679ccd07fbd40c4c2c35eafd02','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a4fb828026e58024db24eddecfff3377b17afed972a90c551b44b0fc58e9ead',2002,'EH','Western Sahara','people-and-society',1172,'Population: 256,177 (July 2002 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: NA (2002 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: 6,233,821 ,945 (July 2002 est.)
Age structure:
0-14 years: 29.2% (male 932,581 ,592; female
885,688,851)
15-64 years: 63.7% (male 2,009,997,089; female
1,964,938,201)
65 years and over: 7.1% (male 193,549,180; female
247,067,032) (2002 est.)
Population growth rate: 1.23% (2002 est.)
Birth rate: 21.16 births/1 ,000 population (2002 est.)
Death rate: 8.93 deaths/1 ,000 population (2002 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .05 ma!e(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.01 male(s)/female (2002 est.)
Infant mortality rate: 51 .55 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 63.94 years
male: 62.28 years
femafe: 65.67 years (2002 est.)
Total fertility rate: 2.7 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Religions: Christians 32.88% (of which Roman
Catholics 17.39%, Protestants 5.62%, Orthodox
3.54%, Anglicans 1.31%), Muslims 19.54%, Hindus
13.34%, Buddhists 5.92%, Sikhs 0.38%, Jews 0.24%,
other religions 12.6%, non-religious 12.63%, atheists
2.47% (2000 est.)
Languages: Chinese, Mandarin 14.37%, Hindi
6.02%, English 5.61%, Spanish 5.59%, Bengali 3.4%,
Portuguese 2.63%, Russian 2.75%, Japanese 2.06%,
German, Standard 1.64%, Korean 1.28%, French
1.27% (2000 est.)
note: percents are for "first language” speakers only
Literacy:
definition: age 15 and over can read and write
total population: 77%
male: 83%
female: 71% (1995 est.)
564
World (continued)','7e66bfae81079ff4544e75a092225111255728452554a1f55b8d1bf655ff79e6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfc2c886e8591cc840409c109649ca38a145dfef2e4c43f43b788183d6b68f00',2002,'YE','Yemen','people-and-society',1181,'Population: 18,701 ,257 (July 2002 est.)
Age structure:
0-14 years: 47% (male 4,468,928; female 4,317,648)
15-64 years: 50.1% (male 4,783,769; female
4,587,309)
65 years and over: 2.9% (male 273,282; female
270,321) (2002 est.)
Population growth rate: 3.4% (2002 est.)
Birth rate: 43.3 births/1,000 population (2002 est.)
Death rate: 9.31 deaths/1 ,000 population (2002 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2002 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 ma!e(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over. 1.01 male(s)/female
total population: 1.04 male(s)/female (2002 est.)
Infant mortality rate: 66.78 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 60.59 years
male: 58.81 years
female: 62.46 years (2002 est.)
Total fertility rate: 6.9 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; but also
Afro-Arab, South Asians, Europeans
Religions: Muslim including Shaf''i (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)
Population: 10,656,929
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing (July 2002 est.)
Age structure:
0-14 years: 19.6% (male 1 ,077,581 ; female 1 ,005,379)
568
Yugoslavia (continued)
15-64 years: 65.3% (male 3,41 5,929; female
3,546,410)
65 years and over: 15.1% (male 690,014; female
921,616) (2002 est.)
Population growth rate: -0.12% (2002 est.)
Birth rate: 12.8 births/1 ,000 population (2002 est.)
Death rate: 1 0.59 deaths/1 ,000 population
(2002 est.)
Net migration rate: -3.38 migrant(s)/1 ,000
population (2002 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.75 male(s)/femate
total population: 0.95 male(s)/female (2002 est.)
Infant mortality rate: 1 7.36 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 73.72 years
male: 70.78 years
female: 76.89 years (2002 est.)
Total fertility rate: 1 .78 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serb 62.6%, Albanian 16.5%,
Montenegrin 5%, Hungarian 3.3%, other 12.6%
(1991)
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbian 95%, Albanian 5%
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 97.2%
female: 88.9% (1991)','2fd4c1e9a9b302d23f4bac3474bb034030189ded666415b3fd84c2d8b3701317','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69f25870bc3a5692913999eea7d2ae869df35ab7cec25b3692524070592ff38',2002,'ZM','Zambia','people-and-society',1189,'Population: 9,959,037
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 47. t% (male 2,357,581; female
2,335,644)
15-64 years: 50.4% (male 2,497,360; female
2,519,227)
65 years and over: 2.5% (male 1 06,1 60; female
143,065) (2002 est.)
Population growth rate: 1 .9% (2002 est.)
Birth rate: 41 ,01 births/1 ,000 population (2002 est.)
Death rate: 21.89 deaths/1,000 population
(2002 est.)
Net migration rate: -0.16 migrant(s)/1,000
population (2002 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.99 male(s)/female (2002 est.)
Infant mortality rate: 89.39 deaths/1 ,000 live births
(2002 est.)
571
Zambia (continued)
Life expectancy at birth:
total population: 37.35 years
male: 37.05 years
female: 37.66 years (2002 est.)
Total fertility rate: 5.43 children bom/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 1 9.95%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 870,000
(1999 est.)
HIV/AIDS - deaths: 99,000 (1999 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 1 5 and over can read and write English
total population: 78.9%
male: 85.7%
female: 72.6%','66383163fcb3856d58d8633378fe15a23d278b966ab5a4c0550c27da1fba2183','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cb764d6f76d939f3eba41e64d15dbf295c6fcc33a7c9d054fe1ab64d2ca0c4',2002,'ZW','Zimbabwe','people-and-society',1197,'Population: 11,376,676
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2002 est.)
Age structure:
0-14 years: 37.9% (male 2,178,073; female
2,128,287)
15-64 years: 58.4% (male 3,376,850; female
3,268,315)
65 years and over: 3.7% (male 21 3,286; female
211,865) (2002 est.)
Population growth rate: 0.05% (2002 est.)
Birth rate: 24.59 births/1 ,000 population (2002 est.)
Death rate: 24.06 deaths/1,000 population
(2002 est.)
Net migration rate: NEGL migrant(s)/1 ,000
population
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
(2002 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 .02 male(s)/fema!e
15-64 years: 1.03 ma!e(s)/female
65 years and over: 1 .01 ma!e(s)/female
total population: 1 .03 ma!e(s)/female (2002 est.)
Infant mortality rate: 62.97 deaths/1 ,000 live births
(2002 est.)
Life expectancy at birth:
total population: 36,5 years
male: 37.87 years
female: 35.1 years (2002 est.)
Total fertility rate: 3.21 children born/woman
(2002 est.)
HIV/AIDS - adult prevalence rate: 25.06%
(1999 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .5 million
(1999 est.)
HIV/AIDS • deaths: 160,000 (1999 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 82%, Ndebele
14%, other 2%), mixed and Asian 1%, white less
than 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 1 5 and over can read and write English
total population: 85%
mate: 90%
female: 80% (1995 est.)','98b5493c5a35ae63e7453e9058a6f9c3bce9ca64b6e3ea4837a083c4c0220ec5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

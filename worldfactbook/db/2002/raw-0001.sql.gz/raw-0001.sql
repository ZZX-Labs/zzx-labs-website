SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0f788e718887a57bd621cff5d53f7291967864ede10c80f86a37935a470669',2002,'','','raw',1,'II
I Physical Map of the World, June 2002
H AUSTRALIA Independent state
■ Bermuda Dependency or area of special sove "eigmy
■ Sicily / AZORES Island / island group
^ Capita!
The Central Intelligence Agency (CIA) publishes The World
Factbook in printed and Internet versions. US Government
officials may obtain information about availability of the Factbook
from their organizations or through liaison channels to the CIA.
Other users may obtain sales information about printed copies
from the following:
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512*1800; toll free: [1] (866) 512-1800
FAX: [11(202) 512-2250
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only In the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
http^/wvvwxia.gov/cla/pubtications/factbook/index.html
^ Imaging & Publishing Support
...the Intelligence Community publisher
ASIA
80291 3AI {R02105) 6-02
EUROPE
Jan Mayen
i
F.Y.R.O.M. - The Fwnor YjowUrv RtpMz of Vecedonto
Barents
Norwegian Sea
— h~ — At?tic_ ^Circle _
<y Faroe Islands
Stavangei
Ni>rt/l
Sea
Oslo.
Ume
fSWEDEIv Gulf1
or
Kotknh
Gavlc!','a34d977c2a702a910110d5e8f77a633f548aaeb1ed38f9229f5420e835bdf4c2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e8007a482450ea086d948370d98437014c33bae2293a9f24f56aa2e30040fd',2002,'FI','Finland','raw',2,'^Tampere
MAND
Stockholm^ ifiANDS /^Tallinn v
''vJc Estonia \\
St. Petersburg
RUSSIA
TGdteborg
Moscow
!««rf / VX LATVIA
RTga*
''dftmrf I \\ LITHUANIA > ^bsk V^0''"*
.Matfnd I Aw - Vilnius, f Mahily.
*> Minsk
•N&nefiisWr
Jverpoor
[NQDO
6omholm
^Gdansk"?
.Hamburg
Celtic
''ardlff Birmingham) Amstcrd
'' , ~ _ Tlotterd
London"
BremenN, BcHIK poz^
* "POLAND
^Frankfurt 5^-^ .^r^Krakdw
*am Main v ^
• /Brussels* ^
trgtoh Clumw j ulte''S^ BEL.
Guernsey ''O R.)/
Jersey tun.)*
— 1 — _ ''-\\WLUi\\vnii7uure \\ -■ r-
-.Parts ujxXT H * V Bmo" ^Jy^^
Strasbourg?^ ^Munich ^ZTs^''Nt
^Njnjes? v.-ov^V ^ f j s^-^ • \\ Vienna
t. BELARUS {
^Hrodna
Homy!
#Rivne
176','6b4c74e3f749de44acc768540a5c07bb30ebda859e48499fbae93f88ff5374f7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f469cdc24a66e8720067017c88829b7a48682364947a82b91af32bc72bad242',2002,'UA','Ukraine','raw',3,'•L''vlv
Biscay
L Porto :"
^Bilbao /
Zaragozav
Andorra .-^^ft. ifcurim Rlorerice*" >\\ ^SST''"
''""v Napoca "T MOLDOVA
4 ^ '' Bucharest) /Cortstartja
, BOSNIA. _
Mortar ''^S^T^v ^^I^^T^^^'' Sui^A r
.4 • \\ . Sea
f Madrid ''
r««T ^ * — "~^~^-^jfy **''e*rk
SPAIT1 Valency
^^Barcelona
<7
\\0lbraui^4{#g«
Rabat
"•Casablanca (j, ''
MOROC3CO
^ BALEARIC
ISLANOS
Mediterranean Sea
Ionian 1 ^
Sea \\ ^
Algiers
; "Uinls
ALGERIA * ) ^ISL
Scale l: 19,500,000 '' feq^t
Valletta"^ iMubot Cottformal Coff/c ProjecUonrT^"^
MALTA standard parallels 40''N and 56 ''N
0 300 Kilometers
80291 OAI (R01083) 6-02
Centra!
Intelligence
Agency
The
World
Factbook
2002
In general, information available as of 1 January
2002 was used in the preparation of this edition.
The World Facfbook is prepared by the Central
intelligence Agency for the use of US Government
officials, and the style, lormat, coverage, and
content are designed to meet their specific
requirements. Information is provided by Antarctic
Information Program (National Science
Foundation), Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department
of Labor), Central Intelligence Agency, Council of
Managers of National Antarctic Programs, Defense
Intelligence Agency (Department of Defense),
Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration
(Department of Transportation), National imagery
and Mapping Agency (Department of Defense),
Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs
(Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on
Geographic Names (Department of the Interior), US
Transportation Command (Department of Defense),
and other public and private sources.
The Factbook is in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties.
Comments and queries are welcome and may be
addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
DISTRIBUTION STATEMENT A
Approved for Public Release
Distribution Unlimited
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
isacquired, converted into intelligence, and made available to
policymakers, information is raw data from any source, data
that may be fragmentary, contradictory unreliable,
ambiguous, deceptive, or wrong, intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President''s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only since
World War II have they been coordinated on a government-
wide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1 ) the Joint Army Navy Intelligence Studies (JANIS), (2j the
National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed and coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence - ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services - OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1 943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1 943 and July 1947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff. Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S,
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1 946, page 46) that world leadership in peace requires
even more elaborate intelligence than in war. "The conduct of
peace involves all countries, all human activities - not just the
enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
13 January 1946, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbook was created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbook was published in August
1962, and the first unclassified version was published in June
1 971 . The NIS program was terminated in 1 973 except for the
Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with
sales through the US Government Printing Office (GPO) . The
year 2002 marks the 55th anniversary of the establishment of
the Central Intelligence Agency and the 59th year of
continuous basic intelligence support to the US Government
by The World Factbook M its two predecessor programs.
ii
Contents
Page
Page
Page
Notes and Definitions
vii
531','143270969b0719ea65750f02bb8ea21ccc24a53cb7f93620259887ab008712b7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3974d9f92c319d4506a6d113362b11c7efeebb7823255adb4191bb51ebc12f84',2002,'IE','Ireland','raw',4,'252
RsirhaHnc
Dal UcLUUo
45
E
East Timor
151
Israel (also see separate Gaza Strip
254
Daooab Ua inula
47','46a06061e45351c0331a2a5cc7cb3cae7898fd264c1ed4088fe259514681aaf6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f539d15075c58e29d89dff4612c857142ff4bcdc151b908059a76847c22c5fc9',2002,'JE','Jersey','raw',5,'266
DUN via
62
Europa Island
170
Johnston Atoll
268
Rncnifl and Mor7onnvina
DUotiia ctnu ncit-cyuvii la
fid
F
Falkland Islands (!s!as Malvinas)
170','1c2d03ecc4d06bf7ce67f61eb4c884fd883a57d8879cc204f4ca483086f89eab','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0902ba01e82519daec49382b70245449ba50ad972a0fe2e1c09d1b1141dfdec',2002,'LY','Libya','raw',6,'301
Page
Page
Liechtenstein 303
Lithuania 305
Luxembourg 308
M Macau 310
Macedonia, The Former Yugoslav 312
Republic of
Madagascar 314
Malawi 317
Malaysia 319
Maldives 322
Mali 324
Malta 326
Man, Isle of 326
Marshall Islands 330
Martinique 332
Mauritania 334
Mauritius 336
Mayotte 338
Mexico 340
Micronesia, Federated States of 343
Midway Islands 345
Moldova 346
Monaco 348
Mongolia 350
Montserrat 353
Morocco 354
Mozambique 357
N Namibia 360
Nauru [ 362
Navassa Island 364
Nepal 365
Netherlands 367
Netherlands Antilles ^70
New Caledonia 372
New Zealand 374
Nicaragua 377
Niger 379
Nigeria 382
Niue 384
Norfolk Island 386
Northern Mariana Islands 388
Norway 390
O Oman 392
P Pacific Ocean 394
Pakistan 395
Palau 398
Palmyra Atoll 400
Panama 401
Papua New Guinea 404
Paracel Islands 406
Paraguay 407
Peru 409
Philippines 412
Pitcaim Islands 415
Poland 416
Portugal 419
Puerto Rico 422
Q Oatar 424
R Reunion 426
Romania 428
Russia 431
Rwanda 434
S Saint Helena 437
Saint Kitts and Nevis 438
Saint Lucia 440
Saint Pierre and Miquelon 442
Saint Vincent and the Grenadines 444
Samoa 446
San Marino 448
Sao Tome and Principe 450
Saudi Arabia 452
Senegal 454
Seychelles 456
Sierra Leone 458
Singapore 461
Slovakia 463
Slovenia 466
Solomon Islands 468
Somalia 470
South Africa 473
South Georgia and the South 475
Sandwich Islands
Southern Ocean 476
Spain 478
Spratly Islands 481
Sri Lanka 481
__ _
Suriname 486
Svalbard 489
Swaziland 490
Sweden 492
Switzerland 495
Syria 497
T Taiwan entry follows Zimbabwe
Tajikistan 500
Tanzania 503
Thailand 505
Togo 508
Tokelau 510
Tonga 512
Trinidad and Tobago 514
i romeiin isianu
o to
initio
i unisia
01 1
Titrif a\\i
1 UlKcy
o iy
Ti rrVmoniotan
1 UiKlTlcniSlan
Turk^ and Caicos Islands
525','fa0b8bd971f584deb934f2377187f3e610b8b7b2bcf1484b53712126bb51e02e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19e5e1c9d55b3b3cc4d2c73525eae9d0b1635033a979558b8130db6f2089ad72',2002,'US','United States','raw',7,'540
v
Notes and Definitions
In addition to the updating of information, the following changes have been made
in this edition of The World Factbook There is a new country profile on East Timor
and there is a new entry on Distribution of family income - Gini index. Revision
of some individual country maps, first introduced in the 2001 edition, is continued
in this edition. The revised maps include elevation extremes and a partial
geographic grid.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up solely from
the first letter of the major words in the expanded form is rendered in all capital
letters (NATO from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general, an acronym made
up of more than the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement). Hybrid
forms are sometimes used to distinguish between initially identical terms (WTO:
WTrO for World Trade Organization and WToO for World Tourism Organization,)
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years,
65 years and over). The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 55 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture - products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not alt airports have facilities for refueling,
maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to the following five
groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m, (4) 914 to
1,523 m, and (5) under 914 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for refueling, maintenance, or air traffic
control.
Airports - with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces) by length. For airports
with more than one runway, only the longest runway is included according to the
vii
Notes and Definitions (continued)
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m,
(4) 914 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control
Appendixes: This section includes Facf£?oo/r-related material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area - comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annua! number of births during a year per
1,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the tevel of fertility and the age structure of the
population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms
Capital: This entry gives the location of the seat of government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, television, and Internet service provider entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes: see Data codes
Country map: Most versions of the Facta* provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
viii
Notes and Definitions (continued)
Country name: This entry includes ail forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica ItaJiana), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Currency: This entry identifies the national medium of exchange and its basic
subunit.
Currency code: This entry gives the international Organization for
Standardization (ISO) 421 7 alphabetic currency code for each country.
Data codes: This information is presented in Appendix D: Cross-Reference List
of Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes. This appendix includes the US Government
approved Federal Information Processing Standards (FIPS) codes, the
International Organization for Standardization (ISO) codes, and Internet codes for
land entities. The appendix also includes the International Hydrographic
Organization (IHO) codes, Aeronautical Chart and Information Center (ACIC; now
a part of the National Imagery and Mapping Agency or NIMA) codes, and Defense
Intelligence Agency (DIA) codes for hydrographic entities. The US Government
has not yet approved a standard for hydrographic data codes similar to the FIPS
10-4 standard for country data codes.
Date of Information: In general, information available as of 1 January 2001, was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total public and private debt owed to
nonresidents repayable in foreign currency, goods, or services.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
185 independent states, including 183 of the 189 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, and the US itself). In addition,
the US has diplomatic relations with 3 independent states that are not in the UN -
East Timor, Holy See, and Switzerland.
Diplomatic representation in the US: This entry includes the chief of mission,
chancery, telephone, FAX, consulate general locations, and consulate locations.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, toicft office
locations, consulate general locations, and consulate locations.
ix
Notes and Definitions (continued)
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Distribution of family income - Gini index: This index measures the degree of
inequality in the distribution of family income in a country. The index is calculated
from the Lorenz curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The index is the ratio
of (a) the area between a country''s Lorenz curve and the 45 degree helping line
to (b) the entire triangular area under the 45 degree line. The more nearly equal a
country''s income distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index of 25. The more
unequal a country''s income distribution, the farther its Lorenz curve from the 45
degree line and the higher its Gini index, e.g., a Sub-Saharan country with an index
of 50. If income were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if income were
distributed with perfect inequality, the Lorenz curve would coincide with the
horizontal axis and the right vertical axis and the index would be 100.
Economic aid - donor: This entry refers to net official development assistance
(ODA) from Organization for Economic Cooperation and Development (OECD)
nations to developing countries and multilateral organizations, ODA is defined as
financial assistance that is concessional in character, has the main objective to
promote economic development and welfare of the less developed countries
(LDCs), and contains a grant element of at least 25%. The entry does not cover
other official flows (OOF) or private flows.
Economic aid - recipient: This entry, which is subject to major problems of
definition and statistical coverage, refers to the net inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new inflows
and repayments.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity - consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and
distribution.
x
Notes and Definitions (continued)
Electricity ■ exports: This entry is the total exported electricity in kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in kilowatt-hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt-hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Electricity - production by source: This entry states the percentage share of
electricity generated from each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes: This entry includes both the highest point and the lowest
point
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies* and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country* names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 268 separate
geographic entities in The World Factbook\\\\)a\\ may be categorized as follows:
INDEPENDENT STATES
1 92 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya/Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Luci^ Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
xi
Notes and Definitions (continued)
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','7e736991f6f357b13d05fb50e2ac8193aa31fe35ad39848b3fd329ba46cdf4dc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d33d44343039365a6ee7471ddb23b974c75e32d2c6be98b742f27f2845929f0',2002,'VU','Vanuatu','raw',8,'548
VpnpzuplA
550
Viptnam
¥ P\\>U 1C4M 1
553
Virnin klanrte
555
vv
vvaKc isiano
00/','b587c1374cb55bfe8eefe10d1d46548b6ca30921e77d3506b17dc295dedb2bed','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64bf6470b7fa9adeb628e65203e554a77b4726dd4b915f0533d378e9ee44c14d',2002,'EH','Western Sahara','raw',9,'562
World
564
Y
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian'' Ocean, Pacific Ocean,
Southern Ocean
1 World
268 total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
acidification - the lowering of soil and water pH due to acid precipitation and
deposition usually through precipitation; this process disrupts ecosystem nutrient
flows and may kill freshwater fish and plants dependent on more neutral or alkaline
conditions (see acid rain).
acid rain • characterized as containing harmful levels of sulfur dioxide or
nitrogen oxide; acid rain is damaging and potentially deadly to the earth''s fragile
ecosystems; acidity is measured using the pH scale where 7 is neutral, values
greater than 7 are considered alkaline, and values below 5.6 are considered acid
precipitation; note - a pH of 2.4 (the acidity of vinegar) has been measured in
rainfall in New England.
aerosol * a collection of airborne particles dispersed in a gas, smoke, or fog.
afforestation - converting a bare or agricultural space by planting trees and
plants; reforestation involves replanting trees on areas that have been cut or
destroyed by fire.
xii
Notes and Definitions (continued)
asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in particulate form.
biodiversity - also biological diversity; the relative number of species, diverse
in form and function, at the genetic, organism, community, and ecosystem level;
loss of biodiversity reduces an ecosystem''s ability to recover from natural or
man-induced disruption.
bio-indicators - a plant or animal species whose presence, abundance, and
health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given area or volume.
carbon cycle - the term used to describe the exchange of carbon (in various
forms, e.g., as carbon dioxide) between the atmosphere, ocean, terrestrial
biosphere, and geological deposits.
catchments ■ assemblages used to capture and retain rainwater and runoff; an
important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972.
defoliants • chemicals which cause plants to lose their leaves artificially; often
used in agricultural practices for weed control, and may have detrimental impacts
on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
desertification - the spread of desert-like conditions in arid or semi-arid areas,
due to overgrazing, loss of agriculturally productive soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a technique
used for collecting bottom-dwelling marine organisms (e.g., shellfish) or harvesting
coral, often causing significant destruction of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is generally anchored to
a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by its effect of
"sweeping the ocean clean".
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial waste which
are released into the environment, subsequently polluting it.
endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources include lakes,
streams, rivers, glaciers, and underground aquifers.
greenhouse gas - a gas that traps" infrared radiation in the lower atmosphere
causing surface warming; water vapor, carbon dioxide, nitrous oxide, methane,
hydrofluorocarbons, and ozone are the primary greenhouse gases in the Earth''s
atmosphere.
groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho and
South Africa to redirect Lesotho''s abundant water supply into a rapidly growing
area in South Africa; while it is the largest infrastructure project in southern Africa,
it is also the most costly and controversial; objections to the project include claims
that it forces people from their homes, submerges farmlands, and squanders
economic resources.
xiii
Notes and Definitions (continued)
Inuit Circumpolar Conference (ICC) - represents the 125,000 Inuits of Russia,
Alaska, Canada, and Greenland in international environmental issues; a pane!
convenes every three years to determine the focus of the ICC; the most current
concerns are long-range transport of pollutants, sustainable development, and
climate change.
metallurgical plants • industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
noxious substances - injurious, very harmful to living beings.
overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (03) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultraviolet radiation that can be harmful to living organisms.
poaching - the illegal killing of animals or fish, a great concern with respect to
endangered or threatened species.
pollution - the contamination of a healthy environment by man-made waste.
potable water - water that is drinkable, safe to be consumed.
salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process; also
involves the accumulation of salts in topsoil caused by evaporation of excessive
irrigation water, a process that can eventually render soil incapable of supporting
crops.
siltation - occurs when water channels and reservoirs become clotted with silt
and mud, a side effect of deforestation and soil erosion.
slash-and-burn agriculture - a rotating cultivation technique in which trees are
cut down and burned in order to clear land for temporary agriculture: the land is
used until its productivity declines at which point a new plot is selected and the
process repeats: this practice is sustainable white population levels are low and
time is permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences for the','986f2d7b66dd9fb534fdefa95ff481f08bab5b07f5d982bcf79ae476428f10b9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63bef7c12c629983602bfe978845a3bb719a4f4663d2e8b5806eb271f3fa92fb',2002,'ZW','Zimbabwe','raw',10,'573
Taiwan
576
iv
Page
Appendixes A: Abbreviations 579
B: International Organizations and Groups 586
C: Selected International Environmental Agreements 621
D: Cross-Reference List ot Country Data Codes 629
E: Cross-Reference List of Hydrographic Data Codes 637
F: Cross-Reference List of Geographic Names 638
Reference Maps Africa
Antarctic Region
Arctic Region
Asia
Central America and the Caribbean
Europe
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk
Island
2 China - Hong Kong, Macau
2 Denmark • Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands. Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miqueton, Tromelin Island, Wallis
and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway • Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilfa, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey,
Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and
the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','fe42d88d6e5e4d595ca6e3a18215acfaee8e0e55fe7387254d1ca1d489a967b4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('783bc3d8e38f1aa357702b3b995bb6d59ef81009f65eff5a21ea7ac79a0fd843',2002,'','','raw',1,'CIA - The World Factbook 2002 -- Cambodi: e” for Release: 2022/12/08 C06979339v/cia/publications/factbook/print/cb html
Country List | World Factbook Home
Sistiphon
olemréab
Pouthiieat,
'' Phau Adraly,
e
Background: Following a five-year struggle, Communist Khmer Rouge forces
captured Phnom Penh in 1975 and ordered the evacuation of all cities and
towns; over 1 million displaced people died from execution or enforced
hardships. A 1978 Vietnamese invasion drove the Khmer Rouge into the
countryside and touched off 13 years of fighting. UN-sponsored elections
in 1993 helped restore some semblance of normalcy, as did the rapid
diminishment of the Khmer Rouge in the mid-1990s. A coalition
government, formed after national elections in 1998, brought renewed
political stability and the surrender of remaining Khmer Rouge forces.
s j
fof9 10/24/2002 11:07 AM
Approved for Release: 2022/12/08 C06979339
CIA - The World Factbook 2002 -- omg for Release: 2022/12/08 C069793390v/cia/publications/factbook/print/cb.htm]
Location: Southeastern Asia, bordering the Gulf of Thailand, between Thailand,
Vietnam, and Laos
Geographic 13 00N, 105 00E
coordinates:
Map references: Southeast Asia
Area: total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area - slightly smaller than Oklahoma
comparative:
Land total: 2,572 km
boundaries: border countries: Laos 541 km, Thailand 803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime claims: contiguous zone: 24 NM
territorial sea: 12 NM
continental shelf: 200 NM
exclusive economic zone: 200 NM
Climate: tropical; rainy, monsoon season (May to November); dry season
(December to April); little seasonal temperature variation
Terrain: mostly low, flat plains; mountains in southwest and north
Elevation lowest point: Gulf of Thailand 0 m
extremes: highest point: Phnum Aoral 1,810 m
Natural timber, gemstones, some iron ore, manganese, phosphates, hydropower
resources: potential
Land use: arable land: 21%
permanent crops: 1%
other: 78% (1998 est.)
Irrigated land: 2,700 sq km (1998 est.)
Natural hazards: monsoonal rains (June to November); flooding; occasional droughts
Environment - illegal logging activities throughout the country and strip mining for
currentissues: poems in the western region along the border with Thailand have resulted
in habitat loss and declining biodiversity (in particular, destruction of
mangrove swamps threatens natural fisheries); soil erosion; in rural areas,
a majority of the population does not have access to potable water; toxic
waste delivery from Taiwan sparked unrest in Kampong Saom
(Sihanoukville) in December 1998
Environment - party to: Biodiversity, Climate Change, Desertification, Endangered
international Species, Hazardous Wastes, Marine Life Conservation, Ozone Layer
agreements: protection, Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
mecurapiy - a land of paddies and forests dominated by the Mekong River and Tonle
note: Sap
ee
20f9 10/24/2002 11:07 AM
Approved for Release: 2022/12/08 C06979339
CIA - The World Factbook 2002 -- eee for Release: 2022/12/08 C06979339V/cia/publications/factbook/print/cb. htm!
Population:
Age structure:
Population
growth rate:
Birth rate:
Death rate:
Net migration
rate:
Sex ratio:
infant mortality
rate:
Life expectancy
at birth:
Total fertility
rate:
HIV/AIDS - adult
prevalence rate:
HIV/AIDS -
people living
with HIV/AIDS:
HIV/AIDS -
deaths:
Nationality:
Ethnic groups:
Religions:
Languages:
Literacy:
12,775,324
note: estimates for this country explicitly take into account the effects of
excess mortality due to AIDS; this can result in lower life expectancy,
higher infant mortality and death rates, lower population and growth
rates, and changes in the distribution of population by age and sex than
would otherwise be expected (July 2002 est.)
0-14 years: 40.7% (male 2,646,883; female 2,550,015)
15-64 years: 55.8% (male 3,373,692; fernale 3,758,736)
65 years and over: 3.5% (male 182,149; female 263,849) (2002 est.)
2.24% (2002 est.)
32.93 births/1,000 population (2002 est.)
10.51 deaths/1,000 population (2002 est.)
0 migrant(s)/1,000 population (2002 est.)
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 male(s)/female (2002 est.)
64 deaths/1,000 live births (2002 est.)
total population: 57.1 years
female: 59.5 years (2002 est.)
male: 54.81 years
4.66 children born/woman (2002 est.)
4.04% (1999 est.)
220,000 (1999 est.)
14,000 (1999 est.)
noun: Cambodian(s)
_ adjective: Cambodian
Khmer 90%, Vietnamese 5%, Chinese 1%, other 4%
Theravada Buddhist 95%, other 5%
Khmer (official) 95%, French, English
definition: age 15 and over can read and write
total population: 35%
male: 48%
Semale: 22% (1990 est.)
3 0f9
10/24/2002 11:07 AM
Approved for Release: 2022/12/08 C06979339
CIA -The World Factbook 2002 -- Cambodt qggprrves for Release: 2022/12/08 C06979339v/cia/publications/factbook/print/cb.htmi
4o0f9
Country name:','1b07dd095a2b9608c9eafa2b8826f3e48fb6f224bebd0791eb4f72971a62b466','internet-archive','cia-readingroom-document-06979339','txt','23fb86984440c69281d1cc4dda66f178c921f20ab0df412f204fc36999179dcb','https://archive.org/download/cia-readingroom-document-06979339/06979339_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64975345b29322906b9dfd535114d1b8895a891380186f4d5be95fc418b6be02',2002,'','','raw',1,'The Central Intelligence Agency (CIA) publishes The World
Factbook in printed and Internet versions. US Government
officials may obtain information about availability of the Factbook
from their organizations or through liaison channels to the CIA.
Other users may obtain sales information about printed copies
from the following:
Superintendent of Documents
P.O.Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [11(202)512-2250
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-5847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703)605-6900
http://www.ntls.gov/
The World Factbook can be accessed on the Internet at:
http://www.cia.gov/cla/publication8/fartbook/index.html
Imaging & Publishing Support
...the Intelligence Community publisher
ASIA
N^rwvrfjn Svalbard
rK
9° 80 100 120
JllANZ lOSEc/ J \\ \\
law/ An: tic* Ocean \\
i i x
i \\p
Cherskly''^ w ■
3 • .6
/ i y'' nct.''ava
Murmansk/'' zeum
o y.
/"in5k* 5 « ’ Vv ’ ‘
7 ^ BELAy \\
Kiev^^x- Moscow1''
X J / /Nizhniy NovgoiWv. qY/
UKR. < / V / /^7
S .Voronezh V“n'' . J 7\\^
Lo«T*y i* /v,ka"ri"b“
4 7^40,goe,X_,, S"”''’" V/chely,W»Sk
Tv’rSw* PV)/ - H .♦ /,
Astana \\
Qaraghandy
(Karaganda) •','b8693202f260ba967f0fdeb49395995a80767a7627bd4e58a7e6ba20001ae887','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee8896cddb712be78d4ea025897497d63682afd8ae3178101f5c831ef111472',2002,'KZ','Kazakhstan','raw',2,'Ukr
u Vs
Viksl '' / . ■
j m . • . ''Xc%flS«OGO :
\\ Sr^ \\ V •
Pet ro^vldvskrV
Kamenskiy «(
Sea of ^
OUlolA >
k occupied by ihc Soviet Union In 19JS.
>. adminlsiered by Russia.
\\ \\ e-alTied by In par. *
l/i ..-
\\V Khabarovsk/
rw <
lrt|^yj^»iu!cteAWf
m**
« S^^VUZBEKr"'' .. . -..MfflPfQOLIA rtf'' £\\f» T^i
r.Tehrin^^UAshi&«l^ L , v . . . ‘ of • ,\\ X#
V5I
i ^iVi/ jf ; ‘idibuf.
-Tshfrar , ,i 77 AT0HM1BT«1“%><|®^V; -V ? *
i V
Changchun -j/vladivostoj, .Ar
Sea bOapan iJj
lenvangr^pjBRTJl^ * ^
i^/X^gyang Yof*L
i^" r. j.Xoui . /«
y-c X **— W . ^ Indian dam
SSSu \\/~
W'' OM.Vi >
i*
''..liffis*
\\ J} llh/iySs" / ^fcgiJao .•<^|1''3
\\xi''JTf \\V •’
w.,iT" ’• KMltag^yUfetanglui g
I ft. A „„/U,- <61 -}.
U /■is?m 6ahir>^™/m*bW to*3it I ''•" N-nllng/rV^hanghal g
e /X-HL/m , ^,/Tl e£ fl
*/ 3 "rtkisjh ^ i
7><^Ne%vDeIhi^A • T . . V/''(c)uihg^ / • k .. 4f oWmw"y ^
!■■ f S — ★( l v ■* \\X5^<e . / /-Lhasa o.VVS- ; Vf / A7 ^ * • - • Nanehftng , y ^
/ < S ^ 1 /^sMEPAtX^-^-r^5 — V\\\\T < Xr''V . Chong''Tfng . • , , £ . V* -a
N-. ) 7 Jaipur. \\f : V A A\\« :.T‘ * / . i • Taipei J * .0\\c S ''
-°rnv, ,i atA^
U ^*SMl
Mumbai L ~ *~~
(Bombay)! ,p“"''.
Arabian
j Hyderabad /
I c Bangalore Kchennal
''( T ^ / tSui''A -X -xC",N,.nirt(, Hong Kong SiA.R.-,
r.t.Tin.^ 7K 75-''/“''? ““""''^pMacau S.A.R
mi| w-!W;^Ban6i
Phiiippin
MKSHADWfEP *, >
(INDIA)
rj,\\l H?\\lLAnD''%,
WjBi ngkok, - -
ANDAMAN U
ISLANDS {!
(INDIA) 0 Aiul-iman %L
tU VIETNAM ,
/, I SPRATtV;-.; ;
,''S ISLANDS .
CHo Chi Minh
city
r l a.*«.iiw
A Set
MALDIVES^
Scale 1:48,000,000
Azimuthal Equal-Area Projection
Boundary representation Is
not necessarily authoritative.
KtWaysia
Bandar Scrix-j
Begawaij/''f.
BRUnEL^''/r^
^Kuala Lumpur . MALAYSIA^'' ’k.:
272','5981ca3ef09da42ed38325f8d6991194a71c3390b92c718de6204d6bfe64ce15','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200932513eef6584eda43cf3bf01a08e93f552b3cae639bd6d855c4a3e133ce2',2002,'SG','Singapore','raw',3,'R^lftOArORE
\\^SiimatrcT\\^
^ MkjAbang*
(cLo&rsC ^
t M*rV - . Xo Banda 5< J
Indian
Ocean
B ''Ti D^O''^eW
. , . Java 5 M
Jakarta
-HT-V— e~ng*l^V‘ <w„S3^
iaw I
y EAST TIMOR I
Timor (tn','2c0ba0291d683ef51577e1930767773b8e7b4cc91f457f3e46272dbc53cc5801','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80b910ad73ebd547f05b9d39ce5c118554efbb66d0f1630459da189cd86d39a1',2002,'GL','Greenland','raw',4,'(DENMARK)
F.Y.R.O.M. - The Fomw Yugoslav RtpJMiS ol Vccedonta 20
Jan Mayen
(NORWAY)^
/ Sea
Reykjavfl
Hammerfe£^V,
Norwctfian 5ea
^CELAMD
Torshavn*
206
A','d7fcd196bb8272b7d5aca296fb7ec8902e299035ebed02bb0300e74bf0b93ac5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2803f7d769284b7c167ac8127a028c12a4e9cc2e07e4a1f7bb8a113c0e33e0a',2002,'FI','Finland','raw',5,'SWEDEiy a«tf \\
I A Boflvii.1
N o r t h
A t Untie
Ocean
ORKNEY
ISLANDS
HEBRIDES
Atferdccny
i DubllnJViJ,^j»
eland''
TuNGDOMS-.
CCTr. aiu Birmingham) Amstcr
,&^Car<Hn / /
I ^jrRotterda
y ^ London 7 ^ ds
^Tampere
, Helsinki
</ r:‘ : . :
%
p . t ■■■■■ ''.
Stavanger^
Y~ V
*>- ^
Nart/i
Sea
iDErif
"Stockholm jftELANDS /Tallinn l
fit \\ Y> ESTONIA \\
»■ Pc"!rsbure
yv ^Gbteborg
jfl Baltic Sea \\y
? * — rJ^OIand \\ X LI
CT6 A—
ci ^!!rlnfir«r«DssiA
Vltsyebsk kysmolensk
Vilnius, f Mahilyow
''/ *1 Minsk
Bornholm s'' £
^ ^-^GdaAskT^ \\ yHrodnj
J^\\^iamburg ? | \\
•nr-m^''v Warsaw C*Bre^-
Bremen N BCriifi Poznan Y
J * \\L, ''poland\\ ■/
y BELARUS (1 S
vHrodna \\ •
\\ HomyHV-
f London? ^ Y\\ .Essen Leipzig/^
S/ \\Cologne * V,
t%« **> /uSffW\\ ^GERMANY ./
Guernsey iu.k.)„ L— ^ L>i /f I.* Frankfurt V5
L/? rt * V .a Frankfurt
L (V M am Main 7
_ , Luxembourg s
.Parts luxXv. . /
T kS* #Stutlgarty^
V"''\\ Strasbourg Yv ^inmich
CZECH REPUBLIC
Brno* )/ SLOW
•L’vlv
Chernivtsi
176','e992ebdb137a73ac4d8c08c1fd9f60c6b52835e6e008f628b68619d4c74c2fca','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('839e8b7bc9620eb7aa64d082d983c9eab83b702772a8ef2242371577ca9fa947',2002,'UA','Ukraine','raw',6,'L>l t*~ TV .. I . ...
• A • Mykolqyiv
\\chi?inSu A~,
lil^’*. . , J.a*. / *.44Jodcsa
rnlch C iff,''” ./ ri„iv-t l»»l*\\
• <T vienna^T''- — ABupapest/ N~™|ca ■ MOLDOV/
g-W’/ 4«v. / ^..4%, ^','fc7ce5b17ce9cd3eee1f942710bf1dd9923396feebb1d7ebb3183956e4131842','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81674c5867ddbd16d2f9f7465c4313cbdbe20d5eaea31fc6901cf7cf8eabc9a5',2002,'RO','Romania','raw',7,'ji Bucharest) /Constanta
| Porto y, .- ,
/ J ZaragoaA f ^rlfiok
* __ I -..jjjaito
J f SPAIN valcnci«y ^5
^ / FRANVp p J ly ROMANIA
A / 1 \\\\ f- ,fi*Zm3irVjL a BueJj1
l\\ “^V''^^Wurln “''"Vrhlcrr^TTV^ rvA^^riVAA^. *-
^ tUm,
/ 5JJUCW
ltr t'' ^ A , 1 .''A *s?fla ''
Vama/
BUJUQAftfA A
VATTCANS''’ - <t
CITY
I #SevllIa r 47 • ''
~^0|^l|jiir.lrf4gSj^>T 5
— - Ceuta A''lvrlti
/ UsMtrt) x-j
/ -X _ _ , Mellila °S5
/ ."■ ^^^^jsraiM
Rabat rW''f •’:
^BALEARIC <*.
ISLANDS ''Kj''Sgllai
Mediterranean Sea
Algiers s^?*1
y •S'' ;~j£yi inlsj
^Casablanca ,,, ''','22d9196b14a96960170edaa78b90db80ecd6f7cb13a5a21d54b306532e56dbc7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e683a31b10f23dde430f4f9e012064f243176d4be81ef5a0590021d3d2da0c79',2002,'MA','Morocco','raw',8,';o :j '' j ALGERIA ^ ;f‘ M1S7,
Ab^'' ''TvL-a i VTr^9-Sy^,''4/:4LaA°s!rJ^lo-
2S522 —
•2 V Is r >te>r 5ea y‘i^vc, " ^ .-
. Ionian \\ ^ / p, » * ^
Sea \\ ^
^‘-''Sicily \\ \\ * ''* % * Rhodes''?
^~V ) '' 0 . A
Scale 1 : 1 9,500,000
Valletta^ Lambert Conformal Conk ProjectionTT
MALTA standard parallels 40*N and 56 ''N
0 300 Kilometers
Tyrrhenian S
Vj
Palermo
Sicily f
80291 OAI (R01083) 6-02
Central
Intelligence
Agency
The
World
Factbook
2002
In general, information available as of 1 January
2002 was used in the preparation of this edition.
The World Factbook is prepared by the Central
Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and
content are designed to meet their specific
requirements. Information is provided by Antarctic
Information Program (National Science
Foundation), Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department
of Labor), Central Intelligence Agency, Council of
Managers of National Antarctic Programs, Defense
Intelligence Agency (Department of Defense).
Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration
(Department of Transportation), National Imagery
and Mapping Agency (Department of Defense),
Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs
(Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on
Geographic Names (Department of the Interior), US
T ransportation Command (Department of Defense),
and other public and private sources.
The Factbook is in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties.
Comments and queries are welcome and may be
addressed to:
Central Intelligence Agency
Attn,: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
DISTRIBUTION STATEMENT A
Approved for Public Release
Distribution Unlimited
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence, and made available to
policymakers, Information is raw data from any source, data
that may be fragmentary, contradictory, unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished Intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President’s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only since
World War II have they been coordinated on a government¬
wide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1 ) the Joint Army Navy Intelligence Studies (JANIS), (2 j the
National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed and coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong <G-2), Adm. H. C. Train
(Office of Naval Intelligence - ONI), and Gen. William J,
Donovan (Director of the Office of Strategic Services - OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1943 and July 1947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1946, page 46) that world leadership in peace requires
even more elaborate intelligence than in war. ''The conduct of
peace involves all countries, all human activities - not just the
enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
13 January 1948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1 954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbookwas created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbookwas published in August
1 962, and the first unclassified version was published in June
1 971 . The NIS program was terminated in 1 973 except for the
Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with
sales through the US Government Printing Office (GPO). The
year 2002 marks the 55th anniversary of the establishment of
the Central Intelligence Agency and the 59th year of
continuous basic intelligence support to the US Government
by The World Factbook and its two predecessor programs.
ii
Contents
Page
Page
Page
Notes and Definitions
vii','73e9dba8d3dae738f962e0944f84a9247c55f0300d25780f0080f41479037208','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff1e22cd8062f7bf00d2ab0edde2bff987eaa49b319b57c44110f7226fac7480',2002,'HK','Hong Kong','raw',9,'232
Ashmore and Cartier Islands
29
Cote d''Ivoire
128
Howland Island
234
Atlantic Ocean
29','bce5e75174269b443957d90c123a63991f9e85e5a4c94bbb6dbbee0c40bf1538','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('301ca4a95f814ccee8ec84f7f1f379773ab0d869a3ef09f6e5ce966af54e8454',2002,'LY','Libya','raw',10,'301
iii
Page
Liechtenstein 303
Lithuania 305
Luxembourg 308
M Macau 310
Macedonia, The Former Yugoslav 312
Republic of
Madagascar 314
Malawi 317
Malaysia 319
Maldives 322
Mali 324
Malta _ 326
Man, Isle of 328
Marshall Islands 330
Martinique 332
Mauritania 334
Mauritius 336
Mayotte 338
Mexico 340
Micronesia, Federated States of 343
Midway Islands 345
Moldova 346
Monaco 348
Mongolia 350
Montserrat 353
Morocco 354
Mozambique 357
N Namibia 360
Nauru ’ 362
Navassa Island 364
Nepal 365
Netherlands 367
Netherlands Antilles 370
New Caledonia 372
New Zealand 374
Nicaragua 377
Niger 379
Nigeria 382
Niue 384
Norfolk Island 386
Northern Mariana Islands 38B
Norway 390
O Oman 392
P Pacific Ocean 394
Pakistan 395
Palau 398
Palmyra Atoll 400
Panama 401
Papua New Guinea 404
Paracel Islands 406
Page
Paraguay 407
Peru 409
Philippines 412
Pitcairn Islands 415
Poland 416
Portugal 419
Puerto Rico 422
Q Qatar 424
R Reunion 426
Romania 428
Russia 431
Rwanda 434
S Saint Helena 437
Saint Kitts and Nevis 438
Saint Lucia 440
Saint Pierre and Miquelon 442
Saint Vincent and the Grenadines 444
Samoa 446
San Marino 448
Sao Tome and Principe 450
Saudi Arabia 452
Senegal 454
Seychelles 456
Sierra Leone 458
Singapore 461
Slovakia 463
Slovenia 466
Solomon Islands 468
Somalia 470
South Africa 473
South Georgia and the South 475
Sandwich Islands
Southern Ocean 476
Spain 478
Spratly Islands 48?
Sri Lanka 481
Sudan 484
Suriname 486
Svalbard 489
Swaziland 490
Sweden 492
Switzerland 495
Syria 497
T Taiwan entry follows Zimbabwe
Tajikistan 500
Tanzania 503
Thailand 505
Togo 508
Tokelau 510
Tonga _ 512
_ Page
Trinidad and Tobago 514
Tromelin Island 516','4049445bdd5da64eef961854aea0fc1fd9ccb766969c8c1e896483eb4bb31136','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34491db58befdffa40dbd0c9ebf3714b18f9f49bc3ee194f2f08a7711a3c1498',2002,'TN','Tunisia','raw',11,'Turkey _ 519
Turkmenistan 522
Turks and Caicos Islands 525
Tuvalu 526
U Uganda 528
Ukraine 531
United Arab Emirates 534
United Kingdom 536
United States 540
Uruguay 543
Uzbekistan 546
V Vanuatu 548
Venezuela 550
Vietnam 553
Virgin Islands 555
W Wake Island 557
Wallis and Futuna 558
West Bank 560
Western Sahara 562
World 564
Y Yemen 566
Yugoslavia 568
Z Zambia 571
Zimbabwe 573
Taiwan 576
iv
Appendixes
A: Abbreviations 579
B: International Organizations and Groups 586
C: Selected International Environmental Agreements 621
D: Cross-Reference List of Country Data Codes 629
E: Cross-Reference List of Hydrographic Data Codes 637
F: Cross-Reference List of Geographic Names 638
Reference Maps Africa
Antarctic Region
Arctic Region
Asia
Central America and the Caribbean
Europe
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World','12c05a55d133835acf2aaaf9b5f6710a73cc5c84b32ad9660538bb3a4986dde0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffeba95235353c3a9088e1a6550b5d3110db6a9803da4f4a44a2208c8331b0ae',2002,'US','United States','raw',12,'Notes and Definitions
In addition to the updating of information, the following changes have been made
in this edition of The World Factbook. There is a new country profile on East Timor
and there is a new entry on Distribution of family income ■ Gini index. Revision
of some individual country maps, first introduced in the 2001 edition, is continued
in this edition. The revised maps include elevation extremes and a partial
geographic grid,
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up solely from
the first letter of the major words in the expanded form is rendered in all capital
letters (NATO from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general, an acronym made
up of more than the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement). Hybrid
forms are sometimes used to distinguish between initially identical terms (WTO:
WTrO for World Trade Organization and WToO for World Tourism Organization.)
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years,
65 years and over). The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture * products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports * with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to the following five
groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m, (4) 914 to
1 ,523 m, and (5) under 91 4 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for refueling, maintenance, or air traffic
control.
Airports - with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces) by length. For airports
with more than one runway, only the longest runway is included according to the
vii
Notes and Definitions (continued)
following five groups - (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m,
(4) 914 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control
Appendixes: This section includes Facfboofc-related material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Wafer area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area • comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census, The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annual number of births during a year per
1 ,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms
Capital: This entry gives the location of the seat ot government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, television, and Internet service provider entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes: see Data codes
Country map: Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
viii
Notes and Definitions (continued)
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italians), local short form ( Italia), former(Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Currency: This entry identifies the national medium of exchange and its basic
subunit.
Currency code: This entry gives the International Organization for
Standardization (ISO) 4217 alphabetic currency code for each country.
Data codes: This information is presented in Appendix D: Cross-Reference List
of Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes. This appendix includes the US Government
approved Federal Information Processing Standards (FIPS) codes, the
International Organization for Standardization (ISO) codes, and Internet codes for
land entities. The appendix also includes the International Hydrographic
Organization (IHO) codes, Aeronautical Chart and Information Center (ACIC; now
a part of the National Imagery and Mapping Agency or NIMA) codes, and Defense
Intelligence Agency (DIA) codes for hydrographic entities. The US Government
has not yet approved a standard for hydrographic data codes similar to the FIPS
10-4 standard for country data codes.
Date of Information: In general, information available as of 1 January 2001 , was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total public and private debt owed to
nonresidents repayable in foreign currency, goods, or services.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
185 independent states, including 183 of the 189 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, and the US itself). In addition,
the US has diplomatic relations with 3 independent states that are not in the UN -
East Timor, Holy See, and Switzerland.
Diplomatic representation in the US: This entry includes the chief of mission,
chancery, telephone, FAX, consulate general locations, and consulate locations.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, branch office
locations, consulate general locations, and consulate locations.
ix
Notes and Definitions (continued)
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Distribution of family income - Gini index: This index measures the degree of
inequality in the distribution of family income in a country. The index is calculated
from the Lorenz curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The index is the ratio
of (a) the area between a country''s Lorenz curve and the 45 degree helping line
to (b) the entire triangular area under the 45 degree line. The more nearly equal a
country''s income distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index of 25. The more
unequal a country''s income distribution, the farther its Lorenz curve from the 45
degree line and the higher its Gini index, e.g., a Sub-Saharan country with an index
of 50. tf income were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if income were
distributed with perfect inequality, the Lorenz curve would coincide with the
horizontal axis and the right vertical axis and the index would be 100.
Economic aid - donor: This entry refers to net official development assistance
(ODA) from Organization for Economic Cooperation and Development (OECD)
nations to developing countries and multilateral organizations. ODA is defined as
financial assistance that is concessional in character, has the main objective to
promote economic development and welfare of the less developed countries
(LDCs), and contains a grant element of at least 25%. The entry does not cover
other official flows (OOF) or private flows.
Economic aid ■ recipient: This entry, which is subject to major problems of
definition and statistical coverage, refers to the net inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new inflows
and repayments.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity • consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and
distribution.
x
Notes and Definitions (continued)
Electricity - exports: This entry is the total exported electricity in kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in kilowatt-hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt-hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Electricity - production by source: This entry states the percentage share of
electricity generated from each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes: This entry includes both the highest point and the lowest
point.
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government, "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 268 separate
geographic entities in The World Factbook that may be categorized as follows:
INDEPENDENT STATES
1 92 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
XI
Notes and Definitions (continued)
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','ab71f595198c653994c568dde571de08c88a56cb07d0b5a5343c8ea4886fa474','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0eea65236a29a5abda44515949aa154358a82ee404c083e882698bbf1e33e18',2002,'ZW','Zimbabwe','raw',13,'OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk
Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands. Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilla, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey,
Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and
the South Sandwich Islands, Turks and Caicos Islands
14 US • American Samoa, Baker Island, Guam, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','8d16d7fc49d9e2d959d19a4aded2da3a6843b2b1fa85c91816dd10567915c336','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('669beea111f5f9dc8769e8133780c0bc2c540d13a8fc7e94fd14ba652322b5ce',2002,'EH','Western Sahara','raw',14,'OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
268 total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
acidification - the lowering of soil and water pH due to acid precipitation and
deposition usually through precipitation; this process disrupts ecosystem nutrient
flows and may kill freshwater fish and plants dependent on more neutral or alkaline
conditions (see acid rain).
acid rain - characterized as containing harmful levels of sulfur dioxide or
nitrogen oxide; acid rain is damaging and potentially deadly to the earth''s fragile
ecosystems; acidity is measured using the pH scale where 7 is neutral, values
greater than 7 are considered alkaline, and values below 5.6 are considered acid
precipitation; note - a pH of 2.4 (the acidity of vinegar) has been measured in
rainfall in New England.
aerosol • a collection of airborne particles dispersed in a gas, smoke, or fog.
afforestation - converting a bare or agricultural space by planting trees and
plants; reforestation involves replanting trees on areas that have been cut or
destroyed by fire.
xn
Notes and Definitions (continued)
asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in particulate form.
biodiversity - also biological diversity; the relative number of species, diverse
in form and function, at the genetic, organism, community, and ecosystem level;
loss of biodiversity reduces an ecosystem''s ability to recover from natural or
man-induced disruption.
bio-indicators - a plant or animal species whose presence, abundance, and
health reveal the general condition of its habitat.
biomass - the total weight or volume of living matter in a given area or volume,
carbon cycle - the term used to describe the exchange of carbon (in various
forms, e.g., as carbon dioxide) between the atmosphere, ocean, terrestrial
biosphere, and geological deposits.
catchments ■ assemblages used to capture and retain rainwater and runoff; an
important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972.
defoliants - chemicals which cause plants to lose their leaves artificially; often
used in agricultural practices for weed control, and may have detrimental impacts
on human and ecosystem health.
deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
desertification - the spread of desert-like conditions in arid or semi-arid areas,
due to overgrazing, loss of agriculturally productive soils, or climate change.
dredging - the practice of deepening an existing waterway; also, a technique
used for collecting bottom-dwelling marine organisms (e.g., shellfish) or harvesting
coral, often causing significant destruction of reef and ocean-floor ecosystems.
drift-net fishing - done with a net, miles in extent, that is generally anchored to
a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by its effect of
“sweeping the ocean clean”.
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke, sewage, or industrial waste which
are released into the environment, subsequently polluting it.
endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
freshwater ■ water with very low soluble mineral content; sources include lakes,
streams, rivers, glaciers, and underground aquifers.
greenhouse gas • a gas that “traps” infrared radiation in the lower atmosphere
causing surface warming; water vapor, carbon dioxide, nitrous oxide, methane,
hydrofluorocarbons, and ozone are the primary greenhouse gases in the Earth''s
atmosphere.
groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho and
South Africa to redirect Lesotho''s abundant water supply into a rapidly growing
area in South Africa; while it is the largest infrastructure project in southern Africa,
it is also the most costly and controversial; objections to the project include claims
that it forces people from their homes, submerges farmlands, and squanders
economic resources.
XIII
Notes and Definitions (continued)
Inuit Circumpolar Conference (ICC) - represents the 1 25,000 Inuits of Russia,
Alaska, Canada, and Greenland in international environmental issues; a panel
convenes every three years to determine the focus of the ICC; the most current
concerns are long-range transport of pollutants, sustainable development, and
climate change.
metallurgical plants - industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
noxious substances - injurious, very harmful to living beings,
overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
ozone shield ■ a layer of the atmosphere composed of ozone gas (03) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultraviolet radiation that can be harmful to living organisms.
poaching - the illegal killing of animals or fish, a great concern with respect to
endangered or threatened species.
pollution - the contamination of a healthy environment by man-made waste,
potable water ■ water that is drinkable, safe to be consumed,
salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process; also
involves the accumulation of salts in topsoil caused by evaporation of excessive
irrigation water, a process that can eventually render soil incapable of supporting
crops.
siltation - occurs when water channels and reservoirs become clotted with silt
and mud, a side effect of deforestation and soil erosion.
slash-and-burn agriculture - a rotating cultivation technique in which trees are
cut down and burned in order to clear land for temporary agriculture: the land is
used until its productivity declines at which point a new plot is selected and the
process repeats; this practice is sustainable while population levels are low and
time is permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences for the','46378f9bb0cb802354889672edcb473bf3a05b439032606e9cf8a811286de400','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1da6944dc52fe71deff2bf1fa501ae2800d34ef3ee51b8d088f67c27d417a9eb',2002,'','','raw',1,'The Project Gutenberg EBook of The 2002 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2002 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: December 27, 2008 [EBook #6344]
Release Date: August, 2004
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2002 CIA WORLD FACTBOOK ***
Produced by Philip Serracino Inglott
CIA -- The World Factbook 2002 -- Country Listing','a8108e2058f4e7fa710c9113db9f5200adc31ec6aea0a39561fff3c76107f73c','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5f7bc04d0d1649f779c4a339c8a236f2c2f2957ad7afa4b0dc3ee0032b4fdc',2002,'ZW','Zimbabwe','raw',2,'Taiwan
CIA - The World Factbook 2002
========================================================================','f333b6335f892aa52101d0fbc54f653832d3286d42e0b485e53169ee07e0d193','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

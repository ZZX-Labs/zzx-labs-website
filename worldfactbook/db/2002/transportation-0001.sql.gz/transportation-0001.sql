SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52242ed370a2b9ec2ca972ef330492023978472e133b371c4f488f55769f9d6a',2002,'AU','Australia','transportation',23,'Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Highways
total
paved
unpaved
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports - with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,427 m
914 to 1,523 m
under 91 4 m
Airports - with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Transportation - note
Railways:
total: 24.6 km
broad gauge: 9.6 km 1 .524-m gauge from Gushgy
(Turkmenistan) to Towraghondi; 15 km 1. 524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
(2001)
Highways:
tote/; 21 ,000 km
paved: 2,793 km
unpaved: 18,207 km (1998 est.)
Waterways: 1,200 km
note: chiefly Amu Darya, which handles vessels up to
500 DWT(2001)
Pipelines: natural gas 180 km
note: product pipelines from Uzbekistan and
Turkmenistan have been in disrepair and disuse for
years (2002)
Ports and harbors: Kheyrabad, Shir Khan
Airports: 46(2001)
Airports - with paved runways:
tofaMO
over 3,047 m: 3
2,438 to 3,047 m: A
1,524 to 2,437 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 36
2,438 to 3,047 m: 7
1,524 to 2,437 m:13
914 to 1,523 m: 4
under 91 4 m:11 (2001)
Heliports: 2(2001)
Railways:
total: 447 km
standard gauge: 441 km 1.435-m gauge (2001 est.)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km
note: includes Albanian sections of Lake Scutari, Lake
Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 196 km; petroleum products 55
km; natural gas 64 km (1996)
Ports and harbors: Durres, Sarande, Shengjin,
Vlore
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 1 3,423
GRT/20f837DWT
ships by type: cargo 7, includes some foreign-owned
ships registered here as a flag of convenience:
Croatia 1, Honduras 1 (2002 est.)
Airports: 11 (2001)
Airports ■ with paved runways:
total: Z
2,438 to 3,047 m: 3 (2001)
Airports - with unpaved runways:
total: $
over 3,047 m;1
1,524 to 2,431 rm;1
91 ''4 to 1,523 m: 2
under 914 m: 4 (2001)
Heliports: 1 (2001)
Railways:
total: 4,820 km
standard gauge: 3,664 km 1.435-m gauge (301 km
electrified; 215 km double-track)
narrow gauge: 1,156 km 1.055-m gauge (1999 est.)
Highways:
total: 104,000 km
paved: 71 ,656 km (including 640 km of expressways) ''
unpaved: 32,344 km (1996 est.)
Waterways: none
Pipelines: crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Dellys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 73 ships (1 ,000 GRT or over) totaling 903,944
GRT/1,051,433DWT
ships by type: bulk 9, cargo 25, chemical tanker 7,
liquefied gas 1 0, petroleum tanker 5t roll on/roll off 1 2,
short-sea passenger 4, specialized tanker 1 , includes
some foreign-owned ships registered here as a flag of
convenience: United Arab Emirates 2 (2002 est.)
Airports: 136(2001)
Airports - with paved runways:
tofa/:52
over 3,047 m: 9
2,438 to 3,047 m: 26
1,524 to 2,437 m:M
914 to 1,523 m: 5
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 84
2,438 to 3,047 m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 40
under 914 m: 18 (2001)
Heliports: 1 (2001)
Railways:
tofa/: 33,81 9 km (2,540 km electrified)
broad gauge: 3,719 km 1.600-m gauge
standard gauge: 15,422 km 1.435-m gauge
narrow gauge: 14,506 km 1.067-m gauge
dual gauge: 172 km NA gauges (1999 est.)
Highways:
tote/: 91 3,000 km
paved: 353,331 km (including 1,363 km of
expressways)
unpaved: 559,669 km (1996)
Waterways: 8,368 km (mainly used by small,
shallow-draft craft)
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantie, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 55 ships (1 ,000 GRT or over) totaling 1 ,469,362
GRT/1 ,869,262 DWT
ships by type: bulk 26, cargo 5, chemical tanker 4,
container 1, liquefied gas 4, passenger 2, petroleum
tanker 7, roll on/roll off 6, includes some
foreign-owned ships registered here as a flag of
convenience: France 2, United Kingdom 2, United
States 14 (2002 est.)
Airports: 421 (2001)
Airports - with paved runways:
total: 282
over 3,047 m: 10
2,438 to 3,047 m: 11
1,524 to 2,437 m:m
914 to 1,523 m: 124
under 914 m: 9 (2001)
Airports - with unpaved runways:
total: 139
1,524 to 2,437m: 16
914 to 1,523 m: 111
under 914 m: 12 (2001)
Railways:
total: 6,095.2 km (3,643.3 km electrified)
standard gauge: 5,564.2 km 1.435-m gauge (3,521.2
km electrified)
narrow gauge: 33.9 km 1 .000-m gauge (28.1 km
electrified); 497.1 km 0.760*m gauge (94 km
electrified) (2001 est.)
Highways:
total: 133,361 km
paved: 133,361 km (including 1,613 km of
expressways)
unpaved: 0 km (1998)
Waterways: 358 km (1999)
Pipelines: crude oil 777 km; natural gas 840 km
(1999)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 1 0 ships (1 ,000 GRT or over) totaling 46,563
GRT/59.278DWT
ships by type: bulk 1 , cargo 6, combination bulk 1 ,
container 2 (2002 est)
Airports: 55(2001)
Airports - with paved runways:
total: 24
over 3,047 m:1
2,438 to 3,047m: 5
1,524 to 2,437 m:1
914 to 1523 m:3
unofer0f4ro:14(2OO1)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m:\\
914 to 1,523 m: 3
under 914 m:Z?(zm)
Heliports: 1 (2001)
Military branches: Land Forces (KdoLdSK), Air
Forces (KdoLuSK)
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,092,623 (2002 est.)
Military manpower - fit for military service:
males age 75-49:1,728,191 (2002 est.)
Military manpower - reaching military age
annually:
males: 50,580 (2002 est.)
Military expenditures - dollar figure:
$1,497,100,000 (FY01/02)
Military expenditures - percent of GDP: 0.8%
(FY01/02)
35
Waterways: none
Ports and harbors: none; offshore anchorage only
Railways: 0 km
Highways:
fofa/:234km
paved: 86 km
unpaved: 148 km (1 06 km of which is access and
plantation road) (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
tofaM
1,524 to 2,437 m: 1 (2001)','45a4ec6bacabae186f6143258c7ea38c64525ce2f5a8b68e9ce202f749c87e35','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55b13cd0ad6b35943c5b98e4e7c5c930144923d73dc96ccfe327c94b65399c7',2002,'NZ','New Zealand','transportation',33,'RatlWays: 0 km
Highways:
total: ZbO km
paved: ^0 km
unpaved: 200 km
Waterways: none
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none (2002 est.)
Airports: 4 (2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 2
under 914 m:2 (2001)
Railways:
total: 3,908 km
narrow gauge: 3,908 km 1 .067-m gauge (506 km
electrified) (2001)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1996)
Waterways: 1,609 km
note: of little importance in satisfying total
transportation requirements
Pipelines: petroleum products 160 km; natural gas
1,000 km: liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 68,427
GRT/1 06,627 DWT
ships by type: bulk 3, cargo 1 , container 1 , petroleum
tanker 2, roll on/roll off 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Australia 1 (2002 est.)
Airports: 106(2001)
Airports ■ with paved runways:
tofa/:44
over 3,047 m: 2
2,438/0 3,047/71:1
1,524 to 2,437 m: 10
914 to 1,523 m: 28
under 914 m: 3 (2001)
Airports • with unpaved runways:
total: 62
1,524 to 2,437 m^
914 to 1,523 m: 24
under 914 m: 37 (2001)
Heliports: 1 (2001)
376
New Zealand (continued)
Railways: Okm
Highways:
fofa/; 680 km
paved: 184 km
unpa ved: 496 km (1996)
Waterways: none
Ports and harbors: Neiafu, Nukualofa, Pangai
Merchant marine:
total: 80 ships (1,000 GRT or over) totaling 292,139
GRT/421,221 DWT
ships by type: bulk 10, cargo 54, liquefied gas 4,
petroleum tanker 8, roll on/roll off 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 1 , Australia 4,
Austria 1 , Bolivia 1 , Cyprus 1 , Djibouti 1 , Egypt 2,
Greece 4, Lebanon 2, Liberia 2, Marshall Islands 2,
Morocco 1 , Norway 1, Panama 1, Romania 3,
Russia 1, Sao Tome and Principe 1, Saudi Arabia 2,
Singapore 1, Sweden 1, Switzerland 3, Syria 5,
Ukraine 1, United Arab Emirates 16, United States 4
(2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1 (2001)
513
Tonga (continued)
Airports - with unpaved runways:
total: 4
Trinidad and SjSI
1,524 to 2,437 m:1
9f4tot,523m:1
Tobago ■fiSS
under PMm: 2 (2001)
O IS 30km
Railways: minimal agricultural railroad system near
San Fernando; common carrier railway service was
discontinued in 1968(2001)
Highways:
fofa/: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1996)
Waterways: none
Pipelines: crude oil 1 ,032 km; petroleum products 1 9
km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,91 0 GRT/
7,546 DWT
ships by type: cargo 2, petroleum tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: Z
over 3,047 m:1
2,438 to 3,047 m;1
1,524to2,437m:\\(200\\)
Airports - with unpaved runways:
iotan
914 to 1,523 mA
under 914 m: 2 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
totals
under 914 m A (2001)
Railways: 0 km
Highways:
total: 120 km (ile Uvea 100 km, lie Futuna 20 km)
paired'' 16 km (all on Ile Uvea)
unpaved: 104 km (He Uvea 84 km, Ile Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 71 ,868
GRT/7,422 DWT
ships by type: passenger 4
note; includes some foreign-owned ships registered
here as a flag of convenience: France 3, United States
1 (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
tofa/;1
1,524 to ZA$7m:\\ (2001)
Airports - with unpaved runways:
tote/: 1
914 to 1,523 m: 1 (2001)','d51d847b2f5c9ce01485a40c055ab6ce476c7c04b74c94793cb23f083a109cd2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ada0d5b25d5c99d625453b308c6bed62c5a322d412a1d44a263df0088fda569',2002,'ES','Spain','transportation',42,'Railways: 0 km.
Highways:
fofa/: 269 km
■pared: 198 km
unpaved: 71 km (1994 est.)
Waterways: none
Ports and harbors: none
Airports: none (2001)
Railways:
total: NA km; 1 ,000-m gauge system in dockyard area
only (no longer used) (2001 est.)
Highways:
total: 46.25 km
paved: 46.25 km
unpaved: 0 km (2001)
Waterways: none
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 75 ships (1 ,000 GRT or over) totaling 900,400
GRT/1, 277,61 1 DWT
ships by type: bulk 2, cargo 35, chemical tanker 6,
container 10, multi-functional large-load carrier 3,
passenger 3, petroleum tanker 14, roll on/rofl off 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1, Cyprus 1,
France 2, Germany 55, Greece 6, Ireland 1 ,
Monaco 2, Norway 3, United Kingdom 13 (2002 est.)
Airports: 1(2001)
Airports - with paved runways:
fofaM
1,524 to 2,437 m: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Railways:
fotef; 15.171 km
broad gauge: 12,781 km''1.668-m gauge (6,434 km
electrified)
standard gauge: 525 km 1.435-m gauge (525 km
electrified)
narrow gauge: 1 ,837 km 1.000-m gauge (617 km
electrified); 28 km 0.914-m gauge (28 km electrified)
(2001)
Highways:
ml: 346,858 km
paved: 343,389 km (including 9,063 km of
expressways)
unpaved: 3,469 km (1997)
Waterways: 1 ,045 km (of minor economic
importance)
Pipelines: crude oil 265 km; petroleum products
1,794 km; natural gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilla, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Sanlander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 144 ships (1 ,000 GRT or over) totaling
1,364,751 GRT/1 ,962,764 DWT
shjps by type: bulk 10, cargo 31 , chemical tanker 10,
container 10, liquefied gas 2, livestock carrier 1 ,
passenger 2, petroleum tanker 24, refrigerated cargo
8, roll on/roll off 35, short-sea passenger 8, vehicle
carrier 3
nofe: includes some foreign-owned ships registered
here as a flag of convenience; Croatia 1 , Cuba 2,
Denmark 1 , Germany 7, Italy 1 , Netherlands 1 ,
Norway 6, Uruguay 3 (2002 est.)
Airports: 133(2001)
Airports - with paved runways:
total: 85
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 18
914to 1,523m:W
under 914 m: 23 (2001)
Airports - with unpaved runways:
tofa/:48
1,524 to 2,437 m:1
914 to 1,523 m: 14
uncfer 974 m: 33 (2001)
Heliports: 5(2001)','e6c22c33dda9366b285adf38302e7751b2930c569a853eb7ff86753438fa4679','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a377a11c7092567d5fe4d7d10de91488ce185cd979899b38b6242de88a46cba',2002,'AO','Angola','transportation',51,'Railways:
total: 2,771 km (inland, much of the track is unusable
because of land mines still in place from the civil war)
narrow gauge: 2,648 km 1 .067-m gauge; 123 km
0.600-m gauge (2000 est.)
Highways:
total: 76,626 km
pa ved: 19,156 km
unpaved: 57,470 km (1997)
Waterways; 1,295 km
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Mocamedes, Namibe, Porto
Amboim, Soyo
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 39,305
GRT/63,528 DWT
ships by type: cargo 8, petroleum tanker 1 (2002 est.)
Airports: 244 (2001)
Airports - with paved runways:
total: 32
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m:K
914 to 1,523 m:6
under 914 m: 1 (2001)
Airports - with unpaved runways:
tote/: 212
over 3, 047 m: 2
2,438 to 3,047 m: 5
1t524 to 2A37m: 30
914 to 1,523 m:%
under 914 m: 80 (2001)','1b51517e220dfdf5c1ee4e02d42e91d80d003ce1d343021621f3b285165c731b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c99f8e3d898e1b2f5ca6c770bddd0ac80c1508b597507bdd8c6fa0aa08bb3e41',2002,'AI','Anguilla','transportation',61,'Railways: 0 km
Highways:
tofa/:105 km
paved: 65 km
unpaved:40 km (1998 est.)
Waterways: none
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (2001)
Airports • with unpaved runways:
total: 2
under 914 m: 2 (2001)','5a6a47241d88171d1f4d3c90919ac1ed5defbca3701469e4d2f2ccdba7910115','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2804f10bf0c0ab9b6faa3dfeb15a43cc8e09c38c2141cc004f4c699027a9620a',2002,'AQ','Antarctica','transportation',69,'Ports and harbors: there are no developed ports
and harbors in Antarctica: most coastal stations have
offshore anchorages, and supplies are transferred
from ship to shore by small boats, barges, and
helicopters; a few stations have a basic wharf facility;
US coastal stations include McMurdo (77 51 S, 1 66 40
E), Palmer (64 43 S, 64 03 W); government use only
except by permit (see Permit Office under "Legal
System"); all ships at port are subject to inspection in
accordance with Article 7, Antarctic Treaty; offshore
anchorage is sparse and intermittent
Airports: 30(2001)
note: 27 stations, operated by 16 national
governments party to the Antarctic Treaty, have
aircraft landing facilities for either helicopters and/or
fixed-wing aircraft; commercial enterprises operate
two additional aircraft landing facilities; helicopter
pgds are available at 27 stations; runways at 15
locations are gravel, sea-ice, blue-ice, or compacted
snow suitable for landing wheeled, fixed-wing aircraft;
of these, 1 is greater than 3 km in length, 6 are
between 2 km and 3 km in length, 3 are between 1 km
and 2 km in length, 3 are less than 1 km in length, and
2 are of unknown length; snow surface skiways,
limited to use by ski-equipped, fixed-wing aircraft, are
available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and
3 km in length, 2 are between 1 km and 2 km in length,
2 are less than 1 km in length, and 4 are of unknown
length; aircraft landing facilities generally subject to
severe restrictions and limitations resulting from
extreme seasonal and geographic conditions; aircraft
landing facilities do not meet ICAO standards;
advance approval from the respective governmental
or nongovernmental operating organization required
for landing; landed aircraft are subject to inspection in
accordance with Article 7t Antarctic Treaty
Airports - with unpaved runways:
total: 19
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m;1
914 to 1,523 m: 4
under 914 m: 5 (2m)
Heliports: 27 stations have helicopter landing
facilities (helipads) (2001)','d2335058bfcad712b387de9b3b47fa6b054cf0be67ca9c8f1088446c26edd441','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d99607d9cb469cedd63033f11efc71923bcacf830b12a27361ba5c17a4d331',2002,'GP','Guadeloupe','transportation',79,'Railways:
fofa/:77km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.61 0-m
gauge (used almost exclusively for handling
sugarcane) (2001 est.)
Highways:
tote/; 1,165 km
paved: 384 km
unpaved: 781 km
note: it is assumed that the main roads are paved; the
secondary roads are assumed to be unpaved (1995)
Waterways: none
Ports and harbors: Saint John''s
Merchant marine:
total: 762 ships (1 ,000 GRT or over) totaling
4,541 ,940 GRT/5,894,553DWT
ships by type: bulk 20, cargo 469, chemical tanker 9,
combination bulk 4, container 202, liquefied gas 7,
multi-functional large-load carrier 6, petroleum tanker
1, refrigerated cargo 9, roll on/roll off 35
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 ,
Bangladesh 2, Belgium 3, Colombia 1, Cuba 1,
Estonia 1 , Germany 747, Greece 1 , Iceland 8, Latvia
1, Lebanon 2, Lithuania 1, Netherlands 22, New
Zealand 2, Portugal 1, Slovenia 6, South Africa 1,
Sweden 2, United Kingdom 1 , United States 7
(2002 est.)
Airports: 3(2001)
Airports - with paved runways:
totef;2
2,438 to 3,047 m:]
under Wm: 1 (2001)
Airports - with unpaved runways:
total:]
under 914 m: 1 (2001)
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
Transportation - note: sparse network of air, ocean,
river, and land routes; the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways','fe6259aa1c7fcb64163798ac35ae2a7eebf676f692e07dd30df02373699deee2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('121b8c2b4e150564edb3a192cbe8fd9cade53a7216cf28e21a9e38801425e3e5',2002,'AM','Armenia','transportation',97,'Railways:
total: 852 km in common carrier service; does not
include industrial lines
broad gauge: 852 km 1.520-m gauge (779 km
electrified) (2001 est.)
Highways:
total: 11,300 km
paved: 10,500 km (includes some all-weather
gravel-surfaced roads)
unpaved: 800 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: NAkm
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 7(2001)
Airports - with unpaved runways:
total:!
over 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m:$
under 914 m: 1 (2001)
Railways: Okm
Highways:
tofa/:800 km
paved: 51 3 km
unpaved: 287 km
note: most coastal roads are paved, while unpaved
roads serve large tracts of the interior (1995)
Waterways: none
Ports and harbors: Barcadera, Oranjestad, Sint
Nicolaas
Merchant marine: includes a foreign-owned ship
registered here as a flag of convenience: Monaco 1
(2002 est)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
Transportation - note: Kiel Canal and Saint
Lawrence Seaway are two important waterways;
significant domestic commercial and recreational use
of Intracoastal Waterway on central and south Atlantic
seaboard and Gulf of Mexico coast of US','18b839235a9a4af45e384acb2aff5a16ca57960191ac38e9397d66004d4a122c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92dcf1e20fdd66cd85acbf4a73ace53e6e2c3c11fcf60ff51a35d02898fad697',2002,'AZ','Azerbaijan','transportation',105,'Railways:
total: 2,125 km in common carrier service; does not
include industrial lines
broad gauge: 2,\\2$ km 1,520-m gauge (1,278 km
electrified) (1993 est.)
Highways:
total: 36,700 km
paved: 31 ,800 km (includes some all-weather
gravel-surfaced roads)
unpaved: 4,900 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: crude oil 1,130 km; petroleum products
630 km; natural gas 1 ,240 km
Ports and harbors: Baku(Baki)
t Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 246,051
GRT/306,756 DWT
ships by type: cargo 12, petroleum tanker 40, roll on/
roll off 2 (2002 est)
Airports: 52(2001)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 5
1524 to 2,437 m: 4 (2001)
Airports - with unpaved runways:
tofa/:43
1t524to2f437m:7
914 to 1,523 m:B
under 914 m:2%(200\\)','d4c8280ceaa0785b88ac8683e0cdf98efc760c3819e69be3efa1a15b40ff52b9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d0b538ebce5a7c1be4976071c0df5ab53de8c08c5e00f3e93ff421e4f60d2e1',2002,'BS','Bahamas','transportation',110,'Railways: Okm
Highways:
total: 2,693 km
pavecf: 1 ,546 km
unpaved: 1,147 km (1997)
Waterways: none
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,076 ships (1 ,000 GRT or over) totaling
31,309,187 GRT/45,859,485 DWT
ships by type: bulk 1 59, cargo 246, chemical tanker
41, combination bulk 13, combination ore/oil 22,
container 80, liquefied gas 28, livestock carrier 2,
multi-functional large-load carrier 8, passenger 88,
passenger/cargo 1 , petroleum tanker 178, railcar
carrier 1, refrigerated cargo 120, roll on/roll off 49,
short-sea passenger 16, specialized tanker 2, vehicle
carrier 22
nofe: includes some foreign-owned ships registered
here as a flag of convenience: Angola 1 , Argentina 1 ,
Australia 4, Belgium 18, Bermuda 1, Canada 5, Chile
1 , China 3, Croatia 2, Cuba 3, Cyprus 2, Denmark 27,
Ecuador 1 , Estonia 2, Finland 9, France 15, Germany
26, Greece 173, Hong Kong 6, India 2, Indonesia 2,
Ireland 1 , Israel 3, Italy 9, Jamaica 1 , Japan 32, Kenya
3, Malaysia 10, Malta 2, Monaco 67, Netherlands 32,
New Zealand 2, Norway 237, Panama 2, Philippines
3, Poland 13, Reunion 1 , Russia 6, Saudi Arabia 9,
Singapore 13, Slovenia 1, South Korea 2, Spain 7,
Sweden 12, Switzerland 8, Thailand 1, Trinidad and
Tobago 2, Turkey 2, Ukraine 2, United Arab Emirates
10, United Kingdom 107, United States 159, Uruguay
1 (2002 est.)
Airports: 67(2001)
Airports - with paved runways:
tofa/:32
over 3, 047 m: 3
2,438 to 3,047 m: 4
7,524 to 2,437 m: 12
914 to 1,523 m: 10
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 23 (200))
Heliports: 1 (2001)','b1709e316bd22bacdd4655d29dffe29d4537d6b43169d2b5ab70bccfe8a471ad','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1801d8087105e2358baa77a4f0160c3168ae728dc433ab846924056ec88107e0',2002,'BH','Bahrain','transportation',120,'Railways: 0 km
Highways: 3,164 km
paved: 2,433 km
unpaved: 731 km
note: a paved causeway links Bahrain and Saudi
Arabia
Waterways: none
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 270,784
GRT/384,561 DWT
ships by type: bulk 2, cargo 4, container 2, includes a
foreign-owned ship registered here as a flag of
convenience: Kuwait 1 (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
totals
over 3,047 m: 2 (2001)
Airports • with unpaved runways:
tofeM
1,524 to 2,437 m: 1 (2001)
Heliports: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note • there is one small boat landing area along the
middle of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
mt completely covered with vegetation and unusable
Transportation - note: there is a day beacon near
the middle of the west coast','5bb9eb4566b6abdbf4a027297758b67d4d51214e6d95f49aa0fe0aad1dcb0f48','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2dc079e2f4b6768afadef3f43dfe992bf9964d0d8c74179bfeff79831c5ffaf',2002,'BD','Bangladesh','transportation',125,'Railways:
total: 2,745 km
broad gauge: 923 km 1.676-m gauge
narrow gauge: 1,822 km 1.000-m gauge (2000 est.)
Highways:
.tote/: 201,182 km
pavecM9,112km
unpaved: 182,070 km (1997)
Waterways: up to 8,046 km depending on season
note: includes 3,058 km main cargo routes
Pipelines: natural gas 1,250 km
Ports and harbors: Chittagong, Dhaka, Mongla
Port, Narayanganj (2001)
Merchant marine:
total: 34 ships (1 ,000 GRT or over) totaling 269,932
GRT/379,271 DWT
ships by type: bulk 2, cargo 26, container 3,
petroleum tanker 2, refrigerated cargo 1 , includes s
foreign-owned ship registered here as a flag of
convenience: Singapore 5 (2002 est.)
Airports: 18(2001)
Airports - with paved runways:
total: 15
over 3,047 m:]
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m:)
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m:1
under 914 m: 2 (2001)','8523fb8f3dd6786b8c864cf77b267e9480e97941d6ec5d58fe66a657a974b5cd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4573890f24a018b6fe754f94762caafa0473eb95cce33a51a5cd9141a883bc',2002,'LC','Saint Lucia','transportation',136,'Railways: 0 km
Highways:
total: 1,650 km
paved: 1,628 km
unpaved: 22 km (1998)
Waterways: none
Ports and harbors: Bridgetown, Speightstown (Port
Charles Marina)
Merchant marine:
total: 41 ships (1 ,000 GRT or over) totaling 629,987
GRT/1 ,073,991 DWT
ships by type: bulk 9, cargo 26, combination bulk 1 ,
container 1 , petroleum tanker 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Bahamas,
The 1 , Canada 4, Germany 1 , Greece 2, Hong Kong
7, Norway 7, United Kingdom 18 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047m: 1 (2001)','d233df65519fba7e143881ba5bb38f141e3f4c8e63acfe61451937db85a26486','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acbbe43b0433223193f9dc88e1cb98c0349c40d3384fbe20b2d21cc604e9ed8a',2002,'MZ','Mozambique','transportation',145,'Waterways: none
Ports and harbors: none; offshore anchorage only
Railways: 0 km
Highways:
tofa/;880 km
paved: 673 km
unpaved: 207 km (1996)
Waterways: none
Ports and harbors: Fomboni, Moroni,
Moutsamoudou
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 139,779
GRT/205,369 DWT
sft/jos by fype; cargo 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Malta 1 , Pakistan 1 ,
Turkey 1 (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
total: 4
2,438 to 3,047m:)
914 to 1,523 m: 3 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m''A (2m)
Railways:
total: NA km; short line going to a jetty
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total:!
914 to 1,523 /n: 1 (2001)
Pipelines: petroleum products 212 km
Ports and harbors: Binga, Kariba
Airports: 454(2001)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,435 fo 3,047 m; 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2001)
Airports - with unpaved runways:
total: 437
1,524 to 2,437 m: 4
914 to 1,523 m: 209
under 914 m: 22A (2001)
Railways:
tofaM.108 km
narrow gauge: 1 ,108 km 1 .067-m gauge (519 km
electrified)
note: in addition to the above routes in common
carrier service, there are several thousand kilometers
of 1 .067-m gauge routes that are dedicated to
industrial use (2001)
Highways:
total: 34,901 km
paved: 31 ,271 km (including 538 km of expressways)
unpaved: 3,630 km (1 998 est.)
Waterways: NA
Pipelines: petroleum products 3,400 km; natural gas
1,800 km (1999)
Ports and harbors: Chi-lung (Keetung), Hua-lien,
Kao-hsiung, Su-ao, Tai*chung
Merchant marine:
total: 152 ships (1 ,000 GRT or over) totaling
4,262,451 GRT/6,596,950 DWT
stops by type: bulk 40, cargo 28, combination bulk 3,
container 53, petroleum tanker 17, refrigerated cargo
9, roll on/roll off 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Hong Kong 3, Japan 1
(2002 est.)
Airports: 39(2001)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m:Q
1,524 to 2,437 m;8
914 to 1,523 m:B
under 914 m:3(2001)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m^
under 914 m: 2 (2001)
Heliports: 3(2001)','3448007a42b671b95f8ca94a8bfb540f51b09cac5797b534c7693adc7d22d880','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc7f6767c8f5d3d3a77fe7a34f6abe9c55c7bf4a71a6e26d3f8113abf31e412a',2002,'FR','France','transportation',157,'Railways:
total: 5,523 km
broad gauge: 5,523 km 1.520-m gauge (875 km
electrified) (2000 est.)
Highways:
total: 98,200 km
paved: 66,100 km (includes some all-weather
gravel-surfaced roads)
unpaved: 32,100 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: NA km; note * Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1 ,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 136(2001)
Airports - with paved runways:
tofa/:33
over3,047m:2
2,438 to 3,047 m:W
1,524 to 2,437 mA
under 914 m:11 (2001)
Airports - with unpaved runways:
total: 103
over 3,047 m:Z
2,438 to 3,047 m:10
1,524 to 2,437 m: 11
914 to 1,523 m: 14
under 914 m: 65 (2001)
Railways:
total: 3,422 km
standard gauge: 3,422 km 1.435-m gauge (2,517 km
electrified; 2,563 km double-tracked) (2001)
Highways:
total: 145,774 km
paved: 1 1 6,1 82 km (including 1 ,674 km of
expressways)
unpaved: 29,592 km (1999)
Waterways: 1,570 km (route length in regular
commercial use) (2001)
Pipelines: crude oil 161 km; petroleum products
1,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mons,
Namur, Oostende, Zeebrugge
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 31 ,362
GRT/54.058DWT
ships by type: cargo 6, chemical tanker 9, petroleum
tanker 5, includes some foreign-owned ships
registered here as a flag of convenience: Finland 1,
Netherlands 3 (2002 est.)
Airports: 42 (2001)
Airports - with paved runways:
total: 24
over 3,047 m:6
2,438 to 3,047 m: 8
1,524 to 2,437 m:Z
914 to 1,523 m:1
under 914 m: 6 (2001)
Airports - with unpaved runways:
total: 18
914 to 1,523 m:2
under 914 m: 16 (2001)
Heliports: 1 (2001)
52
Belgium (continued)
Railways: 0 km
Highways:
total: 2,880 km
paved: 490 km
unpaved: 2,390 km (1998 est.)
Waterways: 825 km (river network used by
shallow-draft craft; seasonally navigable)
Ports and harbors: Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine:
total: 31 5 ships (1 ,000 6RT or over) totaling
1,240,551 GRT/1,761,168 DWT
ships by type: bulk 26, cargo 204, chemical tanker 6,
combination ore/oil 1 , container 1 2, passenger/cargo 1 ,
petroleum tanker 39, refrigerated cargo 15, roll on/roll
off 8, short-sea passenger 1 , specialized tanker 1 ,
vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 2, Belgium 3,
British Virgin Islands 6, Cambodia 1 , China 38,
Cyprus 1 , Ecuador 1 , Egypt 1 , Equatorial Guinea 1 ,
Eritrea 1 , Estonia 7, Germany 3, Greece 4, Grenada 1 ,
Honduras 1, Hong Kong 20, Indonesia 6, Italy 2,
Japan 4, Jordan 1f Lebanon 1, Liberia 5, Malaysia 3,
Malta 2, Man, Isle of 1 , Marshall Islands 13, Mexico 1 ,
Netherlands 1, Nigeria 1, Panama 12, Philippines 4,
Portugal 1, Romania 1, Russia 3, Saint Vincent and
the Grenadines 3, Saudi Arabia 1 , Singapore 22,
South Korea 10, Spain 4, Switzerland 1 , Taiwan 1 ,
Thailand 6, Tunisia 1 , Turkey 1 , Ukraine 3, United
Arab Emirates 9, United Kingdom 2, United States 4,
Virgin Islands (UK) 6, Yemen 1 (2002 est)
Airports; 44 (2001)
Airports - with paved runways:
total: 4
1,524 to 2,437 m:)
914 to 1,523 m:\\
under 914 m: 2 {2001}
Airports - with unpaved runways:
total: 40
2,438 to 3,047 m''A
914 to 1,523 m: 10
under 914 m: 29 (2001)
Railways: 0 km
Highways:
total: 15 km (2001)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none; lagoon anchorage only
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports • with paved runways:
total: 1
1,524 to 2,437 m:\\ (2001)
Railways:
tofa/:660 km
narrow gauge: 660 km 1.000-meter gauge; 25 km
double-track
nofe: an additional 600 km of this railroad extends into
Burkina Faso, ending at Kaya, north of Ouagadougou
(2000 est.)
Highways:
totai: 50,400 km
paved: 4,889 km
unpaved: 45,511 km (1996)
Waterways: 980 km (navigable rivers, canals, and
numerous coastal lagoons)
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Airports: 36(2001)
Airports - with paved runways:
total: 7
over 3,047 m-A
2,438 to 3,047 m: 2
1,524 to 2,437 m:4 (2001)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:7
914 to 1523 m: 13
under 914 m: 9 {200^
Railways: 0 km
Highways:
total: 550 km
paved: at least 50 km
unpaved''.Uk (2002)
Waterways: none
Ports and harbors: Stanley
Merchant marine: none (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
tofa/:22
2,438 to 3,047 m:1
under 914 m: 1 1 (2001)
Airports - with unpaved runways:
fofa/:3 3
under 914 m: 3 (2001)
Railways: 0 km
Highways:
tote/: 1,81 7 km
paved: 817 km
unpaved: 1,000 km (1998)
Waterways: 3,300 km navigable by native craft
note: 460 km navigable by small oceangoing vessels
and coastal and river steamers
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none (2002 est.)
Airports: 11 (2001)
Airports - with paved runways:
tote/: 4
over 3,047 m:1
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5 (20M)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 71 ships (1 ,000 GRT or over) totaling 2,815,472
GRT/4,806,161 DWT
ships by type: bulk 5, cargo 5, chemical tanker 13,
container 1 1 , liquefied gas 7, petroleum tanker 19, roll
on/roll off 11
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 2, France 62,
Japan 3, Monaco 1 , Norway 5, Sweden 1 (2002 est.)
Airports: none (2001)
Railways:
tofa/:649km
standard gauge: 649 km 1.435-m gauge; single-track
(2000 est.)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996)
Waterways: 1 ,600 km (perennially navigable)
Pipelines: crude oil 270 km; petroleum products
14 km
Ports and harbors: Cap Lopez, Kango, Lambarene,
Libreville, Mayumba, Owendo, Port-Gentil
Airports: 59 (2001)
Airports - with paved runways:
tote/; 10
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m:7
914 to 1,523 m;1 (2001)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 8
914 to 1,523 m:17
under 914 m: 24 (2001)
Railways:
total: NA km; privately owned, narrow-gauge
plantation lines
Highways:
total: 2,560 km
paved: 965 km
unpaved: 1,595 km (1996)
Waterways: none
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,240 GRT/
109 DWT
ships by type: passenger 1
nofe: includes a foreign-owned ship registered here
as a flag of convenience: France 1 (2002 est)
Airports: 9(2001)
Airports - with paved runways:
total: 8
over 3,047 m;1
914 to 1,523 m:2
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2001)
Railways: 0 km (2002)
Highways:
total: 2,1 05 km (2000)
paved: NA km
unpaved: HA km
Waterways: none
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none (2002 est.)
Airports: 2(2001)
333
Martinique (continued)
Airports * with paved runways:
total: 1
over 3,047 m''A (2m)
Airports - with unpaved runways:
total: 1
underm m;1 (2001)
Railways: 1,815 km
broad gauge: 1,815 km 1.524-m gauge (2001)
Highways:
total: 3,387 km
paved: 1,563 km
unpaved: 1,824 km
nofe: there are also 45,862 km of rural roads that
consist of rough, unimproved, cross-country tracks
(2000)
Waterways: 400 km (1999)
Ports and harbors: none
Airports: 34(2001)
Airports - with paved runways:
total: B
2,438 to 3,047 m:l
under 914 m: 1 (2001)
Airports • with unpaved runways:
total: 26
over 3,047 m:Z
2,438 to 3,047 m: 5
1,524 to 2,437 m:10
914 to 1,523 m: 3
under 914 m: 5 (2001)
Highways:
tote/; 269 km
paved: 203 km
unpaved:66 km (1995)
Waterways: none
Ports and harbors: Plymouth (abandoned), Little
Bay (anchorages and ferry landing), Carr''s Bay
Merchant marine: none (2002 est.)
Airports: none; the only airport was destroyed by
volcanic activity; a helicopter service to Antigua is
used (2001)
Railways: 0 km
Highways:
total: 2,724 km
paved: 1 ,300 km (including 73 km of four-lane road)
unpaved: 1,424 km
note: 370 km of road are maintained by national
authorities, 754 km by departmental authorities and
1 ,600 km by local authorities (1 994)
Waterways: none
Ports and harbors: Le Port, Pointe des Galets
427
Reunion (continued)
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 28,264
GRT/44,885 DWT
ships by type: chemical tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: France 1 (2002 est,)
Airports: 2 (2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1 ,523 m: 1 (2001)
Railways: 0 km
Highways:
total: 1,040 km
pai/ed:320km
unpaved: 720 km (1996)
Waterways: none
Ports and harbors: Kingstown
Merchant marine:
total: 788 ships (1 ,000 GRT or over) totaling
7,000,660 GRT/10,702,776 DWT
445
Railways:
total: 16,878 km
standard gauge: 1 6,536 km 1 .435-m gauge (4,928 km
electrified; 12,591 km double- or multiple-tracked)
broad gauge: 342 km 1 .600-m gauge (1 90 km
double-tracked)
note: all 1. 600-m gauge track is in common carrier
service in Northern Ireland (1996)
Highways:
tofa/:371,603 km
paved: 371 ,603 km (including 3,303 km of
expressways)
unpaved: 0 km (1998 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Glasgow,
Grangemouth, Hull, Leith, Liverpool, London,
Manchester, Peterhead, Plymouth, Portsmouth,
Scapa Flow, Southampton, Sullom Voe, Tees, Tyne
Merchant marine:
total: 212 ships (1 ,000 GRT or over) totaling
4,308,232 GRT/4,171,757 DWT
ships by type: bulk 7, cargo 32, chemical tanker 13,
combination ore/oil 1, container 53, liquefied gas 3,
passenger 13, passenger/cargo 1, petroleum tanker
48, refrigerated cargo 4, roll on/roll off 26, short-sea
passenger 10, specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience; Bermuda 1 , Cyprus 1 ,
Denmark 21 , Germany 6, Greece 3, Hong Kong 4,
Italy 1 , Monaco 4, Netherlands 1 , Norway 9, Russia 1 ,
South Africa 2, Sweden 1 1 , Taiwan 2, United States 5
(2002 est.)
Airports: 470(2001)
Airports - with paved runways:
fofa/:332
over 3,047 m:8
2,438 to 3,047 m: 33
1,524 to 2,437 m: 150
914 to 1,523 m: 84
under 91 4 m: 57 (2001)
Airports - with unpaved runways:
fofa/:138
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m:1U (2001)
Heliports: 13(2001)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1,800 km (1997 est.)
note: Israelis have developed many highways to
service Jewish settlements
Waterways: none
Ports and harbors: none
Airports: 3(2001)
Airports - with paved runways:
total: Z
2,438 to 3,047 m:1
1,524 to 2,437 /n;1
under 914 m:) (2001)','7331168ee0939d39d0de8b2036da7853d74eeab1c56312669c3efffe28962498','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35336f961284c5817b829ffacf922f5f0fea47f222b840b6920b4580feb550aa',2002,'TG','Togo','transportation',167,'Railways:
total: 578 km
narrow gauge: 578 km 1.000-m gauge (2000 est.)
Highways:
total: 6,787 km
paved: 1 ,357 km (including 10 km of expressways)
unpaved: 5,430 km (1997 est.)
Waterways: streams navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none (2002 est.)
Airports: 5 (2001)
Airports - with paved runways;
to/a/; 1
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
total: 4
2,438 to 3,047m: 1
1,524 to 2,437 m:!
914 to 1,523 m: 2 (2001)','e07328033045e67329fb89c6be727cfff55618db0666fad28d409268a104d24a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06494e00ce85f27bc41701ecdc1aa6d5ac34296ada2c5ef2174ec5ed51e028a8',2002,'BM','Bermuda','transportation',176,'Railways: 0 km
Highways:
fofa/:450 km
paved: NA
unpaved: NA
note: public roads - 209 km; private roads - 241 krfi
(2002)
Waterways: none
Ports and harbors: Hamilton, Saint George''s,
Dockyard
Merchant marine:
total: 102 ships (1 ,000 GRT or over) totaling
5,485,450 GRT/8,782,869 DWT
ships by type: bulk 28, cargo 4, container 1 6, liquefied
gas 6, passenger 3, petroleum tanker 17, refrigerated
cargo 16, roll on/roll off 9, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 5, Denmark 2,
Germany 1, Greece 1, Hong Kong 9, Indonesia 1,
Norway 2, Sweden 11, United Kingdom 52, United
States 13 (2002 est.)
Airports: 1 (2002)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2960 m) (2002)','13dec2687ddb4d442346855217a1e946f7435bd92435e32da797562a1152f4b2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24c5b1470ea51c1187f635df43a086a33c0077bb4d4f9bf591f152536a0fd300',2002,'CN','China','transportation',186,'Railways: 0 km
Highways:
total: 3,285 km
paved: 1,994 km
unpaved: 1,291 km (1996)
Waterways: none
Ports and harbors: none
Airports: 2(2001)
Airports - with paved runways:
fofa/:1
1,524 to 2,437 m:\\ (2001)
Airports - with unpaved runways:
total: \\
914 to 1,523 m; 1 (2001)
Railways:
total: 67,524 km (including 5,400 km of provincial
"local" rails)
standard gauge: 63,924 km 1.435-m gauge (13,362
km electrified; 20,250 km double-track)
narrow gauge: 3,600 km 0.750-m and 1 .000-m gauge
local industrial lines (1999 est.)
Highways:
totals A million km
paved: 271 ,300 km (with at least 16,000 km of
expressways)
unpaved: 1,128,700 km (1999)
Waterways: 110,000 km (1999)
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Shenzhen, Tianjin, Wenzhou, Xiamen, Xingang,
Yantai, Zhanjiang (2001)
Merchant marine:
total: 1 ,764 ships (1 ,000 GRT or over) totaling
16,915,047 GRT/25,366,296 DWT
ships by type: barge carrier 2, bulk 328, cargo 822,
chemical tanker 25, combination bulk 10, combination
ore/oil 1, container 134, liquefied gas 26,
multi-functional large-load carrier 6, passenger 7,
passenger/cargo 45, petroleum tanker 263,
refrigerated cargo 26, roll on/roll off 23, short-sea
passenger 42, specialized tanker 3, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 1 , Germany 1 ,
Hong Kong 16, Japan 2, Panama 2, South Korea 1,
Spain 1 , Taiwan 9, Tanzania 1 , Turkey 1 (2002 est.)
Airports: 489(2001)
Airports - with paved runways:
total: 324
over 3,047m: 27
2,43$ to 3,047 m: 88
1,524 to 2,437 m: 147
914 to 1,523 m: 30
under 914 m: 32 (2001)
Airports - with unpaved runways:
J0ta/;165
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 29
914 to 1,523 m; 56
under 914 m:7S {2001)
Railways:
tofa/:34km
standard gauge: 34 km 1.435-m gauge (electrified
and double-tracked)
note: connects to China railway system at Hong
Kong-China border (2001)
Highways:
total: 1,831 km
paved: \\ $M km
unpaved: 0 km (1997)
Waterways: none
Ports and harbors: Hong Kong
Merchant marine:
total: 433 ships (1 ,000 GRT or over) totaling
13,539,257 GRT/22,682,757 DOT
ships by type: barge carrier 1 , bulk 264, cargo 38,
chemical tanker 1 0, combination bulk 2, container 73,
liquefied gas 8, multi-functional large-load carrier 1,
petroleum tanker 32, refrigerated cargo 1 , short-sea
passenger 1 , vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 5, Belize 1 ,
British Virgin Islands 1, China 115, Denmark 2,
Germany 1 9, Greece 2, India 8, Japan 8, Liberia 1 ,
Malaysia 7P Norway 1, Panama 2, Philippines 5r
Singapore 7, South Korea 2, Taiwan 1, United
Kingdom 27, Virgin Islands (UK) 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 3
over 3,047 m;1
1,524 to 2,437 m: 1 (2001)
Heliports: 2(2001)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note • there is one small boat landing area along the
middle of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
EARHART and Fred NOONAN - they left Lae, New
Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable
Transportation - note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia EARHART
Railways:
total: 7,869 km
broad gauge: 36 km 1 ,524-m gauge
standard gauge: 7,614 km 1.435-m gauge (2,423 km
electrified; 1,236 km double-tracked)
narrow gauge: 219 km 0.760-m gauge
note: Hungary and Austria jointly manage the
cross-border, standard-gauge railway connecting
Gyor, Sopron, and Ebenfurt (Gysev railroad) which
has a route length of about 1 01 km in Hungary and 65
km in Austria (2001)
Highways:
total: 188,203 km
paved: 81 ,680 km (including 448 km of expressways)
unpaved: 106,523 km (1998 est.)
Waterways: 1 ,373 km (permanently navigable)
(1997)
Pipelines: crude oil 1 ,204 km; natural gas 4,387 km
(1991)
Ports and harbors: Budapest, Dunaujvaros
Airports: 43(2001)
Airports - with paved runways:
tofa/:16
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 mA
under 914 mA (2m)
Airports - with unpaved runways:
to/a/:27
2,438 to 3,047 m:Z
1,524 to 2,437 m: 4
914 to 1,523 mA2
under 914 m: 8 (2001)
Heliports: 5(2001)
Railways:
total: 677 km
narrow gauge: 677 km 1 .050-m gauge (2001 )
Highways:
/ofa/; 8,000 km
paved: 8,000 km
unpaved: 0 km (2000 est.)
Waterways: none
Pipelines: crude oil 209 km; note - may not be in use
Ports and harbors: Al ''Aqabah
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 41,206
GRT/53,401 DWT
ships by type: bulk 1 , cargo 3, container 1 , roli on/roll
off 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 6 (2002 est.)
Airports: 16(2001)
Airports - with paved runways:
totalis
over 3,047 m:7
2,438 to 3,047 m;6
914 to 1,523 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 3
under 914 m:Z (2m)
Heliports: 1 (2001)
Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 30,300 km (including 140 km of expressways)
paved: 22,600 km (includes some all-weather
gravel-surfaced roads)
unpaved: 7,700 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Koi or
Rybach''ye)
Airports: 50(2001)
Airports - with paved runways:
total: 4
over 3,047 m:l
2,438 to 3,047 m:1
1,524 to 2,437 /n:1
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
total: 46
2,438 to 3,047 m;3
1,524 to 2,437 m:S
914 to 1,523 m;6
under 974 m: 32 (2001)
Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Macau
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports • with paved runways:
total: 1
over 3,047 m: 1 (2001)
Railways:
total: 699 km
standard gauge: 699 km 1 .435-m gauge (233 km
electrified)
note: a 56-km extension of the Kumanovo-Betjakovce
line to the Bulgarian border at Gyueshevo is under
construction (2001)
Highways:
total: 8,684 km
paved: 5,540 km (including 133 km of expressways)
unpaved: 3,144 km (1997)
Waterways:
note: lake transport only, on the Greek and Albanian
borders
Pipelines: 10 km
Ports and harbors: none
Airports: 17(2001)
Airports -with paved runways:
toteMO
2,439 to 3,047 m: 2
under 914 m: 8 (2001)
Airports • with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 4(2001)
Airports - with paved runways:
total: *\\
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:)
under 914 m: 2(2001)','4e4821177d40d194d556552ec1f2373f2a7cf0ee48a6ff0746d61e54e4179cc2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b787bcf6e4c128438aa90c4ef9a62f62cf4ffa150bcd490033e17bd16336c951',2002,'NP','Nepal','transportation',196,'Railways:
total: 3,691 km
narrow gauge: 3,652 km 1.000-m gauge; 39 km
0.760-m gauge (13 km electrified) (1995 est.)
Highways:
total: 49,400 km
paved: 2,500 km (including 30 km of expressways)
unpaged; 46t900 km (1996)
Waterways: 10,000 km (commercially navigable)
Pipelines: crude oi! 1,800 km; petroleum products
580 km; natural gas 1 ,495 km
Ports and harbors: Puerto Aguirre (on the
Paraguay/Parana waterway, at the Bolivia/Brazil
border); also, Bolivia has free port privileges in
maritime ports in Argentina, Brazil, Chile, and','61dca69cc2e2c70152f64b54a170737c249734b8a15e936c536e5cab2eb5a40c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('739e9ae612edd7198c6e031220fe7b084f6a4c2f6ef308ee0945b51e17253cd8',2002,'PY','Paraguay','transportation',197,'Merchant marine:
total: 36 ships (1 ,000 GRT or over) totaling 1 96,399
GRT/320.137DWT
ships by type: bulk 3, cargo 15, chemical tanker 2,
container 1 , petroleum tanker 13, roll on/roll off 2
note: includes some foreign-owned ships registered
here as a flag of Belize 2, China 2, Cuba 1 , Cyprus 1 ,
Egypt 1, Honduras 1, Latvia 2, Liberia 2, Panama 1,
Saint Vincent and the Grenadines 1 , Saudi Arabia 1 ,
Singapore 1 , South Korea 3, Switzerland 1 1 Ukraine 1 ,
United Arab Emirates 5, United States 1 (2002 est.)
Airports: 1,109(2001)
Airports - with paved runways:
total: K
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 1,096
over 3,047 m: ''\\
2,438 to 3,047 m: 4
1,524 to 2,437 m: 65
914 to 1,523 m: 236
under 914 m: 790 (2001)','2162e205da75898835868fe6489432024b3c9fb41e56df4ca0bed7a72ee8178d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d011a01eb4630ab8dc32daa5dde2813484374dc3a49900c3114a9dc38fd0b1a',2002,'IT','Italy','transportation',208,'Railways:
total: 1 ,021 km (795 km electrified; operating as diesel
or steam until grids are repaired)
standard gauge: 1 ,021 km 1.435-m gauge; note -
many segments still need repair and/or reconstruction
because of war damage (2000 est.)
Highways:
total: 21 ,846 km
paved: 14,020 km
unpaved: 7,826 km
note: road system is in need of maintenance and
repair (2001)
Waterways: NA km; large sections of the Sava
blocked by downed bridges, silt, and debris
Pipelines: crude oil 174 km; natural gas 90 km
(1992)
Ports and harbors: Bosanska Gradiska, Bosanski
Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava), Orasje
Merchant marine: none (2002 est.)
Airports: 27(2001)
Airports - with paved runways:
total: S
2,438 to 3,047 m: 4
1,524 to 2,437 m:1
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: \\9
1,524 to 2,437 m:1
914to1t523m:7
under 914 m: 11 (2001)
Heliports: 5(2001)
Railways:
total: 888 km
narrow gauge: 888 km 1 .067-m gauge (2000 est.)
Highways:
toteM0,217km
paved: 5,620 km
unpaved: 4,597 km (1999)
Waterways: none
Ports and harbors: none
Airports: 92(2001)
Airports - with paved runways:
total: 11
2,438 to 3,047 m: 2
1,524 to 2,437 m:8
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
tote/: 81
1,524 to 2,437 m: 3
914 to 1,523 m:56
under 914 m:22 (200})
Railways:
total: 0.86 km
standard gauge: 0.86 km 1 .435-m gauge
note: a spur of the Italian Railways system, serving
Rome''s Saint Peter''s station (2001 est,)
Highways: none; atl city streets
Waterways: none
Ports and harbors: none
Airports: none (2001)
Heliports: 1 (2001)
Railways:
tofa/:595 km
narrow gauge: 318 km 1.067-m gauge; 277 km
0.914-m gauge (2000)
Highways:
total: 15,400 km
paved: 3,126 km
unpaved: 12,274 km (1999 est.)
Waterways: 465 km (navigable by small craft)
Ports and harbors: La Ceiba, Puerto Castilla,
Puerto Cortes, San Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 284 ships (1 ,000 GRT or over) totaling 749,243
GRT/846,942 DWT
ships by type: bulk 20, cargo 1 66, chemical tanker 5,
container 6, livestock carrier 1 , passenger 3,
passenger/cargo 3, petroleum tanker 54, refrigerated
cargo 12, roll on/roll off 8, short-sea passenger 4,
specialized tanker 1, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 1 , Bahrain 1 ,
Belize 1, British Virgin Islands 1, Bulgaria 1, China 8,
Costa Rica 1, Cyprus 1, Egypt 6, El Salvador 1,
Germany 1, Greece 18, Hong Kong 3, Indonesia 2,
Italy 1, Japan 7, Lebanon 4, Liberia 4, Maldives 2,
Marshall Islands 1, Mexico 1, Nigeria 1, Norway 1,
Panama 14, Philippines 1, Romania 2, Russia 1, Saint
Kitts and Nevis 3, Saint Vincent and the Grenadines 1 ,
Singapore 24, South Korea 12, Spain 1, Syria 1,
Taiwan 4, Tanzania 1, Trinidad and Tobago 1 ,
Turkey 2, Turks and Caicos Islands 1 , United Arab
Emirates 6, United Kingdom 1, United States 5,
Vanuatu 1 , Vietnam 1 , Virgin Islands (UK) 1
(2002 est.)
Airports: 117(2001)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m:3
uneter0f4m:4(2OO1)
Airports - with unpaved runways:
fofaMOS
1,524 to 2,437 m: 2
914 to 1}523m: 20
under 914 m: 83 (2001)
Railways: 0 km; note - there is a 1 .5-km cable
railway connecting the city of San Marino to Borgo
Maggiore
Highways:
total: 220 km
paved: 220 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: none
Airports: none (2001)
Railways:
total: 4,406 km
standard gauge: 3,440 km 1 .435-m gauge
narrow gauge: 900 km 1.000-m gauge; 10 km
0.800-m gauge
dual gauge: 56 km 1. 435-m and 1.000-m gauges (3
rail system)
note: Swiss railways are virtually all electrified
(2001)
Highways:
total: 71 ,059 km (including 1 ,638 km of
expressways)
paved: 71 ,059 km
unpaved:0km (1999)
Waterways: 65 km
note: The Rhine carries heavy traffic on the
Basel-Rheinfelden and Schaffhausen-Bodensee
stretches; there are also 12 navigable lakes
Pipelines: crude oil 314 km; natural gas 1 ,506 km
Ports and harbors: Basel
Merchant marine:
total: 26 ships (1 ,000 GRT or over) totaling 509,943
GRT/896,309DWT
ships by type: bulk 1 5, cargo 6, chemical tanker 4,
petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience:, United Kingdom 6,
United States 1 (2002 est.)
Airports: 66(2001)
Airports - with paved runways:
total: 42
over 3,047 m:Z
2,438 to 3,047 ''m:5
1,524 to 2,437 m:11
914 to 1 ,523 m:^
under 914 m: 15 (2001)
Airports - with unpaved runways:
tofa/:24
under 914 m: 24 (2001)''
Heliports: 1 (2001)
Railways:
total: 2,750 km
standard gauge: 2,423 km 1.435-m gauge
narrow gauge: 327 km 1 ,050-m gauge
note: rail link between Syria and Iraq replaced in 2000
(2001)
Highways:
total: 41 ,451 km
pavecf: 9,575 km (including 877 km of expressways)
unpaved: 31,876 km (1997)
Waterways: 870 km (minimal economic importance)
Pipelines: crude oil 1,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia, Tartus
Merchant marine:
total: 143 ships (1 ,000 GRT or over) totaling 482,985
GRT/702,590 DWT
ships by type: bulk 12, cargo 1 26, livestock carrier 4,
roll on/roli off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 1 , Greece 2,
Italy 1, Lebanon 10 (2002 est.)
Airports: 99(2001)
Airports - with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 75
1,524 to 2,437m: 2
914 to 1,523 m:\\\\
under 914 m: 62 (2001)
Heliports: 2(2001)','f50e2f1c63fd84b74c38b0b2e545ab3db84fb5064310b382c658317782b147f6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c924423857e9a617343e48dd3166cc9a54336b8d7fab415af04648be35d8211b',2002,'CO','Colombia','transportation',228,'Railways:
total: broad gauge: 5,679 km 1.600-m gauge (1,199
km electrified)
standard gauge: 194 km 1 .440-m gauge
narrow gauge: 24,666 km 1 ,000-m gauge (930 km
electrified)
dual gauge: 336 km 1 .000-m and 1 .600-m gauges
(three rails)
note: in addition to the interurban routes itemized
above, Brazil has 247.8 km of suburban railway
consisting of 170.8 km of 1 .600-m gauge (75 km
electrified) and 77 km of 1.000-m gauge (1999 est.)
Highways:
fofa/:1.98 million km
pavecM 84,140 km
unpaved: 1 ,795,860 km (1 996)
Waterways: 50,000 km
Pipelines: crude oil 2,980 km; petroleum products
4,762 km; natural gas 4,246 km (1998)
Ports and harbors: Belem, Fortaleza, llheus,
Imbituba, Manaus, Paranagua, Porto Alegre, Recife,
Rio de Janeiro, Rio Grande, Salvador, Santos, Vitoria
Merchant marine:
total: 165 ships (1,000 GRT or over) totaling
3,662,570 GRT/5,875,933 DWT
72
Brazil (continued)
ships by type: bulk 32, cargo 25, chemical tanker 5,
combination ore/oif 9, container 12, liquefied gas 1 1,
multi-functional large-load carrier 1, passenger/cargo
5, petroleum tanker 54, roil on/roll off 10, short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Chile 2. Germany 6,
Greece 1 , Monaco 1 (2002 est.)
Airports: 3,365(2001)
Airports - with paved runways:
total: 627
over 3,047 m:6
2,438 to 3,047 m: 21
1,524 to 2,437 m: 153
914 to 1,523 m: 407
under 914 m: 40 (2001)
Airports - with unpaved runways:
total: 2,738
1,524 to 2,437 m:12
914 to 1,523 m; 1,316
under 914 m: 1,350 (2001)
Railways:
total: 3,304 km
standard gauge: 150 km 1 ,435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia de
Portete)
narrow gauge: 3,154 km 0.91 4-m gauge (major
sections not in use) (2000 est.)
Highways:
total: 110,000 km
paved: 26,000 km
unpaved: 84,000 km (2000)
Waterways: 18,140 km (navigable by river boats)
(April 1996)
Pipelines: crude oif 3,585 km; petroleum products
1 ,350 km; natural gas 830 km; natural gas liquids 125
km
Ports and harbors: Bahia de Portete, Barranquilla,
Buenaventura, Cartagena, Leticia, Puerto Bolivar,
San Andres, Santa Marta, Tumaco, Turbo
Merchant marine:
total: 1 1 ships (1 ,000 GRT or over) totaling 32,438
GRT/43..126 DWT
ships by type: bulk 5, cargo 3, container 1 , petroleum
tanker 2
note: includes a foreign-owned ship registered here
as a flag of convenience: Germany 1 (2002 est.)
Airports: 1,066(2001)
Airports - with paved runways:
tafa/:93
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 37
914 to 1,523 m: 36
under 914 m: 9 (2001)
Airports - with unpaved runways:
total: 973
2,438 to 3,047 mA
1,524 to 2,437 m: 5%
914 to 1,523 m:312
under914m: 602 (2001)
Heliports: 1 (2001)
Railways:
total: 355 km
broad gauge: 76 km 1 ,524-m gauge
narrow gauge: 279 km 0.91 4-m gauge (2001)
Highways:
total: 11,592 km
paved: 4,079 km (including 30 km of expressways)
unpaved: 7,513 km (2000)
Waterways: 882 km
note: 800 km navigable by shallow draft vessels; 82
km Panama Canal
Pipelines: crude oil 130 km (2001)
Ports and harbors: Balboa, Cristobal, Coco Solo,
Manzanillo (part of Colon area), Vacamonte
Merchant marine:
total: 4,838 ships (1 ,000 GRT or over) totaling
118,878,358 GRT/1 80,588,1 02 DWT
ships by type: bulk 1 ,445, cargo 907, chemical tanker
337, combination bulk 73, combination ore/oil 18,
container 560, liquefied gas 207, livestock carrier 5,
multi-functional large-load carrier 12, passenger 38,
passenger/cargo 3, petroleum tanker 542, railcar
carrier 2, refrigerated cargo 283, roll on/roll off 104,
short-sea passenger 38, specialized tanker 34,
vehicle carrier 230
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 2, Angola 1,
Antigua and Barbuda 1, Argentina 11, Australia 13,
Austria 2, Bahamas, The 5, Belgium 2, Belize 6,
Brazil 6f British Virgin Islands 8, Cambodia 1,
Canada 9, Chile 12, China 259, Colombia 14,
Croatia 2, Cuba 20, Cyprus 3, Denmark 3, Dominican
Republic 1 , Ecuador 3, Egypt 16, Equatorial Guinea 1 ,
France 9, Germany 72, Greece 523, Haiti 1,
Honduras 3, Hong Kong 299, Iceland 1 , India 18,
Indonesia 48, Ireland 1, Israel 5, Italy 9, Japan 1642,
Kenya 1 , Kuwait 2, Latvia 8, Liberia 5, Lithuania 1 ,
Malaysia 18, Malta 2, Marshall Islands 1, Mexico 8,
Monaco 112, Netherlands 19, Netherlands Antilles 1,
Nigeria 3, Norway 98, Paraguay 1 , Peru 15,
Philippines 49, Poland 5, Portugal 7, Puerto Rico 2,
Romania 7, Russia 12, Saint Kitts and Nevis 1, Saint
Vincent and the Grenadines 5, Saudi Arabia 4,
Seychelles 1, Singapore 112, South Africa 3, South
Korea 342, Spain 52, Sri Lanka 3, Sudan 1 ,
Sweden 2, Switzerland 81 , Taiwan 334, Thailand 14,
Trinidad and Tobago 1 , Tunisia 1 , Turkey 4,
Ukraine 1, United Arab Emirates 54, United
Kingdom 73, United States 115, Venezuela 6, Virgin
islands (UK) 8 (2002 est)
Airports: 107(2001)
Airports - with paved runways:
total: 42
over 3,047 m:1
2,438 to 3,047 mA
1 ,524 to 2,437 m:5
914 to 1,523 m:U
under 914 m:21 (2001)
Airports -with unpaved runways:
total:®
914 to 1,523 mA2
under 914 m: 53 (2001)','9a6798f205a7fcd859d2f2b66100a6fdbf6368864a1467e1926a9487e9afea45','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f734fe772a3e7e12de42efbe7c23f93ca7e0623db28c37d0414c1087814aa10d',2002,'IO','British Indian Ocean Territory','transportation',237,'Highways:
fofa/:NAkm
paved: short stretch of paved road of N A km between
port and airfield on Diego Garcia
unpaved: NA km
Waterways: none
Ports and harbors: Diego Garcia
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2001)
Railways: 0 km
Highways:
total: \\V km
pavecf;177km
unpaved: 0 km (2000)
Waterways: none
Ports and harbors: Road Town
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 70,285 GRT/
6,946 DWT
ships by type: passenger 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
914 to 1,523 m:1
under 914 m: 1 (2001)
Airports ■ with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)','60911084bfd1ec14e82b66bb161572644010b0d627798d4976f0667443d00938','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14eb5c183d526c1e1eed489dcd1a5871344e0bb966443315701d7ede5a86b9f3',2002,'MY','Malaysia','transportation',250,'Railways:
tote/; 13 km (private line)
narrow gauge: 13 km 0.610-m gauge (2001 est.)
Highways:
total: 1,712 km
paved: 1,284 km
unpaved:42B km (1996)
Waterways: 209 km; navigable by craft drawing less
than 12 m
Pipelines: crude oil 135 km; petroleum products 418
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 348,476
GRT/340r635DWT
ships by type: liquefied gas 7
note: includes some foreign-owned ships registered
here as a flag of convenience: United Kingdom 7
(2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 1
over 3,047 ''m:1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1523 m^ (2001)
Heliports: 3(2001)','75a5db98017f455262d834647ec37384b21ac96b9d36b40280693c419c7f8670','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2279d2cf0f77ea398620399cd65fb1e58934d0316cc1fa4f56f6708d02f96f4f',2002,'BG','Bulgaria','transportation',259,'Railways:
total: 4,294 km
standard gauge: 4,049 km 1 .435-m gauge (2,710 km
electrified)
narrow gauge: 245 km 0.760-m gauge (2002)
Highways:
total: 37,288 km
paved: 33,786 km (including 324 km of expressways)
unpaved: 3,502 km (2001)
Waterways: 470 km (1987)
Pipelines: petroleum products 525 km; natural gas
1,500 km (1999)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 77 ships (1 ,000 GRT or over) totaling 881 ,758
GRT/1 ,312,833 DWT
ships by type: bulk 43, cargo 15, chemical tanker 4,
container 2, passenger/cargo 1 , petroleum tanker 4,
railcar carrier 2, refrigerated cargo 1, roll on/roll off 3,
short-sea passenger 1, specialized tanker 1
(2002 est,)
Airports: 215(2001)
Airports • with paved runways:
tofa/:129
over 3,047 m:1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 15
914 to 1 ,523 m:1
under 914 m: 93 (2001)
Airports - with unpaved runways:
total: 86
1,524to2l437m:2
914 to 1,523 m:W
under 914 m: 74 (2001)
Heliports: 1 (2001)','8e132fc34df20fcb9944ad15f4b44d57cb26dbf6bb608f64c43cf18a4cb294e3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('221b61faaee2a25707db9f76577bcf42b23098f614351e0e45eebe645bfbea49',2002,'ET','Ethiopia','transportation',263,'Railways:
total: 622 km (517 km from Ouagadougou to the Cote
d''tvoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km 1,000-m gauge (1995 est.)
Highways:
total: 12,506 km
paved: 2,001 km
unpaved: 10,505 km (1996)
Waterways: none
Ports and harbors: none
Airports: 33(2001)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: M
1,524 to 2,437 m: 3
914 to 1,523 m:12
under 914 m: 16 (2001)
82
Burkina FaSO (continued)
Railways: Okm
Highways:
total: 4,400 km
pavecf;453km
unpaved: 3,947 km (1996)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none (2002 est.)
Airports: 28(2001)
Airports - with paved runways:
totals
over 3,047 /n:1
1,524 to 2,437 m:1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 20 [200])
Railways: 0 km
Highways;
total: 320 km
paved: 21 8 km
tmpaved; 102 km (1996)
Waterways: none
Ports and harbors; Santo Antonio, Sao Tome
Merchant marine:
tote/; 41 ships (1,000 GRT or over) totaling 169,991
GRT/245,996 DWT
ships by type: bulk 6, cargo 23, chemical tanker 1 ,
container 3, livestock carrier 1 , petroleum tanker 3,
refrigerated cargo 1 , roll on/roll off 2, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 1 , Greece 1 ,
Kenya 1, Portugal 1, Syria 1, Turkey 1 (2002 est.)
Airports: 2 (2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m: 1 (2001)
Railways:
total: 1,392 km
standard gauge: 1 ,392 km 1 ,435-m gauge (724 km
are double-tracked) (2001)
Highways:
total: 146,524 km
paved: 44, 104 km
unpaved: 102,420 km (1997 est.)
Waterways: none
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Mishab, Ras
Tanura, Yanbu'' al Bahr, Madinat Yanbu1 al Sinaiyah
Merchant marine:
total: 71 ships (1 ,000 GRT or over) totaling 1 ,071 ,315
GRT/1,412,125DWT
ships by type: cargo 1 1 , chemical tanker 1 0,
container 4, livestock carrier 3, passenger 1,
petroleum tanker 20, refrigerated cargo 3, roll on/roll
off 11 , short-sea passenger 8
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 3, Finland 1 ,
Greece 3, Kuwait 1 , Sudan 1 , United Arab Emirates 1 ,
United Kingdom 3 (2002 est.)
Airports: 209(2001)
Airports - with paved runways:
tote/: 71 70
over 3,047 m: 31 31
2,435 to 3,047 m: 12 11
1,524 to 2,437 m: 23 23
914 to 1,523m: S3
under 914 m: 2 2 (2001)
Airports - with unpaved runways:
total: W
2,438 to 3,047 m: 5
1,524 to 2,437 m:79
914 to 1,523 m: 28
under 914 m: 15 (2001)
Heliports: 5(2001)
453
Saudi Arabia (continued)','2fa706c2f3206db9af4dc7056b0639c809320986aa2c8c422dd551f7fc96a740','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('970ffa0c92f6fd3a5b59488b885b685fcbb128ebb510e38d930c168d9cbc1bd8',2002,'TH','Thailand','transportation',272,'Railways:
total: 3,991 km
narrow gauge: 3,991 km 1 .000-m gauge (2000 est.)
Highways:
total: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1996)
Waterways: 12,800 km
note: 3,200 km navigable by large commercia!
vessels
Pipelines: crude oil 1 ,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk,
Mandalay, Moulmein, Myttkyina, Rangoon, Akyab
(Sittwe), Tavoy
Merchant marine:
total: 35 ships (1 ,000 GRT or over) totaling 382,386
GRT/582,084 DWT
ships by type: bulk 9, cargo 21 , container 1 ,
passenger/cargo 3, petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 5, Japan 4
(2002 est)
Airports: 80(2001)
Airports - with paved runways:
tote/: 8
over 3,047m: 2
2,438 to 3,047m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 72
over 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 21
under 914 m: 33 (2001)
Heliports: 2(2001)
Railways: 0 km
Highways:
total: 14,480 km
paved: 1,028 km
unpaved: 13,452 km (1996)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 7(2001)
Airports - with paved runways:
totals
over 3,047 m: 1 (2001)
87
Burundi (continued)
Airports - with unpaved runways:
total: B
914 to 1,523 m:3
under 914 m: 3 (2001)
Railways: 0 km (2001)
Highways:
total: 14,000 km
paved: 3,360 km
unpaved: 10,640 km (1991)
Waterways: 4,587 km approximately
note: primarily Mekong and tributaries; 2,897
additional km are intermittently navigable by craft
drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 2,370 GRT/
3,110 DWT
ships by type: cargo 1 (2002 est.)
Airports: 51 (2001)
Airports - with paved runways:
total: 9
2,433*03,047/17:1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2001)
Airports - with unpaved runways:
total: A2
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 914 m: 26 (2001)','efaf16160be21cae545982ee5115e969a75f90450abc3c31264bb2ea5e9d0d5c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11593509fafcfb5709b52e6aa66df8bfcc0425b9c30651d864e03c5b24b61f66',2002,'UG','Uganda','transportation',286,'Railways:
total: 603 km
narrow gauge: 603 km 1.000-m gauge (2001 est.)
Highways:
total: 35,769 km
paved: 4,165 km
unpaved: 31 ,604 km (1997)
Waterways: 3,700 km
note: navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1 .8 m
Ports and harbors: KampongSaom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine:
total: 404 ships (1 ,000 GRT or over) totaling
1,889,404 GRT/2,740,232 DWT
ships by type: bulk 37, cargo 31 2, chemical tanker 2,
combination bulk 5, container 7, liquefied gas 1 ,
livestock carrier 2, multi-functional large-load carrier
1, passenger/cargo 1, petroleum tanker 15,
refrigerated cargo 10, roll on/roll off 9, short-sea
passenger 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Aruba 1 , Belize 8,
British Virgin Islands 1, Bulgaria 3, China 21, Cyprus
15, Denmark 1 , Egypt 7, Estonia 1 , Georgia 1 ,
Germany 1, Greece 12, Honduras 5, Hong Kong 12,
Iceland 1 , Indonesia 2, Iran 1 , Ireland 1 , Italy 1 , Japan
5, Jordan 1 , Latvia 2t Lebanon 5, Liberia 5, Lithuania
1 , Malta 1 , Netherlands 1 , Norway 2, Panama 7,
Romania 4, Russia 67, Saint Kitts and Nevis 10, Saint
Vincent and the Grenadines 4, Singapore 15, South
Korea 24, Syria 1 3, Thailand 1 , Turkey 22, Ukraine 1 3,
United Arab Emirates 2, United Kingdom 1, United
States 5, Vietnam 2, Virgin Islands (UK) 1 (2002 est.)
Airports: 20(2001)
Airports - with paved runways:
total: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
totalis
1,524 to 2,437 m:1
914 to 1,523 m: 13
under 914 m: 1 (2001)
Heliports: 2(2001)
Railways:
fo/aM,104 km
narrow gauge: 1 ,104 km 1 ,000-m gauge (1 995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
i/npaverf:30,012 km (1995)
Waterways: 2,090 km (of decreasing importance)
Ports and harbors: Bonaberi, Douala, Garoua,
Kribi, Tiko
Airports: 49(2001)
Airports - with paved runways:
tofa/:11
over 3,047 m:2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m:)
under 914 m:1 (2001)
92
Cameroon (continued)
Railways: 0 km
Highways:
total: 158 km (Saint Helena 1 18 km, Ascension 40 km,
Tristan da Cunha 0 km)
paved: 1 38 km (Saint Helena 98km, Ascension 40 km,
Tristan da Cunha 0 km)
unpaved: 20 km (Saint Helena 20 km, Ascension 0
km, Tristan da Cunha 0 km)
Waterways: none
Ports and harbors: Georgetown (on Ascension),
Jamestown
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
totalA
overWm; 1 (2001)','e80e80493e2b35ef4712f2c34f93f51b3c2572c672b8a2030977418f52fa098f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9296573fad861f27ab0461b50de13aced1134ad282430cb25646717641fec246',2002,'CA','Canada','transportation',288,'i+l
Airports - with unpaved runways:
tofa/;38
1,524 to 2,437 m: 7
914 to 1,523 m: 2]
under 914 m: 10 (2001)
Railways:
total: 36,1 14 km
standard gauge: 36,1 1 4 km 1 .435-m gauge (1 56 km
electrified)
note: Canada has two major transcontinental freight
railway systems: Canadian National (privatized
November 1995) and Canadian Pacific Raifway;
passenger service is provided by the
government-operated fi mi VIA, which has no trackage
of its own (2000 est.)
Highways:
total: 901 ,902 km
paved: 31 8,371 km (including 16,571 km of
expressways)
unpaved: 583,531 km (1999)
Waterways: 3,000 km (including Saint Lawrence
Seaway)
Pipelines: crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine:
total: 122 ships (1 ,000 GRT or over) totaling
1,797,240 GRT/2,680,223 DWT .
ships by type: barge carrier 1 , bulk 66, cargo 13,
chemical tanker 5, combination bulk 2, passenger 2,
passenger/cargo 1, petroleum tanker 18, railcar
carrier 2, roll on/roll off 8, short-sea passenger 3,
specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 3, Monaco
16, United Kingdom 1 , United States 1 (2002 est.)
Airports: 1,419(2001)
Airports - with paved runways:
total: 519
over 3,047 m: 18
2,438 to 3,047 m: 16
1,524 to 2,437 m: 151
914 to 1,523 m:244
under 914 m: 90 (2001)
Airports - with unpaved runways;
total: m
1,524 to 2,437 m: 74
914 to 1,523 m:m
under 914 m: 462 (2001)
Heliports: 18(2001)','46779cc07f5c1dfd45188a1f9e40c3d7f93aa5e607a61c68ce9da2c19f1a33cc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('282791610ea049041550fd168f44612591cc1ac45982dc0e1566ac889bc49877',2002,'PT','Portugal','transportation',300,'Railways: 0 km
Highways:
total: 1,W km
paved: 858 km
unpai/ed:242km (1996)
Waterways: none
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,395 GRT/
6,614 DWT
ships by type: cargo 3, chemical tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United Kingdom 1
(2002 est.)
Airports: 9
note: 3 airports are reported to be nonoperational
(2001)
Airports - with paved runways:
total: 3
over 3,047 m:1
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 3 (2001)
Railways:
total: 2,850 km
broad gauge: 2,576 km 1.668-m gauge (623 km
electrified; 426 km double-tracked)
narrow gauge: 274 km 1 .000-m gauge (2001 )
Highways:
total: 68,732 km
paved: 59,1 10 km (including 797 km of expressways)
unpaved: 9,622 km (1999)
Waterways: 820 km
note: relatively unimportant to national economy,
used by shallow-draft craft limited to 300 metric-ton or
less cargo capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
nofe: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 140 ships (1 ,000 GRT or over) totaling
1,001 ,440 GRT/1 ,519,701 DWT
ships by type: bulk 10, cargo 71, chemical tanker 17,
container 10, liquefied gas 8, multi-functional
large-load carrier 1, petroleum tanker 10, refrigerated
cargo t, rolf on/roll off 6, short-sea passenger 4,
vehicle carrier 2
nofe; includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1 , British Virgin
Islands 1 , Cyprus 1 , Denmark 6, Germany 20, Greece
1 , Iceland 1 , Italy 16, Lebanon 1 , Liberia 1 , Monaco 2,
Norway 5, Panama 5, Spain 22, Switzerland 8, United
Kingdom 1, Virgin Islands (UK) 1 (2002 est.)
Airports: 67 (2001)
Airports - with paved runways:
total: AO
over3,047m:5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 5
914 to 1,523 m:U
under 914 m:7 (2001)
Airports - with unpaved runways:
tofa/:27
914 to 1523 m:]
under 914 m: 26 (2001)','688ed74c5b1a7363f40f35c7817ea6f138389174b14822ce8ac92d3ebc63be93','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dd23f21e231146c800fee27f74ef8dd098188db906a2a76b2da3368ca56ba76',2002,'HN','Honduras','transportation',311,'Railways: 0 km
Highways:
tofa/:406 km
paved; 304 km
unpa ved: 102 km
Waterways: none
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 1 21 ships (1 ,000 GRT or over) totaling
2,034,181 GRT/3,191,597 DOT
ships by type: bulk 24, cargo 4, chemical tanker 34,
container 1 , liquefied gas 1 , petroleum tanker 14,
refrigerated cargo 40, roil on/roll off 2, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Bahrain 2, China 1,
Germany 4, Greece 27, Hong Kong 3, Italy 2, Japan
1, Norway 14, Sweden 13, United Kingdom 15, United
States 35 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
1,524to2,437m:2(2m)
Airports - with unpaved runways:
toial-A
914 to 1,523 m; 1 (2001)
Miirtary
Military branches: no regular indigenous military
forces; Royal Cayman Islands Police Force (RCIPF)
Military ■ note: defense is the responsibility of the
UK
Railways: 0 km
Highways:
total: 23,81 0 km
paved; 429 km
unpaved: 23,381 km (2000)
Waterways: 900 km
note: traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important
river, navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1 .8 m
Ports and harbors: Bangui, Nola, Salo, Nzinga
Airports: 51 (2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 2 (2001)
Airports -with unpaved runways:
total: 4B
2,438 to 3,047 m:1
1,524 to 2,437 m:9
914 to 1,523 m: 23
under 914 m-A5(2m)
Railways: Okm
Highways;
total: 33,400 km
paved: 450 km
unpaved: 32,950 km
note: probably no more than 8,000 km of the total
receive maintenance, the remainder being desert
tracks (2000)
Waterways: 2,000 km
Ports and harbors: none
Airports: 49(2001)
Airports - with paved runways:
total: 7
over 3,047 m: 2
2,438 to 3,047 m:2
1,524 to 2,437 m:1
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 42
1,524 to 2,437m: 12
914 to 1,523 m: 20
under 914 m: 10 (2001)
Railways:
total: 562 km
narrow gauge: 562 km 0.91 4-m gauge
note: length of operational route is reduced to 283 km
by disuse and lack of maintenance (2001 est.)
Highways:
total: 10,029 km
paved: 1 ,986 km (including 327 km of expressways)
unpaved: 8,043 km (1997)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutla, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
Merchant marine: none (2002 est.)
Airports: 83(2001)
Airports - with paved runways:
total: 4
over 3,047 m:1
1,524 to 2,437 m:)
914 to 1,523m: 2 (2001)
Airports - with unpaved runways:
tote* 79
914 to 1,523 m: 17
under 914 m:62 (2001)
Heliports: 1 (2001)','9c532f89973aef2b6a55bd4b358fc932423599b3a67f92db3b2cff9b0996c6f5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70fa9a403fdd10f6349aec152775cb5cf3a25982b88f8d0c99b6a064a38b6074',2002,'PE','Peru','transportation',322,'Railways:
total: 6,702 km
broad gauge: 2,831 km 1.676-m gauge (1,317 km
electrified)
narrow gauge: 1 1 7 km 1 .067-m gauge (28 km
electrified); 3,754 km 1.000-m gauge (37 km
electrified) (2000 est.)
Highways:
fofal: 79,800 km
paved: 11 ,01 2 km
i/npavecf: 66,788 km (1996)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 47 ships (1 ,000 GRT or over) totaling 669,670
GRT/931.647DWT
ships by type: bulk 11, cargo 4, chemical tanker 10,
container 5, liquefied gas 2, passenger 3, petroleum
tanker 4, roll on/rotl off 5, vehicle carrier 3, includes a
foreign-owned ship registered here as a flag of
convenience: Netherlands 1 (2002 est.)
Airports: 363(2001)
Airports - with paved runways:
total: 70
over 3,047 m:6
2,438 to 3,047 m:G
1,524 to 2,437 m: 20
914 to 1,523 m: 22
under 914 m: 16 (2001)
Airports - with unpaved runways:
total: 293
over 3,047 m-A
2,438 to 3,047 m: 4
1,524 to 2,437 m:11
914to1t523m:m
under 914 m:217 (2001)
Railways:
total. 965 km
narrow gauge: 965 km 1 .067-m gauge (2000 est.)
Highways:
total: 43, 197 km
paved: 8,165 km
unpaved: 35,032 km (2001)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 33 ships (1 ,000 GRT or over) totaling 239,876
GRT/393.680DWT
ships by type: cargo 2, chemical tanker 3, liquefied
gas 1, passenger 3, petroleum tanker 23, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Chile 1 , Greece 1
(2002 est.)
Airports: 205(2001)
Airports - with paved runways:
total: 61
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 18
914 to 1,523 m: 17
under 914 m: 19 (2001)
Airports - with unpaved runways:
total: U4
914 to 1,523 m:M
under 914 m: 113 (2001)
Heliports: 1 (2001)','a0a5f473f7623bc217a4c8f6e853fe0476ee36f008734b954fc4fd4ab3e91f34','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17f619deb5ff8f1221eeaf25dc559cdada915ab2ba101c1e9efaf18394a0a12a',2002,'CX','Christmas Island','transportation',331,'Railways: 24 km to serve phosphate mines
Highways:
total: 140 km (not including 100 km that is maintained
by private industry)
paved; 30 km
unpaved: 110 km (1999)
Waterways: none
Ports and harbors: Flying Fish Cove
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
totai''A
1,524 to 2,437 ''m:1 (2001)','0006b09e021ea244874df4d6db48e3f99e6e7a0b0f0d69fe76075fe6c9d9c20f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff485639b31d50f969b8782a341f24b0872059db89e0b4d1b2d4867b31d5e0f6',2002,'CG','Congo','transportation',336,'Railways:
total: 5,138 km
narrow gauge: 3,987 km 1.067-m gauge (858 km
electrified); 125 km 1.000-m gauge; 1,026 km
0.600-m gauge
nofe: severely reduced route-distance in use because
of damage to facilities by civil strife (2000 est.)
Highways:
total: 157,000 km (including 30 km of
expressways)(1996)
paved: NA km
unpaved: NA km
Waterways: 1 5,000 km (including the Congo and its
tributaries, and unconnected lakes)
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Merchant marine: none (2002 est.)
Airports: 232 (2001)
Airports - with paved runways:
fofa/;24
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m:15
914 to 1,523 m: 2 {2001)
Airports - with unpaved runways:
total: 20B
1,524 to 2,437 m: 20
914 to 1,523 m:%
under 914 m: 92 (2001)
Heliports: 1 (2001)
Railways:
total: 894 km
narrow gauge: 894 km 1 .067-m gauge (2000 est.)
Highways:
total: 12,800 km
paved: 1,242 km
unpaved: 11,558 km (1996)
122
Congo, Republic of the (continued)
Waterways: 1,120 km
note: the Congo and Ubangi (Oubangui) rivers
provide 1,120 km of commercially navigable water
transport; other rivers are used for local traffic only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Airports: 33(2001)
Airports - with paved runways:
total: A
over 3,047 m:1
1,524 to 2,437 m: 3 (2001)
Airports - with unpaved runways:
total: 2d
1,524 to 2t437m:7
914 to 1,523 m: 10
under 914 m: 12 {2m)','5a695806fedb0c10103039e8e22cadc955060b1be60cdcc2e89c6edeee031f28','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9849290aa39f95b71bb3c4354fe43f9c93fef39d0cdbed3862008f1ff67cad',2002,'CK','Cook Islands','transportation',349,'Railways: Okm
Highways:
total: 320 km (1992)
paved: NA
unpaved: NA
Waterways: none
Ports and harbors: Avarua, Avatiu
Airports: 7(2001)
Airports - with paved runways:
fofaM
1,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m:${20M)
124
Cook Islands (continued)
Waterways: none
Ports and harbors: none; offshore anchorage only','f6ee4f7df48676a01ca7745637dcec69ac7fd6d25e8f1467cfb95611b8a0c6e1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('692cc3a68b79fc70a4ea2afd70727c4f2d0f665011950b18004bace6a4c59abb',2002,'CR','Costa Rica','transportation',358,'Railways:
fofa/:950 km
narrow gauge: 950 km 1 .067-m gauge (260 km
electrified) (2000 est.)
Highways:
total: 37,273 km
paved: 7,827 km
unpaved: 29,446 km (1998 est.)
Waterways: 730 km (seasonally navigable)
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine:
totals ship (1 ,000 GRT or over) totaling 1,716GRT/
NADWT
ships by type: passenger 1 (2002 est.)
Airports: 152(2001)
Airports - with paved runways:
total: 29
2,438 to 3,047 m: 2
1,524 to 2,437mA
127
Costa Rica (continued)
914 to 1, 523 m:19
under 914 m: 7 (2001)
Airports • with unpaved runways:
toteM23
914 to 1,523 m: 28
under 914 m: 95 (2001)','bd5b9a247d4dd89d3bd93e793421f58c3ff640d9f9bd2c10545d18f367aaee04','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ac78f0e43db333213958a10d001b60281a4dbab5881359d595bc9594e9292d',2002,'SI','Slovenia','transportation',370,'Railways:
to/a/: 2,726 km
standard gauge: 2,726 km 1 .435-m gauge (NA
electrified) (2000)
Highways:
total: 28,009 km
paved: 23,695 km (including 330 km of expressways)
unpaved: 4,31 4 km (2001)
Waterways: 785 km
note: (perennially navigable; large sections of Sava
blocked by downed bridges, silt, and debris)
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992)
Ports and harbors: Dubrovnik, Dugi Rat, Omisalj,
Ploce, Pula, Rijeka, Sibenik, Split, Vukovar (inland
waterway port on Danube), Zadar
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling ''681 ,465
GRT/1 ,076,31 5 DWT
ships by type: bulk 14, cargo 13, chemical tanker 1,
combination bulk 5, container 1, multi-functional
large-load carrier 3, passenger 1 , petroleum tanker 2,
refrigerated cargo 2, roll on/roll off 4, short-sea
passenger 3
note: includes a foreign-owned ship registered here
as a flag of convenience: Hong Kong 1 (2002 est.)
Airports: 67(2001)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m:6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m:B (mi)
Airports - with unpaved runways:
total: 45
1524 to 2,437 m:\\
914 to 1,523 m:7
under 914 m: 37 (2001)
Heliports: 1 (2001)','8f919ef86ef0ba0a32c1d13ebacf676b0a523645d605c05f56827d7bc0adbc18','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a179bf259e9a62329a57a1d72a299aba492b7600fbf01cd85104b572d6d770ea',2002,'CU','Cuba','transportation',380,'Railways:
totai: 4,807 km
standard gauge: 4,807 km 1 .435-m gauge, in public
use (147 km electrified)
note: in addition to the 4,807 km of standard-gauge
track in public use, 7,162 km of track is in private use
by sugar plantations; about 90% of the private use
track is standard gauge and the rest is narrow gauge
(2000 est.)
Highways:
fofa/: 60;858 km
paved: 29,820 km (including 638 km of expressway)
wipaved:31,038 km (1997)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanilio, Mariel, Matanzas, Nuevitas, Santiago de
Merchant marine:
total: 14 ships (1 ,000 GRT or over) totaling 44,187
GRT/63.416DWT
ships by type: bulk 3, cargo 6, liquefied gas 1,
petroleum tanker 1 , refrigerated cargo 3 (2002 est.)
Airports: 172(2001)
Airports - with paved runways:
tofa/:78
over3t047m:7
2J38 to 3,047 m:8
1,524 to 2,437 m: 20
914 to 1,523 m: 1
under 914 m:36 (2001)
Airports - with unpaved runways:
totef: 94
914 to 1,523 m: 31
under 914 m: 63 (2001)
Railways: 0 km
Highways:
total: Greek Cypriot area: 1 0,663 km (1 998 est.);
Turkish Cypriot area: 2,350 km (1996 est.)
paved: Greek Cypriot area: 6,249 km (1998 est.);
Turkish Cypriot area: 1 ,370 km (1996 est.)
unpaved: Greek Cypriot area: 4,414 km (1998 est.);
Turkish Cypriot area: 980 km (1996 est.)
Waterways: none
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos
Merchant marine:
total: 1 ,254 ships (1 ,000 GRT or over) totaling
22,802,712 GRT/36,337,768 DWT
ships by type: barge carrier 2, bulk 438, cargo 378,
chemical tanker 24, combination bulk 31 , combination
ore/oil 2, container 133, liquefied gas 4, passenger 7,
passenger/cargo 1, petroleum tanker 131,
refrigerated cargo 46, roll on/roll off 41 , short-sea
passenger 10, specialized tanker 3, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Austria 12, Belgium 2,
Bulgaria 2, Canada 3, Chile 2r China 16, Croatia 2,
Cuba 1 1 , Finland 1 , Germany 229, Greece 607, Guam
1 , Hong Kong 6, India 6, Iran 1 , Ireland 1 , Israel 5, Italy
1, Japan 26, Latvia 14, Lebanon 1, Lithuania 2,
Mexico 1 , Monaco 10, Netherlands 30, Norway 23,
Panama 1, Philippines 2, Poland 19, Portugal 2,
Russia 57, Singapore 2, Slovenia 2, South Korea 4,
Spain 7t Sudan 2, Sweden 6, Switzerland 4, Turkey 1 ,
Ukraine 1, United Arab Emirates 13, United Kingdom
6, United States 4, Vietnam 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 12
2,438 to 3,047 m:7
1,524 to 2,437 mA
914 to 1,523 m: 3
under 914 mA (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 mA
under 914 m: 2 (2001)
Heliports: 7(2001)
Railways:
total: 9,444 km
standard gauge: 9,350 km 1 ,435-m gauge (2,843 km
electrified; 1,929 km double-track)
narrow gauge: 94 km 0.760-m gauge (2000 est.)
Highways:
total: 55,432 km
paved: 55,432 km (including 499 km of expressways)
unpaved: 0 km (2000)
Waterways: 303 km
note: (the Labe (Elbe) is the principal river) (2000)
Pipelines: natural gas 3:550 km (2000)
Ports and harbors: Decin, Prague, Usti nad Labem
Airports: 121 (2001)
Airports - with paved runways:
total: 4A
over 3,047 m: 2
2,438 to 3,047 m:10
1,524 to 2,437 m:tt
914 to 1,523 m: 2
under 914 m: 17 (2001)
Airports - with unpaved runways:
total: 77
1,524 to 2,437 m:]
914 to 1,523 m: 28
under 914 m: 48 (2001)
Heliports: 1 (2001)','f7d381e687473f89af165f927eb567a7dabda38774a92196bcd7bf036519c5ae','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6c863446105963d78500e42c91b13add77638e4e1c557eb583b928574741b3e',2002,'DJ','Djibouti','transportation',398,'Railways:
total: 100 km (Djibouti segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 100 km 1.000-m gauge
note: Djibouti and Ethiopia plan to revitalize the
century-old railroad that links their capitals by 2003
(2001 est.)
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996)
Waterways: none
Ports and harbors: Djibouti
Airports: 12 (2001)
Airports - with paved runways:
fofa/:2
over 3,047 mA
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
tofaMO
1 ,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m; 3 (2001)
Railways: 0 km
Highways:
total: 7B0 km
paved: 390 km
unpaved:3% km (2001)
Waterways: none
Ports and harbors: Portsmouth, Roseau
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2 (2001)','aa6096d918393b0f0e6235fdd93800c806180bd102b837267fd43d561ceac82d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d57f01d97229a5bc340c9ef673b5dbbe588765ed1197f5d10e6615e002bd74ea',2002,'DO','Dominican Republic','transportation',408,'Railways:
fofa/:757km
standard gauge: 375 km 1.435-m gauge (Central
Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominican .
Republic Government Railway)
miscellaneous gauge: 240 km operated by sugar
companies in various gauges (0.558-m, 0.762-m,
1.067-m gauges) (2000 est.)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1996)
Waterways: none
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana,
Manzanillo, Puerto Plata, San Pedro de Macoris,
Santo Domingo
Merchant marine:
ml: 1 ship (1 ,000 GRT or over) totaling 1 ,587 GRT/
1,165 DWT
ships by type: cargo 1 (2002 est.)
Airports: 29(2001)
Airports - with paved runways:
tofafr13
over 3,047 m: 3
2,438 to 3,047 m: 2
1524 to 2,437 m: 4
914to1,523m:Z
under 914 m: 1 (2001)
Airports - with unpaved runways:
tate/:16
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m:10 (2001)
Railways:
tofa/:96km
narrow gauge: 96 km 1 .000-m gauge,
note: rural, narrow-gauge system for hauling
sugarcane; no passenger service (2001)
Highways:
total: 14,400 km
paved: 14,400 km
unpaved: 0 km (1996)
Waterways: none
Ports and harbors: Guanica, Guayanilla, Guayama,
Playa de Ponce, San Juan
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 19,046 GRT/
22,582 DWT
ships by type: container 1 (2002 est.)
423
Puerto RiCO (continued)
Airports: 30(2001)
Airports - with paved runways:
tofa/:19
over 3,047 m:3
1,524 to 2,437 m: 3
0f4tof,523m:8
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: W
914 to 1,523 m: 2
under 914 m:9(2001)','47f1bbf9f556842cf46aa612165e3aef6968d103d9a4c54f011554491a9507bd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e24f43b896010ef6c26ec69455de1b08fae4e1d0b552649decd0a44702154b',2002,'ID','Indonesia','transportation',415,'Railways: Okm
Highways:
total: 3,800 km
pawed: 428 km
unpave* 3,372 km (1995)
Waterways: NA
Pipelines: NA
Ports and harbors: NA
Merchant marine:
total: M
ships by type:
Airports: 8(2001)
Airports - with paved runways:
tofa/:3
2,438 to 3,047 m:]
1,524 to 2,427 m: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 3
under 914 m:''2(2001)
Heliports: 1 (2001)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km
electrified; 101 km double-track); 497 km 0.750-m
gauge (2001)
Highways:
total: 342,700 km
paved: 158,670 km
unpaved: 184,030 km (1997)
Waterways: 21,579 km total
note: Sumatra 5,471 km, Java and Madura 820 km,
Kalimantan 10,460 km, Sulawesi (Celebes) 241 km,
Irian Uaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Makassar, Palembang, Semarang, ''
Surabaya
Merchant marine:
total: 668 ships (1 ,000 GRT or over) totaling
2,969,281 GRT/4,043,526 DWT
ships by type: bulk 41 , cargo 392, chemical tanker 12,
container 32, liquefied gas 3, livestock carrier 1 ,
passenger 8, passenger/cargo 14, petroleum tanker
126, refrigerated cargo 1, roll on/roll off 15, short-sea
passenger 8, specialized tanker 9, vehicle carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 1 , Hong
Kong 2, India 1, Japan 2, Malaysia 1, Monaco 3,
Panama 1 , Philippines 1 , Singapore 1 1 , South
Korea 1 , Switzerland 1 , UK 2, US 1 (2002 est.)
Airports: 490(2001)
Airports ■ with paved runways:
total: m
over 3,047 m: 4
2,438 to 3,047 m: 13
1,524 to 2,437 m;46
914 to 1,523 m: 48
under 914 m: 45 (2001)
Airports • with unpaved runways:
total: 339
1,524 to 2,437 m: 3
914 to 1,523 m: 27
uncfer 074 m: 309 (2001)
Heliports: 6(2001)
Railways:
total: 6,130 km
broad gauge: 94 km 1 .676-m gauge
standard gauge: 6,036 km 1.435-m gauge (187 km
electrified)
note: broad-gauge track is employed at the borders
with Azerbaijan and Turkmenistan which have
broad-gauge rail systems; 41 km of the
standard-gauge, electrified track is in suburban
service at Tehran (2001)
Highways:
total: 140,200 km
paved: 49,440 km (including 470 km of expressways)
unpaved: 90,760 km (1998 est.)
Waterways: 904 km
note: the Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been
dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzali, Bushehr, Bandar-e Emam
Khomeyni, Bandar-e Lengeh, Bandar-e Mahshahr,
Bandar-e Torkaman, Chabahar (Bandar Beheshti),
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sim,
Khorramshahr (limited operation since November
1992), Now Shahr
Merchant marine:
total: 147 ships (1 ,000 GRT or over) totaling
4,136,971 GRT/7,166,703 DWT
ships by type: bulk 48, cargo 36, chemical tanker 4,
container 10, liquefied gas 1, multi-functional
large-load carrier 6, petroleum tanker 30, refrigerated
cargo 2, roll on/roll off 9, short-sea passenger 1
(2002 est.)
Airports: 322(2001)
Airports - with paved runways:
total: 118
over 3,047 m: 40
2,438 to 3,047 m: 24
1,524 to 2,437 m: 24
914 to 1,523 m: 23
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 204
over 3,047 m:1
2,438 to 3,047 m:Z
1,524 to 2,437 m:13
914 to 1,523 m: 124
under 914 m: 63 (2001)
Heliports: 11 (2001)
248
Iran (continued)
Railways:
total: 2,339 km
standard gauge: 2,339 km 1.435-m gauge (2001)
Highways:
total: 45,550 km
paved; 38,400 km
unpaved: 7,150 km (1996 est)
Waterways: 1,015 km
note: Shaft al Arab is usually navigable by maritime
traffic for about 130 km; channel has been dredged to
3 m and is in use; Tigris and Euphrates Rivers have
navigable sections for shallow-draft boats; Shaft al
Basrah canal was navigable by shallow-draft craft
before closing in 1991 because of the Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1 ,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 25 ships (1 ,000 GRT or over) totaling 186,709
GRT/278,575 DWT
ships by type: cargo 14, passenger 1 , passenger/
cargo 1 , petroleum tanker 8, roll on/roll off 1
(2002 est.)
Airports: 108(2001)
Airports - with paved runways:
total: 73
over 3,047 m: 20
2,438 to 3,047 m: 34
1,524 to 2,437 m:6
914 to 1,523 m:B
under 914 m:7(200^
Airports - with unpaved runways:
total: 35
over 3, 047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m:W
under 914 m: 12 (2001)
Heliports: 4(2001)
Railways:
total: 1,801 km
narrow gauge: 1,801 km 1.000-m gauge (148 km
electrified) (2001)
Highways:
total: 64,672 km
paved: 48,707 km (including 1,192 km of
expressways)
unpaved: 15,965 km
note: in addition to these national and main regional
roads, Malaysia has thousands of kilometers of local
roads that are maintained by local jurisdictions (1999)
Waterways: 7,296 km
note: Peninsular Malaysia 3,209 km, Sabah 1 ,569 km,
Sarawak 2,51 8 km
Pipelines: crude oil 1 ,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabatu,
Kuantan, Kuching, Kudat, Labuan, Lahad Datu,
Lumut, Miri, PasirGudang, Penang, Port Dickson,
Port Kelang, Sandakan, Sibu, Tanjung Berhala,
Tanjung Kidurong, Tawau
Merchant marine:
total: 363 ships (1 ,000 GRT or over) totaling
4,952,119 GRT/7,229,299 DWT
ships by type: bulk 57, cargo 1 1 4, chemical tanker 35,
container 62, liquefied gas 20, livestock carrier 1,
passenger 2, petroleum tanker 60, roll on/roll off 5,
specialized tanker 1 , vehicle carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , China 1,
Germany 2, Hong Kong 15, Indonesia 3, Japan 4,
Monaco 1, Philippines 2, Singapore 78, South
Korea 2, Vietnam 1 (2002 est.)
Airports: 116(2001)
Airports - with paved runways:
tofa/;34
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 11
914 to 1,523 m:6
under 914 m:7(2W\\) .
Airports - with unpaved runways:
total: 82
1,524 to 2A37m:\\
914 to 1,523 m:B
under 914 m:7Z{2Q0-\\)
Heliports: 1 (2001)
Highways:
tofa/: 240 km
paved: 42 km
unpaved: 198 km (1996)
Waterways: none
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 7 (2001)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: 4
9/4fo?,523m;2(2001)
344
Railways: 0 km
Highways:
total: 19,600 km
pavecf: 686 km
unpaved: 18,914 km (1996)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port
Moresby, Rabaul
Merchant marine:
total: 22 ships (1 ,000 GRT or over) totaling 40,91 1
GRT/58,723 DWT
405
Papua New Guinea (continued)
ships by type: bulk 1 , cargo 1 0, chemical tanker 1 ,
combination ore/oil 3, container 1 , petroleum tanker 3,
roll on/roll off 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Singapore 2t United
Kingdom 7 (2002 est.)
Airports: 490(2001)
Airports - with paved runways:
totef:21
2,438 to 3,047 m: 2
1,524 to 2,437 m:14
914 to 1,523 m: 4
under 914 m: 1 (2001)
Airports - with unpaved runways:
total, m
1.524 to 2:437m:W
914 to 1,523 m: 57
under 914 m: 402 (2001)
Heliports: 2(2001)
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 .000-m gauge
note: there is also a 83 km mass transit system with 48
stations
Highways:
tote/: 3,150 km
paved: 3,066 km (including 150 km of expressways)
unpawed: 84 km (2000)
Waterways: none
Ports and harbors: Singapore
Merchant marine:
total: 876 ships (1 ,000 GRT or over) totaling
20,686,612 GRT/32,647,743DWT
ships by type: bulk 131 , cargo 1 00, chemical tanker
81 , combination bulk 1 0, combination ore/oil 6,
container 168, liquefied gas 35, livestock carrier 2r
multi-functional large-load carrier 1 , petroleum tanker
287, refrigerated cargo 6, roll on/roll off 5, short-sea
passenger 1 , specialized tanker 1 1 , vehicle carrier 32
nofe: includes some foreign -owned ships registered
here as a flag of convenience: Australia 7, Belgium 6,
China 12, Denmark 27, Germany 17, Greece 4, Hong
Kong 44, Indonesia 8, Japan 52, Malaysia 4, Monaco
22, Netherlands 2, Norway 42, Philippines 6,
Russia 3, Slovenia 1, South Korea 10, Sweden 13,
Switzerland 7, Taiwan 46, Tanzania 2, Thailand 22,
United Arab Emirates 4, United Kingdom 14, United
States 1 (2002 est.)
Airports: 9(2001)
Airports - with paved runways:
totals
over 3,047 m: 2
2,438 to 3,047 m:1
1,524 to 2,437m: 4
914 to 1,523 m:)
under 914 m: 1 (2001)','2b4e9b889b00b44547b932fd546796c42edc636ec3c97fc9e4e2f0bb7c6da997','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('495f67fa522edd17394a16f82d777a56fdcc50909d9a64a4ea63a6ae6c4bab96',2002,'LY','Libya','transportation',425,'Railways:
total: 4,955 km
standard gauge: 4,955 km 1,435-m gauge (42 km
electrified; 1,560 km double-track) (2000 est.)
Highways:
total: 64,000 km
paved: 50,000 km
unpaved: 14,000 km (1996)
Waterways: 3,500 km
note: including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller
canals in the delta; Suez Canal (193.5 km including
approaches), used by oceangoing vessels drawing up
to 16.1 mot water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, Bur Safajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine:
total: 175 ships (1 ,000 GRT or over) totaling
1,331,186 GRT/1 , 987,964 DWT
ships by type: bulk 23, cargo 58, container 2, liquefied
gas 1 , passenger 61 , petroleum tanker 14, roll on/roli
off 13, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience:, Denmark 1 ,
Germany 1, Greece 6, Lebanon 3, Monaco 1,
Ukraine 1 (2002 est.)
Airports: 92(2001)
Airports - with paved runways:
total: 72
over 3,047 m: 13
2,438 to 3,047 m: 37
1,524 to 2,437 m:\\7
914 to 1,523 m: 2
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 20
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
91 4 to 1,523 m:7
under 914 m: 10 (2001)
Heliports: 2(2001)
157
Egypt (continued)','80eeb7d07d23892ba9df228b01c317635dc1fffd509fcbab1a26f2505d6290e0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b35841a73ea06b2f0d1fd71ef72151df1c258b4db5a61b20b9daedad59846d7b',2002,'GN','Guinea','transportation',435,'Railways:
fofa/:0km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2,880 km (1996)
Waterways: none
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 14,413
GRT/1 6,251 DWT
ships by type: bulk 1 , cargo 3, passenger 1 ,
passenger/cargo 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
tofa/:2
2,438 to 3,047 m:l
1 ,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
tofa/M
under 914 m: 1 (2001)
Railways:
total: 31 7 km
narrow gauge: 317 km 0.950-m gauge
note: links Ak''ordat and Asmara with the port of
Massawa; nonoperationa! since 1978 except for about
a 5 km stretch that was reopened in Massawa in 1 994;
rehabilitation of the remainder and of the rolling stock
is under way (2001 est.)
Highways:
total: 3,850 km
paved: 810 km
unpaved: 3,040 km (2000)
Waterways: none
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa) ,
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 9,100
GRT/23,399DWT
ships by type: bulk 1 , cargo 2, liquefied gas 1 ,
petroleum tanker 1, roll on/roll off 1 (2002 est.)
Airports: 21 (2001)
Airports - with paved runways:
tote/: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2001)
Airports - with unpaved runways:
total: 17
over 3,047 m:\\
2,438 to 3,047 m:2
1,524 to 2,437 m:5
914 to 1,523 m:7
under 914 m: 2 (2001)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1 .067-m gauge
standard gauge: 52 km 1 .435-m gauge
note: years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and
utility of the system; a project to restore Nigeria''s
railways is now underway (2001)
Highways:
total: 193,200 km
paved: 59,892 km (including 1,194 km of
expressways)
unpaved: 133,308 km
note: many of the roads reported as paved may be
graveled; because of poor maintenance and years of
heavy freight traffic - in part the result of the failure of
the railroad system - much of the road system is
barely usable (2001)
383
Nigeria (continued)
Waterways: 8,575 km
note: consisting of the Niger and Benue rivers and
smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products
3t000 km; natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warri
Merchant marine:
total: 43 ships (1 ,000 GRT or over) totaling 331 ,094
GRT/614,171 DWT
ships by type: bulk 1 , cargo 7, chemical tanker 4,
petroleum tanker 29, roll on/roll off 1 , specialized
tanker 1
note; includes some foreign-owned ships registered
here as a flag of convenience: Bulgaria 1 , Greece 1 ,
Norway 1 , Pakistan 1 , Togo 1, United States 1
(2002 est.)
Airports: 70(2001)
Airports - with paved runways:
total: 35
over 3,047 m: 7
2,438 to 3,047 m:10
1,524 to 2,437 m: 9
914 to 1,523 m: 7
under 91 ''4 m: 2 (2001)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 3
914 to 1,523 m:U
under 914 m:18 (2001)
Heliports: 1 (2001)','37760519bbf65e56510cea97b7e7b180052516665473ec3c359b8a9dfcc9e202','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01cae9175566a505971859fb7feb2e68be36f270187e0deee246c02b00180692',2002,'EE','Estonia','transportation',447,'Railways:
total: 968 km common carrier lines only; does not
include dedicated industrial lines
broad gauge: 968 km 1.520-m gauge (132 km
electrified) (2001)
Highways:
total: 30,300 km
paved: 29,200 km (including 75 km of expressways);
note - these roads are said to be hard-surfaced, and
include, in addition to conventionally paved roads,
some that are surfaced with gravel or other coarse
aggregate, making them trafficable in all weather
unpaved: 1,100 km (2000)
Waterways: 320 km (perennially navigable) (2002)
Pipelines: natural gas 2,000 km (2002)
166
Estonia (continued)
Ports and harbors: Haapsalu, Kunda, Muuga,
Paldiski, Parnu, Tallinn
Merchant marine:
total: 37 ships (1 ,000 GRT or over) totaling 245,958
GRT/1 93,042 DWT
ships by type: bulk 2, cargo 1 3, container 5, petroleum
tanker 2, roll on/roll off 9, short-sea passenger 6
note: includes a foreign-owned ship registered here
as a flag of convenience: Liberia 1 (2002 est.)
Airports: 32(2001)
Airports - with paved runways:
total; Q
2,438 to 3,047 m:7
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 24
over 3,047 m;1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1523 m;5
under 914 m: 6 (2001)
Railways:
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1 .000-m gauge
note: in 1998, Djibouti and Ethiopia announced plans
to revitalize the century-old railroad that links their
capitals and since then Ethiopia has expended
considerable effort to repair and maintain the lines; in
2001 , Ethiopia and Sudan agreed to build a line from
Ethiopia to Port Sudan (2000 est.)
Highways:
total: 24,145 km
paved: 3,290 km
unpaved: 20,855 km (1998)
Waterways: none
Ports and harbors: none; Ethiopia is landlocked
and was by agreement with Eritrea using the ports of
Assab and Massawa; since the border dispute with
Eritrea flared, Ethiopia has used the port of Djibouti for
nearly all of its imports
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 81 ,933
GRT/101,287DWT
ships by type: cargo 5, container 1 , petroleum
tanker 1, roll on/roll off 2 (2002 est.)
Airports: 86(2001)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
tofa/;72
over 3,047 m: 2
2,438 to 3,047 m: 4
1, 524 to 2,437 m:11
914 to 1,523 m: 33
under 914 m: 22 (20M)','55cda6a88723a34e83d19ad41dcb0802bb086714ae3b640bdc7ff0fba238e040','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822c4cb08e89db5082e586e966b7c33d9505185d756d5592408f26c87162f510',2002,'FO','Faroe Islands','transportation',457,'Railways: Okm
Highways:
total: 4Q3 km
paved: 454 km
unpaved: 9 km (1999)
Waterways: none
Ports and harbors: Torshavn, Klaksvik, Tvoroyri,
Runavik, Fuglafjordhur
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 100,951
GRT/1 39,396 DWT
173
Faroe Islands (continued)
ships by type: cargo 2, petroleum tanker 2,
refrigerated cargo 1 , rati on/roll off i, short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 3, Norway 1 ,
United''Kingdom 1 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: \\
914 to 1,523 m: 1 (2001)','957bd1f056124f947b52f0a1103485cd44b95d6afa2fbee4d264fbb68838ac77','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c6cb06d2fc5aff9e963fdab450d22109529db3b5d5e8ccfddf22a62727dbb0',2002,'JE','Jersey','transportation',468,'Railways:
total: 597 km
narrow gauge: 597 km 0.61 0-m gauge
note: belongs to the government-owned Fiji Sugar
Corporation (1995)
Highways:
total: 3,440 km
paved: 1,692 km
unpaved:\\,74% km (1996)
Waterways: 203 km
note: 122 km navigable by motorized craft and
200-metric-ton barges
Ports and harbors: Lambasa, Lautoka, Levuka,
Malau, Savusavu, Suva, Vuda
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 1 ,870
GRT/14,787 DWT
ships by type: chemical tanker 2, passenger 1 ,
petroleum tanker 1 , roll on/roll off 1 , specialized tanker
1, includes some foreign-owned ships registered here
as a flag of convenience: Australia 1 , Singapore 4
(2002 est.)
Airports: 27 (2001)
Airports - with paved runways:
total: 3
over 3,047 m:1
1,524 to 2,437 m''A
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 24
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 914 m: 18 (2001)
Railways:
total: 5,865 km
broad gauge: 5,865 km 1 ,524-m gauge (2,234 km
electrified; 480 km double- or multiple-track)
(2000 est.)
Highways:
tote/: 77,831 km
paved: 49,789 km (including 444 km of expressways)
unpaved: 28,042 km (1999)
Waterways: 6,675 km
note: includes Saimaa Canal; 3,700 km suitable for
large ships
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 98 ships (1 ,000 GRT or over) totaling 1 ,172,404
GRT/1 ,144,1 39 DWT
ships by type: bulk 9, cargo 26, chemical tanker 5,
passenger 1 , petroleum tanker 1 1 , roll on/roll off 36,
short-sea passenger 10
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Sweden 1
(2002 est.)
Airports: 160(2001)
Airports - with paved runways:
total: 73
over 3,047 m:Z
2,438 to 3,047 m: 26
1,524 to 2,437 m: 10
914 to 1,523 m: 22
under 914 m: 12 (2001) 4
Airports - with unpaved runways:
total: Q7
914 to 1,523 m:5
under 914 m:Z2(20M)
Railways:
tofa/;647 km
standard gauge: 647 km 1 .435-m gauge (2001 )
Highways:
total: 15,965 km
paved: 15,965 km (including 56 km of expressways)
unpaved: 0 km (1998 est.)
Waterways: none
Pipelines: crude oil 708 km; petroleum products
290 km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eiiat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 16 ships (1,000 GRT or over) totaling 595,319
GRT/704,544 DWT
ships by type: container 15, roll on/roll off 1
(2002 est.)
Airports: 54(2001)
Airports - with paved runways:
fofa/:29
over 3,047 m: 2
2,43B to 3,047 m:4
1,524 to 2,437 m:7
914to1)523m:\\\\
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m:1
914 to 1 ,523 m: 4
under 914 m: 20 (2001)
Heliports: 3(2001)
Railways: 0 km
Highways:
total: 577 km (1995)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
totals
1,524 to 2,437 m;1 (2001)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,590 km
unpaved: 860 km (1999 est.)
Waterways: none
Pipelines: crude oil 877 km; petroleum products 40
km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina'' ''Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 38 ships (1 ,000GRTor over) totaling 2,274,515
GRT/3,627,835DWT
ships by type: bulk 1 , cargo 1 , container 6, liquefied
gas 6, livestock carrier 5, petroleum tanker 19
note: includes some foreign-owned ships registered
here as a flag of convenience: Monaco 1, Saudi
Arabia 1 (2002 est.)
Airports: 7(2001)
Airports - with paved runways:
total: 3
over 3,047 m:1
2,438 to 3,047 m: 2 (2001)
Airports - with unpaved runways:
fofaf:4
1,524 to 2,437 m:1
under 074 m: 3 (2001)
Heliports: 3(2001)
Railways: Okm (2002)
Highways:
total: 4,825 km
paved: 2,287 km
unpa ved: 2,538 km (1999)
Waterways: none
Ports and harbors: Mueo, Noumea, Thio
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 1 1261 GRT/
1,600 DWT
ships by type: cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Malaysia 1 (2002 est.)
Airports: 29(2001)
Airports - with paved runways:
total: 6
over 3,047 m:1
914 to 1,523 m: 4
under 914 m: 1 (2001)
Airports - with unpa ved runways:
total: 23
914 to 1,523 m: 12
under 914 m:11 (2001)
Heliports: 6(2001)
Railways:
total: 1,201 km
standard gauge: 1 ,201 km 1 .435-m gauge (489 km
electrified) (2001)
Highways:
total: 19,586 km
paved: 17,745 km (including 249 km of expressways)
unpaved: 1 ,841 km (1 998 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Airports: 14(2001)
Airports - with paved runways:
total: 6
over 3, 047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: B
1,524 to 2,437 m: 2
914 to 1t523m: 2
Urtcfer9f4m:4(2001)
Railways:
tofa/;297km
narrow gauge: 297 km 1 .067-m gauge
note: includes 71 km which are not in use (2001)
Highways:
total: 3,800 km
paved: 1,064 km
unpavecf: 2,736 km (2002)
Waterways: none
Ports and harbors: none
Airports: 18(2001)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (2001)
Airports - with unpaved runways:
total: M
914 to 1,523 m: 7
under 914 m:10 (2001)','9f1b8ae241de5ef19bda21ff8ad8fde9ca7fb8b6a093529f13d319ca7e585c23','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f42cace6001e9837ac3f40add27d1d7240677d3a4aa0a78190859ea2ece8ea7',2002,'WF','Wallis and Futuna','transportation',475,'Railways:
total: 31 ,939 km (operated by French National
Railways (SNCF); 14,176 km of SNCF routes are
electrified and 12,132 km are double- or
multiple-track)
standard gauge: 31 ,840 km 1 .435-m gauge
narrow gauge: 99 km 1 .000-m gauge (2000 est.)
Highways:
total: 892,900 km
paved: 892,900 km (including 9,900 km of
expressways)
unpaged: 0 km (1999)
Waterways: 14,932 km (6,969 km heavily traveled)
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling 1 ,263,691
GRT/1 ,769,932 DWT
ships by type: bulk 3, cargo 4, chemical tanker 9,
combination bulk 1 , container 3, liquefied gas 3,
passenger 3, petroleum tanker 15, roll on/roll off 4,
short-sea passenger 4
note: includes some foreign-owned ships registered
here as a flag of convenience: French Polynesia 2,
Greece 1 , Japan 1 , Norway 1 , Sweden 9 (2002 est.)
Airports: 477(2001)
Airports - with paved runways:
total: 270
over 3,047 m: 14
2,438 to 3,047 m: 29
1,524 to 2,437 m: 96
914 to 1,523 m:75
under 91 4 m:56 (2001)
Airports - with unpaved runways:
tofa/:207
1,524 to 2,437 m: 3
914 to 1,523 m;73
under 914 m: 131 (2001)
Heliports: 3(2001)','f00acd149c5bb73ea097f4561e1bfbef47be2851dd8e8086deeb2c6692ad917a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35aa1229af0285b7aa9c0394957298d9b444027597221b13b4a0d1dc173104f6',2002,'PF','French Polynesia','transportation',491,'Railways: 0 km
Highways:
fo/a/:792km
parad: 264 km
unpaved:52B km (2000)
Waterways: none
Ports and harbors: Mataura, Papeete, Rikitea,
Uturoa
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,240 GRT/
7,765 DWT
ships by type: cargo 1 , passenger/cargo 2,
refrigerated cargo 1 (2002 est.)
Airports: 45 (2001)
Airports - with paved runways:
total:
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m;21
wncfer ST4 /n; 5 (2001 )
Airports - with unpaved runways:
total: 12
914 to 1,523 m: 3
under 914 m: 9 (2001)','e838e6505fb729ae74a6cefe57e257b1817b4b3734cb1f508b25c5ede5106c8d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa91ed2cba4eea2b4b3429249cda5a4f51cdcf66d27ed1d7a99f09efb88ed66',2002,'GW','Guinea-Bissau','transportation',499,'Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
(mpavetf: 1,744 km (1996)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
totals
over 3,047 m:1 (2001)','7868d7e6535cfc4abff54a0e0c457f914c7c2fa574532c2e94e9567cdfb7a293','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3672d25642d6eb67d2c894ccedae3d5b1d5e98bef3462899a82912451a92e9b',2002,'IL','Israel','transportation',509,'Railways:
total: NA km; note - one line, abandoned and in
disrepair, little trackage remains (2001 est.)
Highways:
fofa/;NAkm ,
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Waterways: none
Ports and harbors: Gaza
Airports: 2(2001)
note: includes Gaza International Airport (GIA),
inaugurated on 24 November 1998 as part of
agreements stipulated in the September 1995 Oslo II
Accord and the 23 October 1998 Wye River
Memorandum; GIA has been largely closed since
October 2000 by Israeli orders and its runway was
destroyed by the Israeli Defense Forces in
December 2001
Airports - with paved runways:
totaM
over 3,047 m:] (2001)
Airports - with unpaved runways:
tofa/:1
under 91 4 m: 1 (2001)','3226337ad674b1e2428cf3b8b58cdd61d0e499cb9dad6117dc03aef6596b104e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('841d07d4f2692f79d84fc9890a5a15ffe95962c2eec5823a458929f50ae8328d',2002,'GE','Georgia','transportation',517,'Railways:
totai: 1,583 km in common carrier service; does not
include industrial lines
broad gauge: 1 ,546 km 1 .520-m gauge
narrow gauge: 37 km 0.912-m gauge (2000 est.)
Highways:
total: 33,900 km
paved: 29,500 km (includes some afl-weather
gravel-surfaced roads)
unpaved: 4,400 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Bat umi, Pot''i, Sokhumi
Merchant marine:
totai: 64 ships (1 ,000 GRT or over) totaling 210,620
GRT/288,565 DWT
ships by type: bulk 5, cargo 46, container 5, petroleum
tanker 7, roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Belize 1, Bulgaria 1 ,
Cyprus 1 , Ecuador 1 , Egypt 4, Gibraltar 1 , Greece 5,
Jordan 1 , Latvia 1 , Liberia 1 , Malta 1 , Panama 9,
Romania 8, Russia 4, Saint Kitts and Nevis 3, Saint
Vincent and the Grenadines 3, Saudi Arabia 2, Syria
5, Turkey 2, Ukraine 7, United Arab Emirates 1 1 ,
United Kingdom 1, United States 1 (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
to/a/: 16
over 3,047 m:\\
2,438 to 3,047 m:8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m;3 (2001)
Airports - with unpaved runways:
total: 15
2,438 to 3,047 m:1
1,524 to 2,437m: 4
914 to 1,523 m: 4
under 914 m:6 (2001)
Transportation - note: transportation network is in
poor condition resulting from ethnic conflict, criminal
activities, and fuel shortages; network lacks
maintenance and repair
Railways:
total: 44,000 km (including at least 20,300 km
electrified); most routes are double- or multiple-track
nofe: since privatization in 1994, Deutsche Bahn AG
(DBAG) no longer publishes details of the track it
197
Germany (continued)
owns; in addition to the DBAG system there are 102
privately owned railway companies which own
approximately 3,000 to 4,000 km of track (2001 est.)
Highways:
total: 656,140 km
paved: 650,891 km (including 1 1 ,400 km of
expressways)
unpaved: 5,249 km (all-weather) (1998 est.)
Waterways: 7,500 km
note: major rivers include the Rhine and Elbe; Kiel
Canal is an important connection between the Baltic
Sea and North Sea (1999)
Pipelines: crude oil 2,240 km (2001)
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Luebeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 388 ships (1 ,000 GRT or over) totaling
5,758,942 GRT77. 1 32,525 DWT
ships by type: cargo 132, chemical tanker 10,
container 219, liquefied gas 3, passenger 3,
petroleum tanker 7, railcar carrier 2, refrigerated cargo
1, roll on/roll off 4, short-sea passenger 7
nofe: includes some foreign-owned ships registered*
here as a flag of convenience: Chile 1 , Finland 5,
Iceland 1, Netherlands 3, Switzerland 1 (2002 est.)
Airports: 625(2001)
Airports - with paved runways:
total: 325
over 3,047 m;11
2,438 to 3,047m: 55
1,524 to 2,437 m: 65
914 to 1,523 m: 67
under 914 m: 127 (2001)
Airports - with unpaved runways:
tofa/:''300
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 51
under 914 m:238 (2001)
Heliports: 59(2001)
Railways:
total: 953 km
narrow gauge: 953 km 1.067-m gauge; undergoing
major rehabilitation (2001 est.)
Highways:
total: 38,940 km
paved: 9,346 km (including 30 km of expressways)
unpaved: 29,594 km (2001)
Waterways: 1,293 km
note: Volta, Ankobra, andTano Rivers provide 1 68 km
of perennial navigation for launches and lighters; Lake
Volta provides 1,125 km of arterial and feeder
waterways
Pipelines: Okm
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 16,450
GRT/22.097DWT
ships by type: petroleum tanker 2, refrigerated
cargo 5
note: includes some foreign-owned ships registered
here as a flag of convenience: Brazil 1 , Saint Vincent
and the Grenadines 1 , Spain 1 (2002 est.)
Airports: 12(2001)
Airports - with paved runways:
total: 7
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
974 fo 7,523 m: 2 (2001)
Airports - with unpaved runways:
/ofa/;5
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m:2 (2m)','41ac71d762ca94d30c296e390f08ccf85cb702e53605d4fe7570bc4f0d5523f0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('552916e67d5549061af6ee3e65529c8fc247ab0bbf7255f483f9529446602947',2002,'GR','Greece','transportation',528,'Railways:
total: 2,571 km
standard gauge: 1 ,565 km 1 .435-m gauge (36 km
electrified)
narrow gauge: 961 km 1 .000-m gauge; 22 km
0.750-m gauge (a rack-type railway for steep grades)
dual gauge: 23 km combined 1. 435-m and 1. 000-m
gauges (three rail system) (2001 est,)
Highways:
total: 117,000 km
paved: 107,406 km (including 470 km of
expressways)
unpaved: 9,594 km (1996)
Waterways: 60 km
note: system consists of three coastal canals
including the Corinth Canal (6 km) which crosses the
Isthmus of Corinth connecting the Gulf of Corinth with
the Saronic Gulf and shortens the sea voyage from
the Adriatic to Peiraiefs (Piraeus) by 325 km; there are
also three unconnected rivers
Pipelines: crude oil 26 km; petroleum products
547 km
Ports and harbors: Afexandroupofis, Elefsis,
Irakieion (Crete), Kavala, Kerkyra, Chalkis,
Igoumenitsa, Lavrion, Patrai, Peiraiefs (Piraeus),
Thessaloniki, Volos
Merchant marine:
total: 802 ships (1 ,000 GRT or over) totaling
27,998,523 GRT/49,458,125 DWT
ships by type: bulk 294, cargo 54, chemical tanker 25,
combination bulk 7, combination ore/oil 5,
container 45, liquefied gas 7, multi-functional
large-load carrier 1, passenger 13, petroleum
tanker 265, refrigerated cargo 3, roll on/roll off 23,
short-sea passenger 54, specialized tanker 4, vehicle
carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Ireland 1 , Japan 1 ,
Liberia 1, Norway 1, Panama 2, Russia 1, Saudi
Arabia 1 , United Kingdom 1 (2002 est,)
Airports: 79 (note - new Athens airport at Spafa
opened in March 2001) (2001)
Airports - with paved runways:
total: 65
over 3,047 m: 6
2,438 to 3,047 m: 15
1,524 to 2,437 m: 19
914 to 1,523 m:W
under 914 m: 9 (2001)
Airports - with unpaved runways:
total: 14
914 to 1,523 m: 4
under 914 m: 10 (2001)
Heliports: 4(2001)','c0b454a65642b603ea5be584ca3fba2fa9cdf542fd9169340dadb064f38251b8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0328f5d2c66ffa78ab8db5a2438df2c4139bf182192c767fcd52c18bbbd833a',2002,'GL','Greenland','transportation',537,'Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved:% km
Waterways: none
Ports and harbors: Aasiaat (Egedesminde),
llulissat (Jakobshavn), Kangerlussuaq, Nanortalik,
Narsarsuaq, Nuuk (Godthab), Qaqortoq (Julianehab),
Sisimiut (Holsteinsborg), Tasiilaq (March 2001)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,289 GRT/
1,500 DWT
ships by type: cargo 1 , passenger 1, includes a
foreign-owned ship registered here as a flag of
convenience: Denmark 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 9
over 3,047 m;1
2,438 to 3,047 m: 1
1524 to 2,437 m:1
914 to 1,523 m;1
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 6
1t524 to 2,437 m:1
914 to 1,523 m:3
under 914 m: 2 (2001)','d312cb3de5bc21e1f31d42baa10ff0a42c5809b88b1ddb04fe19d76b3b5ec8fd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa5fe332d6d3a4db18e395123f88422016a0bb72a6760b2f0830f827bd8b814f',2002,'GD','Grenada','transportation',545,'Railways: 0 km
Highways:
total: 1,040 km
paved: 638 km
unpaved; 402 km (1996)
Waterways: none
Ports and harbors: Grenville, Saint George''s
Merchant marine: none (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 mA
1,524 to 2,437 mA
under 914 mA (2001)','462999206cdd17578c404497b56b6c34c192d3fb4cf4f86e05c3da82563b7018','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13f9d931bf6e4966949b5305ec177f85db0ede0425aea388bc3fdac6fc809169',2002,'GU','Guam','transportation',556,'Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaveof:210km
note: there are also 685 km of roads classified
non-public, including roads located on federal
government installations
Waterways: none
Ports and harbors: Apra Harbor
Merchant marine: none (2002 est.)
Airports: 5(2001)
Airports • with paved runways:
total: 4
over 3,047 m:2
2,438 to 3,047 m:1
914 to 1f523 m: 1 (2001)
Airports - with unpaved runways:
totals
under 914 m;1 (2001)
Railways:
total; m km
narrow gauge: 884 km 0.914-m gauge (single-track)
note: much of the railway is inoperable (2001 est.)
Highways:
total: 13,856 km
paved: 4,370 km (including 140 km of expressways)
unpaved: 9,486 km (1998)
Waterways: 990 km
note: 260 km navigable year round; additional 730 km
navigable during highwater season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none (2002 est.)
Airports: 475(2001)
Airports - with paved runways:
total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 464
2,438 to 3,047 m:]
1,524 to 2,437 m: 9
914 to 1,523 m:m
under 914 m:331 (2001)','1f69f7dea90a3534b26a060e63070ea24e90bf6e3c1469cb34cee8198c6d343c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2d44acb6bd9b3954318cfab7c2aa56b8fab82cb5f6cbecd55881e110fb73e5',2002,'GG','Guernsey','transportation',565,'Railways: 5 km
Highways:
tofa/.NAkm
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: St. Peter Port, Saint Sampson
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
914 to 1 ,523 m;1
under 914 m: 1 (2001)
Railways:
total: 1,086 km
standard gauge: 279 km 1.435-m gauge
narrow gauge: 807 km 1,000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry) (2000 est.)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved. 25,467 km (1996)
Waterways: 1 ,295 km (navigable by shallow-draft
native craft)
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
tofa/:5
over 3,047 m:1
2,438 to 3,047 m''A
1,524 to 2,437 m: 3 (2001)
Airports - with unpaved runways:
foteMO
1,524 to 2,437 m:6
914 to 1,523 m: 3
under $14 m: 1 (2001)','3b6fa82466a9afb4263a162681bb3664451a886a6c9a0bfbcd8c39c44d619e8d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('750d05d13f62c4f2c80f82cacb784664cde6443840e51714fe4e38e15401c86d',2002,'GY','Guyana','transportation',574,'Railways:
total: 187 km
standard gauge: 139 km 1 .435-m gauge
narrow gauge: 48 km 0.91 4-m gauge
note: all dedicated to ore transport (2001 est.)
Highways:
fofa/; 7,970 km
paved: 590 km
unpaved: 7,380 km (1996)
Waterways: 5,900 km (total length of navigable
waterways)
nofe: Berbice, Demerara, and Essequibo rivers are
navigable by oceangoing vessels for 150 km, 100 km,
and 80 km, respectively
Ports and harbors; Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total 2 ships (1 ,000 GRT or over) totaling 2,929 GRT/
4,507 DWT
ships by type: cargo 2 (2002 est.)
Airports: 51 (2001)
Airports * with paved runways:
totals
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m: 3 (2001)
224
Guyana (continued)
Airports - with unpaved runways:
total: AS
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m;36 (2001)
Railways:
fofa/:166 km (single-track)
standard gauge: 80 km 1.435-m gauge
narrow gauge: 86 km 1 .000-m gauge
note: Suriname railroads are not in operation (2001)
Highways:
total: 4,530 km
paved: 1,178 km
unpaved: 3,352 km (1996)
Waterways: 1,200 km
nofe: most important means of transport; oceangoing
vessels with drafts ranging up to 7 m can navigate
many of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie,
Paramaribo, Paranam, Wageningen
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 3,432 GRT/
4,525 DWT
ships by type: cargo 1 , container 1 , petroleum tanker
1 (2002 est.)
Airports: 46(2001)
Airports - with paved runways:
total: 5
over 3,047 m:]
914 to 1,523 m:1
under 914 m: 4 (2001)
Airports - with unpaved runways:
totai:41
1,524 to 2,437 m:]
914 to 1,523 m:5
under 914 m:35 (2001)
Railways: 0 km
Highways:
fofa/:NAkm
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
tofaM
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
total: 3
under 914 m: 3 (20M)','f42bde905ceffd4a1d37954e70dd312f9e75c22b573c2e1db8b0ba234f1d8e30','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96cc78c16a3c381b07205bb3fe851f373d17572c9fae54e35522d21fb81e1258',2002,'HT','Haiti','transportation',584,'Railways:
tofa/:40km
narrow gauge: 40 km 0.760-m gauge; single-track
note: privately owned industrial line; closed in early
1990s (2001 est.)
Highways:
total: 4,160 km
paved: 1,011 km
unpaved:3M$ km (1996)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, LesCayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none (2002 est.)
Airports: 12(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m: 1(2001)
Airports - with unpaved runways:
total: 10
914to1t523m:4
under 914 m; 6 (2001)','cab027f5dfd640248776dde5310eccfdcf0cf6f1546bf7b070c1356221519fd2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff0c0a7b2066c0669df7b97cd2eaec444d3cc003bec294726d2af0a45c4b1ec7',2002,'IS','Iceland','transportation',599,'Railways: Okm
Highways:
total: 12,691 km
paved: 3,262 km
unpa ved: 9,429 km (1999)
Waterways: none
Ports and harbors: Akureyri, Hornafjordhur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vesttmannaeyjar
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1,816 GRT/
2,500 DWT
ships by type: chemical tanker 1 (2002 est.)
Airports: 86(2001)
Airports - with paved runways:
total: 13
over 3,047 m;1
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2001)
Airports - with unpaved runways:
total: 73
1,524 to 2,437 m: 3
914 to 1,523 m: 21
wafer Sf4/n:49(2001)
239
Iceland (continued)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports • with unpaved runways:
total: 1
1,524 to 2,437 m-A {2m)','829b2b9f2b4207fcd058f34d5e634b4b3c53c7fc2302c8e36597d65a9d7b78bd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe8081f7263115776e3bc61ce52a0fa4166f353bfd901c05146d9603e0067e15',2002,'IN','India','transportation',607,'Railways:
total: 63,693 km (13,771 km electrified)
broad gauge: 45,103 km 1 .676-m gauge
narrow gauge: 15,178 km 1 .000-m gauge; 3,105 km
0.762-m gauge; 307 km 0.610-m gauge (2001)
Highways:
total: 3,31 9,644 km
paved: 1,517,077 km
wpaved: 1 ,802,567 km (1996)
Waterways: 16,180 km
nofe: 3,631 km navigable by large vessels
Pipelines: crude oil 3,005 km; petroleum products
2,687 km; natural gas 1,700 km (1995)
Ports and harbors: Chennai (Madras), Cochin,
Jawaharal Nehru, Kandla, Kolkata (Calcutta), Mumbai
(Bombay), Vishakhapatnam
Merchant marine:
total: 319 ships (1 ,000 GRT or over) totaling
6,325,284 GRT/1 0,581 ,459 DWT
ships by type: bulk 1 1 5, cargo 80, chemical tanker 1 6,
combination bulk 1, combination ore/oil 3,
container 13, liquefied gas 9, passenger/cargo 5,
petroleum tanker 74, short-sea passenger 2,
specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: China 1, United Arab
Emirates 10, United Kingdom 1 (2002 est.)
Airports: 335(2001)
Airports - with paved runways:
fofa/:234
over 3, 047 m: 14
2,438 to 3,047 m: 48
1,524 to 2,437 m: 80
914 to 1,523 m:7S
under 914 m''A7 (2m)
Airports - with unpaved runways:
tofa/:101
2,438 to 3,047 m:1
1,524 to 2,437 m:7
914 to 1,523 m:41
under 914 m: 52 (2001)
Heliports: 18(2001)
Ports and harbors: Chennai (Madras; India),
Colombo (Sri Lanka), Durban (South Africa), Jakarta
(Indonesia), Kolkata (Calcutta; India) Melbourne
(Australia), Mumbai (Bombay; India), Richards Bay
(South Africa)','641b1188ddd674bae452bf3c63ee8eb604e84a29bade27d7d71820badc61dfd9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62430d8e872ffb6812f5c234f126bd8929ea2262e15650dc3e8b10593254c34',2002,'IE','Ireland','transportation',616,'Railways:
total: 3,314 km
broad gauge: 1,949 km 1.600-m gauge (38 km
electrified; 485 km double-tracked)
narrow gauge: 1 ,365 km 0.914-m gauge (operated by
the Irish Peat Board to transport peat to power
stations and briqueting plants) (2001)
Highways:
total: 92,500 km
paved: 87,043 km (including 115 km of expressways)
unpaved: 5,457 km (1999 est.)
Waterways: 700 km (limited facilities for commercial
traffic) (1998)
Pipelines: natural gas 7,592 km (transmission 1 ,1 58
km; distribution 6,434 km) (2000)
253
Ireland (continued)
Ports and harbors: Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
Merchant marine:
Jo/a/: 26 ships (1 ,000 GRT or over) totaling 110,741
GRT/1 27,342 DWT
ships by type: bulk 4, cargo 20, container 1 , short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 2 (2002 est.)
Airports: 41 (2001)
Airports - with paved runways:
tote/: 17
over 3,047 mA
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m:l{im)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 2
under 914 m:22 (2001) .','32138aca9dd3898fae5d975de76755bfe83dccbbe2d39975074b38635bc532ad','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab16f75ac9dc269fadbce30c84b0c37595a200df9c6cfa27826fffbe0ff184be',2002,'TN','Tunisia','transportation',626,'Railways:
total: 19,786 km
standard gauge: 18,761 km 1.435-m gauge (11,251
km electrified)
narrow gauge: 113 km 1.000-m gauge (113 km
electrified); 912 km 0.950-m gauge (192 km
electrified) (2001)
Highways:
total: 668,669 km
paved: 668,669 km (including 6,460 km of
expressways)
unpaved: Okm (2001)
Waterways: 2,400 km
note: serves various types of commercial traffic,
although of limited overall value (2002)
Pipelines: crude oil 1 ,703 km; petroleum products
2,148 km; natural gas 19,400 km
Ports and harbors: Augusta (Sicily), Bagnoli, Ban,
Brindisi, Gela, Genoa, La Spezia, Livorno, Milazzo,
Naples, Porto Foxi, Porto Torres (Sardinia), Salerno,
Savona, Taranto, Trieste, Venice (2001)
Merchant marine:
total: 467 ships (1 ,000 GRT or over) totaling
8,499,248 GRT/1 0,383,988 DWT
ships by type: bulk 45, cargo 41 , chemical tanker 91 ,
combination ore/oil 4, container 24, liquefied gas 37,
multi-functional large-load carrier 1 , passenger 15,
petroleum tanker 80, refrigerated cargo 4, roll on/roll
off 70, short-sea passenger 27, specialized tanker 12,
vehicle carrier 16
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 1 , Denmark 4,
France 1 , Greece 3, Man, Isle of 1 , Monaco 7,
Netherlands 6, Norway 1, Panama 2, Spain 1,
Switzerland 1, Taiwan 15, Turkey 1, United Kingdom
6, United States 12 (2002 est.)
Airports: 135(2001)
Airports - with paved runways:
tofa/:97
over 3,047 m: 5
2,438 to 3,047 m: 33
1,524 to 2,437 m:17
914 to 1,523 m: 30
under 914 m: -12(2001)
Airports - with unpaved runways:
total: 38
1,524 to 2,437 m: 2
914 to 1,523 m: 18
under 914 m:\\%(im)
Heliports: 4(2001)
Railways:
fofa/:2t168km
standard gauge: 471 km 1 .435-m gauge
narrow gauge: 1 ,687 km 1 .000-m gauge
dual gauge: 10 km 1 .000-m and 1 .435-m gauges
(three rails) (2001)
Highways:
tofa/: 23,1 00 km
pa ved: 18,226 km
unpavecf:4,874km(1996)
Waterways: none
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 16 ships (1 ,000 GRT or over) totaling 150,710
GRT/162,616DWT
ships by type: bulk 2, cargo 4, chemical tanker 4,
liquefied gas 1 , petroleum tanker 1 , short-sea
passenger 3, specialized tanker 1 (2002 est.)
Airports: 30(2001)
518
Tunisia (continued)
Turkey
Airports - with paved runways:
total: U
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1523 m: 3 (2001)
Airports - with un paved runways:
fcfa/:16
1,524 to 2,437 m: 2
914 to 1,523 m:7
under 914 m: 7 (2001)
Railways:
total: 8,607 km
standard gauge: 8,607 km 1.435-m gauge (2,131 km
electrified) (2001)
Highways:
total: 382,059 km
paved: 106,976 km (including 1 ,726 km of
expressways)
unpaved: 275,083 km (1999 est.)
Waterways: 1,200 km (approximately)
Pipelines: crude oil 1,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Ice! (Mersin), Samsun,
Trabzon
Merchant marine:
total: 553 ships (1 ,000 GRT or over) totaling
5,674,099 GRT/9, 108,81 9 DWT
ships by type: bulk 138, cargo 239, chemical
tanker 45, combination bulk 5, combination ore/oil 2,
container 27, liquefied gas 6, passenger/cargo 1,
petroleum tanker 45, refrigerated cargo 3, roll on/roli
off 27, short-sea passenger 10, specialized tanker 5
rjofe: includes some foreign-owned ships registered
here as a flag of convenience: Belize 1 , Cyprus 1 ,
Denmark 2, Greece 1 , Italy 1 , Thailand 1 , United
Kingdom 11 (2002 est.)
Airports: 120(2001)
Airports - with paved runways:
total: m
over 3,047 m: 16
2,438 to 3,047 m: 30
1,524 to 2,437 m:W
914 to 1,523 m: 15
under 914 m: 6 (2001)
Airports - with unpaved runways:
tofa/:34
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m;8
under 91 4 m: 24 (2001)
Heliports: 6(2001)','54a10af118bde82918856983b5bd6c24a9033771591f7ea44f2f4ada40f6d4c9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c416e8836d992991ff7d268b454db21aab180abff53bc6f6a0c62e8d3d01341',2002,'JM','Jamaica','transportation',636,'Railways:
total: 272 km
standard gauge: 272 km 1.435-m gauge; note - 207
km, belonging to the Jamaica Railway Corporation,
were in common carrier service but are no longer
operational; the remaining track is privately owned
and used to transport bauxite (2000)
Highways:
total: 19,000 km
paved: 13,433 km
unpaved: 5,567 km (1997)
Waterways: none
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rtos, Port Antonio,
Rocky Point, Port Esquivel (Longswharf)
Merchant marine:
total: 1 ships (1,000 GRT or over) totaling 21,954
GRT/25,250 DWT
ships by type: petroleum tanker 1 , includes some
foreign-owned ships registered here as a flag of
convenience: Latvia 2, United States 2 (2002 est.)
Airports: 35(2001)
Airports - with paved runways:
tofa/:11
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m;3
under 914 m: 5 (2XM)
Airports - with unpaved runways:
tofa/:24
914to1f523m:2
under 914 m:22 (2001)','285ef9ccd2a1f64958ea89769c8ac06f941425f78e679ba51fff26a5fc6374cf','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80beca88adac7c068443fab64ed331f294003bee0be7dfb483642b0f96fa6a4f',2002,'NO','Norway','transportation',644,'Railways:
total: 23,654 km (15,895 km electrified)
standard gauge: 3,059 km 1 ,435-m gauge (entirely
electrified)
narrow gauge: 77 km 1 .372-m gauge (entirely
electrified): 20,491 km 1 ,067-m gauge (12,732 km
electrified); 27 km 0.762-m gauge (entirely electrified)
(2000)
Highways:
total: 1,1 52,207 km
paved: 863,003 km (including 6,1 1 4 km of
expressways)
unpaved: 289,204 km (1997 est.)
Waterways: 1 ,770 km approximately
note: seagoing craft ply all coastal inland seas
Pipelines: crude oil 84 km; petroleum products 322
km; natural gas 1,800 km
Ports and harbors: Akita, Amagasaki, Chiba,
Hachinohe, Hakodate, Higashi-Harima, Himeji,
Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide,
Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 61 5 ships (1 ,000 GRT or over) totaling
10,995,839 GRT/14,405,159 DWT
ships by type: bulk 1 33, cargo 48, chemical tanker 1 7,
combination bulk 24, combination ore/oil 3, container
1 9, liquefied gas 50, passenger 9, passenger/cargo 2,
petroleum tanker 189, refrigerated cargo 13, roll on/
roll off 48, short-sea passenger 6, vehicle carrier 54
note: includes some foreign-owned ships registered
here as a flag of convenience: China 1 , Panama 1,
Singapore 1 (2002 est.)
Airports: 173(2001)
Airports - with paved runways:
fate/; 142
over 3,047 m:!
2,438 to 3,047 m:37
1,524 to 2,437 m: 37
914 to 1,523 m: 30
under 914 m: 31 (2001)
Airports - with unpaved runways:
totals
1,524 to 2,437 m''A
914to1,523m:$
under 914 m: 27(2001)
Heliports: 16(2001)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area in the
middle of the west coast and another near the
southwest corner of the island
Transportation - note: there is a day beacon near
the middle of the west coast','f5a33fe424b1bbb876c6aaa31d9a61de98cadabb057e46ddea0fc0251b642ee3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65e28fcedf8c4cade7787b03376e5d5135f73f0264f08a0bcdc73d4129709722',2002,'MH','Marshall Islands','transportation',651,'Waterways: none
Ports and harbors: Johnston Island
Airports: 1 (2001)
Airports - with paved runways:
total: l
2,438 to 3,047 m: 1 (2001)
Railways: 0 km
Highways:
total: NAkm
paved: 64.5 km
unpaved:Uk km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks (2002)
Waterways: none
Ports and harbors: Majuro
Merchant marine:
total: 270 ships (1 ,000 GRT or over) totaling
11,807,839 GRT/19,332,014DWT
ships by type: bulk 82, cargo 14, chemical tanker 24,
combination ore/oil 4, container 46, liquefied gas 8,
multi-functional large-load carrier 1, petroleum tanker
88, vehicle carrier 3
note: the ship''s register of the Marshall Islands is a
flag of convenience register since essentially none of
the vessels on it is owned domestically, includes the
following foreign-owned ships registered here as a
flag of convenience: China 1, Cyprus 1, Denmark 9,
Germany 70, Greece 54, Hong Kong 2, Japan 4,
Monaco 8, Netherlands 8, Norway 10, Poland 16,
Singapore 1 , Turkey 6, United Kingdom 3, United
States 87, Uruguay 1 (2002 est.)
Airports: 17(2001)
Airports - with paved runways:
tofaM
1,524 to 2,437 m: 3
914 to 1 (523/n;1 (2001)
Airports - with unpaved runways:
tofa/:13
914 to 1,523 m: 10
under 914 m:Z(2m)','500c79545798cfa3cfb296b72c8f7b1aa0cfa11ef66e81066a265f6ca047b5b7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a14fcf19b1a1b092205fef710c966b3c709a6c307336cfd769af25048b0ffc',2002,'KZ','Kazakhstan','transportation',663,'Railways:
total: 13,601 km in common carrier service; does not
include industrial lines
broad gauge: 13,601 km 1.520-m gauge (3,661 km
electrified) (2001)
Highways:
total: 189,000 km
paved: 108,100 km (includes some all-weather
gravel-surfaced roads)
unpaved: 80,900 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 3,900 km
note: on the Syr Darya (Syrdariya) and Ertis (Irtysh)
rivers
Pipelines: crude oil 2,850 km; refined products 1 ,500
km; natural gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Merchant marine:
mil: 1 ship (1 ,000 GRT or over) totaling 1 ,064 GRT/
646 DWT
ships by type: roll on/roll off 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 449 (2001)
Airports • with paved runways:
total: 28
over 3,047 m: 6
2,438 to 3,047 m:U
1 ,524 to 2,437 m: 5
under 074 m; 3 (2001)
Airports - with unpaved runways:
total: 421
over 3,047 m: 11
2,438 to 3,047 m: 18
1,524 to 2,437 m: 45
914 to 1,523 m: 101
under 914 m;246 (2001)
Railways:
total: 2,778 km
narrow gauge: 2,778 km 1.000-m gauge
note: the line connecting Nairobi with the port of
Mombasa is the most important in the country
Highways:
tote/: 63,800 km
paved: 8,932 km
unpaved: 54,868 km (2001)
Waterways: NA
note: part of the Lake Victoria system is within the
boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,893 GR77
6,320 DWT
ships by type: petroleum tanker 1, roll on/roll off 1
(2002 est.)
Airports: 231 (2001)
Airports - with paved runways:
total: 20
over 3, 047 m: 4
2,438 to 3,047 ''m:1
1,524 to 2,437 m: 3
914 to 1,523 m:H
under 914 m A (2001)
Airports - with unpaved runways:
total: 211
2,438 to 3,047 m:1
1,524 to 2,437 m:14
914 to 7,523 m: 111
under 914 m: 85 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1937 and 1938','c10a54d21def9995c3d6a4077c26da606bcdbc531bf4ebd5595017c67d0b9cc5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f61cc7c5ffbbd8796fd6dbfb82ffa38ea8c28433a37b725a6f671784c2c4d219',2002,'KI','Kiribati','transportation',673,'Railways: 0 km
Highways:
tofa/:670 km
paved: NA km
unpaved: NA km
note: 27 km are paved in South Tarawa (2001)
Waterways: 5 km (small network of canals in Line
Islands)
Ports and harbors: Banaba, Betio, English
Harbour, Kanton
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,291 GRT/
1,295 DWT
ships by type: passenger/cargo 1 (2002 est.)
Airports: 21 (2001)
Airports - with paved runways:
tofeM
7,524 fo 2,437 m: 4 (2001)
Airports - with unpaved runways:
total: 17
914 to 1,523 m:W
under 914 m: 4 (2001)
Railways:
total: 5,000 km
standard gauge: 4 ,095 km 1.435-m gauge (3,500 km
electrified; 159 km double-tracked)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1 .435-m and 1 .600-m gauges
(three rails provide two gauges) (1996)
Highways:
tote/; 31 ,200 km
paved: 1,997 km
unpaved: 29,203 km (1996)
Waterways: 2,253 km
note: mostly navigable by small craft only
Pipelines: crude oil 37 km; petroleum product 1 80 km
Ports and harbors: Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine:
total: 122 ships (1 ,000 GRT or over) totaling 738,886
GRT/1 ,037,506 DWT
ships by type: bulk 4, cargo 1 02, combination bulk 1 ,
mufti-functional large-load carrier 1 , passenger 2,
passenger/cargo 1 , petroleum tanker 6, refrigerated
cargo 3, short-sea passenger 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 , Greece 2,
Pakistan 1 , Singapore 1 (2002 est,)
281
Korea, North (continued)
Airports: 87(2001)
Airports - with paved runways:
total: 39
over 3,047 m:Z
2,438 to 3,047 m: 26
1,524 to 2,437 m;8
914 to 1,523 m:}
under 914 m:] (2001)
Airports - with unpaved runways:
total: 4&
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
5/4 to /,523 m: 13
under 91 4 m: 8 (2001)
Railways:
total: 3,124 km
standard gauge: 3,1 24 km 1.435-m gauge (661 km
electrified) (2000)
Highways:
total: 87,534 km
paved: 65,388 km (including 1 ,996 km of
expressways)
unpaved: 22,146 km (1999)
Waterways: 1,609 km
note: restricted to small native craft
Pipelines: petroleum products 455 km
Ports and harbors: Chinhae, Inch''on, Kunsan,
Masan, Mokp''o, P''ohang, Pusan,Tonghae-hang,
Ulsan, Yosu
Merchant marine:
total: 501 ships (1 ,000 GRT or over) totaling
5,679,171 GRT/9,172,403 DWT
ships by type: bulk 104, cargo 160, chemical tanker
47, combination bulk 6, container 52, liquefied gas 1 6,
multi-functional large-load carrier 1 , passenger 3,
petroleum tanker 73, refrigerated cargo 25, roll on/roll
off 5, short-sea passenger 1 , specialized tanker 3,
vehicle carrier 5, includes some foreign-owned ships
registered here as a flag of convenience: Australia 1 ,
Bulgaria 1 , China 1 , Greece 1 , Japan 1 , Malaysia 1 ,
Norway 1 , Panama 1 , Saint Vincent and the
Grenadines 1, United Kingdom 1 (2002 est.)
Airports: 102(2001)
Airports - with paved runways:
total: 68
over 3,047 m: 2
2,438 to 3,047 m: 19
1,524 to 2,437 m: 16
914 to 1,523 m: 11
under 914 m:20 (2001)
Airports • with unpaved runways:
tofa/:34
914 to 1,523 m: 2
under 914 m:32 (2001)
Heliports: 203(2001)','b48d7a64729508629f9dc957f89c832a31d09ee9af4f25361f0ceee48d737afd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a7f3c37bc734b4e3a7acc93edb4f931f964694a60bab0f54e5d9b94b65d9046',2002,'LV','Latvia','transportation',685,'Railways:
total; 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km
electrified)
narrow gauge: 33 km 0.750-m gauge (2001)
Highways:
total: 59,1 78 km
paved: 22,843 km
unpaved: 36,335 km (1998 est.)
Waterways: 300 km (perennially navigable)
Pipelines: crude oil 750 km; refined products 780
km; natural gas 560 km (1992)
Ports and harbors: Liepaja, Riga, Ventspils
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 30,1 1 9
GRT/30.572DWT
ships by type: cargo 1 , petroleum tanker 1 ,
refrigerated cargo 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 3 (2002 est.)
Airports: 25 (2001)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m:]
914 to 1,523 mA
under 914m: 4 (2001)
Airports - with unpaved runways:
tote/: 12
2,436 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m:2
under 914 m: 7 (2001)
Railways:
tofa/:399 km
standard gauge: 317 km 1 .435-m
narrow gauge: 82 km 1 .050-m
note: entire system is unusable because of damage in
civil war (2001)
Highways:
total: 7,300 km
paved: 6,350 km
unpaved: 950 km (1999 est.)
Waterways: none
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Antilyas, Batroun, Beirut,
Chekka, El Mina, Ez Zahrani, Jbail, Jounie, Naqoura,
Sidon, Tripoli, Tyre
Merchant marine:
total: 67 ships (1 ,000 GRT or over) totaling 320,770
GRT/468,293 DWT
ships by type: bulk 8, cargo 38, chemical tanker 1 ,
combination bulk 1 , container 4, liquefied gas 1 ,
livestock carrier 7, refrigerated cargo 1 , roll on/roll off
3, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: France 1 , Greece 10,
Netherlands 4, Panama 1 , Saint Vincent and the
Grenadines 2, Spain 1, Syria 2 (2002 est.)
Airports: 8(2001)
Airports - with paved runways:
total: 5
over 3,047 mA
2,438 to 3,047 ''m:2
1,524 to 2,437 m:\\
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m:) (2001)','2deac44f81e7db5ce3131cd9260561a831978abdd2c584a568f9884e10f313e4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7b633f20dc26680e3914cb50184fc838ca32576a270dfbf18b09082643455e',2002,'ZA','South Africa','transportation',689,'Railways:
tofa/:2.6 km; note - owned by, operated by, and
included in the statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge (1995)
Highways:
total: 4,955 km
paverf:887km
i/npaved: 4,068 km (1996)
Waterways: none
Ports and harbors: none
Airports: 28 (2001)
Airports - with paved runways:
total: A
over 3,047 m:1
914 to 1,523 m:1
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 4
under 914 m: 20 (2001)
Railways:
to/a/: 490 km (328 km single-track)
standard gauge: 345 km 1 ,435-m gauge
narrow gauge: 145 km 1 .067-m gauge
note: in 1989, Liberia had three rail systems owned
and operated by foreign steel and financial interests in
conjunction with the Liberian Government; one of
these, the Lamco Railroad, closed in 1989 after iron
ore production ceased; the other two were shut down
by the civil war; large sections of the rail lines have
been dismantled; approximately 60 km of railroad
track was exported for scrap (2001 )
Highways:
total: 10,600 km
paveo*:657km
unpaved: 9,943 km
note: there is major deterioration on all highways due
to heavy rains and lack of maintenance (1996 est.)
Waterways: none
Ports and harbors: Buchanan, Greenville, Harper,
Monrovia
Merchant marine:
total: 1 ,513 ships (1,000 GRT or over) totaling
51,912,244 GRT/79,297,046 DWT
ships by type: barge carrier 3, bulk 31 3, cargo 89,
chemical tanker 167, combination bulk 16,
combination ore/oil 32, container 318, liquefied gas
99, multi-functional large-load carrier 4, passenger 23,
petroleum tanker 302, refrigerated cargo 69, roll on/
roll off 20, short-sea passenger 3, specialized tanker
13, vehicle carrier 42
300
Liberia (continued)
note: includes some foreign-owned ships registered
here as a flag of convenience; Argentina 9, Australia
2, Austria 15, Belgium 9, Brazil 5, Canada 4, Cayman
Islands 1 , Chile 7, China 39, Croatia 1 1 , Denmark 4,
Ecuador 1, Estonia 1, Germany 437, Greece 154,
Hong Kong 69, India 5, Indonesia 1 , Israel 1, Italy 5,
Japan 90, Latvia 20, Man, Isle of 5, Monaco 56,
Netherlands 12, New Zealand 1, Nigeria 1f Norway
103, Pakistan 1, Portugal 5, Russia 66, Saudi Arabia
21 , Singapore 20, Slovenia 1 , South Africa 1 , South
Korea 10, Spain 2, Sweden 9, Switzerland 17, Taiwan
29, Turkey 3, Ukraine 4, United Arab Emirates 12,
United Kingdom 39, United States 113, Uruguay 3,
Vietnam 1 (2002 est.)
Airports: 47(2001)
Airports - with paved runways:
total: 2
over 3,047 m:1
f ,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m: A
914 to 1,523 m:6
under 914 m: 35 (2001)
Railways:
note: Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m
standard-gauge line from the Tunisian frontier to
Tripoli and Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been little progress;
other plans made jointly with Egypt would establish a
rail line from As Sallum, Egypt, to Tobruk with
completion originally set for mid-1994; Libya signed
contracts with two private companies - Bahne of
Egypt and Jez Sistemas Ferroviarios of Spain ■ in
1998 for the supply of crossings and pointwork (2001)
Highways:
total: 24,484 km
paved; 6,798 km
unpaved: 17,686 km
note: data for the length of unpaved roads include the
assumption that because they were listed as
secondary roads, they are unpaved; some may be
paved and some part of the primary roads may not be
paved (1996)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1,947 km
Ports and harbors: Al Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 209,000
GRT/278,277 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
gas 3, petroleum tanker 2, roll on/roll off 4, short-sea
passenger 4
note: includes some foreign-owned ships registered
here as a flag of convenience: ^Igeria 1 , Kuwait 1 ,
United Arab Emirates 1 (2002 est.)
Airports: 136(2001)
Airports - with paved runways:
total: 58
over 3, 047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 5
under 914 m: 2 {200])
Airports - with unpaved runways:
total: 7B
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m;14
914 to 1,523 m: 40
under 914 m:\\%{2W\\)
Heliports: 1 (2001)','0802a6d6d2d42e2ec31ca7d20b18bbda3a205ecc74779947f638941e2f7ab99f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568e5c0dcd68908a6d5972bba4425617e90ac8a7b081b6941de659155a28cc1c',2002,'LI','Liechtenstein','transportation',703,'Railways:
total: 18.5 km
standard gauge: 1 8.5 km 1 .435-m gauge (electrified)
note: owned, operated, and included in statistics of
Austrian Federal Railways (2001)
Highways:
tofa/;250 km
pavecf:250 km
unpaved: 0 km
Waterways: none
Ports and harbors: none
Airports: none (2001)','228f8c208e515c026152e315de2cef13961b887f0bf9820330a95d37363cd263','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4922371c26b79ff073ec238e4b110cd637e2f148e57bbd9071318a526f5b4d71',2002,'CH','Switzerland','transportation',708,'Railways:
total: 1,998 km
broad gauge: 1,807 km 1.524-m gauge (122 km
electrified)
standard gauge: 22 km 1.435-m gauge
narrow gauge: 169 km 0.750-m gauge (2001)
Highways:
total: 44,000 km
paved: 35,500 km
unpaved: 8,500 km (2001)
Waterways: 600 km (perennially navigable)
Pipelines: crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Butinge, Kaunas, Klaipeda
Merchant marine:
total: 47 ships (1 ,000 GRT or over) totaling 279,743
GRT/304,156DWT
ships by type: cargo 25, combination bulk 8,
petroleum tanker 2, railcar carrier 1 , refrigerated
cargo 6, roll on/roll off 2, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 3 (2002 est.)
Airports: 72(2001)
Airports - with paved runways:
fofa/:9
over 3,047 m; 2
1,524 to 2,437 m:4
under 914 m: 3 (2001)
Airports - with unpaved runways:
tofa/:63
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 55 (2001)','03253ba09a4596abb19c6e0dd777a442d2888649f17e400cbf02cd3fe20398db','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b02f3df70784a2ae948406f1a055ad59e92a8925d5fa58003aea4d454bdcc4',2002,'DE','Germany','transportation',715,'Railways:
fofa/:274km
standard gauge: 274 km 1 .435-m gauge (242 km
electrified) (2001)
Highways:
total: 5,166 km
paved: 5,166 km (including 118 km of expressways)
unpaved: 0 km (1999)
Waterways: 37 km (on the Moselle)
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 60 ships (1 ,000 GRT or over) totaling 1 ,487,752
GRT/2,123,579DWT
ships by type: bulk 2, chemical tanker 1 3, container 8,
liquefied gas 19, passenger 4, petroleum tanker 8, roll
on/roll off 6
309
Luxembourg (continued)
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 21 , Finland 3,
France 8, Germany 10, Monaco 1, Netherlands 3,
Norway 1, United Kingdom 9, United States 3
(2002 est.)
Airports: 2 (2001)
Airports - with paved runways:
tote/: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
totals
under 914 m: 1 (2001)
Heliports: 1 (2001)','594ab22d353ac27ea46b4b0fa71f752d407f1240465c6377af53dbb6a8d36ceb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15de69114a690b1d43a2f42abe2ffc04aaa576131adf6a552baafd0e8bb91a74',2002,'YT','Mayotte','transportation',725,'Railways:
total: m km
narrow gauge: 893 km 1,000-m gauge (2001)
Highways:
total: 49,837 km
paved: 5,781 km
unpaved: 44,056 km (1 996)
Waterways:
note: of local importance only
Ports and harbors: Antsiranana,
Antsohimbondrona, Mahajanga, Toamasina, Toliara
Merchant marine:
total: 15 ships (1 ,000 GRT or over) totaling 27,199
GRT/37,462 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
gas 1 , petroleum tanker 2, roll on/roll off 2 (2002 est.)
Airports: 130(2001)
Airports - with paved runways:
total: 29
over 3,047 m:1
2,438 to3t047m:2
1,524 to 2,437 m: 4
914 to 1,523 m:20
under 914 m: 2 (2001)
Airports -with unpaved runways:
toteMOl
1,524 to 2,437 m: 2
914 to 1,523 m: 55
under 914 m: 44 (2001)
Railways:
tofa/:797 km
narrow gauge: 797 km 1 .067-m gauge (2001 )
Highways:
total: 14,594 km
paved: 2,773 km
unpaved: 11,821 km (2001)
Waterways: 144 km
note: on Lake Nyasa (Lake Malawi) and Shire Riverall
Ports and harbors: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota, Chiiumba
Airports: 44(2001)
Airports - with paved runways:
total: 6
over 3,047 mA
1,524 to 2,437 mA
914to1,523m:4(2m)
Airports - with unpaved runways:
total: Z%
1,524 to 2,437mA
914 to 1,523 m:U
under 914 m: 23 (2001)','4814ffd8bd38666d606b66d068e81deb38cb88ec055e77d8c5a0780977a8dbf1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b11ff78792065913cbbc9e2671cd581ade12272e1b6c6171546dba03e2491568',2002,'MV','Maldives','transportation',734,'Railways: Okm
Highways:
total: m km
paved: NA km
unpaved: NA km; note - Male has 9.6 km of coral
highways within the city (1988 est.)
Waterways: none
Ports and harbors: Gan, Male
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 51,532
GRT/71,298 DWT
ships by type: cargo 13, short-sea passenger 1
(2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m:1 (2001)
323
Maldives (continued)
Airports - with unpaved runways:
total: Z
914(0 1,52301:3(2001)
Railways:
tofa/;729 km
narrow gauge: 729 km 1.000-m gauge
note: linked to Senegal''s rail system through Kayes
(2001)
Highways:
total: 15,100 km
pa ved: 1,827 km
unpaved: 13,273 km (1996)
Waterways: 1,815 km
Ports and harbors: Koulikoro
Airports: 27(2001)
Airports - with paved runways:
total: 7
2,438 to 3,047 m: 4
1 ,524 to 2,437 m:1
914 to 1,523 /r?: 2 (2001)
Airports - with unpaved runways:
fcfa/;20
1 ,524 to 2,437 m: 4
914 to 1,523 m:7
under 914 m: Q{2001)','88f9863bee2e771bdbe2d16ca8276007a58d70186e815d395e31976fd813896e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f508fb43bb903648b515519d8222a3b0c70ddf88ac05f60b5fe8e5246411d2e',2002,'MT','Malta','transportation',743,'Railways: Okm
Highways:
total: 1,742 km
paved: \\, 677 km
unpaved:GS km (1997)
Waterways: none
Ports and harbors: Marsaxlokk, Valletta
Merchant marine:
total: 1,323 ships (1,000 GRT or over) totaling
27,208,819 GRT/44,617,877 DWT
ships by type: bulk 440, cargo 334, chemical tanker
54, combination bulk 10, combination ore/oi! 12,
container 75, liquefied gas 4, livestock carrier 3,
multi-functionaf large-load carrier 1, passenger 6,
passenger/cargo 1 1 petroleum tanker 270,
refrigerated cargo 39, roll on/roll off 45, short-sea
passenger 9, specialized tanker 3, vehicle carrier 17
nofe: includes some foreign-owned ships registered
here as a flag of convenience: Australia 4, Austria 6,
Bangladesh 1 , Belgium 3, Bulgaria 19, Canada 2,
China 16, Croatia 14, Cuba 1, Cyprus 7, Denmark 3,
Estonia 5, Finland 1 , Germany 54, Greece 627, Hong
Kong 12, Iceland 3, India 10, Iran 2, Israel 26, Italy 36,
Japan 2, Latvia 24, Lebanon 6, Monaco 29,
Netherlands 10, Nigeria 2, Norway 43, Poland 29,
Portugal 2, Romania 15, Russia 85, Saudi Arabia 1,
Slovenia 2, South Korea 5, Spain 1, Switzerland 54,
Syria 4, Turkey 84, Ukraine 25, United Arab
Emirates 3, United Kingdom 4, United States 10
{2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Railways:
total: 68.5 km (43.5 km electrified) (2001)
Highways:
total: 800 km
paved: 800 km
unpavedO km (1999)
Waterways: none
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
Merchant marine:
total: 212 ships (1 ,000 GRT or over) totaling
5,540,100 GRT/9,130,508 DWT
ships by type: bulk 29, cargo 34, chemical tanker 22,
combination bulk 2, container 29, liquefied gas 24,
petroleum tanker 46, roll on/roll off 20, specialized
tanker 1, vehicle carriers
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 45, France 1 ,
Germany 48, Greece 6, Hong Kong 10, Iceland 1,
Italy 8, Monaco 7, Netherlands 3, Norway 5,
Sweden 4, Switzerland 2, United Kingdom 70, United
States 1 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1524 to 2,437 m: 1 (2001)','b9542221b10f5985a34e6aa30889ad9e420dd70fb655dd761ca96556651fcc66','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80847ea66ef8b9c378e206e36a664466b30a0b0ab75a1feaba92ae0e6ab8c152',2002,'MR','Mauritania','transportation',756,'Railways: 704 km
standard gauge: 704 km 1.435-m gauge
note: owned and operated by government mining
company (2001)
Highways:
total: 7,720 km
paved: 830 km
unpaved: 6,890 km (2000)
Waterways:
note: ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none (2002 est.)
Airports: 26(2001)
Airports - with paved runways:
totals
2,438 to 3,047 m:Z
1,524 to 2,437 m: 6 (2001)
Airports - with unpaved runways:
total: U
2,438 to 3,047 m: 2
1,524 to 2,437m: 5
914 to 1,523 m:7
under 914 m: 3 (2001)','2ba04212f36cd9dc08e84e9d7e4b51ecfe074d6ee78b6b681445d3b481cf5095','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ceb89fc7aa748945734c186849cb1184e548f92aacd0a49c23dd1cb54b32c8f',2002,'MU','Mauritius','transportation',766,'Railways: 0 km (2002)
Highways:
total: 1,860 km
paved: 1,786 km (including 36 km of expressways)
unpaved:lA km (2001)
Waterways: none
Ports and harbors: Port Louis
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 66,004
GRT/90,017 DWT
ships by type: cargo 2, combination bulk 2, container
2, refrigerated cargo 2
note: includes some foreign-owned ships registered
here as a flag of convenience:, Belgium 1 , India 3,
Norway 1, Switzerland 2 (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 2
over 3,047 m:i
9Mfof.523m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m: 2 [200])','e20eb10ea4bd73c1a805216040d981efdac8632c38ffc6175edf0207be84f2bc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07fd0d0afb2586aaa4dae8045164842a4d0c52591f4385239b3c813ea5183e0a',2002,'MX','Mexico','transportation',769,'Railways: 0 km (2002)
Highways:
total: M km
paved: 72 km
unpaved: 21 km
Waterways: none
Ports and harbors: Dzaoudzi
Merchant marine: none (2002 est)
Airports: 1 (2001)
Airports - with paved runways:
total:)
1,524 to 2,437 m: 1(2001)
Railways:
total: 18,000 km
standard gauge: 18,000 km 1.435*m gauge (2001)
Highways:
total: 323,977 km
paved: 96,221 km (including 6,335 km of
expressways)
unpa^erf: 227,756 km (1997)
Waterways: 2,900 km
note: navigable rivers and coastal canals
Pipelines : crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km
Ports and harbors: Acapulco, Altamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tamptco, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 44 ships (1,000 GRT or over) totaling 656,594
GRT/987,822 DWT
ships by type: bulk 3, cargo 1 , chemical tanker 4,
liquefied gas 3, petroleum tanker 27, roll on/roll off 3,
short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Canada 2, Denmark 1
(2002 est.)
Airports: 1,852(2001)
Airports - with paved runways:
tofaf:235
over 3,047 m: 11
2,438 to 3, 047 m: 28
1,524 to 2.437 m: 85
914 to 1,523 m: 86
untferSMm: 25 (2001)
Airports - with unpaved runways:
total: 1,617
over 3,047 m; ]
2,438 to 3,047 m:1
1,524 to 2,437 m: 69
914 to 1,523 m: 461
under 91 4 m: 1,085 (2001)
Heliports: 2 (2001)
342
Mexico (continued)
Railways:
total: 23,420 km
broad gauge: 646 km 1.524-m gauge
standard gauge: 21 ,639 km 1 ,435-m gauge (1 1 ,626
km electrified; 8,978 km double-tracked)
narrow gauge: 1 ,135 km various gauges including
1.000-m, 0.785-m( 0.750-m, and 0.600-m (2001)
Highways:
fofa/:381,046km
paved: 249,966''km (including 268 km of
expressways)
unpaved: 131 ,080 km (1998)
Waterways: 3,812 km (navigable rivers and canals)
(1996)
Pipelines: crude oil and petroleum products 2,280
km; natural gas 17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Gliwice,
Kolobrzeg, Szczecin, Swinoujscie, Ustka, Warsaw,
Wroclaw
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 382,518
GRT/641.657DWT
ships by type: bulk 14, cargo 3, chemical tanker 1 , roll
on/roll off 1 (2002 est.)
Airports: 122(2001)
418
Poland (continued)
Airports - with paved runways:
tote/; 83
over 3,047 m;3
2,438 to 3,04? ''m:29
1,524 to 2,437 m: 42
0Mto W23m:6
under 014 m: 3 (2001)
Airports - with unpaved runways:
tofa/:39
2,438 to 3,047 m:1
7,524 to 2,437 m: 4
914 to 1,523 m: 13
i/nrferPM m;21 (2001)
Heliports: 3(2001)','34876f7976a905616f4ed53fbe29adf873e708903d4efead8152f2ba3994988a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff0bd392e5993cea80e3e416d79ba6a97576daf0530c87313e7866a0683b94d4',2002,'FM','Micronesia, Federated States of','transportation',776,'(continued)
Airports ■ with unpaved runways:
total: 1
914 to 1,523 m;1 (2001)
Highways:
tofa/;NAkm
paved: NA km
unpaved: NA km
Waterways: none
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3(2001)
Airports - with paved runways:
total: 2
1t524 to 2,437m: 2 (2001)
Airports - with unpaved runways:
total: \\
914 to 1,523 m: 1 (2001)
345
Midway Islands (continued)','e621b94f271ab475025c9cbc601d01d9a3367d878dad75c4316db8c71d8a1216','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64def0058194466b7c6616b64648d7474be980204594e7965efe20a69e7f0091',2002,'UA','Ukraine','transportation',792,'Railways:
total: 1,328 km
broad gauge: 1 ,328 km 1 .520-m gauge (2001)
Highways:
ml: 20,000 km
paved: 13,900 km (includes some alf-weather
gravel-surfaced roads)
unpaved: 6,100 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 30(2001)
Airports - with paved runways:
total: 7
over 3,047 mA
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
under 914 mA (2001)
Airports - with unpaved runways:
total: 23
2,438 to 3,047 m: 4
1,524 to 2,437 mA
914 to 1,523 m: 4
under 914 m: 14 (2001)
Railways:
total: 1 1 ,385 km (3,888 km electrified)
standard gauge: 10,898 km 1.435-m gauge
broad gage: 60 km 1.524-m gauge
narrow gauge: 427 km 0.760-m gauge (2001)
Highways:
total: 153,359 km
paved: 103,671 km (including 133 km of
expressways)
unpaved: 49,688 km (1998 est.)
Waterways: 1,724 km(1984)
Pipelines: crude oil 2,800 km; petroleum products
1,429 km; natural gas 6,400 km (1992)
Ports and harbors: Braila, Constanta, Galati,
Mangalia, Sulina, Tulcea
Merchant marine:
total: 70 ships (1 ,000 GRT or over) totaling 561 ,470
GRT/754.836DWT
ships by type: bulk 1 1 , cargo 47, passenger 1 ,
passenger/cargo 1 , petroleum tanker 4, railcar
carrier 2, roll on/roll off 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 1, Italy 5
(2002 est.)
Airports: 61 (2001)
Airports - with paved runways:
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 11 (2001)
Airports - with unpaved runways:
total: 37
1,524 to 2,437 m: 2
914 to 1,523 m:12
under 914 m:23 (2001)
Heliports: 2 (2001)
Railways:
tofe/;87,157km
broad gauge: 86,200 km 1 .520-m gauge (40,300 km
are electrified)
narrow gauge: 957 km 1.067-m gauge (installed on
Sakhalin Island)
note: an additional 63,000 km of broad gauge routes
serve specific industries and are not available for
common carrier use (2002)
Highways:
total: 952,000 km
433
Russia (continued)
paverf: 752f000 km (including about 336,000 km of
conventionally paved roads, and about 41 6,000 km of
roads with all-weather gravel surfaces)
unpaved: 200,000 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1998)
Waterways: 95,900 km (total routes in general use)
note: routes with navigation guides serving the
Russian River Fleet - 95,900 km; routes with night
navigational aids - 60,400 km; man-made navigable
routes -16,900 km (Jan 1994)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (June 1993 est.)
Ports and harbors: Aleksandrovsk-Sakhalinsky,
Arkhangelsk, Astrakhan'', De-Kastri, Indigirskiy,
Kaliningrad, Kandalaksha, Kazan'', Khabarovsk,
Kholmsk, Krasnoyarsk, Lazarev, Mago, Mezen'',
Moscow, Murmansk, Nakhodka, Nevel''sk,
Novorossiysk, Onega, Petropavtovsk-Kamchatskiy,
Rostov, Shakhtersk, Saint Petersburg, Sochi,
Taganrog, Tuapse, Uglegorsk, Vanino, Vladivostok,
Volgograd, Vosiochnyy, Vyborg
Merchant marine:
total: 888 ships (1 ,000 GRT or over) totaling
4,390,745 GRT/5,357,436 DWT
ships by type: barge carrier 1 , bulk 21 , cargo 556,
chemical tanker 7, combination bulk 21, combination
ore/oil 6, container 29, multi-functional large-load
carrier 1 , passenger 41 , passenger/cargo 3,
petroleum tanker 153, refrigerated cargo 22, roll on/
roll off 20, short-sea passenger 7
note: includes some foreign-owned ships registered
here as a flag of convenience: Belize 1 , Cambodia 1 ,
Cyprus 9, Denmark 1 , Estonia 4, Greece 3, Honduras
1, Latvia 4, Lithuania 3, Moldova 3, Netherlands 1,
South Korea 1 , Turkey 18, Turkmenistan 2, Ukraine
10, United Kingdom 5, United States 1 (2002 est.)
Airports: 2,743(2001)
Airports - with paved runways:
total: m
over 3,047 m:56
2,438 to 3,047 m: 178
■1,524 to 2.437 m; 76
914 to 1,523 m: 69
underm m:92 (2001)
Airports - with unpaved runways:
total: 2,272
over 3,047 m: 28
2,438 to 3,047 m: 118
1,524 to 2,437 m: 204
914 to 1,523 ro;324
under 914 m^,$% (2001)
Railways: 0 km
Highways:
fofaM 2,000 km
paved: 1,000 km
unpaved: 1 1 ,000 km (1997 est.)
Waterways:
note: Lac Kivu navigable by shallow-draft barges and
native craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 8(2001)
Airports • with paved runways:
total: A
over 3,047 m:]
914 to 1,523 m: 2
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: A
914 to 1,523 m:1
wider9Mm:3(2001)
Railways:
total: 22,51 0 km
broad gauge: 21 ffi km 1.524-m gauge (8,927 km
electrified)
standard gauge: 49 km 1 ,435-m gauge
narrow gauge: 510 km 0.750-m gauge
note: these data do not include railroads dedicated to
serving industry and not in common carrier service
(2001)
Highways:
total: 273,700 km
paved: 236,400 km (including 1 ,770 km of
expressways and a substantial amount of all-weather
roads with gravel surfaces)
unpaved: 37,300 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 4,499 km
nofe; 1 ,672 km are on the Pryp''yat'' and Dniester
(Dnister) (1990)
Pipelines: crude oil 4,000 km (1995); petroleum
products 4,500 km (1995); natural gas 34,400 km
(1998)
Ports and harbors: Berdyans''k, Feodosiya,
lllichivs''k, Izmayil, Kerch, Kherson, Kiev (Kyyiv),
Kiliya, Mariupol'', Mykolayiv, Odesa, Reni,
Sevastopol'', Yalta, Yuzhnyy
Merchant marine:
total: 138 ships (1 ,000 GRT or over) totaling 669,303
GRT/707,857 DWT
ships by type: bulk 7, cargo 1 00, container 3, liquefied
gas 2, passenger 11, passenger/cargo 1, petroleum
tanker 12, railcar carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 1, Greece 1,
Panama 1 , Russia 4, Saint Vincent and the
Grenadines 1 (2002 est.)
Airports: 718(2001)
Airports - with paved runways:
total: 114
over 3,047 m: 14
2,438 to 3,047 m;50
1,524 to 2,437 m: 21
914 to 1,523 m:3
under 914 m:2B{m\\)
Airports - with unpaved runways:
fofa/:604
over 3,047 m:W
2,438 to 3,047m: 37
1,524 to 2,437m: 52
914 to 1,523 m: 45
under914m: 457 (2001)','bdffb5d030a77eba47ad23bde12716ea791f017914a235c4dc7b81cb543c4680','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a655a24f0f4c75a52b4a87cad9f70bf7c01653a6223f6d01c247dd2f71e9f0f3',2002,'MC','Monaco','transportation',800,'Railways:
total: M km
standard gauge: 1.7 km 1.435-m gauge (2002)
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Monaco
Merchant marine: none (2002 est.)
Airports: none; linked to airport in Nice, France, by
helicopter service (2001)
Heliports: 1 (shuttle service between the
international airport at Nice, France, and Monaco''s
heliport at Fontvieille) (2001)','462a2a99d17fb1e6fca0a82935df713b99c9e19fc8f7d5e6a6590b95b0b442d0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('376eb8f103573f83efd0da367ecab1cf2715146eeb9a27df8257f82d53649d92',2002,'GI','Gibraltar','transportation',806,'Railways:
fcfaMt907 km
standard gauge: 1 ,907 km 1 .435-m gauge (1 ,003 km
electrified; 540 km double-tracked) (2001)
Highways:
total: 57,847 km
paved: 30,254 km (including 327 km of expressways)
unpaved: 27,593 km (1 998)
Waterways: none
Pipelines: crude oil 362 km; petroleum products
491 km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Melilla
Merchant marine;
total: 41 ships (1 ,000 GRT or over) totaling 227,364
GRT/277,306 DWT
ships by type: cargo 10, chemical tanker 6, container
6, petroleum tanker 2, refrigerated cargo 8, roll on/roll
off 8, short-sea passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Hong Kong
1 , Netherlands 2, Norway 2 (2002 est.)
Airports: 67 (2001)
Airports - with paved runways:
tofa/:26
over 3,047 m: 9
2,438 to 3,047 m: 6
1,524 to 2,437 m: 9
914to1,523m:l
under 914 m:1 (2001)
Airports - with unpaved runways:
fofa/:41
2,438 to 3,047 m:l
1,524 to 2,437 m:W
914 to 1,523 m:W
under 914 m:1 1 (2001)
Heliports: 1 (2001)
Railways:
total: 3,1 31 km
narrow gauge: 2,988 km 1.067-m gauge; 143 km
0.762-m gauge (2001)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,71 5 km (1996)
Waterways: 3,750 km (navigable routes)
Pipelines: crude oil 306 km; petroleum products
289 km
note: not operating
Ports and harbors: Beira, tnhambane, Maputo,
Nacala, Pemba, Quelimane
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 4,125 GRT/
7,024 DWT
ships by type: cargo 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 2
(2002 est.)
Airports: 166(2001)
Airports - with paved runways:
total: 22
over 3,047 m:1
2,43$ to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2001)
Airports - with unpaved runways:
fofaM44
2,438 to 3,047 m;1
1,524 to 2,437 m:16
914 to 1,523 m: 37
under 914 m: 90 {2W)','97ddf1a2995c258d7eabe9df5941e4a2ccc1d6d8cc442d8efd37ef2c950ebe8d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9389bb6dd83f449797180094af87842ba52867e18357df430e5c4789b70797',2002,'BW','Botswana','transportation',819,'Railways:
total: 2,382 km
narrow gauge: 2,382 km 1.067-m gauge (2001)
Highways:
total: 64,800 km
paved: 5,378 km
unpaved: 59,430 km (2001)
Waterways: none
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none (2002 est.)
Airports: 137(2001)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437m: 14
914 to 1,523 m: 4 (2001)
361
Namibia (continued)
Airports - with unpaved runways:
tofa/:115
2,438 to 3,047 m: 2
1,524 to 2,437 m:2\\
914 to 1,523 m;72
under 914 m: 20 (2001)
Unemployment rate: 0%
Budget:
reyent/es: $23.4 million
expenditures: $64.8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, offshore banking,
coconut products
Industrial production growth rate: NA%
Electricity - production: 30 million kWh (2000)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2000)
Electricity • consumption: 27.9 million kWh (2000)
Electricity -exports: 0kWh(2000)
Electricity - imports: 0 kWh (2000)
Agriculture -products: coconuts
Exports: $25.3 million (f.o.b., 1991)
Exports - commodities: phosphates
Exports - partners: NZ, Australia, South Korea, US
(2000)
imports: $21.1 million (c.i.f., 1991)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia, US, UK, Indonesia,
India (2000)
Debt -external: $33.3 mfffion
Economic aid - recipient: $2.25 million from
Australia (FY96/97 est.)
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .9354 (January 2002) 1 .9320 (2001 ), 1 .71 73 (2000),
1.5497 (1999), 1.5888 (1998), 1.3439 (1997)
Fiscal year: 1 July - 30 June
Railways:
total: 5 km
note: gauge unknown; used to haul phosphates from
the center of the island to processing facilities on the
southwest coast (2001)
Highways:
tofa/:30km
paved: 24 km
unpaved: 6 km (1998 est.)
Waterways: none
Ports and harbors: Nauru
Merchant marine: none (2002 est.)
Airports: 1 (2001)
363
Nauru (continued)
Airports - with paved runways:
toteM
1,524 to 2.437 m: 1 (2001)
Waterways: none
Ports and harbors: none: offshore anchorage only
Railways:
tofa/;59 km
narrow gauge: 59 km 0.762*m gauge
note: all in Kosi close to Indian border (2001)
Highways:
total: 13,223 km
paved: 4,073 km
onpaved: 9,150 km (April 1999)
Waterways: none
Ports and harbors: none
Airports: 45 (2001)
Airports - with paved runways:
Ma/; 8
over 3,047 m;1
1,524 to 2,437 m:1
914 to 1523 m: 6 (2001)
Airports • with unpaved runways:
tofa/;37
1,524 to 2t437 m:1
914 to 1,523 m:7
under 914 m: 2d (2001)','06953d7d57344ad8a9f4df60a9d72d727baa2c4b2686f90dd7729ff2e27caff0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe63c25d35052bd2af04f70f37280a8e1cf09818b0864ecc0bf077857015435',2002,'NL','Netherlands','transportation',827,'Railways:
total: 2,808 km
standard gauge: 2,808 km 1.435-m gauge (2,061 km
electrified) (2001)
Highways:
total: 116,500 km
paved: 104,850 km (including 2,235 km of
expressways)
unpaved: 11,650 km (1999)
Waterways: 5,046 km (of which 3,745 km are
canals)
note: 47% of total route length is usable by craft of
1,000-metric-ton capacity or larger
Pipelines: crude oil 418 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, Delfzijl, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht,
Vlissingen
Merchant marine:
total: 622 ships (1 ,000 GRT or over) totaling
4,587,662 GRT/5,251 ,529 DWT
ships by type: bulk 3, cargo 380, chemical tanker 46,
container 64, liquefied gas 16, livestock carrier 2,
multi-functional large-load carrier 15, passenger 9,
petroleum tanker 28, refrigerated cargo 34, roll on/rolf
off 18, short-sea passenger 2, specialized tanker 5
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1 , Canada 1 ,
Denmark 5, Finland 5, Germany 55, Ireland 12,
Norway 12, Sweden 17, United Kingdom 33, United
States 12 (2002 est.)
Airports: 28 (2001)
Airports - with paved runways:
tofa/:20
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m:B
914 to 1,523 m: 4
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: B
914 to 1523 m: 2
under 914 m: 6 (2001)
Heliports: 1 (2001)
Railways: 0 km (2002)
Highways:
tofa/;600 km
paved: 300 km
unpaved: 300 km (1992)
Waterways: none
Ports and harbors: Kralendijk, Philipsburg.
Willemstad
Merchant marine:
total: 123 ships (1 ,000 GRT or over) totaling
1 ,056.362 GRT/1 ,341 ,735 DWT
ships by type: bulk 2, cargo 39, chemical tanker 2,
combination ore/oil 4, container 24, liquefied gas 5,
multi-functional large-load carrier 15, passenger 1 ,
refrigerated cargo 24, roll on/roll off 7
note: includes foreign-owned ships registered here as
a flag of convenience: Belgium 3, Denmark 2,
Germany 43, Monaco 8, Netherlands 52, New
Zealand 1 , Norway 3, Peru 1 , Spain 1 , Sweden 3,
United Kingdom 5 (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 5
over 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m:1
under 914 m: 1 (2001)','7c11c87d62e32ddff536df0062d398bca78ba9d59be8119d310a6a618b189e5c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c3e444dda9d87741fde2ee4d7002abe509ea5c047e47f10d7ed109ff1d336d',2002,'NI','Nicaragua','transportation',836,'Railways:
tofa/:6km
narrow gauge: 6 km 1 .067-m gauge
note: carries mostly passengers from Chichigalpa to
Ingenio San Antonio (2001)
Highways:
total: 16,382 km
paved: 1,818 km
unpaved: 14,564 km (1998)
Waterways: 2,220 km (including 2 large lakes)
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none (2002 est.)
Airports: 182(2001)
Airports - with paved runways:
tote/: 11
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m:3
under 914 m: 3 (20M)
Airports - with unpaved runways:
total: 171
1,524 to 2,437 m:1
914 to 1,523 m: 25
under 914 m: 145 (2001)','6f55643c67de4d4ae7cb865477f159f034a6c5ef4d886ac400afe0f5b935b2be','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba8192165028a0d15fddbc1d620eaa3141de2ac0f9f8e18bfa357742ef52165d',2002,'NE','Niger','transportation',845,'Railways: 0 km (2002)
Highways:
total: 10,100 km
paved: 798 km
unpaved: 9,302 km (1996)
Waterways: 300 km
note: the Niger River is navigable from Niamey to
Gaya on the Benin frontier from mid-December
through March
Ports and harbors: none
Airports: 26(2001)
Airports - with paved runways:
tofa/;9
2,438 to 3,047 m: 2
1,524 to 2,437 m:G
under 914 m:1 (2001)
Airports - with unpaved runways:
totat''M
1,B24to2A37m:\\
914 to 1,523 m;U
under 914 m: 2 (2001)','429240b12acc080d3d9bf8359e3a7cd5a6b0520f625ee835e7318aa5dcfb7c0a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e97237e9dfa319947d9621b436b5ebf3ae9a4a88181c0916abd9c37023d7ae0b',2002,'NF','Norfolk Island','transportation',859,'Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km (2001)
Waterways: none
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)','a88b63e67acfde39011199f664ddc5fd353bd8c53770fafca89ca3aff3d81737','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40604c6545261e848f82c2c70fd41fd68c0232a8356e0614c559d94e52a2a6b2',2002,'MP','Northern Mariana Islands','transportation',863,'Railways: 0 km
Highways:
tofa/; 362 km
paved: NA km
unpavertNA km (1991)
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none (2002 est.)
Airports: 6(2001)
Airports - with paved runways:
tote/: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m:2 (2001)
Airports - with unpaved runways:
total: 3
2,438 to 3,047 m:l
under 914 m: 2 (2001)
Heliports: 1 (2001)
Railways:
total: 4,006 km
standard gauge: 4,006 km 1 ,435-m gauge (2,471 km
electrified) (2001)
Highways:
tote/: 91 ,180 km
paved: 67,838 km (including 109 km of expressways)
unpaved: 23,342 km (1999)
Waterways: 1 ,577 km (along west coast)
note: navigable by 2.4 m maximum draft vessels
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Floro,
Hammerfest, Harstad, Haugesund, Kristiansand,
Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 746 ships (1 ,000 GRT or over) totaling
20,691,266 GRT/32,126,513 DWT
ships by type: bulk 84, cargo 130, chemical tanker
1 19, combination bulk 9, combination ore/oil 38,
container 18, liquefied gas 91 , passenger 6,
petroleum tanker 143, refrigerated cargo 9, roll on/roll
off 41 , short-sea passenger 21 , specialized tanker 2,
vehicle carrier 35
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Denmark
14, Germany 1 1 , Greece 10, Hong Kong 7, Iceland 2,
Japan 11, Lithuania 1 , Monaco 42, Poland 1, Saudi
Arabia 3, Singapore 10, Sweden 42, Switzerland 2,
United Kingdom 4, United States 5 (2002 est.)
Airports: 102(2001)
Airports - with paved runways:
tofa/:67
over 3,047 m:1
2,438 to 3,047 m: 13
1,524to2,437m:K
914 to 1,523 m: 15
under 914 m: 26 (2001)
Airports - with unpaved runways:
fofa/:35
914 to 1 ,523 m:6
i/ncfer0f4m:29(2OO1)
Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22,960 km (1996)
Waterways: none
Pipelines: crude oil 1 ,300 km; natural gas 1 ,030 km
Ports and harbors: Matrah, Mina* al Fahl, Mina''
Raysut
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 17,291
GRT/9.457DWT
ships by type: cargo 1 , passenger 1 ,
passenger/cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Singapore 1 (2002 est.)
Airports: 143(2001)
Airports - with paved runways:
totals
over 3,047 m: 4
2,438 to 3,047 m:1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 137
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 54
914 to 1,523 m:W
under 914 m: 36 (2001)
Heliports: 1 (2001)
Ports and harbors: Bangkok (Thailand), Hong
Kong, Kao-hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)
Transportation - note: Inside Passage offers
protected waters from southeast Alaska to Puget
Sound (Washington state)
Waterways: none
Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (2001)
Airports - with paved runways:
to/a/;1
2,438 to 3,047 m: 1 (2001)
Transportation - note: formerly an important
commercial aviation base, now used by US military,
some commercial cargo planes, and for emergency
landings
557
Wake Island (continued)','d6e43454c0db3dd589822df00c4b2df10215728bad922d0fed839dd21b2ad6c2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f51096213747f67581577d31855aa8628c812f039188d593fd4b3bcde729ab7c',2002,'PK','Pakistan','transportation',875,'Railways:
total: 8,163 km
broad gauge: 7,71 8 km 1.676-m gauge (293 km
electrified)
narrow gauge: 445 km 1 .000-m gauge (2001)
Highways:
total: 247,81 1 km
paved: 141,252 km (including 339 km of
expressways)
unpaved: 106,559 km (1998)
Waterways: none
Pipelines: crude oil 250 km; petroleum products 885
km; natural gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin
Qasim
Merchant marine:
total: 17 ships (1 ,000 GRT or over) totaling 241 ,832
GRT/367,093 DWT
ships by type: cargo 13, container 3, petroleum
tanker 1 (2002 est.)
Airports: 120(2001)
Airports - with paved runways:
total: BS
over 3,047 m:12
2,438 to 3,047 m: 22
1,524 to 2,437 m: 31
914 to 1,523 m;17
under 914 m: 3 (2001)
Airports - with unpaved runways:
tote/; 35
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 18 (2001)
Heliports: 9(2001)','25c962830685ee1b42f40686a53a8a7f79493611e3b0c7b0f91b05aa32d094b4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d246511be38e5a7cd4f284c1de03f38d67fe5ab733c59f9b74f9a31665a004bc',2002,'PW','Palau','transportation',885,'Railways: Okm
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Waterways: none
Ports and harbors: Koror
Merchant marine: none (2002 est.)
Airports: 3 (2001)
Airports - with paved runways:
total:)
1,524 to 2,437 m: 1 (2001)
Airports • with unpaved runways:
total: 2
1,524 to 2,437 m: 2 (2001)
Highways: much of the road and many causeways
built during World War II are unserviceable and
overgrown (2001)
Waterways: none
Ports and harbors: West Lagoon
Airports: 1 (2001)
Airports - with unpaved runways:
tafaM
1,524 to 2,437 m: 1 (2001)','3fb3f542fee1c175c7ee0135a51191b5ade4b5f49a154f300f94a54a65e31f50','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1c94baae4abbafeea96ed08ab01e157a1097b97041820adf36e493aed2857b1',2002,'PH','Philippines','transportation',896,'Waterways: none
Ports and harbors: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 ''m:1 (2001)','b84d6d1493ecaa0e43a70170c587e3d0453560e8a283d1c2966c022a609e9ffb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a9932a481cf7811e4c6c49bc8263db6b93be2805edd21c0a7423cfac82398d8',2002,'AR','Argentina','transportation',901,'Railways:
total: m km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1 ,000-m gauge
nofe: there are 470 km of various gauges that are
privatety owned
Highways:
total: 25,901 km
paved: 3,067 km
unpaved: 22,834 km (2001)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encamacion
Merchant marine:
total: 21 ships (1 ,000 GRT or over) totaling 34,623
GRT/36,821 DWT
ships by type: cargo 1 4, chemical tanker 1 , petroleum
tanker 3, roll on/rol? off 3
note: includes some foreign-owned ships registered
here as a flag of convenience; Argentina 2, Japan 1
(2002 est.)
408
Paraguay (continued)
Airports: 899(2001)
Airports - with paved runways:
total: 11
over 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4 (2001)
Airports - with unpaved runways:
tote/; 888
1524 to 2,437 m: 28
0M to 7,523 m: 332
under 914 m: 528 (2001)
Railways:
total: 2,102 km
standard gauge: 1,695 km 1.435-m gauge
narrow gauge: 407 km 0.91 4-m gauge (2001)
Highways:
total: 72,900 km
paved: 8,700 km
unpaved: 64,200 km (1999 est.)
Waterways: 8,808 km
nofe: 8,600 km of navigable tributaries of Amazon
system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
Ports and harbors: Callao, Chimbote, Ho, Matarani,
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 29,470
GRT/45,451 DWT
ships by type: cargo 4, petroleum tanker 1
nofe: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 239(2001)
Airports - with paved runways:
total: 47
over 3,047 m: 5
2,438 to 3,047 m: 20
1,524 to 2,437 m: 13
914 to 1,523 m:S
under 914 m:1 (2001)
Airports - with unpaved runways:
total: 192
1,524 to 2,437 m: 25
914 to 1,523 m: 65
under 914 m: 102 (2001)
Railways:
total: 897 km
narrow gauge: 897 km 1 .067-m gauge (405 km are
not in operation) (2001)
Highways:
total: 199,950 km
paved: 39,590 km
unpaved: 160,360 km (1998 est.)
Waterways: 3,219 km
note: limited to vessels with a draft of less than 1 .5 m
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, lloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 416 ships (1 ,000 GRT or over) totaling
5,179,029 GRT/7.670,688 DWT
ships by type: bulk 134, cargo 112, chemical tanker 2,
combination bulk 7, container 5, liquefied gas 9,
livestock carrier 9, passenger 4, passenger/cargo 10,
petroleum tanker 41 , refrigerated cargo 20, roll on/roll
off 14, short-sea passenger 29, specialized tanker 2,
vehicle carrier 18
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 2 1 Canada 1,
Germany 3, Greece 8, Hong Kong 13, Japan 47,
Malaysia 19, Netherlands 14, Norway 8, Panama 3,
Singapore 12, South Korea 1, Taiwan 2, United
Kingdom 7 (2002 est.)
Airports: 275(2001)
Airports - with paved runways:
totef:77
over3,047m:4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1523 m: 30
under 914 m: 12 (2001)
Airports - with unpaved runways:
total: m
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 74
under 914 m: 119 (2001)
Heliports: 2(2001)
Railways: 0 km
Highways:
fofa/:6.4km
paved: 0 km
unpaved: 6.4 km
Waterways: none
Ports and harbors: Adamstown (on Bounty Bay)
Merchant marine: none (2002 est)
Airports: none (2001)','453e28d0829e5558af5be4804934fb0af1e6235109254ee2b8074a46aab6127d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4f7e5d8c8f90c491469c4a1a75a6913f5ae4429fc0cfb50574f22c55f90bf8e',2002,'QA','Qatar','transportation',917,'Railways: 0 km
Highways:
total: 1,230 km
paved: 1,107 km
unpaved: 123 km (1996)
Waterways: none
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul island, Umm Said
(Musay''id) ''
Merchant marine:
total: 25 ships (1,000 GRT or over) totaling 679,081
GRT/1,051,088 DWT
ships by type: cargo 10, combination ore/oil 2,
container 7, petroleum tanker 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Kuwait 1, United Arab
Emirates 3 (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
total: 2
over 3,047 m: 2 (2001)
Airports - with unpaved runways:
total: 2
914 to 1,523 m;1
under 914 m:1 (2001)
Heliports: 1 (2001)','dd06dc1b9d1fac9e909397c581ad7cabcf63ef0b0a7b09929a5276821b593d0a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461ef7f53f0b4c639cbed23a8d09ab3a3c5f6e1901eff083dfb0079fd8f9d7f2',2002,'TT','Trinidad and Tobago','transportation',924,'Railways:
total: SB km
narrow gauge: 58 km 0762-m gauge on Saint Kitts to
serve sugarcane plantations (2002)
Highways:
total: m km
paved: km
unpaved: 184 km (2000)
Waterways: none
Ports and harbors: Basseterre, Charlestown
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m;1
914 to 1,523 m: 1 (2001)','dfa15b9004ee2f07edc213972cf4cf38248c75ee1d1330ee7872a29d529e26db','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddab488a3428bf6ff09b385001ef4c60f4aabfa9300136dad0f0607596cfd4c8',2002,'MQ','Martinique','transportation',933,'Railways: Okm
Highways:
total: 1,21 Okm
paved: 63 km
unpaved: 1,147 km (1996)
Waterways: none
Ports and harbors: Castries, Vieux Fort
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
2MB to mi m:\\
1524 to 2,437 m: 1 (2001)
Railways: Okm
Highways:
total: 114 km
paved: 69 km
unpaved:45km (1994 est.)
Waterways: none
Ports and harbors: Saint Pierre
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m: 1 (2001)','97df7d94b2c773f500ba3c50fceb8ff460a928fe565cdaaf51d3c7e1b7d1ceec','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25e790701956291a2ada9b0654f9974264b59f2deb7c0ac362078ca9888cd319',2002,'WS','Samoa','transportation',936,'c
15
30 mi
"Asau -\\
Savaii \\\\ So
>
-''f
i Salelologa, '' / :
Apolima
v " 1 Mulifanua
cifir Orov
APIA*
Syt/f.''5 Pnntir Ocean
-■r,''" ....
Nu''utua
ships by type: barge carrier 1 , bulk 142, cargo 382,
chemical tanker 24, combination bulk 1 1 , combination
ore/oil 3, container 47, liquefied gas 7, livestock
carrier 3t multi-functional large-load carrier 2,
passenger 3, petroleum tanker 48, refrigerated
cargo 39, roll on/roll off 52, short-sea passenger 13,
specialized tanker 1 0, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 1, Anguiila 1,
Argentina 1, Australia 2, Bahamas, The 1,
Bangladesh 1, Barbados 2t Belgium 4, Bulgaria 14,
Canada 1 , Cayman Islands 1 , China 1 35, Colombia 1 ,
Croatia 12, Cyprus 6, Denmark 16, Egypt 7, Estonia 6,
France 27, Germany -12, Greece 156, Guyana 7,
Hong Kong 23, Iceland 1, India 11, Indonesia 3,
Israel 2, Italy 19, Japan 1, Kenya 4, Latvia 5,
Lebanon 9, Liberia 5, Lithuania 1, Malta 1, Man, Isle
of 1, Marshall Islands 3, Mexico 1, Monaco 6,
Netherlands 14, Netherlands Antilles 1, Nigeria 3,
Norway 33, Pakistan 5, Panama 2, Poland 2,
Portugal 2, Puerto Rico 2, Russia 8, Saint Kitts and
Nevis 1, Saudi Arabia 3, Singapore 4, Slovenia 7,
South Korea 4, Spain 1, Sweden 6, Switzerland 10,
Syria 2, Taiwan 1 , Thailand 1 , Trinidad and Tobago 1 ,
Tunisia 1, Turkey 15, Ukraine 8, United Arab
Emirates 45, United Kingdom 16, United States 25,
Vietnam 1 (2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: 5
914to1t523m:4
under 914 m;1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m:) (2001)
Railways: Okm
Highways:
tofa/; 836 km
pavetf 267 km
unpaved: 569 km (1983)
Waterways: none
Ports and harbors: Apia, Asau, Mulifanua,
Salelofoga
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 7,091
GRT/ 8,127 DWT
ships by type: cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Germany 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 mA (2001)','ef16a5f184579a9d2b75c302fef0be176585242cc4b9274e100984df7c8ac272','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('865ae189c83bc677b3c7596bd4808eaffa202c63f287029fb0a10245111b0302',2002,'SN','Senegal','transportation',950,'Railways:
tofa/:906 km
narrow gauge: 906 km 1.000-meter gauge (70 km
double-tracked) (2001)
Highways:
total: 14,576 km
paved: 4,271 km
unpaved: 10,305 km (1996)
Waterways: 897 km
note: 785 km on the Senegal river, and 1 12 km on the
Saloum river
Ports and harbors: Dakar Kaoiack, Matam, Podor,
Richard Toll, Saint-Louis, Ziguinchor
Airports: 20(2001)
Airports - with paved runways:
totals
over 3,047 m:1
1,524 to 2,437 m;6
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: H
1,524 to 2,437 m:6
914 to 1,523 m: 4
under 914 m;1 (2001)','ebe1d21f6af0c8e3add945cb4073dff4334a72e7b54c5934c59810d518dd253f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49f6459f1c50221662b2e085a6c634462b7847282d1c44264e471db705c2bd4f',2002,'SC','Seychelles','transportation',960,'Railways: 0 km
Highways:
tote/: 280 km
paved: 176 km
unpaved: 104 km (1997)
Waterways: none
Ports and harbors: Victoria
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 7,086 GRT/
10,192 DWT
ships by type: cargo 2
note: includes some foreign-owned ships registered
here as a flag of convenience: South Africa 2
(2002 est.)
Airports: 14(2001)
Airports • with paved runways:
total: 7
2,438 to 3,047 m:1
914 to 1,523 m: 4
under 914 m; 2 (2001)
Airports • with unpaved runways:
fofa/:7
914 to 1,523 m: 3
under 91 4 m: 4 (2001)','706ea252616356e9288a0659f756324fec4e776e83bd4c3063adb1bb09d51c40','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1681ba8ae6942a58a3b17e99dd8eb2c4beeda02ba53f1ca79cac31e8b885f86',2002,'SL','Sierra Leone','transportation',969,'Railways:
total: 84 km
narrow gauge: 84 km 1.067-m gauge
note: Sierra Leone has no common carrier railroads;
the existing railroad is private and used on a limited
basis while the mine at Marampa is closed (2001)
Highways:
total: 11,700 km
paved: 936 km
unpaved: 10,764 km (2002)
Waterways: 800 km (of which 600 km navigable year
round)
Ports and harbors: Bonthe, Freetown, Pepel
Airports: 10(2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: $
914 to 1,523 m:7
under 914 m: 2 (2001)
Heliports: 2 (2001)','9747979e3fe8ca5046196b1c19a56c99657dc9cdfe60504884f815582c4f35fb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('916ffacbbabf61be51e188b7834ef5cbda77a9d455ada1416a180f13c1a954a6',2002,'HU','Hungary','transportation',983,'Railways:
total: 3,660 km
broad gauge: 102 km 1.520-m gauge
standard gauge: 3,507 km 1.435-m gauge (1,505 km
electrified; 1,011 km double-tracked)
narrow gauge: 51 km (46 km 1 ,000-m gauge; 5 km
0.750-m gauge) (2001)
Highways:
total: 17,710 km
paved: 17,533 km (including 288 km of expressways)
unpaved: 177 km (1998 est.)
Waterways: 172 km (all on the Danube)
Pipelines: petroleum products NA km; natural gas
2,700 km
Ports and harbors: Bratislava, Komarno
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 15,191
GRT/19,489 DWT
ships by type: cargo 3 (2002 est.)
Airports: 34(2001)
Airports - with paved runways:
total: 17
over3,047m:2
2,438 to 3,047 m: 2
1,524 to 2,437m: 3
914 to 1,523 m:3
under 914 m:7 {200))
Airports - with unpaved runways:
total: 17
2,438 to 3,047 m''A
914 to 1,523 m:9
under 914 m: 7 (2001)
Heliports: 1 (2001)','cb65747c699b08211bf8dd41a2e6a4ad2e16abbd568359a0e3554a5a5d9e7b86','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405bb079e49e050aef12e6e61967def1b5714f55651a434c83eb7a4effbc1ab8',2002,'SB','Solomon Islands','transportation',993,'Railways: 0 km
Highways:
total: 1,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Waterways: none
Ports and harbors: Aola Bay, Honiara, Lofung,
Noro, Vim Harbor, Yandina
Merchant marine: none (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
total: 2
1 ,524 to 2,437 m:1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m: 19 (2001)','1ad564aa4fa57345f274502a359b96f101fefe8936fa74415bbe15cb3ffe63a8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee66cd1929c4daa60a4093a9297482e202014369177224aac059ee1df0284ae6',2002,'SO','Somalia','transportation',1002,'Railways: 0 km
Highways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (1996)
Waterways: none
Pipelines: crude oil 15 km
Ports and harbors: Boosaaso, Berbers, Chisimayu
(Kismaayo), Mercar Mogadishu
Merchant marine; none (2002 est.)
Airports: 54(2001)
Airports - with paved runways:
fofa/:6
over 3, 047 m: 4
1524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
fofaf:48
2,438 to 3,047 m: 3
1,524 to 2,437 m: 15
914 to 1,523 m: 27
under 914 m: 3 (2001)
Railways:
total: 20,384 km
narrow gauge: 20,070 km 1.067-m gauge (9,090 km
electrified); 314 km 0.61 0-m gauge
note: in addition, South Africa has an electrified
1.065-m gauge commuter rail system, with a total
length of 1 ,254 km, which serves
Johannesburg-Pretoria, Cape Town, Durban, East
London, and Port Elizabeth (2001)
Highways:
total: 358,596 km
paved: 59,753 km (including 1 ,927 km of
expressways)
unpaved: 298,843 km (1996)
Waterways: NA
Pipelines: crude oil 931 km; petroleum products
1,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mossel Bay, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 271 ,650
GRT/268,604DWT
ships by type: container 6, petroleum tanker 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 3,
Netherlands 1 (2002 est.)
Airports: 740 (2001)
Airports - with paved runways:
fofa/:144
over 3,047 m: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 47
914 to 1,523 m:72
under 914 m:11 (2001)
Airports - with unpaved runways:
total: $%
1,524 to 2,437 m;34
914 to 1,523 m: 304
under 914 m: 258 (2001)
Waterways: none
Ports and harbors: Grytviken
Airports: none (2001)
Ports and harbors: McMurdo, Palmer, and offshore
anchorages in Antarctica
note: few ports or harbors exist on the southern side
of the Southern Ocean; ice conditions limit use of most
of them to short periods in midsummer; even then
some cannot be entered without icebreaker escort;
most antarctic ports are operated by government
research stations and, except in an emergency, are
not open to commercial or private vessels; vessels in
any port south of 60 degrees south are subject to
inspection by Antarctic Treaty observers (see
Article 7}
Transportation - note: Drake Passage offers
alternative to transit through the Panama Canal','62b6463814c95aeb4d7343a3ad7ba408cef252faabd6cc0dfb0c705defece91b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fddca9f529b9af87e7017afc60e7b6a3014f6175cc9ba88de9a22e7c9f55048',2002,'LK','Sri Lanka','transportation',1011,'Railways:
total: 1,463 km
broad gauge: 1 ,404 km 1 .676-m gauge
narrow gauge: 59 km 0.762-m gauge (2001)
Highways:
total: 11,285 km
paved: 10,721 km
unpaved: 564 km (1998 est.)
Waterways: 430 km (navigable by shallow-draft
craft)
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine:
total: 18 ships (1 ,000 GRT or over) totaling 137,321
GRT/233,367 DWT
ships by type: bulk 1 , cargo 1 5, container 1 , petroleum
tanker 1 , includes some foreign-owned ships
registered here as a flag of convenience: Germany 9,
Hong Kong 1 , United Arab Emirates 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: U
over 3,047 m;1
1,524 to 2,437 m:7
914 to 1,523 m; 6 (2001)
Airports - with unpaved runways:
total:]
under 914 m: 1 (2001)
Railways:
total: 5,995 km
narrow gauge: 4,595 km 1 .067-m gauge; 1 ,400 km
0.600-m gauge plantation line
note: the 1. 067-m line from Khartoum to Port Sudan
carries over two-thirds of Sudan''s rail traffic; the
0!600-m gauge system serves Sudan''s cotton
plantations with over 120 collecting stations (2001)
Highways:
tote/: 11,900 km
paved: 4,320 km
unpaved: 7,580 km (1996)
Waterways: 5,310 km
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 39,545
GRT/51.195DWT
ships by type: cargo 2, roll on/roll off 2 (2002 est.)
Airports: 65(2001)
Airports - with paved runways:
total: 12
over 3,047 m:1
2,438 to 3,047 m:Z
1,524 to 2,437 m: 3 (2001)
Airports - with unpaved runways:
tofa/:53
1,524 to 2,437 m:16
914 to 1f523m: 26
under 914 m: 11 (2001)
Heliports: 1 (2001)','f33cd0a92133d473ed3c5c18c20a183f8d615acb2f76de07026cb17a8043f43a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32e01fc858cbf1d133e35174cc810353d133893cc371be0e12b422e329864905',2002,'AF','Afghanistan','transportation',1021,'Railways:
tofa£482km
broad gauge: 482 km 1 .520-m gauge
nofe; includes only lines in common carrier service;
lines dedicated to particular industries are excluded
(2001)
Highways:
total: 29,900 km
paved: 21 ,400 km (includes some all-weather
gravel-surfaced roads)
unpaved: 8,500 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports: 53(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
under 914 m-A (2001)
Airports - with unpaved runways:
total: 51
over 3,047 m:1
1524 to 2,437 m: 2
914 to 1,523 m:12
under 914 m:% (2001)
Railways:
total: 3,569 km .
narrow gauge: 2,600 km 1 .000-m gauge; 969 km
1.067-m gauge
note: the Tanzania-Zambia Railway Authority
(TAZARA), which operates 1 ,860 km of 1 .067-m
narrow gauge track between Dar es Salaam and
Kapiri Mposhi in Zambia (of which 969 km are in
Tanzania and 891 km are in Zambia) is not a part of
Tanzania Railways Corporation; because of the
difference in gauge, this system does not connect to
Tanzania Railways (2001)
Highways:
total: 85,000 km
pa ved: 4,250 km
unpaved: 80,750 km (2001)
Waterways:
note; Lake Tanganyika, Lake Victoria, and Lake
Nyasa are principal avenues of commerce between
Tanzania and its neighbors on those lakes
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam,
Kigoma, Kilwa Masoko, Lindi, Mtwara, Mwanza,
Pangani, Tanga. Wete, Zanzibar
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 21 ,987
GRT/27,121 DWT
ships by type: cargo 2, passenger/cargo 2, petroleum
tanker 2, roll on/roll off 1 , short-sea passenger 1
(2002 est.)
Airports: 125(2001)
Airports - with paved runways:
fcfa/:11
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m:1
under 914 m; 1 (2001)
Airports - with unpaved runways:
total: 114
1,524 to 2,437 m:18
914 to 1,523 m: 61
under 914 m: 35 (2001)
Railways:
total: 4,071 km
narrow gauge: A fill km 1.000-m gauge (''2001 )
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1,615 km (1996)
Waterways: 4,000 km
note: 3,701 km are navigable throughout the year by
boats with drafts up to 0.9 meters; numerous minor
waterways serve shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhla
Merchant marine:
total: 297 ships (1,000 GRT or over) totaling
1,661,314 GRT/2,564,820DWT
ships by type: bulk 34, cargo 1 33, chemical tanker 3,
combination bulk 1 , container 14, liquefied gas 20,
multi-functional large-load carrier 2, passenger 1 ,
petroleum tanker 65, refrigerated cargo 16, roll on/roll
off 2, short-sea passenger 2, specialized tanker 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Greece 1 ,
Indonesia 1, Japan 1, Norway 24, Panama 1,
Singapore 1 (2002 est.)
Airports: 110(2001)
Airports - with paved runways:
fo/a/: 59
over 3,047 m: 7
2,438 to 3,047 m:M)
1,524 to 2,437 m: 22
914 to 1,523 m: 16
under 914 m: 4 (2001)
Airports - with unpaved runways:
tote/: 51
1,524 to 2,437 mA
914 to 1,523 m:19
under 914 m;31 (2001)
Heliports: 2(2001)
Railways:
total: 525 km
narrow gauge: 525 km 1.000-m gauge (2001)
Highways:
total 7,520 km
paved: 2,376 km
unpaved: 5,144 km (1996)
Waterways: 50 km (Mono river)
Ports and harbors: Kpeme, Lome
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 2,603 GRT/
2,800 DWT
ships by type: specialized tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Greece 1 (2002 est.)
Airports: 9(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 2 (2001)
Airports - with unpaved runways:
total:!
914 to 1,523 m: 5
under 914 m:2(2001)
Railways: 0 km
Highways:
tofa/:121 km
paved: 24 km
unpaved:Q7 km (2000)
Waterways: none
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none (2002 est.)
Airports: 8(2001)
Airports - with paved runways:
total: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:l
under 914 m:2 (2001)','a844790e0b01719fa86c05bf4f11259665b776a54e6350d49238d9bd21ce3c59','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91126e9dc48f3273167c8e0e59cacf8f84dacd65bde440e95249d79a8ffba2e2',2002,'TK','Tokelau','transportation',1030,'Railways: 0 km
Highways:
fofa/:NAkm
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2002 est.)
Airports: none; lagoon landings are possible by
amphibious aircraft (2001)
511
Tokelau (continued)','77937b88db4252aee0ed5d3ee5bf293b466748c781af69ebbfd407b40ba83d5a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed42e9e34fac3f5e0fd954bd6cc719dd85df5dcf9e0596a8fb5fe13806c36871',2002,'TM','Turkmenistan','transportation',1039,'Railways:
total: 2,440 km
broad gauge: 2,440 km 1 .520-m gauge (2001 )
Highways:
total: 22,000 km
paved: 18,000 km (includes some all-weather
gravel -surfaced roads)
unpaved: 4,000 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: the Amu Darya is an important inland
waterway for Turkmenistan
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbasy
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 4,600 GRT/
5,000 DWT
ships by type: petroleum tanker 1 (2002 est.)
Airports: 76(2001)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4 (2001)
Airports • with unpaved runways:
total: 63
2,438 to 3,047 m:7
1,524 to 2,437 m: 5
914 to 1,523 m: 10
under 914 m: 41 (2001)','f05cfd440219b91a6edfc8c2be6cf9eb72c3edeaeef24f1a79790b9a09a2e192','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e65872bcf4229299795b6d7d7130a59f9d5b50e4aa44ac65a3f5dd5e21efb637',2002,'TV','Tuvalu','transportation',1048,'Railways: 0 km
Highways:
tote/: 19.5 km
paved: 0 km
unpaved: 19.5 km (2002)
Waterways: none
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 31 ,021
GRT/52,198 DWT
ships by type: cargo 3, passenger/cargo 1 , petroleum
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 5 (2002 est.)
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2001)
Railways:
total: 1,241 km
narrow gauge: 1,241 km 1,000-m gauge
note: a program to rehabilitate the railroad is
underway (2001)
Highways:
total: 27,000 km
paved: 1,800 km
unpaved: 25,200 km (of which about 4,200 km are
all-weather roads) (1990)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,091 GRT/
8,229 DWT
ships by type: roll on/roll off 3
note: these ships are in cargo and passenger (ferry)
service on Uganda''s inland waterways (2002 est.)
Airports: 27 (200!)
Airports - with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
tofa/:23
2,438 to 3,047 m: 1
1,524 to 2,437 m:$
914 to 1,523 m:9
under 914 m: 7 (2001)','911d424c2975a1c5fbcecf22bbb5055373680a86decd77c9fc15743282e3c2f5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6ac1657e9208a2ee2368f35af7d82c1f3df5479050e396eaf445232ae33fa39',2002,'OM','Oman','transportation',1059,'Railways: 0 km
Highways:
total: 4,835 km
paved: 4,835 km
unpaved: 0 km (1998 est.)
Waterways: none
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, Al Fujayrah, Das Island,
Khawr Fakkan, Mina* Jabal ''Ali, Mina'' Khalid, Mina''
Rashid, Mina'' Saqr, Mina'' Zayid, Umm al Qaywayn
Merchant marine:
total: 56 ships (1,000 GRT or over) totaling 833,401
GRT/1,251,015DWT
ships by type: cargo 1 3, chemical tanker 3, container
7, liquefied gas 1 1 livestock carrier 1 , petroleum tanker
25, roll on/roll off 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 2, Italy 1 ,
Kuwait 2 (2002 est.)
Airports: 38(2001)
Airports - with paved runways:
fofa/:1922
over 3,047 m: 8 8
2,438 to 3,047 m: 3 3
1,524 to 2,437 m: 2 4
914 to 1,523 m: 2 3
under 914 m: 4 4 (2001)
Airports - with unpaved runways;
tote/: 19 19
over 3,047 m:1 1
2,438 to 3,047 m;1 1
1,524 to 2,437 m: 3 3
M to 1,523 m; 9 9
under 914 m: 5 5 (2001)
Heliports: 2(2001)','b14ed9ce8a443c1c15d452d9c12e2ad5a78d7d9c59ef85bd3ffa86c8d630b423','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9988dcc15953bd509b7385e168763ceabcf865c758c9cbd93aca00d5b5d3f0f',2002,'US','United States','transportation',1067,'Railways:
total: 212,433 km mainline routes
standard gauge: 212,433 km 1.435-m gauge
note: represents the aggregate length of roadway of
all line-haul railroads including an estimate for Class II
and 111 railroads (1998)
Highways:
total: 6,370,031 km
paved: 5,733,028 km (including 74,091 km of ^
expressways)
unpaved: 637,003 km (1997)
Waterways: 41,009 km
note: navigable inland channels, exclusive of the
Great Lakes
Pipelines: petroleum products 276,000 km; natural
gas 331 ,000 km (1991)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago. Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia.. Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 264 ships (1 ,000 GRT or over) totaling
6,911,641 GRT/9,985,660 DWT
ships by type: barge carrier 1 , bulk 1 1 , cargo 14,
chemical tanker 1 6, collier 1 , combination bulk 4,
combination tanker 11, container 86, multi-functional
large-load carrier 4, passenger/cargo 2, petroleum
tanker 81, roll on/roll off 28, specialized tanker 3,
vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Canada 4,
Denmark 1 5, France 1 , Germany 1 , Netherlands 3,
Norway 7, Puerto Rico 4, Singapore 1 1 1 Sweden 1 ,
United Kingdom 3 (2002 est.)
Airports: 14,695(2001)
Airports - with paved runways:
total: 5,127
over 3,047 m: 183
2,438 to 3,047 m: 222
1,524 to 2,437 m; 1,342
914 to1t523m: 2,41 3
under 914 m;967 (2001)
Airports - with unpaved runways:
total: 9,568
over 3,047 m;1
2,438 to 3,047 m: 7
1,524 to 2,437 m;165
914 to 1,523 m: 1,679
under914m: 7,716 (2001)
Heliports: 132(2001)
Railways:
total: 2,993 km
standard gauge: 2,993 km 1 ,435-m gauge
note: of the total route length, 461 km have been
taken out of service and 460 km are in only partial use;
moreover, not all lines offer passenger service (2001)
Highways:
total: 8,764 km
paved: 7,800 km
unpaved:%4 km (2001)
Waterways: 1 ,600 km (used by coastal and
shallow-draft river craft)
Ports and harbors: Colonia, Fray Bentos, Juan La
Caze, La Paloma, Montevideo, Nueva Palmira,
Paysandu, Punta del Este, Piriapolis
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 7,752 GRT/
5,228 DOT
ships by type: petroleum tanker 1 , roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 4, Greece 1
(2002 est.)
Airports: 64(2001)
Airports - with paved runways:
total: 15
2,438 to 3,047 m:1
1 ,524 to 2,437 m:S
914 to 1,523 m:7
under 914 m:2(2m)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 2
914 to 1,523 m: 16
under 914 m:31 (2001)','8547c51c4d5a8a074870bfe825e767e92ab3974fb2603db340accb00ec4c57e6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73024a907203d586b9da5074e1e24d19afa448d69698857467b9f1a2deb27615',2002,'UZ','Uzbekistan','transportation',1076,'Railways:
total: 3,656 km
broad gauge: 3,656 km 1.520-m gauge (618 km
electrified) (2000)
Highways:
total: 81 ,600 km
paved: 71 ,237 km (includes some all-weather
gravel-surfaced roads)
unpaved: 10,363 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: ''1,100 km (1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya)
Airports: 267(2001)
Airports - with paved runways:
total: W
over 3,047 m: 3
2,438 to 3,047 m: 5
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 257
over 3,047 m: 3
2,438 to 3,047 m:t
1,524 to 2,437 m:11
914 to 1,523 m: 13
under 914 m: 222 (2001)','55cb235bd3443f70e1c56bb319473e641310838894baa91db135bd494d242500','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62705d80d2a97368ff950511cd05d15090a972862b6fa59bdef3c20b1ada8ec7',2002,'VU','Vanuatu','transportation',1086,'Railways: 0 km
Highways:
total: 1,070 km
paved: 256 km
onpauecf;814km(1996)
Waterways: none
Ports and harbors: Forari, Port-Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 54 ships (1,000 GRT or over) totaling 1 ,092,838
GRT/1 ,329,576 DWT
ships by type: bulk 22, cargo 9, chemical tanker 1 ,
combination bulk 3, container 2, liquefied gas 3,
petroleum tanker 1, refrigerated cargo 7, vehicle
carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 3, Canada 2,
China 1, Japan 25, Monaco 4, Netherlands 1, New
Zealand 5, Panama 1 , Poland 1 , Switzerland 2, United
Kingdom 4, US 2, Vietnam 1 (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:\\
914 to 1,523 m;1 (2001)
Airports • with unpaved runways:
total: 29
1,524 to 2,437 m:2
914 to 1,523 m:W
under 914 m: 17 (2001)
Railways:
total: 682 km
standard gauge: 682 km 1.435-m gauge
note: 248 km of the existing system are privately
owned; passenger services are nonexistent; however,
a National Railways Plan, intended to provide a
significant railway system, has been initiated (2001)
Highways:
total: 96,155 km
paved: 32,308 km
unpaved: 63,847 km (1997 est.)
Waterways: 7,100 km
note: Rio Orinoco and Lago de Maracaibo accept
oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,01 0 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz. Puerto Ordaz,
Puerto Sucre, Punta Cardon
Merchant marine:
total: 45 ships (1 ,000 GRT or over) totaling 716,361
GRT/1 ,267,095 DWT
ships by type: bulk 7, cargo 9, liquefied gas 3,
passenger/cargo 1 , petroleum tanker 1 4, roll on/roll off
10, short-sea passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 , Greece 1 ,
Italy 1 , United Kingdom 1 , United States 2 (2002 est.)
Airports: 372(2001)
Airports - with paved runways:
tofa/:124
over 3,047 m: 5
2,438 to 3,047 m: 11
1,524 to 2,437 m: 22
914 to 1,523 m: 59
under 914 m: 17 (2001)
Airports -with unpaved runways:
total: 248
1,524 to 2,437 m: 11
914 to 1,523 m: 97
under 914 m: 140 (2001)
Heliports: 1 (2001)
Railways:
''tote/: 3,142 km
standard gauge: 209 km 1.435-m gauge
narrow gauge: 2,625 km 1 ,000-m gauge
dual gauge: 308 km three-rail track combining
1.435-m and 1.000-m gauges (2001)
Highways:
total: 93,300 km
paved: 23,41 8 km
unpaved: 69,882 km (1996)
Waterways: 17,702 km
note: more than 5,149 km are navigable at all times by
vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minn City, Ha Long, Quy Nhon, Nha
Trang, Vinh, Vung Tau
Merchant marine:
total: 1 53 ships (1 ,000 GRT or over) totaling 782,91 2
GRT/1 ,173,186 DWT
ships by type: bulk 9, cargo 113, chemical tanker 1,
combination bulk 1, container 5, liquefied gas 2,
petroleum tanker 20, refrigerated cargo 2
nofe: includes some foreign-owned ships registered
here as a flag of convenience: Cambodia 1, Japan 1,
Singapore 1, United Kingdom 2 (2002 est.)
Airports: 34(2001)
Airports - with paved runways:
total: 17
over 3,047 m:8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 17
over 3,047 m''^
1,524 to 2,437 m:1
914 to 1 ,523 m: 7
under 914 m: 8(2001)','cb3255fb4b385304f48077512ed2c452a52e9a486df6f4710a0b7f4fe372c0eb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf9e72633f980e8b52101c1488ee5aa1de554f8f3bb8a1c5118607df84f74f2',2002,'PR','Puerto Rico','transportation',1093,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km (2000)
Waterways: none
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2 (2001)','1d0d3f133a8625e49cd4368aec4e8b7fcfb21334a5d38e289ef5a46afd919410','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c488ec15438bb7714baa52bac287551ad09ac471f7cd9d0a5ad8a0115df987f3',2002,'DZ','Algeria','transportation',1104,'Railways: 0 km
Highways:
total: 6,200 km
paved: 1,350 km
unpaved: 4,850 km (1991 est.)
Waterways: none
Ports and harbors: Ad Dakhla, Cabo Bojador,
Laayoune (El Aaiun)
Airports: 11 (2001)
Airports - with paved runways:
totals
2,438 to 3,047 m:3 (2001)
Airports - with unpaved runways:
total: B
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 3 (2001)
Railways:
total: 1,201,337 km includes about 190,000 to
195,000 km of electrified routes of which 147,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,160 km in
North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) - Atlantique line
broad gauge: 251, 153 km
standard gauge: 71 0,754 km
narrow gauge: 239,430 km
Highways:
total: km
paved: NA km
i/npavec/:NAkm
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina'' al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama
Railways: 0 km
Highways:
total: 69,263 km
paved: 9,963 km
unpavecf:59,300km(1999)
567
YeiUGn (continued)
Waterways: none
Pipelines: crude oil 644 km; petroleum products
32 km
Ports and harbors: Aden, Al Hudaydah, Al Mukalfa,
As Salif, Ras Issa, Mocha, Nishtun
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 1 5,002
GRT/23752 DWT
ships by type: cargo 1 , petroleum tanker 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Hong Kong 2
(2002 est.)
Airports: 49(2001)
Airports - with paved runways:
total: U
over 3,047 m: 3
2,438 to 3,047 m: 8
1,524 to 2A37mA
914 to 1,523 mA
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 35
over 3,047 m: 2
2,438 to 3,047 m:$
1,524 to 2,437 m;8
914 to 1,523 m: 13
under 914 m: 4 (2m)
Railways:
total: 4,059 km
standard gauge: 4,059 km 1 ,435-m gauge (1 ,377 km
electrified)
note: during the 1999 Kosovo conflict, the Serbian rail
system suffered significant damage due to bridge
destruction; many rail bridges have been rebuilt;
Montenegrin rail lines remain intact (2001)
Highways:
total: 48,603 km
paved: 28,822 km (including 560 km of expressways)
vnpaved: 19,781 km
note: because of the 1999 Kosovo conflict, many road
bridges were destroyed; since the end of the conflict
in June 1999, there has been an intensive program to
either rebuild bridges or build by-pass routes (1999)
Waterways: 587 km
note: the Danube River, central Europe''s connection
with the Black Sea, runs through Serbia; since early
2000, a pontoon bridge, replacing a destroyed
conventional bridge, has obstructed river traffic at
Novi Sad; the obstruction is bypassed by a canal
system, the inadequate lock size of which limits the
size of vessels which may pass; the pontoon bridge
can be opened for large ships but has slowed river
traffic (2001)
Pipelines: crude oil 415 km; petroleum products 130
km; natural gas 2,110 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 2,437
GRT/400 DWT
ships by type: short-sea passenger 1 (2002 est.)
Airports: 46 (2001)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m:2
under 914 m: 4 (2001)
Airports - with unpaved runways:
total: 27 27
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m:2 1 3(2001)
Heliports: 2 (2001)
Railways:
fofa/:2,157km
narrow gauge: 2,157 km 1,067-m gauge (13 km
double-track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority (TAZARA), which
operates 1 ,860 km of 1.067-m narrow gauge track
between Dar es Salaam and Kapiri Mposhi where it
connects to the Zambia Railways system; TAZARA is
not a part of the Zambia Railways system; Zambia
Railways assets are scheduled for concessioning
(2002)
Highways:
total: 66,781 km
paved: NA km
unpaved: NA km (1997 est.)
Waterways: 2,250 km
note: includes Lake Tanganyika and the Zambezi and
Luapula rivers
Pipelines: crude oil 1 ,724 km
Ports and harbors: Mpulungu
Airports: 111 (2001)
Airports - with paved runways:
over 3,047 m:1
2,438 to 3,047 m:3
1,524 to 2,437 m: 4
914 to 1,523 m:2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: W
2,438 to 3,047 m:1
1,524 to 2,437 m:3
914 to 1,523 m: 66
under 914 m:30 (2001)','cd2213a78a00df80e81993ed361bc6354a011af62c5bd5d81b874f795e44c7f6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efd66477587e7e299ff1756fa7327d805cc1766b266bc7aeba513d423ff062cf',2002,'ZW','Zimbabwe','transportation',1112,'Railways:
total: 3,077 km
narrow gauge: 3,077 km 1 ,067-m gauge (31 3 km
electrified; 42 km double-tracked)
nofe; includes the 318 km Bulawaya-Beitbridge
Railway Company line (2001 )
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (2002)
Waterways: chrome ore is transported from Harare -
by way of the Mazoe River - to the Zambezi River in','9189f09de1b88dc404c27fb205cfbde1656df016e52954b92618d4ce5ef4c6d0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc117a7b5ad1027193d3f8049652addaa0e6fbea3f05b06235d9c10a242d4689',2002,'AU','Australia','transportation',39,'Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Highways
total
paved
unpaved
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports - with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2, 427 m
914 to 1,523 m
under 914 m
Airports - with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 91 4 m
Heliports
Transportation - note
Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
to/a/; 7,686,850 sq km
land: 7,617,930 sqkm
wafer; 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area * comparative: slightly smaller than the US
contiguous 48 states
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
contiguous zone: 24 NM
continental shell: 200 NM or to the edge of the
continental margin
exclusive economic zone: 200 NM
territorial sea: 1 2 NM
Climate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
30
Australia (continued)
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2,229 m
Natural resources: bauxite, coal, iron ore, copper,
tin, silver, uranium, nickel, tungsten, mineral sands,
lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 7%
permanent crops: 0%
other: 93% (1998 est.)
Irrigated land: 24,000 sq km (1998 est.)
Natural hazards: cyclones along the coast; severe
droughts; forest fires
Environment - current issues: soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; regular, tropical,
invigorating, sea breeze known as "the Doctor" occurs
along the west coast in the summer
Railways:
total: 33,819 km (2,540 km electrified)
broad gauge: 3,'' 719 km 1.600-m gauge
standard gauge: 15,422 km 1.435-m gauge
narrow gauge: 14,506 km 1 .067-m gauge
dual gauge: 1 72 km NA gauges (1999 est.)
Highways:
total: 913,000 km
paved: 353,331 km (including 1,363 km of
expressways)
unpaved: 559,669 km (1996)
Waterways: 8,368 km (mainly used by small,
shallow-draft craft)
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantle, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 55 ships (1 ,000 GRT or over) totaling 1 ,469,362
GRT/1 ,869,262 DWT
ships by type: bulk 26, cargo 5, chemical tanker 4,
container 1, liquefied gas 4, passenger 2, petroleum
tanker 7, roll on/roll off 6, includes some
foreign-owned ships registered here as a flag of
convenience: France 2, United Kingdom 2, United
States 14 (2002 est.)
Airports: 421 (2001)
Airports - with paved runways:
total: 282
over 3,047 m: 10
2,438 to 3,047 m: 11
1,524 to 2,437 rn:m
914 to 1,523 m: 124
under 91 4 m: 9 (2001)
Airports - with unpaved runways:
total: 139
1,524 to 2,437 m: 16
914 to 1,523m: 111
under 914 m: 12 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Waterways: none
Ports and harbors: none; offshore anchorage only
Railways: 0 km
Highways:
total: 234 km
paved: 86 km
unpaved: 148 km (1 06 km of which is access and
plantation road) (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports • with paved runways:
total: 1
1,524 to 2.437 m: 1 (2001)
Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km (2001)
Waterways: none
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2, 437 m: 1 (2001)','ed247aa483c87325f66e27da7af38f6f85dd2e00b4bc4290a41dba1934fef8fc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bd57ab0e526a90e416f9b1f01a640fa049904c281252214991305f2338c08bb',2002,'AF','Afghanistan','transportation',49,'Railways:
total: 24.6 km
broad gauge: 9.6 km 1.524-m gauge from Gushgy
(Turkmenistan) to Towraghondi; 15 km 1.524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
(2001)
Highways:
fo/a/: 21 ,000 km
paved: 2,793 km
unpaved: 18,207 km (1998 est.)
Waterways: 1,200 km
note: chiefly Amu Darya, which handles vessels up to
500 DWT (2001)
Pipelines: natural gas 180 km
note: product pipelines from Uzbekistan and
Turkmenistan have been in disrepair and disuse for
years (2002)
Ports and harbors: Kheyrabad, Shir Khan
Airports: 46(2001)
Airports - with paved runways:
total: 10
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 36
2,438 to 3,047 m: 7
1,524 to 2,437 m: 13
914 to 1,523 m: 4
under 914 m: 11 (2001)
Heliports: 2(2001)
Railways:
total: 482 km
broad gauge: 482 km 1.520-m gauge
note: includes only lines in common carrier service;
lines dedicated to particular industries are excluded
(2001)
Highways:
total: 29,900 km
paved: 21, 400 km (includes some all-weather
gravel-surfaced roads)
unpaved: 8,500 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports: 53(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 51
over 3,047 m: 1
1,524 to 2,437m: 2
914 to 1,523 m: 12
under 914 m: 36 (2001)
Railways: 0 km
Highways:
tofa/:121 km
paved: 24 km
unpaved: 97 km (2000)
Waterways: none
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none (2002 est.)
Airports: 8(2001)
Airports - with paved runways:
total: 5
1,524 to 2,437 m: 3
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2001)','3fdf28f6aadf2454a82c1da128e92c1b72256271c8f9207844420fa08a8724ea','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4d9629965bed3886d24abccd57dce03cb38ac41e5b6d2b9fb5e8056a727acdc',2002,'AL','Albania','transportation',58,'Railways:
total: 447 km
standard gauge: 447 km 1.435-m gauge (2001 est.)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km
note: includes Albanian sections of Lake Scutari, Lake
Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 196 km; petroleum products 55
km; natural gas 64 km (1996)
Ports and harbors: Durres, Sarande, Shengjin,
Vlore
Merchant marine:
tote/: 7 ships (1,000 GRT or over) totaling 13,423
GRT/20,837 DWT
ships by type: cargo 7, includes some foreign-owned
ships registered here as a flag of convenience:
Croatia 1 , Honduras 1 (2002 est.)
Airports: 11 (2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 (2001)
Airports - with unpaved runways:
total: 8
over 3,047 m:1
1,524 to 2,437 m;1
914 to 1,523 m: 2
under 914 m: 4 (2001)
Heliports: 1 (2001)
Railways:
total: 4,820 km
standard gauge: 3,664 km 1.435-m gauge (301 km
electrified; 215 km double-track)
narrow gauge: 1,156 km 1.055-m gauge (1999 esl.)
Highways:
total: 104,000 km
paved: 71 ,656 km (including 640 km of expressways) ''
unpaved: 32,344 km (1996 est.)
Waterways: none
Pipelines: crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Dellys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 73 ships (1 ,000 GRT or over) totaling 903,944
GRT/1 ,051,433 DWT
ships by type: bulk 9, cargo 25, chemical tanker 7,
liquefied gas 10, petroleum tanker 5, roll on/roll off 12,
short-sea passenger 4, specialized tanker 1 , includes
some foreign-owned ships registered here as a flag of
convenience: United Arab Emirates 2 (2002 est.)
Airports: 136(2001)
Airports - with paved runways:
total: 52
over 3,047 m: 9
2,438 to 3,047 m: 26
1,524 to 2,437 m: 11
914 to 1,523 m: 5
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: B4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 40
under 914 m:18 (2001)
Heliports: 1 (2001)','d6fec44d74380a3a45d2ed74074219cfcf5028ed5460c98c8b4169a8e1f3f94c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98dacac068f4772b55996e197e65247df3e89746c48c67bd4a18403875f97188',2002,'NZ','New Zealand','transportation',69,'Railways: Okm
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Waterways: none
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2001)
Railways: Okm
Highways:
total: 680 km
paved: 184 km
uopavecf:496km(1996)
Waterways: none
Ports and harbors: Neiafu, Nukualofa, Pangai
Merchant marine:
total: 80 ships (1,000 GRT or over) totaling 292,139
GRT/421 ,221 DWT
ships by type: bulk 1 0, cargo 54, liquefied gas 4,
petroleum tanker 8, roll on/roll off 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 1 , Australia 4,
Austria 1 , Bolivia 1 , Cyprus 1 , Djibouti 1 , Egypt 2,
Greece 4, Lebanon 2, Liberia 2, Marshall Islands 2,
Morocco 1 , Norway 1 , Panama 1 , Romania 3,
Russia 1, Sao Tome and Principe 1, Saudi Arabia 2,
Singapore 1, Sweden 1, Switzerland 3, Syria 5,
Ukraine 1, United Arab Emirates 16, United States 4
(2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1 (2001)
513
Tonga (continued)
Airports • with unpaved runways:
total: 4
1,524 to 2,437 m:1
914 to 1,523 m: 1
under 91 4 m:2 (2001)
Railways: minimal agricultural railroad system near
San Fernando; common carrier railway service was
discontinued in 1968 (2001)
Highways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1996)
Waterways: none
Pipelines: crude oil 1 ,032 km; petroleum products 1 9
km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,910 GRT/
7,546 DWT
ships by type: cargo 2, petroleum tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 6 (2001)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 mil
under 914 m: 2 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Railways: 0 km
Highways:
total: 120 km (lie Uvea 100 km, lie Futuna 20 km)
paved: 1 6 km (all on lie Uvea)
unpaved: 104 km (lie Uvea 84 km, lie Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 71 ,868
GRT/7,422 DWT
ships by type: passenger 4
note: includes some foreign-owned ships registered
here as aflag of convenience: France 3, United States
1 (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)','59fd545a15214adf32a68ead7b132c599cb06a09e79a4ff7501bcea41ae76cb5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e03d65e216d2b7b69d268e9c0e89a40fc8cb482d7c0c1fab141172ec12ce291',2002,'AD','Andorra','transportation',78,'Railways: 0 km.
Highways:
tofa/:269km
paved: 198 km
unpaved: 71 km (1994 est.)
Waterways: none
Ports and harbors: none
Airports: none (2001)','05c8360a3cc0eecc34117a1a528e7d1e766393f60a288d856ed31344f1bba658','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f749dc1aab2c85ccb7fa906d506daa781bc0e656006360271cb3acd8c170a3b5',2002,'AO','Angola','transportation',87,'Railways:
total: 2,771 km (inland, much of the track is unusable
because of land mines still in place from the civil war)
narrow gauge: 2,648 km 1 ,067-m gauge; 1 23 km
0.600-m gauge (2000 est.)
Highways:
total: 76,626 km
paved: 19,156 km
unpaved: 57,470 km (1997)
Waterways: 1,295 km
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Mocamedes, Namibe, Porto
Amboim, Soyo
Merchant marine:
total: 9 ships (1,000 GRT or over) totaling 39,305
GRT/63,528 DWT
ships by type: cargo 8, petroleum tanker 1 (2002 est.)
Airports: 244(2001)
Airports - with paved runways:
total: 32
over 3,047 m:4
2,438 to 3,047 m: 8
1,524 to 2,437m: 13
914 to 1,523 m :6
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 212
over 3,047 m: 2
2,438 to 3,047m: 5
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 80 (2001)
Railways: 0 km
Highways:
total: 105 km
paved: 65 km
unpaved:40km(1998 est.)
Waterways: none
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (2001)
Airports • with unpaved runways:
total: 2
under 914 m: 2(2001)','c31f197adb06f5176cddcbfe48f17c4fe9aee6b463089baf0c65caa2cdcf7160','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e1f3c01669e455496a68aa41bd7e2ec88093ead415015e46598b713cee4d80',2002,'AQ','Antarctica','transportation',97,'Ports and harbors: there are no developed ports
and harbors in Antarctica: most coastal stations have
offshore anchorages, and supplies are transferred
from ship to shore by small boats, barges, and
helicopters; a few stations have a basic wharf facility;
US coastal stations include McMurdo (77 51 S, 1 66 40
E), Palmer (64 43 S, 64 03 W); government use only
except by permit (see Permit Office under “Legal
System"); all ships at port are subject to inspection in
accordance with Article 7, Antarctic Treaty; offshore
anchorage is sparse and intermittent
Airports: 30(2001)
note: 27 stations, operated by 16 national
governments party to the Antarctic T reaty, have
aircraft landing facilities for either helicopters and/or
fixed-wing aircraft; commercial enterprises operate
two additional aircraft landing facilities; helicopter
pads are available at 27 stations; runways at 15
locations are gravel, sea-ice, blue-ice, or compacted
snow suitable for landing wheeled, fixed-wing aircraft;
of these, 1 is greater than 3 km in length, 6 are
between 2 km and 3 km in length, 3 are between 1 km
and 2 km in length, 3 are less than 1 km in length, and
2 are of unknown length; snow surface skiways,
limited to use by ski-equipped, fixed-wing aircraft, are
available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and
3 km in length, 2 are between 1 km and 2 km in length,
2 are less than 1 km in length, and 4 are of unknown
length; aircraft landing facilities generally subject to
severe restrictions and limitations resulting from
extreme seasonal and geographic conditions; aircraft
landing facilities do not meet ICAO standards;
advance approval from the respective governmental
or nongovernmental operating organization required
for landing; landed aircraft are subject to inspection in
accordance with Article 7, Antarctic Treaty
Airports - with unpaved runways:
tofa/:19
over 3,047 m: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 5 (2001)
Heliports: 27 stations have helicopter landing
facilities (helipads) (2001)
Railways:
total: 33,744 km (167 km electrified)
broad gauge: 20,594 km 1.676-m gauge (141 km
electrified)
standard gauge: 2,739 km 1 ,435-m gauge (26 km
electrified)
narrow gauge: 10,154 km 1.000-m gauge; 257 km
0.750-m gauge (2000 est.)
Highways:
total: 215,434 km
paved: 63,553 km (including 734 km of expressways)
unpaved: 151,881 km (1998 est.)
Waterways: 10,950 km
Pipelines: crude oil 4,090 km; petroleum products
2,900 km; natural gas 9,918 km
Ports and harbors: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, Concepcion del Uruguay, La
Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 24 ships (1 ,000 GRT or over) totaling 1 47,505
GRT/222,500 DWT
ships by type: cargo 9, petroleum tanker 1 0, railcar
carrier 1 , refrigerated cargo 2, roll on/roll off 1 ,
short-sea passenger 1, includes some foreign-owned
ships registered here as a flag of convenience: United
Arab Emirates 1, Uruguay 1 (2002 est.)
Airports: 1,369(2001)
Airports - with paved runways:
total: 144
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 60
914 to 1,523 m: 45
under 914 m: 9 (2001)
Airports - with unpaved runways:
total: 1,225
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 53
914 to 1,523 m: 598
under 914 m: 570 (2001)
Railways:
total: 852 km in common carrier service; does not
include industrial lines
broad gauge: 852 km 1.520-m gauge (779 km
electrified) (2001 est.)
Highways:
total: 11, 300 km
paved: 10,500 km (includes some all-weather
gravel-surfaced roads)
unpaved: 800 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: NAkm
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 7(2001)
Airports - with unpaved runways:
total: 7
over 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m:1 (2001)
Railways: Okm
Highways:
total: 800 km
paved: 51 3 km
unpaved: 287 km
note: most coastal roads are paved, while unpaved
roads serve large tracts of the interior (1995)
Waterways: none
Ports and harbors: Barcadera, Oranjestad, Sint
Nicolaas
Merchant marine: includes a foreign-owned ship
registered here as a flag of convenience: Monaco 1
(2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only','6839c7ce79a682883a4410ed574a235ac93280de0d1acb06294fa3f8f0401292','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f03f72cb5d8dd10e64bb68cc110a0ba4251d5781ca5b36cd0c7bfa07cf62596e',2002,'GP','Guadeloupe','transportation',106,'Railways:
tofa/:77km
narrow gauge: 64 km 0,760-m gauge; 13 km 0.610-m
gauge (used almost exclusively for handling
sugarcane) (2001 est.)
Highways:
total: 1,165 km
paved: 384 km
unpaved: 781 km
note: it is assumed that the main roads are paved; the
secondary roads are assumed to be unpaved (1995)
Waterways: none
Ports and harbors: Saint John''s
Merchant marine:
total: 762 ships (1 ,000 GRT or over) totaling
4,541 ,940 GRT/5, 894, 553 DWT
ships by type: bulk 20, cargo 469, chemical tanker 9,
combination bulk 4, container 202, liquefied gas 7,
multi-functional large-load carrier 6, petroleum tanker
1, refrigerated cargo 9, roll on/roll off 35
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 ,
Bangladesh 2, Belgium 3, Colombia 1, Cuba 1,
Estonia 1 , Germany 747, Greece 1 , Iceland 8, Latvia
1, Lebanon 2, Lithuania 1, Netherlands 22, New
Zealand 2, Portugal 1, Slovenia 6, South Africa 1,
Sweden 2, United Kingdom 1 , United States 7
(2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
Transportation • note: sparse network of air, ocean,
river, and land routes; the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways','d1af5142f3323ac759140be811e99e41e1b41027c3496663fa10298d0113a4a6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68323eddc509bf162bb2d7dbf480c8050e2f4a3fdf64023da91bf157e0bfca23',2002,'AT','Austria','transportation',123,'Railways:
total: 6,095.2 km (3,643.3 km electrified)
standard gauge: 5,564.2 km 1 .435-m gauge (3,521 .2
km electrified)
narrow gauge: 33.9 km 1 ,000-m gauge (28.1 km
electrified); 497.1 km 0.760-m gauge (94 km
electrified) (2001 est.)
Highways:
total: 133,361 km
paved: 133,361 km (including 1,613 km of
expressways)
unpaved: 0 km (1998)
Waterways: 358 km (1999)
Pipelines: crude oil 777 km; natural gas 840 km
(1999)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 10 ships (1,000 GRT or over) totaling 46,563
GRT/59,278 DWT
ships by type: bulk 1 , cargo 6, combination bulk 1 ,
container 2 (2002 est.)
Airports: 55(2001)
Airports - with paved runways:
total: 24
over 3,047 m:1
2,438 to 3,047 m: 5
1,524 to 2,437m: 1
914 to 1,523 m: 3
under 914 m: 14 (2001)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 27 (2001)
Heliports: 1 (2001)','762ef849a0124d6375981bfcfb151f44397567b3da838f25f921f90ac9e91b4f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4520f9ef82268dad53914d7086b33de9f10ade17f0f8b450c22d43962205e0be',2002,'AZ','Azerbaijan','transportation',131,'Railways:
total: 2,125 km in common carrier service; does not
include industrial lines
broad gauge: 2, 125 km 1.520-m gauge (1,278 km
electrified) (1993 est.)
Highways:
total: 36,700 km
paved: 31 ,800 km (includes some all-weather
gravel-surfaced roads)
unpaved: 4,900 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: crude oil 1,130 km; petroleum products
630 km; natural gas 1 ,240 km
Ports and harbors: Baku (Baki)
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 246,051
GRT/306,756 DWT
ships by type: cargo 12, petroleum tanker 40, roll on/
roll off 2 (2002 est.)
Airports: 52(2001)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 4 (2001)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 28 (2001)','e2eea5d2f1c83f93cb8d410134f4f50c484012d235b22c898676a5fb5fd74527','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('789a00ff2ff0641aacee6fc5d64407c839e40d8a41ae5e89279da5778035bf63',2002,'BS','Bahamas','transportation',141,'Railways: Okm
Highways:
total: 2,693 km
paved: 1 ,546 km
unpaved: 1,147 km (1997)
Waterways: none
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,076 ships (1,000 GRT or over) totaling
31,309,187 GRT/45, 859, 485 DWT
ships by type: bulk 159, cargo 246, chemical tanker
41, combination bulk 13, combination ore/oil 22,
container 80, liquefed gas 28, livestock carrier 2,
multi-functional large-load carrier 8, passenger 88,
passenger/cargo 1, petroleum tanker 178, railcar
carrier 1 , refrigerated cargo 120, roll on/roll off 49,
short-sea passenger 16, specialized tanker 2, vehicle
carrier 22
note: includes some foreign-owned ships registered
here as a flag of convenience: Angola 1 , Argentina 1 ,
Australia 4, Belgium 18, Bermuda 1, Canada 5, Chile
1 , China 3, Croatia 2, Cuba 3, Cyprus 2, Denmark 27,
Ecuador 1 , Estonia 2, Finland 9, France 15, Germany
26, Greece 173, Hong Kong 6, India 2, Indonesia 2,
Ireland 1 , Israel 3, Italy 9, Jamaica 1 , Japan 32, Kenya
3, Malaysia 10, Malta 2, Monaco 67, Netherlands 32,
New Zealand 2, Norway 237, Panama 2, Philippines
3, Poland 1 3, Reunion 1 , Russia 6, Saudi Arabia 9,
Singapore 13, Slovenia 1, South Korea 2, Spain 7,
Sweden 12, Switzerland 8, Thailand 1, Trinidad and
Tobago 2, Turkey 2, Ukraine 2, United Arab Emirates
10, United Kingdom 107, United States 159, Uruguay
1 (2002 est.)
Airports: 67(2001)
Airports - with paved runways:
total: 32
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 12
914 to 1,523 m: 10
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 3
914 to 1,523 m : 9
under 914 m: 23 (2001)
Heliports: 1 (2001)','aa1b9ec27cf6857de0bcc5a7f0e4e6c659af8db3da78a360c7f75597a9182908','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9b5759a5d26b3ac48c5df2bf78f81580eb1f3debaa0b3085d97cbb830a01ed2',2002,'BH','Bahrain','transportation',151,'Railways: Okm
Highways: 3,164 km
paved: 2,433 km
unpaved: 731 km
note: a paved causeway links Bahrain and Saudi
Arabia
Waterways: none
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina’ Salman, Sitrah
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 270,784
GRT/384,561 DWT
ships by type: bulk 2, cargo 4, container 2, includes a
foreign-owned ship registered here as a flag of
convenience: Kuwait 1 (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
total: 3
over 3,047 m: 2(2001)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Heliports: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area along the
middle of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
m, completely covered with vegetation and unusable
Transportation - note: there is a day beacon near
the middle of the west coast','8986350a3237f214e03409866ea01cf7d3c079df1095b59e1ed9e63bb948b593','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01563079ca27f0a9ddd8113d3b1b362605c2f04ed05022162391ee045d5597ed',2002,'BD','Bangladesh','transportation',159,'Railways:
total: 2,745 km
broad gauge: 923 km 1.676-m gauge
narrow gauge: 1 ,822 km 1,000-m gauge (2000 est.)
Highways:
total: 201,182 km
paved: 19,1 12 km
unpaved: 182,070 km (1997)
Waterways: up to 8,046 km depending on season
note: includes 3,058 km main cargo routes
Pipelines: natural gas 1 ,250 km
Ports and harbors: Chittagong, Dhaka, Mongla
Port, Narayanganj (2001)
Merchant marine:
total: 34 ships (1 ,000 GRT or over) totaling 269,932
GRT/379,271 DWT
ships by type: bulk 2, cargo 26, container 3,
petroleum tanker 2, refrigerated cargo 1, includes s
foreign-owned ship registered here as a flag of
convenience: Singapore 5 (2002 est.)
Airports: 18(2001)
Airports - with paved runways:
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m: 5 (2001)
Airports ■ with unpaved runways:
total: 3
1,524 to 2,437 m:1
under 914 m: 2 (2001)','db45169120fb49ed3cb612ac1fb7f111612c444c46531aa6f4f3301c3f290f44','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29abb95d0c2fbd0ec33e649742235ac860faca1528ad4ced7fb8c4e7db2d19cc',2002,'LC','Saint Lucia','transportation',163,'Railways: 0 km
Highways:
total: 1,650 km
paved: 1,628 km
unpaved: 22 km (1998)
Waterways: none
Ports and harbors: Bridgetown, Speightstown (Port
Charles Marina)
Merchant marine:
total: A 1 ships (1,000 GRT or over) totaling 629,987
GRT/1 ,073,991 DWT
ships by type: bulk 9, cargo 26, combination bulk 1 ,
container 1 , petroleum tanker 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Bahamas,
The 1, Canada 4, Germany 1, Greece 2, Hong Kong
7, Norway 7, United Kingdom 18 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047m: 1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only','320dbca96b1db05a74a92bd608266821bc96e224b0bd4fdc18704b614bca84e0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b1f221305919ad2764392b29aecc34801d99110f3f1a14f6de33de73f18dc61',2002,'BY','Belarus','transportation',178,'Railways:
total: 5,523 km
broad gauge: 5,523 km 1 ,520-m gauge (875 km
electrified) (2000 est.)
Highways:
total: 98,200 km
paved: 66,100 km (includes some all-weather
gravel-surfaced roads)
unpaved: 32,100 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: NA km; note • Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1 ,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 136(2001)
Airports - with paved runways:
total: 33
over 3,047m: 2
2,438 to 3,047 m: 19
1,524 to 2,437 m:1
under 914 m: 11 (2001)
Airports - with unpaved runways:
total: 103
over 3,047 m: 3
2,438 to 3,047 m: 10
1,524 to 2,437m: 11
914 to 1,523 m: 14
under 914 m: 65 (2001)
Railways:
total: 3,422 km
standard gauge: 3,422 km 1.435-m gauge (2,517 km
electrified; 2,563 km double-tracked) (2001)
Highways:
total: 145,774 km
paved: 1 16,182 km (including 1,674 km of
expressways)
unpaved: 29,592 km (1999)
Waterways: 1 ,570 km (route length in regular
commercial use) (2001)
Pipelines: crude oil 161 km; petroleum products
1,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mons,
Namur, Oostende, Zeebrugge
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 31 ,362
GRT/54,058 DWT
ships by type: cargo 6, chemical tanker 9, petroleum
tanker 5, includes some foreign-owned ships
registered here as a flag of convenience: Finland 1,
Netherlands 3 (2002 est.)
Airports: 42(2001)
Airports - with paved runways:
total: 24
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 6 (2001)
Airports -with unpaved runways:
total: 18
914 to 1,523 m: 2
under 914 m: 16 (2001)
Heliports: 1 (2001)
52
Belgium (continued)
Railways:
tote/: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km
electrified)
narrow gauge: 33 km 0.750-m gauge (2001)
Highways:
total: 59, 178 km
paved: 22,843 km
unpaved: 36,335 km (1998 est.)
Waterways: 300 km (perennially navigable)
Pipelines: crude oil 750 km; refined products 780
km; natural gas 560 km (1992)
Ports and harbors: Liepaja, Riga, Ventspils
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 30,1 1 9
GRT/30,572 DWT
ships by type: cargo 1 , petroleum tanker 1 ,
refrigerated cargo 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 3 (2002 est.)
Airports: 25(2001)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 mA
914 to 1,523 mA
under 914 m: 4 (2001)
Airports - with unpaved runways:
total: 12
2,438 to 3,047 mA
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 7 (2001)','52c2e8c265b4736ec376e8f654a2a5f14f219bd98dc7fac01b04e885a4072bc7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b3a68b05edef8f46d7f3f9c60267ad6d983c45280eb6eee294a8c6798feb63e',2002,'BZ','Belize','transportation',187,'Railways: 0 km
Highways:
total: 2,880 km
paved: 490 km
unpaved: 2,390 km (1998 est.)
Waterways: 825 km (river network used by
shallow-draft craft; seasonally navigable)
Ports and harbors: Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine:
total: 31 5 ships (1 ,000 GRT or over) totaling
1,240,551 GRT/1 ,761, 168 DWT
ships by type: bulk 26, cargo 204, chemical tanker 6,
combination ore/oil 1 , container 1 2, passenger/cargo 1 ,
petroleum tanker 39, refrigerated cargo 15, roll on/roll
off 8, short-sea passenger 1 , specialized tanker 1 ,
vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 2, Belgium 3,
British Virgin Islands 6, Cambodia 1 , China 38,
Cyprus 1 , Ecuador 1 , Egypt 1 , Equatorial Guinea 1 ,
Eritrea 1 , Estonia 7, Germany 3, Greece 4, G renada 1 ,
Honduras 1, Hong Kong 20, Indonesia 6, Italy 2,
Japan 4, Jordan 1 , Lebanon 1 , Liberia 5, Malaysia 3,
Malta 2, Man, Isle of 1 , Marshall Islands 1 3, Mexico 1 ,
Netherlands 1, Nigeria 1, Panama 12, Philippines 4,
Portugal 1 , Romania 1 , Russia 3, Saint Vincent and
the Grenadines 3, Saudi Arabia 1, Singapore 22,
South Korea 10, Spain 4, Switzerland 1, Taiwan 1,
Thailand 6, Tunisia 1 , T urkey 1 , Ukraine 3, United
Arab Emirates 9, United Kingdom 2, United States 4,
Virgin Islands (UK) 6, Yemen 1 (2002 est.)
Airports: 44(2001)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m:1
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 40
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 29 (2001)','8dcd4f852f4dafd7377a33a9ceadaf2d7511ecf59e0603c3acc8e48621927841','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfad85be1ea1f05820ecd88832d51e0ac7ac933bbec85cde9f079d8d512f1efe',2002,'BJ','Benin','transportation',195,'Railways:
total: 578 km
narrow gauge: 578 km 1.000-m gauge (2000 est.)
Highways:
total: 6,787 km
paved: 1 ,357 km (including 10 km of expressways)
unpaved: 5,430 km (1997 est.)
Waterways: streams navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none (2002 est.)
Airports: 5 (2001)
Airports • with paved runways:
total: 1
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 2 (2001)
Railways: 0 km
Highways:
total: 450 km
paved: NA
unpaved: NA
note: public roads - 209 km; private roads - 241 krfi
(2002)
Waterways: none
Ports and harbors: Hamilton, Saint George''s,
Dockyard
Merchant marine:
total: 102 ships (1 ,000 GRT or over) totaling
5,485,450 GRT/8, 782, 869 DWT
ships by type: bulk 28, cargo 4, container 1 6, liquefied
gas 6, passenger 3, petroleum tanker 17, refrigerated
cargo 16, roll on/roll off 9, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 5, Denmark 2,
Germany 1, Greece 1, Hong Kong 9, Indonesia 1,
Norway 2, Sweden 11, United Kingdom 52, United
States 13 (2002 est.)
Airports: 1 (2002)
Airports • with paved runways:
total: 1
2,438 to 2,047m: 1 (2960 m) (2002)','2aababf986d03ca6200c65ca06eb01ce26ca81626be506493ff52a4a10338666','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0a579e9605dcff20738cce6a6189ede5722d7faedc81e7a7675323a971c6b0f',2002,'BT','Bhutan','transportation',204,'Railways: 0 km
Highways:
total: 3,285 km
paved: 1 ,994 km
unpaved: 1,291 km (1996)
Waterways: none
Ports and harbors: none
Airports: 2(2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001 )','c4dfb51ebd870d56daf9c7235358a8ceaaf9842ae5b9ecd5319956e05616e8da','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4755098e2861328a48525cdcbf713aca5438bf42f4a0044771d19c7063fb910a',2002,'NP','Nepal','transportation',213,'Railways:
total: 3,691 km
narrow gauge: 3,652 km 1.000-m gauge; 39 km
0.760-m gauge {13 km electrified) (1995 est.)
Highways:
total: 49,400 km
payed: 2,500 km (including 30 km of expressways)
unpaved: 46,900 km (1996)
Waterways: 10,000 km (commercially navigable)
Pipelines: crude oil 1,800 km; petroleum products
580 km; natural gas 1 ,495 km
Ports and harbors: Puerto Aguirre (on the
Paraguay/Parana waterway, at the Bolivia/Brazil
border); also, Bolivia has free port privileges in
maritime ports in Argentina, Brazil, Chile, and','696f5131eb6c3042364dc814ad6ad6f97f2615d38fe7812e7ac60106d889e71e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a95c5ab2bcfc0e750e91e2a69d11ddf6c4e005e22742d5cd3c039ce690d652b8',2002,'PY','Paraguay','transportation',214,'Merchant marine:
total : 36 ships (1 ,000 GRT or over) totaling 1 96,399
GRT/320,137 DWT
ships by type: bulk 3, cargo 15, chemical tanker 2,
container 1 , petroleum tanker 13, roll on/roll off 2
note: includes some foreign-owned ships registered
here as a flag of Belize 2, China 2, Cuba 1 , Cyprus 1 ,
Egypt 1, Honduras 1, Latvia 2, Liberia 2, Panama 1,
Saint Vincent and the Grenadines 1 , Saudi Arabia 1 ,
Singapore 1 , South Korea 3, Switzerland 1 , Ukraine 1 ,
United Arab Emirates 5, United States 1 (2002 est.)
Airports: 1,109(2001)
Airports - with paved runways:
total: 13
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2(2001)
Airports - with unpaved runways:
tote/: 1 ,096
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 65
914 to 1,523 m: 236
under 914 m: 790 (2001)','aeecefe33888ae070e41bc607d25ddef5ac05684d6edd8601ddb870b31a1a968','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01ad5adef5c63713baac6f508dd59a3822ee6adc61b11b5b2fb9860f92148c61',2002,'IT','Italy','transportation',224,'Railways:
total: 1 ,021 km (795 km electrified; operating as diesel
or steam until grids are repaired)
standard gauge: 1,021 km 1.435-m gauge; note -
many segments still need repair and/or reconstruction
because of war damage (2000 est.)
Highways:
total: 21,846 km
paved: 14,020 km
unpaved: 7,826 km
note: road system is in need of maintenance and
repair (2001)
Waterways: NA km; large sections of the Sava
blocked by downed bridges, silt, and debris
Pipelines: crude oil 174 km; natural gas 90 km
(1992)
Ports and harbors: Bosanska Gradiska, Bosanski
Brad, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava), Orasje
Merchant marine: none (2002 est.)
Airports: 27(2001)
Airports - with paved runways:
total: 6
2,438 to 3,047m: 4
1,524 to 2,437 m: 1
under 91 4 m: 3 (2001)
Airports - with unpaved runways:
total: 19
1,524 to 2,437 m: 1
914 to 1,523 m:7
under 914 m: 11 (2001)
Heliports: 5(2001)
Railways:
total: 888 km
narrow gauge: 888 km 1.067-m gauge (2000 est.)
Highways:
total: 10,217 km
paved: 5,620 km
unpaved: 4,597 km (1999)
Waterways: none
Ports and harbors: none
Airports: 92(2001)
Airports - with paved runways:
total: 11
2,438 to 3,047 m: 2
1,524 to 2,437 m: 8
914 to 1,523 m: 1 (2001)
Airports • with unpaved runways:
total: 81
1,524 to 2,437 m: 3
914 to 1,523 m: 56
under 914 m: 22 (2001)
Railways:
total: 4,406 km
standard gauge: 3,440 km 1 ,435-m gauge
narrow gauge: 900 km 1.000-m gauge; 10 km
0.800-m gauge
dual gauge: 56 km 1.435-m and 1.000-m gauges (3
rail system)
note: Swiss railways are virtually all electrified
(2001)
Highways:
total: 71 ,059 km (including 1 ,638 km of
expressways)
paved: 71, 059 km
unpaved: 0 km (1999)
Waterways: 65 km
note: The Rhine carries heavy traffic on the
Basel-Rheinfelden and Schaffhausen-Bodensee
stretches; there are also 12 navigable lakes
Pipelines: crude oil 314 km; natural gas 1 ,506 km
Ports and harbors: Basel
Merchant marine:
total: 26 ships (1 ,000 GRT or over) totaling 509,943
GRT/896,309 DWT
ships by type: bulk 15, cargo 6, chemical tanker 4,
petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience:, United Kingdom 6,
United States 1 (2002 est.)
Airports: 66(2001)
Airports - with paved runways:
fofa/:42
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 11
914 to 1,523 m: 8
under 914 m: 15 (2001)
Airports - with unpaved runways:
total: 24
under 914 m: 24 (2001)''
Heliports: 1 (2001)
Railways:
total: 2,750 km
standard gauge: 2,423 km 1.435-m gauge
narrow gauge: 327 km 1.050-m gauge
note: rail link between Syria and Iraq replaced in 2000
(2001)
Highways:
total: 41,451 km
paved: 9,575 km (including 877 km of expressways)
unpaved: 31,876 km (1997)
Waterways: 870 km (minimal economic importance)
Pipelines: crude oil 1,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia, Tartus
Merchant marine:
total: 143 ships (1 ,000 GRT or over) totaling 482,985
GRT/702,590 DWT
ships by type: bulk 12, cargo 126, livestock carrier 4,
roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 1, Greece 2,
Italy 1, Lebanon 10 (2002 est.)
Airports: 99(2001)
Airports • with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 75
1,524 to 2,437 m: 2
914 to 1,523 m:M
under 914 m: 62 (2001)
Heliports: 2(2001)','8166c9f7147c305f51e7fa1b1932373d3efbf2671cebcc503bc2260d7a7f991d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f29ecab44ee264a0b9b1d703691bea1e5f2a7c09cd5b82f3ade329ded3ae124',2002,'SR','Suriname','transportation',233,'Waterways: none
Ports and harbors: none; offshore anchorage only
Railways:
total: 5,995 km
narrow gauge: 4,595 km 1 ,067-m gauge; 1 ,400 km
0.600-m gauge plantation line
note: the 1.067-m line from Khartoum to Port Sudan
carries over two-thirds of Sudan''s rail traffic; the
0.600-m gauge system serves Sudan''s cotton
plantations with over 120 collecting stations (2001)
Highways:
total: 11,900 km
paved: 4,320 km
unpaved: 7,580 km (1996)
Waterways: 5,310 km
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 39,545
GRT/51 ,195 DWT
ships by type: cargo 2, roll on/roil off 2 (2002 est.)
Airports: 65(2001)
Airports - with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (2001)
Airports - with unpaved runways:
total: 53
1,524 to 2,437 m: 16
914 to 1,523 m: 26
under 914 m: 11 (2001)
Heliports: 1 (2001)','15e63fd8e72f23ab3061d0bb69a134810dd76ba014ccb82f9547cd5444c8bdb0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d183a7c81ba6ad68f73033592247f14b9c7cb45f1e182d73ba2966c4cb9b77db',2002,'NO','Norway','transportation',242,'Railways:
total: broad gauge: 5,679 km 1 .600-m gauge (1 ,1 99
km electrified)
standard gauge: 194 km 1 .440-m gauge
narrow gauge: 24,666 km 1 ,000-m gauge (930 km
electrified)
dual gauge: 336 km 1 ,000-m and 1 .600-m gauges
(three rails)
note: in addition to the interurban routes itemized
above, Brazil has 247.8 km of suburban railway
consisting of 170.8 km of 1 .600-m gauge (75 km
electrified) and 77 km of 1 ,000-m gauge (1999 est.)
Highways:
tofa/:1.98 million km
paved: 184,140 km
unpaved: 1,795,860 km (1996)
Waterways: 50,000 km
Pipelines: crude oil 2,980 km; petroleum products
4,762 km; natural gas 4,246 km (1998)
Ports and harbors: Belem, Fortaleza, llheus,
Imbituba, Manaus, Paranagua, Porto Alegre, Recife,
Rio de Janeiro, Rio Grande, Salvador, Santos, Vitoria
Merchant marine:
total: 1 65 ships (1 ,000 GRT or over) totaling
3,662,570 GRT/5, 875, 933 DWT
72
Brazil (continued)
ships by type: bulk 32, cargo 25, chemical tanker 5,
combination ore/oil 9, container 12, liquefied gas 1 1,
multi-functional large-load carrier 1, passenger/cargo
5, petroleum tanker 54, roll on/roll off 10, short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Chile 2, Germany 6,
Greece 1 , Monaco 1 (2002 est.)
Airports: 3,365(2001)
Airports - with paved runways:
total: 627
over 3,047 m: 6
2,438 to 3,047 m: 21
1,524 to 2,437 m: 153
914 to 1,523 m: 407
under 914 m: 40 (2001)
Airports - with unpaved runways:
total: 2,738
1,524 to 2,437 m:72
914 to 1,523 m: 1,316
under 914 m: 1,350 (2001)
Railways:
total: 23,654 km (15,895 km electrified)
standard gauge: 3,059 km 1 ,435-m gauge (entirely
electrified)
narrow gauge: 77 km 1 ,372-m gauge (entirely
electrified): 20,491 km 1 ,067-m gauge (12,732 km
electrified); 27 km 0.762-m gauge (entirely electrified)
(2000)
Highways:
total: 1,152,207 km
paved: 863,003 km (including 6,1 1 4 km of
expressways)
unpaved: 289,204 km (1997 est.)
Waterways: 1 ,770 km approximately
note: seagoing craft ply all coastal inland seas
Pipelines: crude oil 84 km; petroleum products 322
km; natural gas 1,800 km
Ports and harbors: Akita, Amagasaki, Chiba,
Hachinohe, Hakodate, Higashi-Harima, Himeji,
Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide,
Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 61 5 ships (1 ,000 GRT or over) totaling
10,995,839 GRT/14,405,1 59 DWT
ships by type: bulk 1 33, cargo 48, chemical tanker 1 7,
combination bulk 24, combination ore/oil 3, container
1 9, liquefied gas 50, passenger 9, passenger/cargo 2,
petroleum tanker 189, refrigerated cargo 13, roll on I
roll off 48, short-sea passenger 6, vehicle carrier 54
note: includes some foreign-owned ships registered
here as a flag of convenience: China 1 , Panama 1 ,
Singapore 1 (2002 est.)
Airports: 173(2001)
Airports • with paved runways:
total: 142
over 3,047 m: 7
2,438 to 3,047 m: 37
1,524 to 2,437 m: 37
914 to 1,523 m: 30
under 914 m: 31 (2001)
Airports • with unpaved runways:
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 27 (2001)
Heliports: 16(2001)
Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area in the
middle of the west coast and another near the
southwest corner of the island
Transportation - note: there is a day beacon near
the middle of the west coast','c82535f63bce7d5ce3abc863d7ca9e8a008a33dc2253480c4593b5fed02fbafe','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b590609362a879426706bead22089d75ed6589c16e617d372c41705331fc024',2002,'IO','British Indian Ocean Territory','transportation',251,'Highways:
total: NA km
paved: short stretch of paved road of N A km between
port and airfield on Diego Garcia
unpaved: NA km
Waterways: none
Ports and harbors: Diego Garcia
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Railways: 0 km
Highways:
total: 177 km
paved: 177 km
unpaved: 0 km (2000)
Waterways: none
Ports and harbors: Road Town
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 70,285 GRT I
6,946 DWT
ships by type: passenger 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
914 to 1,523 m: 1
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Railways:
total: 13 km (private line)
narrow gauge: 13 km 0.61 0-m gauge (2001 est.)
Highways:
total: 1,712 km
paved: 1,284 km
unpaved: 428 km (1996)
Waterways: 209 km; navigable by craft drawing less
than 1.2 m
Pipelines: crude oil 135 km; pelroleum products 418
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 348,476
GRT/340,635 DWT
ships by type: liquefied gas 7
note: includes some foreign-owned ships registered
here as a flag of convenience: United Kingdom 7
(2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Heliports: 3(2001)','12d310f580fe849c4ac43db20ca30a6082cd8a96ed23618496758f20d05e3c3d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df722901b729363707672156d60eadb1a325ed46011e65195eab7a7bd7299419',2002,'BG','Bulgaria','transportation',263,'Railways:
total: 4,294 km
standard gauge: 4, 049 km 1.435-m gauge (2,710 km
electrified)
narrow gauge: 245 km 0.760-m gauge (2002)
Highways:
total: 37,288 km
paved : 33,786 km (including 324 km of expressways)
unpaved: 3,502 km (2001)
Waterways: 470 km (1987)
Pipelines: petroleum products 525 km; natural gas
1,500 km (1999)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 77 ships (1 ,000 GRT or over) totaling 881 ,758
GRT/1,312,833 DWT
ships by type: bulk 43, cargo 15, chemical tanker 4,
container 2, passenger/cargo 1 , petroleum tanker 4,
railcar carrier 2, refrigerated cargo 1, roll on/roll off 3,
short-sea passenger 1, specialized tanker 1
(2002 est.)
Airports: 215(2001)
Airports • with paved runways:
tofa/: 1 29
over 3,047 m: 1
2,438 to 3,047 m: 19
1,524 to 2, 437 m: 15
914 to 1,523 m: 1
under 914 m: 93 (2001)
Airports -with unpaved runways:
total: 86
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m:74 (2001)
Heliports: 1 (2001)','9064cb94b40d6da04af6c86f413a04db6d0c3ecc1402b8077a07c0636efcb594','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d8e8e94085b95ef757f385bd97ab05fd99d9d2d2b2cfa99667efe147e743bc8',2002,'ET','Ethiopia','transportation',268,'Railways:
total: 622 km (51 7 km from Ouagadougou to the Cote
d’Ivoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km 1.000-m gauge (1995 est.)
Highways:
total: 12,506 km
paved: 2,001 km
unpaved: 1 0,505 km (1 996)
Waterways: none
Ports and harbors: none
Airports: 33(2001)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 31
1,524 to 2,431m: 3
914 to 1,523 m: 12
under 914 m: 16 (2001)
82
Burkina Faso (continued)
Railways:
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1.000-m gauge
note: in 1998, Djibouti and Ethiopia announced plans
to revitalize the century-old railroad that links their
capitals and since then Ethiopia has expended
considerable effort to repair and maintain the lines; in
2001 , Ethiopia and Sudan agreed to build a line from
Ethiopia to Port Sudan (2000 est.)
Highways:
total: 24,145 km
paved: 3,290 km
unpaved: 20,855 km (1998)
Waterways: none
Ports and harbors: none; Ethiopia is landlocked
and was by agreement with Eritrea using the ports of
Assab and Massawa; since the border dispute with
Eritrea flared, Ethiopia has used the port of Djibouti for
nearly all of its imports
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 81 ,933
GRT/101 ,287 DWT
ships by type: cargo 5, container 1 , petroleum
tanker 1 , roll on/roll off 2 (2002 est.)
Airports: 86(2001)
Airports - with paved runways:
total: 14
over 3,047m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 72
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 33
under 914 m: 22 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Railways: Okm
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1996)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none (2002 est.)
Airports: 28(2001)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 20 (2001)
Railways: 0 km
Highways:
total: 320 km
paved: 21 8 km
unpaved: 102 km (1996)
Waterways: none
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 41 ships (1,000 GRT or over) totaling 169,991
GRT/245,996 DWT
ships by type: bulk 6, cargo 23, chemical tanker 1,
container 3, livestock carrier 1 , petroleum tanker 3,
refrigerated cargo 1 , roll on/roll off 2, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 1 , Greece 1 ,
Kenya 1, Portugal 1, Syria 1, Turkey 1 (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m:1 (2001)','466aabe7b4a8dfaacbdafc88f0b99a0bc996441ceef9e2336af9357d1268d535','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ae76acdb7fd871a08cdb2ce5fb2aed3da27dbb056eda194c754e9bd85cdf71',2002,'TH','Thailand','transportation',276,'Railways:
total: 3,991 km
narrow gauge: 3,991 km 1 ,000-m gauge (2000 est.)
Highways:
total: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1 996)
Waterways: 12,800 km
note: 3,200 km navigable by large commercial
vessels
Pipelines: crude oil 1 ,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk,
Mandalay, Moulmein, Myitkyina, Rangoon, Akyab
(Sittwe), Tavoy
Merchant marine:
total: 35 ships (1 ,000 GRT or over) totaling 382,386
GRT/582,084 DWT
ships by type: bulk 9, cargo 21 , container 1 ,
passenger/cargo 3, petroleum tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 5, Japan 4
(2002 est.)
Airports: 80(2001)
Airports - with paved runways:
total: 8
over 3,047 m: 2
2,438 to 3,047m: 2
1,524 to 2,437 m: 4
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
total: 72
over 3,047 m: 2
1,524 to 2,437m: 16
914 to 1,523 m: 21
under 914 m: 33 (2001)
Heliports: 2(2001)
Railways: 0 km
Highways:
total: 14,480 km
paved: 1 ,028 km
unpaved: 13,452 km (1996)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 7(2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
87
Burundi (continued)
Airports - with unpaved runways:
total: 6
91 4 to 1,523 m: 3
under 914 m: 3 (2001)
Railways: 0 km (2001)
Highways:
total: 14,000 km
paved: 3,360 km
unpaved: 10,640 km (1991)
Waterways: 4,587 km approximately
note: primarily Mekong and tributaries; 2,897
additional km are intermittently navigable by craft
drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 2,370 GRT/
3,110 DWT
ships by type: cargo 1 (2002 est.)
Airports: 51 (2001)
Airports • with paved runways:
total: 9
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2001)
Airports - with unpaved runways:
total: 42
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 914 m: 26 (2001)
Railways:
total: 3,569 km .
narrow gauge: 2,600 km 1 ,000-m gauge; 969 km
1.067-m gauge
note: the Tanzania-Zambia Railway Authority
(TAZARA), which operates 1,860 km of 1.067-m
narrow gauge track between Dar es Salaam and
Kapiri Mposhi in Zambia (of which 969 km are in
Tanzania and 891 km are in Zambia) is not a part of
Tanzania Railways Corporation; because of the
difference in gauge, this system does not connect to
Tanzania Railways (2001)
Highways:
total: 85,000 km
paved: 4,250 km
unpaved: 80,750 km (2001)
Waterways:
note: Lake Tanganyika, Lake Victoria, and Lake
Nyasa are principal avenues of commerce between
Tanzania and its neighbors on those lakes
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam,
Kigoma, Kilwa Masoko, Lindi, Mtwara, Mwanza,
Pangani, Tanga, Wete, Zanzibar
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 21 ,987
GRT/27,121 DWT
ships by type: cargo 2, passenger/cargo 2, petroleum
tanker 2, roll on/roll off 1 , short-sea passenger 1
(2002 est.)
Airports: 125(2001)
Background: A unified Thai kingdom was
established in the mid-14th century. Known as Siam
until 1939, Thailand is the only Southeast Asian
country never to have been taken over by a European
power. A bloodless revolution in 1932 led to a
constitutional monarchy. In alliance with Japan during
World War II, Thailand became a US ally following the
conflict.
Railways:
total: 4,071 km
narrow gauge: 4,071 km 1.000-m gauge (‘2001)
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1,615 km (1996)
Waterways: 4,000 km
note: 3,701 km are navigable throughout the year by
boats with drafts up to 0.9 meters; numerous minor
waterways serve shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhla
Merchant marine:
total: 297 ships (1,000 GRT or over) totaling
1,661 ,314 GRT/2, 564, 820 DWT
ships by type: bulk 34, cargo 1 33, chemical tanker 3,
combination bulk 1, container 14, liquefied gas 20,
multi-functional large-load carrier 2, passenger 1 ,
petroleum tanker 65, refrigerated cargo 16, roll on/roll
off 2, short-sea passenger 2, specialized tanker 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Greece 1 ,
Indonesia 1, Japan 1, Norway 24, Panama 1,
Singapore 1 (2002 est.)
Airports: 110(2001)
Airports - with paved runways:
total: 59
over 3,047 m: 7
2,438 to 3,047 m: 10
1,524 to 2,437 m: 22
914 to 1,523 m: 16
under 914 m: 4(2001)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m:1
914 to 1,523 m: 19
under 914 m: 31 (2001)
Heliports: 2(2001)
Railways:
total: 525 km
narrow gauge: 525 km 1 ,000-m gauge (2001 )
Highways:
total: 7,520 km
paved: 2,376 km
unpaved: 5,144 km (1996)
Waterways: 50 km (Mono river)
Ports and harbors: Kpeme, Lome
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 2,603 GRT /
2,800 DWT
ships by type: specialized tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Greece 1 (2002 est )
Airports: 9(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 2 (2001)
Airports - with unpaved runways:
total : 7
914 to 1,523 m: 5
under 914 m:2{2001)','1521014a5b71507e72146e2e8487038429d865932c9c34521a024670422d4783','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e33d22e4e4cd5a0b19c50ad5ffd580c782164b1992627576c6820256288c96d',2002,'KH','Cambodia','transportation',289,'Railways:
total: 603 km
narrow gauge: 603 km 1.000-m gauge (2001 est.)
Highways:
total: 35,769 km
paved: 4,165 km
unpaved: 31,604 km (1997)
Waterways: 3,700 km
note: navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1 .8 m
Ports and harbors: Kampong Saom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine:
total: 404 ships (1 ,000 GRT or over) totaling
1,889,404 GRT/2, 740,232 DWT
ships by type: bulk 37, cargo 31 2, chemical tanker 2,
combination bulk 5, container 7, liquefied gas 1 ,
livestock carrier 2, multi-functional large-load carrier
1, passenger/cargo 1, petroleum tanker 15,
refrigerated cargo 10, roll on/roll off 9, short-sea
passenger 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Aruba 1 , Belize 8,
British Virgin Islands 1, Bulgaria 3, China 21, Cyprus
15, Denmark 1 , Egypt 7, Estonia 1 , Georgia 1 ,
Germany 1, Greece 12, Honduras 5, Hong Kong 12,
Iceland 1 , Indonesia 2, Iran 1 , Ireland 1 , Italy 1 , Japan
5, Jordan 1 , Latvia 2, Lebanon 5, Liberia 5, Lithuania
1, Malta 1 , Netherlands 1, Noway 2, Panama 7,
Romania 4, Russia 67, Saint Kitts and Nevis 10, Saint
Vincent and the Grenadines 4, Singapore 15, South
Korea 24, Syria 1 3, Thailand 1 , T urkey 22, Ukraine 1 3,
United Arab Emirates 2, United Kingdom 1, United
States 5, Vietnam 2, Virgin Islands (UK) 1 (2002 est.)
Airports: 20(2001)
Airports - with paved runways:
total: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
fofaM5
1,524 to 2,437 m: 1
914 to 1,523 m : 13
under 914 m: 1 (2001)
Heliports: 2(2001)
Railways:
total: 1,104 km
narrow gauge: 1,104 km 1.000-m gauge (1995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,01 2 km (1995)
Waterways: 2,090 km (of decreasing importance)
Ports and harbors: Bonaberi, Douala, Garoua,
Kribi, Tiko
Airports: 49(2001)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 91 4 m: 1 (2001)
92
Cameroon (continued)
Airports - with unpaved runways:
total: 38
1,524 to 2,437 m: 7
91 4 to 1,523 m: 21
under 914 m: 10 (2001)','4a315cc9aa586d737a42c0f720b89dcca9d3040f4fa1ec417e4b9698b380433e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0dbb0f62146c74abd64c2ccbcd1d21a23b958d986e21846375ae8b753c92e3f',2002,'US','United States','transportation',300,'Railways:
fofaf: 36,1 14 km
standard gauge: 36,1 14 km 1 ,435-m gauge (1 56 km
electrified)
note: Canada has two major transcontinental freight
railway systems: Canadian National (privatized
November 1995) and Canadian Pacific Railway;
passenger service is provided by the
government-operated firm VIA, which has no trackage
of its own (2000 est.)
Highways:
fofal:901,902km
paved: 31 8,371 km (including 16,571 km of
expressways)
unpaved: 583,531 km (1999)
Waterways: 3,000 km (including Saint Lawrence
Seaway)
Pipelines: crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine:
total: 122 ships (1 ,000 GRT or over) totaling
1,797,240 GRT/2, 680, 223 DWT
ships by type: barge carrier 1 , bulk 66, cargo 1 3,
chemical tanker 5, combination bulk 2, passenger 2,
passenger/cargo 1 , petroleum tanker 18, railcar
carrier 2, roll on/roll off 8, shorl-sea passenger 3,
specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 3, Monaco
16, United Kingdom 1 , United States 1 (2002 est.)
Airports: 1,419(2001)
Airports - with paved runways:
total: 519
over 3,047 m: 18
2,438 to 3,047 m: 16
1,524 to 2,437 m: 151
914 to 1,523 m: 244
under 914 m: 90 (2001)
Airports - with unpaved runways:
total: 900
1,524 to 2,437m: 74
914 to 1,523 m: 364
under 914 m: 462(2001)
Heliports: 18(2001)
Railways:
total: 212,433 km mainline routes
standard gauge: 212,433 km 1.435-m gauge
note: represents the aggregate length of roadway of
all line-haul railroads including an estimate for Class II
and III railroads (1998)
Highways:
total: 6,370,031 km
paved: 5,733,028 km (including 74,091 km of
expressways)
unpaved: 637,003 km (1997)
Waterways: 41,009 km
note: navigable inland channels, exclusive of the
Great Lakes
Pipelines: petroleum products 276.000 km; natural
gas 331 ,000 km (1991)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago. Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 264 ships (1,000 GRT or over) totaling
6,911,641 GRT/9, 985, 660 DWT
ships by type: barge carrier 1 , bulk 1 1 , cargo 14,
chemical tanker 1 6, collier 1 , combination bulk 4,
combination tanker 11, container 86, multi-functional
large-load carrier 4, passenger/cargo 2, petroleum
tanker 81, roll on/roll off 28, specialized tanker 3,
vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Canada 4,
Denmark 1 5, France 1 , Germany 1 , Netherlands 3,
Norway 7, Puerto Rico 4, Singapore 1 1 , Sweden 1 ,
United Kingdom 3 (2002 est.)
Airports: 14,695(2001)
Airports - with paved runways:
fofaf: 5,127
over 3,047 m: 183
2,438 to 3,047 m: 222
1,524 to 2,437 m: 1 ,342
914 to 1,523 m: 2,413
under 914 m:967 (2001)
Airports - with unpaved runways:
fofaf: 9,568
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 165
914 to 1,523 m: 1,679
under 914 m: 7,716 (2001)
Heliports: 132(2001)','61facb7cd98546b183fab44f252a1c557bc51c1b612a13993caec2382ff4282e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b7ff90d15daa09d92da9cbea6f3c8e6055febce4cc5a52128183b92f1c039c1',2002,'PT','Portugal','transportation',305,'Railways: 0 km
Highways:
total: 1,100 km
paved: 858 km
unpaved: 242 km (1996)
Waterways: none
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,395 GRT /
6,614 DWT
ships by type: cargo 3, chemical tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United Kingdom 1
(2002 est.)
Airports: 9
note: 3 airports are reported to be nonoperational
(2001)
Airports - with paved runways:
total: 3
over 3,047 m: 1
914 to 1, 523 m: 2 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 3 (2001)
Railways:
total: 2,850 km
broad gauge: 2,576 km 1.668-m gauge (623 km
electrified; 426 km double-tracked)
narrow gauge: 274 km 1.000-m gauge (2001)
Highways:
total: 68,732 km
paved: 59,1 10 km (including 797 km of expressways)
unpaved: 9,622 km (1999)
Waterways: 820 km
note: relatively unimportant to national economy,
used by shallow-draft craft limited to 300 metric-ton or
less cargo capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
note: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 140 ships (1 ,000 GRT or over) totaling
1,001 ,440 GRT/1 ,519,701 DWT
ships by type: bulk 10, cargo 71, chemical tanker 17,
container 10, liquefied gas 8, multi-functional
large-load carrier 1, petroleum tanker 10, refrigerated
cargo T, roll on/roll off 6, short-sea passenger 4,
vehicle carrier 2
note: includes some foreign-owned ships registered
here as aflag of convenience: Belgium 1 , British Virgin
Islands 1 , Cyprus 1 , Denmark 6, Germany 20, Greece
1 , Iceland 1 , Italy 1 6, Lebanon 1 , Liberia 1 , Monaco 2,
Norway 5, Panama 5, Spain 22, Switzerland 8, United
Kingdom 1, Virgin Islands (UK) 1 (2002 est.)
Airports: 67(2001)
Airports - with paved runways:
total: 40
over 3,047m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m:7 (2001)
Airports - with unpaved runways:
total: 27
914 to 1,523 m;1
under 914 m: 26 (2001)','65cffde639715529632a16e2798a6d0e41817706ffcf7b5fb15bbff6e0dbd221','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce94620ce25905ad908fd74773584ed107c7e5c987480b9a841ae0b59594ce03',2002,'HN','Honduras','transportation',316,'Railways: 0 km
Highways:
total: 406 km
paved: 304 km
unpaved: 102 km
Waterways: none
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 1 21 ships (1 ,000 GRT or over) totaling
2,034,181 GRT/3,191,597 DWT
ships by type: bulk 24, cargo 4, chemical tanker 34,
container 1, liquefied gas 1, petroleum tanker 14,
refrigerated cargo 40, roll on/roll off 2, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Bahrain 2, China 1,
Germany 4, Greece 27, Hong Kong 3, Italy 2, Japan
1, Norway 14, Sweden 13, United Kingdom 15, United
States 35 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2(2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
M i I ft a r y
Military branches: no regular indigenous military
forces; Royal Cayman Islands Police Force (RCIPF)
Military - note: defense is the responsibility of the
UK
Railways: 0 km
Highways:
tofa/: 23,810 km
paved; 429 km
unpaved: 23,381 km (2000)
Waterways: 900 km
note: traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important
river, navigable all year to craft drawing 0.6 m or less;
282 km navigable to craft drawing as much as 1 .8 m
Ports and harbors: Bangui, Nola, Salo, Nzinga
Airports: 51 (2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2001 )
Airports • with unpaved runways:
total: 48
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 23
under 914 m: 15 (2001)
Railways: Okm
Highways:
total: 33,400 km
paved: 4 50 km
unpaved: 32,950 km
note: probably no more than 8,000 km of the total
receive maintenance, the remainder being desert
tracks (2000)
Waterways: 2,000 km
Ports and harbors: none
Airports: 49(2001)
Airports - with paved runways:
total: 1
over 3,047 m: 2
2,438 to 3.047 m: 3
1,524 to 2,437 m: 1
under 914 m:1 (2001)
Airports - with unpaved runways:
total: 42
1,524 to 2.437 m: 12
914 to 1,523 m: 20
under 914 m: 10 (2001)
Railways:
total: 6,702 km
broad gauge: 2,831 km 1 .676-m gauge (1 ,317 km
electrified)
narrow gauge: 1 17 km 1.067-m gauge (28 km
electrified); 3,754 km 1.000-m gauge (37 km
electrified) (2000 est.)
Highways:
total: 79,800 km
paved: 11,012 km
unpaved: 68,788 km (1996)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 47 ships (1 ,000 GRT or over) totaling 669,670
GRT/931 ,647 DWT
ships by type: bulk 11, cargo 4, chemical tanker 10,
container 5, liquefied gas 2, passenger 3, petroleum
tanker 4, roll on/roll off 5, vehicle carrier 3, includes a
foreign-owned ship registered here as a flag of
convenience: Netherlands 1 (2002 est.)
Airports: 363(2001)
Airports - with paved runways:
total: 70
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 20
914 to 1,523 m: 22
under 914 m: 16 (2001)
Airports - with unpaved runways:
total: 293
over 3,047m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1 1
914 to 1,523 m: 60
under 914 m: 217 (2001)
Railways:
total: 595 km
narrow gauge: 318 km 1.067-m gauge; 277 km
0.914-m gauge (2000)
Highways:
total: 15,400 km
paved: 3,126 km
unpaved: 12,274 km (1999 est.)
Waterways: 465 km (navigable by small craft)
Ports and harbors: La Ceiba, Puerto Castilla,
Puerto Cortes, San Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 284 ships (1 ,000 GRT or over) totaling 749,243
GRT/846,942 DWT
ships by type: bulk 20, cargo 1 66, chemical tanker 5,
container 6, livestock carrier 1 , passenger 3,
passenger/cargo 3, petroleum tanker 54, refrigerated
cargo 12, roll on/roll off 8, short-sea passenger 4,
specialized tanker 1 , vehicle carrier 1
note: includes some foreign-owried ships registered
here as a flag of convenience: Argentina 1 , Bahrain 1 ,
Belize 1, British Virgin Islands 1, Bulgaria 1, China 8,
Costa Rica 1, Cyprus 1, Egypt 6, El Salvador 1,
Germany 1, Greece 18, Hong Kong 3, Indonesia 2,
Italy 1, Japan 7, Lebanon 4, Liberia 4, Maldives 2,
Marshall Islands 1, Mexico 1, Nigeria 1, Norway 1,
Panama 14, Philippines 1, Romania 2, Russia 1, Saint
Kitts and Nevis 3, Saint Vincent and the Grenadines 1 ,
Singapore 24, South Korea 12, Spain 1, Syria 1,
Taiwan 4, Tanzania 1, Trinidad and Tobago 1,
Turkey 2, Turks and Caicos Islands 1 , United Arab
Emirates 6, United Kingdom 1, United States 5,
Vanuatu 1, Vietnam 1, Virgin Islands (UK) 1
(2002 est.)
Airports: 117(2001)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 4 (2001)
Airports - with unpaved runways:
total: 105
1,524 to 2,437 m: 2
914 to 1,523 m: 20
under 914 m: 83 (2001)','83266440701aed756fd6c921de2f43a838dafc9e59887e1a6bc202984f9eff41','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2911c5784fd5bdd6bdd08f88d0162450d9f0ad111739e8a9b116188a30241e1d',2002,'CN','China','transportation',326,'Railways:
total: 67,524 km (including 5,400 km of provincial
"local" rails)
standard gauge: 63,924 km 1.435-m gauge (13,362
km electrified; 20,250 km double-track)
narrow gauge: 3,600 km 0.750-m and 1 .000-m gauge
local industrial lines (1999 est.)
Highways:
total: 1 .4 million km
paved: 271 ,300 km (with at least 16,000 km of
expressways)
unpaved: 1 ,128,700 km (1999)
Waterways: 110,000 km (1999)
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Shenzhen, Tianjin, Wenzhou, Xiamen, Xin gang,
Yantai, Zhanjiang (2001)
Merchant marine:
total: 1 ,764 ships (1 ,000 GRT or over) totaling
16,915,047 GRT/25,366,296 DWT
ships by type: barge carrier 2, bulk 328, cargo 822,
chemical tanker 25, combination bulk 10, combination
ore/oil 1, container 134, liquefied gas 26,
multi-functional large-load carrier 6, passenger 7,
passenger/cargo 45, petroleum tanker 263,
refrigerated cargo 26, roll on/roll off 23, short-sea
passenger 42, specialized tanker 3, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 1 , Germany 1 ,
Hong Kong 16, Japan 2, Panama 2, South Korea 1,
Spain 1 , Taiwan 9, Tanzania 1, Turkey 1 (2002 est.)
Airports: 489(2001)
Airports - with paved runways:
total: 324
over 3,047m: 27
2,438 to 3,047 m: 88
1,524 to 2,437 m: 147
914 to 1,523 m: 30
under 914 m: 32 (2001)
Airports - with unpaved runways:
total: 165
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 29
914 to 1,523 m: 56
under 914 m: 78 (2001)
Railways:
total: 34 km
standard gauge: 34 km 1.435-m gauge (electrified
and double-tracked)
note: connects to China railway system at Hong
Kong-China border (2001)
Highways:
total: 1,831 km
paved: 1,831 km
unpaved: 0 km (1997)
Waterways: none
Ports and harbors: Hong Kong
Merchant marine:
total: 433 ships (1 ,000 GRT or over) totaling
13,539,257 GRT/22, 682, 757 DWT
ships by type: barge carrier 1 , bulk 264, cargo 38,
chemical tanker 1 0, combination bulk 2, container 73,
liquefied gas 8, multi-functional large-load carrier 1,
petroleum tanker 32, refrigerated cargo 1 , short-sea
passenger 1 , vehicle carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 5, Belize 1 ,
British Virgin Islands 1, China 115, Denmark 2,
Germany 19, Greece 2, India 8, Japan 8, Liberia 1,
Malaysia 7, Norway 1, Panama 2, Philippines 5,
Singapore 7, South Korea 2, Taiwan 1, United
Kingdom 27, Virgin Islands (UK) 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2, 437 m:1 (2001)
Heliports: 2 (2001)
Railways:
total: 677 km
narrow gauge: 677 km 1 .050-m gauge (2001 )
Highways:
total: 8,000 km
paved: 8,000 km
unpaved: 0 km (2000 est.)
Waterways: none
Pipelines: crude oil 209 km; note - may not be in use
Ports and harbors: Al ''Aqabah
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 41 ,206
GRT/53,401 DWT
ships by type: bulk 1 , cargo 3, container 1 , roll on/roll
off 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 6 (2002 est.)
Airports: 18(2001)
Airports - with paved runways:
total: 15
over 3,047 m: 7
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 3
under 914 m:3(2001)
Heliports: 1 (2001)
Railways:
total: NA km; short line going to a jetty
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)','e2a38b0fb6223300c38009d47b521fd6bce33ded08a45d2c18e8a8cc2dee8b7a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b6fe66f549414ff60275d717f0c10c9104bdfdca94d8ab539d915e9b6cead0b',2002,'CX','Christmas Island','transportation',335,'Railways: 24 km to serve phosphate mines
Highways:
total: 140 km (not including 100 km that is maintained
by private industry)
paved: 30 km
unpaved; 110 km (1999)
Waterways: none
Ports and harbors: Flying Fish Cove
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)','875f46a90cfe36e4deba9370ecb87eb5bf867a0492acef9a31a0801e8ad64497','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bde4a5818b5ed15cf37b8dc537d22135f0d6782161230ce86ecdcf22d8b2c294',2002,'FR','France','transportation',344,'Railways: 0 km
Highways:
total: 15 km (2001)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none; lagoon anchorage only
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Railways:
total: 660 km
narrow gauge: 660 km 1 .000-meter gauge; 25 km
double-track
note: an additional 600 km of this railroad extends into
Burkina Faso, ending at Kaya, north of Ouagadougou
(2000 est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,511 km (1996)
Waterways: 980 km (navigable rivers, canals, and
numerous coastal lagoons)
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Airports: 36(2001)
Airports • with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2001)
Airports ■ with unpaved runways:
total: 29
1,524 to 2,437 m:7
914 to 1,523 m: 13
under 914 m: 9 (2001)
Railways: 0 km
Highways:
total: 550 km
paved: at least 50 km
unpaved: NA (2002)
Waterways: none
Ports and harbors: Stanley
Merchant marine: none (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 22
2,438 to 3,047 m: 1
under 914 m:1 1 (2001)
Airports - with unpaved runways:
total: 3 3
under 914 m: 3(2001)
Railways: 0 km
Highways:
total: 1,817 km
paved: 81 7 km
unpaved: 1,000 km (1998)
Waterways: 3,300 km navigable by native craft
note: 460 km navigable by small oceangoing vessels
and coastal and river steamers
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none (2002 eSt.)
Airports: 11 (2001)
Airports - with paved runways:
total: 4
over 3,047m: 1
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5(2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 71 ships (1 ,000 GRT or over) totaling 2,815,472
GRT/4, 806,161 DWT
ships by type: bulk 5, cargo 5, chemical tanker 13,
container 1 1 , liquefied gas 7, petroleum tanker 19, roll
on/roll off 1 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 2, France 62,
Japan 3, Monaco 1 , Norway 5, Sweden 1 (2002 est.)
Airports: none (2001)
Railways:
total: NA km; privately owned, narrow-gauge
plantation lines
Highways:
total: 2,560 km
paved: 965 km
unpaved: 1,595 km (1996)
Waterways: none
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,240 GRT/
109 DWT
ships by type: passenger 1
note: includes a foreign-owned ship registered here
as a flag of convenience: France 1 (2002 est.)
Airports: 9(2001)
Airports - with paved runways:
total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Railways: 0 km (2002)
Highways:
total: 2,105 km (2000)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none (2002 est.)
Airports: 2(2001)
333
Martinique (continued)
Airports • with paved runways:
total: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Railways: 1,815 km
broad gauge: 1 ,815 km 1 .524-m gauge (2001)
Highways:
total: 3,387 km
paved: 1,563 km
unpaved: 1 ,824 km
note: there are also 45,862 km of rural roads that
consist of rough, unimproved, cross-country tracks
(2000)
Waterways: 400 km (1999)
Ports and harbors: none
Airports: 34(2001)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m: 1 (2001)
Airports • with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5(2001)
Railways: 0 km
Highways:
total: 2,724 km
paved: 1 ,300 km (including 73 km of four-lane road)
unpaved: 1,424 km
note: 370 km of road are maintained by national
authorities, 754 km by departmental authorities and
1,600 km by local authorities (1994)
Waterways: none
Ports and harbors: Le Port, Pointe des Galets
427
Reunion (continued)
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 28,264
GRT/44,885 DWT
ships by type: chemical tanker 1
note : includes a foreign-owned ship registered here
as a flag of convenience: France 1 (2002 est.)
Airports: 2 (2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2001)
Railways:
fofa/:2,168 km
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1 ,687 km 1 .000-m gauge
dual gauge: 10 km 1 .000-m and 1 ,435-m gauges
(three rails) (2001)
Highways:
tofa/: 23,100 km
paved: 18,226 km
unpaved: 4,874 km (1996)
Waterways: none
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 16 ships (1 ,000 GRT or over) totaling 150,710
GRT/1 62,616 DWT
ships by type: bulk 2, cargo 4, chemical tanker 4,
liquefied gas 1 , petroleum tanker 1 , short-sea
passenger 3, specialized tanker 1 (2002 est.)
Airports: 30(2001)
518
Tunisia (continued)
o
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3(2001)
Airports - with unpaved runways:
total: 16
1,524 to 2, 437 m: 2
914 to 1,523 m: 7
under 914 m: 7 (2001)
Railways:
total: 8,607 km
standard gauge: 8,607 km 1.435-m gauge (2,131 km
electrified) (2001)
Highways:
total: 382,059 km
paved: 1 06,976 km (including 1 ,726 km of
expressways)
unpaved: 275,083 km (1 999 est.)
Waterways: 1,200 km (approximately)
Pipelines: crude oil 1,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Icel (Mersin), Samsun,
Trabzon
Merchant marine:
total: 553 ships (1 ,000 GRT or over) totaling
5,674,099 GRT/9, 108, 81 9 DWT
ships by type: bulk 138, cargo 239, chemical
tanker 45, combination bulk 5, combination ore/oil 2,
container 27, liquefied gas 6, passenger/cargo 1 ,
petroleum tanker 45, refrigerated cargo 3, roll on/roll
off 27, short-sea passenger 10, specialized tanker 5
note: includes some foreign-owned ships registered
here as a flag of convenience; Belize 1 , Cyprus 1 ,
Denmark 2, Greece 1 , Italy 1 , Thailand 1 , United
Kingdom 1 1 (2002 est.)
Airports: 120(2001)
Airports - with paved runways:
total: 86
over 3,047 m: 16
2,438 to 3,047 m: 30
1,524 to 2,437 m: 19
914 to 1,523 m: 15
under 91 4 m: 6 (2001)
Airports - with unpaved runways:
total: 34
over 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 24 (2001)
Heliports: 6(2001)
Railways:
total: 16,878 km
standard gauge: 1 6,536 km 1 ,435-m gauge (4,928 km
electrified; 12,591 km double- or multiple-tracked)
broad gauge: 342 km 1 .600-m gauge (1 90 km
double-tracked)
note: all 1. 600-m gauge track is in common carrier
service in Northern Ireland (1996)
Highways:
tofa/:371,603 km
paved: 371 ,603 km (including 3,303 km of
expressways)
unpaved: 0 km (1998 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Glasgow,
Grangemouth, Hull, Leith, Liverpool, London,
Manchester, Peterhead, Plymouth, Portsmouth,
Scapa Flow, Southampton, Sullom Voe, Tees, Tyne
Merchant marine:
total: 212 ships (1 ,000 GRT or over) totaling
4,308,232 GRT/4, 171, 757 DWT
ships by type: bulk 7, cargo 32, chemical tanker 13,
combination ore/oil 1, container 53, liquefied gas 3,
passenger 13, passenger/cargo 1, petroleum tanker
48, refrigerated cargo 4, roll on/roll off 26, short-sea
passenger 10, specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Bermuda 1 , Cyprus 1 ,
Denmark 21 , Germany 6, Greece 3, Hong Kong 4,
Italy 1 , Monaco 4, Netherlands 1 , Norway 9, Russia 1 ,
South Africa 2, Sweden 1 1 , Taiwan 2, United States 5
(2002 est.)
Airports: 470(2001)
Airports - with paved runways:
total: 332
over 3,047 m: 8
2,438 to 3,047 m: 33
1,524 to 2,437 m: 150
914 to 1,523 m: 84
under 914 m: 57(2001)
Airports - with unpaved runways:
total: 138
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under914 m:114 (2001)
Heliports: 13(2001)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1,800 km (1997 est.)
note: Israelis have developed many highways to
service Jewish settlements
Waterways: none
Ports and harbors: none
Airports: 3(2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2001)','a58b718c8db70b7fe1be1a7b5d8a40c418ea22641a13fec6375a4635297e00fa','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06455cdb7fc08137388fbef56f4707385e964ef42a7d06b74cb64319663c978c',2002,'CO','Colombia','transportation',352,'Railways:
total: 3,304 km
standard gauge: 150 km 1,435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia de
Portete)
narrow gauge: 3,154 km0.914-m gauge (major
sections not in use) (2000 est.)
Highways:
tofa/: 1 1 0,000 km
paved: 26,000 km
unpaved: 84,000 km (2000)
Waterways: 18,140 km (navigable by river boats)
(April 1996)
Pipelines: crude oil 3,585 km; petroleum products
1 ,350 km; natural gas 830 km; natural gas liquids 125
km
Ports and harbors: Bahia de Portete, Barranquilla,
Buenaventura, Cartagena, Leticia, Puerto Bolivar,
San Andres, Santa Marta, Tumaco, Turbo
Merchant marine:
total: 11 ships (1,000 GRT or over) totaling 32,438
GRT/43,126 DWT
ships by type: bulk 5, cargo 3, container 1 , petroleum
tanker 2
note: includes a foreign-owned ship registered here
as a flag of convenience: Germany 1 (2002 est.)
Airports: 1,066(2001)
Airports - with paved runways:
total: 93
over 3,047m: 2
2,438 to 3,047 m: 9
1,524 to 2, 437 m: 37
91 4 to 1,523 m: 36
under 914 m: 9 (2001)
Airports - with unpaved runways:
total: 973
2,438 to 3,047 m: 1
1,524 to 2,437 m: 58
914 to 1,523 m: 312
under 914 m:602(2001)
Heliports: 1 (2001)','91e3667a28ec83174cca8d46a979766a714414b0936526760909f0c71ed48a24','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c41b24fc0f19bedc9e30fdc4684be82c9a9a0af6307f0dfff424e8b7a79e78f',2002,'MZ','Mozambique','transportation',363,'Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1996)
Waterways: none
Ports and harbors: Fomboni, Moroni,
Moutsamoudou
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 39,779
GRT/205,369 DWT
ships by type: cargo 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Malta 1 , Pakistan 1 ,
Turkey 1 (2002 est.)
Airports: 4(2001)
Airports • with paved runways:
total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2001)
Railways:
total: 3,1 31 km
narrow gauge: 2,988 km 1,067-m gauge; 143 km
0.762-m gauge (2001)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (1996)
Waterways: 3,750 km (navigable routes)
Pipelines: crude oil 306 km; petroleum products
289 km
note: not operating
Ports and harbors: Beira, Inhambane, Maputo,
Nacala, Pemba, Quelimane
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 4,125 GRT /
7,024 DWT
ships by type: cargo 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 2
(2002 est.)
Airports: 166(2001)
Airports - with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 144
2,438 to 3,047 m:1
1,524 to 2,437 m: 16
914 to 1,523 m: 37
under 914 m: 90 (2001)
Railways:
total: 1,108 km
narrow gauge: 1 ,1 08 km 1 .067-m gauge (51 9 km
electrified)
nofe: in addition to the above routes in common
carrier service, there are several thousand kilometers
of 1 .067-m gauge routes that are dedicated to
industrial use (2001)
Highways:
total: 34,901 km
paved: 31 ,271 km (including 538 km of expressways)
unpaved: 3,630 km (1998 est.)
Waterways: NA
Pipelines: petroleum products 3,400 km; natural gas
1,800 km (1999)
Ports and harbors: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, Tai-chung
Merchant marine:
total: 152 ships (1 ,000 GRT or over) totaling
4,262,451 GRT/6, 596, 950 DWT
ships by type: bulk 40, cargo 28, combination bulk 3,
container 53, petroleum tanker 17, refrigerated cargo
9, roll on/rolloff 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Hong Kong 3, Japan 1
(2002 est.)
Airports: 39(2001)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 9
1,524 to 2,437 m: 8
914 to 1,523 m: 8
under 914 m:3 (2001)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2001)
Heliports: 3(2001)','389a396623dc91d03a6e703d65288de3e083f836f0e90c87c30f367cba3838e5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8c00cb7245d8f11adce9373d4a4c18b05d2b1e61160722a8cfb219b7d77d770',2002,'CG','Congo','transportation',369,'Railways:
total: 5,138 km
narrow gauge: 3,987 km 1.067-m gauge (858 km
electrified); 125 km 1 ,000-m gauge; 1 ,026 km
0.600-m gauge
note: severely reduced route-distance in use because
of damage to facilities by civil strife (2000 est.)
Highways:
total: 157,000 km (including 30 km of
expressways)(1996)
paved: NA km
unpaved: NA km
Waterways: 1 5,000 km (including the Congo and its
tributaries, and unconnected lakes)
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Merchant marine: none (2002 est.)
Airports: 232(2001)
Airports • with paved runways:
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 15
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 208
1,524 to 2,437 m: 20
914 to 1,523 m: 96
under 914 m: 92 (2001)
Heliports: 1 (2001)
Railways:
total.'' 894 km
narrow gauge: 894 km 1 ,067-m gauge (2000 est.)
Highways:
total: 12,800 km
paved: 1,242 km
unpaved: 11,558 km (1996)
122
Congo, Republic of the (continued)
Waterways: 1,120 km
note: the Congo and Ubangi (Oubangui) rivers
provide 1,120 km of commercially navigable water
transport; other rivers are used for local traffic only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Airports: 33(2001)
Airports - with paved runways:
total: 4
over 3,047 m:1
1,524 to 2,437 m: 3(2001)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 12 (2001)','7d7a9da546220f15077fc3ab7cd691e0736ee86aa529d1a72cc83c12b66be1ce','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('806019909a42f6211fbe4f26e2b139500279edf57719de037c3dc42670d4411a',2002,'CK','Cook Islands','transportation',382,'Railways: Okm
Highways:
total: 320 km (1992)
paved: NA
unpaved: NA
Waterways: none
Ports and harbors: Avarua, Avatiu
Airports: 7(2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (2001)
124
Cook Islands (continued)','329e37fe84317ea23626fa13d894b5490234ff0945816eb3a56840aa6f0646a8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c880f6637c30477023d30dac1b971df14cd0ee6abc9356ce82f3eea1cc50249',2002,'CR','Costa Rica','transportation',390,'Railways:
total: 950 km
narrow gauge: 950 km 1 ,067-m gauge (260 km
electrified) (2000 est.)
Highways:
total: 37,273 km
paved: 7 ,827 km
unpaved: 29,446 km (1998 est.)
Waterways: 730 km (seasonally navigable)
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine:
to/a/: 1 ship (1,000 GRT or over) totaling 1,716 GRT/
NA DWT
ships by type: passenger 1 (2002 est.)
Airports: 152(2001)
Airports - with paved runways:
total: 29
2,438 to 3,047 m: 2
1,524 to 2,437 m:1
127
Costa Rica (continued)
914 to 1,523 m: 19
under 914 m: 7 (2001)
Airports - with unpaved runways:
total: 123
914 to 1,523 m: 28
under 914 m: 95 (2001)','52026f674d30b019b8acf148d7a8467a586f49129a7a350577ae4cd8c74024e9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1f80fc3b29b93aa62f19f81f359b0a51cff7c0b2adb332b500f8c7278e9941a',2002,'SI','Slovenia','transportation',402,'Railways:
total: 2,726 km
standard gauge: 2,726 km 1.435-m gauge (NA
electrified) (2000)
Highways:
total: 28,009 km
paved: 23,695 km (including 330 km of expressways)
unpaved: 4,314 km (2001)
Waterways: 785 km
note: (perennially navigable; large sections of Sava
blocked by downed bridges, silt, and debris)
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992)
Ports and harbors: Dubrovnik, Dugi Rat, Omisalj,
Ploce, Pula, Rijeka, Sibenik, Split, Vukovar (inland
waterway port on Danube), Zadar
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling 681 ,465
GRT/1 ,076,31 5 DWT
ships by type: bulk 14, cargo 13, chemical tanker 1,
combination bulk 5, container 1, multi-functional
large-load carrier 3, passenger 1 , petroleum tanker 2,
refrigerated cargo 2, roll on/roll off 4, short-sea
passenger 3
note: includes a foreign-owned ship registered here
as a flag of convenience: Hong Kong 1 (2002 est.)
Airports: 67(2001)
Airports • with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 8 (2001)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m: 37 (2001)
Heliports: 1 (2001)','0b5f825ec26d724e649991eb5c25c3e95ee7fca48189724847425640e49be8e9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d18700148f29159b06d82501719c7072c10d662f0ba96559c548e5472f9d0e',2002,'MX','Mexico','transportation',412,'Railways:
tote/: 4,807 km
standard gauge: 4,807 km 1.435-m gauge, in public
use (147 km electrified)
note: in addition to the 4,807 km of standard-gauge
track in public use, 7,162 km of track is in private use
by sugar plantations; about 90% of the private use
track is standard gauge and the rest is narrow gauge
(2000 est.)
Highways:
tote/: 60,858 km
paved: 29,820 km (including 638 km of expressway)
unpaved: 31 ,038 km (1997)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanillo, Mariel, Matanzas, Nuevitas, Santiago de
Railways:
total: 18,000 km
standard gauge: 18,000 km 1.435-m gauge (2001)
Highways:
total: 323,977 km
paved: 96,221 km (including 6,335 km of
expressways)
unpaved: 227,756 km (1997)
Waterways: 2,900 km
note: navigable rivers and coastal canals
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km
Ports and harbors: Acapulco, Altamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 44 ships (1 ,000 GRT or over) totaling 656,594
GRT/987,822 DWT
ships by type: bulk 3, cargo 1 , chemical tanker 4,
liquefied gas 3, petroleum tanker 27, roll on/roll off 3,
short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Canada 2, Denmark 1
(2002 est.)
Airports: 1,852(2001)
Airports - with paved runways:
total: 235
over 3,047 m:M
2.438 to 3,047 m: 28
1,524 to 2,437 m: 85
914 to 1,523 m: 86
under 914 m: 25 (2001)
Airports - with unpaved runways:
total: 1,617
over 3,047m: 1
2.438 to 3,047 m: 1
1,524 to 2,437 m: 69
914 to 1,523 m: 461
under 91 4 m: 1,085 (2001)
Heliports: 2 (2001)
342
Mexico (continued)
Railways:
total'' 23,420 km
broad gauge: 646 km 1 ,524-m gauge
standard gauge: 21 ,639 km 1 .435-m gauge (1 1 ,626
km electrified; 8,978 km double-tracked)
narrow gauge: 1 ,1 35 km various gauges including
1.000-m, 0.785-m, 0.750-m, and 0.600-m (2001)
Highways:
fofa/:381,046 km
paved: 249,966 km (including 268 km of
expressways)
unpaved: 131,080 km (1998)
Waterways: 3,812 km (navigable rivers and canals)
(1996)
Pipelines: crude oil and petroleum products 2,280
km; natural gas 17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Gliwice,
Kolobrzeg, Szczecin, Swinoujscie, Ustka, Warsaw,
Wroclaw
Merchant marine:
total: 19 ships (1,000 GRT or over) totaling 382,518
GRT/641 ,657 DWT
ships by type: bulk 14, cargo 3, chemical tanker 1 , roll
on/roll off 1 (2002 est.)
Airports: 122(2001)
418
Poland (continued)
Airports - with paved runways:
total: 83
over 3,047 m: 3
2,438 to 3,047 m: 29
1,524 to 2,437 m: 42
914 to 1,523 m: 6
under 91 4 m: 3(2001)
Airports - with unpaved runways:
total: 39
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 13
under 914 m: 21 (2001)
Heliports: 3(2001)','427000e8a98cb206c6d9acb99063fce658a0e1c4baecab0bb5b473e2cd38899e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae681fcac433b25294703875407008430f14bbf2937700f866b7aae0ef985f05',2002,'CU','Cuba','transportation',413,'Merchant marine:
total: 14 ships (1 ,000 GRT or over) totaling 44,187
GRT/63.416DWT
ships by type: bulk 3, cargo 6, liquefied gas 1,
petroleum tanker 1, refrigerated cargo 3 (2002 est.)
Airports: 172(2001)
Airports - with paved runways:
total: 78
over 3.047 m: 7
2,438 to 3,047 m: 8
1,524 to 2,437 m: 20
914 to 1,523 m: 7
under 914 m: 36 (2001)
Airports - with unpaved runways:
total: 94
914 to 1,523 m: 31
under 914 m: 63 (2001 )','c1dd8e9609f19891519984648de43ee750a0c27faf85571914a32db467a56aa0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53056d9a337b42bf8458df282701825d74909a3b482b99f40cda2663fc9d62c9',2002,'CY','Cyprus','transportation',421,'Railways: Okm
Highways:
total: Greek Cypriot area: 10,663 km (1 998 est.);
Turkish Cypriot area: 2,350 km (1996 est.)
paved: Greek Cypriot area: 6,249 km (1998 est.);
Turkish Cypriot area: 1 ,370 km (1 996 est.)
unpaved: Greek Cypriot area: 4,414 km (1998 est.);
Turkish Cypriot area: 980 km (1996 est.)
Waterways: none
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos
Merchant marine:
total: 1 ,254 ships (1 ,000 GRT or over) totaling
22,802,712 GRT/36,337,768 DWT
ships by type : barge carrier 2, bulk 438, cargo 378,
chemical tanker 24, combination bulk 31 , combination
ore/oil 2, container 133, liquefied gas 4, passenger 7,
passenger/cargo 1 , petroleum tanker 1 31 ,
refrigerated cargo 46, roll on/roll off 41 , short-sea
passenger 10, specialized tanker 3, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Austria 12, Belgium 2,
Bulgaria 2, Canada 3, Chile 2, China 16, Croatia 2,
Cuba 1 1 , Finland 1 , Germany 229, Greece 607, Guam
1 , Hong Kong 6, India 6, Iran 1 , Ireland 1 , Israel 5, Italy
1, Japan 26, Latvia 14, Lebanon 1, Lithuania 2,
Mexico 1 , Monaco 10, Netherlands 30, Norway 23,
Panama 1, Philippines 2, Poland 19, Portugal 2,
Russia 57, Singapore 2, Slovenia 2, South Korea 4,
Spain 7, Sudan 2, Sweden 6, Switzerland 4, Turkey 1 ,
Ukraine 1, United Arab Emirates 13, United Kingdom
6, United States 4, Vietnam 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 7
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m: 2(2001)
Heliports: 7(2001)
Railways:
total: 9,444 km
standard gauge : 9,350 km 1 ,435-m gauge (2,843 km
electrified; 1,929 km double-track)
narrow gauge: 94 km 0.760-m gauge (2000 est.)
Highways:
total: 55,432 km
paved: 55,432 km (including 499 km of expressways)
unpaved: 0 km (2000)
Waterways: 303 km
note: (the Labe (Elbe) is the principal river) (2000)
Pipelines: natural gas 3,550 km (2000)
Ports and harbors: Decin, Prague, Usti nad Labem
Airports: 121 (2001)
Airports - with paved runways:
total: 44
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 13
914 to 1,523 m: 2
under 914 m: 17 (2001)
Airports - with unpaved runways:
total: 77
1,524 to 2,437 m: 1
914 to 1,523 m: 28
under 914 m: 48 (2001)
Heliports: 1 (2001)','6c7c1ae646420863a8f65987479f41350f129f00334b03ab0e752e63b66650d8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1efac17f1a34ec0e30d92a9a6a8f75d9c412fdac5b2c48aa4613a3b051f2188',2002,'SE','Sweden','transportation',432,'Railways:
total: 2,859 km (508 km privately owned and
operated)
standard gauge: 2,859 km 1 ,435-m gauge (600 km
electrified; 760 km double-track) (1998 est.)
Highways:
total: 71,474 km
paved: 71 ,474 km (including 880 km of expressways)
unpaved: 0 km (1999)
Waterways: 417 km
Pipelines: crude oil 1 10 km; petroleum products 578
km; natural gas 700 km
Ports and harbors: Abenra, Alborg, Arhus,
Copenhagen, Esbjerg. Fredericia, Kolding, Odense,
Roenne (Bornholm), Vejle
Merchant marine:
total: 301 ships (1,000 GRT or over) totaling
6,258,959 GRT/8, 143, 520 DWT
ships by type: bulk 8, cargo 105, chemical tanker 26,
container 72, liquefied gas 20, livestock carrier 5,
petroleum tanker 25, railcar carrier 1 , refrigerated
cargo 13, roll on/roll off 16, short-sea passenger 7,
specialized tanker 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Greenland
1, Indonesia 1, Netherlands 1, Norway 9, United
Kingdom 1 (2002 est.)
Airports: 116(2001)
Airports - with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2001)
Airports • with unpaved runways:
total: 88
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m: 80 (2001)
Railways:
total: 100 km (Djibouti segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 100 km 1.000-m gauge
note: Djibouti and Ethiopia plan to revitalize the
century-old railroad that links their capitals by 2003
(2001 est.)
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996)
Waterways: none
Ports and harbors: Djibouti
Airports: 12(2001)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2001)
Railways: 0 km
Highways:
total: 780 km
paved: 390 km
unpaved: 390 km (2001)
Waterways: none
Ports and harbors: Portsmouth, Roseau
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2 (2001)','26cd2aed95bfb8f0022b68925256c9e1aa4fce759430410cb42aecabfbd1517b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e5a07aa36b78cd2df0009e144d4fe3509e7368bd0ae8912742808bde459ea58',2002,'DO','Dominican Republic','transportation',440,'Railways:
total: 757 km
standard gauge: 375 km 1 ,435-m gauge (Central
Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominican .
Republic Government Railway)
miscellaneous gauge: 240 km operated by sugar
companies in various gauges (0.558-m, 0.762-m,
1.067-m gauges) (2000 est.)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1996)
Waterways: none
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana,
Manzanillo, Puerto Plata, San Pedro de Macoris,
Santo Domingo
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,587 GRT/
1,165 DWT
ships by type: cargo 1 (2002 est.)
Airports: 29(2001)
Airports - with paved runways:
total: 13
over3,047m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 10 (2001)
Railways:
total: 96 km
narrow gauge: 96 km 1.000-m gauge,
note: rural, narrow-gauge system for hauling
sugarcane; no passenger service (2001)
Highways:
total: 14,400 km
paved: 14,400 km
unpaved: 0 km (1996)
Waterways: none
Ports and harbors: Guanica, Guayanilla, Guayama,
Playa de Ponce, San Juan
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 19,046 GRT/
22,582 DWT
ships by type: container 1 (2002 est.)
Puerto Rico (continued)
Airports: 30(2001)
Airports • with paved runways:
total: 19
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 11
914 to 1,523 m: 2
under 914 m: 9 (2001)','0e640488e4cc04fa4ceaa94b6d283ee178c07d9385f8926188b6e41ee8e15b74','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5920c2cf0dbbf95434fa59a5666670105a3ce7c8077170abba2bdc5c801d696f',2002,'ID','Indonesia','transportation',444,'Railways: Okm
Highways:
total: 3,800 km
paved: 428 km
unpaved: 3,372 km (1995)
Waterways: NA
Pipelines: NA
Ports and harbors: NA
Merchant marine:
total: NA
ships by type: NA
Airports: 8(2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,427 m: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 3
under 91 4 m: 2 (2001)
Heliports: 1 (2001)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km
electrified; 101 km double-track); 497 km 0.750-m
gauge (2001)
Highways:
total: 342,700 km
paved: 158,670 km
unpaved: 184,030 km (1997)
Waterways: 21,579 km total
note: Sumatra 5,471 km, Java and Madura 820 km,
Kalimantan 10,460 km, Sulawesi (Celebes) 241 km,
Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Makassar, Palembang, Semarang,
Surabaya
Merchant marine:
total: 668 ships (1 ,000 GRT or over) totaling
2,969,281 GRT/4,043,526 DWT
ships by type: bulk 41 , cargo 392, chemical tanker 12,
container 32, liquefied gas 3, livestock carrier 1 ,
passenger 8, passenger/cargo 14, petroleum tanker
126, refrigerated cargo 1 , roll on/roll off 1 5, short-sea
passenger 8, specialized tanker 9, vehicle carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 1 , Hong
Kong 2, India 1, Japan 2, Malaysia 1, Monaco 3,
Panama 1 , Philippines 1 , Singapore 1 1 , South
Korea 1, Switzerland 1, UK 2, US 1 (2002 est.)
Airports: 490(2001)
Airports - with paved runways:
total: 156
over 3,047 m: 4
2,438 to 3,047 m: 13
1,524 to 2,437 m: 46
914 to 1,523 m: 48
under 914 m: 45 (2001)
Airports • with unpaved runways:
total: 339
1,524 to 2,437 m: 3
914 to 1,523 m: 27
under 914 m: 309 (2001)
Heliports: 6 (2001)
Railways:
total: 6,130 km
broad gauge: 94 km 1 ,676-m gauge
standard gauge: 6,036 km 1.435-m gauge (187 km
electrified)
note: broad-gauge track is employed at the borders
with Azerbaijan and Turkmenistan which have
broad-gauge rail systems; 41 km of the
standard-gauge, electrified track is in suburban
service at Tehran (2001)
Highways:
total: 140,200 km
paved: 49,440 km (including 470 km of expressways)
unpaved: 90,760 km (1998 est.)
Waterways: 904 km
note: the Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been
dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzali, Bushehr, Bandar-e Emam
Khomeyni, Bandar-e Lengeh, Bandar-e Mahshahr,
Bandar-e Torkaman, Chabahar (Bandar Beheshti),
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sim,
Khorramshahr (limited operation since November
1992), Now Shahr
Merchant marine:
total: 147 ships (1 ,000 GRT or over) totaling
4,136,971 GRT/7, 166, 703 DWT
ships by type: bulk 48, cargo 36, chemical tanker 4,
container 10, liquefied gas 1, multi-functional
large-load carrier 6, petroleum tanker 30, refrigerated
cargo 2, roll on/roll off 9, short-sea passenger 1
(2002 est.)
Airports: 322(2001)
Airports - with paved runways:
total: MB
over 3,047 m: 40
2,438 to 3,047 m: 24
1,524 to 2,437 m: 24
914 to 1,523 m: 23
under 91 4 m: 7(2001)
Airports • with unpaved runways:
total: 204
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 124
under 914 m: 63 (2001)
Heliports: 11 (2001)
248
Iran (continued)
Highways:
total: 240 km
paved: 42 km
unpaved: 198 km (1996)
Waterways: none
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports:’ 7 (2001)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: 4
914 to 1,523 m:2 (2001)
344
Railways:
total: 897 km
narrow gauge: 897 km 1 ,067-m gauge (405 km are
not in operation) (2001)
Highways:
total: 199,950 km
paved: 39,590 km
unpaved: 160,360 km (1998 est.)
Waterways: 3,219 km
note: limited to vessels with a draft of less than 1 .5 m
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, Iloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 416 ships (1,000 GRT or over) totaling
5,179,029 GRT/7, 670, 688 DWT
ships by type: bulk 134, cargo 112, chemical tanker 2,
combination bulk 7, container 5, liquefied gas 9,
livestock carrier 9, passenger 4, passenger/cargo 10,
petroleum tanker 41 , refrigerated cargo 20, roll on/roll
off 14, short-sea passenger 29, specialized tanker 2,
vehicle carrier 18
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 2, Canada 1 ,
Germany 3, Greece 8, Hong Kong 13, Japan 47,
Malaysia 19, Netherlands 14, Norway 8, Panama 3,
Singapore 12, South Korea 1, Taiwan 2, United
Kingdom 7 (2002 est.)
Airports: 275(2001)
Airports - with paved runways:
total: 77
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1,523 m: 30
under 914 m: 12 (2001)
Airports - with unpaved runways:
total: 198
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 74
under 91 4 m: 119 (2001)
Heliports: 2(2001)
Railways: 0 km
Highways:
total : 6.4 km
paved: 0 km
unpaved: 6.4 km
Waterways: none
Ports and harbors: Adamstown (on Bounty Bay)
Merchant marine: none (2002 est.)
Airports: none (2001)
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 ,000-m gauge
note: there is also a 83 km mass transit system with 48
stations
Highways:
tofa/:3,150 km
paved: 3,066 km (including 150 km of expressways)
unpaved: 84 km (2000)
Waterways: none
Ports and harbors: Singapore
Merchant marine:
total: 876 ships (1 ,000 GRT or over) totaling
20,686,612 GRT/32,647,743 DWT
ships by type: bulk 131, cargo 100, chemical tanker
81, combination bulk 10, combination ore/oil 6,
container 168, liquefied gas 35, livestock carrier 2,
multi-functional large-load carrier 1 , petroleum tanker
287, refrigerated cargo 6, roll on/roll off 5, short-sea
passenger 1 , specialized tanker 1 1 , vehicle carrier 32
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 7, Belgium 6,
China 12, Denmark 27, Germany 17, Greece 4, Hong
Kong 44, Indonesia 8, Japan 52, Malaysia 4, Monaco
22, Netherlands 2, Norway 42, Philippines 6,
Russia 3, Slovenia 1, South Korea 10, Sweden 13.
Switzerland 7, Taiwan 46, Tanzania 2, Thailand 22,
United Arab Emirates 4, United Kingdom 14, United
States 1 (2002 est.)
Airports: 9(2001)
Airports - with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 91 4 m: 1 (2001)','64e02630b56504b7caf7fbad098f1f75a854adfe969b92f78d88b1219e5fd406','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06648be99d8a2a44b38e52e8c3c8373ecb165b461c0d2d0fc5dd60c605bc43c',2002,'PE','Peru','transportation',454,'Railways:
total: 965 km
narrow gauge: 965 km 1 ,067-m gauge (2000 est.)
Highways:
total: 43,1 97 km
paved: 8,165 km
unpaved: 35,032 km (2001)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 33 ships (1 ,000 GRT or over) totaling 239,876
GRT/393,680 DWT
ships by type: cargo 2, chemical tanker 3, liquefied
gas 1, passenger 3, petroleum tanker 23, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Chile 1 , Greece 1
(2002 est.)
Airports: 205(2001)
Airports - with paved runways:
total: 61
over 3,047m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 18
914 to 1,523 m: 17
under 914 m: 19 (2001)
Airports - with unpaved runways:
total: 144
914 to 1,523 m: 31
under 914 m: 113 (2001)
Heliports: 1 (2001)
Railways:
total: 4,955 km
standard gauge: 4,955 km 1,435-m gauge (42 km
electrified; 1,560 km double-track) (2000 est.)
Highways:
total: 64,000 km
paved: 50,000 km
unpaved: 14,000 km (1996)
Waterways: 3,500 km
note: including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller
canals in the delta; Suez Canal (193.5 km including
approaches), used by oceangoing vessels drawing up
to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, BurSafajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine:
total: 175 ships (1 ,000 GRT or over) totaling
1,331,186 GRT/1 ,987,964 DWT
ships by type: bulk 23, cargo 58, container 2, liquefied
gas 1 , passenger 61 , petroleum tanker 14, roll on/roll
off 13, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience:, Denmark 1,
Germany 1, Greece 6, Lebanon 3, Monaco 1,
Ukraine 1 (2002 est.)
Airports: 92(2001)
Airports - with paved runways:
total: 72
over 3,047 m: 13
2,438 to 3,047 m: 37
1,524 to 2,437 m: 17
914 to 1,523 m: 2
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 20
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 91 4 m: 10 (2001)
Heliports: 2(2001)
157
Egypt (continued)
Railways:
total: 562 km
narrow gauge: 562 km 0.91 4-m gauge
note: length of operational route is reduced to 283 km
by disuse and lack of maintenance (2001 est.)
Highways:
total: 10,029 km
paved: 1 ,986 km (including 327 km of expressways)
unpaved: 8,043 km (1997)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutla, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
Merchant marine: none (2002 est.)
Airports: 83(2001)
Airports - with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 79
914 to 1,523 m: 17
under 914 m: 62 (2001)
Heliports: 1 (2001)
Railways:
total: 2,102 km
standard gauge: 1,695 km 1.435-m gauge
narrow gauge: 407 km 0.91 4-m gauge (2001)
Highways:
total: 72, 900 km
paved: 8,700 km
unpaved: 64,200 km (1999 est.)
Waterways: 8,808 km
note: 8,600 km of navigable tributaries of Amazon
system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
Ports and harbors: Callao, Chimbote, llo, Matarani,
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine;
total: 5 ships (1 ,000 GRT or over) totaling 29,470
GRT/45,451 DWT
ships by type: cargo 4, petroleum tanker 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 239(2001)
Airports • with paved runways:
total: 47
over 3,047 m: 5
2,438 to 3,047 m: 20
1,524 to 2,437m: 13
914 to 1,523 m: 8
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 192
1,524 to 2,437 m: 25
914 to 1,523 m: 65
under 914 m: 102 (2001)','fa40eba4716423942058a8a55adcfd21ff784079efd3d0ac28e6e5093cbdda36','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b85fcdfc6b892b14b04d318c1e2b3ffb82788a0ee58c77f361de4434d8b12781',2002,'GN','Guinea','transportation',464,'Railways:
fofa/:0km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2,880 km (1996)
Waterways: none
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
totals ships (1,000 GRT or over) totaling 14,413
GRT/1 6,251 DWT
ships by type: bulk 1 , cargo 3, passenger 1 ,
passenger/cargo 1 (2002 est.)
Airports: 3(2001)
Airports • with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Railways:
tofa/: 317 km
narrow gauge: 317 km 0.950-m gauge
note: links Ak''ordat and Asmara with the port of
Massawa; nonoperational since 1978 except for about
a 5 km stretch that was reopened in Massawa in 1 994;
rehabilitation of the remainder and of the rolling stock
is underway (2001 est.)
Highways:
total: 3,850 km
paved: 810 km
unpaved: 3,040 km (2000)
Waterways: none
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa) ,
Merchant marine:
fofa/: 6 ships (1,000 GRT or over) totaling 19,100
GRT/23,399 DWT
ships by type: bulk 1 , cargo 2, liquefied gas 1 ,
petroleum tanker 1, roll on/roll off 1 (2002 est.)
Airports: 21 (2001)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2(2001)
Airports - with unpaved runways:
total: 17
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m:7
under 914 m: 2 (2001)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1 .067-m gauge
standard gauge: 52 km 1 ,435-m gauge
note: years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and
utility of the system; a project to restore Nigeria''s
railways is now underway (2001)
Highways:
total: 193,200 km
paved: 59,892 km (including 1,194 km of
expressways)
unpaved: 133,308 km
note: many of the roads reported as paved may be
graveled; because of poor maintenance and years of
heavy freight traffic - in part the result of the failure of
the railroad system - much of the road system is
barely usable (2001)
383
Nigeria (continued)
Waterways: 8,575 km
note: consisting of the Niger and Benue rivers and
smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products
3,000 km; natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warri
Merchant marine:
total: 43 ships (1 ,000 GRT or over) totaling 331 ,094
GRT/614,171 DWT
ships by type: bulk 1 , cargo 7, chemical tanker 4,
petroleum tanker 29, roll on/roll off 1, specialized
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Bulgaria 1 , Greece 1 ,
Norway 1 , Pakistan 1, Togo 1, United States 1
(2002 est.)
Airports: 70(2001)
Airports - with paved runways:
total: 35
over3,047m: 7
2,438 to 3,047m: 10
1,524 to 2,437 m: 9
914 to 1,523 m: 7
under 914 m: 2(2001)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 3
914 to 1,523 m: 14
under 914 m: 18 (2001)
Heliports: 1 (2001)','989a139ca97248b385e0f1c0aa4a45efc3eac32bd4f9fdc0713896c861db944a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bfa57971a9439a71519894294d0844bfbe6100431c8d2258f14f3339b0a20b1',2002,'EE','Estonia','transportation',475,'Railways:
total: 968 km common carrier lines only; does not
include dedicated industrial lines
broad gauge: 968 km 1.520-m gauge (132 km
electrified) (2001)
Highways:
tote/: 30,300 km
paved: 29,200 km (including 75 km of expressways);
note - these roads are said to be hard-surfaced, and
include, in addition to conventionally paved roads,
some that are surfaced with gravel or other coarse
aggregate, making them trafficable in all weather
unpaved: 1,100 km (2000)
Waterways: 320 km (perennially navigable) (2002)
Pipelines: natural gas 2,000 km (2002)
166
Estonia (continued)
Ports and harbors: Haapsalu, Kunda, Muuga,
Paldiski, Parnu, Tallinn
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 245,958
GRT/1 93,042 DWT
ships by type: bulk 2, cargo 1 3, container 5, petroleum
tanker 2, roll on/roll off 9, short-sea passenger 6
note: includes a foreign-owned ship registered here
as a flag of convenience: Liberia 1 (2002 est.)
Airports: 32(2001)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 5
under 914 m: 6 (2001)','af36e963f488154a3117aeeb1584adeb65e5ae96e8c77af9c02a27b45398f7ba','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81090bc741bf484a80b4084ef46832b8eebb25e48a80e36c7546626ca5c96b73',2002,'FO','Faroe Islands','transportation',484,'Railways: 0 km
Highways:
total: 4 63 km
paved: 454 km
unpaved: 9 km (1999)
Waterways: none
Ports and harbors: Torshavn, Klaksvik, Tvoroyri,
Runavik, Fuglafjordhur
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 100,951
GRT/1 39,396 DWT
173
Faroe Islands (continued)
ships by type: cargo 2, petroleum tanker 2,
refrigerated cargo 1 , roll on/ro!l off 1, short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 3, Norway 1 ,
United''Kingdom 1 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (2001)','b9141500d5a17522af9ef7da6b08180779b798313d4ece7480ac8472ce4a7f2a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a51853638c8f7d460fe426f56d7babb197d3503d14ca257ad676ccf7c20e55c7',2002,'JE','Jersey','transportation',494,'Railways:
total: 597 km
narrow gauge: 597 km 0.61 0-m gauge
note: belongs to the government-owned Fiji Sugar
Corporation (1995)
Highways:
total: 3,440 km
paved: 1,692 km
unpaved: 1,748 km (1996)
Waterways: 203 km
note: 122 km navigable by motorized craft and
200-metric-ton barges
Ports and harbors: Lambasa, Lautoka, Levuka,
Malau, Savusavu, Suva, Vuda
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 1 ,870
GRT/1 4,787 DWT
ships by type: chemical tanker 2, passenger 1 ,
petroleum tanker 1 , roll on/roll off 1 , specialized tanker
1, includes some foreign-owned ships registered here
as a flag of convenience: Australia 1 , Singapore 4
(2002 est.)
Airports: 27(2001)
Airports - with paved runways:
total: 3
over 3,047 m:1
1,524 to 2,437 mA
914 to 1,523 mA (2001)
Airports - with unpaved runways:
total: 24
1,524 to 2,437 mA
914 to 1,523 m: 5
under 914 m: 18 (2001)
Railways:
total: 647 km
standard gauge: 647 km 1.435-m gauge (2001)
Highways:
total: 15,965 km
paved: 15,965 km (including 56 km of expressways)
unpaved: 0 km (1998 est.)
Waterways: none
Pipelines: crude oil 708 km; petroleum products
290 km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 16 ships (1 ,000 GRT or over) totaling 595,319
GRT/704,544 DWT
ships by type: container 1 5, roll on/roll off 1
(2002 est.)
Airports: 54(2001)
Airports - with paved runways:
total: 29
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 7
914 to 1,523 m: 11
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 91 4 m: 20 (2001)
Heliports: 3(2001)
Railways: 0 km
Highways:
total: 577 km (1995)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,590 km
unpaved: 860 km (1999 est.)
Waterways: none
Pipelines: crude oil 877 km; petroleum products 40
km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina'' ''Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 38 ships (1 ,000 GRT or over) totaling 2,274,515
GRT/3,627,835 DWT
ships by type: bulk 1 , cargo 1 , container 6, liquefied
gas 6, livestock carrier 5, petroleum tanker 19
note: includes some foreign-owned ships registered
here as a flag of convenience: Monaco 1, Saudi
Arabia 1 (2002 est.)
Airports: 7(2001)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 2(2001)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 m:1
under 914 m: 3 (2001)
Heliports: 3(2001)
Railways:
total: 1,201 km
standard gauge: 1 ,201 km 1 ,435-m gauge (489 km
electrified) (2001)
Highways:
total: 19,586 km
paved: 17,745 km (including 249 km of expressways)
unpaved: 1 ,841 km (1 998 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Airports: 14(2001)
Airports - with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437m: 1
914 to 1,523 m: 2
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2001)
Railways: 0 km
Highways:
total: 1,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Waterways: none
Ports and harbors: Aola Bay, Honiara, Lofung,
Noro, Viru Harbor, Yandina
Merchant marine: none (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m: 19 (2001)
Railways:
total: 297 km
narrow gauge: 297 km 1 ,067-m gauge
note: includes 71 km which are not in use (2001)
Highways:
total: 3,800 km
paved: 1,064 km
unpaved: 2,736 km (2002)
Waterways: none
Ports and harbors: none
Airports: 18(2001)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:: (2001)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 7
under 914 m: 10 (2001)','3f5edbb95a1acd0b6f769b0351158fe872c856d1a162a8612554ebcd8235f5b3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c0aa881756f2358c7a24148d3b7d5541cd2647f18c314757771f47657e4cb1b',2002,'FI','Finland','transportation',503,'Railways:
total: 5,865 km
broad gauge: 5, 865 km 1.524-m gauge (2,234 km
electrified; 480 km double- or multiple-track)
(2000 est.)
Highways:
total: 77,831 km
paved: 49,789 km (including 444 km of expressways)
unpaved: 28,042 km (1999)
Waterways: 6,675 km
note: includes Saimaa Canal; 3,700 km suitable for
large ships
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 98 ships (1 ,000 GRT or over) totaling 1 ,172,404
GRT/1,144,139 DWT
ships by type: bulk 9, cargo 26, chemical tanker 5,
passenger 1 , petroleum tanker 1 1 , roll on/roll off 36,
short-sea passenger 10
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Sweden 1
(2002 est.)
Airports: 160(2001)
Airports - with paved runways:
total: 73
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437 m: 10
914 to 1,523 m: 22
under 914 m: 12(2001)
Airports - with unpaved runways:
total: 87
914 to 1,523 m: 5
under 914 m: 82 (2001)
Railways:
total: 4,006 km
standard gauge: 4,006 km 1 .435-m gauge (2,471 km
electrified) (2001)
Highways:
total: 91,180 km
paved: 67,838 km (including 109 km of expressways)
unpaved: 23,342 km (1999)
Waterways: 1 ,577 km (along west coast)
note: navigable by 2.4 m maximum draft vessels
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Flora,
Hammerfest, Harstad, Haugesund, Kristiansand,
Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 746 ships (1 ,000 GRT or over) totaling
20,691,266 GRT/32,126,513 DWT
ships by type: bulk 84, cargo 130, chemical tanker
1 19, combination bulk 9, combination ore/oil 38,
container 18, liquefied gas 91 , passenger 6,
petroleum tanker 143, refrigerated cargo 9, roll on/roll
off 41 , short-sea passenger 21 , specialized tanker 2,
vehicle carrier 35
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , Denmark
1 4, Germany 1 1 , Greece 1 0, Hong Kong 7, Iceland 2,
Japan 1 1 , Lithuania 1 , Monaco 42, Poland 1 , Saudi
Arabia 3, Singapore 10, Sweden 42, Switzerland 2,
United Kingdom 4, United States 5 (2002 est.)
Airports: 102(2001)
Airports - with paved runways:
total: 67
over 3,047 m: 1
2,438 to 3,047 m: 13
1,524 to 2,437 m: 13
914 to 1,523 m: 15
under 914 m: 26 (2001)
Airports - with unpaved runways:
fofa/:35
914 to 1,523 m: 6
under 914 m: 29 (2001)
Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22,960 km (1996)
Waterways: none
Pipelines: crude oil 1 ,300 km; natural gas 1 ,030 km
Ports and harbors: Matrah, Mina'' al Fahl, Mina''
Raysut
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 17,291
GRT/9,457 DWT
ships by type: cargo 1 , passenger 1 ,
passenger/cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Singapore 1 (2002 est.)
Airports: 143(2001)
Airports - with paved runways:
total: 6
over 3,047m: 4
2,438 to 3,047 m: 1
914 to 1,523 m:1 (2001)
Airports • with unpaved runways:
total: 137
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 54
914 to 1,523 m: 38
under 914 m: 36 (2001)
Heliports: 1 (2001)
Ports and harbors: Bangkok (Thailand), Hong
Kong, Kao-hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)
Transportation ■ note: Inside Passage offers
protected waters from southeast Alaska to Puget
Sound (Washington state)','3e3723f88657198e14efa44e38ee6b34f89362a007a6ec3a2b90faa98d3f33c0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('263475e64dbab4656c26e2f0716d7362df7f55a78d6d7d9773d2728b57e58332',2002,'WF','Wallis and Futuna','transportation',513,'Railways:
total: 31 ,939 km (operated by French National
Railways (SNCF); 14,176 km of SNCF routes are
electrified and 12,132 km are double- or
multiple-track)
standard gauge: 31 ,840 km 1 ,435-m gauge
narrow gauge: 99 km 1 ,000-m gauge (2000 est.)
Highways:
total: 892,900 km
paved: 892,900 km (including 9,900 km of
expressways)
unpaved: 0 km (1999)
Waterways: 14,932 km (6,969 km heavily traveled)
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling 1 ,263,691
GRT/1 ,769,932 DWT
ships by type: bulk 3, cargo 4, chemical tanker 9,
combination bulk 1, container 3, liquefied gas 3,
passenger 3, petroleum tanker 15, roll on/roll off 4,
short-sea passenger 4
note: includes some foreign-owned ships registered
here as a flag of convenience: French Polynesia 2,
Greece 1 , Japan 1 , Noiway 1 , Sweden 9 (2002 est.)
Airports: 477(2001)
Airports - with paved runways:
total: 270
over 3,047m: 14
2,438 to 3,047 m: 29
1,524 to 2,437m: 96
914 to 1,523 m: 75
under 91 4 m: 56 (2001)
Airports - with unpaved runways:
total: 207
1,524 to 2,437 m: 3
914 to 1,523 m: 73
under 914 m: 131 (2001)
Heliports: 3(2001)','62943fdff870f462932fc84089a9d24e725dbadd856580ed34e81427ec7bdb29','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77e07a23d243e500d97cd0ad86c8bcec267ef7f0bd3865471ca5e49f91443b95',2002,'PF','French Polynesia','transportation',528,'Railways: 0 km
Highways:
total: 792 km
paved: 264 km
unpaved: 528 km (2000)
Waterways: none
Ports and harbors: Mataura, Papeete, Rikitea,
Uturoa
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,240 GRT/
7,765 DWT
ships by type: cargo 1 , passenger/cargo 2,
refrigerated cargo 1 (2002 est.)
Airports: 45(2001)
Airports - with paved runways:
total: 33
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 21
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 12
914 to 1,523 m: 3
under 914 m: 9(2001)','56a9df5dcde8ddfc68334c34e00e9862111115b89b11be8096aa078456e4ec6f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9387f18bfdafc1f3037e7afeee3adc215d050a957cbc6ecac1f15b6ecd3489f3',2002,'GA','Gabon','transportation',536,'Railways:
total: 649 km
standard gauge: 649 km 1.435-m gauge; single-track
(2000 est.)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996)
Waterways: 1,600 km (perennially navigable)
Pipelines: crude oil 270 km; petroleum products
14 km
Ports and harbors: Cap Lopez, Kango, Lambarene,
Libreville, Mayumba, Owendo, Port-Gentil
Airports: 59 (2001)
Airports - with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 8
914 to 1,523 m: 17
under 914 m: 24 (2001)
Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
unpaved: 1,744 km (1996)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2001)
Railways:
total: NA km; note - one line, abandoned and in
disrepair, little trackage remains (2001 est.)
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Waterways: none
Ports and harbors: Gaza
Airports: 2(2001)
note: includes Gaza International Airport (GIA),
inaugurated on 24 November 1998 as part of
agreements stipulated in the September 1995 Oslo II
Accord and the 23 October 1998 Wye River
Memorandum; GIA has been largely closed since
October 2000 by Israeli orders and its runway was
destroyed by the Israeli Defense Forces in
December 2001
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2001)','ce28b58471829c9c9a276b5f3a61f853254f7500b10e29ca3bc720c40d474714','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ac0b82076121654245e6147e979da7e86e1dcda2b912958eb10ae8c70979708',2002,'GE','Georgia','transportation',543,'Railways:
total: 1,583 km In common carrier service; does not
include industrial lines
broad gauge: 1,546 km 1.520-m gauge
narrow gauge: 37 km 0.912-m gauge (2000 est.)
Highways:
total: 33,900 km
paved: 29,500 km (includes some all-weather
gravel-surfaced roads)
unpaved: 4,400 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: none
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Bat umi, P''ofi, Sokhumi
Merchant marine:
total: 64 ships (1 ,000 GRT or over) totaling 210,620
GRT/288,565 DWT
ships by type: bulk 5, cargo 46, container 5, petroleum
tanker 7, roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Belize 1 , Bulgaria 1 ,
Cyprus 1 , Ecuador 1 , Egypt 4, Gibraltar 1 , Greece 5,
Jordan 1 , Latvia 1 , Liberia 1 , Malta 1 , Panama 9,
Romania 8, Russia 4, Saint Kitts and Nevis 3, Saint
Vincent and the Grenadines 3, Saudi Arabia 2, Syria
5, Turkey 2, Ukraine 7, United Arab Emirates 1 1 ,
United Kingdom 1, United States 1 (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
total: 16
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 15
2,438 to 3,047 m:1
1,524 to 2,437m: 4
914 to 1,523 m: 4
under 914 m: 6 (2001)
Transportation - note: transportation network is in
poor condition resulting from ethnic conflict, criminal
activities, and fuel shortages; network lacks
maintenance and repair','024fdfb14df1955965f74080489334aea9c31fbd033b5c16bb4ecd95dfa50003','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b37ad5a5f0a72f8e593e386f3e970d54392819c1b60f00ac14fcfccd3d78978c',2002,'DE','Germany','transportation',551,'Railways:
total: 44,000 km (including at least 20,300 km
electrified); most routes are double- or multiple-track
note: since privatization in 1994, Deutsche Bahn AG
(DBAG) no longer publishes details of the track it
197
Germany (continued)
owns; in addition to the DBAG system there are 102
privately owned railway companies which own
approximately 3,000 to 4,000 km of track (2001 est.)
Highways:
total: 656,140 km
paved: 650,891 km (including 11,400 km of
expressways)
unpaved: 5,249 km (all-weather) (1998 est.)
Waterways: 7,500 km
note: major rivers include the Rhine and Elbe; Kiel
Canal is an important connection between the Baltic
Sea and North Sea (1999)
Pipelines: crude oil 2,240 km (2001)
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Luebeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 388 ships (1 ,000 GRT or over) totaling
5,758,942 GRT/7, 132,525 DWT
ships by type: cargo 132, chemical tanker 10,
container 219, liquefied gas 3, passenger 3,
petroleum tanker 7, railcar carrier 2, refrigerated cargo
1, roll on/roll off 4, short-sea passenger 7
nofe: includes some foreign-owned ships registered
here as a flag of convenience: Chile 1 , Finland 5,
Iceland 1, Netherlands 3, Switzerland 1 (2002 est.)
Airports: 625(2001)
Airports - with paved runways:
total: 325
over 3,047 m: 11
2,438 to 3,047m: 55
1,524 to 2,437 m: 65
914 to 1,523 m: 67
under 914 m: 127 (2001)
Airports - with unpaved runways:
tofaf: 300
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 51
under 914 m: 238 (2001)
Heliports: 59(2001)
Railways:
total: 953 km
narrow gauge: 953 km 1.067-m gauge; undergoing
major rehabilitation (2001 est.)
Highways:
total: 38,940 km
paved: 9,346 km (including 30 km of expressways)
unpaved: 29,594 km (2001)
Waterways: 1,293 km
note: Volta, Ankobra, andTano Rivers provide 168 km
of perennial navigation for launches and lighters; Lake
Volta provides 1 ,125 km of arterial and feeder
waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 16,450
GRT/22,097 DWT
ships by type: petroleum tanker 2, refrigerated
cargo 5
note: includes some foreign-owned ships registered
here as a flag of convenience: Brazil 1 , Saint Vincent
and the Grenadines 1, Spain 1 (2002 est.)
Airports: 12(2001)
Airports - with paved runways:
total:!
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 2 (2001)
Railways:
total: 274 km
standard gauge: 274 km 1 ,435-m gauge (242 km
electrified) (2001)
Highways:
total: 5,166 km
paved: 5, 1 66 km (including 1 1 8 km of expressways)
unpaved: 0 km (1999)
Waterways: 37 km (on the Moselle)
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 60 ships (1 ,000 GRT or over) totaling 1 ,487,752
GRT/2,123,579DWT
ships by type: bulk 2, chemical tanker 1 3, container 8,
liquefied gas 19, passenger 4, petroleum tanker 8, roll
on/roll off 6
I
309
Luxembourg (continued)
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 21 , Finland 3,
France 8, Germany 10, Monaco 1 , Netherlands 3,
Norway 1, United Kingdom 9, United States 3
(2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)
Heliports: 1 (2001)
Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Macau
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2001)
Railways:
total: 699 km
standard gauge: 699 km 1 ,435-m gauge (233 km
electrified)
note: a 56-km extension of the Kumanovo-Beljakovce
line to the Bulgarian border at Gyueshevo is under
construction (2001)
Highways:
total: 8.684 km
paved: 5,540 km (including 133 km of expressways)
unpaved: 3,144 km (1997)
Waterways:
note: lake transport only, on the Greek and Albanian
borders
Pipelines: 10 km
Ports and harbors: none
Airports: 17(2001)
Airports - with paved runways:
total: ID
2,438 to 3,047 m: 2
under 914 m: 8 (2001)
Airports • with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2001)','0e5c69d05ae41a8a88cea5c8789044dc4bb89c3c257de35de2c956284b7a6dd5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e4425a44e6b1edbe8129f7ae10da51eca6217701db2ed685bbb86dfec1f406e',2002,'GI','Gibraltar','transportation',560,'Railways:
total: NA km; 1 ,000-m gauge system in dockyard area
only (no longer used) (2001 est.)
Highways;
total: 46.25 km
paved: 46.25 km
unpaved: 0 km (2001)
Waterways: none
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 75 ships (1 ,000 GRT or over) totaling 900,400
GRT/1 ,277,611 DWT
ships by type: bulk 2, cargo 35, chemical tanker 6,
container 10, multi-functional large-load carrier 3,
passenger 3, petroleum tanker 14, roll on/roll off 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1, Cyprus 1,
France 2, Germany 55, Greece 6, Ireland 1,
Monaco 2, Norway 3, United Kingdom 13 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports ■ with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Railways:
total: 1,907 km
standard gauge: 1 ,907 km 1 ,435-m gauge (1 ,003 km
electrified; 540 km double-tracked) (2001)
Highways:
totef: 57,847 km
paved: 30,254 km (including 327 km of expressways)
unpaved: 27,593 km (1998)
Waterways: none
Pipelines: crude oil 362 km; petroleum products
491 km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Melilla
Merchant marine:
total: 41 ships (1 ,000 GRT or over) totaling 227,364
GRT/277,306 DWT
ships by type: cargo 10, chemical tanker 6, container
6, petroleum tanker 2, refrigerated cargo 8, roll on/roll
off 8, short-sea passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Hong Kong
1, Netherlands 2, Norway 2 (2002 est.)
Airports: 67(2001)
Airports - with paved runways:
total: 26
over 3,047 m: 9
2,438 to 3,047 m: 6
1,524 to 2,437 m: 9
914 to 1,523 m:1
under914m:1 (2001)
Airports - with unpaved runways:
tofa/:41
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 19
under 914 m: 11 (2001)
Heliports: 1 (2001)','6dd089d5db7ca2837aef2924842990aea082bb3073220999f4093cea00b84581','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7e5496f2a53eddd605e5c2b05204734ddbc750a1bbe3d775992474477492e32',2002,'GR','Greece','transportation',569,'Railways:
total: 2,571 km
standard gauge: 1 ,565 km 1 .435-m gauge (36 km
electrified)
narrow gauge: 961 km 1 ,000-m gauge; 22 km
0.750-m gauge (a rack-type railway for steep grades)
dual gauge: 23 km combined 1 ,435-m and 1 .000-m
gauges (three rail system) (2001 est.)
Highways:
total: 117,000 km
paved: 107,406 km (including 470 km of
expressways)
unpaved: 9,594 km (1996)
Waterways: 80 km
note: system consists of three coastal canals
including the Corinth Canal (6 km) which crosses the
Isthmus of Corinth connecting the Gulf of Corinth with
the Saronic Gulf and shortens the sea voyage from
the Adriatic to Peiraiefs (Piraeus) by 325 km; there are
also three unconnected rivers
Pipelines: crude oil 26 km; petroleum products
547 km
Ports and harbors: Alexandroupolis, Elefsis,
Irakleion (Crete), Kavala, Kerkyra, Chalkis,
Igoumenitsa, Lavrion, Patrai, Peiraiefs (Piraeus),
Thessaloniki, Volos
Merchant marine:
total: 802 ships (1,000 GRT or over) totaling
27,998,523 GRT/49,458,125 DWT
ships by type: bulk 294, cargo 54, chemical tanker 25,
combination bulk 7, combination ore/oil 5,
container 45, liquefied gas 7, multi-functional
large-load carrier 1, passenger 13, petroleum
tanker 265, refrigerated cargo 3, roll on/roll off 23,
short-sea passenger 54, specialized tanker 4, vehicle
carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Ireland 1 , Japan 1 ,
Liberia 1, Norway 1, Panama 2, Russia 1, Saudi
Arabia 1 , United Kingdom 1 (2002 est.)
Airports: 79 (note - new Athens airport at Spafa
opened in March 2001) (2001)
Airports - with paved runways:
total: 65
over 3,047m: 6
2,438 to 3,047 m: 15
1,524 to 2,437 m: 19
914 to 1,523 m: 16
under 9 14 m: 9 (2001)
Airports - with unpaved runways:
total: 14
914 to 1,523 m: 4
under 914 m: 10 (2001)
Heliports: 4(2001)','51e93593b9cfaaa1178745c5d2652bda3c0c0e8db072106d1aa94a3a2b35fde9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75c7c88e8828ff6be7c59dda3988d93d4ddb7118a6c511b59aaafb69c5fa1e00',2002,'GL','Greenland','transportation',578,'Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Waterways: none
Ports and harbors: Aasiaat (Egedesminde),
llulissat (Jakobshavn), Kangerlussuaq, Nanortalik,
Narsarsuaq, Nuuk (Godthab), Qaqortoq (Julianehab),
Sisimiut (Holsteinsborg), Tasiilaq (March 2001)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,289 GRT /
1,500 DWT
ships by type: cargo 1 , passenger 1 , includes a
foreign-owned ship registered here as a flag of
convenience: Denmark 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m:1
under 91 4 m: 5 (2001)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 91 4 m: 2 (2001)','a180e53fe5768c2d1faa11fcb303cbf03135e5d034ac25f1e75905157906c193','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac32ef36cb9de50869a41ff8821e3b48f624ac74dc56cb12ae9f72990572a5d0',2002,'GD','Grenada','transportation',586,'Railways: 0 km
Highways:
total: 1,040 km
paved: 638 km
unpaved: 402 km (1996)
Waterways: none
Ports and harbors: Grenville, Saint George''s
Merchant marine: none (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2001)
Railways: 0 km
Highways:
total: 1,040 km
paved: 320 km
unpaved: 720 km (1996)
Waterways: none
Ports and harbors: Kingstown
Merchant marine:
total: 788 ships (1 ,000 GRT or over) totaling
7,000,660 GRT/10,702,776 DWT
445','a8496d49201735293756fea89c8b505b41a30e2978fb1a03c44848f07b93ff81','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d593cfaae29292f855997381a7752a9d38c901fc3537ac2dca4e1ed63e94527a',2002,'GU','Guam','transportation',595,'Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there are also 685 km of roads classified
non-public, including roads located on federal
government installations
Waterways: none
Ports and harbors: Apra Harbor
Merchant marine: none (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 4
over 3,047 m:2
2,438 to 3,047 m:t
914 to 1,523 m: 1 (2001)
Airports • with unpaved runways:
total: 1
under 914 m: 1 (2001)
Railways:
total: 884 km
narrow gauge: 884 km 0.91 4-m gauge (single-track)
note: much of the railway is inoperable (2001 est.)
Highways:
total: 13,856 km
paved: 4,370 km (including 140 km of expressways)
unpaved: 9,486 km (1998)
Waterways: 990 km
nofe: 260 km navigable year round; additional 730 km
navigable during highwater season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none (2002 est.)
Airports: 475(2001)
Airports • with paved runways:
total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 464
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 123
under 914 m: 331 (2001)','0be286d25767423fe7300a2c06c29b8a5b5e41582205cd299eec58ddec1f41a0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ba5d39ab37b1920d22192da3c586f8ef1ac1916b56e774a8a86ae899ba7e710',2002,'GG','Guernsey','transportation',604,'Railways: 5 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: St. Peter Port, Saint Sampson
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2001)','35ad6b5b84962fb1fa9f0bf71aa75b1c6aedad3c794e30cf1ece06be26104f5f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8c829656fcb61737f2eec14aab4354440577e9e33cd479aa36a7fd06aa9782b',2002,'GW','Guinea-Bissau','transportation',607,'Railways:
tote/: 1 ,086 km
standard gauge: 279 km 1.435-m gauge
narrow gauge: 807 km 1 ,000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry) (2000 est.)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25,467 km (1996)
Waterways: 1 ,295 km (navigable by shallow-draft
native craft)
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 5
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3(2001)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 1 (2001)','ad27b4872fd8c89fdfaf02b3ea4c9a42e5c6d108b61b363ad2c7ef002828b40d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69df1901a30225bde30b0199b2cb2c46b9af8e00f5dcb421ece65265553b919',2002,'GY','Guyana','transportation',620,'Railways:
total: 187 km
standard gauge: 139 km 1.435-m gauge
narrow gauge: 48 km 0.91 4-m gauge
note: all dedicated to ore transport (2001 est.)
Highways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (1996)
Waterways: 5,900 km (total length of navigable
waterways)
note: Berbice, Demerara, and Essequibo rivers are
navigable by oceangoing vessels for 1 50 km, 100 km,
and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 2,929 GRT /
4,507 DWT
ships by type: cargo 2 (2002 est.)
Airports: 51 (2001)
Airports • with paved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m: 3 (2001)
224
Guyana (continued)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 91 4 m: 36(2001)
Railways:
total: 166 km (single-track)
standard gauge : 80 km 1 .435-m gauge
narrow gauge: 86 km 1 ,000-m gauge
note: Suriname railroads are not in operation (2001)
Highways:
total: 4,530 km
paved: 1,178 km
unpaved: 3,352 km (1996)
Waterways: 1,200 km
note: most important means of transport; oceangoing
vessels with drafts ranging up to 7 m can navigate
many of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie,
Paramaribo, Paranam, Wageningen
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 3,432 GRT/
4,525 DWT
ships by type: cargo 1 , container 1 , petroleum tanker
1 (2002 est.)
Airports: 46(2001)
Airports - with paved runways:
total: 5
over 3,047 m: 1
914 to 1,523 m:1
under 914 m: 4(2001)
Airports - with unpaved runways:
total: 41
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 914 m: 35 (2001)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none (2002 est.)
Airports: 4(2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2001)
Airports • with unpaved runways:
total: 3
under 914 m: 3 (2001)','9f4714f9819cc2f1efaaefdf2c6d27cd58426cf6eecf7a76cdfd001ee79d0cf5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('157bc068ba1de2244cf9f5b4af104fd3582041eadff7ad079d7cd902602d491e',2002,'HT','Haiti','transportation',629,'Railways:
total: 40 km
narrow gauge: 40 km 0,760-m gauge; single-track
note: privately owned industrial line; closed in early
1990s (2001 est.)
Highways:
total: 4, 160 km
paved: 1,011 km
unpaved: 3,149 km (1996)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, Les Cayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none (2002 est.)
Airports: 12(2001)
Airports ■ with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m:1 (2001)
Airports - with unpaved runways:
total: 10
914 to 1,523 m: 4
under 914 m: 6 (2001)','9d776543756779ff385c907fb527b4a5666356de7a16759c407956763054fa4a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85610ae1548a7fe518dd6438a5332abce3176be67ec5200e3d19e5f49dea9405',2002,'HM','Heard Island and McDonald Islands','transportation',637,'Waterways: none
Ports and harbors: none; offshore anchorage only
Railways:
total: 0.86 km
standard gauge: 0.86 km 1.435-m gauge
note: a spur of the Italian Railways system, serving
Rome''s Saint Peter''s station (2001 est.)
Highways: none; all city streets
Waterways: none
Ports and harbors: none
Airports: none (2001)
Heliports: 1 (2001)','a598c4af0c0b13c538e0b5868b6eda0eacc1babb6168d71d04d2bad42722fc68','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fa4eb48cac081064a07417406454a3131324d4f379e714f7f299bfe3a0d0fd',2002,'HU','Hungary','transportation',646,'Waterways: none
Ports and harbors: none; offshore anchorage only;
note - there is one small boat landing area along the
middle of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
EARHART and Fred NOONAN - they left Lae, New
Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable
Transportation - note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia EARHART
Railways:
total: 7,869 km
broad gauge: 36 km 1.524-m gauge
standard gauge: 7,614 km 1 .435-m gauge (2,423 km
electrified; 1,236 km double-tracked)
narrow gauge: 219 km 0.760-m gauge
note: Hungary and Austria jointly manage the
cross-border, standard-gauge railway connecting
Gyor, Sopron, and Ebenfurt (Gysev railroad) which
has a route length of about 1 01 km in Hungary and 65
km in Austria (2001)
Highways:
total: 188,203 km
paved: 81 ,680 km (including 448 km of expressways)
unpaved: 106,523 km (1998 est.)
Waterways: 1 ,373 km (permanently navigable)
(1997)
Pipelines: crude oil 1 ,204 km; natural gas 4,387 km
(1991)
Ports and harbors: Budapest, Dunaujvaros
Airports: 43(2001)
Airports - with paved runways:
total: 16
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 27
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 8 (2001)
Heliports: 5(2001)
Railways: Okm
Highways:
total: 12,691 km
paved: 3,262 km
unpaved: 9,429 km (1999)
Waterways: none
Ports and harbors: Akureyri, Homafjordhur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vesttmannaeyjar
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 1,816 GRT/
2,500 DWT
ships by type: chemical tanker 1 (2002 est.)
Airports: 86(2001)
Airports ■ with paved runways:
total: 13
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2001)
Airports - with unpaved runways:
total: 73
1,524 to 2, 437m: 3
91 4 to 1,523 m: 21
under 914 m: 49 (2001)
239
Iceland (continued)','ac2a252177b3412aded54e1560067a6ce4f601349f8afd2fe716d7bca722d5ab','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb335c29c52ffd2a4bc8afbbaa1bfbd6a0e781aebc925e25998ad9211d6e067',2002,'IN','India','transportation',657,'Railways:
total: 63,693 km (13,771 km electrified)
broad gauge: 45,103 km 1.676-m gauge
narrow gauge: 15,178 km 1 ,000-m gauge; 3,105 km
0.762-m gauge; 307 km 0.61 0-m gauge (2001)
Highways:
total: 3,31 9,644 km
paved: 1,517,077 km
unpaved: 1,802,567 km (1996)
Waterways: 16,180 km
note: 3,631 km navigable by large vessels
Pipelines: crude oil 3,005 km; petroleum products
2,687 km; natural gas 1,700 km (1995)
Ports and harbors: Chennai (Madras), Cochin,
Jawaharal Nehru, Kandla, Kolkata (Calcutta), Mumbai
(Bombay), Vishakhapatnam
Merchant marine:
total : 319 ships (1 ,000 GRT or over) totaling
6,325,284 GRT/1 0,581 ,459 DWT
ships by type: bulk 1 1 5, cargo 80, chemical tanker 1 6,
combination bulk 1, combination ore/oil 3,
container 13, liquefied gas 9, passenger/cargo 5,
petroleum tanker 74, short-sea passenger 2,
specialized tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: China 1, United Arab
Emirates 10, United Kingdom 1 (2002 est.)
Airports: 335(2001)
Airports - with paved runways:
total: 234
over 3,047 m: 14
2,438 to 3,047 m: 48
1,524 to 2,437 m: 80
914 to 1,523 m: 75
under 914 m: 17 (2001)
Airports - with unpaved runways:
tofa/:101
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 41
under 914 m: 52 (2001)
Heliports: 18(2001)
Ports and harbors: Chennai (Madras; India),
Colombo (Sri Lanka), Durban (South Africa), Jakarta
(Indonesia), Kolkata (Calcutta; India) Melbourne
(Australia), Mumbai (Bombay; India), Richards Bay
(South Africa)','038cb11696f384dc534223f8fdfa636cc6abbbeb1fc79901f6600e56c3fa3909','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da4b4e0968b6827bfd6104ecc9fb2a59346c4e01b085f6a10e1408f453f9fb51',2002,'IQ','Iraq','transportation',667,'Railways:
total: 2,339 km
standard gauge: 2,339 km 1 ,435-m gauge (2001 )
Highways:
total: 45,550 km
paved: 38,400 km
unpaved: 7,150 km (1996 est.)
Waterways: 1,015 km
note: Shaft al Arab is usually navigable by maritime
traffic for about 130 km; channel has been dredged to
3 m and is in use; Tigris and Euphrates Rivers have
navigable sections for shallow-draft boats; Shaft al
Basrah canal was navigable by shallow-draft craft
before closing in 1991 because of the Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1 ,360 km
Ports and harbors: Umm Qasr, Khawr a z Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 25 ships (1 ,000 GRT or over) totaling 186,709
GRT/278,575 DWT
ships by type: cargo 14, passenger 1 , passenger/
cargo 1 , petroleum tanker 8, roll on/roll off 1
(2002 est.)
Airports: 108(2001)
Airports - with paved runways:
total: 73
over 3,047 m: 20
2,438 to 3,047 m: 34
1,524 to 2,437 m: 6
914 to 1,523 m: 6
under 914 m: 7 (2001)
Airports - with unpaved runways:
total: 35
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 10
under 914 m: 12 (2001)
Heliports: 4(2001)','c212e60adeedfaa222f4bf99985d459883d80bc2eae6100c7a3b1735e5318028','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a32f14149467e82ffd4d192600c13a87d552b0ff0e2cba102be21ede21ec5ab',2002,'IE','Ireland','transportation',677,'Railways:
total: 3,314 km
broad gauge: 1,949 km 1.600-m gauge (38 km
electrified; 485 km double-tracked)
narrow gauge: 1 ,365 km 0.914-m gauge (operated by
the Irish Peat Board to transport peat to power
stations and briqueting plants) (2001)
Highways:
total: 92,500 km
paved: 87,043 km (including 115 km of expressways)
unpaved: 5,457 km (1999 est.)
Waterways: 700 km (limited facilities for commercial
traffic) (1998)
Pipelines: natural gas 7,592 km (transmission 1 ,1 58
km; distribution 6,434 km) (2000)
Ireland (continued)
Ports and harbors; Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
Merchant marine:
total: 26 ships (1 ,000 GRT or over) totaling 1 1 0,741
GRT/1 27,342 DWT
ships by type: bulk 4, cargo 20, container 1 , short-sea
passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 2 (2002 est.)
Airports: 41 (2001)
Airports - with paved runways:
total: 17
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 7 (2001)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2001)
Railways: 0 km
Highways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1996)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port
Moresby, Rabaul
Merchant marine:
total: 22 ships (1 ,000 GRT or over) totaling 40,91 1
GRT/58,723 DWT
405
Papua New Guinea (continued)
ships by type: bulk 1 , cargo 1 0, chemical tanker 1 ,
combination ore/oil 3, container 1 , petroleum tanker 3,
roll on/roll off 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Singapore 2, United
Kingdom 7 (2002 est.)
Airports: 490 (2001)
Airports - with paved runways:
total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m:1 (2001)
Airports - with unpaved runways:
total: 469
1,524 to 2,437 m: 10
914 to 1,523 m: 57
under 914 m: 402 (2001)
Heliports: 2(2001)','f964aee25e510df42f5cd2532694eefc3c0cbc90a2595fc0a96eb5918e5be93d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199bc337de86af59bc896f317479d81866fe204c3b4d8896f8b47b3b864c1760',2002,'TN','Tunisia','transportation',687,'Railways:
total: 19,786 km
standard gauge: 18,761 km 1.435-m gauge (11,251
km electrified)
narrow gauge: 1 13 km 1 .000-m gauge (1 1 3 km
electrified); 912 km 0.950-m gauge (192 km
electrified) (2001)
Highways:
total: 668,669 km
paved: 668,669 km (including 6,460 km of
expressways)
unpaved: 0 km (2001)
Waterways: 2,400 km
note: serves various types of commercial traffic,
although of limited overall value (2002)
Pipelines: crude oil 1 ,703 km; petroleum products
2,148 km; natural gas 19,400 km
Ports and harbors: Augusta (Sicily), Bagnoli, Bari,
Brindisi, Gela, Genoa, La Spezia, Livorno, Milazzo,
Naples, Porto Foxi, Porto Torres (Sardinia), Salerno,
Savona, Taranto, Trieste, Venice (2001)
Merchant marine:
total: 467 ships (1 ,000 GRT or over) totaling
8,499,248 GRT/1 0,383,988 DWT
ships by type: bulk 45, cargo 41 , chemical tanker 91 ,
combination ore/oil 4, container 24, liquefied gas 37,
multi-functional large-load carrier 1 , passenger 15,
petroleum tanker 80, refrigerated cargo 4, roll on/roll
off 70, short-sea passenger27, specialized tanker 12,
vehicle carrier 16
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 1 , Denmark 4,
France 1, Greece 3, Man, Isle of 1, Monaco 7,
Netherlands 6, Norway 1, Panama 2, Spain 1,
Switzerland 1, Taiwan 15, Turkey 1, United Kingdom
6, United States 12 (2002 est.)
Airports: 135(2001)
Airports • with paved runways:
total: 97
over 3,047 m: 5
2,438 to 3,047 m:33
1,524 to 2,437 m:17
914 to 1,523 m: 30
under 914 m: 12 (2001)
Airports • with unpaved runways:
total: 38
1,524 to 2,437m: 2
914 to 1,523 m: 18
under 914 m: 18(2001)
Heliports: 4(2001)','22a9548194beaa9bc2deb576c3ada38e5e63ec0aaaa8c221773c90f7afef1af4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52c3f69bf2aeab7d09bc46295d6e484100393f5296128da12cff69998d4e9bbb',2002,'JM','Jamaica','transportation',696,'Railways:
tofa/:272km
standard gauge: 272 km 1 ,435-m gauge; note - 207
km, belonging to the Jamaica Railway Corporation,
were in common carrier service but are no longer
operational; the remaining track is privately owned
and used to transport bauxite (2000)
Highways:
total: 19,000 km
paved: 13,433 km
unpaved: 5,567 km (1997)
Waterways: none
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rios, Port Antonio,
Rocky Point, Port Esquivel (Longswharf)
Merchant marine:
total: 1 ships (1,000 GRT or over) totaling 21,954
GRT/25,250 DWT
ships by type: petroleum tanker 1 , includes some
foreign-owned ships registered here as a flag of
convenience: Latvia 2, United States 2 (2002 est.)
Airports: 35(2001)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 1
914 to 1,523 m: 3
under 914 m: 5 (2001)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2001)','f20065a7c5a4936ac28c3fd11c28c5887173ab21366a2d6b044d44b0b49d6167','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da34da8d5cca0cc39b6e8c5e2561733cd2074cd5df2f4763a4455b720e3829c',2002,'IS','Iceland','transportation',701,'Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2001)','bbcccc76e8e20d41d4a744c6e28e8f74c5e07a5bc6f192f843dc7b80115cf376','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75b3ef37c0d009bcde525989030eff3cef346259a7d9302472769ee857a8c85c',2002,'MH','Marshall Islands','transportation',707,'Waterways: none
Ports and harbors: Johnston Island
Airports: 1 (2001)
Airports - with paved runways:
total : 1
2,438 to 3,047 m: 1 (2001)','328d6c9fb7cfefed86ba38fa3250ec78b9ee803de513eeda88bf4e47ffb398e4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dfa0507f1a33c00e3240daa6630419ff3946162482590f5932a72a7d773c3f3',2002,'KZ','Kazakhstan','transportation',718,'Railways:
total: 13,601 km in common carrier service; does not
include industrial lines
broad gauge: 13,601 km 1.520-m gauge (3,661 km
electrified) (2001)
Highways:
total: 189,000 km
paved: 108,100 km (includes some all-weather
gravel-surfaced roads)
unpaved: 80,900 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 3,900 km
note: on the Syr Darya (Syrdariya) and Ertis (Irtysh)
rivers
Pipelines: crude oil 2,850 km; refined products 1 ,500
km; natural gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Paviodar,
Semey (Semipalatinsk)
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,064 GRT 7
646 DWT
ships by type: roll on/roll off 1
note: includes a foreign-owned ship registered here
as a flag of convenience: United States 1 (2002 est.)
Airports: 449(2001)
Airports - with paved runways:
total: 28
over 3,047 m:6
2,438 to 3,047 m: 14
1,524 to 2,437 m: 5
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 421
over 3,047 m: 11
2,438 to 3,047 m: 18
1,524 to 2,437m: 45
914 to 1,523 m: 101
under 914 m: 246 (2001)','1d9545d4c5ada293131a6d89f7aa11cbdeb4653ae77451e42f73a695e79ff8a4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7512e0b8c36120ba08e46b793d0cc3f57866c10c3952f7a907bb3cae7f6a0bc5',2002,'KE','Kenya','transportation',727,'Railways:
total: 2,778 km
narrow gauge: 2,778 km 1.000-m gauge
note: the line connecting Nairobi with the port of
Mombasa is the most important in the country
Highways:
total: 63,800 km
paved: 8,932 km
unpaved: 54,868 km (2001)
Waterways: NA
note: part of the Lake Victoria system is within the
boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,893 GRT/
6,320 DWT
ships by type: petroleum tanker 1, roll on/roll off 1
(2002 est.)
Airports: 231 (2001)
Airports - with paved runways:
total: 20
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 1 (2001)
Airports ■ with unpaved runways:
total: 21 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 111
under 914 m: 85 (2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1937 and 1938','e618f66c5acb6ddb1433e4dfb5d5ef50dc464efa7835f052237e41f1df338f05','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8030bc7cb2921d79c3d9655e586d905f61dc7df78fcad053a8902a9ad5fed91',2002,'KI','Kiribati','transportation',733,'Railways: 0 km
Highways:
total: 670 km
paved: NA km
unpaved: NA km
note: 27 km are paved in South Tarawa (2001)
Waterways: 5 km (small network of canals in Line
Islands)
Ports and harbors: Banaba, Betio, English
Harbour, Kanton
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 1,291 GRT/
1,295 DWT
ships by type: passenger/cargo 1 (2002 est.)
Airports: 21 (2001)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 4 (2001)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 13
under 914 m: 4 (2001)
Railways:
total: 5,000 km
standard gauge: 4,095 km 1.435-m gauge (3,500 km
electrified; 159 km double-tracked)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1 .435-m and 1 ,600-m gauges
(three rails provide two gauges) (1996)
Highways:
to/a/; 31 ,200 km
paved: 1,997 km
unpaved: 29,203 km (1996)
Waterways: 2,253 km
note: mostly navigable by small craft only
Pipelines: crude oil 37 km; petroleum product 1 80 km
Ports and harbors: Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch’aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine:
total: 122 ships (1 ,000 GRT or over) totaling 738,886
GRT/1 ,037,506 DWT
ships by type: bulk 4, cargo 1 02, combination bulk 1 ,
multi-functional large-load carrier 1 , passenger 2,
passenger/cargo 1 , petroleum tanker 6, refrigerated
cargo 3, short-sea passenger 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 , Greece 2,
Pakistan 1 , Singapore 1 (2002 est.)
281
Korea, North (continued)
Airports: 87(2001)
Airports • with paved runways:
total: 39
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 48
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 13
under 914 m: 8 (2001)
Railways:
total: 3,124 km
standard gauge: 3,124 km 1.435-m gauge (661 km
electrified) (2000)
Highways:
total: 87,534 km
paved: 65,388 km (including 1,996 km of
expressways)
unpaved: 22, 1 46 km (1999)
Waterways: 1,609 km
note: restricted to small native craft
Pipelines: petroleum products 455 km
Ports and harbors: Chinhae, Inch''on, Kunsan,
Masan, Mokp''o, P''ohang, Pusan, Tonghae-hang,
Ulsan, Vosu
Merchant marine:
total: 501 ships (1 ,000 GRT or over) totaling
5,679,171 GRT/9, 172,403 DWT
ships by type: bulk 104, cargo 160, chemical tanker
47, combination bulk 6, container 52, liquefied gas 1 6,
multi-functional large-load carrier 1 , passenger 3,
petroleum tanker 73, refrigerated cargo 25, roll on/roll
off 5, short-sea passenger 1 , specialized tanker 3,
vehicle carrier 5, includes some foreign-owned ships
registered here as a flag of convenience: Australia 1 ,
Bulgaria 1, China 1, Greece 1, Japan 1, Malaysia 1,
Norway 1, Panama 1, Saint Vincent and the
Grenadines 1 , United Kingdom 1 (2002 est.)
Airports: 102(2001)
Airports - with paved runways:
total: 68
over 3,047 m: 2
2,438 to 3,047 m: 19
1,524 to 2,437 m: 16
914 to 1,523 m:U
under 914 m: 20 (2001)
Airports • with unpaved runways:
total: 34
914 to 1,523 m: 2
under 914 m: 32 (2001)
Heliports: 203(2001)','f1b73588bd2594c9aadc63f1a42eed7872f71e83046ce81447aef3d2665a4131','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f9400775b2269f30274e456160b9396e0e82c3e4aa9f10929db903c817bf74d',2002,'KG','Kyrgyzstan','transportation',741,'Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 30,300 km (including 140 km of expressways)
paved: 22,600 km (includes some all-weather
gravel-surfaced roads)
unpaved: 7,700 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 50(2001)
Airports - with paved runways:
total: 4
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 46
2,438 to 3,047 m: 3','a7d49b4257d5f0cfd0d8a16f121a0a8718c8219592cfb77830987581596fcd0f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96b407b97ae0e3b8e8b7e3c700962e77e913d935bd199656022c30be3588bbd2',2002,'LB','Lebanon','transportation',752,'Railways:
total: 399 km
standard gauge: 317 km 1 ,435-m
narrow gauge: 82 km 1 ,050-m
note: entire system is unusable because of damage in
civil war (2001)
Highways:
total: 7,300 km
paved: 6,350 km
unpaved: 950 km (1999 est.)
Waterways: none
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Antilyas, Batroun, Beirut,
Chekka, El Mina, Ez Zahrani, Jbail, Jounie, Naqoura,
Sidon, Tripoli, Tyre
Merchant marine:
total: 67 ships (1 ,000 GRT or over) totaling 320,770
GRT/468,293 DWT
ships by type: bulk 8, cargo 38, chemical tanker 1 ,
combination bulk 1 , container 4, liquefied gas 1 ,
livestock carrier 7, refrigerated cargo 1 , roll on/roll off
3, vehicle carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: France 1 , Greece 1 0,
Netherlands 4, Panama 1, Saint Vincent and the
Grenadines 2, Spain 1, Syria 2 (2002 est.)
Airports: 8(2001)
Airports - with paved runways:
total: 5
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 2
under 91 4 m:1 (2001)','0c3a97dcee9cd63a781ef1be705e28ddd106d549d5c7b03455c05c1fe78f5608','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a355417c4b08588adf322af6442d0e2a0dec372e1b425911772cdabe9ce6da',2002,'ZA','South Africa','transportation',757,'Railways:
total: 2.6 km; note - owned by, operated by, and
included in the statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge (1995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,068 km (1996)
Waterways: none
Ports and harbors: none
Airports: 28 (2001)
Airports - with paved runways:
total: 4
over 3,047m: 1
914 to 1,523 m: 1
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 4
under 914 m:20 (2001)
Railways:
total: 490 km (328 km single-track)
standard gauge: 345 km 1.435-m gauge
narrow gauge: 145 km 1.067-m gauge
note: in 1989. Liberia had three rail systems owned
and operated by foreign steel and financial interests in
conjunction with the Liberian Government; one of
these, the Lamco Railroad, closed in 1989 after iron
ore production ceased; the other two were shut down
by the civil war; large sections of the rail lines have
been dismantled; approximately 60 km of railroad
track was exported for scrap (2001)
Highways:
total: 10,600 km
paved: 657 km
unpaved: 9,943 km
note: there is major deterioration on all highways due
to heavy rains and lack of maintenance (1996 est.)
Waterways: none
Ports and harbors: Buchanan, Greenville, Harper,
Monrovia
Merchant marine:
total: 1,513 ships (1,000 GRT or over) totaling
51,912,244 GRT/79,297,046 DWT
ships by type: barge carrier 3, bulk 31 3, cargo 89,
chemical tanker 167, combination bulk 16,
combination ore/oil 32, container 318, liquefied gas
99, multi-functional large-load carrier 4, passenger 23,
petroleum tanker 302, refrigerated cargo 69, roll on/
roll off 20, short-sea passenger 3, specialized tanker
13, vehicle carrier 42
300
Liberia (continued)
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 9, Australia
2, Austria 15, Belgium 9, Brazil 5, Canada 4, Cayman
Islands 1 , Chile 7, China 39, Croatia 1 1 , Denmark 4,
Ecuador 1, Estonia 1, Germany 437, Greece 154,
Hong Kong 69, India 5, Indonesia 1 , Israel 1, Italy 5,
Japan 90, Latvia 20, Man, Isle of 5, Monaco 56,
Netherlands 12, New Zealand 1, Nigeria 1, Norway
103, Pakistan 1, Portugal 5, Russia 66, Saudi Arabia
21 , Singapore 20, Slovenia 1 , South Africa 1 , South
Korea 10, Spain 2, Sweden 9, Switzerland 17, Taiwan
29, Turkey 3, Ukraine 4, United Arab Emirates 12,
United Kingdom 39, United States 113, Uruguay 3,
Vietnam 1 (2002 est.)
Airports: 47(2001)
Airports - with paved runways:
total: 2
over 3,047 m: 1
1, 524 to 2, 437 m: 1 (2001)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m: 4
914 to 1,523 m: 6
under 914 m: 35 (2001)
Railways:
total: 20,384 km
narrow gauge: 20,070 km 1.067-m gauge (9,090 km
electrified); 314 km 0.61 0-m gauge
note: in addition, South Africa has an electrified
1.065-m gauge commuter rail system, with a total
length of 1 ,254 km, which serves
Johannesburg-Pretoria, Cape Town, Durban, East
London, and Port Elizabeth (2001)
Highways:
total: 358,596 km
paved: 59,753 km (including 1,927 km of
expressways)
unpaved: 298,843 km (1996)
Waterways: NA
Pipelines: crude oil 931 km; petroleum products
1 ,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mossel Bay, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 271 ,650
GRT/268,604 DWT
ships by type: container 6, petroleum tanker 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 3,
Netherlands 1 (2002 est.)
Airports: 740(2001)
Airports - with paved runways:
total: 144
over 3,047 m: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 47
914 to 1,523 m: 72
under 9 14 m: 11 (2001)
Airports - with unpaved runways:
total: 596
1,524 to 2,437 m: 34
914 to 1,523 m: 304
under 914 m: 258 (2001)
Waterways: none
Ports and harbors: Grytviken
Airports: none (2001)
Ports and harbors: McMurdo, Palmer, and offshore
anchorages in Antarctica
note: few ports or harbors exist on the southern side
of the Southern Ocean; ice conditions limit use of most
of them to short periods in midsummer; even then
some cannot be entered without icebreaker escort;
most antarctic ports are operated by government
research stations and, except in an emergency, are
not open to commercial or private vessels; vessels in
any port south of 60 degrees south are subject to
inspection by Antarctic Treaty observers (see
Article 7)
Transportation - note: Drake Passage offers
alternative to transit through the Panama Canal','77181c373eb073e642f6c45501475f827a627e99c33559e5b413a89a1c1edd70','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('173a16bcabb564e64f2ecf4182f668606898c6c5bef7e83d90aebe109076f689',2002,'LY','Libya','transportation',769,'Railways:
note: Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m
standard-gauge line from the Tunisian frontier to
Tripoli and Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been little progress;
other plans made jointly with Egypt would establish a
rail line from As Sallum, Egypt, to Tobruk with
completion originally set for mid-1994; Libya signed
contracts with two private companies - Bahne of
Egypt and Jez Sistemas Ferroviarios of Spain - in
1 998 for the supply of crossings and pointwork (2001 )
Highways:
total: 24,484 km
paved: 6,798 km
unpaved: 17,686 km
note: data for the length of unpaved roads include the
assumption that because they were listed as
secondary roads, they are unpaved; some may be
paved and some part of the primary roads may not be
paved (1996)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1,947 km
Ports and harbors: Al Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 209,000
GRT/278,277 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
gas 3, petroleum tanker 2, roll on/roll off 4, short-sea
passenger 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Algeria 1 , Kuwait 1 ,
United Arab Emirates 1 (2002 est.)
Airports: 136(2001)
Airports - with paved runways:
total: 58
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 5
under 914m: 2 (2001)
Airports • with unpaved runways:
total: 78
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437m: 14
914 to 1,523 m: 40
under 914 m: 18 (2001)
Heliports: 1 (2001)','525be5200d6b218ecb9c65e8b39d5c4077e01eb0d0f52606462f2bfe6ba9dbfa','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('754ab894a2e3e66af0af432f9fa33145da9975cd3db825abbbc670f5a9216f71',2002,'LT','Lithuania','transportation',781,'Railways:
total: 18.5 km
standard gauge: 1 8.5 km 1 ,435-m gauge (electrified)
note: owned, operated, and included in statistics of
Austrian Federal Railways (2001)
Highways:
tofa/:250 km
paved: 250 km
unpaved: 0 km
Waterways: none
Ports and harbors: none
Airports: none (2001)
Background: Independent between the two World
Wars, Lithuania was annexed by the USSR in 1940.
On 1 1 March 1990, Lithuania became the first of the
Soviet republics to declare its independence, but this
proclamation was not generally recognized until
September of 1991 (following the abortive coup in
Moscow). The last Russian troops withdrew in 1993,
Lithuania subsequently has restructured its economy
for eventual integration into Western European
institutions.
Railways:
total: 1,998 km
broad gauge: 1 ,807 km 1 ,524-m gauge (1 22 km
electrified)
standard gauge: 22 km 1.435-m gauge
narrow gauge: 169 km 0.750-m gauge (2001)
Highways:
total: 44,000 km
paved: 35,500 km
unpaved: 8,500 km (2001)
Waterways: 600 km (perennially navigable)
Pipelines: crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Butinge, Kaunas, Klaipeda
Merchant marine:
total: 47 ships (1 ,000 GRT or over) totaling 279,743
GRT/304.156DWT
ships by type: cargo 25, combination bulk 8,
petroleum tanker 2, railcar carrier 1 , refrigerated
cargo 6, roll on/roll off 2, short-sea passenger 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 3 (2002 est.)
Airports: 72 (2001)
Airports - with paved runways:
total: 9
over 3,047 m: 2
1,524 to 2,437m: 4
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 63
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 55 (2001)','6608be738d775ff33595ed72fac14352de105381577ebb9d6afabb55a22c0efd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a288a69b0cd2b1b234e5ccaffe59d8f2441d535268ec676eaaa589e2c55777a',2002,'KM','Comoros','transportation',794,'Railways:
total: 893 km
narrow gauge: 893 km 1.000-m gauge (2001)
Highways:
total: 49,837 km
paved: 5,781 km
unpaved: 44,056 km (1996)
Waterways:
note: of local importance only
Ports and harbors: Antsiranana,
Antsohimbondrona, Mahajanga, Toamasina, Toliara
Merchant marine:
total: 15 ships (1 ,000 GRT or over) totaling 27,199
GRT/37,462 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
gas 1 , petroleum tanker 2, roll on, ''roll off 2 (2002 est.)
Airports: 130(2001)
Airports - with paved runways:
total: 29
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (2001)
Airports • with unpaved runways:
total: 101
1,524 to 2,437 m: 2
914 to 1,523 m: 55
under 914 m: 44 (2001)','cfd480ab90d873bc808ed5153acfe885f0c5a6fc9d17de747d211faac82e8a71','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a833ba4ebf6cae7d7176cd24cadb1a3f4de3c20e6689c739f1a77fabb66f7f8',2002,'MW','Malawi','transportation',802,'Railways:
total: 797 km
narrow gauge: 797 km 1 .067-m gauge (2001 )
Highways:
total: 14,594 km
paved: 2,773 km
unpaved: 11,821 km (2001)
Waterways: 144 km
note: on Lake Nyasa (Lake Malawi) and Shire Riverall
Ports and harbors: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota, Chilumba
Airports: 44(2001)
Airports - with paved runways:
total: 6
over 3,047 m:1
1,524 to 2,437 m: 1
914 to 1,523 m: 4 (2001)
Airports - with unpaved runways:
total: 38
1,524 to 2,437mA
914 to 1,523 m:14
under 91 4 m: 23 (2001)
Railways:
tote/; 1 ,801 km
narrow gauge: 1,801 km 1.000-m gauge (148 km
electrified) (2001)
Highways:
tote/; 64,672 km
paved: 48,707 km (including 1,192 km of
expressways)
unpaved: 15,965 km
note: in addition to these national and main regional
roads, Malaysia has thousands of kilometers of local
roads that are maintained by local jurisdictions (1999)
Waterways: 7,296 km
note: Peninsular Malaysia 3,209 km, Sabah 1 ,569 km,
Sarawak 2,51 8 km
Pipelines: crude oil 1 ,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabalu,
Kuantan, Kuching, Kudat, Labuan, Lahad Datu,
Lumut, Miri, Pasir Gudang, Penang, Port Dickson,
Port Kelang, Sandakan, Sibu, Tanjung Berhala,
Tanjung Kidurong, Tawau
Merchant marine:
total: 363 ships (1,000 GRT or over) totaling
4,952,11 9 GRT/7, 229, 299 DWT
ships by type: bulk 57, cargo 1 1 4, chemical tanker 35,
container 62, liquefied gas 20, livestock carrier 1,
passenger 2, petroleum tanker 60, roll on/roll off 5,
specialized tanker 1 , vehicle carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 1 , China 1,
Germany 2, Hong Kong 15, Indonesia 3, Japan 4,
Monaco 1, Philippines 2, Singapore 78, South
Korea 2, Vietnam 1 (2002 est.)
Airports: 116(2001)
Airports - with paved runways:
total: 34
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 11
914 to 1,523 m: 6
under 914 m: 7 (2001) .
Airports - with unpaved runways:
total: 82
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m:73 (2001)
Heliports: 1 (2001)','fe1a3542aa77951c0a76b03e89f41e2b81f43fcff901f7dcb61c8d88751edf65','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a262d7a6fc197b1b0aa79a78fd5d8a1e3e1450389d4eadcba021385861448c0',2002,'MV','Maldives','transportation',811,'Railways: Okm
Highways:
total: NA km
paved: NA km
unpaved: NA km; note - Male has 9.6 km of coral
highways within the city (1988 est.)
Waterways: none
Ports and harbors: Gan, Male
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 51,532
GRT/71 ,298 DWT
ships by type: cargo 13, short-sea passenger 1
(2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 2
over 3,047 m: 1
2.438 to 3,047 m: 1 (2001)
Maldives (continued)
Airports • with unpaved runways:
tots!: 3
914 to 1,523m: 3 (2001)','18209abe48e507c02cd55bcc9be6a45decf1fcabb00128ce42c29a046439f230','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f1063a07416374933e3252a1c9a5a26d56ab46203b0e94d5a3c6040725cb304',2002,'ML','Mali','transportation',819,'Railways:
total: 729 km
narrow gauge: 729 km 1.000-m gauge
note: linked to Senegal''s rail system through Kayes
(2001)
Highways:
total: 15,100 km
paved: 1,827 km
unpaved: 13,273 km (1996)
Waterways: 1,815 km
Ports and harbors: Koulikoro
Airports: 27(2001)
Airports - with paved runways:
total:?
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 20
1,524 to 2,437 m: 4
914 to 1,523 m: 7
under 914 m; 9 (2001)
Railways: Okm
Highways:
total: 1,742 km
paved: 1,677 km
unpaved: 65 km (1997)
Waterways: none
Ports and harbors: Marsaxlokk, Valletta
Merchant marine:
total: 1,323 ships (1,000 GRT or over) totaling
27,208,819 GRT/44,617,877 DWT
ships by type: bulk 440, cargo 334, chemical tanker
54, combination bulk 10, combination ore/oil 12,
container 75, liquefied gas 4, livestock carrier 3,
multi-functional large-load carrier 1 , passenger 6,
passenger/cargo 1 , petroleum tanker 270,
refrigerated cargo 39, roll on/roll off 45, short-sea
passenger 9, specialized tanker 3, vehicle carrier 17
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 4, Austria 6,
Bangladesh 1 , Belgium 3, Bulgaria 19, Canada 2,
China 16, Croatia 14, Cuba 1, Cyprus 7, Denmark 3,
Estonia 5, Finland 1 , Germany 54, Greece 627, Hong
Kong 12, Iceland 3, India 10, Iran 2, Israel 26, Italy 36,
Japan 2, Latvia 24, Lebanon 6, Monaco 29,
Netherlands 10, Nigeria 2, Norway 43, Poland 29,
Portugal 2, Romania 15, Russia 85, Saudi Arabia 1,
Slovenia 2, South Korea 5, Spain 1, Switzerland 54,
Syria 4, Turkey 84, Ukraine 25, United Arab
Emirates 3, United Kingdom 4, United States 10
(2002 est.)
Airports: 1 (2001)
Airports • with paved runways:
total: 1
over 3,047 m: 1 (2001)
Railways:
total: 68.5 km (43.5 km electrified) (2001)
Highways:
total: 800 km
paved: 800 km
unpaved: 0 km (1999)
Waterways: none
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
Merchant marine:
total: 21 2 ships (1 ,000 GRT or over) totaling
5,540,100 GRT/9,130,508 DWT
ships by type: bulk 29, cargo 34, chemical tanker 22,
combination bulk 2, container 29, liquefied gas 24,
petroleum tanker 46, roll on/roll off 20, specialized
tanker 1, vehicle carriers
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 45, France 1 ,
Germany 48, Greece 6, Hong Kong 10, Iceland 1,
Italy 8, Monaco 7, Netherlands 3, Norway 5,
Sweden 4, Switzerland 2, United Kingdom 70, United
States 1 (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Railways: 0 km
Highways:
total: NA km
paved: 64.5 km
unpaved: NA km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks (2002)
Waterways: none
Ports and harbors: Majuro
Merchant marine:
total: 270 ships (1 ,000 GRT or over) totaling
11,807,839 GRT/19, 332, 014 DWT
ships by type: bulk 82, cargo 14, chemical tanker 24,
combination ore/oil 4, container 46, liquefied gas 8,
multi-functional large-load carrier 1, petroleum tanker
88, vehicle carrier 3
note: the ship''s register of the Marshall Islands is a
flag of convenience register since essentially none of
the vessels on it is owned domestically, includes the
following foreign-owned ships registered here as a
flag of convenience: China 1, Cyprus 1, Denmark 9,
Germany 70, Greece 54, Hong Kong 2, Japan 4,
Monaco 8, Netherlands 8, Norway 10, Poland 16,
Singapore 1, Turkey 6, United Kingdom 3, United
States 87, Uruguay 1 (2002 est.)
Airports: 17(2001)
Airports ■ with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1, 523 m:1 (2001)
Airports - with unpaved runways:
fofa/:13
914 to 1,523 m: 10
under 914 m:3 (2001)','c59acc8d6b99d5978b7a211f020e22b7286187fc1b63aa2c142538c21abb75f3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60439edf1c40e8f620f8046c35c7620c9e8eb69841eb405cffd3a75dac0e4226',2002,'MR','Mauritania','transportation',833,'Railways: 704 km
standard gauge: 704 km 1.435-m gauge
note: owned and operated by government mining
company (2001)
Highways:
total: 7,720 km
paved: 830 km
unpaved: 6,890 km (2000)
Waterways:
note: ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none (2002 est.)
Airports: 26(2001)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 3
1,524 to 2,437 m: 6(2001)
Airports - with unpaved runways:
total: 17
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m:7
under 914 m: 3 (2001)','b0ca9c87c03d4053b2635dc73a98bcf3595083d34daba82d89ebb8853f05b370','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1649837d812c5ab22272d989c6cc757d491d4fe3f7e907736f98db810d2131d6',2002,'MU','Mauritius','transportation',842,'Railways: 0 km (2002)
Highways:
tote/: 1 ,860 km
paved: 1 ,786 km (including 36 km of expressways)
unpaved: 74 km (2001)
Waterways: none
Ports and harbors: Port Louis
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 66,004
GRT/90,017 DWT
ships by type: cargo 2, combination bulk 2, container
2, refrigerated cargo 2
note: includes some foreign-owned ships registered
here as a flag of convenience:, Belgium 1 , India 3,
Norway 1 , Switzerland 2 (2002 est.)
Airports: 5(2001)
Airports - with paved runways:
total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m: 2(2001)','83defea8d4c5abee23518886c90088b5e711d9b6ad6d919d24f427d209019ade','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ffa6f9e97a42e1540e542541a9b832aa8fa31f76f8cd71d49a1e04df7cecbed',2002,'YT','Mayotte','transportation',847,'Railways: 0 km (2002)
Highways:
total: 9 3 km
paved: 72 km
unpaved: 21 km
Waterways: none
Ports and harbors: Dzaoudzi
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)','9f99ef2ded0e08cc88a9b668bfd78098de792c27d9a96ca380302bef094bddf1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b5ba81d95c2138ddcc0b9659a0c48e8874cebba79fba40384b74db21e7c3db9',2002,'FM','Micronesia, Federated States of','transportation',850,'(continued)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437m: 2 (2001)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2001)
345
Midway Islands (continued)
Railways:
total: 1,328 km
broad gauge: 1,328 km 1.520-m gauge (2001)
Highways:
total: 20,000 km
paved: 13,900 km (includes some all-weather
gravel-surfaced roads)
unpaved: 6,100 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 30(2001)
Airports - with paved runways:
total: 7
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 23
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 14 (2001)','069de1db822e8da1bd7340d913dba9d579cf8585ec0cd9b7629f14c42132b198','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55538fd4d86b15b774ee98baa45ca1b5b0698c8880178acc1fe59a47ea579c5',2002,'MC','Monaco','transportation',865,'Railways:
total: 1.'' 7 km
standard gauge: 1.7 km 1.435-m gauge (2002)
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: Monaco
Merchant marine: none (2002 est.)
Airports: none; linked to airport in Nice, France, by
helicopter service (2001)
Heliports: 1 (shuttle service between the
international airport at Nice, France, and Monaco''s
heliport at Fontvieille) (2001)','7c64baa0aa64842b0cc37da3fe5eba57a38f86284cc3cfe5c3531eb6834c06dd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a136b863b24e5c66116192bf511130b707238676377c3da4aaa0c85493edc5',2002,'MS','Montserrat','transportation',872,'Highways:
total: 269 km
paved: 203 km
unpaved: 66 km (1995)
Waterways: none
Ports and harbors: Plymouth (abandoned), Little
Bay (anchorages and ferry landing), Carr’s Bay
Merchant marine: none (2002 est.)
Airports: none; the only airport was destroyed by
volcanic activity; a helicopter service to Antigua is
used (2001)','31684813842c2a540fd3ce3f9998dc82e2a648d74d82b4db1c7e3aead77cd3a8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b343c8cad7da50978977c71f2843f4fa161d66b24ab60f042757185b4c17978f',2002,'NA','Namibia','transportation',882,'Railways:
fo/af: 2,382 km
narrow gauge: 2,382 km 1 ,067-m gauge (2001 )
Highways:
total: 64,800 km
paved: 5,378 km
unpaved: 59,430 km (2001 )
Waterways: none
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none (2002 est.)
Airports: 137(2001)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437m: 14
914 to 1,523 m: 4(2001)
361
Namibia (continued)
Airports • with unpaved runways:
total: 115
2,438 to 3,047 m:2
1,524 lo 2,437 m: 21
914 to 1,523 m: 72
under 914 m: 20 (2001)
Unemployment rate: 0%
Budget:
revenues: $23.4 million
expenditures: $64.8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, offshore banking,
coconut products
Industrial production growth rate: NA%
Electricity - production: 30 million kWh (2000)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2000)
Electricity • consumption: 27.9 million kWh (2000)
Electricity - exports: 0 kWh (2000)
Electricity - imports: 0 kWh (2000)
Agriculture - products: coconuts
Exports: $25.3 million (f.o.b., 1991)
Exports - commodities: phosphates
Exports - partners: NZ, Australia, South Korea, US
(2000)
Imports: $21.1 million (c.i.f., 1991)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia, US, UK, Indonesia,
India (2000)
Debt - external: $33.3 million
Economic aid - recipient: $2.25 million from
Australia (FY96/97 est.)
Currency: Australian dollar (AUD)
Currency code: AUD
Exchange rates: Australian dollars per US dollar -
1 .9354 (January 2002) 1 .9320 (2001 ), 1 .71 73 (2000),
1.5497 (1999), 1.5888 (1998), 1.3439 (1997)
Fiscal year: 1 July - 30 June
Railways:
total: 5 km
note: gauge unknown; used to haul phosphates from
the center of the island to processing facilities on the
southwest coast (2001)
Highways:
total: 30 km
paved: 24 km
unpaved: 6 km (1998 est.)
Waterways: none
Ports and harbors: Nauru
Merchant marine: none (2002 est.)
Airports: 1 (2001)
363
Nauru (continued)
Airports - with paved runways:
total: 1
1,524 to 2.437 m: 1 (2001)
Waterways: none
Ports and harbors: none: offshore anchorage only','3e962c6810b2ac74253d57a7828cc7c09bcfc68102a97ab4e91f152a2c5d1cd1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9304a034148a871eec60318ef9bc66fa84339049cb2c1ee95c48466c898e62d0',2002,'NL','Netherlands','transportation',886,'Railways:
total: 59 km
narrow gauge: 59 km 0.762-m gauge
note: all in Kosi close to Indian border (2001)
Highways:
tofa/: 13,223 km
paved: 4,073 km
unpaved: 9,150 km (April 1999)
Waterways: none
Ports and harbors: none
Airports: 45(2001)
Airports - with paved runways:
total: 8
over 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 6 (2001)
Airports • with unpaved runways:
total: 37
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m: 29 (2001)
Railways:
total: 2,808 km
standard gauge: 2,808 km 1.435-m gauge (2,061 km
electrified) (2001)
Highways:
total: 116,500 km
paved: 104,850 km (including 2,235 km of
expressways)
unpaved: 1 1 ,650 km (1999)
Waterways: 5,046 km (of which 3,745 km are
canals)
note: 47% of total route length is usable by craft of
1 ,000-metric-ton capacity or larger
Pipelines: crude oil 418 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, Delfzijl, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht,
Vlissingen
Merchant marine:
total: 622 ships (1 ,000 GRT or over) totaling
4,587,662 GRT/5,251 ,529 DWT
ships by type: bulk 3, cargo 380, chemical tanker 46,
container 64, liquefied gas 16, livestock carrier 2,
multi-functional large-load carrier 15, passenger 9,
petroleum tanker 28, refrigerated cargo 34, roll on/roll
off 18, short-sea passenger 2, specialized tanker 5
note: includes some foreign-owned ships registered
here as a flag of convenience: Belgium 1 , Canada 1 ,
Denmark 5, Finland 5, Germany 55, Ireland 12,
Norway 12, Sweden 17, United Kingdom 33, United
States 12 (2002 est.)
Airports: 28 (2001)
Airports - with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m:7
1,524 to 2,437m: 6
914 to 1,523 m: 4
under 914 m:1 (2001)
Airports - with unpaved runways:
total: 8
914 to 1,523 m: 2
under 914 m: 6 (2001)
Heliports: 1 (2001)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','ca898fc96e794c8a21bb22a5564580dc7141ca993ac00f8aba7bce6cab509f73','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5439d6c993048532ed24b8ec5fe3276c9d786e7b30e1e335aac2b8068d2d7ed',2002,'VU','Vanuatu','transportation',897,'Railways: 0 km (2002)
Highways:
fofa/:4,825km
paved: 2,287 km
unpaved: 2,538 km (1999)
Waterways: none
Ports and harbors: Mueo, Noumea, Thio
Merchant marine:
total: 1 ships (1 ,000 GRT or over) totaling 1 ,261 GRT /
1 ,600 DWT
ships by type: cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Malaysia 1 (2002 est.)
Railways:
total: 3,908 km
narrow gauge: 3,908 km 1.067-m gauge (506 km
electrified) (2001)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1996)
Waterways: 1,609 km
note: of little importance in satisfying total
transportation requirements
Pipelines: petroleum products 160 km; natural gas
1,000 km; liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 68,427
GRT/1 06,627 DWT
ships by type: bulk 3, cargo 1 , container 1 , petroleum
tanker 2, roll on/roll off 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Australia 1 (2002 est.)
Airports: 106(2001)
Airports • with paved runways:
total: 44
over 3,047 m: 2
2,438 to 3,047 mA
1,524 to 2,437 m: 10
914 to 1,523 m: 28
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 62
1,524 to 2,437 mA
914 to 1,523 m: 24
under 914 m: 37 (2001)
Heliports: 1 (2001)
376
New Zealand (continued)
Railways:
total: 6 km
narrow gauge: 6 km 1 ,067-m gauge
note: carries mostly passengers from Chichigalpa to
Ingenio San Antonio (2001)
Highways:
total: 16,382 km
paved: 1,818 km
unpaved: 14,564 km (1998)
Waterways: 2,220 km (including 2 large lakes)
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none (2002 est.)
Airports: 182(2001)
Airports • with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 3
914 to 1,523 m: 3
under 914 m: 3 (2001)
Airports ■ with unpaved runways:
total: 171
1,524 to 2,437 m: 1
914 to 1,523 m: 25
under 914 m: 145 (2001)
Railways: 0 km
Highways:
total: 1,070 km
paved: 256 km
unpaved: 814 km (1996)
Waterways: none
Ports and harbors: Forari, Port-Vila, Santo (Espirilu
Santo)
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 1 ,092,838
GRT/1 ,329,576 DWT
ships by type: bulk 22, cargo 9, chemical tanker 1 ,
combination bulk 3, container 2, liquefied gas 3,
petroleum tanker 1 , refrigerated cargo 7, vehicle
carrier 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Australia 3, Canada 2,
China 1, Japan 25, Monaco 4, Netherlands 1, New
Zealand 5, Panama 1 , Poland 1 , Switzerland 2, United
Kingdom 4, US 2, Vietnam 1 (2002 est.)
Airports: 31 (2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 29
1,524 to 2,437m: 2
914 to 1,523 m: 10
under 914 m: 17 (2001)
Railways:
total: 682 km
standard gauge: 682 km 1.435-m gauge
note: 248 km of the existing system are privately
owned; passenger services are nonexistent; however,
a National Railways Plan, intended to provide a
significant railway system, has been initiated (2001)
Highways:
tofa/: 96,155 km
paved: 32,308 km
unpaved: 63,847 km (1997 est.)
Waterways: 7,100 km
note: Rio Orinoco and Lago de Maracaibo accept
oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz, Puerto Ordaz,
Puerto Sucre, Punta Cardon
Merchant marine:
total: 45 ships (1,000 GRT or over) totaling 716,361
GRT/1 ,267,095 DWT
ships by type: bulk 7, cargo 9, liquefied gas 3,
passenger/cargo 1 , petroleum tanker 1 4, roll on/roll off
10, short-sea passenger 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 1 , Greece 1 ,
Italy 1 , United Kingdom 1 , United States 2 (2002 est.)
Airports: 372 (2001)
Airports - with paved runways:
total: 124
over 3,047 m: 5
2,438 to 3,047 m: 11
1,524 to 2,437 m: 32
914 to 1,523 m: 59
under 914 m: 17 (2001)
Airports - with unpaved runways:
total: 248
1,524 to 2,437m: 11
914 to 1,523 m: 97
under 914 m: 140 (2001)
Heliports: 1 (2001)
Railways:
total: 3,142 km
standard gauge: 209 km 1.435-m gauge
narrow gauge: 2,625 km 1.000-m gauge
dual gauge: 308 km three-rail track combining
1.435-m and 1.000-m gauges (2001)
Highways:
total: 93,300 km
paved: 23,41 8 km
unpaved: 69,882 km (1996)
Waterways: 17,702 km
note: more than 5,149 km are navigable at all times by
vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minh City, Ha Long, Quy Nhon, Nha
Trang, Vinh,VungTau
Merchant marine:
total: 153 ships (1 ,000 GRT or over) totaling 782,912
GRT/1 ,173,186 DWT
ships by type: bulk 9, cargo 1 13, chemical tanker 1,
combination bulk 1 , container 5, liquefied gas 2,
petroleum tanker 20, refrigerated cargo 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Cambodia 1, Japan 1,
Singapore 1, United Kingdom 2 (2002 est.)
Airports: 34(2001)
Airports - with paved runways:
total: 17
over 3,047 m:8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 17
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 8 (2001)','44a96a197eca8789746aab046da7ba989c4696b9f8f2d366112881c59857a5c0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8c833b6596caa5e41cc9fb8022dcef292d2d8b9ab4f62f64088cf86611235d',2002,'NE','Niger','transportation',904,'Railways: Okm (2002)
Highways:
total: 10,100 km
paved: 798 km
unpaved: 9,302 km (1996)
Waterways: 300 km
note: the Niger River is navigable from Niamey to
Gaya on the Benin frontier from mid-December
through March
Ports and harbors: none
Airports: 26(2001)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 6
under 914 m: 1 (2001)
Airports • with unpaved runways:
total: 17
1,524 to 2,437 m:t
914 to 1,523 m: 14
under 914 m: 2 (2001)','ca284a775abfee5e7206b8d2d4fd410db3adff436c580916f7f94a4fb1115df0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dceb04cdbf25ce2c40ca716662373af0e671baf688c15ffccf8e3facbd957137',2002,'MP','Northern Mariana Islands','transportation',918,'Railways: 0 km
Highways:
total: 362 km
paved: NA km
unpaved.'' NA km (1991)
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none (2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: 3
2,438 to 3,047m: 1
1,524 to 2,437 m: 2 (2001)
Airports - with unpaved runways:
total: 3
2,438 to 3,047 m:1
under 914 m: 2 (2001)
Heliports: 1 (2001)
Waterways: none
Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (2001)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2001)
Transportation - note: formerly an important
commercial aviation base, now used by US military,
some commercial cargo planes, and for emergency
landings
557
Wake Island (continued)','26a0d5dc4ce110c2b66d0a3094a23bcecdf22cd37fa7f30959166c272c3200b5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f625314860c74e1c4b9a83fc9bd138ca7452f928129d1a9eb67cf7faa63336',2002,'PK','Pakistan','transportation',928,'Railways:
total: 8,163 km
broad gauge: 7,718 km 1.676-m gauge (293 km
electrified)
narrow gauge: 445 km 1 .000-m gauge (2001 )
Highways:
total: 247,811 km
paved: 141,252 km (including 339 km of
expressways)
unpaved : 106,559 km (1998)
Waterways: none
Pipelines: crude oil 250 km; petroleum products 885
km; natural gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin
Qasim
Merchant marine:
total: 17 ships (1 ,000 GRT or over) totaling 241 ,832
GRT/367,093 DWT
ships by type: cargo 13, container 3, petroleum
tanker 1 (2002 est.)
Airports: 120(2001)
Airports - with paved runways:
total: 85
over 3,047 m: 12
2,438 to 3,047 m: 22
1,524 to 2,437 m: 31
914 to 1,523 m: 17
under 914 m: 3 (2001)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 18 (2001)
Heliports: 9 (2001)','77df7e0fc9e0c03b63e1750c12c41d30167b80484dff68ac715da99deef2bb21','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acf1eb9ef070dba126125bd034f033315e40ad64645436d354a0dbb30ba44b20',2002,'PW','Palau','transportation',937,'Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Waterways: none
Ports and harbors: Koror
Merchant marine: none (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2001)
Airports • with unpaved runways:
total: 2
1,524 to 2,437 m: 2(2001)
Highways: much of the road and many causeways
built during World War II are unserviceable and
overgrown (2001)
Waterways: none
Ports and harbors: West Lagoon
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2001)','fd657935b524a911955d6e544b4807dec217bb7415d8ebf40c836db49243d0bb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2a64788000d0f43eca23a8adecbab25802e2598d9bca53d00e350f89257398d',2002,'PA','Panama','transportation',945,'Railways:
total: 355 km
broad gauge: 76 km 1 ,524-m gauge
narrow gauge: 279 km 0.91 4-m gauge (2001)
Highways:
total: 11,592 km
paved: 4,079 km (including 30 km of expressways)
unpaved: 7,513 km (2000)
Waterways: 882 km
note: 800 km navigable by shallow draft vessels; 82
km Panama Canal
Pipelines: crude oil 1 30 km (2001 )
Ports and harbors: Balboa, Cristobal, Coco Solo,
Manzanillo (part of Colon area), Vacamonte
Merchant marine:
total: 4,838 ships (1 ,000 GRT or over) totaling
118,878,358 GRT/180,588, 102 DWT
ships by type: bulk 1 ,445, cargo 907, chemical tanker
337, combination bulk 73, combination ore/oil 18,
container 560, liquefied gas 207, livestock carrier 5,
multi-functional large-load carrier 12, passenger 38,
passenger/cargo 3, petroleum tanker 542, railcar
carrier 2, refrigerated cargo 283, roll on/roll off 104,
short-sea passenger 38, specialized tanker 34,
vehicle carrier 230
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 2, Angola 1,
Antigua and Barbuda 1, Argentina 11, Australia 13,
Austria 2, Bahamas, The 5, Belgium 2, Belize 6,
Brazil 6, British Virgin Islands 8, Cambodia 1,
Canada 9, Chile 12, China 259, Colombia 14,
Croatia 2, Cuba 20, Cyprus 3, Denmark 3, Dominican
Republic 1 , Ecuador 3, Egypt 16, Equatorial Guinea 1 ,
France 9, Germany 72, Greece 523, Haiti 1,
Honduras 3, Hong Kong 299, Iceland 1 , India 18,
Indonesia 48, Ireland 1, Israel 5, Italy 9, Japan 1642,
Kenya 1 , Kuwait 2, Latvia 8, Liberia 5, Lithuania 1 ,
Malaysia 18, Malta 2, Marshall Islands 1, Mexico 8,
Monaco 112, Netherlands 19, Netherlands Antilles 1,
Nigeria 3, Norway 98, Paraguay 1 , Peru 15,
Philippines 49, Poland 5, Portugal 7, Puerto Rico 2,
Romania 7, Russia 12, Saint Kitts and Nevis 1, Saint
Vincent and the Grenadines 5, Saudi Arabia 4,
Seychelles 1, Singapore 1 12, South Africa 3, South
Korea 342, Spain 52, Sri Lanka 3, Sudan 1 ,
Sweden 2, Switzerland 81 , Taiwan 334, Thailand 14,
Trinidad and Tobago 1 , Tunisia 1, Turkey 4,
Ukraine 1, United Arab Emirates 54, United
Kingdom 73, United States 115, Venezuela 6, Virgin
Islands (UK) 8 (2002 est.)
Airports: 107(2001)
Airports - with paved runways:
total: 42
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 21 (2001)
Airports -with unpaved runways:
total: 65
914 to 1,523 m: 12
under 914 m: 53 {2001)','1ff5a4053284efc0b048745fa99dd4515fdf6f076347a1ed63be8f3483dcb010','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40dabc5b052b42380c1764b6e9044ce8e165c920329b05575bf9d06f511557e1',2002,'PH','Philippines','transportation',953,'Waterways: none
Ports and harbors: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 1 (2001)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2001)','d2fe6f00db483dbdd3a089157c91653691667108b224934920e074e7c8bee29d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbbbc98a6249c174946435ed6d0f426bf616b8fba59fe1127ee2ee523a730c7a',2002,'AR','Argentina','transportation',957,'Railways:
total: 971 km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1 ,000-m gauge
note: there are 470 km of various gauges that are
privately owned
Highways:
total: 25,901 km
paved: 3,067 km
unpavecf: 22,834 km (2001)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encamacion
Merchant marine:
total: 21 ships (1 ,000 GRT or over) totaling 34,623
GRT/36,821 DWT
ships by type: cargo 1 4, chemical tanker 1 , petroleum
tanker 3, roll on/roll off 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 2, Japan 1
(2002 est.)
408
Paraguay (continued)
Airports: 899(2001)
Airports - with paved runways:
total: 1 1
over 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 4 (2001)
Airports - with unpaved runways:
total: 888
1,524 to 2,437 m: 28
914 to 1,523 m: 332
under 914 m: 528 (2001)','b7d9ebf6a460b9f8cd34b6e3910ec73d364a696cdcd9fd0a76e0e05dd6344fad','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8773a73982384cf705e1d7c7a443be0900eec03ec45c88f6360217cb0508432',2002,'QA','Qatar','transportation',973,'Railways: 0 km
Highways:
total: 1,230 km
paved: 1,107 km
unpaved: 123 km (1996)
Waterways: none
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul Island, Umm Sa''id
(Musay’id) ''
Merchant marine:
total: 25 ships (1,000 GRT or over) totaling 679,081
GRT/1 ,051,088 DWT
ships by type: cargo 10, combination ore/oil 2,
container 7, petroleum tanker 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Kuwait 1, United Arab
Emirates 3 (2002 est.)
Airports: 4 (2001)
Airports - with paved runways:
total: 2
over 3,047 m: 2(2001)
Airports - with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2001)
Heliports: 1 (2001)','3d30d6b8a00cb73ac660c27ec28a075df4ccce67ab336414db5c4e3b168a042a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83c5fbd68fcd4d9081b7377a872409bfde759d56f1cab313ae16dcc8a4755c54',2002,'UA','Ukraine','transportation',980,'Railways:
total: 1 1 ,385 km (3,888 km electrified)
standard gauge: 10,898 km 1.435-m gauge
broad gage: 60 km 1.524-m gauge
narrow gauge: 427 km 0.760-m gauge (2001)
Highways:
total: 153,359 km
paved : 103,671 km (including 133 km of
expressways)
unpaved: 49,688 km (1998 est.)
Waterways: 1,724 km (1984)
Pipelines: crude oil 2,800 km; petroleum products
1,429 km; natural gas 6,400 km (1992)
Ports and harbors: Braila, Constanta, Galati,
Mangalia, Sulina, Tulcea
Merchant marine:
total: 70 ships (1 ,000 GRT or over) totaling 561 ,470
GRT/754,836 DWT
ships by type: bulk 1 1 , cargo 47, passenger 1 ,
passenger/cargo 1, petroleum tanker 4, railcar
carrier 2, roll on/roll off 4
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 1, Italy 5
(2002 est.)
Airports: 61 (2001)
Airports - with paved runways:
total: 24
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 11 (2001)
Airports - with unpaved runways:
total: 37
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m: 23(2001)
Heliports: 2(2001)
Railways:
total: 87,157 km
broad gauge: 86,200 km 1 ,520-m gauge (40,300 km
are electrified)
narrow gauge: 957 km 1 .067-m gauge (installed on
Sakhalin Island)
note: an additional 63,000 km of broad gauge routes
sen/e specific industries and are not available for
common carrier use (2002)
Highways:
total: 952,000 km
433
Russia (continued)
paved: 752.000 km (including about 336,000 km of
conventionally paved roads, and about 41 6,000 km of
roads with all-weather gravel surfaces)
unpaved: 200,000 km (these roads are made of
unstabilized earth and are difficult to negotiate in we!
weather) (1998)
Waterways: 95,900 km (total routes in genera! use)
note: routes with navigation guides serving the
Russian River Fleet - 95,900 km; routes with night
navigational aids - 60,400 km; man-made navigable
routes - 16,900 km (Jan 1994)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (June 1993 est.)
Ports and harbors: Aleksandrovsk-Sakhalinsky,
Arkhangelsk, Astrakhan'', De-Kastri, Indigirskiy,
Kaliningrad, Kandalaksha, Kazan'', Khabarovsk,
Kholmsk, Krasnoyarsk, Lazarev, Mago, Mezen’,
Moscow, Murmansk, Nakhodka, Nevel''sk,
Novorossiysk, Onega, Petropavlovsk-Kamchatski
Rostov, Shakhtersk, Saint Petersburg, Sochi,
Taganrog, Tuapse, Uglegorsk, Vanino, Vladivostok,
Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 888 ships (1 ,000 GRT or over) totaling
4,390,745 GRT/5,357,436 DWT
ships by type: barge carrier 1 , bulk 21 , cargo 556,
chemical tanker 7, combination bulk 21, combination
ore/oil 6, container 29, multi-functional large-load
carrier 1 , passenger 41 . passenger/cargo 3,
petroleum tanker 153, refrigerated cargo 22, roll on/
roll off 20, short-sea passenger 7
note: includes some foreign-owned ships registered
here as a flag of convenience: Belize 1 , Cambodia 1 ,
Cyprus 9, Denmark 1 , Estonia 4, Greece 3, Honduras
1, Latvia 4, Lithuania 3, Moldova 3, Netherlands 1,
South Korea 1 , Turkey 18, Turkmenistan 2, Ukraine
10, United Kingdom 5, United States 1 (2002 est.)
Airports: 2,743(2001)
Airports - with paved runways:
total: 471
over 3,047 m: 56
2,438 to 3.047 m:m
1,524 to 2.437 m: 76
914 to 1,523 m: 69
under 914 m:92 (2001)
Airports - with unpaved runways:
total: 2,272
over 3,047 m: 28
2,438 to 3,047 m: 118
1,524 to 2,437 m: 204
914 to 1,523 m: 324
under 914 m: 1,598 (2001)
Railways: 0 km
Highways:
total: 12,000 km
paved: 1 ,000 km
unpaved: 1 1 ,000 km (1997 est.)
Waterways:
note: Lac Kivu navigable by shallow-draft barges and
native craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 8(2001)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 4
914 to 1,523 m:1
under 914 m: 3(2001)
Railways:
tofa/: 22,510 km
broad gauge: 21 ,951 km 1 ,524-m gauge (8,927 km
electrified)
standard gauge: 49 km 1 .435-m gauge
narrow gauge: 51 0 km 0.750-m gauge
note: these data do not include railroads dedicated to
serving industry and not in common carrier service
(2001)
Highways:
total: 273,700 km
paved: 236,400 km (including 1 ,770 km of
expressways and a substantial amount of all-weather
roads with gravel surfaces)
unpaved: 37,300 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 4,499 km
note: 1 ,672 km are on the Pryp''yaf and Dniester
(Dnister) (1990)
Pipelines: crude oil 4,000 km (1995); petroleum
products 4,500 km (1995); natural gas 34,400 km
(1998)
Ports and harbors: Berdyans''k, Feodosiya,
lllichivs''k, Izmayil, Kerch, Kherson, Kiev (Kyyiv),
Kiliya, Mariupol'', Mykolayiv, Odesa, Reni,
Sevastopol'', Yalta, Yuzhnyy
Merchant marine:
total: 138 ships (1 ,000 GRT or over) totaling 669,303
GRT/707,857 DWT
ships by type: bulk 7, cargo 1 00, container 3, liquefied
gas 2, passenger 11, passenger/cargo 1, petroleum
tanker 12, railcar carrier 2
note: includes some foreign-owned ships registered
here as a flag of convenience: Cyprus 1, Greece 1,
Panama 1 , Russia 4, Saint Vincent and the
Grenadines 1 (2002 est.)
Airports: 718(2001)
Airports - with paved runways:
total: 114
over 3,047 m: 14
2,438 to 3,047 m: 50
1,524 to 2,437m: 21
914 to 1,523 m: 3
under 914 m:26 (2001)
Airports - with unpaved runways:
total: 604
over 3,047 m: 13
2,438 to 3,047 m: 37
1,524 to 2,437 m: 52
914 to 1,523 m: 45
under 914 m: 457 (2001)','5d29ba8275be14ab454dc5bb3709683e8d4e755ec6eb5996de7dc0d421a605a1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('133ec63e7262269e359b565d0e6012e39be34b1579e573fc53fbaa7447df3584',2002,'UG','Uganda','transportation',992,'Railways: 0 km
Highways:
total: 1 58 km (Saint Helena 1 1 8 km. Ascension 40 km,
Tristan da Cunha 0 km)
paved: 1 38 km (Saint Helena 98km, Ascension 40 km,
Tristan da Cunha 0 km)
unpaved : 20 km (Saint Helena 20 km, Ascension 0
km, Tristan da Cunha 0 km)
Waterways: none
Ports and harbors: Georgetown (on Ascension),
Jamestown
Merchant marine: none (2002 est.)
Airports: 1 (2001)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2001)','f348565e0ce931aea19b7bb4c814cbd1509639421ccc676dbfecd0b3d0765f39','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('085135cb933c3a164e72b0a661c04fa30940af0130320f5210bcbcf74097b9eb',2002,'TT','Trinidad and Tobago','transportation',998,'Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations (2002)
Highways:
total: 320 km
paved: 136 km
unpaved: 184 km (2000)
Waterways: none
Ports and harbors: Basseterre, Charlestown
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1, 523 m: 1 (2001)','25d7ac8ee90e21dc2d60bc4f7b9942e17562cbf62912bd5656277061bfbf89f9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42da8631a1cb8a5aa9384110fa2414a14ae09cc574bfe67790059482563b31f7',2002,'MQ','Martinique','transportation',1002,'Railways: Okm
Highways:
total: 1,210 km
paved: 63 km
unpaved: 1,147 km (1996)
Waterways: none
Ports and harbors: Castries, Vieux Fort
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2001)
Railways: Okm
Highways:
tofa/:114km
paved: 69 km
unpaved: 45 km (1994 est.)
Waterways: none
Ports and harbors: Saint Pierre
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports • with paved runways:
total: 2
1,524 to 2,437 m:1
914 tol, 523 m: 1 (2001)','7eaae00f0895fd9e77a56ab8a32427721bfaca835f22b559ad3a622b1970a86e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb983313b9e15cea582ed776068da4395c86e92c92e3408205ce6b49256ed61b',2002,'VC','Saint Vincent and the Grenadines','transportation',1005,'(continued)
ships by type: barge carrier 1 , bulk 1 42, cargo 382,
chemical tanker 24, combination bulk 1 1 , combination
ore/oil 3, container 47, liquefied gas 7, livestock
carrier 3, multi-functional large-load carrier 2,
passenger 3, petroleum tanker 48, refrigerated
cargo 39, roll on/roll off 52, short-sea passenger 13,
specialized tanker 1 0, vehicle carrier 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Albania 1 , Anguilla 1 ,
Argentina 1, Australia 2, Bahamas, The 1,
Bangladesh 1, Barbados 2, Belgium 4, Bulgaria 14,
Canada 1, Cayman Islands 1, China 135, Colombia 1 ,
Croatia 12, Cyprus 6, Denmark 1 6, Egypt 7, Estonia 6,
France 27, Germany 12, Greece 156, Guyana 7,
Hong Kong 23, Iceland 1, India 11, Indonesia 3,
Israel 2, Italy 19, Japan 1, Kenya 4, Latvia 5,
Lebanon 9, Liberia 5, Lithuania 1, Malta 1, Man, Isle
of 1, Marshall Islands 3, Mexico 1, Monaco 6,
Netherlands 14, Netherlands Antilles 1, Nigeria 3,
Norway 33, Pakistan 5, Panama 2, Poland 2,
Portugal 2, Puerto Rico 2, Russia 8, Saint Kitts and
Nevis 1, Saudi Arabia 3, Singapore 4, Slovenia 7,
South Korea 4, Spain 1, Sweden 6, Switzerland 10,
Syria 2, Taiwan 1 , Thailand 1 , Trinidad and Tobago 1 ,
Tunisia 1, Turkey 15, Ukraine 8, United Arab
Emirates 45, United Kingdom 16, United States 25,
Vietnam 1 (2002 est.)
Airports: 6(2001)
Airports - with paved runways:
total: 5
914 to 1,523 m: 4
under 914 m:1 (2001)
Airports • with unpaved runways:
total: 1
under 914 m:1 (2001)','063483b8d3c20a7b1df9cbbf50ac055c34b28f28a4dfbacafcf4eb5b84a34725','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c8c4549ab9e35cb8318336b135e18df65563eeffb40d5e6cbb8bd9e3a63526',2002,'WS','Samoa','transportation',1013,'Railways: Okm
Highways:
total: 836 km
paved: 267 km
unpaved: 569 km (1983)
Waterways: none
Ports and harbors: Apia, Asau, Mulifanua,
Salelologa
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 7,091
GRT/ 8,127 DWT
ships by type: cargo 1
note: includes a foreign-owned ship registered here
as a flag of convenience: Germany 1 (2002 est.)
Airports: 3(2001)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1 (2001)
Airports - with unpaved runways:
total: 1
under 91 4 mA (2001)','84058378a8d956b532e7c83d62d0ef671ce05f848d7f9255e207a622e78d7499','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('714fd0c897e81f167923f19b603d1a8577c50ad3ff52e8ffed743ca70cf0a5e6',2002,'SM','San Marino','transportation',1021,'Railways: 0 km; note - there is a 1 .5-km cable
railway connecting the city of San Marino to Borgo
Maggiore
Highways:
total: 220 km
paved: 220 km
unpaved: 0 km (2001)
Waterways: none
Ports and harbors: none
Airports: none (2001)','eefc5708bc76ee1ea2b2a9d23bd7fe317444416b3c7279096ec28809c95a262e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2f5b41ae86c28eab83e52fe2817fd7600e5cbbf3114b2eafba524d6f12e8ab1',2002,'SA','Saudi Arabia','transportation',1030,'Railways:
total: 1,392 km
standard gauge: 1 ,392 km 1.435-m gauge (724 km
are double-tracked) (2001)
Highways:
total: 146,524 km
pavecf: 44,104 km
unpaved: 102,420 km (1997 est.)
Waterways: none
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1 ,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Mishab, Ras
Tanura, Yanbu'' al Bahr, Madinat Yanbu1 al Sinaiyah
Merchant marine:
total: 71 ships (1 ,000 GRT or over) totaling 1 ,071 ,31 5
GRT/1 ,412,125 DWT
ships by type: cargo 1 1 , chemical tanker 1 0,
container 4, livestock carrier 3, passenger 1,
petroleum tanker 20, refrigerated cargo 3, roll on/roll
off 1 1 , short-sea passenger 8
note: includes some foreign-owned ships registered
here as a flag of convenience: Egypt 3, Finland 1 ,
Greece 3, Kuwait 1 , Sudan 1 , United Arab Emirates 1 ,
United Kingdom 3 (2002 est.)
Airports: 209(2001)
Airports - with paved runways:
total: 71 70
over 3,047 m: 31 31
2,438 to 3,047m: 1211
1,524 to 2,437 m: 23 23
914 to 1,523 m: 3 3
under 914 m: 2 2 (2001)
Airports - with unpaved runways:
total: 138
2,438 to 3,047 m: 3
1,524 to 2,437 m: 79
914 to 1,523 m: 39
under 914 m: 15 (2001)
Heliports: 5(2001)
453
Saudi Arabia (continued)','7ad7514c5106b3b77f2222b5716c5610a9c21bf2edc3349662b34b0350cddc01','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3d331153a2f2e404a986b01009ad9218650af7ba55639bb9cb78fe9fc8f63e4',2002,'SN','Senegal','transportation',1038,'Railways:
total: 906 km
narrow gauge: 906 km 1.000-meter gauge (70 km
double-tracked) (2001)
Highways:
total: 14,576 km
paved: 4,271 km
unpaved: 10,305 km (1996)
Waterways: 897 km
note: 785 km on the Senegal river, and 1 12 km on the
Saloum river
Ports and harbors: Dakar, Kaolack, Matam, Podor,
Richard Toll, Saint-Louis, Ziguinchor
Airports: 20(2001)
Airports - with paved runways:
total: 9
over 3,047m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2001)
Airports - with unpaved runways:
total: 11
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 1 (2001)','1e7b2bf575a9a38045e96fb0806392d7189061b51395d9e3701fa5a7bcd1a2a8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0ce8e55f2518c81217d1b2f2ed19904bcf108e6042d7737486a7c816db6714b',2002,'SC','Seychelles','transportation',1047,'Railways: Okm
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1997)
Waterways: none
Ports and harbors: Victoria
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 7,086 GRT /
10,192 DWT
ships by type: cargo 2
note: includes some foreign-owned ships registered
here as a flag of convenience: South Africa 2
(2002 est.)
Airports: 14(2001)
Airports - with paved runways:
total: 7
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2001)','b0ee11b4db7edcf0b1b6d18be477ffbdb549128c6de8cffd4db6f282626b3050','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d814722b19eab4f49d5d1d6ab1d1f7f890cbccac38fd9f50852f228a0cf990a0',2002,'SL','Sierra Leone','transportation',1055,'Railways:
to/af;84km
narrow gauge: 84 km 1.067-m gauge
nofe: Sierra Leone has no common carrier railroads;
the existing railroad is private and used on a limited
basis while the mine at Marampa is closed (2001)
Highways:
total: 1 1,700 km
paved: 936 km
unpaved: 10,764 km (2002)
Waterways: 800 km (of which 600 km navigable year
round)
Ports and harbors: Bonthe, Freetown, Pepel
Airports: 10(2001)
Airports • with paved runways:
total: 1
over 3,047 m:1 (2001)
Airports - with unpaved runways:
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2001)
Heliports: 2 (2001)','b6616817c8fa164d9b867504769d9f58061a3e9e10872b74066bee530ff9048a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('873672ec741715ae1338d86737ec7f78adbf5f83ce88bf55879bec64f0226d1f',2002,'SO','Somalia','transportation',1073,'Railways: 0 km
Highways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (1996)
Waterways: none
Pipelines: crude oil 15 km
Ports and harbors: Boosaaso, Berbers. Chisimayu
(Kismaayo), Merca. Mogadishu
Merchant marine: none (2002 est.)
Airports: 54(2001)
Airports - with paved runways:
total: 6
over 3,047 m: 4
1,524 to 2,437 m:1 (2001)
Airports - with unpaved runways:
total: 48
2,438 to 3,047m: 3
1,524 to 2,437 m: 15
914 to 1,523 m: 27
under 91 4 m: 3 (2001)','d6699e8ab4a3a9118a5c6c3d2b0dbc9f91a2dd2ad691386d8bd27b6595073343','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8249530d9a6ac4dc653ce7c25b3f11cb45317980d894e9b87e250171520381c1',2002,'DZ','Algeria','transportation',1084,'Railways:
total: 15.171 km
broad gauge: 12,781 km''1.668-m gauge (6,434 km
electrified)
standard gauge: 525 km 1.435-m gauge (525 km
electrified)
narrow gauge: 1,837 km 1.000-m gauge (617 km
electrified); 28 km 0.914-m gauge (28 km electrified)
(2001)
Highways:
total: 346,858 km
paved: 343,389 km (including 9,063 km of
expressways)
unpaved: 3,469 km (1997)
Waterways: 1 ,045 km (of minor economic
importance)
Pipelines: crude oil 265 km; petroleum products
1,794 km; natural gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilia, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Santander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 144 ships (1 ,000 GRT or over) totaling
1,364,751 GRT/1, 962, 764 DWT
ships by type: bulk 10, cargo 31, chemical tanker 10,
container 10, liquefied gas 2, livestock carrier 1 ,
passenger 2, petroleum tanker 24, refrigerated cargo
8, roll on/roll off 35, short-sea passenger 8, vehicle
carrier 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Croatia 1 , Cuba 2,
Denmark 1 , Germany 7, Italy 1 , Netherlands 1 ,
Norway 6, Uruguay 3 (2002 est.)
Airports: 133(2001)
Airports - with paved runways:
total: 85
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 18
914 to 1,523 m: 19
under 914 m: 23 (2001)
Airports • with unpaved runways:
total: 48
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 33 (2001)
Heliports: 5(2001)
Waterways: none
Ports and harbors: none; offshore anchorage only
Airports: 4(2001)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (2001)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (2001)
Railways:
total: 1,463 km
broad gauge: 1 ,404 km 1 .676-m gauge
narrow gauge: 59 km 0.762-m gauge (2001)
Highways:
total: 11,285 km
paved: 10,721 km
unpaved: 564 km (1998 est.)
Waterways: 430 km (navigable by shallow-draft
craft)
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine:
total: 18 ships (1 ,000 GRT or over) totaling 137,321
GRT/233,367 DWT
ships by type: bulk 1 , cargo 1 5, container 1 , petroleum
tanker 1 , includes some foreign-owned ships
registered here as a flag of convenience: Germany 9,
Hong Kong 1, United Arab Emirates 1 (2002 est.)
Airports: 15(2001)
Airports - with paved runways:
total: 14
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 6(2001)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2001)','63121c799d0e345d6904435f44a77a5e7f5064e59725d64dca843bcd0a37070e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c860f1941bd60523e37fd667b74e3e80d2a048e7e7367ec02f6e0eddfb8d986d',2002,'TK','Tokelau','transportation',1109,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: none; offshore anchorage only
Merchant marine: none (2002 est.)
Airports: none; lagoon landings are possible by
amphibious aircraft (2001)
511
Tokelau (continued)','b870eaa7afe75750c63a18a774721bb4c8634b4cc58b7475f173c43f672bedf0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e7543ed605205869791e3663763ad47425ed6e07137bc03eda4d87c5b559136',2002,'TM','Turkmenistan','transportation',1120,'Railways:
total: 2,440 km
broad gauge: 2,440 km 1.520-m gauge (2001)
Highways:
total: 22,000 km
paved: 18,000 km (includes some all-weather
gravel-surfaced roads)
unpaved: 4,000 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1996)
Waterways: the Amu Darya is an important inland
waterway for Turkmenistan
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbasy
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 4,600 GRT/
5,000 DWT
ships by type: petroleum tanker 1 (2002 est.)
Airports: 76(2001)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4 ( 2001)
Airports - with unpaved runways:
total: 63
2,438 to 3,047 m: 7
1,524 to 2,437m: 5
914 to 1,523 m: 10
under 914 m: 41 (2001)','13d9ea9a93011c7b13cce3af41852b0784ba2ae772ed38de288aa6db332ed197','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d6a60bda1740b4926c25f27f974ddeb8cb6e977ea141479838486086e7c92d2',2002,'TV','Tuvalu','transportation',1130,'Railways: 0 km
Highways:
total: 19.5 km
paved: 0 km
unpaved: 19.5 km (2002)
Waterways: none
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 31 ,021
GRT/52,198 DWT
ships by type: cargo 3, passenger/cargo 1 , petroleum
tanker 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 5 (2002 est.)
Airports: 1 (2001)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m:1 (2001)
Railways:
total: 1,241 km
narrow gauge: 1,241 km 1.000-m gauge
note: a program to rehabilitate the railroad is
underway (2001)
Highways:
total: 27,000 km
paved: 1 ,800 km
unpaved: 25,200 km (of which about 4,200 km are
all-weather roads) (1990)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,091 GRT I
8,229 DWT
ships by type: roll on/roll off 3
note: these ships are in cargo and passenger (ferry)
service on Uganda’s inland waterways (2002 est.)
Airports: 27(2001)
Airports - with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2,437 mA (2001)
Airports - with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m:6
914 to 1,523 m: 9
under 91 4 m: 7 (2001)','fdf06d5a6b80f578d1b257366288267eee925f45696997515dd01a6da902e128','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6f9888c40f6f13de342acd4aad2728caf97928e7af4325167b23677bfeefd0',2002,'OM','Oman','transportation',1140,'Railways: 0 km
Highways:
total: 4,835 km
paved: 4,835 km
unpaved: 0 km (1998 est.)
Waterways: none
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, A! Fujayrah, Das Island,
Khawr Fakkan, Mina'' Jabal ''Ali, Mina'' Khalid, Mina''
Rashid, Mina'' Saqr, Mina'' Zayid, Umm al Qaywayn
Merchant marine:
total: 56 ships (1,000 GRT or over) totaling 833,401
GRT/1,251 ,015 DWT
ships by type: cargo 1 3, chemical tanker 3, container
7, liquefied gas 1 , livestock carrier 1 , petroleum tanker
25, roll on/roll off 6
note: includes some foreign-owned ships registered
here as a flag of convenience: Greece 2, Italy 1 ,
Kuwait 2 (2002 est.)
Airports: 38(2001)
Airports - with paved runways:
total: 19 22
over 3,047 m: 8 8
2,438 to 3,047 m: 3 3
1,524 to 2, 437 m: 2 4
914 to 1,523 m: 2 3
under 914 m: 4 4 (2001)
Airports - with unpaved runways:
total: 19 19
over 3,047 m: 1 1
2,438 to 3,047 m: 11
1,524 to 2,437m: 3 3
914 to 1,523 m: 9 9
under 914 m: 5 5 (2001)
Heliports: 2(2001)','dc5d6dbf4a39c04773c9cabf893b93c09a6f085e29eaec64d9ad5b5540c2d4ae','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea5386dff5ac650af741286faa37b81eb7babbd7987d40b62ca19fdc009b41f7',2002,'UY','Uruguay','transportation',1149,'Railways:
total: 2,993 km
standard gauge: 2,993 km 1 ,435-m gauge
note: of the total route length, 461 km have been
taken out of service and 460 km are in only partial use;
moreover, not all lines offer passenger service (2001 )
Highways:
total: 8,764 km
paved: 7,800 km
unpaved: 964 km (2001)
Waterways: 1 ,600 km (used by coastal and
shallow-draft river craft)
Ports and harbors: Colonia, Fray Bentos, Juan La
Caze, La Paloma, Montevideo, Nueva Palmira,
Paysandu, Punta del Este, Piriapolis
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 7,752 GRT /
5,228 DWT
ships by type: petroleum tanker 1 , roll on/roll off 1
note: includes some foreign-owned ships registered
here as a flag of convenience: Argentina 4, Greece 1
(2002 est.)
Airports: 64(2001)
Airports - with paved runways:
total: 15
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m:7
under 914 m: 2 (2001)
Airports • with unpaved runways:
total: 49
1,524 to 2,437 m: 2
914 to 1,523 m: 16
under 914 m: 31 (2001)','dc197158d804652f4b124f384bba4ad48fde9110bad173583ec58b162326592a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405cdb024556ecfe1f41011f56dc63ab64c3ee8adb836c39996fec7fb212b3b1',2002,'UZ','Uzbekistan','transportation',1158,'Railways:
total: 3,656 km
broad gauge: 3,656 km 1.520-m gauge (618 km
electrified) (2000)
Highways:
to/a/: 81 ,600 km
paved: 71 ,237 km (includes some all-weather
gravel-surfaced roads)
unpaved: 10,363 km (these roads are made of
unstabilized earth and are difficult to negotiate in wet
weather) (1990)
Waterways: 1,100 km (1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya)
Airports: 267(2001)
Airports - with paved runways:
ftrfaMO
over 3,047 m: 3
2,438 to 3,047 m: 5
under 914 m: 2 (2001)
Airports - with unpaved runways:
total: 257
over 3,047m: 3
2,438 to 3,047 m: 8
1,524 to 2,437 m: 11
914 to 1,523 m: 13
under 914 m: 222 (2001)','69526afa4b7b557ec90eb910aa1c1f1a76732656c0be87d60033f7b98de2a23f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05c0c013a23219c4450ec96333e9e48f2e753b1d1513a6283f2dce1dcea353ee',2002,'PR','Puerto Rico','transportation',1165,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km (2000)
Waterways: none
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine: none (2002 est.)
Airports: 2(2001)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2(2001)','419b4817c980e622f769866f0d7b299d2b5fe595f9d4691b4a23f7684dbd3d31','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d050485e584eb9738c365bbecbb1b2b91c3081ffae8ee0e3ee290ca236db0f20',2002,'EH','Western Sahara','transportation',1176,'Railways: 0 km
Highways:
total: 6,200 km
paved: 1,350 km
unpavecf:4,850 km (1991 est.)
Waterways: none
Ports and harbors: Ad Dakhla, Cabo Bojador,
Laayoune (El Aaiun)
Airports: 11 (2001)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 (2001)
Airports • with unpaved runways:
total: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2001)
Railways:
total: 1,201,337 km includes about 190,000 to
195,000 km of electrified routes of which 147,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,160 km in
North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) - Atlantique line
broad gauge: 251 ,1 53 km
standard gauge: 710,754 km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina'' al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama','6f6b03842cfabf118eda49b0a9489da660aff50e79dac5e7f8931cf459c0d1f4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ef615a53a910bbcb9767973009126f919096c170720f7dc5468c8cab2e1a60',2002,'YE','Yemen','transportation',1185,'Railways: 0 km
Highways:
total: 69,263 km
paved: 9,963 km
unpaved: 59,300 km (1 999)
567
Yemen (continued)
Waterways: none
Pipelines: crude oil 644 km; petroleum products
32 km
Ports and harbors: Aden, Al Hudaydah, Al Mukalla,
As Salif, Ras Issa, Mocha, Nishtun
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 1 5,002
GRT/23,752 DWT
ships by type: cargo 1 , petroleum tanker 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Hong Kong 2
(2002 est.)
Airports: 49(2001)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2001)
Airports - with unpaved runways:
total : 35
over 3,047 m: 2
2,438 to 3.047 m: 8
1,524 to 2,437 m: 8
914 to 1,523 m: 13
under 914 m: 4 (2001)
Railways:
total: 4,059 km
standard gauge: 4,059 km 1 ,435-m gauge (1 ,377 km
electrified)
note: during the 1999 Kosovo conflict, the Serbian rail
system suffered significant damage due to bridge
destruction; many rail bridges have been rebuilt;
Montenegrin rail lines remain intact (2001)
Highways:
total: 48,603 km
paved: 28,822 km (including 560 km of expressways)
unpaved: 19,781 km
note: because of the 1 999 Kosovo conflict, many road
bridges were destroyed; since the end of the conflict
in June 1999, there has been an intensive program to
either rebuild bridges or build by-pass routes (1999)
Waterways: 587 km
note: the Danube River, central Europe''s connection
with the Black Sea, runs through Serbia; since early
2000, a pontoon bridge, replacing a destroyed
conventional bridge, has obstructed river traffic at
Novi Sad; the obstruction is bypassed by a canal
system, the inadequate lock size of which limits the
size of vessels which may pass; the pontoon bridge
can be opened for large ships but has slowed river
traffic (2001)
Pipelines: crude oil 415 km; petroleum products 130
km; natural gas 2,110 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 2,437
GRT/400 DWT
ships by type: short-sea passenger 1 (2002 est.)
Airports: 46(2001)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2001)
Airports - with unpaved runways:
total: 27 27
1,524 to 2,437 m: 2
914 to 1,523 m: 12
under 914 m:2 13 (2001)
Heliports: 2 (2001)','8e0555c58ac73955e672f23ee1aa9827419ab2f95a1eefb9129e796bfce7d54b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebfca23a1a09298a0f85775ffc2184ef0368061fcbaf77dbd0be0ec138cd157a',2002,'ZM','Zambia','transportation',1193,'Railways:
(ofa/.''2,157km
narrow gauge: 2,157 km 1.067-m gauge (13 km
double-track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority (TAZARA), which
operates 1,860 km of 1.067-m narrow gauge track
between Dar es Salaam and Kapiri Mposhi where it
connects to the Zambia Railways system; TAZARA is
not a part of the Zambia Railways system; Zambia
Railways assets are scheduled for concessioning
(2002)
Highways:
tote/: 66,781 km
paved: NA km
unpaved: NA km (1997 est.)
Waterways: 2,250 km
note: includes Lake Tanganyika and the Zambezi and
Luapula rivers
Pipelines: crude oil 1 ,724 km
Ports and harbors: Mputungu
Airports: 111 (2001)
Airports - with paved runways:
total: 11
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 1 (2001)
Airports - with unpaved runways:
total: 100
2,438 to 3,047 m:\\
1,524 to 2,437 m: 3
914 to 1,523 m: 66
under 914 m: 30 (2001)','93a255a8a4ac8a963f3795fe26ed421ebe894895c533b8ff5bebfd706472ce71','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

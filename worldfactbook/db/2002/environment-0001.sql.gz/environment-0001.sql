SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74e5e767aad59c425a12874f861c0cc8a981ed5dd3461957d695370317c5aa55',2002,'EH','Western Sahara','environment',11,'soil degradation - damage to the land''s productive capacity because of poor
agricultural practices such as the excessive use of pesticides or fertilizers, soil
compaction from heavy equipment, or erosion of topsoil, eventually resulting in
reduced ability to produce agricultural products.
soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
ultraviolet (UV) radiation • a portion of the electromagnetic energy emitted by
the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
water-born diseases - those in which the bacteria survive in, and is
transmitted through, water; always a serious threat in areas with an untreated
water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels - party to
and signed but not ratified Agreements are listed in alphabetical order by the
abbreviated form of the full name.
xiv
Notes and Definitions (continued)
Environmental agreements: This information is presented in Appendix C:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local currency
per US dollar and as determined by international market forces or official fiat
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day
activities of the government. For example, in the UK, the monarch is the chief of
state, and the prime minister is the head of government. In the US, the president
is both the chief of state and the head of government Cabinet includes the official
name for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession to power,
date of the last election, and date of the next election. Election results includes the
percent of vote for each candidate in the last election.
Exports: This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities: This entry provides a rank ordering of exported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but which may
begin in any month. All yearly references are for the calendar year (CY) unless
indicated as a noncalendar fiscal year (FY),
Rag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Rag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodology for more information.
xv
Notes and Definitions (continued)
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (???) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
derived from the PPP method provide the best available starting point for
comparisons of economic strength and well-being between countries. The division
of a GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries are often
rough approximations. Most of the GDP estimates are based on extrapolation of
PPP numbers published by the UN International Comparison Program (UNICP)
and by Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. In contrast, the currency exchange rate
method involves a variety of international and domestic financial forces that often
have little relation to domestic output. In developing countries with weak currencies
the exchange rate estimate of GDP in dollars is typically one-fourth to one-half the
PPP estimate. Furthermore, exchange rates may suddenly go up or down by 10%
or more because of market forces or official fiat whereas real output has remained
unchanged. On 12 January 1994, for example, the 14 countries of the African
Financial Community (whose currencies are tied to the French franc) devalued
their currencies by 50%. This move, of course, did not cut the real output of these
countries by half. One important caution: the proportion of, say defense
expenditures as a percentage of GDP in local currency accounts may differ
substantially from the proportion when GDP accounts are expressed in PPP
terms, as, for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP and other
economic data can not be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information, and changes in
national statistical methods and practices.
GDP - composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP.
GDP - per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis adjusted
for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix F:
Cross-Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names referenced to
one or more related Factbook entries. Spellings are normally but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
xvi
Notes and Definitions (continued)
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.gM republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government - note: This entry includes miscellaneous government information
of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry states the total length of the highway system and the length
of the paved and unpaved parts.
HIV/AIDS - adult prevalence rate: This entry gives an estimate of the percentage
of adults (aged 15-49) living with HIV/AIDS. The adult prevalence rate is calculated
by dividing the estimated number of adults living with HIV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of adults and
children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate of all
people (adults and children) alive at yearend with HIV infection, whether or not
they have developed symptoms of AIDS.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Hydrographic data codes: see Data codes
xvii
Notes and Definitions (continued)
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinot), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chforal hydrate, barbiturates (Amytal, Nembutal Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(PCP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psitocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
xviii
Notes and Definitions (continued)
Imports: This entry provides the total US dollar amount of imports on a ci.f. (cost,
insurance, and freight) or f.o.b. (free on board) basis.
Imports - commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year. This rate is often
used as an indicator of the level of health in a country.
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year''s consumer prices.
Internet country code: This entry includes the two-letter codes maintained by the
international Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list
and used by the Internet Assigned Numbers Authority (IANA) to establish
country-coded top-ievel domains (ccTLDs).
Internet Service Providers (ISPs): This entry supplies the number of Internet
Service Providers within a country. An ISP is defined as a company that provides
access to the Internet.
Internet users: This entry gives the number of users within a country that access
the Internet. Statistics vary from country to country and may include users who
access the Internet at least several times a week to those who access it only once
within a period of several months.
International disputes: see Disputes - international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix B:
International Organizations and Groups which includes the name, abbreviation,
date established, aim, and members by category.
xix
Notes and Definitions (continued)
Introduction: This category includes one entry, Background.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry contains a rank ordering of component
parts of the labor force by occupation.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for three
different types of land use: arable land - land cultivated for crops that are replanted
after each harvest like wheat, maize, and rice; permanent crops - land cultivated
for crops that are not replanted after each harvest like citrus, coffee, and rubber;
includes land under flowering shrubs, fruit trees, nut trees, and vines, but excludes
land under trees grown for wood or timber; other - any land not arable or under
permanent crops; includes permanent meadows and pastures, forests and
woodlands, built-on areas, roads, barren land, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes ind tides the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, rote in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
xx
ARCTIC REGION
80291 6A!(R021 12) 6-02
ANTARCTIC REGION
Southern
Ocean
8029 17A1 (R02207)6-02
SOUTHEAST ASIA
Cocos
(Keeling)
Islands *
(AUSTRALIA) ''
Indian Ocean
Scale 1:32,000,000 at5«N
Mercator Projection
$00 Kflomctcrs
5C0 Miles
Boundary representation ts not necessarily authoritative.
Names ir. Vietnam are (down without diacritical marks.
100','83c86ecca0efa626699592414b4a105d5d9b5c26f610d29ec860a5d32c00820b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0280bccfa6964b9d442076d5d65d9d69be87112564c0020ea470198259aac4ea',2002,'AU','Australia','environment',12,'Mount Isa*
DESERT
80291 4AI (R02106) 6-02
He Amsterdam
. <Fr. S. and Ant. Lands)
* tic Saint-Paul
iff. S. and Ant. Lands]
id Antarctic Lands
eard island and
* McDonald islands
(AUSTL.)
June 2002
Twenty of 27 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Boundary representation is not necessarily authoritative.
802905AI (R00349)6-02
Guide tO Country Prof NeS ( Categories , Fields, and subfields)','fed7e58da6f369edbc07f2a5869b09e1dff19cd7e3e7ae3ab8eba8562a830b2b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd627387ac339144948c438ba3b237ef87819fe1b22379551eff4eb26ca0ca3',2002,'US','United States','environment',13,'1 Bart™
V^-Lhilkflii ^ ^
Scale 1:360,000
• State capital A ,Hefm
Scale l:27,0O0,O00\\ /
Atbcrs Equal-Area Projection \\ j
standard parallels 28CI30,N and 45e30''N
0 5C0 Kilometers 1/ / /
1 1 i1 ''i 1 1 ,\\ I \\
0 500 Miles
^
Chihuahua','ed93bc4973b3781cc5cb09096be7511d42854ff13ac3c1e3452984b8e859e325','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c466a88c7ad69dec91e1e7735203f8add5c31df5f284d96a814da41cbde8ccc2',2002,'MX','Mexico','environment',14,'Monterrey
>f Mexico
THE BAHAMAS
V
Hawaii
-25
C 11
t
0 . ■ 1"
id way 4 .i
lands
. *V ''
0 1f
0 1!
North Pacific
0 14
Ocean
0
Scale 1:34,
0 400 K
I 1 , 1
000,000
lomerers
Kauai
® ^Honolulu
0atni Mmil
Tropic of Cancer
25-
0 4D0 Miles
1 1£
o i:
o ic
0
20-
802907AI £
SOUTH AMERICA
8O2909AI(R021O8)6-O2
MIDDLE EAST
NORTH AMERICA
802906AI (R02067) 6-02
STANDARD TIME ZONES OF THE WORLD
Add time rone nunber to local timo to obtain UTC.
Subrrac! lime yone mtrrthor from UTC lo obtain IocjI
Ad<! lime zone number to local lime to ob:atn UTC. WEST
Subtract i;mc zone number trnm UTC 10 obtain local lime.
EAST
Subtract time zone number from local time w obtain UTC.
Add tirr.e zone r umber to JTC to obtain time.
f eneh Southern an 1
""SEW" Q„ fLEs«t>Z£T
(5:00
3
(FRANCE
i ii.es ckoZET
i I f. s. acid Ant Ufi<js|
16:00
4
Wllr. S. and Ant. Undo:
17:00
5
18:00
6
19:00
7
20:00
6
21:00
22:00
10
23:00
Sun
2-1:00
12
Sun
Sun
00:00 1:00
12 II
'' focal time
80291 8AI(R021 B3)6-02
Political Map of the World, June 2002','8b262fa52553d5efc014a91cf3e690b34a25ac83e42278bba55405efe0752b8e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e48fe7c5e93d3e288cca654c1f4af731a70ec79c3d1cb3b8c88e80a3f02c44',2002,'BM','Bermuda','environment',15,'Sicily/ AZORES
★
Independent state
Dependency or area of special sovereignty
Island / island group
Capital
Scale 1:35,000,000
Robinson Projection
standard parallels 38''N and 38''S
Johnston Atoll
IU.5.1
* '' ^Honolulu
HAWAIIAN ^ j
ISLANDS P /
(U.S.) /
, Kingman Reef (U.S.)
" Palmyra Atoll (U.S.)
Clipperton Island
(FRANCE*
2002
GMAPACOS
ISLANDS
(ECUADOR)','cf1746d66d55edc8efebbbd505d5c7d86d7303fdd20fec73358750631bff6f68','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f581024571c6465255afa3e245d6d497bb6f5359d1810a4d0d1a50c1d23bfd6a',2002,'AQ','Antarctica','environment',16,'_ *^pouaIa
jflafe#^ Yaounde
j; iviaie
MALDIVES it
British Indian
Ocean Territory
(U.K.) C
Diego
Garcia
INOIAh
OCEAN
He Amsterdam
. (Fr, S. and Ant. Lands)
* Ik Saint-Paul
(Fr. S. and Ant. Lands)
French Southern and Antarctic Lands
/ (FRANCE)
PRiNCE EDWARD
ISLANDS
(SOUTH AFRICA)
ILES CROZET
(Fr. S. and Ant. Lands)
£0
tLES KERGUELEN
(Fr. S, and Ant. Lands)
uvet Island
iORWAY)
/
Heard Island and
* McDonald Islands
(AUSTL.)
f.£Maie
MALDIVES \\i
British Indian
Ocean Territory
Diego
Garcia
INDIAN
OCEAN
Cocos :
(Keeling) Islands
(AUSTL)','a63e7bb708274ed1ea5d6577031bd729a544ddfbefb3fe50884bb37fa4ff502c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('636e22878c195543368fbc786c156daa42e31326f01545452e52a30ceda52808',2002,'PR','Puerto Rico','environment',1091,'GDP: purchasing power parity - $1 .8 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$15,000 (2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: Uk%
highest 70%:NA%
Inflation rate (consumer prices): NA%
Labor force: 48,356 (2002 est.)
Labor force - by occupation: agriculture 1%,
industry 20%, services 79% (1990 est.)
Unemployment rate: 4.9% (March 1999)
Budget:
revenues: $364.4 million
expenditures: $364,4 million, including capital
expenditures of SNA (1990 est.)
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity • production: 1.02 billion kWh (1999)
Electricity - production by source:
fossil fuel: W%
hydro: 0%
nuclear: 0%
other: 0% (1999)
556
Virgin Islands (continued)
Electricity - consumption: 948.6 million kWh
(1999)
Electricity ■ exports: 0 kWh (1 999)
Electricity -imports: 0 kWh (1999)
Agriculture ■ products: fruit, vegetables, sorghum;
Senepol cattle
Exports: $NA
Exports - commodities: refined petroleum products
Exports - partners: US, Puerto Rico
Imports: $NA
Imports - commodities: crude oil, foodstuffs,
consumer goods, building materials
Imports - partners: US, Puerto Rico
Debt -external: $NA
Economic aid - recipient: $NA
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','3d64783dbe83fbe380d24da3ff5a2713ce777574d362a65d9b6b3121b7faf1e8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f5acfbffa25d180f41bd05e4f428ed57cca1c113566bc46a650a616c7f252eb',2002,'EH','Western Sahara','environment',15,'soil degradation - damage to the land''s productive capacity because of poor
agricultural practices such as the excessive use of pesticides or fertilizers, soil
compaction from heavy equipment, or erosion of topsoil, eventually resulting in
reduced ability to produce agricultural products.
soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic energy emitted by
the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
water-born diseases - those in which the bacteria survive in, and is
transmitted through, water; always a serious threat in areas with an untreated
water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels - party to
and signed but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
XIV
Notes and Definitions (continued)
Environmental agreements: This information is presented in Appendix C:
Selected international Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date orover a given period of time, as expressed in units of local currency
per US dollar and as determined by international market forces or official fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day
activities of the government. For example, in the UK, the monarch is the chief of
state, and the prime minister is the head of government. In the US, the president
is both the chief of state and the head of government. Cabinet includes the official
name for this body of high-ranking advisers and the method for selection of
members. Elections includes the nature of election process or accession to power,
date of the last election, and date of the next election. Election results includes the
percent of vote for each candidate in the last election.
Exports: This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities: This entry provides a rank ordering of exported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 1 2 months, which often is the calendar year but which may
begin in any month. All yearly references are for the calendar year (CY) unless
indicated as a noncalendar fiscal year (FY).
Rag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile, The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodology for more information.
xv
Notes and Definitions (continued)
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
derived from the PPP method provide the best available starting point for
comparisons of economic strength and well-being between countries. The division
of a GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries are often
rough approximations. Most of the GDP estimates are based on extrapolation of
PPP numbers published by the UN International Comparison Program (UNICP)
and by Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. In contrast, the currency exchange rate
method involves a variety of international and domestic financial forces that often
have little relation to domestic output. In developing countries with weak currencies
the exchange rate estimate of GDP in dollars is typically one-fourth to one-half the
PPP estimate. Furthermore, exchange rates may suddenly go up or down by 10%
or more because of market forces or official fiat whereas real output has remained
unchanged. On 12 January 1994, for example, the 14 countries of the African
Financial Community (whose currencies are tied to the French franc) devalued
their currencies by 50%. This move, of course, did not cut the real output of these
countries by half. One important caution: the proportion of, say, defense
expenditures as a percentage of GDP in local currency accounts may differ
substantially from the proportion when GDP accounts are expressed in PPP
terms, as, for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP and other
economic data can nof be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information, and changes in
national statistical methods and practices.
GDP - composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP.
GDP • per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP • real growth rate: This entry gives GDP growth on an annual basis adjusted
for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix F:
Cross-Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names referenced to
one or more related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
xvi
Notes and Definitions (continued)
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of alt final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g., republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government - note: This entry includes miscellaneous government information
of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry states the total length of the highway system and the length
of the paved and unpaved parts.
HIV/AIDS - adult prevalence rate: This entry gives an estimate of the percentage
of adults (aged 1 5-49) living with HIV/AIDS. The adult prevalence rate is calculated
by dividing the estimated number of adults living wilh HIV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of adults and
children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate of all
people (adults and children) alive at yearend with HIV infection, whether or not
they have developed symptoms of AIDS.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Hydrographic data codes: see Data codes
XVII
Notes and Definitions (continued)
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal. Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(PCP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psitocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
xviii
Notes and Definitions (continued)
Imports: This entry provides the total US dollar amount of imports on a c.i.f. (cost,
insurance, and freight) or f.o.b. (free on board) basis.
Imports - commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
“none” followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year. This rate is often
used as an indicator of the level of health in a country.
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year''s consumer prices.
Internet country code: This entry includes the two-letter codes maintained by the
International Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list
and used by the Internet Assigned Numbers Authority (IANA) to establish
country-coded top-level domains (ccTLDs).
Internet Service Providers (ISPs): This entry supplies the number of Internet
Service Providers within a country. An ISP is defined as a company that provides
access to the Internet.
Internet users: This entry gives the number of users within a country that access
the Internet. Statistics vary from country to country and may include users who
access the Internet at least several times a week to those who access it only once
within a period of several months.
International disputes: see Disputes - international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix B:
International Organizations and Groups which includes the name, abbreviation,
date established, aim, and members by category.
xix
Notes and Definitions (continued)
Introduction: This category includes one entry, Background.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry contains a rank ordering of component
parts of the labor force by occupation.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for three
different types of land use: arable land - land cultivated for crops that are replanted
after each harvest like wheat, maize, and rice; permanent crops - land cultivated
for crops that are not replanted after each harvest like citrus, coffee, and rubber;
includes land under flowering shrubs, fruit trees, nut trees, and vines, but excludes
land under trees grown for wood or timber; other - any land not arable or under
permanent crops; includes permanent meadows and pastures, forests and
woodlands, built-on areas, roads, barren land, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricamera!), forma! name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each parly in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
xx
Providcni yafc Anadyr''
,.™s ^
i
i
^Oymyakon
N £ Yakutsk
\\ y k
^Verkhoyansk ]
ANTARCTIC REGION
// \\
■ Year-round research station
Scale 1:68,000,000
/'' Azimuthal Equal-Men Projection
/ 0 500 10C0 Kilometers
South Atlantic
Ocean
Port Elizabeth
j AFRICA X^
Twenty of 27 Antarctic consultative nations have made
no claims to Antarctic territory (although Russia and the
United States have reserved the right to do so) and they do
not recognize the claims of the other nations.^/
/ ^outh Georgia and the
/ /''''South Sandwich Islands
/ / (administered by. UK..
/ claimed bv ARGENTINA1) *
/ V','495e3606e1204cc9a7cacc861e2fff757da324d10cbe0cff61dd4cfed765816d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2efef11a07fc4784fa576a8e967f5746340ee10823364288abc75d245732846',2002,'BV','Bouvet Island','environment',16,'* (NORWAY)
BRITISH
CLAIM _
yx
PRINCE EDWARD ISlANDS
•’ (SOUTH AFRICA) \\
\\
v Falkland Islands /
Vlslas Malvinas)
(administered by U.K..
claimed by ARGENTINA)
ARGENTINE \\
CLAIM \\ '' . -- SAMAE / \\
mV c,«i, Orcadas \\ (SOUTH '' -» ; . / \\
nvA) 1 '' '' A (ARGENTINA) AFRi£A) NovolazarevskaVa
4 souz°^y \\ ^ / y.
\\ S00TH/x / >c jsr
, ''siiCTuf.V . \\| y °< / \\ ? 7 Qiiccnl Maud Land / ''"^mssiaT^
Wpl. ISM<''DS « jf., X .cdla''geman, \\<VQ / /\\ JtfT*
Drake (A , \\ / \\ «rhalIey(U.K ) / / \\** A /
Southern '' /
Ocean I NORWEGIAN CLAIM y
j _ , . undefined limit /
SOUTH ORKNEY
ISLANDS ''','da384a93b53ada5a34abe04d5eeed810882c0397f7eaac36e9a38a4c67c30d7b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66cec87e4c2f295095bbf6053cc6b64e61e73757c3bcb1b89c04add48d2e2ebf',2002,'AR','Argentina','environment',17,'French''SoutherrX''
and Antarctic Lands
SOUTH
SHETLAND
Xv /X™
I Sc.i
■ Belgrano II
U (ARGENTINA
Mawson
Macrfobtoson (AUSTRALIA)
CHILEAN f
CLAIM l
AIM I Belling iiatbcn }
. i5“_ 1 rx:
f Ellsworth •
r wk.'' . jf (AUSTRALIA)
•; /<%> f / Arf \\
''"m’-v / ( \\ / ^ \\ s'' dVy Amervleediclf
iJ''d'' X''/ \\ ''• // V<Zhong Shan(CHlNA)% (t
''//A Progress (RUSSIAf*Wls<AUS™LiA>
Ills \\
KERGUELEN
Heard Island and \\
McDonald Islands \\
(AUSTRALIA) ^
Amundsen-Scott
(togtrest point in Anatolia. 4897 m) South Pole \\
Land ^ 2600 nr. ; \\.
a/J Bentfey Subglacial Trench t'': \\,
V (kiwes: pent in Anarctia. -8540 m) y . V .
/ ■ Vostok
ley Subglacial Trench *: V \\ / (RUSSIA) / ^ J ,
: point in Anarctca. -8340 m) \\> ^ V. X. / / ^ A
***** iV vu /\\ h }
iJ-. f . (X V>/ i
X/<vj Ross N \\ V\\.. \\ L
a |CC¥ . M \\\\ \\ / ^ n ca
N. A/T"
iTerraSJova''vX./ J X
Ross Sea J (ITALY.) V /si S
V "TSSSU /victoria UtkyA ^ V
. ''v, Dumont d''Urville
'' TO \\ / \\ (FRATICE)
'' , Scat! j . S \\ "
Indian |
Ocean i
1 South
\\ Pacific
■Oce an
Anuntdsen
Argentina, Brazil. Chile. China. Poland. ^
Russia. South Korea, Uruguay each have
a station on King George Island. Y\\
S\\ C( jr»Esperanza
4$ ^RGEMTINA)
60 V ml u Marambio &
Arturo Mat .BlJrM(ARQCriTlriA) ''
ir„ -(irnm
''b ?■ '' J
* /
Ik ke Shelf §
/ -5
L <J
/j Casey
[AUSTRALIA) 5
X/
- 1 - isrxfips
Southern
FRENCH
CLAIM
1 CLAIM
Antarctic!
Peninsula
Southern
Ocean
CHATHAM ISLANDS
(MEW ZEALAND!
SairMaKtin
(ARGEm''hm)
Macquarie islathf
* (AUSTRALIA) \\
Campbell ''
Island -X
(MEW ZCAIAMO! AUCKLAND ISLANDS
//(MEW ZEALAND)
~ ~ ’ e ^SNARES ISL ANDS
(MEW ZEALAMD)
hew / /
ZEALAND/ y South Island ^
^Cbmtchurch
Wellington / /
160 -
| 7 North Island _
S o u t h /
? ac''tfic''
Ocean
\\ fyy
j Adelaide*
Melbourne
^Canberra
[\\ AUSTRALIA
8029 17AI (R02207) 6-02
I
SOUTHEAST ASIA
W V- • \\ ! *’ Ml .
a I jf^h''ngdu '' Wuhan-.
J ''• ; ff
''A - I \\-5-W55lwC. .<•''••/* '' Nancfiing^f '' ;
i; .( VX y^r HINA '' ■ : ■Stf* !UJ^
WiVn ''> <''''''•’ Nanchangs? '' '' ‘ ..
■■''s&l-rW wAWnI 1 -; 1 V-Vii&i C ff T N • A -: Y«W*n
r n 1 n,A >n*sha..:^7^5
rtf'' r* t j j ■ f'' ^ ? m. #Gulyang L f • /* '' , J , *.Lr
—^htoia;.^'' , ijhli *rv''... >;/''■■■ U • ‘.^W
/ *''/y . . VvOft Kunming1 ; 1 •• • I1 /.■ '' ■«'' ''Is*
ihanghal tast
u Clliiu
5e.i ^
OWlMWfl - %
Naha*^ ^ .
”iui/v;y , i J - , • ''. < ... ''?/ *•* -.-J- * V7 . Nana* ^
v?'' y- r/;'' v y?"* y ^ s&
.nJ0 — $Z-zkgl — duangzhou "Shantog7 _ *_ _IrolLe £Lcf5!l _
S Vr
V •; yBURMA y /wy \\ rt,noi -X
VAkvatt :.■■-* C r. '' ■ ^Ha(ph
- 1 BONIN ,
O ISLANDS.
-I
O''
&an|lftpr^^aAcau
^r! * /»*45 >s um.
i? >;? ---r ; ■; — ,o ■—*) - strait
L.l I Tonkin (X'' {Hainan
\\ i fV ,Aiai /Vientiane^ gylnh IX/ Dn«
\\n n ■ vv-\\N ^
IRaVigooti), ■ ■ 1 y \\\\\\\\
T. A* A [ :''i '' ■ I ■ h>\\\\Hue '' \\ P/»KACi-L
l^yy[ ?! "HAILAnp ''4W\\oaNang 4'' , ,SLANDS f
Mawlamylnei J I", .R^haslmaf VIETNAM 1
Dawcl Bangkok / - A ^OUt/l i
ST ,Vv China “
''0I» .i V vfh"iT,pb y P. H I L f
Andaman \\y/j W i 3° SC3 *; »/ £t j
, ’ BABUVA.V ISLANDS
Philippine
Dawc\\\\ Wok/
3 ANDAMAN
/ ISLA.VPS
>’ umoia:
.njirfi rpVii
6»lfuf ^ [mg
Th.c.vJ >pyfi
ISLAK,
■''• i 1 *
» ''?// H^i!^rlnh Sea f #/.;» &
Sm */ ( aulfuf ^ rangs^ * V , . Bacolryf
. /'' H Thlgltul Xfiyur'' SPRATLY . •'' NftroKj. * J?L . „
.;n,cOMS L‘x ."W- **!*» JvST*0™
Phukci \\songkhIa , f •<r ,» . Zaniboang^O
7f"l George Bandar Seri /^Jyiabulu ■ ° .
VT\\ \\ V • MALAYSIA ■ BBUflR^^/ {
% v i r x KfruiMAK ) V. -!x — catenet p
\\>^u*CuaT Lump-u''r ° \\ Sea 4
‘ /VJSjfl''iug Borneo \\
X\\ ^X*S)ngapore / \\ ^-y . ''■. X,
Pi/tow Nia A) \\ a A-nhoApoRE i '' J V
W a .» VPonlianak ''■? r /
>V NICOBAR 1
k''itff Phuket \\\\songl<hla
dwxbnxd TlV>\\
„ , . George Tow i] X - \\
Banda AcehrN-^X 4 i|poh \\
viw.vr 4
FF.D. STATF.S OF
MICRONESIA
Bandar Seri
Begawan .C'',(
Samarinda
Pu/rt;/ sibrrt/f \\*Sumatra\\ ^ ) : s /
“SSSSL\\ XX . -o y
(US^caran^ I Java <e.i Makassar
Teluftfotung J _
'' \\XLiakaru I -M D O
HuSnlA-*^., r«aiS{HrX_^* . Ho,«Seg
- PALAU .
North
Pacific
Ocean
v^''C Halmhern
M.Mucca Equator
Ot^ 0
r* Ceram
dari Xiydl
Burn
layipu ''a*Tv''
Cocos
(Keeling) .
Islands *
(AUSTRALIA) ‘','a4353d0826a9e72b4dac860c502539669ec84ecca75b39dc1ceb1c21e40e4af9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0456d8632e0653f1efc75ee320b4b2407bce2e9ee90f3cda0dc033090644f4',2002,'CX','Christmas Island','environment',18,'(AUSTRALIA) *
BaTvdtm^— X?™ •
, .via.umk*''^ s“''"6a''''" c;
J Sutnhn
I A B.imta Sea ^ f\\ KEPUIAUAN
~7 , fV'' AR(J
• O ^ - /
New''Qu(nea..
I ''tr
PAPUC
/ MEW
Indtan Ocean
, ., /^fK^EAST TIMOR
Kupang^^.^
*• ^
Ti»»u>r
. ’ Sea
Ashmore and /^Darwin
Cartier Islands \\
(AUSTRALIA) J
y*C£, Gulf of
Carpentaria
I
Scale 1:32,000,000 at 5°N
Mercator Projection
0 SOO Kilometers
I- 1 i1 . Ir . W - r - 1
0 500 Miles
Boundary representation Is not necessarily authoritative.
Names in Vietnam are shown without diacritical narks.
o ->V''--/'',,”Por Hedland
/ Karra tha
GREAT SANDY
DESERT
(AUSTL.)
Ashmore and
Cartier; Islands
(AdSTL.)
EAST An fur,
TIMOR Sea
/^Darwin
Tropic of Capricorn (23''2/)_
Alice Springs','71de53c3583c62e39e19f91a77a429d7f2eafc12293054d8407ac1d8f81ae72e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb0a3959d4b339c975ec4e3e4ea22e1864517fcf35eccb53256a993c73e36182',2002,'AU','Australia','environment',19,'Mount Isa*
80291 4 Al (R02106) 6-02
i/e Amsterdam i
. (Fr. S. and Ant. Lands) /
He Salnt-Paul j
(Fr. S. and Ant. Lands) /
id Antarctic Lands
eard Island and
* McDonald islands
(AUSTL.)
SOUTHERN OCEAN
(Jreat Australian
Bight
if
Antarctic,Circle (66"33‘)
8029D5AI (R00349) 6-02
Guide to Country Profiles ( categories , Fields, and subfields)','0c161a7d5b7a5b609237818b88567bb02751aca3723d06b8bc120c9cad964c40','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f8062616e1d076a8a8632a0d7d1028465dd5d6a99cbccd8f8c5effd734c9215',2002,'US','United States','environment',20,'802907AI 6*02
SOUTH AMERICA
.''-HONDURAS^ I
■Tegucigalpa)
. / San A >ii
t/NICARAOUA .tcoLOi.
\\ ^Manama
COSTA RiqiL ?V
Caribbean Sea
Martinique (FRANCE)^ eo
ST. LUG A $ I
"«l.nds ST- vmccw ado < Barbados
Antilles thf r.RF.NAniNFs
THE GRENADINES
GRENADA o''
Istn de Mnlpdo
(COLOMBIA)
Barranquilla
Cartagena f)
• '' “Valencia •*''
jBarqUlsImeto
PoTtj of- Spain
ZS TWrilDAD AMD
.y CiWumN sw-^a^ciudad
y» t |J /ftSan CrlstAbal Guayana
edeJiaJ.^COTEZUELA r
m# /
f L/t./ '' (SURINAMEV Trent
iWColombiaJ^ :
^Georgetown
^*S Paramaribo
UYArt a ) — _ _
. J / Cayenne
V ■ (SURINAMEV rrencrfV
yf i V ) Qulana 1
North |
Atlantic
Ocean
- A
ECiaDOR/
Ct/^aqull/
A )U A Z O N
BASIN
South j
Pacific
Ocean
. Lima yyi _ \\
\\* ''^^7u*fo'' { s
V
^''■''Areqalpo''S''
BRA
MATO G ROSSO
PLATEAU
/S.Culaba
* {-.BOLIVIA
■e. Cochafcimb^ : “Santa Cn
4 Siuici^^*''
v#r i
B R A Z I L I) A N
/ Brasilia ; d
Goidnla, *
H I G H L)A N D S
• Belt)
Horizonte
_ T > /Hy Jl _
k - - ''A-HIoTTgastar o? j " ■»!>*
C Ol
1 isln San Ambroslo
Isla San Fillx T '' <CH,LE>
(CHILE) \\ f
Rio d e Janeiro, •y"'' /
Pa _ /
intos j ‘
V“f t:fv
J- vA^n Miguel
I N 1 Ja^e Tucum*n
/ Alf’C Reststencl
CHILE ? , |
CZ£2?r-UU: . icAdoM, %sanu F^= 2 v
Valparaiso] \\^iMendo?a ^^Rosarlok, JuRUQI
Santiago y -i| ^ ^ Rn*nAc Aii-^civ- . .
Pdrto Alegre,
ARCHIPELAGO \\
JUAN FERNANDEZ \\
(CHILE) • \\
/ /iP | jla PIa"& "Montevideo
concepeldnf ^ARGENTINA )
V Bahia Blanca, _}^^Mar del Plata
\\jk - - — f— - — -
_ — — “ T ? San Carlos de
Puerto Mohtt \\ • Bariloche \\
^Iorlan6polls
South
Atlantic
Ocean
Scale 1:35,000.000
Azimuthal Equal-Area Projection
Boundary represents lion Is
not necessarily authoritative.
y\\j‘ • '' y s7/ f Pnfnsul* VmIcMs
r * S ‘ l- . ( (toweaf point In
[• ) ) South Amgrici. -40m)
M 9 y
r $ O . fComodoro Rlvaddvia
RfOj
Gallegos Magellan
/ Falkland Islands
(Islas Malvinas)
(administered by U.K.,
claimed by ARQEMTIPIA)
/ South Georgia and the
/ South Sandwich Islands
/ (administered by U.K.,
j n\\ claimed by ARGENTINA)
AO
802909 Al (R02108) 6*02
OCEANIA
MIDDLE EAST
ROM.
, Bucharest*
{ I Sevastopol^
fConstanja *','e49e7d017dbec5e9732e73670621b51a3e03f6f24e11d7395e2ead2dead9bb07','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('490ec6756800275656a7596fdea89b1f6da17e3aa1dbbb2904d1bd5d7f6c2613',2002,'BG','Bulgaria','environment',21,'Black Sea
asnodar ''
* RUSSIA
Oori Elbrus
\\ftnghi at point In
£Wo V>,S633m)c_
\\( xXc- Groznyv
Sokh tmTV \\
KAZAKHSTAN |
Caspian
Is
llotvest poirt in
\\ Europe, -2B m) V
Balkanabat
* .Konya j’
V. J I,.p.w \\ GEORGIA T ''/!\\ \\
AeceiTT^'' - Ankara ARMkim^AZeRBAUAN ^“mqayl1 Xrtm,„ba£
TURKEY KayserT^Pj " V '' *
j--o 7 L, v* x* y L->
** *°° Adana GgSntep Dunib
''tw i ^ x Xj — r^\\ a A Zjn|5n‘ . ax''
J I NIC0Sja yiieVUJ (mosuA • l *»" . *•
Pkf^ iutakia ) / Wrkuk7 '' ’"Tehran
I CYPRUss_v“^ L*. SYRIA j V; * f y •QPm
I Beirut (rS K i/ C •■ rSk . .''
Mediterranean ISea Lebanon/ jibamascus^. XBkoftdad \\crma”Ehah °,’
I . / x.GoUn S JXH I A N V® * \\ , ,
v— I Ha''fcTa ^HCighB^\\ 0<K[„ ?VA ) ^ Ejfahln
X_ ISRAEL// ''fXXX IRQA©-XX, ° I R V
J V\\v am) % 1 "
- - - Galroi "jl{. Ga“ Sl n /iflROANN \\ An NisIrTyalr- \\| Abadan ''s-
( oW - - S{airo^ i, ,z y f JORDAN^, \\ At ’ _
Ailrzah ! — - — - X - — — X
I UZBEKISTAN
.Nukus
MSTAN \\
1 Turkmenabat
r. \\ Arbll ''-
( MosuM #
Mediterranean /Sea
CYPRUS^
Zanjan* ; •
Qazvlr,1 .t"l“
’ * Tehran
''V .Q°m
Ashgabat ^Mary
Mashhad l S
/Kermanshah''X
IRAN \\
WE S TERN! \\AsyQt
r.
egyiPt
ERT
An NasIrTyalT- Abadan ,. ^
< Al Bagrah*A* ^ ^ _
\\T /!Sr7\\ ‘Shiraz
X /_ % Kuwait YBushchr
H^JWAtT V
*Hafar V \\
al Batin \\ . x_
S> return
. Al Jubayt ,-„(/
Zahedan*
^ - X>«4rX.
. A V
T» Medina
Boundary /
NUBIAN
o e s e r r
JiddaKL I
*Hafar V \\ Bandar \\
l,-,-i al Batin > , ''^''s. ''Abbas _ \\
y** 11 S? ptTsi.ui v. rf£r\\ I
. AUuhaj^ lW/ \\ ;• , 1
Buravdah Ad Dammatrfc Manama /5^ V_ \\
* Dhahran 9 W ~J «OMAnv>w —
BAHlOwv /QATAR Dubai/ T , 1
\\f ; Doha V \\
Riyadh #Dhabi \\ Muscat!
SAUDI * !
_ -\\-£iiiwir Kr"d'',y • V
»C ratio Boundm\\ J \\
ARABIA ) /
.0 / OMAN /
Port Sudani 5ea','57cfbb9b28234149a8f77151aca9f783076f8dc48b1f3fc3d6234b3dbcb1a69b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e34b4ae640842acffba3079cc55fd2d32e4ee57a647936899cbf940e5e84fd5',2002,'YE','Yemen','environment',22,'Grulfof Aden
Arabian Sea
Scale 1:21,000,000^^ ]
Lambert Conformal Conic Projection ,
stonrftrrrf parallels t2’N and 38''N
0 300 Kilometers ■■ ^
. *Hargeysa SOMALIA
/ ETHIOPIA
: Boundary representation Is X
3j. not necessarily authoritative.
ProvWoiwI ,
AdmtnMrrailve Line ''
/
/Golan Heights is Israeli-occupied Syria. \\
\\ > West Bank and Gaza Strip are Israeli-occupied with current 1
y status subject to the Israell-Palestlnlan Interim Agreement — \\
I permanent status to be determined through further negotiation. I
Israel proclaimed lerusalem as Its capital In 1 950. but the US, like \\
g*Q nearly all other countries, maintains Us Embassy In Tel Aviv. ^
80291 1AI (R021 07) 6-02
160 140 120 100 80 60 40
“V — East
■ Chersklyi Jih..,.iin
l(J SSI A ''
■ \\
\\
■\\
Jyr* V
1 \\ >IPlTM
''AWk
Arctic Ocean/
> A Set
WcnlyaJ^^J j.
VsAi
/ /
trreenfand flea
Itseqqtmoo
(Scoresbff
Jan Mayen
'' (NORWAY)','99ffa6161b6d26b8946b0b6c6bafb7de649b0fee2a0a005d2d0adcd99d3e39ed','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02d8cc04ae5edcc8b2becd77c91c15433dc6063cb6bdba35775f8309a1e90bcc',2002,'GL','Greenland','environment',23,'(DENMARK^
/
Reykjavik
<$> v Prudhoe Beaufort
\\ >V /Se*
Jc^/TsiVbd^Tpates /a
etncl W.McKInfey^-^, // >
th^h*si po/.n« Fairbanks// j
North Am»r£a.6t94 m}u f yi/ ■ f
\\ *#* \\ 477
\\7Anch0rage% Y/Dawson ^
*/JL
Kaifliitt&jL
UReS^iiftr
Baffin Bay
taslllaq A Denmark
(Aronfiissal&f ....
KangCrl ussuaq
ZW{Sopare Stronro
(Sopare Strantttird)
1/ ,
jr Nuuk"«v
H7^r.odthAb)\\
/^sarsuaq^
\\pdvts PaamiilF^r /
5trajf (Frederlkshib)/
.
-$ M''cA va
Kodiak <V
Oulr" of \\
Alaska
kanglqcHnlq ju
(Rankin frPro
C Iqalulr''V
^VTFrobisher B%)
O V) tlvu|lVk
t: A M/A
Labrador Sea
''North
.Pacific
/
JJ/ AT . j AlllalUKM
Hudson Bay \\
Happy Vaite
Goose Bay)
Scheffervllle ■ *
Islntut of
\\-Ncw^onndinnii
'' Chlsasibi
.(Fort George)
VancqLlV^.Calgary
Idmontoifc, A7«A ukr
\\/Soskatoon \\
r St UryuiM- '' St. Pierre
/Q < A •SBSr
. 7/ ‘ Fredericton \\
Qu£bec7 I \\_ •yT7t,altfaxN''
jSeadleTrr-
Winnipeg*
/N *& ,
//i-Cj
Portland 0/
/''<?’/
f «3 /
TK/A \\ Montreal
Tv- HM">> \\
.7.1 ■ ''-''cfsilm John
Ocean
1 "A-.; * t£ / lireat Salt
u" ^ “S
Sacramento ft Sa1rcak«eCitK._ ■*»
San FrandscoSp-L. ~
u n
i V i#''sf f »''
LMmneaPo7A-q {uJJOW ,, j
MOtif .trio . •
/ 7
Clevfct^nd <V i
hlcago Pittsbiufefr^
Colyjnbtrs^/ \\5
Death Valley +
(Uspsl pcfnl in
Norm^Spirica. -96 trj
LosAncele|?.
SarfDi^goV/ _
Las yf
> Veeas
Denver t V-
y,;. Kansas City
. ^Umtlffnapolls r-Si^
''^v\\_St. Louis ''7
ws TT 1
/ Oklahotn i City,
■ Phoenix Albuquerque
® \\-Wladelphla
m ore
y? ."^Wtshington, D.C.
f North
0\\ Norfoll^x Bermuda
t® ‘ \\ : S'' (U''K'')
\\ / Atlantic
^Atlanta ycharleston
Ocean
Jacksonville^
, . Ciudad
: •: JuArez
j New Orfb^n^p
San Houston » ^
I Antonio ♦ey^''^^’ w-o >>
Gulf of Mexico
Scale: 1:38,700,000 - __
Lambert Conformal Conic Projection, . ‘ /
standard parallels 37 ‘N and 65 ''N rwillagigedo
0 300 600 Kilometers (MEXICO)
Boundary representation Is
not necessarily authoritative.
v\\.
GuadMajara# '' •
''<?*■ Mexico-^
kRilii.1 tie
faiitpeciie
racruz .
THE BAHAMAS ^
UiamlV . Nassau ^ ^
7i\\ b* >7...
ralT-r/ '' ^ .
King^
Caribbean
\\Sea
A^ Gifatcmala '' ( Tegucigalpa (
0UATWlXU*/i''-i7
San Salvador^^^ Managua!
EL SALVADOR 1
STANDARD TIME ZONES OF THE WORLD
NORTH
ATLANTIl
OCEAN
V '' BAHAMA!
rou1
CL 5ALVAD
f S0RK1AMC intwce- ,
French P o.J y n-e 6 i a \\
(FRAhCE) ‘
50UTH PACIFIC
; OCEAN
\\PERU
lima \\ |
Scale 1 :85,000,000 at 0°
Miller Cylindrical Projection
0 500 ICOO Kilometers
•F.Y.R.O.M.- The Former Yugoslav Republic of Macedonia
Boundary representation Is noi necessarily authoritative.
} BOLIVIAj
1
m
(DENMARK)
Svalbard
(MORWAY)
Jan Mayen
(MORWAY)
Norwegian
Sea
Iqalult v
JblsherRay) t
TiCELAMD
< (Godthabi
Reykjavik
Faroe
Islands
TorshavnV <DEru
NORWAY-
SWEDEN ;','77e89fa893e67c44998ca0b9f2e072508795312d7843d3d0d09acb2cd522f1df','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('297a3e127a137a3b4c93fedc9ae087da63eade23d1d2d4c9ed2f16a7ed9f5887',2002,'BR','Brazil','environment',24,'7T. / Vaiu
K) ,
WRAQUAYT S4o Raulo j*—
.''3
Buenos Ali r
ARdENTIM
Falkland Islands.
{Isias Malvinas!
(administered by U.K.
Claimed by AROEJITIfli )
I South Cicontl.i and the
South Sandwich Islands
(administered by U.K.
claimed by AROLmiHAI
Add lime rone number to local time'' :o obtain UTC.
Subtract lime zone number from UTC to obtain local
Political Map of the World, June 2002
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily/ AZORES Island / island group
★ Capital
Scale 1 :35,000,000
Robinson Projection
standard parallels 38 ‘N and 38''S
Arctic Circle
U. S./
.Whitehorse
NORTH
PACI F1C
#SaIt Lake City
OCEAN
UNITE
#Los Angeles
/ |San Diego *
/Tijuanar,,^rVw El Paso
/ MeklcaliK^^v. _ /~X
/ 2/7 Ciudad Juarez \\
Tropic of Cancer (23''27'')
- <7
* ^Honolulu
HAWAIIAN
ISLANDS P
(U.S.)
^ Mazatlin _
) MEXICO
) > .Le6n
r ''Guadalajara
Mexico*
Johnston Atoll
(U.5.1
ISMS
REVJttACICEOO
(MEXICO)
Clipperton Island
(FRANCE)
. Kingman Reef (U.S.)
’ Palmyra Atoll (U.S.)
2002
^ ISO
ARCTIC OCEAN
y'' Beaufort Sea
_ _ /^Arctjc^Cirde 16fT33L
.Whitehorse ■ //^
/. Cfi
/ Edmonton^
/ .Calgary
5^2. Baffin ?
/ S x- Island
Iqalult
(Frobisher Bay) i
-
Churchill 7
— Hudson - - — —4—
/ % '' \\
_ ■ / * 4
DA V
x A
1
0 Lata /
7 f
Happy Valley-/
Goose 8ay^£
Uf Winnipeg /
\\ -J
7
► ^Seattle
Portland
Winnipeg, 4
Ufa ^
.«upcri„r<s^O-
/
Minneapolis, Lakt?
Miclu^un ^
Ottawa. Montreal
* _ _ X
7% 4
Labrador
Sea
'' Island of
Newfoundland
#Salt Lake City
^Denver
UNITED
Milwaukee /
cLo(yDeuo''^^^
f" f Cleveland] New York
Indianapolis^ . Philadelphia j
Lake Ontario
Boston /
St. Pierre
and Miquelon
imAf''cn
cNuuk (Godtha
STA/TES
aftnhorc
^shington. D.C.
Olego *','a0368067673f917bc23b6d925dfc2adf6deed2d354fac06f12786e37bc534b34','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13874e7aaec4c7b9a7e4d76df8cf01c8423e731bccf6ace63cd0359cd0cca2aa',2002,'BM','Bermuda','environment',25,'<u.K.r-
NORTH
ATLANTIC
OCEAN
Crulfbf Mexico
THE
.BAHAMAS
V Mflzatlin _ J _
) MEXICO [
) m \\
f - Guadalajara \\
\\ * IVeracru
X Mexico* • MV
Puebla
.Oaxaca
. Jtlaxana _ ?_
Mfrtd iJ&H"
“cOra"
Mr-- Turks and
/ - Caicos Islands
Cayman Is.
lUJU *
British Virgin |
‘MIHICAM lianas I
tRUBLIC , Anguilla (U.IU
*r> /si. KITTS AND NEVIS
-kiFuze x i
. I I* Belmopan s » Dommgo Rico '' * Guadel(
abATm^pOrroimm
GuatemXXiX^
San Salvadot^ovX
EL SALVADOR \\.I''flCA
ManaguiMV ■)
Caribbean Sea
Puerto /.‘ANTIGUA AND BARBUDA
m S°) / ^.Guadeloupe [PR.)
Montserrat $ DOMINICA
cu.r.) ^Martinique (PR.)
ST. VINCENT AND oST. LUCIA
Clipperton Island
(PRANCEl
Barranquiila
isla del Ccco
rrrtCTA mr*>
TM£ GRENADlNESa ! .BARBADOS
JF1”. nan. Antilles ■ !
CJ Q 1 ircm’ • ''GRENADA
''VMcfracalbo . <*> Pcm-of-Spain
A raM^T^A?^STRiNIDADAND
( } wraca5 TOBAGO
VENEZUELA J ^Georgetown
Sfeff&w Paramaribo
ARCTIC /OCEAN
Greenland Sea
Longyear','4806ff647347ad028b3d0613270e5623e48ff6215f064c70ca9298d83445de42','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed2830e54e1ace4c0aad54f3993b78fb517ee124ae9b63e69d8dbacdbb702a77',2002,'FI','Finland','environment',26,'i j'' Bcrgori
UNTH-D i North
lublln''Tj*^ Mafljihester
B-AmstenMiffS Hamburg
GERMANY-.
f’ Is/nnrfof
’ Newfoundland
, ^ . TipR!VEST4 l
\\ I'' i
f .•.bnfev-/L~4''
RUSSIA •
Minsk
vT y™*\\
rlin 1 l6di* *
L I''! tic ,
. . Guernsey, l r> -.
- jcrscyjuic]
'' GERMAm^agu,_ .Krakow), ,v
AJxembourg^QjgQ^ ( U K f
St. Pierre
and Miquelon
(PRANCE1
NORTH
ATLANTI
OCE AN
6a if *w
FRANCE /
.Lyon* ’ 3
1 °rdCa,,X MOHAcI
, Mafselilc^”^
OflAlfAIHC
rnTyr^O-AUSTHAT * Budapest \\ ,i
Romania)/
Bucharest
V/Qibraltariu,K>
/ yWefifiaT^
/ y. ''tsri _ X
Casablonc^Ra^j £V:*J
''■OS
n Ni
f ISardiiln
•Lr-’ txT.y
’TurnfeiA
^^iJlaitaKeeh'',^
logcoX
oVtttC^NtA
Mediterranean Sea (GR.)
CANARY ISLANDS
„ ISP.) 0
Western!
Sahara |
-X _ i
L laavoune
S. (El Aaiun)
CAFE VERDE0
..V
Praia','b26b1d5c7272eaa0569e3b11e761fff525f145d4dda1605a7ef1fd4e95556c37','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b96e65d18fb007c53213cceac84b29f942040c6fa386e5f34398a07950f9f450',2002,'MR','Mauritania','environment',27,'ri i g er
’a Dakar<SENEO,
Banjul jLgjsv^
THE GAMBIA K~p
Bissau^Pr->
GUINEA-BISSWr
Bamako,^™/
Ouagadougou
JTT''
dtk^V-CrYry ™A ,
Fie.l,»ro e-i r OTWracJotMrTH /*
Mnnrm-M \\ v 1 Accra /.
CHAD f
k S
N’Djamena C
CENTRAL
ARRICAN REPUBLIC h
\\
FRANZ !OSEF\\
_ _ — =st£srl
^^Svalbard -
\\
\\ NOVAYA
{NORWAY)
\\ ZEMLYA
\\ Barents Sea ^
^ Si
; C\\ MurmansiT''''''-^*^ *=o — x
SEVERNAYA
ZEMLYA
~3=> gw','f10306dc0a34623da0ec91379deb5342794ab0d01991dbcb8bc7160e3d0d78e9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a4b10d4466ee9ce9e6d3fccc39361bbfb0c647adfc94c1e7d16ae07af10a637',2002,'SE','Sweden','environment',28,'r FINLAND!
LneteMsU^j
i^g^LArA
FySS5>--^-
Si. Petersburg
POLAND \\
Warsaw* <
Lodz* ’
oue Krakow^
M Minsk','0c938847fa49643f4b380e304b1232b20a9953f9b6af43bd139b770472904e1d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f789ae3df2b643bdfc26da558e2374f68203b13607a1d3aac46bc84190231fe4',2002,'BY','Belarus','environment',29,'Arkhangelsk
Novgorod
k Moscow * .Kazan’
Voronezh Saratov
RUSSIA
i .Yekaterinburg
\\ Chelyabinsk
Krasnoyarsk
.Novosibirsk
Barnaul
B’V^''vIv J* .
£ UKRAINE Kharkiv^
N— — — e''friOLDOVA
pest \\/£hi}inau
ommvu reArtv
ROM An 1 A t
Volgograd
^*RoStOv
>.W
^KAZAKHSTAN
\\ lake Balkhash
Qaraghandv nTS.
.(Karaganda)
AN
lake Balkhash
<r*
''19m
AUB4 f Skjl
5i.ra iajs5ro
uu-rn . -0
Valletta .<
Mediterranean Sea SS
1 Eh<kica geBf
jstltnb uK"~~ .
iiursa * Ankara
nr | TURKEY
jKonya* Adana
icynutF^k®1™''
GEORGIAN-^
f''billsU
^^^ekistah
» Bishkek :r>
. KYRGYZSTAN
™ j IRAQ
I Beirut f/VDan^scus
fret Aviv-Yafo j5x>^ \\ Baghdad
^CM^rfe^y.^Kmriiad~V
CaiVo . Tx/jORbAN \\ Al
.Dushanbe^ Kasm','fc5d2051ecf7e0a80446b53eaa691068485e3729602eb619d10110b9cf289a3e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c94041e205606767706c9f8db91e334638daefc6d2dfd38512e76d5a894b7068',2002,'ET','Ethiopia','environment',30,'\\ •
ovoslbirsk \\
\\
.Barnaul \\
< ,+Ulaanbaaur
M O H G O LI A ''
^Changchun
Bering 5ea
Petropavlovsk-Kamchatskiy
CH I Pi A .
2heng2hou
gfcptiXft KOREA Se1 o(
^"SlP%migyang .bp.ni
soOth','a6a1b57d5b76d109e400b88252c685edff6fbaaca2426541c81b76057955d7f0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb33b37bd089f20a63dd3c89b36a004298e8806672636adc390e8a32281a9f65',2002,'JP','Japan','environment',31,'■ occupied by the SOVIET UNlOf
administered by RUSSIA, clain
New ? "v. \\
Delhi* ^.NEPAlS-^^^ jWUTAiy^
laipur* Lucknow ^~kathm§ndul T5§Rwmphu
Kanpur ■
BANGLADESH?
_ _ _
Ahmadabad \\ ^
(Calcutta)} jiiWh \\ W
.NaeDur
Chongqing"
Changsha. .NanchanA
''■rtmvBp C
. « - or -
{ iriDiA
BURMA Hfncrf JT^t''ria''c
v S A
r''''n!'',n f J Hainan
\\ sChianc t^Jr^ VV Deo
- CuaftgaboujeS- — uu J -
^''^t^-SKong KT3iW3r
Macau S.A.R. luren >tr.xit
S.A.R. * \\ ^
t Rangoon
\\m
llMtenila
Philtppin
V K. vVtue ItKasty
J THAILAND* m\\_-'' ''ewws flf
Wgk0k/ - - \\ \\ South China u
|fu(cAN8°w] j 5el
iXjjphnont R^nfw^itKopm Minh City ■'' \\
northern * • \\
Mariana *’ \\
Islands * i
(U.S.) * , \\
^Saipan ^
Guam ‘ \\
(U.S.) * . •
Hagatna \\
. FEDERATED STaW
'' i
j NICOBAR *Q
I ISLANDS
I (INDIA)
2£!Z2*/*fL -i*7 Wl
150
120
9C
JCisangam
5’J DEMOCRATIC
ao rwaW
REPUBLIC L
..OF THE CONGOfl
>nasa a)
Lake tE
l T.tn^anyila\\V
^nT^^Nairobi y
r \\Vr^yi£tona\\ r
ijumbora \\ /
DKUMDI NyZMoT''basa
'' ;oodomV (^Dar es Salaam
TANZANIA 7
?.^iviaie
MALDIVES sfc
British Indian
Ocean Territory
(U.K.) \\','a693f81b56ad3239ba46033776f46bab24bd329c36ba13e06190547149c17c53','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('337c1f4b94ed2f4ccbae9dadc793245bd7d7720c982ca09a3f140ab45f4486b3',2002,'KM','Comoros','environment',32,'Mayotte'' ,
(administered by rKAICE. 0.''''
claimed by COMOROS) r
/Juan dc Nov
'' Island imu
Glorioso Islands
BOTSWANA . J®
Gaborone */''
\\ *Pre
( — / Johannesburg','4c0f928305fe1b94b0c59fcf5a5d80cf19f40c6e6321fe4859453edcfce4a8de','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a30bc873f4ecd5b03bc9f77c0e7b691c1abc52e68c5d1dd05fc66e2677beff',2002,'MZ','Mozambique','environment',33,'Beira/ vteambteuc
jr channel
C Bassas
[ da India.
i» irRAnci''
1 Europa Island
_ / _ trkAficc: _ _ _
l Antananarivo
DAQASCAR
Tromelin Island
. (FRANCE:
c • . Portl
Dent
$ MAURI
Reunion f
(FRANCE) ;
I N D I A h
OCEAN
fie Amsterdam
. (Fr. S. and Ant. Lands)
fie Salnt-Paal
(Fr. S. and Ant. Lands)
French Southern and Antarctic Lands
uvet Island
iORWAY)
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
IIES CROZET
(Fr. S. and Ant. Lands)
ILES KERGUELEN
(Fr. S. and Ant. Lands)
Heard Island and
® McDonald Islands
(AUSTL.)
sf
MALDIVES jo
o
British Indian
Ocean Territory c‘
(U.K.) £
INDIAN
OCEAN
Cocos
(Keeling) Islands
(AUSTL.)
Celebes Sea *
Makassar* If vJV','51ab2c0f9b3699eb199cb21e3ff0e47e2ca11812e7b2cccf64fe046a82c4f062','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59655061af51246b2035461b4300558bb505879f6ae1c56f1124e30f9ca1b5eb',2002,'PR','Puerto Rico','environment',1163,'GDP: purchasing power parity - $1 .8 billion
(2000 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$15,000(2000 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 48,356 (2002 est.)
Labor force - by occupation: agriculture 1%,
industry 20%, services 79% (1990 est.)
Unemployment rate: 4.9% (March 1999)
Budget:
revenues: $364.4 million
expenditures: $364.4 million, including capital
expenditures of SNA (1990 est.)
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity - production: 1.02 billion kWh (1999)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
556
Virgin Islands (continued)
Electricity - consumption: 948.6 million kWh
(1999)
Electricity - exports: 0 kWh (1999)
Electricity - Imports: 0 kWh (1 999)
Agriculture - products: fruit, vegetables, sorghum;
Senepol cattle
Exports: $NA
Exports - commodities: refined petroleum products
Exports - partners: US, Puerto Rico
Imports: $NA
Imports - commodities: crude oil, foodstuffs,
consumer goods, building materials
Imports * partners: US, Puerto Rico
Debt • external: $NA
Economic aid - recipient: $NA
Currency: US dollar (USD)
Currency code: USD
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','7f20fc5b217e476c428c1c18b70eb20d2882d937f0bfb51e0a0c2d25aa622dbc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

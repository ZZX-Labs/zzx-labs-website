SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35de758bd736085f301fa8fa49505cd2f833326f87983548b98f04070f039990',2002,'AU','Australia','communications',22,'Telephones - main lines in use
Telephones - mobile cellular
Telephone system
general assessment
domestic
international
Radio broadcast stations
Television broadcast stations
Internet country code
Internet Service Providers (ISPs)
Internet users
Communications -note
Telephones - main lines in use: 29,000 (1998)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment; very limited telephone and
telegraph service
domestic: in 1997, telecommunications links were
established between Mazar-e Sharif, Herat,
Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations ■ 1 1ntelsat
{Indian Ocean) linked only to Iran and 1 Intersputnik
(Atlantic Ocean region); commercial satellite
telephone center in Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the
active station is in Kabul), FM 1, shortwave 1
(broadcasts in Pashtu, Afghan Persian (Dari), Urdu,
and English) (1999)
Television broadcast stations: at least 10 (one
government-run central television station in Kabul and
regional stations in nine of the 32 provinces; the
regional stations operate on a reduced schedule; also,
in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces) (1998)
Internet country code: .af
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 120,000 (2001)
Telephones - mobile cellular: 250,000 (2001)
Telephone system:
general assessment: Albania has the poorest
telephone sen/ice in Europe with fewer than two
telephones per 100 inhabitants; it is doubtful that
every village has telephone service
domestic: obsolete wire system; no longer provides a
telephone for every village; in 1992, following the fall
of the Communist government, peasants cut the wire
to about 1,000 villages and used it to build fences
internationai: inadequate; international traffic carried
by microwave radio relay from the Tirana exchange to
Italy and Greece
Radio broadcast stations: AM 13, FM 4,
shortwave 2 (2001)
Television broadcast stations: 3 (plus 58
repeaters) (2001)
Internet country code: .a!
Internet Service Providers (ISPs): 1 0 (2001 )
internet users: 12,000(2001)
Telephones - main lines in use: 2.3 million (1998)
Telephones - mobile cellular: 33,500 (1999)
Telephone system:
general assessment: telephone density in Algeria is
very low, not exceeding five telephones per 100
persons; the number of fixed main lines increased in
the last few years to a little more than 2,000,000, but
only about two-thirds of these have subscribers; much
of the infrastructure is outdated and inefficient
domestic: good service in north but sparse in south;
domestic satellite system with 12 earth stations (20
additional domestic earth stations are planned)
international: 5 submarine cables; microwave radio
relay to Italy, France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean), 1 1ntersputnik,
and 1 Arabsat (1998)
7
Algeria (continued)
Radio broadcast stations: AM 25, FM 1 ,
shortwave 8 (1999)
Television broadcast stations: 46 (plus 216
repeaters) (1995)
Internet country code: .dz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 180,000(2001)
Telephones - main lines in use: 10.05 million
(2000)
Telephones - mobile cellular: 8.6 million (2000)
Telephone system:
general assessment: excellent domestic and
international service
domestic: domestic satellite system; much use of
radiotelephone in areas of low population density;
rapid growth of mobile cellular telephones
international: submarine cables to New Zealand,
Papua New Guinea, and Indonesia; satellite earth
stations - 10 Intelsat (4 Indian Ocean and 6 Pacific
Ocean), 2 Inmarsat (Indian and Pacific Ocean
regions) (1998)
Radio broadcast stations: AM 262, FM 345,
shortwave 1 (1998)
Television broadcast stations: 104 (1997)
Internet country code: .au
Internet Service Providers (ISPs): 603 (2001)
Internet users: 10.06 million (2001)
Telephones - main lines in use: 4 million
(consisting of 3,600,000 analog main lines plus
400,000 Integrated Services Digital Network
connections); in addition, there are 100,000
Asymmetric Digital Services lines (2001)
Telephones - mobile cellular: 6 million (2001)
Telephone system:
general assessment: highly developed and efficient
domestic: there are 48 main lines for every 100
persons; the fiber optic net is very extensive; all
telephone applications and Internet services are
available
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean) and 1 Eutefsat; in
addition, there are about 600 VSAT (very small
aperture terminals) (2002)
Radio broadcast stations: AM 2, FM 160 (plus
several hundred repeaters), shortwave 1 (2001)
Television broadcast stations: 45 (plus more than
1,000 repeaters) (2001)
Internet country code: .at
Internet Service Providers (ISPs): 37 (2000)
Internet users: 3 million (2000)
Telephones - main lines in use: 376 (1991)
Telephones - mobile cellular: 0 (1991)
Telephone system:
domestic: single-line telephone system connects all
villages on island
international: NA
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .nu
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','fe15fd7c2bad068b3dc4af4e4a742eb989ead5d3fdeab09a178d72d4fceb72b3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2242378bae8486a42cbd207b0596287f7a47880e72ab9abe1128d113d6aa30c2',2002,'NZ','New Zealand','communications',32,'Telephones - main lines in use: 13,000 (1997)
Telephones - mobile cellular: 2,550 (1997)
Telephone system:
general assessment: NA
domestic: good telex, telegraph, facsimile and cellular
telephone services; domestic satellite system with 1
Comsat earth station
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .as
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 1 .92 million (2000)
Telephones - mobile cellular: 2.2 million (2000)
Telephone system:
general assessment: excellent domestic and
international systems
domestic: NA
international: submarine cables to Australia and Fiji;
satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 124, FM 290,
shortwave 4 (1998)
Television broadcast stations; 41 (plus 52
medium-power repeaters and over 650 low-power
repeaters) (1997)
Internet country code: .nz
Internet Service Providers (ISPs): 36 (2000)
Internet users: 1.78 million (2001)
Telephones - main lines in use: 8,000 (1996)
Telephones - mobile cellular: 302 (1996)
Telephone system:
general assessment: NA
domestic:
international: satellite earth station ■ 1 1ntelsat (Pacific
Ocean) (1996)
Radio broadcast stations: AM 1 , FM 2, shortwave 1
(2001)
Television broadcast stations: 2 (2001)
Internet country code: .to
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1,000(2000)
Telephones - main fines in use: 252,000 (1999)
Telephones -mobile cellular: 17,411 (1997)
Telephone system:
general assessment: excellent international service;
good local service
domestic: NA
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); tropospheric scatter to Barbados
and Guyana
Radio broadcast stations: AM 2, FM 12,
shortwave 0(1998)
515
Trinidad and Tobago (continued)
Television broadcast stations: 4 (1997)
Internet country code: .tt
Internet Service Providers (ISPs): 17 (2000)
Internet users: 42.800(2001)
Communications - note: important meteorological
station
Telephones - main lines in use: 1,125(1994)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(2000)
Television broadcast stations: 2 (2000)
Internet country code: .wf
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','c24dcf1dd8dfcd50c1cc77f7175671ec9e64710c541e37872adf6a26c7f67a6e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f75ca0cc6063315dd1251c877122865446ac0679f5488996db964c8fa55c88b',2002,'ES','Spain','communications',41,'Telephones - main lines in use: 32,946
(December 1998)
Telephones - mobile cellular: 14,117 (December
1998)
Telephone system:
genera! assessment: NA
domestic: modern system with microwave radio relay
connections between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15,
shortwave 0(1 998)
Television broadcast stations: 0 (1997)
Internet country code: .ad
Internet Service Providers (ISPs): 1 (2000)
Internet users: 24,500(2001)
Telephones - main lines in use: 19,000 (1997)
Telephones - mobile cellular: 1 ,620 (1 997)
Telephone system:
general assessment: adequate, automatic domestic
system and adequate international facilities
domestic: automatic exchange facilities
international: radiotelephone; microwave radio relay;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 1 (plus three
low-power repeaters) (1997)
Internet country code: .gi
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Communications - note: 1 meteorological station
Telephones - main lines in use: 17.336 million
(1999)
Telephones - mobile cellular: 8.394 million (1999)
Telephone system:
general assessment: generally adequate, modern
facilities; teledensity is 44 main lines for each 100
persons
domestic: NA
international: 22 coaxial submarine cables; satellite
earth stations - 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric scatter to
adjacent countries
Radio broadcast stations: AM 208, FM 715,
shortwave 1 (1998)
Television broadcast stations: 224 (plus 2,105
repeaters)
nofe: these figures include 11 television broadcast
stations and 88 repeaters in the Canary Islands (1995)
Internet country code: .es
Internet Service Providers (ISPs): 56 (2000)
Internet users: 7.38 million (2001)','c1b8e149abad9171a6e8879d32376bdaa6e20c41192b4992d6787598ecea862e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91bb75483d2d336a72fe07e5152d2a2a02af41d28b27185db2e632241e90052c',2002,'AO','Angola','communications',50,'Telephones - main lines in use: 69,700 (1997)
Telephones - mobile cellular: 25,800 (2000)
Telephone system:
general assessment: telephone service limited mostly
to government and business use; HF radiotelephone
used extensively for military links
domestic: limited system of wire, microwave radio
relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 36, FM 7,
shortwave 9 (2000)
Television broadcast stations: 7 (2000)
Internet country code: .ao
Internet Service Providers (ISPs): 1 (2000)
Internet users: 30,000(2001)','4a817609f62564af5c69f3b4281dd3f8abccf003394ce8ad834aa50091e9c497','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2427c386aea53f657eeba1324abe05d8219b30ddbfaf08bcf1c2029f918d29',2002,'AI','Anguilla','communications',60,'Telephones - main lines in use: 4,974 (2000)
Telephones - mobile cellular: 1 ,629 (2000)
Telephone system:
genera! assessments
domestic: modern internal telephone system
international: microwave radio relay to island of Saint
Martin (Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6, shortwave 1
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .ai
Internet Service Providers (ISPs): 16 (2000)
Internet users: 919(2000)','a3689a1cf71b8786aa1b189e1f987b285099342c2a4ce91d6ef0ac65bac0d2af','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c92aa79f22370496b51fdbdcf1cb48cb3251d6c705d5ca93a0364c7cfcacc4',2002,'AQ','Antarctica','communications',68,'Telephones - main lines in use: 0
note: information for US bases only (2001)
Telephones - mobile cellular: NA; Iridium system
in use
Telephone system:
general assessment: local systems at some research
stations
domestic: NA
international: via satellite from some research stations
Radio broadcast stations: AM NA, FM 2,
shortwave 1
note: information for US bases only (2002)
Television broadcast stations: 1 (cable system
with six channels; American Forces Antarctic
Network-McMurdo)
note: information for US bases only (2002)
Internet country code: .aq
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 7.5 million (1998)
Telephones - mobile cellular: 3 million (December
1999)
Telephone system:
general assessment: by opening the
telecommunications market to competition and
foreign investment with the "Telecommunications
Liberalization Plan of 1998", Argentina encouraged
the growth of modern telecommunication technology;
fiber-optic cable trunk lines are being installed
between all major cities; the major networks are
entirely digital and the availability of telephone service
Is being improved; however, telephone density is
presently minimal, and making telephone service
universalfy available will take some time
domestic: microwave radio relay, fiber-optic cable,
and a domestic satellite system with 40 earth stations
serve the trunk network; more than 1 10,000 pay
telephones are installed and mobile telephone use is
rapidly expanding
international: satellite earth stations - 8 Intelsat (Atlantic
Ocean); Atlantis II and Unisur submarine cables; two
international gateways near Buenos Aires (1999)
Radio broadcast stations: AM 260 (including 10
inactive stations), FM NA (probably more than 1 ,000,
mostly unlicensed), shortwave 6 (1998)
23
Argentina (continued)
Television broadcast stations: 42 (plus 444
repeaters) (1997)
Internet country code: .ar
Internet Service Providers (ISPs): 33 (2000)
Internet users: 3.88 million (2001)','4e3b22a0fcd298651088173bd25ca5915d3b18faf522a0f6d7ed94a56fb13b55','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c6d31a1d1c2e09a6c5d447e5e669745a16b2399ffd8d164c256c2f9b156b4d4',2002,'AG','Antigua and Barbuda','communications',77,'Telephones - main lines in use: 28,000 (1996)
Telephones ■ mobile cellular: 1,300 (1996)
Telephone system:
general assessment: NA
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean); tropospheric
scatter to Saba (Netherlands Antilles) and','d296cb0dc95b0dcb74fc40cebe83e1c686744780b55cbd39423ed56f29b1cc41','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1620c3ae0e5da72c3a8d5bc6114ef2ea83d2f6db129c628527ad18fadbfc2c7d',2002,'GP','Guadeloupe','communications',78,'Radio broadcast stations: AM 4, FM 2,
shortwave 0(1998)
Television broadcast stations: 2 (1997)
Internet country code: .ag
Internet Service Providers (ISPs): 16 (2000)
internet users: 5,000(2001)','90b2d70da512761459bb33b4a8e13c7c1ed1549471debd16eccfd77de7103008','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('188c28da50df41934a8ab4bb8dcb40f67c4134ef29dad6a0cd91ad9230ff3b04',2002,'AM','Armenia','communications',96,'Telephones - main lines in use: 568,000 (1997)
Telephones - mobile cellular: 25,000 (2001)
Telephone system:
general assessment: system inadequate; now 90%
privately owned and undergoing modernization and
expansion
domestic: the majority of subscribers and the most
modern equipment are in Yerevan (this includes
paging and mobile cellular service)
international: Yerevan is connected to the
Trans-Asia-Europe fiber-optic cable through Iran;
additional international service is available by
microwave radio relay and landline connections to the
other countries of the Commonwealth of Independent
States and through the Moscow international switch
and by satellite to the rest of the world; satellite earth
stations • 1 1ntelsat (2000)
Radio broadcast stations: AM 9, FM 6, shortwave 1
(1998)
Television broadcast stations: 3 (plus an unknown
number of repeaters) (1998)
Internet country code: .am
Internet Service Providers (ISPs): 9 (2001)
Internet users: 30,000(2001)
Telephones - main tines in use: 33,000 (1997)
Telephones - mobile cellular: 3,402 (1997)
Telephone system:
general assessment: NA
domestic: more than adequate
international: 1 submarine cable to Sint Maarten
(Netherlands Antilles); extensive interisland
microwave radio relay links
Radio broadcast stations: AM 4, FM 6, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .aw
Internet Service Providers (ISPs): NA
Internet users: 4,000 (2000)','96ffd2dca5a34a62595fcf899af7e08ca496becc9c5be7f35b19da3428a0c5a1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9db6d55246e9fd00455bac5d01c7a9163ff2ba5586a1b28546a9fdbca8ee4a12',2002,'AZ','Azerbaijan','communications',104,'Telephones - main lines in use: 663,000 (1997)
Telephones - mobile cellular: 40,000 (1997)
Telephone system:
general assessment: inadequate; requires
considerable expansion and modernization;
teledensity of 8.6 main lines per 100 persons is very
low
domestic: the majority of telephones are in Baku and
other industrial centers - about 700 villages still
without public telephone service; satellite service
connects Baku to a modern switch in its exclave of
Naxcivan
37
Azerbaijan (continued)
international: the old Soviet system of cable and
microwave is still serviceable; a satellite connection to
Turkey enables Baku to reach about 200 additional
countries, some of which are directly connected to
Baku by satellite providers other than Turkey (1997)
Radio broadcast stations: AM 10, FM 17,
shortwave 1 (1998)
Television broadcast stations: 2 (1997)
Internet country code: .az
Internet Service Providers (ISPs): 2 (2000)
Internet users: 12,000(2001)','10d544557de5afc28d99200d3478699b61f415392ade073769ae2b93d6571850','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35c8faf413546a8300c66fcbdd3d81c633d7c12590bd5cde1366fbd95812ad88',2002,'BS','Bahamas','communications',109,'Telephones - main lines in use: 96,000 (1997)
Telephones • mobile cellular: 6,152 (1997)
Telephone system:
general assessment: modem facilities
domestic: totally automatic system; highly developed
international: troposphere scatter and submarine
cable to Florida; 3 coaxial submarine cables; satellite
earth station - 1 1ntelsat (Atlantic Ocean) (1997)
Radio broadcast stations: AM 3, FM 4, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .bs
Internet Service Providers (ISPs): 19 (2000)
Internet users: 13,100(2001)','8db3768a4caba556726816b2622d44f3203aed1a8d59fa30083421f73095a13d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2af2fdeaabe784d30d36633b4bfaff585fe311f87d66e33c135039e76aa39d9f',2002,'BH','Bahrain','communications',119,'Telephones * main tines in use: 152,000 (1997)
Telephones - mobile cellular: 58,543 (1997)
Telephone system:
general assessment: modern system
domestic: modern fiber-optic integrated services;
digital network with rapidly growing use of mobile
cellular telephones
international: tropospheric scatter to Qatar and UAE;
microwave radio relay to Saudi Arabia; submarine
cable to Qatar, UAE, and Saudi Arabia; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 1ndian
Ocean) and 1 Arabsat (1997)
Radio broadcast stations: AM 2, FM 3, shortwave 0
(1998)
Television broadcast stations: 4 (1997)
Internet country code: .bh
Internet Service Providers (ISPs): 1 (2000)
Internet users: 105,000(2001)','5d61a80a98d31904b9c4f360b2e88752da49a23f367f027324668132416ce3d9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33120f7b6e064cf8b6d6767f797fb0cad9a391c6969de43e9a71474d52092eb2',2002,'BD','Bangladesh','communications',124,'Telephones - main lines in use: 500,000 (2000)
Telephones - mobile cellular: 283,000 (2000)
Telephone system:
general assessment totally inadequate for a modem
country
domestic: modernizing; introducing digital systems;
trunk systems include VHF and UHF microwave radio
relay links, and some fiber-optic cable in cities
international: satellite earth stations - 2 Intelsat
(Indian Ocean); international radiotelephone
communications and iandline service to neighboring
countries (2000)
Radio broadcast stations: AM 12, FM 12,
shortwave 2 (1999)
Television broadcast stations: 15 (1999)
Internet country code: .bd
Internet Service Providers (ISPs): 1 0 (2000)
Internet users: 30,000 (2000)','5a4f5a40ea8f71ce8392885551f78bd41fd458ccded07b3733faae10fab8ac31','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84ab69123e70dfa6652e5a021b9550138f2f7561ba0c90d43dce9d6d52647803',2002,'BB','Barbados','communications',134,'Telephones - main lines in use: 108,000 (1997)
Telephones - mobile cellular: 8,013 (1997)
Telephone system:
general assessment: Hk
domestic: island-wide automatic telephone system
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); tropospheric scatter to Trinidad and','f81b5efd4aed768a2b9762392f16ad83d88ce720f95c221a2bd905d794306378','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4041e9d451d95e46c8c17997c9e9c6f94d4f69c92177899321529c1597ea9ec',2002,'LC','Saint Lucia','communications',135,'Radio broadcast stations: AM 2, FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (plus two cable
channels) (1997)
Internet country code: .bb
Internet Service Providers (ISPs): 19 (2000)
Internet users: 6,000 (2000)
Telephones • main lines in use: 37,000 (1997)
Telephones - mobile cellular: 1 ,600 (1 997)
Telephone system:
general assessment: adequate system
domestic: system is automatically switched
international: direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados; international calls
beyond these countries are carried by Intelsat from','3af5ab543160f50b82cfb4d74c3f6651627fd36dde8a4e3504531ec5e3645622','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9717f3cd52622e51e8d5e88a40111c3ce7929085ff9ac9ea80c3749ccf8ac624',2002,'FR','France','communications',156,'Telephones - main lines in use: 2.313 million
(1997)
Telephones - mobile cellular: 8,167 (1997)
Telephone system:
general assessment: the Ministry of
Telecommunications controls all telecommunications
through its carrier (a joint stock company) Beltelcom
which is a monopoly
domestic: local - Minsk has a digital metropolitan
network and a cellular NMT-450 network; waiting lists
for telephones are long; local service outside Minsk is
neglected and poor; intercity - Belarus has a partly
developed fiber-optic backbone system presently
serving at least 13 major cities (1998); Belarus''s fiber
optics form synchronous digital hierarchy hngs
through other countries* systems; an inadequate
analog system remains operational
international: Belarus is a member of the
Trans-European Line (TEL), Trans-Asia-Europe
(TAE) fiber-optic line, and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments
provide connectivity to Latvia, Poland, Russia, and
Ukraine; worldwide service is available to Belarus
through this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik earth
stations
Radio broadcast stations: AM 28, FM 37,
shortwave 11 (1998)
Television broadcast stations: 47 (plus 27
repeaters) (1995)
Internet country code: .by
Internet Service Providers (ISPs): 23 (2002)
Internet users: 180,000(2001)
Telephones - main lines in use: 4.769 million
(1997)
Telephones • mobile cellular: 974,494 (1997)
Telephone system:
general assessment: highly developed,
technologically advanced, and completely automated
domestic and international telephone and telegraph
facilities
domestic: nationwide cellular telephone system;
extensive cable network; limited microwave radio
relay network
international: 5 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: FM 79, AM 7,
shortwave 1 (1998)
Television broadcast stations: 25 (plus 10
repeaters) (1997)
Internet country code: .be
Internet Service Providers (ISPs): 61 (2000)
Internet users: 2.807 million (2001)
Telephones - main lines in use: 31 ,000 (1 997)
Telephones - mobile cellular: 3,023 (1997)
Telephone system:
general assessment: above-average system
domestic: trunk network depends primarily on
microwave radio relay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 12,
shortwave 0(1998)
54
Belize (continued)
Television broadcast stations: 2 (1997)
Internet country code: .bz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 15,000(2000)
Telephones - main lines in use: 287 (1992)
Telephones - mobile cellular: NA
Telephone system:
general assessment: connected within Australia''s
telecommunication system
domestic: NA
international: telephone, telex, and facsimile
communications with Australia and elsewhere via
satellite; 1 satellite earth station of NA type (2002)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(2000)
Television broadcast stations: NA
Internet country code: .cc
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones - main lines in use: 263,700 (2000)
Telephones - mobile cellular: 450,000 (2000)
Telephone system:
general assessment: well developed by African
standards but operating well below capacity
domestic: open-wire lines and microwave radio relay;
90% digitalized
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean); 2 coaxial
submarine cables (June 1999)
Radio broadcast stations: AM 2, FM 9, shortwave 3
(1998)
Television broadcast stations: 14 (1999)
Internet country code: .ci
Internet Service Providers (ISPs): 5 (2001)
Internet users: 10,000(2001)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessments
domestic: government-operated radiotelephone and
private VHF/CB radiotelephone networks provide
effective service to almost all points on both islands
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean) with links through London to other countries
Radio broadcast stations: AM 1 , FM 7, shortwave 0
(1998)
Television broadcast stations: 2 (operated by the
British Forces Broadcasting Service)
note: cable television is available in Stanley (2002)
Internet country code: .fk
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA; however one-half of all
households are reported to have internet access
(2002)
Telephones - main lines in use: 47,000 (1 997)
Telephones -mobile cellular: NA
Telephone system:
general assessment: NA
domestic: fair open wire and microwave radio relay
system
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 2, FM 14 (including
6 repeaters), shortwave 6 (including 5 repeaters)
(1998)
Television broadcast stations: 3 (plus eight
low-power repeaters) (1997)
Internet country code: .gf
Internet Service Providers (ISPs): 2 (2000)
Internet users: 2,000 (2000)
Internet country code: .tf
Telephones * main lines In use: 39,000 (2000)
Telephones - mobile cellular: 120,000 (2000)
Telephone system:
general assessment: adequate service by African
standards and improving with the help of the growing
mobile cell system
domestic: adequate system of cable, microwave radio
relay, tropospheric scatter, radiotelephone
communication stations, and a domestic satellite
system with 12 earth stations
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 6, FM 7 (and 1 1
repeaters), shortwave 3 (2001)
Television broadcast stations: 3 (plus six
repeaters) (2001)
188
Gabon (continued)
Internet country code: .ga
Internet Service Providers (ISPs): 4 (2001 )
Internet users: 15,000(2001)
Telephones - main lines in use: 171 ,000 (1 996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: domestic facilities inadequate
domestic: NA
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean); microwave radio relay to Antigua and
Barbuda, Dominica, and Martinique
Radio broadcast stations: AM 1, FM 17,
shortwave 0(1998)
Television broadcast stations: 5 (plus several
low-power repeaters) (1997)
Internet country code: .gp
Internet Service Providers (ISPs): 3 (2000)
Internet users: 4,000(2000)
Telephones - main lines in use: 170,000 (1997)
Telephones - mobile cellular: 15,000 (1997)
Telephone system:
general assessment: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe, .
Dominica, and Saint Lucia; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 14,
shortwave 0(1998)
Television broadcast stations: 1 1 (plus nine
repeaters) (1997)
Internet country code: .mq
Internet Service Providers (ISPs): 2 (2000)
Internet users: 5,000 (2000)
Telephones • main lines in use: 104,100 (1999)
Telephones - mobile cellular: 1 1 0,000 (2001 )
Telephone system:
general assessment: very low density: about 3.5
telephones for each thousand persons
domestic: NA
international: satellite earth station • 1 1ntersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 7, FM 9, shortwave 4
(2001)
Television broadcast stations: 4 (plus 18
provincial repeaters and many low powered
repeaters) (1999)
Internet country code: .mn
Internet Service Providers (ISPs): 5 (2001)
Internet users: 30,000(2001)
Telephones - main lines in use: 4,000 (1 997)
Telephones - mobile cellular: 70 (1994)
Telephone system:
general assessment: NA
domestic: NA
international:
Radio broadcast stations: AM 1 , FM 2, shortwaveO
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .ms
Internet Service Providers (ISPs): 17 (2000)
Internet users: NA
Telephones - main lines in use: 268,500 (1999)
Telephones - mobile cellular: 1 97,000 (September
2000)
Telephone system:
general assessment: adequate system; principal
center is Saint-Denis
domestic: modern open wire and microwave radio
relay network
international: radiotelephone communication to
Comoros, France, Madagascar; new microwave route
to Mauritius; satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 55,
shortwave 0(2001)
Television broadcast stations: 35 (plus 18
low-power repeaters) (2001)
Internet country code: .re
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(1999)
Telephones - main lines in use: 20,500 (1998)
Telephones - mobile cellular: NA
Telephone system:
general assessment: adequale system
domestic: islandwide, fulty automatic telephone
system; VHF/UHF radiotelephone from Saint Vincent
to the other islands of the Grenadines
international: VHF/UHF radiotelephone from Saint
Vincent to Barbados; new SHF radiotelephone to
Grenada and to Saint Lucia; access to Intelsat earth
station in Martinique through Saint Lucia
Radio broadcast stations: AM 1 , FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Internet country code: .vc
Internet Service Providers (ISPs): 15 (2000)
Internet users: 3,500(2001)
Telephones - main lines in use: 34.878 million
(1997)
Telephones - mobile cellular: 13 million (yearend
1998)
Telephone system:
general assessment: technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave radio
relay, and fiber-optic systems
international: AO coaxial submarine cables; satellite
earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and 1 Eutelsat; at least 8 large international switching
centers
Radio broadcast stations: AM 219, FM 431 ,
shortwave 3 (1998)
Television broadcast stations: 228 (plus 3,523
repeaters) (1995)
Internet country code: .uk
Internet Service Providers (ISPs): 245 (2000)
Internet users: 33 million (2001)
Telephones - main lines in use: 95,729 (total for
West Bank and Gaza Strip) (1997)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment: NA
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian
company PALTEL are responsible for communication
services in the West Bank
Radio broadcast stations: AM 1 , FM 0,
shortwave 0
note: the Palestinian Broadcasting Corporation
broadcasts from an AM station in Ramallah on 675
kHz; numerous local, private stations are reported to
be in operation (2000)
Television broadcast stations: NA
Internet Service Providers (ISPs): 8 (1999)
Internet users: 60,000 (includes Gaza Strip) (2001)','134e30e716ab7f441f8596d219ef20585490541ac414c81c3d4e29627aec699b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d6cbd27bfebb89c1a3204c4028497d8e105947cad9bdb6251b4556bb2b1069a',2002,'TG','Togo','communications',166,'Telephones - main lines in use: 51 ,000 (2000)
Telephones - mobile cellular: 55,500 (2000)
Telephone system:
general assessment: NA
domestic: fair system of open wire, microwave radio
relay, and cellular connections
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); submarine cable
Radio broadcast stations: AM 2, FM 9, shortwave 4
(2000)
Television broadcast stations: 1 (2001)
Internet country code: .bj
Internet Service Providers (ISPs): 4 (2002)
Internet users: 50,000 (2002)','d32af50f98a1d744dd0edd1aafed0f7a6e0b5d682f94759aa607f58d675e11ed','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb4706b8e962e30179fe5ab266fac4fbe0da27bbad8cd2f31169e7e965188ad6',2002,'BM','Bermuda','communications',175,'Telephones - main lines in use: 52,000 (1997)
Telephones - mobile cellular: 7,980 (1996)
Telephone system:
general assessment: NA
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave 0
(1998)
Television broadcast stations: 3 (1997)
Internet country code: .bm
Internet Service Providers (ISPs): 20 (2000)
Internet users: 25,000 (2000)','075e5c5df12ec7b78883ef6d7e4d621da9f2cb624348b64d82ad9145e90175be','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fafacbbb6bab4f469ae6ae2bfb5fe4f26f4724788419546c227372e916e8222c',2002,'CN','China','communications',185,'Telephones - main lines in use: 6,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessments
domestic: domestic telephone service is very poor
with few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AM 0, FM 1 , shortwave 1
(1998)
Television broadcast stations: 0 (1997)
Internet country code: .bt
Internet Service Providers (ISPs): NA
Internet users: 500 (2000)
Telephones - main lines in use: 135 million (2000)
Telephones - mobile cellular: 65 million
(Januany 2001)
Telephone system:
general assessment: domestic and international
services are increasingly available for private use;
unevenly distributed domestic system serves principal
cities, industrial centers, and many towns
domestic: interprovincial fiber-optic trunk lines and
cellular telephone systems have been installed; a
domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Indian Ocean region) and 1 1nmarsat (Pacific and
Indian Ocean regions); several international
fiber-optic links to Japan, South Korea, Hong Kong,
Russia, and Germany (2000)
Radio broadcast stations: AM 369, FM 259,
shortwave 45 (1998)
Television broadcast stations: 3,240 (of which 209
are operated by China Central Television, 31 are
provincial TV stations and nearly 3,000 are local city
stations) (1997)
Internet country code: .cn
Internet Service Providers (ISPs): 3 (2000)
Internet users: 26.5 million (2001)
Telephones - main lines in use: 3.839 million
(1999)
Telephones - mobile cellular: 3 7 million
(December 1999)
Telephone system:
general assessment: modern facilities provide
excellent domestic and international services
domestic: microwave radio relay links and extensive
fiber-optic network
international: satellite earth stations - 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean); coaxial cable to
Guangzhou, China; access to 5 international
submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 7, FM 13,
shortwave 0(1998)
Television broadcast stations: 4 (plus two
repeaters) (1997)
Internet country code: .hk
Internet Service Providers (ISPs): 17 (2000)
Internet users: 3.93 million (2001)
Telephones • main lines In use: 3.095 million
(1997)
Telephones - mobile cellular: 1 .269 million
(July 1999)
Telephone system:
general assessment the telephone system has been
modernized and is capable of satisfying all requests
for telecommunication service
domestic: the system is digitalized and highly
automated; trunk services are carried by fiber-optic
cable and digital microwave radio relay; a program for
fiber-optic subscriber connections was initiated in
1 996; heavy use is made of mobile cellular telephones
international: Hungary has fiber-optic cable
connections with all neighboring countries; the
international switch is in Budapest; satellite earth
stations - 2 Intelsat (Atlantic Ocean and Indian Ocean
regions), 1 1nmarsat, 1 very small aperture terminal
(VSAT) system of ground terminals
Radio broadcast stations: AM 17, FM 57,
shortwave 3 (1998)
Television broadcast stations: 35 (plus 161
low-power repeaters) (1995)
Internet country code: .hu
Internet Service Providers (ISPs): 16 (2000)
Internet users: 1.2 million (2001)
Telephones • main lines in use: 403,000 (1997)
Telephones - mobile cellular: 1 1 ,500 (1 995)
Telephone system:
general assessment: service has improved recently
with the increased use of digital switching equipment,
but better access to the telephone system is needed
in th& rural areas and easier access to pay telephones
is needed by the urban public
domestic: microwave radio relay transmission and
coaxial and fiber-optic cable are employed on trunk
lines; considerable use of mobile cellular systems;
Internet service is available
international: satellite earth stations - 3 Intelsat.
1 Arabsat, and 29 land and maritime Inmarsat
terminals; fiber-optic cable to Saudi Arabia and
microwave radio relay link with Egypt and Syria;
connection to international submarine cable FLAG
(Fiber-Optic Link Around the Globe); participant in
MEDARABTEL: international links total about 4,000
Radio broadcast stations: AM 6, FM 5, shortwave 1
(1999)
Television broadcast stations: 20 (plus 96
repeaters) (1995)
270
Jordan (continued)
Internet country code: .)o
Internet Service Providers (ISPs): 5 (2000)
Internet users: 210,000(2001)
Telephones - main lines in use: 351 ,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment: poorly developed; about
100,000 unsatisfied applications for household
telephones
domestic: principally microwave radio relay; one
cellular provider, probably limited to Bishkek region
international: connections with other CIS countries by
landline or microwave radio relay and with other
countries by leased connections with Moscow
international gateway switch and by satellite; satellite
earth stations ■ 1 1ntersputnik and 1 1ntelsat;
connected internationally by the Trans-Asia-Europe
(TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater
stations), FM 14, shortwave 2 (1998)
Television broadcast stations: NA (repeater
stations throughout the country relay programs from
Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Internet country code: .kg
Internet Service Providers (ISPs): NA
Internet users: 51,600(2001) *
Telephones - main lines in use: 176,902
(November 2001)
Telephones -mobile cellular: 158,251 (November
2001)
Telephone system:
general assessment: fairly modern communication
facilities maintained for domestic and international
sen/ices
domestic: NA
international: HF radiotelephone communication
facility; access to international communications
carriers provided via Hong Kong and China; satellite
earth station - 1 1ntelsat (Indian Ocean)
311
Macau (continued)
Radio broadcast stations: AM 0, FM 2, shortwave 0
(1998)
Television broadcast stations: 0 (receives Hong
Kong broadcasts) (1997)
Internet country code: .mo
Internet Service Providers (ISPs): 1 (2000)
Internet users: 60,000(2001)
Telephones - main lines in use: 408,000 (1997)
Telephones - mobile cellular: 12,362 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM 29, FM 20,
shortwave 0(1998)
Television broadcast stations: 31 (plus 166
repeaters) (1995)
Internet country code: .mk
Internet Service Providers (ISPs): 6 (2000)
Internet users: 100,000(2001)','684d5456f49aae8e6328bd076938aebbafc554733aec0c0a04b96a826a464501','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b14f69ac721befbf1e517a8a6f8827610347187a8dc5d7e6a5828b9fb26c50',2002,'NP','Nepal','communications',195,'Telephones - main lines in use; 327,600 (1996)
Telephones - mobile cellular: 116,000 (1997)
Telephone system:
general assessment new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities; mobile
cellular telephone use expanding rapidly
domestic: primary trunk system, which is being
expanded, employs digital microwave radio relay;
some areas are served by fiber-optic cable; mobile
cellular systems are being expanded
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 171, FM 73,
shortwave 77 (1999)
Television broadcast stations: 48 (1997)
Internet country code: .bo
Internet Service Providers (ISPs): 9 (2000)
Internet users: 78,000 (2000)
63
Bolivia (continued)','5c021449f42d107348765e9beac02400594f1010efde053d9278e4600cef42e1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c8c5e0e44076f7877c09f32a037bba0df8a7a1bd011403aa02760fb3a50be88',2002,'IT','Italy','communications',207,'Telephones - main lines in use: 303,000 (1997)
Telephones * mobile cellular: 9,000 (1997)
Telephone system:
general assessment: telephone and telegraph
network needs modernization and expansion; many
urban areas are below average as contrasted with
services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 16,
shortwave 1 (1998)
Television broadcast stations: 33 (plus 277
repeaters) (September 1995)
Internet country code: ,ba
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,500 (2000)
Telephones - main lines in use: 150,000 (2000)
Telephones - mobile cellular: 200,000 (2000)
Telephone system:
general assessment the system is expanding with
the growth of mobile cellular service and participation
in regional development
domestic: small system of open-wire lines, microwave
radio relay links, and a few radiotelephone
communication stations; mobile cellular service is
growing fast
international: two international exchanges; digital
microwave radio relay links to Namibia, Zambia,
Zimbabwe, and South Africa; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 8, FM 13,
shortwave 4 (2001)
Television broadcast stations: 1 (2001)
Internet country code: ,bw
Internet Service Providers (ISPs): 1 1 (2001 )
Internet users: 33,000(2001)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic exchange
domestic; tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4, shortwave 2
(1998)
Television broadcast stations: 1 (1996)
Internet country code: .va
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 234,000 (1997)
Telephones - mobile cellular: 14,427 (1 997)
Telephone system:
general assessment: inadequate system
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); connected to Centra! American
Microwave System
Radio broadcast stations: AM 241 , FM 53,
shortwave 12 (1998)
Television broadcast stations: 11 (plus 17
repeaters) (1997)
Internet country code: .hn
Internet Service Providers (ISPs): 8 (2000)
Internet users: 40,000 (2000)
Telephones - main lines in use: 18,000 (1998)
Telephones - mobile cellular: 3,010 (1998)
Telephone system:
general assessment: adequate connections
domestic: automatic telephone system completely
integrated into Italian system
international: connected to Italian international
network
Radio broadcast stations: AM 0, FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (San Marino
residents also receive broadcasts from Italy) (1997)
Internet country code: .sm
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones - main lines in use: 4.82 million (1998)
Telephones - mobile cellular: 1.967 million (1999)
Telephone system:
general assessment: excellent domestic and
international services
domestic: extensive cable and microwave radio relay
networks
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean)
Radio broadcast stations: AM 4, FM 113 (plus
many low power stations), shortwave 2 (1998)
Television broadcast stations: 1 1 5 (plus 1 ,91 9
repeaters) (1995)
Internet country code: .ch
Internet Service Providers (ISPs): 44 (Switzerland
and Liechtenstein) (2000)
Internet users: 3.41 million (2001)
Telephones - main lines in use: 1.313 million
(1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: fair system currently undergoing
significant improvement and digital upgrades,
including fiber-optic technology
domestic: coaxial cable and microwave radio relay
network
international: satellite earth stations • 1 1ntelsat
(Indian Ocean) and 1 1ntersputnik (Atlantic Ocean
region); 1 submarine cable; coaxial cable and
microwave radio relay to Iraq, Jordan, Lebanon, and
Turkey; participant in Medarabtel
Radio broadcast stations: AM 14, FM 2,
shortwave 1 (1998)
Television broadcast stations: 44 (plus 17
repeaters) (1995)
Internet country code: .sy
Internet Service Providers (ISPs): 1 (2000)
Internet users: 32,000(2001)','dfac28447dad98ead6ed81477035958f672ea247cb32e1beeee397f77298788a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e55d0d483cb57c4f8b803062eeeff27cd635d63a30a1509ce2e45cfcbbc0585a',2002,'BV','Bouvet Island','communications',219,'Internet country code: ,bv
Communications - note: automatic meteorological
station','d7e665c31de98b287cd339c3eb2aac29373c14840ab9df863d19b42b97d7fc74','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de4115d222f2f22c7da32ad76ea4ff40c8cfb9b39d7b45e540b1dbcc732425ac',2002,'CO','Colombia','communications',227,'Telephones ■ main lines in use: 17.039 million
(1997)
Telephones - mobile cellular: 4.4 million (1997)
Telephone system:
general assessment: good working system
domestic: extensive microwave radio relay system
and a domestic satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite
earth stations - 3 Intelsat (Atlantic Ocean), 1 1nmarsat
(Atlantic Ocean region east), connected by microwave
relay system to Mercosur Brazilsat B3 satellite earth
station
Radio broadcast stations: AM 1 ,365, FM 296,
shortwave 161 (of which 91 are collocated with AM
stations) (1999)
Television broadcast stations: 1 38 (1 997)
Internet country code: .br
Internet Service Providers (ISPs): 50 (2000)
Internet users: 1 1 .94 million (2001 )
Telephones - main lines in use: 5,433,565
(December 1997)
Telephones - mobile cellular: 1 ,800,229
(December 1998)
Telephone system:
general assessment: modem system in many respects
domestic: nationwide microwave radio relay system;
domestic satellite system with 41 earth stations;
fiber-optic network linking 50 cities
international: satellite earth stations - 6 Intelsat, 1
Inmarsat; 3 fully digitalized international switching
centers; 8 submarine cables
Radio broadcast stations: AM 454, FM 34,
shortwave 27 (1999)
Television broadcast stations: 60 (includes seven
low-power stations) (1997)
Internet country code: .co
Internet Service Providers (ISPs): 18 (2000)
Internet users: 878,000(2001)
Telephones - main lines in use: 396,000 (1997)
Telephones - mobile cellular: 17,000 (1997)
Telephone system:
general assessment: domestic and international
facilities well developed
domestic: NA
international: 1 coaxial submarine cable; satellite
earth stations - 2 Intelsat (Atlantic Ocean); connected
to the Centra! American Microwave System
Radio broadcast stations: AM 101, FM 134,
shortwave 0(1998)
Television broadcast stations: 38 (including
repeaters) (1998)
Internet country code: .pa
Internet Service Providers (ISPs): 6 (2000)
Internet users: 45,000 (2000)','821e975a515ea364cefdb11a0df3f9274179a9190607c4ca60dcc5fbfb7f46f1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565bf6aa801ee5097ff06d65a7d1e2e9964e54cc46d397eb4fbf830c75b5d0c0',2002,'IO','British Indian Ocean Territory','communications',236,'Telephones - main lines in use: NA
Telephone system:
general assessment: separate facilities for military
and public needs are available
domestic: all commercial telephone services are
available, including connection to the Internet
international: international telephone service is
carried by satellite (2000)
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: Jo
Internet Service Providers (ISPs): 1 (2000)
Telephones - main lines in use: 10,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: worldwide telephone service
domestic: HA
international: submarine cable to Bermuda
Radio broadcast stations: AM1.FM 4, shortwave 0
(1998)
Television broadcast stations: 1 (plus one cable
company) (1997)
Internet country code: .vg
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA','3d6a881a6077a224a4ad1bec69e57dba68328b182372be47d66cdb900d655409','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d1e0ca257c289b2463c08914e7b3aac06ecd7bd4f18e5fed5d1031455ddbd5',2002,'MY','Malaysia','communications',249,'Telephones - main lines in use: 79,000 (1996)
Telephones - mobile cellular: 43,524 (1996)
Telephone system:
general assessment: service throughout country is
excellent; international service good to Europe, US,
and East Asia
domestic: every service available
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean); digital submarine
cable links to Malaysia, Singapore, and Philippines
(2001)
Radio broadcast stations: AM 3, FM 10,
shortwave 0(1998)
Television broadcast stations: 2 (1997)
Internet country code: .bn
Internet Service Providers (ISPs): 2 (2000)
Internet users: 28,000(2001)','5009a0f1dca7e672e6e2297f3820fb20b1c944d8ed67398dc0bbc6e9140b7495','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4c90b985a534274cf35bacf32175094962a16af4e88e8da4556b6fe97c7a18e',2002,'BG','Bulgaria','communications',258,'Telephones - main lines in use: 3,186,731 (2001)
Telephones - mobile cellular: 1.054 million (2001)
Telephone system:
general assessment: extensive but antiquated
domestic: more than two-thirds of the lines are
residential; telephone service is available in most
villages; a fairly modern digital cable trunk line now
connects switching centers in most of the regions, the
others are connected by digital microwave radio relay
international: direct dialing to 58 countries; satellite
earth stations - 1 1ntersputnik (Atlantic Ocean region);
2 Intelsat (Atlantic and Indian Ocean regions)
Radio broadcast stations: AM 31 , FM 63,
shortwave 2 (2001)
Television broadcast stations: 39 (plus 1 ,242
repeaters) (2001)
Internet country code: .bg
Internet Service Providers (ISPs): 200 (2001)
Internet users: 585,000(2001)','e549ef3ad7e4232526be5d77f97fa790d90875f6f64c4bcc9168540bc09ce928','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3de1bb8a04d05a12ae75591043cfadc41e6a8b9ff1307c24740e2ddfa5769ca',2002,'ET','Ethiopia','communications',262,'Telephones - main lines in use: 53,200 (2000)
Telephones - mobile cellular: 25,200 (2000)
Telephone system:
general assessment: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 17,
shortwave 3 (2002)
Television broadcast stations: 1 (2001)
Internet country code: .of
internet Service Providers (ISPs): 4 (2001)
Internet users: 10,000(2001)
Telephones - main lines in use: 10,000 (2001)
Telephones - mobile cellular: NA
Telephone system:
general assessment: small system
domestic: combination of microwave radio relay,
open-wire lines, radiotelephone, and cellular
international: NA
Radio broadcast stations: AM 1 (transmitter out of
service), FM 4, shortwave 0 (2002)
Television broadcast stations: NA (1997)
Internet country code: .gw
Internet Service Providers (ISPs): 2 (2002)
Internet users: 1,500(1999)
Telephones - main lines in use: 3,000 (1997)
Telephones - mobile cellular: 6,942 (1997)
Telephone system:
general assessment: adequate facilities
domestic: minimal system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 4, shortwave 0
(1998)
Television broadcast stations: 2 (1997)
Internet country code: .st
Internet Service Providers (ISPs): 2 (2000)
Internet users: 6,500(2001)
Telephones - main lines in use: 3.1 million (1998)
Telephones -mobile cellular: 1 million
note: in 1 998, the government contracted for the
installation of 575,000 additional Group Speciale
Mobile (GSM) cellular telephone lines over 15 months
to raise the total number of subscribers to more than
one million; Riyadh planned to further expand the
GSM system in 1999 by adding an additional one
million lines (1998)
Telephone system:
general assessment: modern system
domestic: extensive microwave radio relay, coaxial
cable, and fiber-optic cable systems
international: microwave radio relay to Bahrain,
Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine cable
to Djibouti, Egypt and Bahrain; satellite earth
stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian
Ocean), 1 Arabsat, and 1 1nmarsat (Indian Ocean
region)
Radio broadcast stations: AM 43, FM 31,
shortwave 2 (1998)
Television broadcast stations: 117 (1997)
internet country code: .sa
Internet Service Providers (ISPs): 42 (2001)
Internet users: 570,000 (2001)','c6d1818d996a03aead75770fa86e19c757af900b8f18560eba1964e4f550544d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b20f460702c34f992cd6e70d2007cf9d25c401f2cf93add181148e0455f96aa5',2002,'TH','Thailand','communications',271,'Telephones - main lines in use: 250,000 (2000)
Telephones - mobile cellular: 8,492 (1997)
Telephone system:
general assessment: meets minimum requirements
for local and intercity service for business and
government; international service is good
domestic: NA
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 3
(1998)
Television broadcast stations: 2(1998)
Internet country code: .mm
Internet Service Providers (ISPs): 1
note: as of September 2000, internet connections
were legal only for the government, tourist offices, and
a few large businesses (2000)
Internet users: 500 (2000)
Telephones - main lines in use: 20,000 (2000)
Telephones - mobile cellular: 1 6,300 (2000)
Telephone system:
general assessment: primitive system
domestic: sparse system of open wire, radiotelephone
communications, and low-capacity microwave radio
relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 0, FM 4, shortwave 1
(2001)
Television broadcast stations: 1 (2001)
Internet country code: .bi
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)
Telephones • main lines in use: 25,000 (1997)
Telephones - mobile cellular: 4,915 (1997)
Telephone system:
general assessment: service to general public is poor
but improving, with over 20,000 telephones currently
in service and an additional 48,000 expected by 2001 ;
the government relies on a radiotelephone network to
communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 1ntersputnik
(Indian Ocean region)
Radio broadcast stations: AM 12, FM 1,
shortwave 4 (1998)
Television broadcast stations: 4 (1999)
Internet country code: .la
internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000(2001)','1a2485fbc749e1cdccc599a7205e6a6abd21a7e1e66b93964c2ec2aadc71caa8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b6ca437e6607baad7a585e02d7e2df1e4924d72d6e06b165fab60b103cabb5',2002,'UG','Uganda','communications',285,'Telephones * main lines in use: 21 ,800 (mid- 1998)
Telephones - mobile cellular: 80,000 (2000)
Telephone system:
general assessment: adequate landline and/or
cellular service in Phnom Penh and other provincial
cities; rural areas have little telephone service
domestic: NA
international: adequate but expensive landline and
cellular service available to all countries from Phnom
Penh and major provincial cities; satellite earth
station - 1 1ntersputnik (Indian Ocean region)
Radio broadcast stations: AM 7, FM 3, shortwave 3
(1999)
Television broadcast stations: 5 (1999)
Internet country code: .kh
Internet Service Providers (ISPs): 2 (2000)
Internet users: 6,000(2001)
Telephones - main lines in use: 95,000 (2001)
Telephones - mobile cellular: 300,000 (2002)
Telephone system:
general assessment: available only to business and
Telephones - main lines in use: 2,000 (1997)
Telephones - mobile cellular: 0 (1997)
Telephone system:
general assessment: can communicate worldwide
domestic: automatic network
international: HF radiotelephone from Saint Helena to
Ascension which is a major coaxial submarine cable
relay point between South Africa, Portugal, and UK ;
satellite earth stations • 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: ,sh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Communications - note: Gough Island has a
meteorological station','177ee41d32783bb02e563557950886f898e90ed99f717f967b88e2f7616c41d4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa451cfd19d1cd6c25d8f9255588499cb58b3a1d531407c5b99f3b6a69690deb',2002,'CA','Canada','communications',295,'Telephones - main lines in use: 1 8.5 millfon (1 999)
Telephones - mobile cellular: 4.207 million (1997)
Telephone system:
general assessment: excellent service provided by
modern technology
domestic: domestic satellite system with about 300
earth stations
international: 5 coaxial submarine cables; satellite
earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean
region)
Radio broadcast stations: AM 535, FM 53,
shortwave 6 (1998)
Television broadcast stations: 80 (plus many
repeaters) (1997)
Internet country code: .ca
Internet Service Providers (ISPs): 760 (2000 est.)
Internet users: 14.44 million (2001)','fe55ba784a42fc8620ce35fb801eab0a71ab03d20e142d8996e63dca95f19357','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9af96c536b89465aaec2351f1d2ce1d1111957c860217e2d0eda1894b1bf6404',2002,'PT','Portugal','communications',299,'Telephones - main lines in use: 60,935 (2002)
Telephones - mobile cellular: 28,1 19 (2002)
Telephone system:
general assessment: effective system, being improved
domestic: interisland microwave radio relay system
with both analog and digital exchanges; work is in
progress on a submarine fiber-optic cable system
which is scheduled for completion in 2003
international: 2 coaxial submarine cables; HF
radiotelephone to Senegal and Guinea-Bissau;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 11 (and 14
repeaters), shortwave 0 (1998)
Television broadcast stations: 3 (2002)
Internet country code: .cv
Internet Service Providers (ISPs): 1 (2000)
Internet users: 8,000(2001)
Telephones - main lines in use: 5.3 million
(yearend 1998)
Telephones - mobile cellular: 3,074,1 94 (1 999)
Telephone system:
general assessment: undergoing rapid development
in recent years, Portugal''s telephone system, by the
end of 1998, achieved a state-of-the-art network with
broadband, high-speed capabilities and a main line
telephone density of 53%
domestic: integrated network of coaxial cables, open
wire, microwave radio relay, and domestic satellite
earth stations
international: 6 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean), NA Eutelsat; troposphere scatter to Azores;
note - an earth station for Inmarsat (Atlantic Ocean
region) is planned
Radio broadcast stations: AM 47, FM 172 (many
are repeaters), shortwave 2 (1998)
Television broadcast stations: 62 (plus 166
repeaters)
note: includes Azores and Madeira Islands (1995)
Internet country code: .pt
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2 million (2001)','3dcc000a2573ba88574af4075cb13f7623df2e3e50ea0eefc348960a866eb6e4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7996d59e2c72f4b383cab4dba98d37acc6c8c79223410caf80fab2ea624cce',2002,'HN','Honduras','communications',310,'Telephones - main tines in use: 19,000 (1995)
Telephones - mobile cellular: 2,534 (1995)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine coaxial cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 1 with cable system
Internet country code: ,ky
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Telephones - main lines in use: 10,000 (1997)
Telephones - mobile cellular: 570 (1997)
Telephone system:
general assessment: fair system
domestic: network consists principally of microwave
radio relay and low-capacity, (ow-powered
radiotelephone communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 0, FM 4, shortwave 1
{2001)
Television broadcast stations: 1 (2001)
Internet country code: .cf
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,500(2001)
Telephones - main lines in use: 10,260 (2000)
Telephones - mobile cellular: 20,000 (2002)
Telephone system:
general assessment: primitive system
domestic: fair system of radiotelephone
communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 5
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .td
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,000 (2000)
103
Chad (continued)
Telephones - main lines in use: 380,000 (1998)
Telephones - mobile cellular: 40,163 (1997)
Telephone system:
general assessment: NA
domestic: nationwide microwave radio relay system
international: satellite earth station • 1 1ntelsat (Atlantic
Ocean); connected to Central American Microwave
System
Radio broadcast stations: AM 61 (plus 24
repeaters), FM 30, shortwave 0 (1998)
Television broadcast stations: 5 (1997)
Internet country code: .sv
Internet Service Providers (ISPs): 4 (2000)
Internet users: 40,000(2000)','a41e4674a0b6e727c767cf6e73d0388ff04c6215378ffc2ae5d3a59884a17a04','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a83c4e75e2b800acc0af18e9b986a3e790b363fd2526fe13b9423280550b25',2002,'PE','Peru','communications',321,'Telephones - main lines in use: 2,603 million
(1998)
Telephones - mobile cellular: 944,225 (1998)
Telephone system:
general assessment: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay links;
domestic satellite system with 3 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 180 (eight inactive),
FM 64, shortwave 17 (one inactive) (1998)
Television broadcast stations: 63 (plus 121
repeaters) (1997)
Internet country code: cl
Internet Service Providers (ISPs): 7 (2000)
Internet users: 1 .75 million (2001)
Telephones - main lines In use: 1,11 5,272 (1 999)
Telephones - mobile cellular: 384,000 (1999)
Telephone system:
general assessment: generally elementary but being
expanded
domestic: facilities generally inadequate and
unreliable
intemationai: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 392, FM 35,
shortwave 29 (2001)
Television broadcast stations: 7 (plus 14
repeaters) (2001)
Internet country code: .ec
Internet Service Providers (ISPs): 31 (2001)
Internet users: 180,000 (2001)','98f55e867da5058e8695c5d5a02fb437455d31e45a9da64923a34411c7f6de42','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5d7f04b2713481686198870e91920adceb27107f6f4b68e1274383c08ed102f',2002,'CX','Christmas Island','communications',330,'Telephones - main tines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: service provided by the
Australian network
domestic: only analog mobile telephone service is
available
International: satellite earth stations - one Intelsat
earth station provides telephone and telex service
(2000)
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: NA
Internet country code: .cx
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','5fe28e4cc5b1f19bb3198464bb939c4f6a3bc15ab49be1819ae633f865ddebcc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c645a6c04718f263be950098aca1226454b4ef4daa4e16b5ae4c08414f47ae97',2002,'MZ','Mozambique','communications',332,'Telephones - main lines in use: 7,000 (2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: sparse system of microwave
radio relay and HF radiotelephone communication
stations
domestic: HF radiotelephone communications and
microwave radio relay
international: HF radiotelephone communications to
Madagascar and Reunion
Radio broadcast stations: AM 1 , FM 4, shortwave 1
(2001)
Television broadcast stations: NA
Internet country code: .km
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,500(2001)
Communications - note: 1 meteorological station
Communications - note: 1 meteorological station
Telephones - main lines in use: 12.49 million
(September 2000)
Telephones - mobile cellular: 16 million
(September 2000)
Telephone system:
general assessment: provides telecommunications
service for every business and private need
domestic: thoroughly modern; completely digitalized
international: satellite earth stations - 2 Intelsat (1
Pacific Ocean and 1 1ndian Ocean); submarine cables
to Japan (Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle East, and
Western Europe (1999)
Radio broadcast stations: AM 218, FM 333,
shortwave 50 (1999)
Television broadcast stations: 29 (plus two
repeaters) (1997)
Internet country code: .tw
Internet Service Providers (ISPs): 8 (2000)
Internet users: 1 1 .6 million (2001 )','acf97b0543d0a52c1e29edf6c3503905bd85fed0389b56b3ef779074cacd3ab4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a621276eff498eb32326ccf3201bed1c7f8ba9a1d8d747bc6e32b580b171d66',2002,'CG','Congo','communications',335,'Telephones • main lines in use: 21 ,000 (1 997)
Telephones - mobile cellular: 15,000 (2000)
Telephone system:
general assessment: poor
domestic: barely adequate wire and microwave radio
relay service in and between urban areas; domestic
satellite system with 14 earth stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1 1 ,
shortwave 2 (2001)
Television broadcast stations: 4 (2001)
Internet country code: .cd
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1,500(1999)
Telephones - main lines in use: 22,000 (1997)
Telephones - mobile cellular: 250,000 (2001)
Telephone system:
general assessment: services barely adequate for
government use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; intercity lines frequently
out-of-order
domestic: primary network consists of microwave
radio relay and coaxial cable
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 3
(2001)
Television broadcast stations: 1 (2002)
Internet country code: .eg
Internet Service Providers (ISPs): 1 (2000)
Internet users: 500 (2000)','8ab2297f9f42fb3ac361a8e852e381441d00e9216eb472108e50938c18f617ff','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b479cf694e3b1d98d4e57a8fc8a330d57745e69f91c55fc4ac120674f9f43aac',2002,'CK','Cook Islands','communications',348,'Telephones - main lines in use: 5,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: NA
ctomesf/cthe individual islands are connected by a
combination of satellite earth stations, microwave
systems, and VHF and HF radiotelephone; within the
islands, service is provided by small exchanges
connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 2; shortwave 0
(1998)
Television broadcast stations: 2 (plus eight
low-power repeaters) (1997)
Internet country code: .ck
Internet Service Providers (ISPs): 3 (2000)
Internet users: NA
Communications - note: there are automatic
weather stations on many of the isles and reefs
relaying data to the mainland','beb89ecbb57ca50ea690dfa348188195e3216ac650302f48f152919e3211c7bf','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45bb8851ab0773193a4cf406c4f30d6d6ef28d971dbdd2c51aea199d237af022',2002,'CR','Costa Rica','communications',357,'Telephones - main lines in use: 450,000(1998)
note: 584,000 installed in 1 997, but only about
450,000 were in use in 1998
Telephones - mobile cellular: 143,000 (2000)
Telephone system:
general assessment: very good domestic telephone
service
domestic: point-to-point and point-to-multi-point
microwave, fiber-optic, and coaxial cable link rural
areas; Internet service is available
international: connected to Central American
Microwave System; satellite earth stations - 2 Intelsat
(Atlantic Ocean); two submarine cables (1999)
Radio broadcast stations: AM 50, FM 43,
shortwave 19 (1998)
Television broadcast stations: 6 (plus 1 1
repeaters) (1997)
Internet country code: .cr
Internet Service Providers (ISPs): 3 (of which only
one is legal) (2000)
Internet users: 250,000(2001)','84d849236051aa63d71b933165ccb8534168b6b56125791a44be07e1f9a52fbe','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('254f93b5df84a89b9331cf864e38b8a4d0e739e5987804a9dcb24306bf0db2c8',2002,'SI','Slovenia','communications',369,'Telephones • main lines in use: 1 ,721 ,1 39 (2000)
Telephones - mobile cellular: 1,3 million (2001)
Telephone system:
general assessment: NA
domestic: reconstruction plan calls for replacement of
all analog circuits with digital and enlarging the
network; a backup will be included in the plan for the
main trunk
international: digital international service is provided
through the main switch in Zagreb; Croatia
participates in the Trans-Asia-Europe (TEL)
fiber-optic project which consists of two fiber-optic
trunk connections with Slovenia and a fiber-optic trunk
line from Rijeka to Split and Dubrovnik; Croatia is also
investing in ADRIA 1, a joint fiber-optic project with
Germany, Albania, and Greece (2000)
Radio broadcast stations: AM 16, FM 98,
shortwave 5 (1999)
Television broadcast stations: 36 (plus 321
repeaters) (September 1995)
Internet country code: .hr
Internet Service Providers (ISPs): 9 (2000)
Internet users: 200,000 (2001)
132
Croatia (continued)','dcc1c98d369e3a55e7de3bde99ebfc87257da96a11bb96e5db6bbab7cfdb2704','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ebcefca8d5c48c0ba673b54a1221d9fb81a3ee7d76e6465ea9f7aa7be72226b',2002,'CU','Cuba','communications',379,'Telephones - main lines in use: 473,031 (2000)
Telephones - mobile cellular: 2,994 (1997)
Telephone system:
general assessment: UA
domestic: principal trunk system, end to end of
country, is coaxial cable; fiber-optic distribution in
Havana and on tsla de la Juventud; 2 microwave radio
relay installations (one is old, US-built; the other
newer, built during the period of Soviet support); both
analog and digital mobile cellular service established
international: satellite earth station - 1 1ntersputnik
(Atlantic Ocean region)
Radio broadcast stations: AM 169. FM 55,
shortwave 1 (1998)
Television broadcast stations: 58 (1997)
Internet country code: xu
Internet Service Providers (ISPs): 5 (2001)
Internet users: 60,000(2001)
Telephones - main fines in use: Greek Cypriot
area: 405,000 (1998); Turkish Cypriot area: 83,162
(1998)
Telephones - mobile cellular: Greek Cypriot area:
68,000 (1998); Turkish Cypriot area: 70,000 (1999)
Telephone system:
general assessment: excellent in both the Greek
Cypriot and Turkish Cypriot areas
domestic: open wire, fiber-optic cable, and microwave
radio relay
/ntemaf/ona/: tropospheric scatter; 3 coaxial and 5
fiber-optic submarine cables; satellite earth stations -
3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean), 2
Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AM
7, FM 60, shortwave 1 (1998); Turkish Cypriot area:
AM 3, FM 1 1, shortwave 1 (1996)
Television broadcast stations: Greek Cypriot
area: 4 (plus 225 low-power repeaters)
(September 1995); Turkish Cypriot area: 4 (plus
5 repeaters) (September 1995)
Internet country code: ,cy
Internet Service Providers (ISPs): 6 (2000)
Internet users: 120,000(2001)
Telephones - main lines in use: 3.869 million
(2000)
Telephones - mobile cellular: 4.346 million (2000)
Telephone system:
general assessment: privatization and modernization
of the Czech telecommunication system got a late
start but is advancing steadily; growth in the use of
mobile cellular telephones is particularly vigorous
domestic: 86% of exchanges now digital; existing
copper subscriber systems now being enhanced with
Asymmetric Digital Subscriber Line (ADSL)
equipment to accommodate Internet and other digital
signals; trunk systems include fiber-optic cable and
microwave radio relay
international: satellite earth stations - 2 Intersputnik
(Atlantic and Indian Ocean regions), 1 1ntelsat, 1
Eutelsat, 1 1nmarsat, 1 Globalstar
Radio broadcast stations: AM 31 , FM 304,
shortwave 17 (2000)
Television broadcast stations: 1 50 (plus 1 ,434
repeaters) (2000)
Internet country code: .cz
Internet Service Providers (ISPs): more than 300
(2000)
Internet users: 1.1 million (2001)
141
Czech Republic (continued)','965b3b0e0c8cac14c98dd9f0dcab96b57c62f4d3b4770f6d5859d80f1c8b142e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95946654604ec312f9a32ef4e06dfdd416100cea06df1821760abd773b09c8b1',2002,'SE','Sweden','communications',390,'Telephones - main lines in use: 4.785 million
(1997)
Telephones - mobile cellular: 1,444,016 (1997)
Telephone system:
general assessment: excellent telephone and
telegraph services
domestic: buried and submarine cables and
microwave radio relay form trunk network, 4 cellular
mobile communications systems
international: 18 submarine fiber-optic cables linking
Denmark with Norway, Sweden, Russia, Poland,
Germany, Netherlands, UK, Faroe Islands, Iceland,
and Canada; satellite earth stations - 6 Intelsat, 10
Eutelsat, 1 Orion, 1 1nmarsat
(Blaavand-Atlantic-East); note - the Nordic countries
(Denmark, Finland, Iceland, Norway, and Sweden)
share the Danish earth station and the Eik, Norway,
station for worldwide Inmarsat access (1997)
Radio broadcast stations: AM 2, FM 355,
shortwave 0(1998)
Television broadcast stations: 26 (plus 51
repeaters) (1998)
Internet country code: .dk
Internet Service Providers (ISPs): 13 (2000)
Internet users: 2.93 million (2001)
Railways:
total: 2,859 km (508 km privately owned and
operated)
standard gauge: 2,859 km 1 .435-m gauge (600 km
electrified; 760 km double-track) (1998 est.)
Highways:
tofa/: 71,474 km
paved: 71 ,474 km (including 880 km of expressways)
unpaved: 0 km (1999)
Waterways: 417 km
Pipelines: crude oil 1 1 0 km; petroleum products 578
km; natural gas 700 km
Ports and harbors: Abenra, Alborg, Arhus,
Copenhagen, Esbjerg, Fredericia, Kolding, Odense,
Roenne (Bornholm), Vejle
Merchant marine:
total: 301 ships (1 ,000 GRT or over) totaling
6,258,959 GRT/8, 143,520 DWT
ships by type: bulk 8, cargo 105, chemical tanker 26,
container 72, liquefied gas 20, livestock carrier 5,
petroleum tanker 25, railcar carrier 1, refrigerated
cargo 13, roll on/roll off 16, short-sea passenger 7,
specialized tanker 3
note: includes some foreign-owned ships registered
here as a flag of convenience: Germany 1 , Greenland
1, Indonesia 1, Netherlands 1, Norway 9, United
Kingdom 1 (2002 est.)
Airports: 116(2001)
Airports - with paved runways:
fofa/:28
over 3,047 m: 2
2,438 to 3,047 m: 7
1524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2001)
Airports - with unpaved runways:
totefr88
1,524 to 2,437 m:1
914 to 1,523 m:7
under 914 m: 80 (2001)
Telephones ■ main lines in use: 6.017 million
(December 1998)
Telephones - mobile cellular: 3.835 million
(October 1998)
Telephone system:
general assessment: excellent domestic and
international facilities; automatic system
domestic: coaxial and multiconductor cables carry
most of the voice traffic; parallel microwave radio relay
systems carry some additional telephone channels
international: 5 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean), 1 Eutelsat,
and 1 1nmarsat (Atlantic and Indian Ocean regions);
note - Sweden shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations: AM 1, FM 265,
shortwave 1 (1998)
Television broadcast stations: 1 69 (plus 1 ,299
repeaters) (1995)
Internet country code: .se
Internet Service Providers (ISPs): 29 (2000)
Internet users: 5.64 million (2000)
Transportation Transnational Issues
Railways: Disputes - international: none
total: 12,821 km
standard gauge: 12,600 km 1 ,435-m gauge (7,918 km
electrified)
narrow gauge: 221 km 0.891 -m gauge (2001)
Highways:
total: 210,760 km
paved: 162707 km (including 1 ,428 km of
expressways)
unpavecf:48,053km(1999)
Waterways: 2,052 km
note: navigable to small steamers and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavle, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 174 ships (1 ,000 GRT or over) totaling
2,255,344 GRT/1 ,609,844 DWT
ships by type: bulk 5, cargo 37, chemical tanker 33,
combination ore/oil 4, passenger 1, petroleum tanker
27, railcar carrier 1, roll on/roll off 38, short-sea
passenger 4, specialized tanker 6, vehicle
carrier 18
note: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 8, Finland 8,
Germany 3, Itafy 3, Japan 2, Norway 7
(2002 est.)
Airports: 255(2001)
Airports - with paved runways:
total: W
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 80
914 to 1,523 m: 27
under 914 m: 25 (2001)
Airports - with unpaved runways:
total: 108
914 to 1 ,523 m:6
under 914 m: 102 (2001)
Heliports: 1 (2001)','f33a854f3d5d6d65f3209324f8d57b2b7ed9bac829d24989d434b5e40096ac9f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f82246d3631e615d075ca173912f83cb869743bfd5f1a40448072af2c69da2c',2002,'DJ','Djibouti','communications',397,'Telephones - main lines In use: 10,000 (2002)
Telephones - mobile cellular: NA (2002)
Telephone system:
genera! assessment: telephone facilities in the city of
Djibouti are adequate as are the microwave radio
relay connections to outlying areas of the country
domestic: microwave radio relay network
international: submarine cable to Jiddah, Suez, Sicily,
Marseilles, Colombo, and Singapore; satellite earth
stations - 1 1ntelsat (Indian Ocean) and 1 Arabsat;
Medarabtel regional microwave radio relay telephone
network
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(2001)
Television broadcast stations: 1 (2002)
Internet country code: .dj
Internet Service Providers (ISPs): 1 (2000)
internet users: 1,400(2000)
Telephones ■ main lines in use: 19,000 (1996)
Telephones - mobile cellular: 461 (1 996)
Telephone system:
general assessment: NA
domestic: fully automatic network
international: microwave radio relay and SH F
radiotelephone links to Martinique and Guadeloupe;
VHF and UHF radiotelephone links to Saint Lucia
Radio broadcast stations: AM 3, FM 10,
shortwave 0(1 998)
Television broadcast stations: 0 (however, there is
one cable television company) (1 997)
Internet country code: .dm
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000 (2000)','84c34fa07345c076105a4be20e22e21b96753baf1a3dd750f448eb21fa66da7e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2c829a9ce6c4ccf53c509f9dd7c89e46600952df0dde40a100bed3382496cbe',2002,'DO','Dominican Republic','communications',407,'Telephones - main lines in use: 709,000 (1997)
Telephones - mobile cellular: 1 30, 1 49 (1 997)
Telephone system:
general assessment: Kb
domestic: relatively efficient system based on
islandwide microwave radio relay network
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 56,
shortwave 4 (1998)
Television broadcast stations: 25(1997)
Internet country code: .do
Internet Service Providers (ISPs): 24 (2000)
Internet users: 25,000(1999)
Telephones - main lines in use: 1 .322 million
(1997)
Telephones - mobile cellular: 169,265 (1 996)
Telephone system:
general assessment: modern system, integrated with
that of the US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system; cellular telephone
service
international: satellite earth station - 1 1ntelsat;
submarine cable to US
Radio broadcast stations: AM 72, FM 17,
shortwave 0(1998)
Television broadcast stations: 18 (plus three
stations of the US Armed Forces Radio and Television
Service) (1997)
Internet country code: .pr
Internet Service Providers (ISPs): 76 (2000)
Internet users: 200,000 (2000)','bd21c19cff932565d7af61988c00fd7f8a1498f8cc063015b5bf9ed10dc5d2ee','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('507855936baf1c24015bd3790b7108dcd240e7dd14a26787f9b54fac6ccea40b',2002,'ID','Indonesia','communications',414,'Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
152
East Timor (continued)
Television broadcast stations: NA
Internet country code: .tp
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 5,588,310 (1998)
Telephones - mobile cellular: 1.07 million (1998)
Telephone system:
general assessment: domestic service fair,
international service good
domestic: interisland microwave system and HF radio
police net; domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 678, FM 43,
shortwave 82 (1998)
Television broadcast stations: 41 (1999)
Internet country code: .id
Internet Service Providers (ISPs): 24 (2000)
Internet users: 2 million (2001)
Telephones - main lines in use: 6.313 million
(1997)
Telephones - mobile cellular: 265,000
(August 1998)
Telephone system:
general assessment: inadequate but currently being
modernized and expanded with the goal of not only
improving the efficiency and increasing the volume of
the urban service but also bringing telephone service
to several thousand villages, not presently connected
domestic: as a result of heavy investing in the
telephone system since 1994, the number of
long-distance channels in the microwave radio relay
trunk has grown substantially; many villages have
been brought into the net; the number of main lines in
the urban systems has approximately doubled; and
thousands of mobile cellular subscribers are being
served; moreover, the technical level of the system
has been raised by the installation of thousands of
digital switches
international: HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; submarine fiber-optic cable to UAE with
access to Fiber-Optic Link Around the Globe (FLAG);
Trans-Asia-Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to
Turkmenistan with expansion to Georgia and
Azerbaijan; satellite earth stations - 9 Intelsat and 4
Inmarsat; Internet service available but limited to
electronic mail to promote Iranian culture
Radio broadcast stations: AM 72, FM 5,
shortwave 5 (1998)
Television broadcast stations: 28 (plus 450
low-power repeaters) (1997)
Internet country code: .ir
Internet Service Providers (ISPs): 8 (2000)
Internet users: 250,000(2001)
Telephones - main lines In use: 675,000 (1997)
Telephones - mobile cellular: NA; sen/ice available
in northern Iraq (2001)
Telephone system:
general assessment: ^constitution of damaged
telecommunication facilities began after the Gulf war;
most damaged facilities have been rebuilt
domestic: the network consists of coaxial cables and
microwave radio relay links
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Atlantic Ocean region), and 1 Arabsat (inoperative);
coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 19 (5 are inactive),
FM 51, shortwave 4 (1998)
Television broadcast stations: 13 (1997)
Internet country code: .iq
Internet Service Providers (ISPs): 1 (2000)
Internet users: 12,500(2001)
Telephones - main lines in use: 4.6 million (2000)
Telephones - mobile cellular: 5 million (2000)
Telephone system:
general assessment: modern system; international
service excellent
domestic: good intercity service provided on
Peninsular Malaysia mainly by microwave radio relay;
adequate intercity microwave radio relay network
between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong,
and Singapore; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean) (2001)
Radio broadcast stations: AM 35, FM 391 ,
shortwave 15 (2001)
Television broadcast stations: 1 (plus 15
high-power repeaters) (2001)
Internet country code: .my
Internet Service Providers (ISPs): 7(2000)
Internet users: 4.1 million (2001)
Telephones - main lines in use: 1 1 ,000 (2001)
Telephones - mobile cellular: NA
Telephone system:
general assessment: adequate system
domestic: islands interconnected by shortwave
radiotelephone (used mostly for government
purposes)
international: satellite earth stations - 5 Intelsat
(Pacific Ocean) (2002)
Radio broadcast stations: AM 5, FM 1 , shortwave 0
(1998)
Television broadcast stations: 2(1997)
Internet country code: .fm
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)
Telephones - main lines in use: 61 ,152 (1999)
Telephones - mobile cellular: 3,053 (1996)
Telephone system:
general assessment: services are adequate and
being improved; facilities provide radiotelephone and
telegraph, coastal radio, aeronautical radio, and
international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and
Guam; satellite earth station - 1 1ntelsat (Pacific
Ocean); international radio communication service
Radio broadcast stations: AM 8, FM 19,
shortwave 28 (1998)
Television broadcast stations: 3 (all in the Port
Moresby area)
nofe; additional stations at Mt. Hagen, Goroka, Lae,
and Rabaul are planned (2002)
Internet country code: .pg
Internet Service Providers (ISPs): 3 (2000)
Internet users: 135,000(2001)
Telephones - main lines in use: 1 .95 million (2000)
Telephones - mobile cellular: 2.74 million (2000)
Telephone system:
general assessment: major consideration given to
serving business interests; excellent international
service
domestic: excellent domestic facilities
international: submarine cables to Malaysia (Sabah
and Peninsular Malaysia), Indonesia, and the
Philippines; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean), and 1 1nmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 0, FM 16;
shortwave 2 (1998)
Television broadcast stations: 6 (2000)
Internet country code: .sg
Internet Service Providers (ISPs): 9 (2000)
Internet users: 2.12 million (2001)','8b8a337c17cb7be85d714b8b03ccb04d7a439bee0d22610cd2f7384f740ce27d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529477b8767243d9b0d63d4d89509567c8f18d1fff4488d70301d2196b4103c4',2002,'LY','Libya','communications',424,'Telephones - main lines in use: 3,971,500
(December 1998)
Telephones • mobile cellular: 380,000 (1 999)
Telephone system:
general assessment: large system; underwent
extensive upgrading during 1990s and is reasonably
modern; Internet access and cellular service are
available
domestic: principal centers at Alexandria, Cairo, Al
Mansurah, Ismailia, Suez, and Tanta are connected
by coaxial cable and microwave radio relay
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean), 1 Arabsat, and
1 1nmarsat; 5 coaxial submarine cables; tropospheric
scatter to Sudan; microwave radio relay to Israel; a
participant in Medarabtel and a signatory to Project
Oxygen (a global submarine fiber-optic cable system)
Radio broadcast stations: AM 42 (plus
15 repeaters), FM 14, shortwave 3 (1999)
Television broadcast stations: 98 (September
1995)
Internet country code: .eg
Internet Service Providers (ISPs): 50 (2000)
Internet users: 560,000 (2001)','af159a4b837c5fdf6159d920dc5fed889fb7df4540d1a45b641ddd181417bc39','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('567092d02c55f59d1fda087489fd086583d65e1e68a181d452dbe1b5e9b2cf61',2002,'GN','Guinea','communications',434,'Telephones - main lines in use: 4,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poor system with adequate
government services
domestic: NA
international: international communications from Bata
and Malabo to African and European countries;
satellite earth station • 1 1ntelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 3, shortwave 5
(2002)
Television broadcast stations: 1 (2002)
Internet country code: .gq
Internet Service Providers (ISPs): 1 (2000)
internet users: 600 (2000)
Telephones - main lines in use: 30,000 (2001 )
Telephones - mobile cellular: NA; note - mobile
cellular service was introduced in May 2001
Telephone system:
general assessment: inadequate
domestic: very inadequate; most telephones are in
Asmara; government is seeking international tenders
to improve the system (2002)
international: NA; note - international connections
exist
Radio broadcast stations: AM 2, FM NA,
shortwave 2 (2000)
Television broadcast stations: 1 (2000)
Internet country code: .er
Internet Service Providers (ISPs): 5 (2001)
Internet users: 12,000(2001)
Telephones - main lines in use: 500,000 (2000)
Telephones - mobile cellular: 200,000 (2001)
Telephone system:
general assessment: an inadequate system, further
limited by poor maintenance; major expansion is
required and a start has been made
domestic: intercity traffic is carried by coaxial cable,
microwave radio relay, a domestic communications
satellite system with 19 earth stations, and a coastal
submarine cable; mobile cellular facilities and the
Internet are available
international: satellite earth stations - 3 Intelsat (2
Atlantic Ocean and 1 1ndian Ocean); coaxial
submarine cable SAFE (South African Far East)
Radio broadcast stations: AM 83, FM 36,
shortwave 11 (2001)
Television broadcast stations: 3 (the government
controls 2 broadcasting stations and 15 repeater
stations) (2002)
Internet country pode: .ng
Internet Service Providers (ISPs): 11 (2000)
Internet users: 100,000(1999)','6af2fe3304976296da7d22a99ba12267db21cb00f55cfd3a3e2dccfde1c5c4df','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('049684536ede5b963bbc21b2a2c7222ad013a05fbb9f9eece8ce202c7b8f31f5',2002,'EE','Estonia','communications',446,'Telephones - main lines in use: 501,691 (2000)
Telephones • mobile cellular: 71 1 ,000 (yearend
2001)
Telephone system:
general assessment: foreign investment in the form of
joint business ventures greatly improved telephone
service; substantial fiber-optic cable systems carry
telephone, TV, and radio traffic in the digital mode;
internet services are available throughout most of the
country - only about 1 1 ,000 subscriber requests were
unfilled by September 2000
domestic: a wide range of high quality voice, data, and
internet services is available throughout the country
international: fiber-optic cables to Finland, Sweden,
Latvia, and Russia provide worldwide
packet-switched service; two international switches
are located in Tallinn (2001)
Radio broadcast stations: AM 0, FM 98,
shortwave 0(2001)
Television broadcast stations: 3 (2001)
Internet country code: .ee
Internet Service Providers (ISPs): 38 (2001)
Internet users: 540,000 (2001)
Telephones - main lines In use: 231 ,900 (2000)
Telephones - mobile cellular: 17,800 (2000)
Telephone system:
general assessment: open wire and microwave radio
relay system; adequate for government use
domestic: open wire; microwave radio relay; radio
communication in the HF, VHF, and UHF frequencies;
two domestic satellites provide the national trunk
service
international: open wire to Sudan and Djibouti;
microwave radio relay to Kenya and Djibouti; satellite
earth stations - 3 Intelsat (1 Atlantic Ocean and 2
Pacific Ocean)
Radio broadcast stations: AM 8, FM 0, shortwave 1
(2001)
Television broadcast stations: 1 plus 24 repeaters
(2002)
Internet country code: .et
Internet Service Providers (ISPs): 1 (2002)
Internet users: 20,000(2002)','9ffe7ee0f692852bac1558e0cfb3080b18b62a55cb6d92b91521df74a9f7f2d5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c48c50e46308fdf26b10d834b65d2e3d9f198e133ebd6d8ad994b1c70a9c3e65',2002,'FO','Faroe Islands','communications',456,'Telephones - main lines in use: 24,851 (1999)
Telephones - mobile cellular: 10,761 (1999)
Telephone system:
general assessment: good international
communications; good domestic facilities
domestic: digitization was completed in 1998; both
NMT (analog) and GSM (digital) mobile telephone
systems are installed
intemationaf: satellite earth stations - 1 Orion; 1
fiber-optic submarine cable to the Shetland Islands,
linking the Faroe Islands with Denmark and Iceland;
fiber-optic submarine cable connection to
Canada-Europe cable
Radio broadcast stations: AM 1, FM 13,
shortwave 0(1998)
Television broadcast stations: 3 (plus 43
low-power repeaters) (September 1995)
Internet country cod<3: .fo
Internet Service Providers (ISPs): 2 (2000)
Internet users: 3,000(2000)','1bd17cf6d5027a8f8880cbb766b1bcb163f159ce5ff363e9c77823d1512f5e39','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('785795e47e893ba6a238f7db2e472d73ea8171e44a4538800691f6685d61ba3f',2002,'JE','Jersey','communications',467,'Telephones - main lines in use: 80,901 (1999)
Telephones - mobile cellular: 5,200 (1997)
Telephone system:
general assessment: modern local, interisland, and
international (wire/radio integrated) public and
special-purpose telephone, telegraph, and teleprinter
facilities: regional radio communications center
domestic: NA
international: access to important cable links between
US and Canada as well as between NZ and Australia;
satellite earth station - 1 1ntelsat (Pacific Ocean)
Radio broadcast stations: AM 13. FM 40,
shortwave 0(1998)
Television broadcast stations: NA
Internet country code: .fj
Internet Service Providers (ISPs): 2 (2000)
Internet users: 7,500 (2000)
Telephones • main lines in use: 2.861 million
(1997)
Telephones • mobile cellular: 2,162,574 (1997)
Telephone system:
general assessment: modern system with excellent
service
domestic: cable, microwave radio relay, and an
extensive cellular net provide domestic needs
international: 1 submarine cable; satellite earth
stations - access to Intelsat transmission service via a
Swedish satellite earth station, 1 1nmarsat (Atlantic
and Indian Ocean regions); note - Finland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 2, FM 186,
shortwave 1 (1998)
Television broadcast stations: 130 (plus 385
repeaters) (1995)
Internet country code: .fi
Internet Service Providers (ISPs): 23 (2000)
Internet users: 2.27 million (2000)
Telephones • main lines in use: 2.8 million (1999)
Telephones ■ mobile cellular: 2.5 million (1999)
Telephone system:
genera! assessment: most highly developed system
in the Middle East although not the largest
domestic: good system of coaxial cable and
microwave radio relay; all systems are digital
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean)
Radio broadcast stations: AM 23, FM 15,
shortwave 2 (1998)
Television broadcast stations: 17 (plus 36
low-power repeaters) (1995)
Internet country code: .it
Internet Service Providers (ISPs): 21 (2000)
Internet users: 1.94 million (2001)
Telephones - main lines in use: 65,500 (1997)
Telephones - mobile cellular: 4,400 (1997)
Telephone system:
general assessments
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM NA, FM 1 ,
shortwave 0(1 998)
Television broadcast stations: 1 (1997)
Internet country code: .je
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 412,000 (1997)
Telephones - mobile cellular: 210,000 (1997)
Telephone system:
■ general assessment: the quality of service is excellent
domestic: new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, open wire, and
fiber-optic cable; a cellular telephone system operates
throughout Kuwait, and the country is well supplied
with pay telephones
international: coaxial cable and microwave radio relay
to Saudi Arabia; linked to Bahrain, Qatar, UAE via the
Fiber-Optic Gulf (FOG) cable; satellite earth stations -
3 Intelsat (1 Atlantic Ocean, 2 Indian Ocean), 1
Inmarsat (Atlantic Ocean), and 2 Arabsat
Radio broadcast stations: AM 6, FM 1 1 ,
shortwave 1 (1998)
Television broadcast stations: 13 (plus several
satellite channels) (1997)
Internet country code: ,kw
Internet Service Providers (ISPs): 3 (2000)
Internet users: 165,000(2001)
Telephones - main lines in use: 47,000 (1997)
Telephones • mobile cellular: 13,040 (1998)
Telephone system:
general assessment: NA
cfomesf/c:NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 6 (plus 25
low-power repeaters) (1997)
Internet country code: .nc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 24,000(2001)
Telephones - main lines in use: 722,000 (1997)
Telephones • mobile cellular: 1 million (2000)
Telephone system:
general assessment: NA
domestic: 100% digital (2000)
international: NA
Radio broadcast stations: AM 17, FM 160,
shortwave 0(1 998)
Television broadcast stations: 48 (2001)
Internet country code: .si
Internet Service Providers (ISPs): 11 (2000)
Internet users: 600,000(2001)
Telephones - main lines in use: 38,500 (2001)
Telephones - mobile cellular: 45,000 (2001)
Telephone system:
general assessment: a somewhat modern but not an
advanced system
domestic: system consists of carrier-equipped,
open-wire lines and low-capacity, microwave radio
relay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2 plus 4
repeaters, shortwave 3 (2001)
Television broadcast stations: 5 plus 7 relay
stations (2001)
Internet country code: .sz
Internet Service Providers (ISPs): 6 (2001)
Internet users: 6,000 (2001)','b01e58de25f304dbeef4bb191de16bd0570599bd286043ebcb8e832e785ececf','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6552d922eef892d7ca085d5a3811ce1b4c0731182e7d62183005d69037440678',2002,'WF','Wallis and Futuna','communications',474,'Telephones - main lines in use: 34.86 million
(yearend 1998)
Telephones - mobile cellular: 1 1 .078 million
(yearend 1998)
Telephone system:
general assessment: highly developed
domestic: extensive cable and microwave radio relay;
extensive introduction of fiber-optic cable; domestic
satellite system
international: saleWlie earth stations - 2 Intelsat (with
total of 5 antennas - 2 for Indian Ocean and 3 for
Atlantic Ocean), NA Eutelsat, 1 1nmarsat (Atlantic
Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41, FM about 3,500
(this figure is an approximation and includes many
repeaters), shortwave 2 (1998)
Television broadcast stations: 584 (plus 9,676
repeaters) (1995)
Internet country code: .fr
Internet Service Providers (ISPs): 62 (2000)
Internet users: 1 1 .7 million (2001 )','ab12baa417df32f23d60498ea0de6623f2bab9dd34336007a4e405d135eee77b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b774947d0fecd25981048bc0f355ebbadf6dd8e4dc47e84c50597eb9a59a1bd',2002,'PF','French Polynesia','communications',490,'Telephones - main lines in use: 52,000 (1997)
Telephones - mobile cellular: 5,427 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 14,
shortwave 2 (1998)
Television broadcast stations: 7 (plus 17
low-power repeaters) (1 997)
Internet country code: .pf
Internet Service Providers (ISPs): 2 (2000)
internet users: 5,000 (2000)','d616f033d578e3e0663854329ef1915127d9a9696d5eedd0efe6fe3e97ba50d6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5df410f10423526415fc7bb1aa185ab3d27b5fc696b4b638655019e81bd8666d',2002,'GW','Guinea-Bissau','communications',498,'Telephones - main lines in use: 31,900 (2000)
Telephones - mobile cellular: 5,624 (2000)
Telephone system:
general assessment; adequate; a packet switched
data network is available
domestic: adequate network of microwave radio relay
and open wire
international: microwave radio relay links to Senegal
and Guinea-Bissau; satellite earth station • 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2, shortwave 0
(2001)
Television broadcast stations: 1
(government-owned) (1997)
Internet country code: .gm
Internet Service Providers (ISPs): 2 (2001)
Internet users: 5,000(2001)','4d6e6d62bd6ac67b840e20af0ca68b0c459e7040a05de171054efe404dabe697','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd46ec17435bb2b14d066175057a2ae1377715163ef9cdb94478485d4083dc1',2002,'IL','Israel','communications',508,'Telephones - main lines in use: 95,729 (total for
Gaza Strip and West Bank) (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: rudimentary telephone services provided
by an open wire system
international: NA
Radio broadcast stations: AM 0; FM 0, shortwave 0
(1998)
Television broadcast stations: 2 (operated by the
Palestinian Broadcasting Corporation) (1997)
Internet Service Providers (ISPs): 3 (1999)
Internet users: 60,000 (includes West Bank) (2001)','05fc06a4d423fd0854f44dea8239078aa91171ac3144d5661d4a1c8a8d887672','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('301ec9205994e07bdcc1b5058ea49cc90ed79cc696c50a095b98b3197f6df11a',2002,'GE','Georgia','communications',516,'Telephones - main lines in use: 620,000 (1997)
Telephones - mobile cellular: 1 85,500 (2000)
Telephone system:
general assessment: NA
domestic: local - Tbilisi and K''ut''aisi have cellular
telephone networks; urban telephone density is about
20 per 100 people: rural telephone density is about 4
per 100 people; intercity facilities include a fiber-optic
line between Tbilisi and K''ut''aisi; nationwide pager
service is available
194
Georgia (continued)
international: Georgia and Russia are working on a
fiber-optic line between P''ofi and Sochi (Russia);
present international service is available by
microwave, landline , and satellite through the Moscow
switch; international electronic mail and telex service
are available
Radio broadcast stations: AM 7, FM 12,
shortwave 4 (1998)
Television broadcast stations: 12 (plus repeaters)
(1998)
Internet country code: .ge
Internet Service Providers (ISPs): 6 (2000)
Internet users: 20,000 (2000)
Telephones - main lines in use: 50.9 million
(March 2001)
Telephones - mobile cellular: 55.3 million
(June 2001)
Telephone system:
general assessment: Germany has one of the world''s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures
since reunification, the formerly backward system of
the eastern part of the country, dating back to World
War II, has been modernized and integrated with that
of the western part
domestic: Germany is served by an extensive system
of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic satellite
system; cellular telephone service is widely available,
expanding rapidly, and inciudes roaming service to
many foreign countries
international: Germany''s international service is
excellent worldwide, consisting of extensive land and
undersea cable facilities as well as earth stations in
the INMARSAT, INTELSAT, EUTELSAT, and
INTERSPUTNIK satellite systems (2001)
Radio broadcast stations: AM 51 , FM 787,
shortwave 4 (1998)
Television broadcast stations: 373 (plus 8,042
repeaters) (1995)
Internet country code: .de
Internet Service Providers (ISPs): 200 (2001)
Internet users: 28.64 million (2001)
Telephones - main lines in use: 240,000 (2001)
Telephones * mobile cellular: 150,000 (2001)
Telephone system:
general assessment: poor to fair system; Internet
accessible; many rural communities not yet
connected; expansion of services is underway
domestic: primarily microwave radio relay; wireless
local loop has been installed
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); microwave radio relay link to
Panaftel system connects Ghana to its neighbors
Radio broadcast stations: AM 0, FM 49,
shortwave 3 (2001)
Television broadcast stations: 10 (2001)
Internet country code: .gh
Internet Service Providers (ISPs): 12 (2000)
Internet users: 200,000(2002)','2a13c9ac9a59692df5fe24b10e836631080443824d0c1066767067d11060d091','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29780e94e224fd65d756a3800115834d94e22f20b51af55354de70ec942dcc09',2002,'GR','Greece','communications',527,'Telephones • main lines In use: 5.431 million
(1997)
Telephones - mobile cellular: 937,700 (1997)
Telephone system:
general assessment: adequate, modern networks
reach all areas; good mobile telephone and
international service
domestic: microwave radio relay trunk system;
extensive open wire connections; submarine cable to
offshore islands
international: tropospheric scatter; 8 submarine
cables; satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 1ndian Ocean), 1 Eutelsat, and 1
Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 26, FM 88,
shortwave 4 (1998)
Television broadcast stations: 36 (plus 1 ,341
low-power repeaters); also two stations in the US
Armed Forces Radio and Television Service (1 995)
Internet country code: .gr
Internet Service Providers (ISPs): 27 (2000)
Internet users: 1 .33 million (1 999)','d17e1a7c04766c3a8de64686c4ed4854a2e65af38654392bb1e8213f077e78a5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7c108cfd562fa69bc2271a7c4ea47a562c3a7a73183706a05203fd8950a9f99',2002,'GL','Greenland','communications',536,'Telephones - main lines in use: 25,617 (yearend
1999)
Telephones - mobile cellular: 12,676 (yearend
1999)
Telephone system:
general assessment: adequate domestic and
international service provided by satellite, cables and
microwave radio relay; totally digitalized in 1995
domestic: microwave radio relay and satellite
international: satellite earth stations - 12 Intelsat, 1
Eutelsat, 2 Americom GE-2 (all Atlantic Ocean)
Radio broadcast stations: AM 5, FM 12,
shortwave 0 (1998)
Television broadcast stations: 1 publicly-owned
station, some local low-power stations, and three
AFRTS (US Air Force) stations (1997)
Internet country code: ,gl
Internet Service Providers (ISPs): 1 (2000)
Internet users: 17,800(2001)','2d81ed8ed283bc678cef3895264ea9ff95ca0c1901c0d0e9a68fca183c8701f2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaed8950a891af1747f1d67038245cfaffc516d2970b846046e602f51f0c3be3',2002,'GD','Grenada','communications',544,'Telephones - main lines in use: 27,000 (1997)
Telephones - mobile cellular: 976 (1997)
Telephone system:
general assessment: automatic, islandwide telephone
system
domestic: interisland VHF and UHF radiotelephone
links
international: new SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM 13,
shortwave 0(1998)
Television broadcast stations: 2 (1 997)
Internet country code: .gd
Internet Service Providers (ISPs): 14 (2000)
Internet users: 4,100(2001)','ab3f1210aa6ce1228bc90dc52bad9b687cd5a773a079973412ccedd747816623','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c956967677e459f1d06d843f1629704c093e2c68016b35583ab0282ed429e87',2002,'GU','Guam','communications',555,'Telephones - main lines In use: 84,134 (1998)
Telephones - mobile cellular: 55,000 (1998)
Telephone system:
general assessment: modern system, integrated with
US facilities for direct dialing, including free use of 800
numbers
domestic: modern digital system, including cellular
mobile service and local access to the Internet
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
(Guam is a trans-Pac''rfic communications hub for MCI,
Sprint, AT&T, IT&E, and GTE, linking the US and
Asia)
Radio broadcast stations: AM 4, FM 7, shortwave 0
(1998)
Television broadcast stations: 5(1997)
Internet country code: .gu
Internet Service Providers (ISPs): 20 (2000)
Internet users: 5,000 (2000)
Telephones ■ main lines in use: 665,061
(June 2000)
Telephones - mobile cellular: 663,296
(September 2000)
Telephone system:
general assessment: fairly modern network centered
in the city of Guatemala
domestic: NA
international: connected to Central American
Microwave System; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 130, FM 487,
shortwave 15 (2000)
Television broadcast stations: 26 (plus 27
repeaters) (1997)
215
Guatemala (continued)
Internet country code: .gt
Internet Service Providers (ISPs): 5(2000)
Internet users: 65,000(2000)','1763a4a9faa830441cd998f4d754656d6b78ea163c48255a547f9f373d82fc60','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aaa0c7b6785a2f142184b88d1d03d8b3edab8a90b25914607621947daca7c82',2002,'GG','Guernsey','communications',564,'Telephones - main lines in use: 44,000 (1996)
Telephones • mobile cellular: 12,000(1997)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM1.FM1, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .gg
Internet Service Providers (ISPs): NA
Internet users: NA
217
Guernsey (continued)
Telephones • main lines in use: 37,000 (1998)
Telephones - mobile cellular: 21 ,567 (1998)
Telephone system:
general assessment: poor to fair system of open-wire
lines, small radiotelephone communication stations,
and new microwave radio relay system
domestic: microwave radio relay and radiotelephone
communication
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 4 (one station is
inactive), FM 1 (plus 7 repeaters), shortwave 3 (2001)
Television broadcast stations: 1 (2001)
Internet country code: .gn
Internet Service Providers (ISPs): 4 (2001)
Internet users: 8,000 (2000)','96a212486f44ad9206b449eee63c9536ac4195d3652daedc4dd4301b71784292','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43f5f9d4ade381a041901992a7f16cb165bde58d77dd2ac6196d7772d938d498',2002,'GY','Guyana','communications',573,'Telephones - main lines in use: 70,000 (2000)
Telephones - mobile cellular: 6,100 (2000)
Telephone system:
general assessment: fair system for long-distance
calling
domestic: microwave radio relay network for trunk
lines
international: troposphere scatter to Trinidad; satellite
earth station • 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3, shortwave 1
(1998)
Television broadcast stations: 3 (one public
station; two private stations which relay US satellite
services) (1997)
Internet country code; .gy
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,000 (2000)
Telephones - main lines in use: 64,000 (1997)
Telephones • mobile cellular: 4,090 (1997)
Telephone system:
general assessment: international facilities are good
domestic: microwave radio relay network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 13,
shortwave 1 (1998)
Television broadcast stations: 3 (plus seven
repeaters) (2000)
Internet country code: .sr
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 1 ,700 (2001)
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: probably adequate
domestic: local telephone service
international: satellite earth station - 1 of unknown
type (for communication with Norwegian mainland
only)
(territory of Norway)
Arctic .,>. Ocean Kvitoya
f ""H X rda/sttandet
Forland y \\ J* , V / SjBarentsgya
Barentsbu^^NGYEA^N
a^iocrf-^f J J^JZdgeoya
reenfand Us
Sea \\
Barents
Sea
* Hopen
Norwegian
g£>a 0 50 100 km
Bjomoya -
0','6bd606c13b97603028d07a39898f7cd70dc0c876669f9b5f3e4226ebfee7bd27','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59215affbd8366b7bf4a861c5be0b1f7ea7fdf98adb1fa4413547a6b65ebda1a',2002,'HT','Haiti','communications',583,'Telephones - main lines in use: 60,000 (1997)
Telephones - mobile cellular: 0 (1 995)
Telephone system:
general assessment: domestic facilities barely
adequate; international facilities slightly better
domestic: coaxial cable and microwave radio relay
trunk service
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 41 , FM 26,
shortwave 0(1 999)
Television broadcast stations: 2 (plus a cable TV
service) (1997)
Internet country code: .ht
Internet Service Providers (ISPs): 3 (2000)
Internet users: 6,000 (2000)','fc3db54657c57e254cbd215a0a9eca699e7c97115991c5681da3692a4889be4d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e98c9fc97b0add093e939a94aa4ace6a73c4cfe5d44537e0e0c4c076c513fa31',2002,'IS','Iceland','communications',598,'Telephones - main lines in use: 168,000 (1997)
Telephones - mobile cellular: 65,746 (1997)
Telephone system:
general assessment: adequate domestic service
domestic: the trunk network consists of coaxial and
fiber-optic cables and microwave radio relay links
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean), 1 1nmarsat (Atlantic and Indian
Ocean regions); note - Iceland shares the Inmarsat
earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM about 70
(including repeaters), shortwave 1 (1998)
Television broadcast stations: 14 (plus 156
low-power repeaters) (1997)
Internet country code: .is
Internet Service Providers (ISPs): 7 (2000)
Internet users: 168,000(2001)
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: there is one radio and meteorological station
(1998)
Internet Service Providers (ISPs): 13 (Jan Mayen
and Svalbard) (2000)','1ae888f6ee97f43d0a4ed18046a0d939433deb386c58080be31c79820a36f65d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f17e7a56f2c3239f969be5752bba93b673e0062ae3cda4715b08f7ecf1a21454',2002,'IN','India','communications',606,'Telephones • main lines in use: 27.7 million
(October 2000)
Telephones - mobile cellular: 2.93 million
(November 2000)
Telephone system:
general assessment: mediocre service; local and long
distance service provided throughout all regions of the
country, with services primarily concentrated in the
urban areas; major objective is to continue to expand
and modernize long-distance network to keep pace
with rapidly growing number of local subscriber lines;
steady improvement is taking place with the recent
admission of private and private-public investors, but,
with telephone density at about two for each 1 00
persons and a waiting list of over 2 million, demand for
main line telephone service will not be satisfied for a
very long time
domestic: local service is provided by microwave
radio relay and coaxial cable, with open wire and
obsolete electromechanical and manual switchboard
systems still in use in rural areas; starting in the 1 980s,
a substantial amount of digital switch gear has been
introduced for local and long-distance service;
long-distance traffic is carried mostly by coaxial cable
and low-capacity microwave radio relay; since 1985
significant trunk capacity has been added in the form
of fiber-optic cable and a domestic satellite system
with 254 earth stations; mobile cellular service is
provided in four metropolitan cities
international: satellite earth stations • 8 Intelsat (Indian
Ocean) and 1 1nmarsat (Indian Ocean region); nine
gateway exchanges operating from Mumbai
(Bombay), New Delhi, Kolkata (Calcutta), Chennai
(Madras), Jalandhar, Kanpur, Gaidhinagar,
Hyderabad, and Ernakulam; 4 submarine cables -
LOCOM linking Chennai (Madras) to Penang;
Indo-UAE-Gulf cable linking Mumbai (Bombay) to Al
Fujayrah, UAE; lndia-SEA-ME-WE-3, SEA-ME-WE-2
with landing sites at Cochin and Mumbai (Bombay);
Fiber-Optic Link Around the Globe (FLAG) with
landing site at Mumbai (Bombay) (2000)
Radio broadcast stations: AM 153, FM 91,
shortwave 66(1998)
Television broadcast stations: 562 (of which 82
stations have 1 kW or greater power and 480 stations
have less than 1 kW of power) (1997)
Internet country code: .in
Internet Service Providers (ISPs): 43 (2000)
Internet users: 5 million (2001)','8dbeef14fa7074c66310cb62546a073e5c55356be70773ac88adf5d632f3504c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cbdf59d311956eda86276de558099c5609373ce140c5bfbf08eb6a131c8fea4',2002,'IE','Ireland','communications',615,'Telephones - main lines in use: 1 .59 million (2001)
Telephones - mobile cellular: 2 million (2001)
Telephone system:
general assessment: modern digital system using
cable and microwave radio relay
domestic: microwave radio relay
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 9, FM 106,
shortwave 0 (1998)
Television broadcast stations: 4 (many low-power
repeaters) (2001)
Internet country code: .ie
Internet Service Providers (ISPs): 22 (2000)
Internet users: 1.25 million (2001)','e9f58e906ccf293916206a9c0efe96769a0be3b6844455a95ddf272f52cbc99a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0dcdf774d8fb533585645d5c5b230657ba339cf83be0e17a2e5ebf78f428b0e',2002,'TN','Tunisia','communications',625,'Telephones - main lines in use: 25 million (1999)
Telephones - mobile cellular: 20.5 million (1999)
Telephone system:
general assessment: modern, well developed, fast;
fully automated telephone, telex, and data services
domestic: high-capacity cable and microwave radio
relay trunks
international: satellite earth stations - 3 Intelsat (with a
total of 5 antennas - 3 for Atlantic Ocean and 2 for
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and NA Eutelsat; 21 submarine cables
Radio broadcast stations: AM about 100, FM
about 4,600, shortwave 9 (1998)
Television broadcast stations: 358 (plus 4,728
repeaters) (1995)
Internet country code: .it
Internet Service Providers (ISPs): 93 (Italy and
Holy See) (2000)
Internet users: 19.25 million (2001)
Telephones - main lines in use: 654,000 (1997)
Telephones • mobile cellular: 50,000 (1998)
Telephone system:
general assessment: above the African average and
continuing to be upgraded; key centers are Sfax,
Sousse, Bizerte, and Tunis; Internet access available
domestic: trunk facilities consist of open-wire lines,
coaxial cable, and microwave radio relay
international: 5 submarine cables; satellite earth
stations - 1 1ntelsat (Atlantic Ocean) and 1 Arabsat;
coaxial cable and microwave radio relay to Algeria
and Libya; participant in Medarabtel; two international
gateway digital switches
Radio broadcast stations: AM 7, FM 20,
shortwave 2 (1998)
Television broadcast stations: 26 (plus 76
repeaters) (1995)
Internet country code: .tn
internet Service Providers (ISPs): 1 (2000)
Internet users: 280,000(2001)
Telephones - main lines in use: 19.5 million (1999)
Telephones - mobile cellular: 17.1 million (2001)
Telephone system:
general assessment: undergoing rapid modernization
and expansion, especially with cellular telephones
domestic: additional digital exchanges are permitting
a rapid increase in subscribers; the construction of a
network of technologically advanced intercity trunk
lines, using both fiber-optic cable and digital
microwave radio relay is facilitating communication
between urban centers; remote areas are reached by
a domestic satellite system; the number of
subscribers to mobile cellular telephone service is
growing rapidly
international: international service is provided by three
submarine fiber-optic cables in the Mediterranean and
Black Seas, linking Turkey with Italy, Greece, Israel,
Bulgaria, Romania, and Russia; also by 12 Intelsat
earth stations, and by 328 mobile satellite terminals in
the Inmarsat and Eutelsat systems (2002)
Radio broadcast stations: AM 16, FM 107,
shortwave 6 (2001)
Television broadcast stations: 635 (plus 2,934
repeaters) (1995)
Internet country code: .tr
Internet Service Providers (ISPs): 50 (2001 )
Internet users: 4 million (2001)','1ff9eef78c11afa88cd7b87ab9130ab5729d3da1755ff1815984690e669cf011','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('165aa6cbf7d428879f2b789ba65f7e3351bfdd60f71585c956b69e2adb3bc95d',2002,'JM','Jamaica','communications',635,'Telephones - main lines in use: 353,000 (1996)
Telephones - mobile cellular: 54,640 (1 996)
Telephone system:
general assessment: fully automatic domestic
telephone network
domestic: UA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 1 0, FM 1 3,
shortwave 0(1998)
Television broadcast stations: 7 (1997)
Internet country code: .jm
Internet Service Providers (ISPs): 21 (2000)
Internet users: 60,000 (2000)','2d24dc928f6aff0277c8fd05a0a16c86b3bb24bae46b11a9777fac17dc380da6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b48bf8ef8185097fd00d5e8605d8a2061eea40959abe6daf24c3dcfdbc843c70',2002,'NO','Norway','communications',643,'Telephones - main lines in use: 60.381 million
(1997)
Telephones - mobile cellular: 63.88 million (2000)
Telephone system:
general assessment: excellent domestic and
international service
domestic: high level of modern technology and
excellent service of every kind
International: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Indian Ocean region), and 1 1nmarsat (Pacific and
Indian Ocean regions); submarine cables to China,
Philippines, Russia, and US (via Guam) (1999)
Radio broadcast stations: AM 215 plus 370
repeaters, FM 89 plus 485 repeaters, shortwave 21
(2001)
Television broadcast stations: 21 1 plus 7,341
repeaters
nofe: in addition, US Forces are served by 3 TV
stations and 2 TV cable services (1999)
Internet country code: .jp
internet Service Providers (ISPs): 73 (2000)
Internet users: 47.08 million (2001)','8f020868fb775fd68fc3391b09edb01cdf3abfe3eee1c5e389d04d420f083e13','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4aab40c03d6058c02e941e46493246383fae31ab1f7d1c7690a69db6f9a80f0',2002,'MH','Marshall Islands','communications',650,'Telephone system:
general assessment: 13 outgoing and 10 incoming
commercial lines; adequate telecommunications
domestic: 60-channel submarine cable (broken in
January 2002), 22 DSN circuits by satellite, Autodin
with standard remote terminal, digital telephone
switch, Military Affiliated Radio System (MARS
station), UHFA/HF air-ground radio, a link to the
Pacific Consolidated Telecommunications Network
(PCTN) satellite
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Television broadcast stations: commercial
satellite television system, with 16 channels (1997)
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 4,186 (2001)
Telephones - mobile cellular: 489 (2001)
Telephone system:
general assessment: digital switching equipment;
modern services include telex, cellular, internet,
international calling, caller ID, and leased data circuits
domestic: Majuro Atoll and Ebeye and Kwajalein
islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
intematbnal: satellite earth stations - 2 Intelsat
(Pacific Ocean); US Government satellite
communications system on Kwajalein (2001)
Radio broadcast stations: AM 2, FM 1 , shortwave 0
note: additionally, the US Armed Forces Radio and
Television Services (Central Pacific Network) operate
one FM and one AM station on Kwajalein (2002)
Television broadcast stations: 2 (both are US
military stations) (2002)
331
Marshall Islands (continued)
Internet country code: .mh
Internet Service Providers (ISPs): 1 (2002)
Internet users: 537(2001)','95bed7c7346459f94d99ca01f5c385777907a099605f539208fdab581fd08293','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4693b3a58f2d52387709249ee7cc7d8ae0c75c413127e91254fbcb49def34d1',2002,'KZ','Kazakhstan','communications',662,'Telephones ■ main lines in use: 1 .92 million (2001)
Telephones - mobile cellular: 400,000 (2001)
Telephone system:
general assessment: service is poor; equipment
antiquated
domestic: intercity by landline and microwave radio
relay; mobile cellular systems are available in most of
international: international traffic with other former
Soviet republics and China carried by landline and
microwave radio relay; with other countries by satellite
and by the Trans-Asia-Europe (TAE) fiber-optic cable;
satellite earth stations - 2 Intelsat
Radio broadcast stations: AM 60, FM 17,
shortwave 9 (1998)
Television broadcast stations: 12 (plus nine
repeaters) (1998)
Internet country code: .kz
Internet Service Providers (ISPs): 10 (with their
own international channels) (2001)
Internet users: 85,000 (2001 )
Telephones - main lines in use: 310,000 (2001)
Telephones - mobile cellular: 540,000 (2001)
Telephone system:
general assessment: unreliable; little attempt to
modernize except for service to business
domestic: trunks are primarily microwave radio relay;
business data commonly transferred by a very small
aperture terminal (VSAT) system
international: satellite earth stations - 4 Intelsat
Radio broadcast stations: AM 24, FM 18,
shortwave 6 (2001)
Television broadcast stations: 8 (2002)
276
Kenya (continued)
Internet country code: .ke
Internet Service Providers (ISPs): 65 (2001)
Internet users: 250,000(2001)','42d711c419d5dfa02c34af3493645dfbda9256b56aa6cdd28b3a2153dfd66455','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('125d926b1ac32375464c9258af238280a05912b782e041ec5cb5c7cb35203077',2002,'KI','Kiribati','communications',672,'Telephones - main lines in use: 3,800 (1999)
Telephones -mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
note: Kiribati is being linked to the Pacific Ocean
Cooperative Telecommunications Network, which
should improve telephone service
Radio broadcast stations: AM 1 , FM 1 . shortwave 1
nofe;the FM and shortwave stations may be inactive
(2002)
Television broadcast stations: 1 (not reported to
be active) (2002)
Internet country code: .ki
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,000(2000)
Telephones * main lines in use: 1.1 million (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) and 1 Russian (Indian Ocean region); other
international connections through Moscow and Beijing
Radio broadcast stations: AM 16, FM 14,
shortwave 12 (1999)
Television broadcast stations: 38 (1999)
Internet country code: .kp
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 24 million (2000)
Telephones - mobile cellular: 28 million
(September 2000)
Telephone system:
general assessment: excellent domestic and -
international services
domestic: NA
international: fiber-optic submarine cable to China; the
Russia-Korea-Japan submarine cable; satellite earth
stations - 3 Intelsat (2 Pacific Ocean and 1 1ndian
Ocean) and 1 1nmarsat (Pacific Ocean region)
Radio broadcast stations: AM 104, FM 136,
shortwave 5 (2001)
Television broadcast stations: 121 (plus 850
repeater stations and the eight-channel American
Forces Korea Network) (1999)
Internet country code: .kr
Internet Service Providers (ISPs): 1 1 (2000)
Internet users: 22.23 million (2001)','9945e3147b6e3e344eb011246430502f6e70b2975f4f14f1c14581d6a9a87839','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73c590d556cc38e8ae1e221be0150397b0fd2868450608b726e08a53554cc23c',2002,'LV','Latvia','communications',684,'Telephones - main lines in use: 734,693 (2000)
Telephones - mobile cellular: 401,263 (2000)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an international capability
independent of the Moscow international switch; more
facilities are being installed for individual use
domestic: expansion underway in intercity trunk line
connections, rural exchanges, and mobile systems;
still many unsatisfied subscriber applications
international: international connections are now
available via cable and a satellite earth station at Riga,
enabling direct connections for most calls (1998)
Radio broadcast stations: AM 8, FM 56,
shortwave 1 (1998)
293
Latvia (continued)
Television broadcast stations: 44 (plus 31
repeaters) (1995)
Internet country code: .(v
Internet Service Providers (iSPs): 41 (2001)
Internet users: 310,000(2001)
Telephones - main lines in use: 700,000 (1999)
Telephones - mobile cellular: 580,000 (1999)
Telephone system:
general assessment: telecommunications system
severely damaged by civil war; rebuilding well
underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean) (erratic
operations); coaxial cable to Syria; microwave radio
relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 20, FM 22,
shortwave 4 (1998)
Television broadcast stations: 15 (plus 5
repeaters) (1995)
Internet country code: .lb
Internet Service Providers (ISPs): 22 (2000)
Internet users: 300,000 (2001 )','ab2a3f8a196a04659e6b028138affd951c041fa905fca79b76348a3811b89572','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dec62a6ec9d3c3d1e82c379b6dd3630917da16b94472b6623456e0f9d195a12a',2002,'ZA','South Africa','communications',688,'Telephones - main lines in use: 22,200 (2000)
Telephones - mobile cellular: 21,600 (2000)
Telephone system:
general assessment: rudimentary system
domestic: consists of a few landlines, a small
microwave radio relay system, and a minor
radiotelephone communication system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM1.FM 2, shortwave 1
(1998)
Television broadcast stations: 1 (2000)
Internet country code: .Is
Internet Service Providers (ISPs): 1 (2000)
Internet users: 4,000 (2000)
Telephones - main lines in use: 6,700 (2000)
Telephones - mobile cellular: 0 (1998)
Telephone system:
general assessment: telephone and telegraph service
via microwave radio relay network; main center is
Monrovia
domestic: Hk
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 0, FM 7, shortwave 2
(2001)
Television broadcast stations: 1 (plus four
low-power repeaters) (2001)
Internet country code: Jr
Internet Service Providers (ISPs): 2(2001)
Internet users: 500(2000)
Telephones - main lines in use: 380,000 (1996)
Telephones -mobile cellular: NA
Telephone system:
general assessment: telecommunications system is
being modernized; mobile cellular telephone system
became operational in 1996
302
Libya (continued)
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international; satellite earth stations - 4 Intelsat,
NA Arabsat, and NA Intersputntk; submarine cables to
France and Italy; microwave radio relay to Tunisia and
Egypt; tropospheric scatter to Greece; participant in
Medarabtel (1999)
Radio broadcast stations: AM 17, FM 4,
shortwave 3 (1998)
Television broadcast stations: 12 (plus one
low-power repeater) (1998)
Internet country code: Jy
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000(2001)','3e1df7736dd8b847d563f540215c0bb36dc9c254815b8c65412598bf62516773','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('390eb7c270e56f2119ed2b0a09626e1d3a1e6a35351c1735c4f9af6f76ed0828',2002,'LI','Liechtenstein','communications',702,'Telephones - main lines in use: 20,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic telephone system
domestic: HA
international: linked to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: AM 0, FM 4, shortwave 0
(1998)
Television broadcast stations: NA (linked to Swiss
networks) (1997)
Internet country code: .li
Internet Service Providers (ISPs): 44
(Liechtenstein and Switzerland) (2000)
Internet users: NA','851953006a7da6c2030d129b542b883d782308f98c6e0a197f397b4ae1c34884','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10123e88d8c9a9e59d45cd75c6fb5852ebc72143fad71a63c79f25b5cfc33d5e',2002,'CH','Switzerland','communications',707,'Telephones - main lines in use: 1 .142 million
(2001)
Telephones - mobile cellular: 500,000 (2001)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an improved international
capability and better residential access
domestic: a national, fiber-optic cable, interurban, trunk
system is nearing completion; rural exchanges are
being improved and expanded; mobile cellular systems
are being installed; access to the Internet is available;
still many unsatisfied telephone subscriber applications
international: landline connections to Latvia and
Poland; major international connections to Denmark,
Sweden, and Norway by submarine cable for further
transmission by satellite
Radio broadcast stations: AM 29, FM 142,
shortwave 1 (2001)
Television broadcast stations: 27
note: Lithuania has approximately 27 broadcasting
stations, but may have as many as 100 transmitters,
including repeater stations (2001)
Internet country code: .it
Internet Service Providers (ISPs): 32 (2001 )
Internet users: 341,000(2001)','47b70788c1ab440e3f14c7564fbc08d81184529fa506758a1232480e8d0864a3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88eef6d9a4d7ded024cccd778aa7bee338d8153d3af4d88904f4bf5bbb103fff',2002,'DE','Germany','communications',714,'Telephones - main lines in use: 314,700 (1999)
Telephones -mobile cellular: 215,741 (2000)
Telephone system:
generai assessment: highly developed, completely
automated and efficient system, mainly buried cables
domestic: nationwide cellular telephone system;
buried cable
international: 3 channels leased on TAT-6 coaxial
submarine cable (Europe to North America)
Radio broadcast stations: AM 2, FM 9, shortwave 2
(1999)
Television broadcast stations: 5 (1999)
Internet country code: .iu
Internet Service Providers (ISPs): 8 (2000)
Internet users: 100,000(2001)','c106042af5e3db67322d817945d4977868645b588a68f15518e9358cd2d1b758','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27147effb3fd506c176103d2bce8b4f025cd7981f3e3b1333990d2f434f78535',2002,'YT','Mayotte','communications',724,'Telephones - main lines in use: 55,000 (2000)
Telephones - mobile cellular: 63,1 00 (2000)
Telephone system:
general assessment: system is above average for the
region
domestic: open-wire lines, coaxial cables, microwave
radio relay, and tropospheric scatter links connect
regions
international: submarine cable to Bahrain; satellite
earth stations - 1 1ntelsat (Indian Ocean) and 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 2 (plus a number of
repeater stations), FM 9, shortwave 6 (2001)
Television broadcast stations: 1 (plus 36
repeaters) (2001)
Internet country code: ,mg
Internet Service Providers (ISPs): 2 (2000)
Internet users: 30,000 (2000)
Telephones - main lines in use: 38,000 (1999)
Telephones - mobile cellular: 49,000 (2000)
Telephone system:
general assessment: NA
domestic: system employs open-wire lines,
microwave radio relay links, and radiotelephone
communications stations
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 9, FM 5 (plus 15
repeater stations), shortwave 2 (plus a third station
held in standby status) (2001)
Television broadcast stations: 1 (2001)
Internet country code: .mw
Internet Service Providers (ISPs): 7 (2001 )
Internet users: 15,000(2000)
Telephones - main lines in use: 9,314 (1997)
Telephones - mobile cellular: 0 (2000)
Telephone system:
general assessment: small system administered by
French Department of Posts and Telecommunications
domestic: Hk
international: microwave radio relay and HF
radiotelephone communications to Comoros (2001 )
339
Mayotte (continued)','c0152ba8a189e88d31a277d447b5578c3d22caa23714405292aba97312f168e9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('088cd2b5b52bfe934110f39efdd257bf7c5051fa6a7e91f3d611a5a67ae48747',2002,'MV','Maldives','communications',733,'Telephones - main lines in use: 21,000 (1999)
Telephones - mobile cellular: 1 ,290 (1 997)
Telephone system:
general assessment: minimal domestic and
international facilities
domestic: interatoll communication through
microwave links; all inhabited islands are connected
with telephone and fax service
international: satellite earth station - 3 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave 1
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .mv
Internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000 (2001)
Telephones - main lines in use: 45,000 (2000)
Telephones - mobile cellular: 40,000 (2001)
Telephone system:
general assessment: domestic system unreliable but
improving; provides only minimal service
domestic: network consists of microwave radio relay,
open wire, and radiotelephone communications
stations; expansion of microwave radio relay in
progress
international: satellite earth stations * 2 Intelsat
(1 Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 1, FM 28,
shortwave 1
note: the shortwave station in Bamako has seven
frequencies and five transmitters and relays
broadcasts for China Radio International (2001)
Television broadcast stations: 1 (plus repeaters)
(2001)
Internet country code: .mi
Internet Service Providers (ISPs): 13 (2001 )
Internet users: 10,000(2000)','29a2d91c4549f653d9559d2e114b3415b44d4d39d7399f09f9769eb0a6f97d47','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1df9b3290a99ba061bde43a147baf09b0608ee507a904b2b7b9e6b11e5d3c71',2002,'MT','Malta','communications',742,'Telephones - main lines in use: 187,000 (1997)
Telephones - mobile cellular: 17,691 (1997)
Telephone system:
general assessment: automatic system satisfies
normal requirements
domestic: submarine cable and microwave radio relay
between islands
international: 2 submarine cables; satellite earth
station • 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 18,
shortwave 6 (1999)
Television broadcast stations: 6 (2000)
Internet country code: .mt
Internet Service Providers (ISPs): 2 (2000)
Internet users: 40,000 (2000)
Telephones - main lines in use: 51 ,000 (1 999)
Telephones - mobile cellular: NA
Telephone system:
general assessment: HA
domestic: landline, telefax, mobile cellular telephone
system
international: fiber-optic cable, microwave radio relay,
satellite earth station, submarine cable
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
329
Man, Isle Of (continued)
Television broadcast stations: 0 (receives
broadcasts from the UK and satellite) (1999)
Internet country code: .im
Internet Service Providers (ISPs): NA
Internet users: NA','f9f9aafbf5b685e6be25cfe5b7a82253eea804ab505ed8485dede7a7aea11f06','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37635d9b1a1f8ad6e600ed2a11def1289d01975a7192e77d42336bb209735df6',2002,'MR','Mauritania','communications',755,'Telephones - main lines in use: 26,500 (2001)
Telephones - mobile cellular: 35f000 (2001)
Telephone system:
general assessment: limited system of cable and
open-wire lines, minor microwave radio relay links,
and radiotelephone communications stations
(improvements being made)
domestic: mostly cable and open-wire lines; a recently
completed domestic satellite telecommunications
system links Nouakchott with regional capitals
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 2 Arabsat
Radio broadcast stations: AM 1, FM 14,
shortwave 1 (2001)
Television broadcast stations: 1 (2002)
Internet country code: .mr
Internet Service Providers (ISPs): 5 (2001 )
Internet users: 7,500(2001)','e1846059433b870e68be447d536571c3abec91d85957b3c41c4cec4a057b3cf2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc40b1b3769b91261cf473a8f58bdf20722564e0f9305ef957b4fcaae3bd2c2a',2002,'MU','Mauritius','communications',765,'Telephones • main lines in use: 245,000 (1998)
Telephones - mobile cellular: 60,482 (1998)
Telephone system:
general assessment: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean); new microwave link to Reunion; HF
radiotelephone links to several countries
Radio broadcast stations: AM 5, FM 9, shortwave 2
(1998)
Television broadcast stations: 2 (plus several
repeaters) (1997)
internet country code: .mu
Internet Service Providers (ISPs): 2 (2000)
Internet users: 87,000(2001)','c3958be9c1500393c66d724a5d68c1f34a176941da547cba787a35c968b19cc1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2032e3fe9eb8499ae76847e634703da4c5d0aa10b35ef05be63957dca9b18632',2002,'MX','Mexico','communications',768,'Radio broadcast stations: AM 1 , FM 5, shortwave 0
(2001)
Television broadcast stations: 3 (2001)
internet country code: .yt
internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 12.332 million
(2000)
Telephones - mobile cellular: 2.02 million (1 998)
Telephone system:
general assessment: low telephone density with
about 12 main lines per 100 persons; privatized in
December 1990; the opening to competition in
January 1997 improved prospects for development
domestic: adequate telephone service for business
and government, but the population is poorly served;
domestic satellite system with 120 earth stations;
extensive microwave radio relay network;
considerable use of fiber-optic cable, coaxial cable,
and mobile cellular service
international: satellite earth stations ■ 32 Intelsat, 2
Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well
as enhancing domestic communications), numerous
Inmarsat mobile earth stations; linked to Central
American Microwave System of trunk connections;
high capacity Columbus-2 fiber-optic submarine cable
with access to the US, Virgin Islands, Canary Islands,
Morocco, Spain, and Italy (1997)
Radio broadcast stations: AM 851, FM 598,
shortwave 16 (2000)
Television broadcast stations: 236 (plus
repeaters) (1997)
Internet country code: .mx
Internet Service Providers (ISPs): 51 (2000)
Internet users: 3.42 million (2001)
Telephones • main lines in use: 8.07 million (1998)
Telephones * mobile cellular: 1.78 million (1998)
Telephone system:
general assessment: underdeveloped and outmoded
system; government aimed to have 10 million
telephones in service by 2000; the process of partial
privatization of the state-owned telephone monopoly
has begun; in 1998 there were over 2 million
applicants on the waiting list for telephone service
domestic: cable, open wire, and microwave radio
relay; 3 cellular networks; local exchanges 56.6%
digital
international: satellite earth stations - 2 Intelsat,
NA Eutelsat, 2 Inmarsat (Atlantic and Indian Ocean
regions), and 1 1ntersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 14, FM 777,
shortwave 1 (1998)
Television broadcast stations: 179 (plus 256
repeaters) (September 1995)
Internet country code: .pi
Internet Service Providers (ISPs): 19 (2000)
Internet users: 3.5 million (2001 )','32800666b962d8f848d8c4c0a34d9fc0b610265f8890d6832a37f429cc8404db','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c52664ba34409362f1bd0715d2ae3663dcae4c2e25b73dc82d8b8c6e1f2359e3',2002,'UA','Ukraine','communications',791,'Telephones - main lines in use: 627,000 (1997)
Telephones • mobile cellular: 2,200 (1997)
Telephone system:
general assessment: inadequate, outmoded, poor
service outside Chisinau, some effort to modernize is
under way
domestic: new subscribers face long wait for service;
mobile cellular telephone service being introduced
international: service through Romania and Russia via
landline; satellite earth stations - Intelsat, Eutelsat,
and Intersputnik
Radio broadcast stations: AM 7, FM 50,
shortwave 3 (1998)
Television broadcast stations: 1 (plus 30
repeaters) (1995)
Internet country code: .md
Internet Service Providers (ISPs): 2 (1999)
Internet users: 15,000(2000)
Telephones - main lines In use: 3.777 million
(1997)
Telephones - mobile cellular: 645,500 (1999)
Telephone system:
general assessment: poor domestic service, but
improving
domestic: 90% of telephone network is automatic;
trunk network is mostly microwave radio relay, with
some fiber-optic cable; about one-third of exchange
capacity is digital; roughly 3,300 villages have no
service
international: satellite earth station • 1 1ntelsat; new
digital, international, direct-dial exchanges operate in
Bucharest; note - Romania is an active participant in
several international telecommunication network
projects (1999)
Radio broadcast stations: AM 40, FM 202,
shortwave 3 (1998)
Television broadcast stations: 48 (plus 392
repeaters) (1995)
Internet country code: .ro
Internet Service Providers (ISPs): 38 (2000)
Internet users: 800,000(2001)
Telephones • main lines in use: 30 million (1998)
Telephones - mobile cellular: 2.5 million
(October 2000)
Telephone system:
genera! assessment: the telephone system has
undergone significant changes in the 1990s; there are
more than 1 ,000 companies licensed to offer
communication services; access to digital lines has
improved, particularly in urban centers; Internet and
e-mail services are improving; Russia has made
progress toward building the telecommunications
infrastructure necessary for a market economy;
however, a large demand for main line service
remains unsatisfied
domestic: cross-country digital trunk lines run from
Saint Petersburg to Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in 60 regional
capitals have modem digital infrastructures; cellular
services, both analog and digital, are available in
many areas; in rural areas, the telephone services are
still outdated, inadequate, and low density
international: Russia is connected internationally by
three undersea fiber-optic cables; digital switches in
several cities provide more than 50,000 lines for
international calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat, Inmarsat,
and Orbita systems
Radio broadcast stations: AM 420, FM 447,
shortwave 56 (1998)
Television broadcast stations: 7,306 (1998)
Internet country code: .ru
internet Service Providers (ISPs): 35 (2000)
internet users: 9.2 million (2000)
Telephones - main lines in use: 1 1 ,000 (1999)
Telephones - mobile cellular: 1 1 ,000 (1 999)
note: Rwanda has mobile cellular service between
Kigali and several prefecture capitals (2002)
Telephone system:
general assessment: telephone system primarily
serves business and government
domestic; the capital, Kigali, is connected to the
centers of the prefectures by microwave radio relay
and, recently, by cellular telephone service; much of
the network depends on wire and HF radiotelephone
international: international connections employ
microwave radio relay to neighboring countries and
satellite communications to more distant countries;
satellite earth stations * 1 1ntelsat (Indian Ocean) in
Kigali (includes telex and telefax service)
Radio broadcast stations: AM 0, FM 3 (two main
FM programs are broadcast through a system of
repeaters and the third FM program is a 24 hour BBC
program), shortwave 1 (2002)
Television broadcast stations: NA
Internet country code: .rw
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000(2001)
Telephones - main lines in use: 9.45 million
(April 1999)
Telephones - mobile cellular: 236,000 (1998)
Telephone system:
general assessment: Ukraine''s telecommunication
development plan, running through 2005, emphasizes
improving domestic trunk lines, international
connections, and the mobile cellular system
domestic: at independence in December 1991 ,
Ukraine inherited a telephone system that was
antiquated, inefficient, and in disrepair; more than 3.5
million applications for telephones could not be
satisfied; telephone density is now rising slowly and
the domestic trunk system is being improved; the
mobile cellular telephone system is expanding at a
high rate
international: two new domestic trunk lines are a part
of the fiber-optic Trans-Asia-Europe (TAE) system
and three Ukrainian links have been installed in the
fiber-optic Trans-European Lines (TEL) project which
connects 18 countries; additional international service
is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in
the Intelsat, Inmarsat, and Intersputnik satellite
systems
Radio broadcast stations: AM 134, FM 289,
shortwave 4 (1998)
Television broadcast stations: at least 33 (plus 21
repeaters that relay broadcasts from Russia) (1997)
Internet country code: .ua
Internet Service Providers (ISPs): 260 (2001 )
Internet users: 750,000 (2001)','545b0997a28a0f1525dec8279e23efe6e768069df64fde6d962b5ea81f8d61aa','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48c5abc2b3b8037e63910d6d71d34d6f1e2475d53bee237cb86dde6eb695588',2002,'MC','Monaco','communications',799,'Telephones - main lines in use: 31 ,027 (1 995)
Telephones • mobile cellular: NA
Telephone system:
genera! assessment: modern automatic telephone
system
domestic: NA
international: no satellite earth stations; connected by
cable into the French communications system
Radio broadcast stations: AM 1, FM NA,
shortwave 8 (1998)
Television broadcast stations: 5 (1998)
Internet country code: .mc
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','a749e860c30f21fedc2e3eaccd2aefd88aa1d9d45f6658ab8e448c1e567e8716','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe4030cf081b22e36c7bc815eb29e7148ee1987c46ac68406232ae3409056e9',2002,'GI','Gibraltar','communications',805,'Telephones - main lines in use: 1.391 million
(1998)
Telephones - mobile cellular: 116,645 (1998)
Telephone system:
general assessment: modern system with all
important capabilities; however density is low with
only 4.6 main lines available for each 100 persons
domestic: good system composed of open-wire lines,
cables, and microwave radio relay links; Internet
available but expensive; principal switching centers
are Casablanca and Rabat; national network nearly
100% digital using fiber-optic links; improved rural
service employs microwave radio relay
international: 7 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain, and
Western Sahara: coaxial cable and microwave radio
relay to Algeria; participant in Medarabtel; fiber-optic
cable link from Agadir to Algeria and Tunisia (1998)
Radio broadcast stations: AM 27, FM 25,
shortwave 6 (1998)
Television broadcast stations: 35 (plus 66
repeaters) (1995)
Internet country code: .ma
Internet Service Providers (ISPs): 8 (2000)
Internet users: 220,000(2001)
Telephones - main lines in use: 90,000
(December 2001)
Telephones - mobile cellular: 100,000 (June 2001 )
Telephone system:
general assessment: fair system but not available
generally (telephone density is only 3.5 telephones for
each 1,000 persons)
domestic: the system consists of open-wire lines and
trunk connection by microwave radio relay and
tropospheric scatter
international: satellite earth stations - 5 Intelsat
(2 Atlantic Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 13, FM 17,
shortwave 11 (2001)
Television broadcast stations: 1 (2001)
Internet country code: .mz
Internet Service Providers (ISPs): 1 1 (2002)
Internet users: 22,500 (2000)','ef37214e39622bfb8a130448eb7ba56f4be431f784df0c489250f196ce612a58','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8805ac45ca9a82415a1591601249853f4fc2870ca629d7184d1e2555a66d75c2',2002,'BW','Botswana','communications',818,'Telephones - main lines in use: 1 1 0,200 (2000)
Telephones • mobile cellular: 82,000 (2000)
Telephone system:
general assessment: good system; about 6
telephones for each 100 persons
domestic: good urban services; fair rural service;
microwave radio relay links major towns; connections
to other populated places are by open wire; 100%
digital
international: fiber-optic cable to South Africa,
microwave radio relay link to Botswana, direct links to
other neighboring countries; connected to Africa ONE
and South African Far East (SAFE) submarine cables
through South Africa; satellite earth stations - 4
Intelsat (2002)
Radio broadcast stations: AM 2, FM 39,
shortwave 4 (2001)
Television broadcast stations: 8 (plus about 20
low-power repeaters) (1997)
Internet country code: .na
Internet Service Providers (ISPs): 2 (2000)
Internet users: 30,000(2001)
Telephones - main lines in use: 2,000 (1996)
Telephones - mobile cellular: 450 (1994)
Telephone system:
general assessment: adequate local and international
radiotelephone communication provided via
Australian facilities
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .nr
internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 236,816
(January 2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poor telephone and telegraph
service; fair radiotelephone communication service
and mobile cellular telephone network
domestic: NA
international: radiotelephone communications;
microwave landline to India; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 5, shortwave 1
(January 2000)
Television broadcast stations: 1 (plus 9 repeaters)
(1998)
Internet country code: .np
Internet Service Providers (ISPs): 6 (2000)
Internet users: 50,000(2001)','b1be954b94399aa1f8b49c4b2e5d6ac977c26548168a125fb22eb059bfbdc85a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183c5da426b59f77c2d63f19530357afbb2c968c55056a717346ad903dadca58',2002,'NL','Netherlands','communications',826,'Telephones - main fines in use: 9,132,400 (1999)
Telephones * mobile cellular: 4,081,891
(April 1999)
Telephone system:
general assessment highly developed and well
maintained
domestic: the existing system of multi-conductor
cables is gradually being replaced by fiber-optic
cables; the density of cellular telephone traffic is
rapidly increasing and further modernization of the
system is expected in 2001 , with the introduction of
the third generation of the Global System for Mobile
Communications (GSM)
international: 5 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean), 1 Eutelsat, and 1 1nmarsat (Atlantic and
Indian Ocean regions) (1996)
Radio broadcast stations: AM 4, FM 58,
shortwave 3 (1998)
Television broadcast stations: 21 (plus 26
repeaters) (1995)
Internet country code: .nl
Internet Service Providers (ISPs): 52 (2000)
Internet users: 8.7 million (2001)
Telephones - main lines in use; 76,000 (1995)
Telephones - mobile cellular: 13,977 (1996)
Telephone system:
general assessment; generally adequate facilities
domestic: extensive interisland microwave radio relay
links
international: submarine cables - 2; satellite earth
stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4, shortwave 0
(1998)
Television broadcast stations: 3 (there is also a
cable service which supplies programs received from
various US satellite networks and two Venezuelan
channels) (1997)
Internet country code: .an
Internet Service Providers (ISPs): 6
Internet users: 2,000 (2000)','1a7b0df97f6fa229c48004e0f6d5b3315881860673a7dd1371e708f924c16853','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d0e189017ddef1ded31eef850fb3ec5c5ee65ee4172efa4956243a731a51597',2002,'NI','Nicaragua','communications',835,'Telephones - main lines in use: 140,000 (1996)
Telephones - mobile cellular: 7,911 (1997)
Telephone system:
generai assessment: inadequate system being
upgraded by foreign investment
domestic: low-capacity microwave radio relay and
wire system being expanded; connected to Central
American Microwave System
international: satellite earth stations - 1 1ntersputnik
(Atlantic Ocean region) and 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 63, FM 32,
shortwave 1 (1998)
Television broadcast stations: 3 (plus seven
low-power repeaters) (1997)
Internet country code: .ni
Internet Service Providers (ISPs): 3 (2000)
Internet users: 20,000 (2000)','aa76bbbac497cb3fdad7da436e3855ab97fc5a68b912c76f4f0d0ea5fbdb5a6b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05a29cc37707f0f8e1dee84f7a3d00ccc7277813b977b5acd6d6d13a90e7cd4',2002,'NE','Niger','communications',844,'Telephones - main lines in use: 20,000 (2001)
Telephones - mobile cellular: 6,700 (2002)
Telephone system:
general assessment: small system of wire, radio
telephone communications, and microwave radio
relay links concentrated in the southwestern area of
domestic: wire, radiotelephone communications, and
microwave radio relay; domestic satellite system with
3 earth stations and 1 planned
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 5, FM 6, shortwave 4
(2001)
Television broadcast stations: 3 (plus seven
low-power repeaters) (2002)
Internet country code: .ne
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)','f1aca7997395cf653794af59c386ad15f43223f0ef9a7c9f1c12eecf81692bfd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9966e5d911d90ed53db3c106823b5063d05e17857d88b2d1f09fe9461b18f376',2002,'MP','Northern Mariana Islands','communications',862,'Telephones - main lines in use: 21 ,000 (1996)
Telephones - mobile cellular: 1 ,200 (1 995)
Telephone system:
general assessment: NA
domestic:
international: satellite earth stations - 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 1
(1998)
Television broadcast stations: 1 (on Saipan and
one station planned for Rota; in addition, two cable
services on Saipan provide varied programming from
satellite networks) (1997)
Internet country code: .mp
Internet Service Providers (ISPs): 1 (2001)
Internet users: NA
Telephones - main lines in use: 2.735 million
(1998)
Telephones ■ mobile cellular: 2,080,408 (1998)
Telephone system:
general assessment: modern in all respects; one of
the most advanced telecommunications networks in
Europe
domestic: Norway has a domestic satellite system;
moreover, the prevalence of rural areas encourages
the wide use of cellular mobile systems instead of
fixed wire systems
international: 2 buried coaxial cable systems;
4 coaxial submarine cables; satellite earth stations -
NA Eutelsat, NA Intelsat (Atlantic Ocean), and
1 1nmarsat (Atlantic and Indian Ocean regions);
note - Norway shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Sweden) (1999)
Radio broadcast stations: AM 5, FM at least 650,
shortwave 1 (1998)
Television broadcast stations: 360 (plus 2,729
repeaters) (1995)
Internet country code: .no
Internet Service Providers (ISPs): 13 (2000)
Internet users: 2.45 million (2001)
391
Norway (continued)
Telephones ■ main lines in use: 201 ,000 (1 997)
Telephones - mobile cellular: 59,822 (1997)
Telephone system:
general assessment: modern system consisting of
open wire, microwave, and radiotelephone
communication stations; limited coaxial cable
domestfc; open wire, microwave, radiotelephone
communications, and a domestic satellite system with
8 earth stations
international: satellite earth stations - 2 Intelsat
(Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 3, FM 9, shortwave 2
(1999)
Television broadcast stations: 13 (plus 25
low-power repeaters) (1999)
Internet country code: .om
Internet Service Providers (ISPs): 1 (2000)
Internet users: 90,000(2001)
Telephone system:
general assessment: satellite communications; 1
DSN circuit off the Overseas Telephone System
COTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA,
shortwave NA
note: Armed Forces Radio/Television Service
(AFRTS) radio service provided by satellite (1998)
Television broadcast stations: 0 (1997)','a7a6d1578de6cdf2e4f141f479655e085420d616fef7b57a3ac7fed39d5eeec4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bda90f8aa958f203c0a59df264753499534072bbbf7a1a5f6aa10f8074bad225',2002,'PK','Pakistan','communications',874,'Telephones - main lines in use: 2.861 million
(March 1999)
Telephones -mobile cellular: 158,000(1998)
Telephone system:
general assessment: the domestic system is
mediocre, but improving; service is adequate for
government and business use, in part because major
businesses have established their own private
systems; since 1988, the government has promoted
investment in the national telecommunications system
on a priority basis, significantly increasing network
capacity; despite major improvements in trunk and
urban systems, telecommunication services are still
not readily available to the majority of the rural
population
domestic: microwave radio relay, coaxial cable,
fiber-optic cable, cellular, and satellite networks
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean); 3 operational
international gateway exchanges (1 at Karachi and 2
at Islamabad); microwave radio relay to neighboring
countries (1999)
Radio broadcast stations: AM 27, FM 1 , .
shortwave 21 (1998)
Television broadcast stations: 22 (plus seven
low-power repeaters) (1997)
Internet country code: ,pk
Internet Service Providers (ISPs): 30 (2000)
Internet users: 1.2 million (2000)
397
Pakistan (continued)','a2ce86c3f1d71988acc37f7fbca44d28e119347c2b76cd1b1c705765ac4672a2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc8e0a304bc4f438b3621a7ef829f3724888aa63772a390fb3e73b3935ea4c44',2002,'PW','Palau','communications',884,'Telephones - main lines in use: 6,700 (2002)
Telephones • mobile cellular: 1 ,000 (2002)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 4, shortwave 1
(2002)
Television broadcast stations: 1 (1997)
Internet country code: .pw
Internet Service Providers (ISPs): 1 (2002)','b54de54d1b0371d3d552150028be955357b17f2070c49f5ceecd21c67033bcad','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d43a45b165dd7fab93ec3174246f81160293e923d206ca9ab20f1881c18d8df4',2002,'AR','Argentina','communications',900,'Telephones • main lines in use: 290.475 (2001)
Telephones - mobile cellular: 510,000 (2001)
Telephone system:
general assessment: meager telephone service;
principal switching center is Asuncion
domestic: fair microwave radio relay network
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 46, FM 27,
shortwave 6 (three inactive) (1998)
Television broadcast stations: 4 (2001)
Internet country code: .py
Internet Service Providers (ISPs): 4 (2000)
Internet users: 20,000 (2000)
Telephones - main lines in use: 1 .509 million
(1998)
Telephones - mobile cellular: 504,995 (1998)
Telephone system:
general assessment: adequate for most requirements
domestic: nationwide microwave radio relay system
and a domestic satellite system with 12 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); Pan American submarine cable
Radio broadcast stations: AM 472? FM 198,
shortwave 189 (1999)
Television broadcast stations: 13 (plus 112
repeaters) (1997)
Internet country code: .pe
Internet Service Providers (ISPs): 10 (2000)
Internet users: 400,000 (2000)
Telephones - main lines in use: 3.1 million (2000)
Telephones - mobile cellular: 6.5 million (2000)
Telephone system:
general assessment: good international
radiotelephone and submarine cable services;
domestic and interisland service adequate
domestic: domestic satellite system with 1 1 earth
stations
international: 9 international gateways; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Pacific
Ocean); submarine cables to Hong Kong, Guam,
Singapore, Taiwan . and Japan
Radio broadcast stations: AM 366, FM 290,
shortwave 5
note: each shortwave station operates on multiple
frequencies in the language of the target audience
(2002)
Television broadcast stations: 75 (2000)
Internet country code: .ph
Internet Service Providers (ISPs): 33 (2000)
Internet users: 2 million (2001)
Telephones - main lines in use: 1 (there are 17
telephones on one party line) (1997)
Telephone system:
general assessment: only party line telephone service
is available for this small, closely related community
domestic: party line service only
international: radiotelephone
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: .pn
Internet Service Providers (ISPs): NA
Internet users: NA','a9b27bc079438ebaf82a2deb74f46334106f8dd1d38565d17c95b652edc96a0b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9cb58928d1433ab95af304a09dfa4bfef6eb06210e7f51cbbdbc698538c5f6',2002,'QA','Qatar','communications',916,'Telephones - main lines in use: 142,000 (1997)
Telephones - mobile cellular: 43,476 (1997)
Telephone system:
general assessment: modern system centered in
Doha
domestic: NA
425
Qatar (continued)
international: tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite earth
stations • 2 Intelsat (1 Atlantic Ocean and 1 1ndian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5, shortwave 1
(1998)
Television broadcast stations: 1 (ptus three
repeaters) (2001)
Internet country code: .qa
Internet Service Providers (ISPs): 1 (2000)
Internet users: 75,000(2001)','35110d634deb30a8da05831577ac63a802d34c2e17c6fffff10dd64edee8d1a4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eddff19b06975d238904bb91a9ffb25cb7d6f47f1d15793c7aa45a5d605e4bd',2002,'TT','Trinidad and Tobago','communications',923,'Telephones - main lines in use: 17,000 (1997)
Telephones - mobile cellular: 205 (1997)
Telephone system:
general assessment: good interisland and
international connections
domestic: interisland links to Antigua and Barbuda
and Saint Martin (Guadeloupe and Netherlands
Antilles) are handled by VHF/UHF/SHF
radiotelephone
international: international calls are carried by
radiotelephone to Antigua and Barbuda and switched
there to submarine cable or to Intelsat; or carried to
Saint Martin (Guadeloupe and Netherlands Antilles)
by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 3, FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Internet country code: .kn
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000(2000)','534137ab4f40eb224a413288f122d7e58c8b0e7ec52b71751f8859f7404e596a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ec18e2280c00d6e7a74d40e5b2e5902f600bc63abfb1f80c21614236a154eeb',2002,'MQ','Martinique','communications',932,'Radio broadcast stations: AM 2, FM 7 (plus 3
repeaters), shortwave 0 (1998)
Television broadcast stations: 3 (of which two are
commercial stations and one is a community antenna
television or CATV channel) (1997)
Internet country code: Jc
Internet Service Providers (ISPs): 15 (2000)
Internet users: 5,000(2000)
Telephones • main lines in use: 4,000 (1997)
Telephones -mobile cellular: 0(1994)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone communication with
most countries in the world; 1 earth station in French
domestic satellite system
Radio broadcast stations: AM1.FM4, shortwave 0
(1998)
Television broadcast stations: 0 (there are,
however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Internet country code: .pm
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','965da921ac8346d91bd311ecb2661d3fbe58d223d8c9d10aaa7cb287de9f1d4b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774b220d47fd6fdd69223c96a6712eb5053bda843437449548f4fa2eac428638',2002,'WS','Samoa','communications',944,'Telephones - main fines in use: 8,183 (1998)
Telephones - mobile cellular: 1 ,545
(February 1998)
Telephone system:
general assessment: adequate
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 3, shortwave 0
(1998)
Television broadcast stations: 6 (1997)
Internet country code: .ws
Internet Service Providers (ISPs): 2 (2000)
Internet users: 500 (2000)','f8bce6264eba238f5fe3596c9a86ccd699e9be7c804b37e9d1e6ccd55f092517','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b07ab824c14ffa04c87ed7d95b16c65b3234321ab76dc74aed0a7517eb7340c8',2002,'SN','Senegal','communications',949,'Telephones - main lines in use: 234,916 (2001)
Telephones - mobile cellular: 373,965 (2001)
Telephone system:
general assessment: good system
domestic: above-average urban system; microwave
radio relay, coaxial cable and fiber-optic cable in trunk
system
international: 4 submarine cables; satellite earth
station • 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 14,
shortwave 0(1998)
Television broadcast stations: 1 (1997)
Internet country code: .sn
Internet Service Providers (ISPs): 15 (2002)
Internet users: 40,000(2001)','47609b19d14b287be3f95cf866bb00e8b8d9891b8251ad906558da6bfdbd824e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57f311ebe7a8b6f2508a3855b675f96fd1ef05c55ab0164f75ff9d0c30f0285c',2002,'SC','Seychelles','communications',959,'Telephones - main lines in use: 19,635 (1997)
Telephones ■ mobile cellular: 16,316 (1999)
Telephone system:
general assessment: effective system
domestic: radiotelephone communications between
islands in the archipelago
international: direct radiotelephone communications
with adjacent island countries and African coastal
countries; satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM1.FM2, shortwave 2
(1998)
Television broadcast stations: 2 (plus 9 repeaters)
(1997)
Internet country code: .sc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000 (2001)','b80a1bfe0fd5140e34c0b6179f188a893f7a68a55534afb4cc856d4c716113c5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e5603025d6f6797dad090ae6c2ae0195bf8fcee4b247990aef4752169e6090',2002,'SL','Sierra Leone','communications',968,'Telephones - main lines in use: 25,000 (2001)
Telephones - mobile cellular: 30,000 (2001)
Telephone system:
general assessment: marginal telephone and
telegraph service
domestic: national microwave radio relay trunk
system, made unserviceable by military activities, is
now operating from Freetown to Bo and Kenema
(April 2001)
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 9, shortwave 1
(1999)
Television broadcast stations: 2 (1999)
Internet country code: .si
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000(2001)','7a7e83b135bd87ba871c2819e070611e84e622101c0362a2fde8efd4a9ac794d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1875af2df10d49f112430f67aef1862e7c95802cf001a6ea9d465ec35f94815c',2002,'HU','Hungary','communications',982,'Telephones - main lines in use: 1 ,934,558 (1 998)
Telephones • mobile cellular: 736,662 (April 1999)
Telephone system:
general assessment: a modernization and
privatization program is increasing accessibility to
telephone service, reducing the waiting time for new
subscribers, and generally improving service quality
domestic: predominantly an analog system that is now
receiving digital equipment and is being enlarged with
fiber-optic cable, especially in the larger cities; mobile
cellular capability has been added
international: three international exchanges (one in
Bratislava and two in Banska Bystrica) are available;
Slovakia is participating in several international
telecommunications projects that wifl increase the
availability of external services
Radio broadcast stations: AM 15, FM 78,
shortwave 2 (1998)
Television broadcast stations: 38 (plus 864
repeaters) (1995)
Internet country code: .sk
Internet Service Providers (ISPs): 6 (2000)
Internet users: 700,000 (2000)','11ab6b5e36b177dd0fda8b0d4cfff5dbc64e756b00dacc9ec99603160fec0133','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35d91328c97febfe57f0e175283546d35eb5b0d28f3fac988fd2f28006ac5b07',2002,'SB','Solomon Islands','communications',992,'Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: 658 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: .sb
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)','0d5fc62e5a70b82b9005c86a0bbd2af9776ef5d1778ac0a1679110123e33c34a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068121224136e963a800b5fc486d6030f89df7315a34122d49e23e15cb685018',2002,'SO','Somalia','communications',1001,'Telephones • main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: the public telecommunications
system was almost completely destroyed or
dismantled by the civil war factions; private wireless
companies offer service in most major cities and
charge the lowest international rates on the continent
domestic: local cellular telephone systems have been
established in Mogadishu and in several other
population centers
international: international connections are available
from Mogadishu by satellite (2001)
Radio broadcast stations: AM 0, FM 1 , shortwave 5
(2001)
Television broadcast stations: 3
nofe:two in Mogadishu; one in Hargeisa (2001)
Internet country code: .so
Internet Service Providers (ISPs): 3 (one each in
Boosaaso, Hargeisa, and Mogadishu) (2000)
Internet users: 200(2000)
Telephones - main lines in use: more than 5
million (2001)
Telephones - mobile cellular: 7.06 million (2001)
Telephone system:
general assessment: the system is the best
developed and most modern in Africa
domestic: consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, radiotelephone communication
stations, and wireless local loops; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria
international: 2 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean)
Radio broadcast stations: AM 14, FM 347 (plus
243 repeaters), shortwave 1 (1998)
Television broadcast stations: 556 (plus 144
network repeaters) (1997)
Internet country code: .za
Internet Service Providers (ISPs): 150 (2001)
Internet users: 2.4 million (2001)
Telephone system:
general assessment: NA
domestic: NA
international: coastal radiotelephone station at
Grytviken
Radio broadcast stations: none
Television broadcast stations: 0 (1997)
Internet country code: ,gs','9453445fa5f2392f2d661dbed5a6f073c5429beada514906db26dbe9ddcb52ee','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7148eb68b4681d7db35e37ac7df4676c788d64d7ca28bf759098639647f44b1',2002,'LK','Sri Lanka','communications',1010,'Telephones - main lines in use: 494,509 (1998)
Telephones - mobile cellular: 228,604 (1 999)
Telephone system:
general assessment: very inadequate domestic
service, particularly in rural areas; likely improvement
with privatization of national telephone company and
encouragement to private investment; good
international service (1999)
domestic: national trunk network consists mostly of
digital microwave radio relay; fiber-optic links now in
use in Colombo area and two fixed wireless local
loops have been installed; competition is strong in
mobile cellular systems; telephone density remains
low at 2.6 main lines per 100 persons (1999)
international: submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian
Ocean) (1999)
Radio broadcast stations: AM 26, FM 45,
shortwave 1 (1998)
Television broadcast stations: 21 (1997)
Internet country code: .Ik
Internet Service Providers (ISPs): 5 (2000)
Internet users: 121,500(2001)
Telephones ■ main lines in use: 400,000 (2000)
Telephones ■ mobile cellular: 20,000 (2000)
Telephone system:
general assessment: large, welt-equipped system by
regional standards and being upgraded; cellular
communications started in 1996 and have expanded
substantially
domestic: consists of microwave radio relay, cable,
radiotelephone communications, tropospheric scatter,
and a domestic satellite system with 14 earth stations
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Arabsat (2000)
Radio broadcast stations: AM 12, FM 1 ,
shortwave 1 (1998)
Television broadcast stations: 3 (1997)
Internet country code: .sd
Internet Service Providers (ISPs): 2 (2002)
Internet users: 50,000 (2002)','2f2db3e559f9842b02ab398a362e7ba5ed671b36f064dd9fd5611de5f0c70e11','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b05a1c398b8639353fb46e485e46b565616513f9828a8b9c077254f60f1fd125',2002,'AF','Afghanistan','communications',1020,'Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 2,500 (1997) .
Telephone system:
general assessment: poorly developed and not well
maintained; many towns are not reached by the
national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio
relay to other CIS republics and by leased
connections to the Moscow international gateway
switch; Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite earth
stations - 1 Orbita and 2 Intelsat
Radio broadcast stations: AM 8, FM 7, shortwave 2
(2001)
Television broadcast stations: 13 (2001)
Internet country code: ,tj
Internet Service Providers (ISPs): 5 (2001)
Internet users: 2,000 (2000)
Telephones - main lines in use: 127,000 (1998)
Telephones - mobile cellular: 30,000 (1999)
Telephone system:
general assessment: fair system operating below
capacity and being modernized for better service;
VSAT (very small aperture terminal) system under
construction
domestic; trunk service provided by open wire,
microwave radio relay, tropospheric scatter, and
fiber-optic cable; some links being made digital
international: satellite earth stations • 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 11,
shortwave 2 (1998)
Television broadcast stations: 3 (1999)
Internet country code: ,tz
Internet Service Providers (ISPs): 6 (2000)
Internet users: 115,000 (2001)
Telephones - main lines in use: 5.6 million (2000)
Telephones -mobile cellular: 3.1 million (2002)
Telephone system:
general assessment service to general public
adequate, but investment in technological upgrades
reduced by recession; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel
cable; domestic satellite system being developed
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 204, FM 334,
shortwave 6 (1999)
Television broadcast stations: 5 (all in Bangkok;
plus 131 repeaters) (1997)
Internet country code: .th
Internet Service Providers (ISPs): 15 (2000)
Internet users: 2.3 million (2000)
Telephones - main lines in use: 25,000 (1997)
Telephones - mobile cellular: 2,995 (1997)
Telephone system:
general assessment: fair system based on a network
of microwave radio relay routes supplemented by
open-wire lines and a mobile cellular system
domestic: microwave radio relay and open-wire lines
for conventional system; cellular system has capacity
of 10,000 telephones
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Symphonie
Radio broadcast stations: AM 2, FM 9, shortwave 4
(1998)
Television broadcast stations: 3 (plus two
repeaters) (1997)
Internet country code: .tg
Internet Service Providers (ISPs): 3 (2001)
Internet users: 20,000(2001)
Telephones - main lines in use: 3,000 (1 994)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: fair cable and radiotelephone
services
domestic:
international: 2 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 3 (one inactive),
FM 6, shortwave 0(1 998)
Television broadcast stations: 0 (broadcasts from
The Bahamas are received; cable television is
established) (1997)
Internet country code: ,tc
Internet Service Providers (ISPs): 14 (2000)
Internet users: NA','49f7f924e2758b32a78dfbb8025529bb0e1ffff46e91cc7c188e88e41b8d4866','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac26feb160ac4244a066badbd4776c08c5b928d7e5d990db9a0a4b5950dd6a7',2002,'TK','Tokelau','communications',1029,'Telephones - main tines in use: NA
Telephones - mobile cellular: 0 (2001)
Telephone system:
general assessment: adequate
domestic: radiotelephone service between islands
international: radiotelephone service to Samoa;
government-regulated telephone service (TeleTok),
with 3 satellite earth stations, established in 1997
Radio broadcast stations:
note: each atoll has a radio broadcast station of
unknown type that broadcasts shipping and weather
reports (1998)
Internet country code: .tk
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','cd51e25a8a4813b5548fc23ebf79bf05a16ab5c9b9cb4b2d097cacff81c04f89','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5b3f83b75bfb85f1bef543803c9202fc65d43db51395d8a789635b86e1f7f6',2002,'TM','Turkmenistan','communications',1038,'Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 4,300 (1998)
Telephone system:
general assessment: poorly developed
domestic: NA
international: linked by cable and microwave radio
relay to other CIS republics and to other countries by
leased connections to the Moscow international
gateway switch; a new telephone link from Ashgabat
to Iran has been established; a new exchange in
Ashgabat switches international traffic th rough Turkey
via Intelsat; satellite earth stations - 1 0rbita and 1
Intelsat
Radio broadcast stations: AM 16, FM 8,
shortwave 2 (1998)
Television broadcast stations: 3 (much
programming relayed from Russia and Turkey) (1 997)
Internet country code: .tm
Internet Service Providers (ISPs): NA
Internet users: 2,000 (2000)','ffaca8defa9162cd480ae71db828d39dbe9bb321a948d6ef8f8a03b9a183dda7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1cc9e286b20a41b6bc459b95fbcdce000a50e4f903fe43ed1fbade737c534a9',2002,'TV','Tuvalu','communications',1047,'Telephones - main lines in use: 1 ,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: serves particular needs for
internal communications
domestic: radiotelephone communications between
islands
international: NA
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1999)
Television broadcast stations: 0 (1997)
Internet country code: .tv
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 50,074; however,
80,868 main lines have been installed (1998)
Telephones - mobile cellular: 9,000 (1998)
Telephone system:
general assessment: seriously inadequate; two
cellular systems have been introduced, but a sharp
increase in the number of main lines is essential;
e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio
relay, and radiotelephone communication stations,
fixed and mobile cellular systems for short range
traffic
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 1nmarsat; analog links to
Kenya and Tanzania
Radio broadcast stations: AM 7, FM 33,
shortwave 2 (2001)
Television broadcast stations: 8 (plus one
low-power repeater) (2001)
Internet country code: .ug
Internet Service Providers (ISPs): 2 (2000)
Internet users: 25,000 (2000)','d4cefaa9ff3f161f80452480e1e0e68294d8b6f8ad1d875978e2d7293cbfb4aa','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fe35380146526df1bacad8c19e0709e2011faffddb31bf41d8a635234e08946',2002,'OM','Oman','communications',1058,'Telephones - main lines in use: 915,223 (1998)
Telephones - mobile cellular: 1 million (1 999)
Telephone system:
general assessment: modern system of microwave
radio relay and coaxial cable; key centers are Abu
Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations • 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and
Pakistan; tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 13, FM 7,
shortwave 2 (1998)
Television broadcast stations: 15 (1997)
Internet country code: .ae
Internet Service Providers (ISPs): 1 (2000)
Internet users: 735,000(2001)','ed905fc69f0d40bae2d5b51b3401e02308730e5b60e0ce14ba2d2592a9f3cbac','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8df98a88dd7f470962c1d052f9b71e9df3df7d8bf885ce71a7e066b7d736a986',2002,'US','United States','communications',1066,'Telephones - main lines in use: 194 million (1997)
Telephones ■ mobile cellular: 69.209 million (1998)
Telephone system:
general assessment: a very large, technologically
advanced, multipurpose communications system
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a
rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite
earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region),
and 4 Inmarsat (Pacific and Atlantic Ocean regions)
(2000)
Radio broadcast stations: AM 4,762, FM 5,542;
shortwave 18 (1998)
Television broadcast stations: more than 1 ,500
(including nearly 1,000 stations affiliated with the five
major networks - NBC, ABC, CBS, FOX, and PBS; in
addition, there are about 9,000 cable TV systems)
(1997)
Internet country code: us
Internet Service Providers (ISPs): 7,800
(2000 est.)
Internet users: 166 million (2001)
Telephones - main tines in use: 929,141 (2001)
Telephones - mobile cellular: 350,000 (2001)
Telephone system:
general assessment: fully digitalized
domestic: most modern facilities concentrated in
Montevideo; new nationwide microwave radio relay
network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean) (2002)
Radio broadcast stations: AM 91, FM 149,
shortwave 7 (2001)
Television broadcast stations: 20 (2001)
Internet country code: .uy
Internet Service Providers (ISPs): 14 (2001 )
Internet users: 370,000(2001)','4cd1f39a4c5c2b020f474e083ebee5eb606b11031abc3b74e2bf3ae106cacd27','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c57092ee06c215ff7f914f29d598aade8fe7edf7d04eea1125022560919f1e1',2002,'UZ','Uzbekistan','communications',1075,'Telephones • main lines in use: 1 .98 million (1 999)
Telephones - mobile cellular: 26,000 (1998)
Telephone system:
general assessment: antiquated and inadequate; in
serious need of modernization
domestic: the domestic telephone system is being
expanded and technologically improved, particularly
in Tashkent and Samarqand, under contracts with
prominent companies in industrialized countries;
moreover, by 1998, six cellular networks had been
placed in operation - four of the GSM type (Global
System for Mobile Communication), one D-AMPS
type (Digital Advanced Mobile Phone System), and
one AMPS type (Advanced Mobile Phone System)
international: linked by landline or microwave radio
relay with CIS member states and to other countries
by leased connection via the Moscow international
gateway switch; after the completion of the Uzbek link
to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities
for international communications; Inmarsat also
provides an international connection, albeit an
expensive one; satellite earth stations - NA (1998)
Radio broadcast stations: AM 20, FM 7,
shortwave 10 (1998)
Television broadcast stations: 4 (plus two
repeaters that relay Russian, Kazakh, Kyrgyz, and
Tajik programs) (1997)
Internet country code: .uz
Internet Service Providers (ISPs): 42 (2000)
Internet users: 7,500 (2000)','bc0e63bf5329e698f326f7d1c4074d5f8d986d4e56d3b85d2f736330c1be8ca5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79233fa9250971b2ed8f5a60d34192d403a7be00d517d0165fd9b336837ccabe',2002,'VU','Vanuatu','communications',1085,'Telephones - main lines in use: 5,500 (1998)
Telephones - mobile cellular: 310 (2000)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 1
(2002)
Television broadcast stations: 1 (2002)
Internet country code: .vu
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000(2000)
Telephones - main lines in use: 2.6 million
(however, 3,500,000 have been installed) (1998)
Telephones - mobile cellular: 2 million (1998)
Telephone system:
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth
stations; recent substantial improvement in telephone
service in rural areas; substantia! increase in
digitalization of exchanges and trunk lines; installation
of a national interurban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador,
Peru, and Bolivia in the construction of an
international fiber-optic network
Radio broadcast stations: AM 201 , FM NA (20 in
Caracas), shortwave 11 (1998)
Television broadcast stations: 66 (plus 45
repeaters) (1997)
Internet country code: .ve
Internet Service Providers (ISPs): 16 (2000)
Internet users: 950,000(2001)
Telephones - main lines in use: 2.6 million (2000)
Telephones - mobile cellular: 730,155 (2000)
Telephone system:
general assessment: Vietnam is putting considerable
effort into modernization and expansion of its
telecommunication system, but its performance
continues to lag behind that of its more modem
neighbors
cfomesf/c:a!l provincial exchanges are digitalized and
connected to Hanoi, Da Nang, and Ho Chi Minh City
by fiber-optic cable or microwave radio relay
networks; since 1991, main lines in use have been
substantially increased and the use of mobile
telephones is growing rapidly
554
Vietnam (continued)
international: satellite earth stations - 2 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 65, FM 7,
shortwave 29 (1999)
Television broadcast stations: at least 7 (plus 13
repeaters) (1998)
Internet country code: .vn
Internet Service Providers (ISPs): 5 (2000)
Internet users: 160,000(2001)','257891ccaf5597632c7c959aa4cdad6b1d8b88d1efc5462fcf8f9a3e5d27a227','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f38cd56d67d6c967848f3a8469069b27c7db197b07feab2426d67e40ae507f',2002,'PR','Puerto Rico','communications',1092,'Telephones - main lines in use: 62,000 (1997)
Telephones - mobile cellular: 2,000 (1992)
Telephone system:
general assessment HA
domestic: modern, uses fiber-optic cable and
microwave radio reiay
international: submarine cable and satellite
communications; satellite earth stations - NA
Radio broadcast stations: AM 5, FM 11,
shortwave 0 (2002)
Television broadcast stations: 2 (2002)
Internet country code: .vi
Internet Service Providers (ISPs): 50 (2000)
Internet users: 12,000(2000)','a5fa3022db80c06429ce1bee7e0ed27dcdb80ac38d313ac2bb5de3610129c48c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eaf0ed7d5f26573c20ce553f713624e4543e32c6674c19c49a7ff8393fe14bd',2002,'DZ','Algeria','communications',1103,'Telephones - main lines in use: about 2,000
(1999 est)
Telephones - mobile cellular: 0 (1999)
Telephone system:
general assessment: sparse and limited system
domestic: NA
international: tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and
satellite; satellite earth stations - 2 Intelsat (Atlantic
Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0, shortwave 0
(1998)
Television broadcast stations: NA
Internet country code: .eh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones ■ main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA;
shortwave NA
Television broadcast stations: NA
Internet Service Providers (ISPs): 1 0,350
(2000 est.)
Internet users: 513.41 million (2001 est.)
Telephones - main lines in use: 291,359 (1999)
Telephones - mobile cellular: 32,042 (2000)
Telephone system:
general assessment: since unification in 1990, efforts
have been made to create a national
telecommunications network
ctomestfcvthe national network consists of microwave
radio relay, cable, tropospheric scatter, and GSM
cellular mobile telephone systems
international: satellite earth stations - 3 Intelsat (2
Indian Ocean and 1 Atlantic Ocean), 1 intersputnik
(Atlantic Ocean region), and 2 Arabsat; microwave
radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 6, FM 1 , shortwave 2
(1998)
Television broadcast stations: 7 (plus several
low-power repeaters) (1997)
Internet country code: .ye
Internet Service Providers (ISPs): 1 (2000)
Internet users: 14,000(2001)
Telephones - main lines in use: 2.017 million
(1995)
Telephones - mobile cellular: 87,000 (1 997)
Telephone system:
general assessment: S
domestic: NA
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 113, FM 194,
shortwave 2 (1998)
Television broadcast stations: more than 771
(including 86 strong stations and 685 low-power
stations, plus 20 repeaters in the principal networks;
also numerous local or private stations in Serbia and
Vojvodina) (1997)
Internet Service Providers (ISPs): 9 (2000)
Internet users: 400,000 (2001)
Telephones - main lines in use: 130,000 (including
more than 40,000 fixed telephones in wireless local
loop connections) (1997)
Telephones - mobile cellular: 75,000 (2001)
Telephone system:
general assessment facilities are aging but still
among the best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay
connects most larger towns and cities; several cellular
telephone services in operation; Internet service is
widely available; very small aperture terminal (VSAT)
networks are operated by private firms
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 19, FM 5,
shortwave 4 (2001)
Television broadcast stations: 9 (2002)
Internet country code: .zm
Internet Service Providers (ISPs): 5(2001)
Internet users: 1 5,000 (2000)','bcacf8ffbece823d10fb6904711a77cf7701512316ee0d0be5f3dd897dd31c3a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e966cdb6a3c5932c3718050a8f0126847c2de9c1c7bb601fa116ba481119b6cf',2002,'ZW','Zimbabwe','communications',1111,'Telephones - main lines in use: 212,000 (in
addition, there are about 20,000 fixed telephones in
wireless local loop connections) (1997)
Telephones - mobile cellular: 1 1 1 ,000 (2001 )
Telephone system:
general assessment: system was once one of the
best in Africa, but now suffers from poor maintenance;
more than 100,000 outstanding requests for
connection despite an equally large number of
installed but unused main lines
domestic: consists of microwave radio relay links,
open-wire lines, radiotelephone communication
stations, fixed wireless local loop installations, and a
substantial mobile cellular network; Internet
connection is available in Harare and planned for all
major towns and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare
and Gweru)
Radio broadcast stations: AM 7, FM 20 (plus 17
repeater stations), shortwave 1 (1998)
Television broadcast stations: 16 (1997)
Internet country code: .zw
Internet Service Providers (ISPs): 6 (2000)
Internet users: 30,000(1999)','370dd9b0b91b59d7513892406cf304a64adf31698d0a31527f10a884907623f5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeb2f41f600646cab2fe889333d1eb38423148e07fc92f73a67bc1631af8817f',2002,'AU','Australia','communications',38,'Telephones - main lines in use
Telephones - mobile cellular
Telephone system
general assessment
domestic
international
Radio broadcast stations
Television broadcast stations
Internet country code
Internet Service Providers (ISPs)
Internet users
Communications -note
xxix
Telephones - main lines in use: 10.05 million
(2000)
Telephones - mobile cellular: 8.6 million (2000)
Telephone system:
general assessment: excellent domestic and
international service
domestic: domestic satellite system; much use of
radiotelephone in areas of low population density;
rapid growth of mobile cellular telephones
international: submarine cables to New Zealand,
Papua New Guinea, and Indonesia; satellite earth
stations - 10 Intelsat (4 Indian Ocean and 6 Pacific
Ocean), 2 Inmarsat (Indian and Pacific Ocean
regions) (1998)
Radio broadcast stations: AM 262, FM 345,
shortwave 1 (1998)
Television broadcast stations: 104 (1997)
Internet country code: au
Internet Service Providers (ISPs): 603 (2001 )
Internet users: 10.06 million (2001)
Communications - note: there are automatic
weather stations on many of the isles and reefs
relaying data to the mainland
Telephones - main lines in use: 376 (1991)
Telephones - mobile cellular: 0 (1991)
Telephone system:
domestic: single-line telephone system connects all
villages on island
international: NA
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .nu
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines In use: 1,087 (1983)
Telephones - mobile cellular: 0 (1 983)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone service with Sydney
(Australia)
Radio broadcast stations: AM 0, FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (local
programming station plus two repeaters that bring in
Australian programs by satellite) (1998)
Internet country code: .nf
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','cda05fd85330a84680371bf37af30b056bbaaedd577bccf1737bfbf8b674cdcb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6bbe92b26d2f0059b595b699a3f9eabeb85b81542724a2c4e32d7367b53e8a4',2002,'AF','Afghanistan','communications',48,'Telephones - main lines in use: 29,000 (1998)
Telephones - mobile cellular: NA
Telephone system:
general assessment: very limited telephone and
telegraph service
domestic: in 1997, telecommunications links were
established between Mazar-e Sharif, Herat,
Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations - 1 1ntelsat
(Indian Ocean) linked only to Iran and 1 1ntersputnik
(Atlantic Ocean region); commercial satellite
telephone center in Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the
active station is In Kabul), FM 1, shortwave 1
(broadcasts in Pashtu, Afghan Persian (Dari), Urdu,
and English) (1999)
Television broadcast stations: at least 10 (one
government-run central television station in Kabul and
regional stations in nine of the 32 provinces; the
regional stations operate on a reduced schedule; also,
in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces) (1998)
Internet country code: .af
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 2,500(1997)
Telephone system:
genera! assessment: poorly developed and not well
maintained; many towns are not reached by the
national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio
relay to other CIS republics and by leased
connections to the Moscow international gateway
switch; Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite earth
stations - 1 0rbita and 2 Intelsat
Radio broadcast stations: AM 8, FM 7, shortwave 2
(2001)
Television broadcast stations: 13 (2001)
Internet country code: .tj
Internet Service Providers (ISPs): 5 (2001)
Internet users: 2,000 (2000)
Telephones - main lines in use: 3,000 (1994)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: fair cable and radiotelephone
services
domestic: NA
international: 2 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 3 (one inactive),
FM 6, shortwave 0(1998)
Television broadcast stations: 0 (broadcasts from
The Bahamas are received; cable television is
established) (1997)
Internet country code: ,tc
Internet Service Providers (ISPs): 14 (2000)
Internet users: NA','f86c3715c516a0d9b4afa9b6bbaa7c081c2a495763cc9fb753461e2c0cb3e231','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af4faf1fb3d5b9d0eba964c6d5ebe7fa83720c33d12f0dcd8e0bd7086afa115',2002,'AL','Albania','communications',57,'Telephones - main lines in use: 120,000 (2001)
Telephones - mobile cellular: 250,000 (2001)
Telephone system:
general assessment: Albania has the poorest
telephone service in Europe with fewer than two
telephones per 100 inhabitants; it is doubtful that
every village has telephone service
domestic: obsolete wire system; no longer provides a
telephone for every village; in 1992, following the fall
of the Communist government, peasants cut the wire
to about 1 ,000 villages and used it to build fences
international: inadequate; international traffic carried
by microwave radio relay from the Tirana exchange to
Italy and Greece
Radio broadcast stations: AM 13, FM 4,
shortwave 2 (2001)
Television broadcast stations: 3 (plus 58
repeaters) (2001)
Internet country code: .at
Internet Service Providers (ISPs): 1 0 (2001 )
Internet users: 12,000(2001)
Telephones - main lines in use: 2.3 million (1998)
Telephones - mobile cellular: 33,500 (1999)
Telephone system:
general assessment: telephone density in Algeria is
very low, not exceeding five telephones per 100
persons; the number of fixed main lines increased in
the last few years to a little more than 2,000,000, but
only about two-thirds of these have subscribers; much
of the infrastructure is outdated and inefficient
domestic: good service in north but sparse in south;
domestic satellite system with 12 earth stations (20
additional domestic earth stations are planned)
international: 5 submarine cables; microwave radio
relay to Italy, France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean), 1 1ntersputnik,
and 1 Arabsat (1998)
Algeria (continued)
Radio broadcast stations: AM 25, FM 1 ,
shortwave 8 (1999)
Television broadcast stations: 46 (plus 216
repeaters) (1995)
Internet country code: .dz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 180,000(2001)','e4404a106405c132e2315060372cdd5266e3fe7a3c9e01b930ad2076496175ea','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b87214a3095a33ae0659ea6c16452611183352602aefe1b54c9542c69973563',2002,'NZ','New Zealand','communications',68,'Telephones - main lines in use: 13,000 (1997)
Telephones - mobile cellular: 2,550 (1997)
Telephone system:
general assessment: NA
domestic: good telex, telegraph, facsimile and cellular
telephone services; domestic satellite system with 1
Comsat earth station
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .as
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 8,000 (1996)
Telephones - mobile cellular: 302 (1996)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean) (1996)
Radio broadcast stations: AM 1 , FM 2, shortwave 1
(2001)
Television broadcast stations: 2 (2001)
Internet country code: .to
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 ,000 (2000)
Telephones - main lines in use: 252,000 (1999)
Telephones - mobile cellular: 17,411 (1997)
Telephone system:
general assessment: excellent international service;
good local service
domestic: NA
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); tropospheric scatter to Barbados
and Guyana
Radio broadcast stations: AM 2, FM 12,
shortwave 0 (1998)
Trinidad and Tobago (continued)
Television broadcast stations: 4 (1997)
Internet country code: .tt
Internet Service Providers (ISPs): 17 (2000)
Internet users: 42.800(2001)
Communications - note: important meteorological
station
Telephones - main lines in use: 1,125 (1994)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(2000)
Television broadcast stations: 2 (2000)
Internet country code: .wf
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','696877255f5947fbd425f0911ba644eb90dcfaafe628f48ed692e534e4ef5569','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93475f770cec7fac326f3f4444ff49e37ad6317db367f2fae2c7451fea35d045',2002,'AD','Andorra','communications',77,'Telephones - main lines in use: 32,946
(December 1998)
Telephones - mobile cellular: 14,117 (December
1998)
Telephone system:
general assessment: NA
domestic: modern system with microwave radio relay
connections between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15,
shortwave 0 (1998)
Television broadcast stations: 0 (1997)
Internet country code: ,ad
Internet Service Providers (ISPs): 1 (2000)
Internet users: 24,500(2001)','f5214c33327481a663ec615b4e1a043f3f7bb78e39159c11efb8e0b9aeaacf26','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d83b8edfccc9fe2ece51a3885245cecfe441e659e826784501d25c6501d8842f',2002,'AO','Angola','communications',86,'Telephones - main lines in use: 69,700 (1997)
Telephones - mobile cellular: 25,800 (2000)
Telephone system:
general assessment: telephone service limited mostly
to government and business use; HF radiotelephone
used extensively for military links
domestic: limited system of wire, microwave radio
relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 36, FM 7,
shortwave 9 (2000)
Television broadcast stations: 7 (2000)
Internet country code: ,ao
Internet Service Providers (ISPs): 1 (2000)
Internet users: 30,000(2001)
Telephones - main lines in use: 4,974 (2000)
Telephones ■ mobile cellular: 1,629 (2000)
Telephone system:
general assessment: NA
domestic: modern internal telephone system
international: microwave radio relay to island of Saint
Marlin (Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6, shortwave 1
(1998)
Television broadcast stations: 1 (1997)
Internet country code: ,ai
Internet Service Providers (ISPs): 1 6 (2000)
Internet users: 919(2000)','53199b6b07b087ba12e39f0471767ee367cd2e778291ed7fdf4ed8ae06957170','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b8558e498f6efe70ff5f013da4d5ebe11ec2c043b51c1bfa72d33def34415ca',2002,'AQ','Antarctica','communications',96,'Telephones • main lines in use: 0
note: information for US bases only (2001 )
Telephones • mobile cellular: NA; Iridium system
in use
Telephone system:
genera! assessment: local systems at some research
stations
domestic: NA
international: via satellite from some research stations
Radio broadcast stations: AM NA, FM 2,
shortwave 1
note: information for US bases only (2002)
Television broadcast stations: 1 (cable system
with six channels; American Forces Antarctic
Network-McMurdo)
note: information for US bases only (2002)
Internet country code: ,aq
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 7.5 million (1998)
Telephones - mobile cellular: 3 million (December
1999)
Telephone system:
general assessment: by opening the
telecommunications market to competition and
foreign investment with the "Telecommunications
Liberalization Plan of 1998", Argentina encouraged
the growth of modem telecommunication technology;
fiber-optic cable trunk lines are being installed
between all major cities; the major networks are
entirely digital and the availability of telephone service
is being improved; however, telephone density is
presently minimal, and making telephone service
universally available will take some time
domestic: microwave radio relay, fiber-optic cable,
and a domestic satellite system with 40 earth stations
serve the trunk network; more than 1 1 0,000 pay
telephones are installed and mobile telephone use is
rapidly expanding
international: satellite earth stations - 8 Intelsat (Atlantic
Ocean); Atlantis II and Unisur submarine cables; two
international gateways near Buenos Aires (1999)
Radio broadcast stations: AM 260 (including 10
inactive stations), FM NA (probably more than 1 ,000,
mostly unlicensed), shortwave 6 (1998)
Argentina (continued)
Military manpower - reaching military age
annually:
males: 335,085 (2002 est.)
Military expenditures - dollar figure: $4.3 billion
(FY99)
Military expenditures • percent of GDP: 1 .3%
(FY00)
Telephones - main lines in use: 568,000 (1997)
Telephones - mobile cellular: 25,000 (2001)
Telephone system:
general assessment: system inadequate; now 90%
privately owned and undergoing modernization and
expansion
domestic: the majority of subscribers and the most
modern equipment are in Yerevan (this includes
paging and mobile cellular service)
international: Yerevan is connected to the
Trans-Asia-Europe fiber-optic cable through Iran;
additional international service is available by
microwave radio relay and landline connections to the
other countries of the Commonwealth of independent
States and through the Moscow international switch
and by satellite to the rest of the world; satellite earth
stations - 1 1ntelsat (2000)
Radio broadcast stations: AM 9, FM 6, shortwave 1
(1998)
Television broadcast stations: 3 (plus an unknown
number of repeaters) (1998)
Internet country code: .am
Internet Service Providers (ISPs): 9 (2001)
Internet users: 30,000(2001)
Telephones - main fines in use: 33,000 (1997)
Telephones - mobile cellular: 3,402 (1997)
Telephone system:
general assessment: NA
domestic: more than adequate
international: 1 submarine cable to Sint Maarten
(Netherlands Antilles); extensive interisland
microwave radio relay links
Radio broadcast stations: AM 4, FM 6, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .aw
Internet Service Providers (ISPs): NA
Internet users: 4,000 (2000)','60508833557a41bd0327d021975cb1860e480fb4e08e679d8f94abf001945ccd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ab5a1dda49d4779289c1365b0208b70b282c0bc48f3e5329177d33c3fd07c72',2002,'AG','Antigua and Barbuda','communications',104,'Telephones - main lines in use: 28,000 (1996)
Telephones - mobile cellular: 1 ,300 (1996)
Telephone system:
general assessment: NA
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean); tropospheric
scatter to Saba (Netherlands Antilles) and','4d33c0896b1bf089bfe0d17bb740f20377c528704c255006a21f0d7ed8402813','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('890af3df57e83a68e724e545b0e5196176ad81bc4aea71d7ad9ebeed0aa8e754',2002,'GP','Guadeloupe','communications',105,'Radio broadcast stations: AM 4, FM 2,
shortwave 0(1998)
Television broadcast stations: 2 (1997)
Internet country code: ,ag
Internet Service Providers (ISPs): 16 (2000)
Internet users: 5,000(2001)','5ba3fc3c64c7cc2b9e49666c8f73532c1cfa20d80373e94a18f95fd7d55baf76','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19359cfbb1a7541297f16dcc7e4cf92a50e5b0b319ea83443b726adeba3825a8',2002,'AT','Austria','communications',122,'Telephones - main lines in use: 4 million
(consisting of 3,600,000 analog main lines plus
400,000 Integrated Services Digital Network
connections); in addition, there are 100,000
Asymmetric Digital Services lines (2001)
Telephones - mobile cellular: 6 million (2001)
Telephone system:
general assessment: highly developed and efficient
domestic: there are 48 main lines for every 1 00
persons; the fiber optic net is very extensive; all
telephone applications and Internet services are
available
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean) and 1 Eutelsat; in
addition, there are about 600 VSAT (very small
aperture terminals) (2002)
Radio broadcast stations: AM 2, FM 160 (plus
several hundred repeaters), shortwave 1 (2001)
Television broadcast stations: 45 (plus more than
1,000 repeaters) (2001)
Internet country code: .at
Internet Service Providers (ISPs): 37 (2000)
Internet users: 3 million (2000)','4d7750d02efae0310f7a4e9d10bb3c8971fcb2f126f42b96e491f7e4ebe59912','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88e5c4b4147cc5b88aa65b32457d20f1788eb8af4f73ca394dd47870cbc9008f',2002,'AZ','Azerbaijan','communications',130,'Telephones - main lines in use: 663,000 (1997)
Telephones - mobile cellular: 40,000 (1997)
Telephone system:
general assessment: inadequate; requires
considerable expansion and modernization;
teledensity of 8.6 main lines per 100 persons is very
low
domestic: the majority of telephones are in Baku and
other industrial centers - about 700 villages still
without public telephone service; satellite service
connects Baku to a modern switch in its exclave of
Naxcivan
37
Azerbaijan (continued)
international: the old Soviet system of cable and
microwave is still serviceable; a satellite connection to
Turkey enables Baku to reach about 200 additional
countries, some of which are directly connected to
Baku by satellite providers other than Turkey (1997)
Radio broadcast stations: AM 10, FM 17,
shortwave 1 (1998)
Television broadcast stations: 2 (1997)
Internet country code: .az
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 2,000 (2001 )','373e02c8f35884f7ac2f2d0398ef7fd86c0f019263ffd1dec2ef7c9ce02b2c74','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4e92714b261d5d25c7cd33915afd1c594086fdc1d1745fa3083512508b4061',2002,'BS','Bahamas','communications',140,'Telephones - main lines in use: 96,000 (1997)
Telephones - mobile cellular: 6,152 (1997)
Telephone system:
general assessment: modem facilities
domestic: totally automatic system; highly developed
international: tropospheric scatter and submarine
cable to Florida; 3 coaxial submarine cables; satellite
earth station - 1 1ntelsat (Atlantic Ocean) (1997)
Radio broadcast stations: AM 3, FM 4, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .bs
Internet Service Providers (ISPs): 19 (2000)
Internet users: 1 3,1 00 (2001 )','70453d3584b95d2afd5fe439c6f520a3627954a0b5bf82bb301f232581cc65e1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2013a9098e6d277629547211e97049000de1ce4102507309e5e0de75fe0a96da',2002,'BH','Bahrain','communications',150,'Telephones • main lines in use: 152,000 (1997)
Telephones - mobile cellular: 58,543 (1997)
Telephone system:
general assessment: modern system
domestic: modern fiber-optic integrated services;
digital network with rapidly growing use of mobile
cellular telephones
international: tropospheric scatter to Qatar and UAE;
microwave radio relay to Saudi Arabia; submarine
cable to Qatar, UAE, and Saudi Arabia; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 1ndian
Ocean) and 1 Arabsat (1997)
Radio broadcast stations: AM 2, FM 3, shortwave 0
(1998)
Television broadcast stations: 4 (1997)
Internet country code: .bh
Internet Service Providers (ISPs): 1 (2000)
Internet users: 105,000(2001)','caaac82fdda740f55184ad273fe9e7ab4bff982dae9404582795b5e4342dc892','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('741da3e2ae6f676498ac38379910b5a260abb053d24d06debd3dd49fc813dc21',2002,'BD','Bangladesh','communications',158,'Telephones - main lines in use: 500,000 (2000)
Telephones ■ mobile cellular: 283,000 (2000)
Telephone system:
general assessment: totally inadequate for a modern
country
domestic: modernizing; introducing digital systems;
trunk systems include VHF and UHF microwave radio
relay links, and some fiber-optic cable in cities
international: satellite earth stations - 2 Intelsat
(Indian Ocean); international radiotelephone
communications and landline service to neighboring
countries (2000)
Radio broadcast stations: AM 12, FM 12,
shortwave 2 (1999)
Television broadcast stations: 15 (1999)
Internet country code: .bd
Internet Service Providers (ISPs): 1 0 (2000)
Internet users: 30,000 (2000)
Telephones - main lines in use: 108,000 (1997)
Telephones - mobile cellular: 8,013 (1997)
Telephone system:
general assessment: NA
domestic: island-wide automatic telephone system
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); tropospheric scatter to Trinidad and','ca144d768ce65f396c68a8e537cb7a6eb446e38a655eaa319f29d01bc7bf8206','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61695fbb3664c801f12199d6dfd47de59ae32b36c8c73c4a167eb7020a588416',2002,'LC','Saint Lucia','communications',162,'Radio broadcast stations: AM 2, FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (plus two cable
channels) (1997)
Internet country code: .bb
Internet Service Providers (ISPs): 19 (2000)
Internet users: 6,000 (2000)
Telephones - main lines in use: 37,000 (1997)
Telephones - mobile cellular: 1 ,600 (1997)
Telephone system:
general assessment: adequate system
domestic: system is automatically switched
international: direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados; international calls
beyond these countries are carried by Intelsat from','175ac37e0b3d363d565d1232dbb65309e9370a2ce1b8012fb9ede8ed9af23bab','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89925fa2ef522cb6b71494f4aaff1bb8ea62ebfecf10857e268e29e61f948165',2002,'BY','Belarus','communications',177,'Telephones - main lines in use: 2.313 million
(1997)
Telephones - mobile cellular: 8,167 (1997)
Telephone system:
general assessment: the Ministry of
Telecommunications controls all telecommunications
through its carrier (a joint stock company) Beltelcom
which is a monopoly
domestic: local - Minsk has a digital metropolitan
network and a cellular NMT-450 network; waiting lists
for telephones are long; local service outside Minsk is
neglected and poor; intercity - Belarus has a partly
developed fiber-optic backbone system presently
serving at least 13 major cities (1 998); Belarus''s fiber
optics form synchronous digital hierarchy rings
through other countries'' systems; an inadequate
analog system remains operational
international: Belarus is a member of the
Trans-European Line (TEL), Trans-Asia-Europe
(TAE) fiber-optic line, and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments
provide connectivity to Latvia, Poland, Russia, and
Ukraine; worldwide service is available to Belarus
through this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik earth
stations
Radio broadcast stations: AM 28, FM 37,
shortwave 11 (1998)
Television broadcast stations: 47 (plus 27
repeaters) (1995)
Internet country code: .by
Internet Service Providers (ISPs): 23 (2002)
Internet users: 180,000(2001)
Telephones - main lines in use: 4.769 million
(1997)
Telephones - mobile cellular: 974,494 (1997)
Telephone system:
general assessment: highly developed,
technologically advanced, and completely automated
domestic and international telephone and telegraph
facilities
domestic: nationwide cellular telephone system;
extensive cable network; limited microwave radio
relay network
international: 5 submarine cables; satellite earth
stations • 2 Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: FM 79, AM 7,
shortwave 1 (1998)
Television broadcast stations: 25 (plus 10
repeaters) (1997)
Internet country code: .be
Internet Service Providers (ISPs): 61 (2000)
Internet users: 2.807 million (2001)
Telephones - main lines in use: 734,693 (2000)
Telephones - mobile cellular: 401 ,263 (2000)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an international capability
independent of the Moscow international switch; more
facilities are being installed for individual use
domestic: expansion underway in intercity trunk line
connections, rural exchanges, and mobile systems;
still many unsatisfied subscriber applications
international: international connections are now
available via cable and a satellite earth station at Riga,
enabling direct connections for most calls (1998)
Radio broadcast stations: AM 8, FM 56,
shortwave 1 (1998)
293
Latvia (continued)
Television broadcast stations: 44 (plus 31
repeaters) (1995)
Internet country code: ,lv
Internet Service Providers (ISPs): 41 (2001)
Internet users: 310,000(2001)','40e5e29a3b546a322d02453e747fab7f47a0143fe6cfda3e737c704265cd8c3f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('569aae55dee95c0a6bc747edbd3ad61f0009da9d8d9f366e87e883a564dc48c8',2002,'BZ','Belize','communications',186,'Telephones • main lines in use: 31,000 (1997)
Telephones - mobile cellular: 3,023 (1997)
Telephone system:
general assessment: above-average system
domestic: trunk network depends primarily on
microwave radio relay
international: satellite earih station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 12,
shortwave 0 (1998)
54
Belize (continued)
Television broadcast stations: 2 (1997)
Internet country code: .bz
Internet Service Providers (ISPs): 2 (2000)
Internet users: 15,000(2000)','5060c38bbc7bbc942944e80cc7c0413433830e4be08bf67494083bdee6c58368','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e25f588803fd8ca43dd9ebf45fce69edd813024f1915fe301b081be4595d55',2002,'BJ','Benin','communications',194,'Telephones - main lines in use: 51 ,000 (2000)
Telephones - mobile cellular: 55,500 (2000)
Telephone system:
general assessment: NA
domestic: fair system of open wire, microwave radio
relay, and cellular connections
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); submarine cable
Radio broadcast stations: AM 2, FM9, shortwave4
(2000)
Television broadcast stations: 1 (2001)
Internet country code: .bj
Internet Service Providers (ISPs): 4 (2002)
Internet users: 50,000 (2002)
Telephones • main lines in use: 52,000 (1997)
Telephones - mobile cellular: 7,980 (1996)
Telephone system:
general assessment: NA
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave 0
(1998)
Television broadcast stations: 3 (1997)
Internet country code: .bm
Internet Service Providers (ISPs): 20 (2000)
Internet users: 25,000 (2000)','440636035334eb0c19f3b24f071f06178d189095cc93a0487c79ee7bc46817b7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5df22720f4f454ee409f5d40bc4cb84cdeef7850c2088245588e03f7c3764398',2002,'BT','Bhutan','communications',203,'Telephones - main lines in use: 6,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: domestic telephone service is very poor
with few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AM 0, FM 1 , shortwave 1
(1998)
Television broadcast stations: 0 (1997)
internet country code: .bt
Internet Service Providers (ISPs): NA
Internet users: 500 (2000)','1ef643c41d27d7b89bf2d132c68d0fa3d2afdf2b73f170888cbd99bd750800cc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f126f734aab3cc995d49e6eda30d402e25ae9cded11f064650aa493a6817487',2002,'NP','Nepal','communications',212,'Telephones - main lines in use: 327,600 (1996)
Telephones - mobile cellular: 116,000 (1997)
Telephone system:
general assessment: new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities; mobile
cellular telephone use expanding rapidly
domestic: primary trunk system, which is being
expanded, employs digital microwave radio relay;
some areas are served by fiber-optic cable; mobile
cellular systems are being expanded
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 171, FM 73,
shortwave 77 (1999)
Television broadcast stations: 48 (1997)
Internet country code: .bo
Internet Service Providers (ISPs): 9 (2000)
Internet users: 78,000 (2000)
63
Bolivia (continued)','93af1a606608f9b984aa18495ec8cae11794945627be72812466bf84c69cc772','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9cfe12144a1679ec055ef997b527c4e745ff32599460761402c63cc09123c7e',2002,'IT','Italy','communications',223,'Telephones - main lines in use: 303,000 (1997)
Telephones - mobile cellular: 9,000 (1997)
Telephone system:
general assessment: telephone and telegraph
network needs modernization and expansion; many
urban areas are below average as contrasted with
services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 16,
shortwave 1 (1998)
Television broadcast stations: 33 (plus 277
repeaters) (September 1995)
Internet country code: .ba
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,500 (2000)
Telephones - main lines In use: 150,000 (2000)
Telephones - mobile cellular: 200,000 (2000)
Telephone system:
general assessment: the system is expanding with
the growth of mobile cellular service and participation
in regional development
domestic: small system of open-wire lines, microwave
radio relay links, and a few radiotelephone
communication stations; mobile cellular service is
growing fast
international: two international exchanges; digital
microwave radio relay links to Namibia, Zambia,
Zimbabwe, and South Africa; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 8, FM 13,
shortwave 4 (2001)
Television broadcast stations: 1 (2001)
Internet country code: .bw
Internet Service Providers (ISPs): 11 (2001)
Internet users: 33,000(2001)
Telephones - main lines in use: 4.82 million (1998)
Telephones - mobile cellular: 1.967 million (1999)
Telephone system:
general assessment: excellent domestic and
international services
domestic: extensive cable and microwave radio relay
networks
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean)
Radio broadcast stations: AM 4, FM 113 (plus
many low power stations), shortwave 2 (1998)
Television broadcast stations: 1 1 5 (plus 1 ,91 9
repeaters) (1995)
Internet country code: ,ch
Internet Service Providers (ISPs): 44 (Switzerland
and Liechtenstein) (2000)
Internet users: 3.41 million (2001)
Telephones - main lines in use: 1 .31 3 million
(1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: fair system currently undergoing
significant improvement and digital upgrades,
including fiber-optic technology
domestic: coaxial cable and microwave radio relay
network
international: satellite earth stations - 1 1ntelsat
(Indian Ocean) and 1 1ntersputnik (Atlantic Ocean
region); 1 submarine cable; coaxial cable and
microwave radio relay to Iraq, Jordan, Lebanon, and
Turkey; participant in Medarabtel
Radio broadcast stations: AM 14, FM 2,
shortwave 1 (1998)
Television broadcast stations: 44 (plus 17
repeaters) (1995)
Internet country code: .sy
Internet Service Providers (ISPs): 1 (2000)
Internet users: 32,000 (2001)','a9bb4a881d9d54cd67af51a79c4a41498e5471de512c922d9cde26572bec4851','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a007e65b9f7118d8196f06a928969ac90d6317343e239c0100b27b7c9fac73',2002,'SR','Suriname','communications',232,'Internet country code: .bv
Communications - note: automatic meteorological
station
Telephones - main lines in use: 400,000 (2000)
Telephones ■ mobile cellular: 20,000 (2000)
Telephone system:
general assessment: large, well-equipped system by
regional standards and being upgraded; cellular
communications started in 1996 and have expanded
substantially
domestic: consists of microwave radio relay, cable,
radiotelephone communications, tropospheric scatter,
and a domestic satellite system with 14 earth stations
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Arabsat (2000)
Radio broadcast stations: AM 12, FM 1,
shortwave 1 (1998)
Television broadcast stations: 3 (1997)
Internet country code: .sd
Internet Service Providers (ISPs): 2 (2002)
Internet users: 50,000 (2002)','24dc05c79364ecc8914fa527b229723df9565eba6cb48159fd7e1140c2512cf9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eafee63cbf8cb7884863b199907430c5cdf4ad3b9341cc20e05188f284fb229a',2002,'NO','Norway','communications',241,'Telephones - main lines in use: 17.039 million
(1997)
Telephones - mobile cellular: 4.4 million (1997)
Telephone system:
general assessment: good working system
domestic: extensive microwave radio relay system
and a domestic satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite
earth stations - 3 Intelsat (Atlantic Ocean), 1 1nmarsat
(Atlantic Ocean region east), connected by microwave
relay system to Mercosur Brazilsat B3 satellite earth
station
Radio broadcast stations: AM 1 ,365, FM 296,
shortwave 161 (of which 91 are collocated with AM
stations) (1999)
Television broadcast stations: 1 38 (1997)
Internet country code: .br
Internet Service Providers (ISPs): 50 (2000)
Internet users: 1 1 .94 million (2001 )
Telephones - main lines in use: 60.381 million
(1997)
Telephones - mobile cellular: 63.88 million (2000)
Telephone system:
genera! assessment: excellent domestic and
international service
domestic: high level of modern technology and
excellent service of every kind
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Indian Ocean region), and 1 1nmarsat (Pacific and
Indian Ocean regions); submarine cables to China,
Philippines, Russia, and US (via Guam) (1999)
Radio broadcast stations: AM 215 plus 370
repeaters, FM 89 plus 485 repeaters, shortwave 21
(2001)
Television broadcast stations: 21 1 plus 7,341
repeaters
note: in addition, US Forces are served by 3 TV
stations and 2 TV cable services (1999)
Internet country code: ,jp
Internet Service Providers (ISPs): 73 (2000)
Internet users: 47.08 million (2001)
Telephones - main lines in use: 6.017 million
(December 1998)
Telephones - mobile cellular: 3.835 million
(October 1998)
Telephone system:
general assessment: excellent domestic and
international facilities; automatic system
domestic: coaxial and multiconductor cables carry
most of the voice traffic; parallel microwave radio relay
systems carry some additional telephone channels
international: 5 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean), 1 Eutelsat,
and 1 1nmarsat (Atlantic and Indian Ocean regions);
note - Sweden shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations: AM 1 , FM 265,
shortwave 1 (1998)
Television broadcast stations: 169 (plus 1,299
repeaters) (1995)
Internet country code: .se
Internet Service Providers (ISPs): 29 (2000)
Internet users: 5.64 million (2000)
Transportation Transnational Issues
Railways: Disputes - international: none
total: 12,821 km
standard gauge: 12,600 km 1 ,435-m gauge (7,918 km
electrified)
narrow gauge: 221 km0.891-m gauge (2001)
Highways:
total: 210,760 km
paved: 1 62,707 km (including 1 ,428 km of
expressways)
unpaved: 48,053 km (1999)
Waterways: 2,052 km
note: navigable to small steamers and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavie, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 174 ships (1,000 GRT or over) totaling
2,255,344 GRT/1 ,609,844 DWT
ships by type: bulk 5, cargo 37, chemical tanker 33,
combination ore/oil 4, passenger 1, petroleum tanker
27, railcar carrier 1 , roll on/roll off 38, short-sea
passenger 4, specialized tanker 6, vehicle
carrier 18
nofe: includes some foreign-owned ships registered
here as a flag of convenience: Denmark 8, Finland 8,
Germany 3, Italy 3, Japan 2, Norway 7
(2002 est.)
Airports: 255(2001)
Airports - with paved runways:
total: 147
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 80
914 to 1,523 m: 27
under 914 m: 25 (2001)
Airports - with unpaved runways:
total: 108
914 to 1,523 m: 6
under 914 m: 102 (2001)
Heliports: 1 (2001)','6aead0f036f177a63d220f25ab55fe2bc0c2755565eebc261fec14927d4a19c5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bbc8673edebf94cfa2b6c871b29153ccff5ace4ce100c877c5948895e57030f',2002,'IO','British Indian Ocean Territory','communications',250,'Telephones - main lines in use: NA
Telephone system:
general assessment: separate facilities for military
and public needs are available
domestic: all commercial telephone services are
available, including connection to the Internet
international: international telephone service is
carried by satellite (2000)
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .io
Internet Service Providers (ISPs): 1 (2000)
Telephones ■ main lines in use: 10,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: worldwide telephone service
domestic: NA
international: submarine cable to Bermuda
Radio broadcast stations: AM 1 , FM 4, shortwave 0
(1998)
Television broadcast stations: 1 (plus one cable
company) (1997)
Internet country code: .vg
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Telephones - main lines in use: 79,000 (1996)
Telephones - mobile cellular: 43,524 (1996)
Telephone system:
general assessment: service throughout country is
excellent; international service good to Europe, US,
and East Asia
domestic: every service available
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacitic Ocean); digital submarine
cable links to Malaysia, Singapore, and Philippines
(2001)
Radio broadcast stations: AM 3, FM 10,
shortwave 0 (1998)
Television broadcast stations: 2 (1997)
Internet country code: ,bn
Internet Service Providers (ISPs): 2 (2000)
Internet users: 28,000(2001)','d775d32821a698c6f96c8ee041df19306bd84a6ded3d02f2124900bbed1bc531','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('357b69740fd6743f5d09d9dcdefe5543b69382f179c784599fcdb4af5ed1fa10',2002,'BG','Bulgaria','communications',262,'Telephones - main lines in use: 3,186,731 (2001)
Telephones - mobile cellular: 1.054 million (2001)
Telephone system:
general assessment: extensive but antiquated
domestic: more than two-thirds of the lines are
residential; telephone service is available in most
villages; a fairly modern digital cable trunk line now
connects switching centers in most of the regions, the
others are connected by digital microwave radio relay
international: direct dialing to 58 countries; satellite
earth stations - 1 1ntersputnik (Atlantic Ocean region);
2 Intelsat (Atlantic and Indian Ocean regions)
Radio broadcast stations: AM 31 , FM 63,
shortwave 2 (2001)
Television broadcast stations: 39 (plus 1 ,242
repeaters) (2001)
Internet country code: .bg
Internet Service Providers (ISPs): 200 (2001)
Internet users: 585,000(2001)','e549ef3ad7e4232526be5d77f97fa790d90875f6f64c4bcc9168540bc09ce928','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad1929fc7042f8955e8ccc7fb47a383b7b9788e1925af53b017def8a30367cab',2002,'ET','Ethiopia','communications',267,'Telephones - main lines in use: 53,200 (2000)
Telephones - mobile cellular: 25,200 (2000)
Telephone system:
general assessment: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 17,
shortwave 3 (2002)
Television broadcast stations: 1 (2001)
Internet country code: .bf
Internet Service Providers (ISPs): 4 (2001)
Internet users: 10,000(2001)
Telephones - main lines In use: 231 ,900 (2000)
Telephones - mobile cellular: 17,800 (2000)
Telephone system:
general assessment: open wire and microwave radio
relay system; adequate for government use
domestic: open wire; microwave radio relay; radio
communication in the HF, VHF, and UHF frequencies;
two domestic satellites provide the national trunk
service
international: open wire to Sudan and Djibouti;
microwave radio relay to Kenya and Djibouti; satellite
earth stations ■ 3 Intelsat (1 Atlantic Ocean and 2
Pacific Ocean)
Radio broadcast stations: AM 8, FM 0, shortwave 1
(2001)
Television broadcast stations: 1 plus 24 repeaters
(2002)
Internet country code: .et
Internet Service Providers (ISPs): 1 (2002)
Internet users: 20,000 (2002)
Communications - note: 1 meteorological station
Telephones • main lines In use: 10,000 (2001)
Telephones - mobile cellular: NA
Telephone system:
general assessment: small system
domestic: combination of microwave radio relay,
open-wire lines, radiotelephone, and cellular
international: NA
Radio broadcast stations: AM 1 (transmitter out of
service), FM 4, shortwave 0 (2002)
Television broadcast stations: NA (1997)
Internet country code: .gw
Internet Service Providers (ISPs): 2 (2002)
Internet users: 1,500(1999)
Telephones - main lines in use: 3,000 (1997)
Telephones - mobile cellular: 6,942 (1997)
Telephone system:
general assessment: adequate facilities
domestic: minimal system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 4, shortwave 0
(1998)
Television broadcast stations: 2 (1997)
Internet country code: .st
Internet Service Providers (ISPs): 2 (2000)
Internet users: 6,500(2001)','9c40994dc7247471df6bde2eb048c2b4ff87b8156549140f9903cb2d32823ea2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8349aa61094587ad02f83522161e01b78feb05b4425e8a932063a7e5707b091f',2002,'TH','Thailand','communications',275,'Telephones - main lines In use: 250,000 (2000)
Telephones - mobile cellular: 8,492 (1997)
Telephone system:
genera! assessment: meets minimum requirements
for local and intercity service for business and
government; international service is good
domestic: NA
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 3
(1998)
Television broadcast stations: 2 (1998)
Internet country code: .mm
Internet Service Providers (ISPs): 1
note: as of September 2000, Internet connections
were legal only for the government, tourist offices, and
a few large businesses (2000)
Internet users: 500 (2000)
Telephones - main lines in use: 20,000 (2000)
Telephones - mobile cellular: 16,300 (2000)
Telephone system:
general assessment: primitive system
domestic: sparse system of open wire, radiotelephone
communications, and low-capacity microwave radio
relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 0, FM 4, shortwave 1
(2001)
Television broadcast stations: 1 (2001)
Internet country code: .bi
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000 (2000)
Telephones - main lines in use: 25,000 (1997)
Telephones - mobile cellular: 4,915 (1997)
Telephone system:
general assessment: service to general public is poor
but improving, with over 20,000 telephones currently
in service and an additional 48,000 expected by 2001 ;
the government relies on a radiotelephone network to
communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 1ntersputnik
(Indian Ocean region)
Radio broadcast stations: AM 12, FM 1,
shortwave 4 (1998)
Television broadcast stations: 4 (1999)
Internet country code: .la
Internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000(2001)
Telephones - main lines in use: 127,000 (1998)
Telephones - mobile cellular: 30,000 (1999)
Telephone system:
general assessment: fair system operating below
capacity and being modernized for better service;
VSAT (very small aperture terminal) system under
construction
domestic: trunk service provided by open wire,
microwave radio relay, tropospheric scatter, and
fiber-optic cable; some links being made digital
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 1 1 ,
shortwave 2 (1998)
Television broadcast stations: 3 (1999)
Internet country code: .tz
Internet Service Providers (ISPs): 6 (2000)
Internet users: 1 1 5,000 (2001 )
Telephones - main lines in use: 5.6 million (2000)
Telephones - mobile cellular: 3.1 million (2002)
Telephone system:
general assessment service to general public
adequate, but investment in technological upgrades
reduced by recession; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel
cable; domestic satellite system being developed
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 204, FM 334,
shortwave 6 (1999)
Television broadcast stations: 5 (all in Bangkok;
plus 131 repeaters) (1997)
Internet country code: .th
Internet Service Providers (ISPs): 15 (2000)
Internet users: 2.3 million (2000)
Telephones - main lines in use: 25,000 (1997)
Telephones - mobile cellular: 2,995 (1997)
Telephone system:
general assessment: lair system based on a network
of microwave radio relay routes supplemented by
open-wire lines and a mobile cellular system
domestic: microwave radio relay and open-wire lines
for conventional system; cellular system has capacity
of 10,000 telephones
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Symphonie
Radio broadcast stations: AM 2, FM 9, shortwave 4
(1998)
Television broadcast stations: 3 (plus two
repeaters) (1997)
Internet country code: ,tg
Internet Service Providers (ISPs): 3 (2001)
Internet users: 20,000(2001)','8950cc047fba845ad093de4cc43c9b52ee961fc6926aebfd656d69058c3654fc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('674a760602060dcd6f6865e3786e6edd564c1ad3710715dbd0a26cc79eee19d9',2002,'KH','Cambodia','communications',288,'Telephones - main lines in use: 21 ,800 (mid-1998)
Telephones - mobile cellular: 80,000 (2000)
Telephone system:
general assessment: adequate landline and/or
cellular service in Phnom Penh and other provincial
cities; rural areas have little telephone service
domestic: NA
international: adequate but expensive landline and
cellular service available to all countries from Phnom
Penh and major provincial cities; satellite earth
station - 1 1ntersputnik (Indian Ocean region)
Radio broadcast stations: AM 7, FM 3, shortwave 3
(1999)
Television broadcast stations: 5 (1999)
Internet country code: .kh
Internet Service Providers (ISPs): 2 (2000)
Internet users: 6,000(2001)
Telephones - main lines in use: 95,000 (2001)
Telephones • mobile cellular: 300,000 (2002)
Telephone system:
general assessment: available only to business and','fc058079920dcbbed1ee1358cf5e7e6bbe2e8a317b8d46b7c576ce79b44e820f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85f8d4a5b7c9399572e88fd0d507b8feb6336d9077cf2e66df1087142f74a184',2002,'US','United States','communications',299,'Telephones ■ main lines in use: 18.5million(1999)
Telephones - mobile cellular: 4.207 million (1997)
Telephone system:
general assessment: excellent service provided by
modern technology
domestic: domestic satellite system with about 300
earth stations
international: 5 coaxial submarine cables; satellite
earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean
region)
Radio broadcast stations: AM 535, FM 53,
shortwave 6 (1998)
Television broadcast stations: 80 (plus many
repeaters) (1997)
Internet country code: .ca
Internet Service Providers (ISPs): 760 (2000 est.)
Internet users: 14.44 million (2001)
Telephones - main lines in use: 194 million (1997)
Telephones - mobile cellular: 69.209 million (1998)
Telephone system:
general assessment: a very large, technologically
advanced, multipurpose communications system
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a
rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite
earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region),
and 4 Inmarsat (Pacific and Atlantic Ocean regions)
(2000)
Radio broadcast stations: AM 4,762, FM 5,542,
shortwave 18 (1998)
Television broadcast stations: more than 1,500
(including nearly 1,000 stations affiliated with the five
major networks - NBC, ABC, CBS, FOX, and PBS; in
addition, there are about 9,000 cable TV systems)
(1997)
Internet country code: us
Internet Service Providers (ISPs): 7,800
(2000 est.)
Internet users: 166 million (2001)','0e7aad848b98c29707deb57901c649c237d7e2377b65880ba8becfa8062cb4d8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e9a8d21d77583c271e9924b537a43198918385d705d2158305e2a1aec792016',2002,'PT','Portugal','communications',304,'Telephones - main lines in use: 60,935 (2002)
Telephones - mobile cellular: 28,1 19 (2002)
Telephone system:
general assessment: effective system, being improved
domestic: interisland microwave radio relay system
with both analog and digital exchanges; work is in
progress on a submarine fiber-optic cable system
which is scheduled for completion in 2003
international: 2 coaxial submarine cables; HF
radiotelephone to Senegal and Guinea-Bissau;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 1 1 (and 14
repeaters), shortwave 0 (1998)
Television broadcast stations: 3(2002)
Internet country code: .cv
Internet Service Providers (ISPs): 1 (2000)
Internet users: 8,000(2001)
Telephones - main lines in use: 5.3 million
(yearend 1998)
Telephones - mobile cellular: 3,074,194 (1999)
Telephone system:
genera! assessment: undergoing rapid development
in recent years, Portugal''s telephone system, by the
end of 1998, achieved a state-of-the-art network with
broadband, high-speed capabilities and a main line
telephone density of 53%
domestic: integrated network of coaxial cables, open
wire, microwave radio relay, and domestic satellite
earth stations
international: 6 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean), NA Eutelsat; tropospheric scatter to Azores;
note - an earth station for Inmarsat (Atlantic Ocean
region) is planned
Radio broadcast stations: AM 47, FM 172 (many
are repeaters), shortwave 2 (1998)
Television broadcast stations: 62 (plus 166
repeaters)
note: includes Azores and Madeira Islands (1995)
Internet country code: .pt
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2 million (2001)','d4058588ee87f4c75243aca09e440541c65db0a2dc35685206d83dc12e963bb1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('772b46f5fa7cf6e9508076697c342609b85e6352f90ebd766ff6d854d360e6d7',2002,'HN','Honduras','communications',315,'Telephones - main lines in use: 19,000 (1995)
Telephones - mobile cellular: 2,534 (1995)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine coaxial cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 1 with cable system
Internet country code: ,ky
Internet Service Providers (ISPs): 16 (2000)
Internet users: NA
Telephones • main lines in use: 10,000 (1997)
Telephones - mobile cellular: 570 (1997)
Telephone system:
general assessment: fair system
domestic: network consists principally of microwave
radio relay and low-capacity, low-powered
radiotelephone communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 0, FM 4, shortwave 1
(2001)
Television broadcast stations: 1 (2001)
Internet country code: .cf
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,500 (2001 )
Telephones - main lines in use: 10,260 (2000)
Telephones - mobile cellular: 20,000 (2002)
Telephone system:
general assessment: primitive system
domestic: fair system of radiotelephone
communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 5
(1998)
Television broadcast stations: 1 (1997)
Internet country code: ,td
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,000 (2000)
103
Chad (continued)
Telephones - main lines in use: 2.603 million
(1998)
Telephones - mobile cellular: 944,225 (1998)
Telephone system:
general assessment: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay links;
domestic satellite system with 3 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 180 (eight inactive),
FM 64, shortwave 17 (one inactive) (1998)
Television broadcast stations: 63 (plus 121
repeaters) (1997)
Internet country code: .cl
Internet Service Providers (ISPs): 7 (2000)
Internet users: 1 .75 million (2001)
Telephones - main lines in use: 234,000 (1997)
Telephones - mobile cellular: 14,427 (1997)
Telephone system:
general assessment: inadequate system
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 241, FM 53,
shortwave 12 (1998)
Television broadcast stations: 11 (plus 17
repeaters) (1997)
Internet country code: .hn
Internet Service Providers (ISPs): 8 (2000)
Internet users: 40,000 (2000)','8f6e34eeed08fa816a6d4b66cc26c057e2c5f0d74e89d8f94b4febba7ea6549a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3d46da10302920c0fd73d9233e83cd0f59f37b2014a31409ae7f6fd9bd08937',2002,'CN','China','communications',325,'Telephones - main lines in use: 135 million (2000)
Telephones - mobile cellular: 65 million
(January 2001)
Telephone system:
general assessment: domestic and international
sen/ices are increasingly available for private use;
unevenly distributed domestic system serves principal
cities, industrial centers, and many towns
domestic: interprovincial fiber-optic trunk lines and
cellular telephone systems have been installed; a
domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Indian Ocean region) and 1 1nmarsat (Pacific and
Indian Ocean regions); several international
fiber-optic links to Japan, South Korea, Hong Kong,
Russia, and Germany (2000)
Radio broadcast stations: AM 369, FM 259,
shortwave 45 (1998)
Television broadcast stations: 3,240 (of which 209
are operated by China Central Television, 31 are
provincial TV stations and nearly 3,000 are local city
stations) (1997)
Internet country code: .cn
Internet Service Providers (ISPs): 3 (2000)
Internet users: 26.5 million (2001)
Telephones ■ main lines in use: 3.839 million
(1999)
Telephones - mobile cellular: 3.7 million
(December 1999)
Telephone system:
general assessment: modern facilities provide
excellent domestic and international services
domestic: microwave radio relay links and extensive
fiber-optic network
international: satellite earth stations - 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean); coaxial cable to
Guangzhou, China; access to 5 international
submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 7, FM 13,
shortwave 0 (1998)
Television broadcast stations: 4 (plus two
repeaters) (1997)
Internet country code: .hk
Internet Service Providers (ISPs): 17 (2000)
Internet users: 3.93 million (2001)
Telephones - main lines in use: 403,000 (1997)
Telephones - mobile cellular: 1 1 ,500 (1 995)
Telephone system:
general assessment: service has improved recently
with the increased use of digital switching equipment,
but better access to the telephone system is needed
in the rural areas and easier access to pay telephones
is needed by the urban public
domestic: microwave radio relay transmission and
coaxial and fiber-optic cable are employed on trunk
lines; considerable use of mobile cellular systems;
Internet service is available
international: satellite earth stations - 3 Intelsat.
1 Arabsat, and 29 land and maritime Inmarsat
terminals; fiber-optic cable to Saudi Arabia and
microwave radio relay link with Egypt and Syria;
connection to international submarine cable FLAG
(Fiber-Optic Link Around the Globe); participant in
MEDARABTEL; international links total about 4,000
Radio broadcast stations: AM 6, FM 5, shortwave 1
(1999)
Television broadcast stations: 20 (plus 96
repeaters) (1995)
270
Jordan (continued)
Internet country code: .jo
Internet Service Providers (ISPs): 5 (2000)
Internet users: 210,000(2001)
Communications - note: 1 meteorological station','4a2551263de50389db8f82b49acf1ec882c112560b474de67fd5e852e23d00a5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9b6f053643d11e3454862c5b3c0d92b2e26fecc6e4a3b2c6fcd803473d8191f',2002,'CX','Christmas Island','communications',334,'Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: service provided by the
Australian network
domestic: only analog mobile telephone service is
available
international: satellite earth stations - one Intelsat
earth station provides telephone and telex service
(2000)
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Clipperton Island
(possession of France)
Background: This isolated island was named for
John CLIPPERTON, a pirate who made it his hideout
early in the 18th century. Annexed by France in 1855,
it was seized by Mexico in 1 897. Arbitration eventually
awarded the island to France, which took possession
in 1935.','0de6e516c1cc31cee5124aeac495453df26d6d5e59af44b0376f8989bd2eb269','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b80b5325686ef8d2dd63e5e131b024fcb235486804a06d9e1a7ade4f90dce9',2002,'FR','France','communications',343,'Telephones - main lines in use: 287 (1992)
Telephones • mobile cellular: NA
Telephone system:
general assessment: connected within Australia''s
telecommunication system
domestic: NA
international: telephone, telex, and facsimile
communications with Australia and elsewhere via
satellite; 1 satellite earth station of NA type (2002)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(2000)
Television broadcast stations: NA
Internet country code: .cc
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Telephones - main lines in use: 263,700 (2000)
Telephones - mobile cellular: 450,000 (2000)
Telephone system:
general assessment: well developed by African
standards but operating well below capacity
domestic: open-wire lines and microwave radio relay;
90% digitalized
international : satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean); 2 coaxial
submarine cables (June 1999)
Radio broadcast stations: AM 2, FM 9, shortwave 3
(1998)
Television broadcast stations: 14 (1999)
Internet country code: .ci
Internet Service Providers (ISPs): 5 (2001)
Internet users: 1 0,000 (2001 )
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: government-operated radiotelephone and
private VHF/CB radiotelephone networks provide
effective service to almost all points on both islands
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean) with links through London to other countries
Radio broadcast stations: AM 1 , FM 7, shortwave 0
(1998)
Television broadcast stations: 2 (operated by the
British Forces Broadcasting Service)
note: cable television is available in Stanley (2002)
Internet country code: .fk
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA; however one-half of all
households are reported to have internet access
(2002)
Telephones - main lines in use: 47,000 (1 997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: fair open wire and microwave radio relay
system
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 2, FM 14 (including
6 repeaters), shortwave 6 (including 5 repeaters)
(1998)
Television broadcast stations: 3 (plus eight
low-power repeaters) (1997)
Internet country code: .gf
Internet Service Providers (ISPs): 2 (2000)
Internet users: 2,000 (2000)
Internet country code: .tf
Telephones - main lines in use: 171 ,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: domestic facilities inadequate
domestic: NA
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean); microwave radio relay to Antigua and
Barbuda, Dominica, and Martinique
Radio broadcast stations: AM 1, FM 17,
shortwave 0 (1998)
Television broadcast stations: 5 (plus several
low-power repeaters) (1997)
Internet country code: .gp
Internet Service Providers (ISPs): 3 (2000)
Internet users: 4,000 (2000)
Telephones - main lines in use: 170,000 (1997)
Telephones - mobile cellular: 15,000 (1997)
Telephone system:
general assessment: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe,
Dominica, and Saint Lucia; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 14,
shortwave 0 (1998)
Television broadcast stations: 1 1 (plus nine
repeaters) (1997)
Internet country code: .mq
Internet Service Providers (ISPs): 2 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 104,100 (1999)
Telephones - mobile cellular: 1 1 0,000 (2001 )
Telephone system:
genera! assessment: very low density: about 3.5
telephones for each thousand persons
domestic: NA
international: satellite earth station - 1 1ntersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 7, FM 9, shortwave 4
(2001)
Television broadcast stations: 4 (plus 18
provincial repeaters and many low powered
repeaters) (1999)
Internet country code: .mn
Internet Service Providers (ISPs): 5 (2001)
Internet users: 30,000 (2001 )
Telephones - main lines in use: 268,500 (1999)
Telephones - mobile cellular: 1 97,000 (September
2000)
Telephone system:
general assessment: adequate system; principal
center is Saint-Denis
domestic: modern open wire and microwave radio
relay network
international: radiotelephone communication to
Comoros, France, Madagascar; new microwave route
to Mauritius; satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 55,
shortwave 0 (2001)
Television broadcast stations: 35 (plus 18
low-power repeaters) (2001)
Internet country code: .re
Internet Service Providers (ISPs): 1 (2000)
Internet users: 10,000(1999)
Telephones - main lines in use: 654,000 (1997)
Telephones - mobile cellular: 50,000 (1998)
Telephone system:
general assessment: above the African average and
continuing to be upgraded; key centers are Sfax,
Sousse, Bizerte, and Tunis; Internet access available
domestic: trunk facilities consist of open-wire lines,
coaxial cable, and microwave radio relay
international: 5 submarine cables; satellite earth
stations - 1 1ntelsat (Atlantic Ocean) and 1 Arabsat;
coaxial cable and microwave radio relay to Algeria
and Libya; participant in Medarabtel; two international
gateway digital switches
Radio broadcast stations: AM 7, FM 20,
shortwave 2 (1998)
Television broadcast stations: 26 (plus 76
repeaters) (1995)
Internet country code: ,tn
Internet Service Providers (ISPs): 1 (2000)
Internet users: 280,000(2001)
Telephones - main lines in use: 19.5 million (1 999)
Telephones - mobile cellular: 17.1 million (2001)
Telephone system:
general assessment: undergoing rapid modernization
and expansion, especially with cellular telephones
domestic: additional digital exchanges are permitting
a rapid increase in subscribers; the construction of a
network of technologically advanced intercity trunk
lines, using both fiber-optic cable and digital
microwave radio relay is facilitating communication
between urban centers; remote areas are reached by
a domestic satellite system; the number of
subscribers to mobile cellular telephone service is
growing rapidly
international: international service is provided by three
submarine fiber-optic cables in the Mediterranean and
Black Seas, linking Turkey with Italy, Greece, Israel,
Bulgaria, Romania, and Russia; also by 12 Intelsat
earth stations, and by 328 mobile satellite terminals in
the Inmarsat and Eutelsat systems (2002)
Radio broadcast stations: AM 16, FM 107,
shortwave 6 (2001)
Television broadcast stations: 635 (plus 2,934
repeaters) (1995)
Internet country code: .tr
Internet Service Providers (ISPs): 50 (2001)
Internet users: 4 million (2001)
Telephones - main lines in use: 34.878 million
(1997)
Telephones - mobile cellular: 13 million (yearend
1998)
Telephone system:
general assessment: technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave radio
relay, and fiber-optic systems
international: 40 coaxial submarine cables; satellite
earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and 1 Eutelsat; at least 8 large international switching
centers
Radio broadcast stations: AM 21 9, FM 431 ,
shortwave 3 (1998)
Television broadcast stations: 228 (plus 3,523
repeaters) (1995)
Internet country code: ,uk
Internet Service Providers (ISPs): 245 (2000)
Internet users: 33 million (2001)
Telephones - main lines in use: 95,729 (total for
West Bank and Gaza Strip) (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian
company PALTEL are responsible for communication
services in the West Bank
Radio broadcast stations: AM 1, FM 0,
shortwave 0
note: the Palestinian Broadcasting Corporation
broadcasts from an AM station in Ramallah on 675
kHz; numerous local, private stations are reported to
be in operation (2000)
Television broadcast stations: NA
Internet Service Providers (ISPs): 8 (1999)
Internet users: 60,000 (includes Gaza Strip) (2001)','ff7fb99777746a082acee8ae4e7111eac2a1b410341d278e5c021422bce2fa6b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95a141e9f4a71345ee337dccc37e6ca04f0d45f5048be7e86171866849fc5d3b',2002,'CO','Colombia','communications',351,'Telephones - main lines in use: 5,433,565
(December 1997)
Telephones - mobile cellular: 1 ,800,229
(December 1998)
Telephone system:
general assessment: modem system in many respects
domestic: nationwide microwave radio relay system;
domestic satellite system with 41 earth stations;
fiber-optic network linking 50 cities
international: satellite earth stations - 6 Intelsat, 1
Inmarsat; 3 fully digitalized international switching
centers; 8 submarine cables
Radio broadcast stations: AM 454, FM 34,
shortwave 27(1999)
Television broadcast stations: 60 (includes seven
low-power stations) (1997)
Internet country code: .co
Internet Service Providers (ISPs): 18 (2000)
Internet users: 878,000(2001)','505be8835544d6de01e325e2689373ce709a7fc2952da9eb7f7967dc5911746c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b4c9358964336996daa5be9d2f280ef24a23ce1caf38d3aa4c14b09014ce46f',2002,'MZ','Mozambique','communications',362,'Telephones - main lines in use: 7,000 (2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: sparse system of microwave
radio relay and HF radiotelephone communication
stations
domestic: HF radiotelephone communications and
microwave radio relay
international: HF radiotelephone communications to
Madagascar and Reunion
Radio broadcast stations: AM 1 , FM 4, shortwave 1
(2001)
Television broadcast stations: NA
Internet country code: .km
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,500 (2001)
Telephones - main lines in use: 90,000
(December 2001)
Telephones - mobile cellular: 1 00,000 (June 2001 )
Telephone system:
general assessment: fair system but not available
generally (telephone density is only 3,5 telephones for
each 1,000 persons)
domestic: the system consists of open-wire lines and
trunk connection by microwave radio relay and
tropospheric scatter
international: satellite earth stations - 5 Intelsat
(2 Atlantic Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 13, FM 17,
shortwave 11 (2001)
Television broadcast stations: 1 (2001)
Internet country code: .mz
Internet Service Providers (ISPs): 11 (2002)
Internet users: 22,500 (2000)
Pipelines: petroleum products 21 2 km
Ports and harbors: Binga, Kariba
Airports: 454 (2001)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2001)
Airports - with unpaved runways:
total: 437
1,524 to 2,437 m: 4
914 to 1,523 m: 209
under 914 m: 224 (2001)
Telephones • main lines in use: 12.49 million
(September 2000)
Telephones - mobile cellular: 16 million
(September 2000)
Telephone system:
general assessment: provides telecommunications
service for every business and private need
domestic: thoroughly modern; completely digitalized
international: satellite earth stations - 2 Intelsat (1
Pacific Ocean and 1 1ndian Ocean); submarine cables
to Japan (Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle East, and
Western Europe (1999)
Radio broadcast stations: AM 218, FM 333,
shortwave 50 (1999)
Television broadcast stations: 29 (plus two
repeaters) (1997)
Internet country code: .tw
Internet Service Providers (ISPs): 8 (2000)
Internet users: 1 1 .6 million (2001 )','c70b8f81e13f6629ec48543abe338007e7704d7b1db4eb73442c82a26eb50272','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a80567521db4b9bf78870b329a8b91d31dae509ca6bdb97524cbf9beb971476b',2002,'CG','Congo','communications',368,'Telephones - main lines in use: 21,000 (1997)
Telephones - mobile cellular: 15,000 (2000)
Telephone system:
general assessment: poor
domestic: barely adequate wire and microwave radio
relay service in and between urban areas; domestic
satellite system with 14 earth stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1 1 ,
shortwave 2 (2001)
Television broadcast stations: 4 (2001)
Internet country code: ,cd
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1,500(1999)
Telephones - main lines in use: 22,000 (1997)
Telephones - mobile cellular: 250,000 (2001)
Telephone system:
general assessment: services barely adequate for
government use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; intercity lines frequently
out-of-order
domestic: primary network consists of microwave
radio relay and coaxial cable
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 3
(2001)
Television broadcast stations: 1 (2002)
Internet country code: .eg
Internet Service Providers (ISPs): 1 (2000)
Internet users: 500 (2000)','bc818fec52ff016f16b6797951f9accdf57f43b1b9f1380a06f2ee6942b76567','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74fd0c15e6a4be13dbc8cde98f36fd6416bc961e6d2322117c4323af6e600ca5',2002,'CK','Cook Islands','communications',381,'Telephones - main lines in use: 5,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: NA
domestic: the individual islands are connected by a
combination of satellite earth stations, microwave
systems, and VHF and HF radiotelephone; within the
islands, service is provided by small exchanges
connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(1998)
Television broadcast stations: 2 (plus eight
low-power repeaters) (1997)
Internet country code: ,ck
Internet Service Providers (ISPs): 3 (2000)
Internet users: NA','a590b4edd282b91039926da2da61153bc6d1143c1cee87604c2ba2752d19f94d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2285a2cc5a9630f4c92941c16de14ee9dd929fa0fe2ad6cce578ac998e6c48e9',2002,'CR','Costa Rica','communications',389,'Telephones - main lines in use: 450,000(1998)
note: 584,000 installed in 1997, but only about
450,000 were in use in 1998
Telephones - mobile cellular: 143,000 (2000)
Telephone system:
general assessment: very good domestic telephone
service
domestic: point-to-point and point-to-multi-point
microwave, fiber-optic, and coaxial cable link rural
areas; Internet service is available
international: connected to Central American
Microwave System; satellite earth stations - 2 Intelsat
(Atlantic Ocean); two submarine cables (1999)
Radio broadcast stations: AM 50, FM 43,
shortwave 19 (1998)
Television broadcast stations: 6 (plus 1 1
repeaters) (1997)
Internet country code: ,cr
Internet Service Providers (ISPs): 3 (of which only
one is legal) (2000)
Internet users: 250,000(2001)
Telephones - main lines in use: 20,000 (2001)
Telephones - mobile cellular: 6,700 (2002)
Telephone system:
general assessment: small system of wire, radio
telephone communications, and microwave radio
relay links concentrated in the southwestern area of','1e8a46f1ffb605ad07e1779c105e6f22cbab473924cd5cbd84883ff076a24204','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3197a2be35e37a756740e29677644410da0753b0e1a9ea3bf913f53c3142834',2002,'SI','Slovenia','communications',401,'Telephones - main lines in use: 1,721,139 (2000)
Telephones - mobile cellular: 1.3 million (2001)
Telephone system:
general assessment: NA
domestic: reconstruction plan calls for replacement of
all analog circuits with digital and enlarging the
network; a backup will be included in the plan for the
main trunk
international: digital international service is provided
through the main switch in Zagreb; Croatia
participates in the Trans-Asia-Europe (TEL)
fiber-optic project which consists of two fiber-optic
trunk connections with Slovenia and a fiber-optic trunk
line from Rijeka to Split and Dubrovnik; Croatia is also
investing in ADRIA 1, a joint fiber-optic project with
Germany, Albania, and Greece (2000)
Radio broadcast stations: AM 16, FM 98,
shortwave 5 (1999)
Television broadcast stations: 36 (plus 321
repeaters) (September 1995)
Internet country code: .hr
Internet Service Providers (ISPs): 9 (2000)
Internet users: 200,000(2001)
132
Croatia (continued)','8339320c6ede45445a2517ef4e02df303429700e45a272535983e86cb157973b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('750cd43d52b5a9e87a341eae6d010e88b6bd9a7d260bfb22a3b8f054e9a5fe7d',2002,'MX','Mexico','communications',411,'Telephones ■ main lines in use: 473,031 (2000)
Telephones - mobile cellular: 2,994 (1997)
Telephone system:
general assessment : NA
domestic: principal trunk system, end to end of
country, is coaxial cable; fiber-optic distribution in
Havana and on Ista de la Juventud; 2 microwave radio
relay installations (one is old, US-built; the other
newer, built during the period of Soviet support); both
analog and digital mobile cellular service established
international: satellite earth station - 1 1ntersputnik
(Atlantic Ocean region)
Radio broadcast stations: AM 169. FM 55,
shortwave 1 (1998)
Television broadcast stations: 58 (1997)
Internet country code: .cu
Internet Service Providers (ISPs): 5 (2001)
Internet users: 60,000(2001)
Telephones - main lines In use: 12.332 million
(2000)
Telephones - mobile cellular: 2.02 million (1998)
Telephone system:
general assessment: low telephone density with
about 12 main lines per 100 persons; privatized in
December 1990; the opening to competition in
January 1997 improved prospects for development
domestic: adequate telephone service for business
and government, but the population is poorly served;
domestic satellite system with 120 earth stations;
extensive microwave radio relay network;
considerable use of fiber-optic cable, coaxial cable,
and mobile cellular service
international: satellite earth stations ■ 32 Intelsat, 2
Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well
as enhancing domestic communications), numerous
Inmarsat mobile earth stations; linked to Central
American Microwave System of trunk connections;
high capacity Columbus-2 fiber-optic submarine cable
with access to the US, Virgin Islands, Canary Islands,
Morocco, Spain, and Italy (1997)
Radio broadcast stations: AM 851 , FM 598,
shortwave 16 (2000)
Television broadcast stations: 236 (plus
repeaters) (1997)
Internet country code: ,mx
Internet Service Providers (ISPs): 51 (2000)
Internet users: 3.42 million (2001)
Telephones - main lines in use: 8.07 million (1998)
Telephones - mobile cellular: 1.78 million (1998)
Telephone system:
general assessment: underdeveloped and outmoded
system; government aimed to have 10 million
telephones in service by 2000; the process of partial
privatization of the state-owned telephone monopoly
has begun; in 1998 there were over 2 million
applicants on the waiting list for telephone service
domestic: cable, open wire, and microwave radio
relay; 3 cellular networks; local exchanges 56.6%
digital
international: satellite earth stations - 2 Intelsat,
NA Eutelsat, 2 Inmarsat (Atlantic and Indian Ocean
regions), and 1 1ntersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 14, FM 777,
shortwave 1 (1998)
Television broadcast stations: 179 (plus 256
repeaters) (September 1995)
Internet country code: .pi
Internet Service Providers (ISPs): 19 (2000)
Internet users: 3.5 million (2001)','5a74dce654c88ec9added350ebe488cbde937437618f0ad15ee716bbb990ad5a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e18e06450f2645fcc4b6644dac4598eef8cee8d2ba366d70472e31e4ed0e6119',2002,'CY','Cyprus','communications',420,'Telephones - main lines in use: Greek Cypriot
area: 405,000 (1998); Turkish Cypriot area: 83,162
(1998)
Telephones - mobile cellular: Greek Cypriot area:
68,000 (1998); Turkish Cypriot area: 70,000 (1999)
Telephone system:
general assessment: excellent in both the Greek
Cypriot and Turkish Cypriot areas
domestic: open wire, fiber-optic cable, and microwave
radio relay
international: tropospheric scatter; 3 coaxial and 5
fiber-optic submarine cables; satellite earth stations -
3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean), 2
Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AWI
7, FM 60, shortwave 1 (1998); Turkish Cypriot area:
AM 3, FM 11, shortwave 1 (1998)
Television broadcast stations: Greek Cypriot
area: 4 (plus 225 low-power repeaters)
(September 1995); Turkish Cypriot area: 4 (plus
5 repeaters) (September 1995)
Internet country code: ,cy
Internet Service Providers (ISPs): 6 (2000)
Internet users: 120,000(2001)
Telephones - main lines in use: 3.869 million
(2000)
Telephones - mobile cellular: 4.346 million (2000)
Telephone system:
general assessment: privatization and modernization
of the Czech telecommunication system got a late
start but is advancing steadily; growth in the use of
mobile cellular telephones is particularly vigorous
domestic: 86% of exchanges now digital; existing
copper subscriber systems now being enhanced with
Asymmetric Digital Subscriber Line (ADSL)
equipment to accommodate Internet and other digital
signals; trunk systems include fiber-optic cable and
microwave radio relay
international: satellite earth stations - 2 Intersputnik
(Atlantic and Indian Ocean regions), 1 1ntelsat, 1
Eutelsat, 1 1nmarsat, 1 Globalstar
Radio broadcast stations: AM 31 , FM 304,
shortwave 17 (2000)
Television broadcast stations: 150 (plus 1,434
repeaters) (2000)
internet country code: .cz
Internet Service Providers (ISPs): more than 300
(2000)
Internet users: 1.1 million (2001)
141
Czech Republic (continued)','2f1eaeb6e3b5ee005c78ec7cff91223cd00eba603981752643acb9724d839e83','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2e6d0ae04bfaaa54f4c79fc5829019b8aed30ef1d649e35f2baad0fd9671c81',2002,'SE','Sweden','communications',431,'Telephones - main lines in use: 4.785 million
(1997)
Telephones - mobile cellular: 1,444,016 (1997)
Telephone system:
general assessment: excellent telephone and
telegraph services
domestic: buried and submarine cables and
microwave radio relay form trunk network, 4 cellular
mobile communications systems
international: 18 submarine fiber-optic cables linking
Denmark with Norway, Sweden, Russia, Poland,
Germany, Netherlands. UK, Faroe Islands, Iceland,
and Canada; satellite earth stations - 6 Intelsat, 10
Eutelsat, 1 Orion, 1 1nmarsat
(Blaavand-Atlantic-East); note - the Nordic countries
(Denmark, Finland, Iceland, Norway, and Sweden)
share the Danish earth station and the Eik, Norway,
station for worldwide Inmarsat access (1997)
Radio broadcast stations: AM 2, FM 355,
shortwave 0 (1998)
Television broadcast stations: 26 (plus 51
repeaters) (1998)
Internet country code: .dk
Internet Service Providers (ISPs): 13 (2000)
Internet users: 2.93 million (2001)
Telephones - main lines in use: 10,000 (2002)
Telephones ■ mobile cellular: NA (2002)
Telephone system:
general assessment: telephone facilities in the city of
Djibouti are adequate as are the microwave radio
relay connections to outlying areas of the country
domestic: microwave radio relay network
international: submarine cable to Jiddah, Suez, Sicily,
Marseilles, Colombo, and Singapore; satellite earth
stations - 1 1ntelsat (Indian Ocean) and 1 Arabsat;
Medarabtel regional microwave radio relay telephone
network
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(2001)
Television broadcast stations: 1 (2002)
Internet country code: .dj
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,400(2000)
Telephones - main lines in use: 19,000 (1996)
Telephones - mobile cellular: 461 (1996)
Telephone system:
general assessment: NA
domestic: fully automatic network
international: microwave radio relay and SHF
radiotelephone links to Martinique and Guadeloupe;
VHF and UHF radiotelephone links to Saint Lucia
Radio broadcast stations: AM 3, FM 10,
shortwave 0(1998)
Television broadcast stations: 0 (however, there is
one cable television company) (1997)
Internet country code: .dm
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000 (2000)','56b7e8892a53c0715376e6e6513f254b7cf9bd5f94acb2ebb5a82b26ab85085c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fea8c41b297aa0fb02c262d1b6425455a43d7bf5b74235da17ea438c7941686d',2002,'DO','Dominican Republic','communications',439,'Telephones * main lines in use: 709,000 (1 997)
Telephones - mobile cellular: 130,149 (1997)
Telephone system:
general assessment: NA
domestic: relatively efficient system based on
islandwide microwave radio relay network
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 56,
shortwave 4 (1998)
Television broadcast stations: 25 (1997)
Internet country code: .do
Internet Service Providers (ISPs): 24 (2000)
Internet users: 25,000(1999)
Telephones - main lines in use: 1 .322 million
(1997)
Telephones - mobile cellular: 1 69,265 (1 996)
Telephone system:
general assessment: modern system, integrated with
that of the US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system; cellular telephone
service
international: satellite earth station - 1 1ntelsat;
submarine cable to US
Radio broadcast stations: AM 72, FM 17,
shortwave 0 (1998)
Television broadcast stations: 18 (plus three
stations of the US Armed Forces Radio and Television
Service) (1997)
Internet country code: .pr
Internet Service Providers (ISPs): 76 (2000)
Internet users: 200,000 (2000)','d4d8931d7d7dfa66079fbc928f81fc74a52fb758d5cc89ec8ea3d9b11d1e8dcd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d984833fb9959b0400c789d2f777afb50bd15380147edf87450d71d025d3c2d',2002,'ID','Indonesia','communications',443,'Telephones - main lines in use: NA
Telephones ■ mobile cellular: NA
Telephone system: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
152
East Timor (continued)
Television broadcast stations: NA
Internet country code: .tp
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones • main lines in use: 5,588,310 (1998)
Telephones - mobile cellular: 1 .07 million (1998)
Telephone system:
general assessment: domestic service fair,
international service good
domestic: interisland microwave system and HF radio
police net; domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 678, FM 43,
shortwave 82 (1998)
Television broadcast stations: 41 (1999)
Internet country code: .id
Internet Service Providers (ISPs): 24 (2000)
Internet users: 2 million (2001)
Telephones - main lines in use: 6.313 million
(1997)
Telephones - mobile cellular: 265,000
(August 1998)
Telephone system:
general assessment: inadequate but currently being
modernized and expanded with the goal of not only
improving the efficiency and increasing the volume of
the urban service but also bringing telephone service
to several thousand villages, not presently connected
domestic: as a result of heavy investing in the
telephone system since 1994, the number of
long-distance channels in the microwave radio relay
trunk has grown substantially; many villages have
been brought into the net; the number of main lines in
the urban systems has approximately doubled; and
thousands of mobile cellular subscribers are being
served; moreover, the technical level of the system
has been raised by the installation of thousands of
digital switches
international: HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; submarine fiber-optic cable to UAE with
access to Fiber-Optic Link Around the Globe (FLAG);
Trans-Asia-Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to
Turkmenistan with expansion to Georgia and
Azerbaijan; satellite earth stations - 9 Intelsat and 4
Inmarsat; Internet service available but limited to
electronic mail to promote Iranian culture
Radio broadcast stations: AM 72, FM 5,
shortwave 5 (1998)
Television broadcast stations: 28 (plus 450
low-power repeaters) (1997)
Internet country code: .ir
Internet Service Providers (ISPs): 8 (2000)
Internet users: 250,000(2001)
Telephones - main lines in use: 1 1 ,000 (2001)
Telephones - mobile cellular: NA
Telephone system:
general assessment: adequate system
domestic: islands interconnected by shortwave
radiotelephone (used mostly for government
purposes)
international: satellite earth stations - 5 Intelsat
(Pacific Ocean) (2002)
Radio broadcast stations: AM 5, FM 1 , shortwave 0
(1998)
Television broadcast stations: 2 (1997)
Internet country code: .fm
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2,000(2000)
Telephones - main lines in use: 3.1 million (2000)
Telephones - mobile cellular: 6.5 million (2000)
Telephone system:
general assessment: good international
radiotelephone and submarine cable services;
domestic and interisland service adequate
domestic: domestic satellite system with 1 1 earth
stations
international: 9 international gateways; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Pacific
Ocean); submarine cables to Hong Kong, Guam,
Singapore, Taiwan, and Japan
Radio broadcast stations: AM 366, FM 290,
shortwave 5
note: each shortwave station operates on multiple
frequencies in the language of the target audience
(2002)
Television broadcast stations: 75 (2000)
Internet country code: .ph
Internet Service Providers (ISPs): 33 (2000)
Internet users: 2 million (2001)
Telephones - main lines in use: 1 (there are 17
telephones on one party line) (1997)
Telephone system:
general assessment: only party line telephone service
is available for this small, closely related community
domestic: party line service only
international: radiotelephone
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: ,pn
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones • main lines in use: 1 .95 million (2000)
Telephones - mobile cellular: 2.74 million (2000)
Telephone system:
general assessment: major consideration given to
serving business interests; excellent international
service
domestic: excellent domestic facilities
international: submarine cables to Malaysia (Sabah
and Peninsular Malaysia), Indonesia, and the
Philippines; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean), and 1 1nmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 0, FM 16,
shortwave 2 (1998)
Television broadcast stations: 6 (2000)
Internet country code: .sg
Internet Service Providers (ISPs): 9 (2000)
Internet users: 2.12 million (2001)','680bcded912dac4b7d51a5fb6ce9b2a6a62f479a480e56175909accba9027dca','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e99287bd0f29fa2c3ef3e41c6ab0f6f8db326bd9ad72c62b8075cb263a7ab9af',2002,'PE','Peru','communications',453,'Telephones - main lines in use: 1,11 5,272 ( 1 999)
Telephones - mobile cellular: 384,000 (1999)
Telephone system:
general assessment: generally elementary but being
expanded
domestic: facilities generally inadequate and
unreliable
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 392, FM 35,
shortwave 29 (2001)
Television broadcast stations: 7 (plus 14
repeaters) (2001)
Internet country code: .ec
Internet Service Providers (ISPs): 31 (2001)
Internet users: 180,000(2001)
Telephones - main lines in use: 3,971,500
(December 1998)
Telephones - mobile cellular: 380,000 (1 999)
Telephone system:
general assessment: large system; underwent
extensive upgrading during 1990s and is reasonably
modern; Internet access and cellular service are
available
domestic: principal centers at Alexandria, Cairo, Al
Mansurah, Ismailia, Suez, and Tanta are connected
by coaxial cable and microwave radio relay
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean), 1 Arabsat, and
1 1nmarsat; 5 coaxial submarine cables; tropospheric
scatter to Sudan; microwave radio relay to Israel; a
participant in Medarabtel and a signatory to Project
Oxygen (a global submarine fiber-optic cable system)
Radio broadcast stations: AM 42 (plus
15 repeaters), FM 14, shortwave 3 (1999)
Television broadcast stations: 98 (September
1995)
Internet country code: .eg
Internet Service Providers (ISPs): 50 (2000)
Internet users: 560,000 (2001)
Telephones - main lines in use: 380,000 (1998)
Telephones - mobile cellular: 40,163 (1997)
Telephone system:
general assessment: NA
domestic: nationwide microwave radio relay system
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean); connected to Central American Microwave
System
Radio broadcast stations: AM 61 (plus 24
repeaters), FM 30, shortwave 0 (1998)
Television broadcast stations: 5 (1997)
Internet country code: ,sv
Internet Service Providers (ISPs): 4 (2000)
Internet users: 40,000(2000)
Telephones - main lines in use: 1 .509 million
(1998)
Telephones - mobile cellular: 504,995 (1998)
Telephone system:
general assessment: adequate for most requirements
domestic: nationwide microwave radio relay system
and a domestic satellite system with 12 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); Pan American submarine cable
Radio broadcast stations: AM 472, FM 198,
shortwave 189 (1999)
Television broadcast stations: 13 (plus 112
repeaters) (1997)
Internet country code: .pe
Internet Service Providers (ISPs): 10 (2000)
Internet users: 400,000 (2000)','2d8bb074c5ff00b8f95acc999236a1d4b8d4368f5f84c0364c0e96fc285ae18c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02b2ecd614fd1291137f3a47a62ee894e342dbef1d8b3cf6d857a358485d8292',2002,'GN','Guinea','communications',463,'Telephones - main tines in use: 4,000 (1996)
Telephones • mobile cellular: NA
Telephone system:
general assessment: poor system with adequate
government services
domestic: NA
international: international communications from Bata
and Malabo to African and European countries;
satellite earth station • 1 1ntelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 3, shortwave 5
(2002)
Television broadcast stations: 1 (2002)
Internet country code: .gq
Internet Service Providers (ISPs): 1 (2000)
Internet users: 600 (2000)
Telephones - main lines in use: 30,000 (2001 )
Telephones - mobile cellular: NA; note - mobile
cellular service was introduced in May 2001
Telephone system:
general assessment: inadequate
domestic: very inadequate; most telephones are in
Asmara; government is seeking international tenders
to improve the system (2002)
international: NA; note - international connections
exist
Radio broadcast stations: AM 2, FM NA,
shortwave 2 (2000)
Television broadcast stations: 1 (2000)
Internet country code: .er
Internet Service Providers (ISPs): 5 (2001)
Internet users: 12,000(2001)
Telephones • main lines in use: 500,000 (2000)
Telephones - mobile cellular: 200,000 (2001)
Telephone system:
general assessment: an inadequate system, further
limited by poor maintenance; major expansion is
required and a start has been made
domestic: intercity traffic is carried by coaxial cable,
microwave radio relay, a domestic communications
satellite system with 19 earth stations, and a coastal
submarine cable; mobile cellular facilities and the
Internet are available
international: satellite earth stations - 3 Intelsat (2
Atlantic Ocean and 1 1ndian Ocean); coaxial
submarine cable SAFE (South African Far East)
Radio broadcast stations: AM 83, FM 36,
shortwave 11 (2001)
Television broadcast stations: 3 (the government
controls 2 broadcasting stations and 15 repeater
stations) (2002)
Internet country pode: .ng
Internet Service Providers (ISPs): 1 1 (2000)
Internet users: 100,000(1999)','2f0631a0dc35f890ed90a0068e170833a5c5a8d3b9e24a900289a01657fd5969','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60214807849c1de3fe8956e9a9cc8641e3e53681b73c8416c8fc7642858a8745',2002,'EE','Estonia','communications',474,'Telephones - main lines in use: 501,691 (2000)
Telephones • mobile cellular: 71 1 ,000 (yearend
2001)
Telephone system:
general assessment: foreign investment in the form of
joint business ventures greatly improved telephone
service; substantial fiber-optic cable systems carry
telephone, TV, and radio traffic in the digital mode;
internet services are available throughout most of the
country - only about 1 1 ,000 subscriber requests were
unfilled by September 2000
domestic : a wide range of high quality voice, data, and
internet services is available throughout the country
international: fiber-optic cables to Finland, Sweden,
Latvia, and Russia provide worldwide
packet-switched service; two international switches
are located in Tallinn (2001)
Radio broadcast stations: AMO, FM98,
shortwave 0 (2001)
Television broadcast stations: 3 (2001)
Internet country code: .ee
Internet Service Providers (ISPs): 38 (2001)
Internet users: 540,000(2001)','49b207a40db0ee9c87f00e722573e5b3a0e99619f6f84941623a0100d0ee5074','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19b71a476db8e22434665e3227d07c105786052595067d3c15839a65c0f23ebc',2002,'FO','Faroe Islands','communications',483,'Telephones - main lines in use: 24,851 (1999)
Telephones - mobile cellular: 10,761 (1999)
Telephone system:
general assessment: good international
communications; good domestic facilities
domestic: digitalization was completed in 1998; both
NMT (analog) and GSM (digital) mobile telephone
systems are installed
international: satellite earth stations - 1 Orion; 1
fiber-optic submarine cable to the Shetland Islands,
linking the Faroe Islands with Denmark and Iceland;
fiber-optic submarine cable connection to
Canada-Europe cable
Radio broadcast stations: AM 1, FM 13,
shortwave 0 (1998)
Television broadcast stations: 3 (plus 43
low-power repeaters) (September 1995)
Internet country code: .fo
Internet Service Providers (ISPs): 2 (2000)
Internet users: 3,000 (2000)','b2a3e6b96f29d92692c3f06db73f88fb0a50891a21ae66fe98ec76c290313f59','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c63603356b73c3e733e18b9e579073e6b246a8c32ce4f080c806ec8f6b148f',2002,'JE','Jersey','communications',493,'Telephones - main lines in use: 80,901 (1999)
Telephones - mobile cellular: 5,200 (1997)
Telephone system:
general assessment: modern local, interisland, and
international (wire/radio integrated) public and
special-purpose telephone, telegraph, and teleprinter
facilities: regional radio communications center
domestic: NA
international: access to important cable links between
US and Canada as well as between NZ and Australia;
satellite earth station - 1 1ntelsat (Pacific Ocean)
Radio broadcast stations: AM 1 3, FM 40,
shortwave 0 (1998)
Television broadcast stations: NA
Internet country code: .fj
Internet Service Providers (ISPs): 2 (2000)
Internet users: 7,500 (2000)
Telephones - main lines in use: 2.8 million (1999)
Telephones ■ mobile cellular: 2.5 million (1999)
Telephone system:
genera! assessment: most highly developed system
in the Middle Hast although not the largest
domestic: good system of coaxial cable and
microwave radio relay; all systems are digital
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean)
Radio broadcast stations: AM 23, FM 15,
shortwave 2 (1998)
Television broadcast stations: 17 (plus 36
low-power repeaters) (1995)
Internet country code: ,i!
Internet Service Providers (iSPs): 21 (2000)
Internet users: 1.94 million (2001)
Telephones - main lines in use: 65,500 (1997)
Telephones - mobile cellular: 4,400 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AMNA, FM1,
shortwave 0(1 998)
Television broadcast stations: 1 (1997)
Internet country code: .je
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 412,000 (1997)
Telephones - mobile cellular: 210,000 (1997)
Telephone system:
general assessment: the quality of service is excellent
domestic: new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, open wire, and
fiber-optic cable; a cellular telephone system operates
throughout Kuwait, and the country is well supplied
with pay telephones
international: coaxial cable and microwave radio relay
to Saudi Arabia; linked to Bahrain, Qatar, UAE via the
Fiber-Optic Gulf (FOG) cable; satellite earth stations -
3 Intelsat (1 Atlantic Ocean, 2 Indian Ocean), 1
Inmarsat (Atlantic Ocean), and 2 Arabsat
Radio broadcast stations: AM 6, FM 11,
shortwave 1 (1998)
Television broadcast stations: 13 (plus several
satellite channels) (1997)
Internet country code: .kw
Internet Service Providers (ISPs): 3 (2000)
Internet users: 165,000(2001)
Telephones - main lines in use: 47,000 (1997)
Telephones - mobile cellular: 13,040 (1998)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station • 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 6 (plus 25
low-power repeaters) (1997)
Internet country code: .nc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 24,000(2001)
Airports: 29 (2001)
Airports - with paved runways:
total: 6
over 3,047 m: 1
914 to 1,523 m : 4
under 91 4 m: 1 (2001)
Airports - with unpaved runways:
total: 23
914 to 1,523 m: 12
under 914 m: 11 (2001)
Heliports: 6(2001)
Telephones - main lines in use: 722,000 (1997)
Telephones - mobile cellular: 1 million (2000)
Telephone system:
general assessment: NA
domestic: 100% digital (2000)
international: NA
Radio broadcast stations: AM 17, FM 160,
shortwave 0(1 998)
Television broadcast stations: 48 (2001)
Internet country code: .si
Internet Service Providers (ISPs): 1 1 (2000)
Internet users: 600,000(2001)
Telephones - main lines in use: 8,000 (1997)
Telephones - mobile cellular: 658 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: .sb
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)
Telephones - main lines in use: 38,500 (2001)
Telephones - mobile cellular: 45,000 (2001)
Telephone system:
general assessment: a somewhat modern bu! not an
advanced system
domestic: system consists of carrier-equipped,
open-wire lines and low-capacity, microwave radio
relay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2 plus 4
repeaters, shortwave 3 (2001)
Television broadcast stations: 5 plus 7 relay
stations (2001)
Internet country code: .sz
Internet Service Providers (ISPs): 6 (2001)
Internet users: 6,000 (2001)','a3cdc6a673fe634ed60d0177f93ccc15baa0754dd426e0747aebc40a5d268f03','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('384d732658304687412eef9a36eded6edd73b4fc9711ec64723079f27845c310',2002,'FI','Finland','communications',502,'Telephones - main lines in use: 2.861 million
(1997)
Telephones - mobile cellular: 2,162,574 (1997)
Telephone system:
general assessment: modern system with excellent
service
domestic: cable, microwave radio relay, and an
extensive cellular net provide domestic needs
international: 1 submarine cable; satellite earth
stations - access to Intelsat transmission service via a
Swedish satellite earth station, 1 1nmarsat (Atlantic
and Indian Ocean regions); note - Finland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 2, FM 186,
shortwave 1 (1998)
Television broadcast stations: 130 (plus 385
repeaters) (1995)
Internet country code: .fi
Internet Service Providers (ISPs): 23 (2000)
Internet users: 2.27 million (2000)
Telephones - main lines in use: 2.735 million
(1998)
Telephones - mobile cellular: 2,080,408 (1998)
Telephone system:
general assessment: modern in all respects; one of
the most advanced telecommunications networks in
Europe
domestic: Norway has a domestic satellite system;
moreover, the prevalence of rural areas encourages
the wide use of cellular mobile systems instead of
fixed wire systems
international: 2 buried coaxial cable systems;
4 coaxial submarine cables; satellite earth stations -
NA Euteisat, NA Intelsat (Atlantic Ocean), and
1 1nmarsat (Atlantic and Indian Ocean regions);
note - Norway shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Sweden) (1999)
Radio broadcast stations: AM 5, FM at least 650,
shortwave 1 (1998)
Television broadcast stations: 360 (plus 2,729
repeaters) (1995)
Internet country code: .no
Internet Service Providers (ISPs): 13 (2000)
Internet users: 2.45 million (2001)
391
Norway (continued)
Telephones - main lines in use: 201,000 (1997)
Telephones - mobile cellular: 59,822 (1997)
Telephone system:
general assessment: modern system consisting of
open wire, microwave, and radiotelephone
communication stations; limited coaxial cable
domestic: open wire, microwave, radiotelephone
communications, and a domestic satellite system with
8 earth stations
international: satellite earth stations - 2 Intelsat
(Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 3, FM 9, shortwave 2
(1999)
Television broadcast stations: 13 (plus 25
low-power repeaters) (1999)
Internet country code: .om
Internet Service Providers (ISPs): 1 (2000)
Internet users: 90,000(2001)','56dd55f6258c0f760723b72551f71acfa8c8740db9ec71884e148420cd2cf4d5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96a573fe1e424f2a0b3fe57a47430bf88e4346531f28b976986c49510f5c3ceb',2002,'WF','Wallis and Futuna','communications',512,'Telephones - main lines in use: 34.86 million
(yearend 1998)
Telephones - mobile cellular: 1 1 .078 million
(yearend 1998)
Telephone system:
general assessment: highly developed
domestic: extensive cable and microwave radio relay;
extensive introduction of fiber-optic cable; domestic
satellite system
international: satellite earth stations - 2 Intelsat (with
total of 5 antennas - 2 for Indian Ocean and 3 for
Atlantic Ocean), NA Eutelsat, 1 1nmarsat (Atlantic
Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41, FM about 3,500
(this figure is an approximation and includes many
repeaters), shortwave 2 (1998)
Television broadcast stations: 584 (plus 9,676
repeaters) (1995)
Internet country code: fr
Internet Service Providers (ISPs): 62 (2000)
Internet users: 1 1 .7 million (2001 )','bce8098790ad920731955d2290117f3ffeae98b11cee658c83ab5111b2a5b05c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d61e0aa4cfa188437f2f448935f973cbbb6e92668843b05205d216bf4ea1723',2002,'PF','French Polynesia','communications',527,'Telephones • main lines in use: 52,000 (1997)
Telephones - mobile cellular: 5,427 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 14,
shortwave 2 (1998)
Television broadcast stations: 7 (plus 17
low-power repeaters) (1997)
Internet country code: ,p<
Internet Service Providers (ISPs): 2 (2000)
Internet users: 5,000 (2000)','2d56c794cd967df853deec9b60032e1487b9393b4a3d2f05cf43142f225ef9ad','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3c83a5cddf502e0af604186c1cb1dd0875162434c9f081a34273d4073d4e5f1',2002,'GA','Gabon','communications',535,'Telephones - main lines in use: 39,000 (2000)
Telephones - mobile cellular: 120,000 (2000)
Telephone system:
general assessment: adequate service by African
standards and improving with the help of the growing
mobile cell system
domestic: adequate system of cable, microwave radio
relay, tropospheric scatter, radiotelephone
communication stations, and a domestic satellite
system with 12 earth stations
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 6, FM 7 (and 1 1
repeaters), shortwave 3 (2001)
Television broadcast stations: 3 (plus six
repeaters) (2001)
188
Gabon (continued)
Internet country code: .ga
Internet Service Providers (ISPs): 4 (2001 )
Internet users: 15,000(2001)
Telephones - main lines in use: 31,900 (2000)
Telephones - mobile cellular: 5,624 (2000)
Telephone system:
general assessment: adequate; a packet switched
data network is available
domestic: adequate network of microwave radio relay
and open wire
international: microwave radio relay links to Senegal
and Guinea-Bissau; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2, shortwave 0
(2001)
Television broadcast stations: 1
(government-owned) (1997)
Internet country code: .gm
Internet Service Providers (ISPs): 2 (2001)
Internet users: 5,000 (2001 )
Telephones • main lines in use: 95,729 (total for
Gaza Strip and West Bank) (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: rudimentary telephone services provided
by an open wire system
international: NA
Radio broadcast stations: AM 0, FM 0, shortwave 0
(1998)
Television broadcast stations: 2 (operated by the
Palestinian Broadcasting Corporation) (1997)
Internet Service Providers (ISPs): 3 (1999)
Internet users: 60,000 (includes West Bank) (2001 )','f53834b584ae61e3e251c9586696700ab086847699a2f734ed6ffc70331574a9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a80dcbdb8356b89de78f42cd6ee48c6ae4c507c0046fc19d592414b14ecb1cbf',2002,'GE','Georgia','communications',542,'Telephones - main lines in use: 620,000 (1997)
Telephones - mobile cellular: 185,500 (2000)
Telephone system:
general assessment: NA
domestic: local - Tbilisi and K''ut’aisi have cellular
telephone networks; urban telephone density is about
20 per 100 people; rural telephone density is about 4
per 100 people; intercity facilities include a fiber-optic
line between Tbilisi and K''ut’aisi; nationwide pager
service is available
194
Georgia (continued)
international: Georgia and Russia are working on a
fiber-optic line between P''ofi and Sochi (Russia);
present international service is available by
microwave, landline , and satellite through the Moscow
switch; international electronic mail and telex service
are available
Radio broadcast stations: AM7,FM12,
shortwave 4 (1998)
Television broadcast stations: 12 (plus repeaters)
(1998)
Internet country code: .ge
Internet Service Providers (ISPs): 6 (2000)
Internet users: 20,000 (2000)','c76e6088c72755068e12bd758f6eb37e1bcab969d27144c311fa4af7b9451bac','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('410db4e9ab8f632af7cd805fc612c9e89ad168fc55260400c960ad9130cdba5d',2002,'DE','Germany','communications',550,'Telephones - main lines in use: 50.9 million
(March 2001)
Telephones - mobile cellular: 55.3 million
(June 2001)
Telephone system:
general assessment: Germany has one of the world''s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures
since reunification, the formerly backward system of
the eastern part of the country, dating back to World
War II, has been modernized and integrated with that
of the western part
domestic: Germany is served by an extensive system
of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic satellite
system; cellular telephone service is widely available,
expanding rapidly, and includes roaming service to
many foreign countries
international: Germany''s international service is
excellent worldwide, consisting of extensive land and
undersea cable facilities as well as earth stations in
the INMARSAT, INTELSAT, EUTELSAT, and
INTERSPUTNIK satellite systems (2001)
Radio broadcast stations: AM 51 , FM 787,
shortwave 4 (1998)
Television broadcast stations: 373 (plus 8,042
repeaters) (1995)
Internet country code: .de
Internet Service Providers (ISPs): 200 (2001)
Internet users: 28.64 million (2001)
Telephones ■ main lines in use: 240,000 (2001)
Telephones • mobile cellular: 150,000 (2001)
Telephone system:
general assessment: poor to fair system; Internet
accessible; many rural communities not yet
connected; expansion of services is underway
domestic: primarily microwave radio relay; wireless
local loop has been installed
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); microwave radio relay link to
Panaftel system connects Ghana to its neighbors
Radio broadcast stations: AM 0, FM 49,
shortwave 3 (2001)
Television broadcast stations: 10 (2001)
Internet country code: .gh
Internet Service Providers (ISPs): 12 (2000)
Internet users: 200,000 (2002)
Telephones - main lines in use: 314,700 (1999)
Telephones - mobile cellular: 215,741 (2000)
Telephone system:
general assessment: highly developed, completely
automated and efficient system, mainly buried cables
domestic: nationwide cellular telephone system;
buried cable
international: 3 channels leased on TAT-6 coaxial
submarine cable (Europe to North America)
Radio broadcast stations: AM 2, FM 9, shortwave 2
(1999)
Television broadcast stations: 5 (1999)
Internet country code: .lu
Internet Service Providers (ISPs): 8 (2000)
Internet users: 100,000(2001)
Telephones - main lines in use: 176,902
(November 2001)
Telephones - mobile cellular: 158,251 (November
2001)
Telephone system:
general assessment: fairly modern communication
facilities maintained for domestic and international
services
domestic: NA
international: HF radiotelephone communication
facility; access to international communications
carriers provided via Hong Kong and China; satellite
earth station - 1 1ntelsat (Indian Ocean)
f
t
311
Macau (continued)
Radio broadcast stations: AM 0, FM 2, shortwave 0
(1998)
Television broadcast stations: 0 (receives Hong
Kong broadcasts) (1997)
Internet country code: .mo
Internet Service Providers (ISPs): 1 (2000)
Internet users: 60,000 (2001 )
Telephones - main lines in use: 408,000 (1997)
Telephones - mobile cellular: 12,362 (1997)
Telephone system:
general assessment: NA
domesf/c:NA
international: NA
Radio broadcast stations: AM 29, FM 20,
shortwave 0 (1998)
Television broadcast stations: 31 (plus 166
repeaters) (1995)
Internet country code: .mk
Internet Service Providers (ISPs): 6 (2000)
Internet users: 100,000(2001)','428fb864d7a0d29398f649d82babfc760e79d7467d231bdffceb5276258f95b0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70813edd81de8cec478eb6b4b3af4fd5c19a69b6575cef3a2e34d0ae78255ecf',2002,'GI','Gibraltar','communications',559,'Telephones - main lines in use: 19,000 (1997)
Telephones - mobile cellular: 1 ,620 (1997)
Telephone system:
general assessment: adequate, automatic domestic
system and adequate international facilities
domestic: automatic exchange facilities
international: radiotelephone; microwave radio relay;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(1998)
Television broadcast stations: 1 (plus three
low-power repeaters) (1997)
Internet country code: .gi
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA
Communications - note: 1 meteorological station
Telephones - main lines in use: 1.391 million
(1998)
Telephones ■ mobile cellular: 116,645 (1998)
Telephone system:
general assessment: modern system with all
important capabilities; however density is low with
only 4.6 main lines available for each 100 persons
domestic: good system composed of open-wire lines,
cables, and microwave radio relay links; Internet
available but expensive; principal switching centers
are Casablanca and Rabat; national network nearly
100% digital using fiber-optic links; improved rural
service employs microwave radio relay
international: 7 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain, and
Western Sahara; coaxial cable and microwave radio
relay to Algeria; participant in Medarabtel; fiber-optic
cable link from Agadir to Algeria and Tunisia (1998)
Radio broadcast stations: AM 27, FM 25,
shortwave 6 (1 998)
Television broadcast stations: 35 (plus 66
repeaters) (1995)
Internet country code: .ma
Internet Service Providers (ISPs): 8 (2000)
internet users: 220,000(2001)','a29efc9a86a9155c7ea96cd33a0af237f82ed0172c7a60dd5c5cdab503535c93','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7017996f4770dcf367c2e3e2acbebab502dd7991be27afdd86ae1d23294bc51b',2002,'GR','Greece','communications',568,'Telephones - main lines in use: 5.431 million
(1997)
Telephones - mobile cellular: 937,700 (1997)
Telephone system:
general assessment: adequate, modern networks
reach all areas; good mobile telephone and
international service
domestic: microwave radio relay trunk system;
extensive open wire connections; submarine cable to
offshore islands
international: tropospheric scatter; 8 submarine
cables; satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 1ndian Ocean), 1 Eutelsat, and 1
Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 26, FM 88,
shortwave 4 (1998)
Television broadcast stations: 36 (plus 1 ,341
low-power repeaters); also two stations in the US
Armed Forces Radio and Television Service (1995)
Internet country code: gr
Internet Service Providers (ISPs): 27 (2000)
Internet users: 1 .33 million (1 999)','9e259dd53fcd8fe7f4bbb71c6e218902db989ec1759363c00ded26c43f2067d2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc2d3d5cfc067382f4970b9c9ec18fb241b837a7f2faec5c13378b1c9b15f997',2002,'GL','Greenland','communications',577,'Telephones - main lines in use: 25,617 (yearend
1999)
Telephones - mobile cellular: 12,676 (yearend
1999)
Telephone system:
general assessment: adequate domestic and
international service provided by satellite, cables and
microwave radio relay; totally digitalized in 1995
domestic: microwave radio relay and satellite
international: satellite earth stations - 12 Intelsat, 1
Eutelsat, 2 Americom GE-2 (all Atlantic Ocean)
Radio broadcast stations: AM 5, FM 12,
shortwave 0 (1998)
Television broadcast stations: 1 publicly-owned
station, some local low-power stations, and three
AFRTS (US Air Force) stations (1997)
Internet country code: .gl
Internet Service Providers (ISPs): 1 (2000)
Internet users: 17,800(2001)','6e5c53447925cf6d7daa5313ccf4f9aa0ac4f4cc812e804035c8be784c5edbe3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23cc97e6ea3b6d9bd482dfb3be36263f75f4661db05b40b4e986368550ff5589',2002,'GD','Grenada','communications',585,'Telephones - main lines in use: 27,000 (1997)
Telephones - mobile cellular: 976 (1997)
Telephone system:
general assessment: automatic, islandwide telephone
system
domestic: interisland VHF and UHF radiotelephone
links
international: new SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM 13,
shortwave 0 (1998)
Television broadcast stations: 2 (1 997)
Internet country code: .gd
Internet Service Providers (ISPs): 14 (2000)
Internet users: 4,100(2001)
Telephones - main lines in use: 20,500 (1998)
Telephones - mobile cellular: NA
Telephone system:
general assessment: adequate system
domestic: islandwide, fully automatic telephone
system; VHF/UHF radiotelephone from Saint Vincent
to the other islands of the Grenadines
international: VHF/UHF radiotelephone from Saint
Vincent to Barbados; new SHF radiotelephone to
Grenada and to Saint Lucia; access to Intelsat earth
station in Martinique through Saint Lucia
Radio broadcast stations: AM 1 , FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Internet country code: .vc
Internet Service Providers (ISPs): 15 (2000)
Internet users: 3,500(2001)','cd1ccf77759d7c87f952362cddd26cdd72645508835cedad2b61539e9ae8ca44','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aba9c7852384f910bbb63d1c057ba01ab328a9ce2da89d5fab940a354700f5fb',2002,'GU','Guam','communications',594,'Telephones - main lines In use: 84,134 (1998)
Telephones • mobile cellular: 55,000 (1998)
Telephone system:
general assessment: modem system, integrated with
US facilities for direct dialing, including free use of 800
numbers
domestic: modern digital system, including cellular
mobile service and local access to the Internet
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
(Guam is a trans-Pacific communications hub for MCI,
Sprint, AT&T, IT&E, and GTE, linking the US and
Asia)
Radio broadcast stations: AM4, FM 7, shortwave 0
(1998)
Television broadcast stations: 5 (1997)
Internet country code: .gu
Internet Service Providers (ISPs): 20 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 665,061
(June 2000)
Telephones - mobile cellular: 663,296
(September 2000)
Telephone system:
general assessment: fairly modem network centered
in the city of Guatemala
domestic: NA
international: connected to Central American
Microwave System; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 130, FM 487,
shortwave 15 (2000)
Television broadcast stations: 26 (plus 27
repeaters) (1997)
215
Guatemala (continued)
Internet country code: .gt
Internet Service Providers (ISPs): 5 (2000)
Internet users: 65,000 (2000)','24c9181d5592fb35f84a7d7ff9bcb688739984baf215688c3b68fdbe66962b8e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52adbe618f3e88c4d5cc97b449029dd433691f3c58744a82b6f03bfd78b9715f',2002,'GG','Guernsey','communications',603,'Telephones - main lines in use: 44,000 (1996)
Telephones - mobile cellular: 12,000 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .gg
Internet Service Providers (ISPs): NA
Internet users: NA
217
Guernsey (continued)','e6d8699100871d7e2da831005995b0c09743b55b45282901b9aa2b20070487b3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('089ab3cbde0a0db4184a7f717f87082651ca62e13a1850b13c8d24e014b1bc83',2002,'GW','Guinea-Bissau','communications',606,'Telephones - main lines in use: 37,000 (1998)
Telephones • mobile cellular: 21,567 (1998)
Telephone system:
general assessment: poor to fair system of open-wire
lines, small radiotelephone communication stations,
and new microwave radio relay system
domestic: microwave radio relay and radiotelephone
communication
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 4 (one station is
inactive), FM 1 (plus 7 repeaters), shortwave 3 (2001 )
Television broadcast stations: 1 (2001)
Internet country code: .gn
Internet Service Providers (ISPs): 4 (2001)
Internet users: 8,000 (2000)','60909f525db234245ec3a622477ab5c2534e977bcbfdf0d2346a1fcf6472fd31','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2bd9348b6340b971a993ada982bd1964df152b6231402bca02107086b5067a4',2002,'GY','Guyana','communications',619,'Telephones - main lines in use: 70,000 (2000)
Telephones - mobile cellular: 6,100 (2000)
Telephone system:
general assessment: fair system for long-distance
calling
domestic: microwave radio relay network for trunk
lines
international: tropospheric scatter to Trinidad; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3, shortwave 1
(1998)
Television broadcast stations: 3 (one public
station; two private stations which relay US satellite
services) (1997)
Internet country code: .gy
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,000 (2000)
Telephones ■ main lines in use: 64,000 (1997)
Telephones - mobile cellular: 4,090 (1997)
Telephone system:
general assessment: international facilities are good
domestic: microwave radio relay network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM13,
shortwave 1 (1998)
Television broadcast stations: 3 (plus seven
repeaters) (2000)
Internet country code: .sr
Internet Service Providers (ISPs): 2 (2000)
Internet users: 1 1 ,700 (2001 )
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: probably adequate
domestic: local telephone service
international: satellite earth station - 1 of unknown
type (for communication with Norwegian mainland
only)
489
Svalbard (continued)
Radio broadcast stations: AM 1, FM 1 (plus 2
repeaters), shortwave 0 (1998)
Television broadcast stations: NA
Internet country code: .sj
Internet Service Providers (ISPs): 13 (Svalbard
and Jan Mayen) (2000)
Internet users: NA','e9fd09541200546f866dd9767656f2fad6937a6c5b8c9775a9be5ecf01681197','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f6eb1079afe9bf653ab81899020afa50bf4970b9931c7bd46c7bde6ff78a66',2002,'HT','Haiti','communications',628,'Telephones - main lines in use: 60,000 (1997)
Telephones - mobile cellular: 0 (1995)
Telephone system:
general assessment: domestic facilities barely
adequate; international facilities slightly better
domestic: coaxial cable and microwave radio relay
trunk service
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 41, FM 26,
shortwave 0(1 999)
Television broadcast stations: 2 (plus a cable TV
service) (1997)
Internet country code: .ht
Internet Service Providers (ISPs): 3 (2000)
Internet users: 6,000 (2000)','214dda5af18fd1246fb7cbfffae9ce613dfee25d0adbbb2f4fef24e8764ab248','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5fafe8c4207bf1c907b278445e2b37b8bf40582235c4d3c3c7675903e77f0ce',2002,'HM','Heard Island and McDonald Islands','communications',636,'Internet country code: .hm
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic exchange
domestic: tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4, shortwave 2
(1998)
Television broadcast stations: 1 (1996)
Internet country code: .va
Internet Service Providers (ISPs): NA
Internet users: NA','2e857e08f6a2e59ebf127bc9242ba3f34cfd4e391ebbaf0b70708e532cd04d92','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd61f6b048069a5e88fda161c9750ab18eb8e03d7a8967525bb450115f8c4374',2002,'HU','Hungary','communications',649,'Telephones ■ main lines in use: 3.095 million
(1997)
Telephones - mobile cellular: 1 .269 million
(July 1999)
Telephone system:
general assessment: the telephone system has been
modernized and is capable of satisfying all requests
for telecommunication service
domestic: the system is digitalized and highly
automated; trunk services are carried by fiber-optic
cable and digital microwave radio relay; a program for
fiber-optic subscriber connections was initiated in
1 996; heavy use is made of mobile cellular telephones
international: Hungary has fiber-optic cable
connections with all neighboring countries; the
international switch is in Budapest; satellite earth
stations - 2 Intelsat (Atlantic Ocean and Indian Ocean
regions), 1 1nmarsat, 1 very small aperture terminal
(VSAT) system of ground terminals
Radio broadcast stations: AM 17, FM 57,
shortwave 3 (1998)
Television broadcast stations: 35 (plus 161
low-power repeaters) (1995)
Internet country code: .hu
Internet Service Providers (ISPs): 16 (2000)
Internet users: 1 .2 million (2001 )
Telephones - main lines in use: 168,000 (1997)
Telephones - mobile cellular: 65,746 (1997)
Telephone system:
general assessment: adequate domestic service
domestic: the trunk network consists of coaxial and
fiber-optic cables and microwave radio relay links
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean), 1 1nmarsat (Atlantic and Indian
Ocean regions); note - Iceland shares the Inmarsat
earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM about 70
(including repeaters), shortwave 1 (1998)
Television broadcast stations: 14 (plus 156
low-power repeaters) (1997)
Internet country code: .is
Internet Service Providers (ISPs): 7 (2000)
Internet users: 1 68,000 (2001 )','5a86009bcc592a21f3278da516421561e421d00c320d07a14479c4879a4cb7e1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7393ef21e9dd525b8530f6f6c99e7e4b039a1c449c2737f0af433c747cf082e0',2002,'IN','India','communications',656,'Telephones - main lines in use: 27.7 million
(October 2000)
Telephones - mobile cellular: 2.93 million
(November 2000)
Telephone system:
general assessment: mediocre service; local and long
distance service provided throughout all regions of the
country, with services primarily concentrated in the
urban areas; major objective is to continue to expand
and modernize long-distance network to keep pace
with rapidly growing number of local subscriber lines;
steady improvement is taking place with the recent
admission of private and private-public investors, but,
with telephone density at about two for each 100
persons and a waiting list of over 2 million, demand for
main line telephone service will not be satisfied for a
very long time
domestic: local service is provided by microwave
radio relay and coaxial cable, with open wire and
obsolete electromechanical and manual switchboard
systems still in use in rural areas; starting in the 1 980s,
a substantial amount of digital switch gear has been
introduced for local and long-distance service;
long-distance traffic is carried mostly by coaxial cable
and low-capacity microwave radio relay; since 1985
significant trunk capacity has been added in the form
of fiber-optic cable and a domestic satellite system
with 254 earth stations; mobile cellular service is
provided in four metropolitan cities
international: satellite earth stations ■ 8 Intelsat (Indian
Ocean) and 1 1nmarsat (Indian Ocean region); nine
gateway exchanges operating from Mumbai
(Bombay), New Delhi, Kolkata (Calcutta), Chennai
(Madras), Jalandhar, Kanpur, Gaidhinagar,
Hyderabad, and Ernakulam; 4 submarine cables -
LOCOM linking Chennai (Madras) to Penang;
Indo-UAE-Gulf cable linking Mumbai (Bombay) to Al
Fujayrah, UAE; lndia-SEA-ME-WE-3, SEA-ME-WE-2
with landing sites at Cochin and Mumbai (Bombay);
Fiber-Optic Link Around the Globe (FLAG) with
landing site at Mumbai (Bombay) (2000)
Radio broadcast stations: AM 153, FM 91,
shortwave 68 (1998)
Television broadcast stations: 562 (of which 82
stations have 1 kW or greater power and 480 stations
have less than 1 kW of power) (1997)
Internet country code: .in
Internet Service Providers (ISPs): 43 (2000)
Internet users: 5 million (2001)','001c40c62eeb7d2870d7be3846bb95e48eecd4f8e8e8142015b96dfb757f42ff','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55ed6cdd4e6986328ab460e668eb764e7b30f1b9966b6ebcdf59aff21ff7a33b',2002,'IQ','Iraq','communications',666,'Telephones - main lines In use: 675,000 (1997)
Telephones - mobile cellular: NA; service available
in northern Iraq (2001)
Telephone system:
general assessment: reconstitution of damaged
telecommunication facilities began after the Gulf war;
most damaged facilities have been rebuilt
domestic: the network consists of coaxial cables and
microwave radio relay links
International: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean), 1 1ntersputnik
(Atlantic Ocean region), and 1 Arabsat (inoperative);
coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 19 (5 are inactive),
FM 51, shortwave 4 (1998)
Television broadcast stations: 13 (1997)
Internet country code: .iq
Internet Service Providers (ISPs): 1 (2000)
Internet users: 12,500(2001)','ea838df52408d46dc7ab88580c3d55039b525a54067acb5c68a324b14dd530b9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1583fcf2b6a270eb016cd47138e379a2d5f658b15863c75a45ea6e40d005d19b',2002,'IE','Ireland','communications',676,'Telephones - main lines in use: 1 .59 million (2001 )
Telephones - mobile cellular: 2 million (2001)
Telephone system:
general assessment: modern digital system using
cable and microwave radio relay
domestic: microwave radio relay
international: satellite earth station - 1 1ntelsat (Atlantic
Ocean)
Radio broadcast stations: AM 9, FM 106,
shortwave 0 (1998)
Television broadcast stations: 4 (many low-power
repeaters) (2001)
Internet country code: ,ie
Internet Service Providers (ISPs): 22 (2000)
Internet users: 1.25 million (2001)
Telephones - main lines in use: 61 ,152 (1999)
Telephones - mobile cellular: 3,053 (1996)
Telephone system:
general assessment: services are adequate and
being improved; facilities provide radiotelephone and
telegraph, coastal radio, aeronautical radio, and
international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and
Guam; satellite earth station - 1 1ntelsat (Pacific
Ocean); international radio communication service
Radio broadcast stations: AM 8, FM 19,
shortwave 28 (1998)
Television broadcast stations: 3 (all in the Port
Moresby area)
note: additional stations at Mt. Hagen, Goroka, Lae,
and Rabaul are planned (2 002)
Internet country code: .pg
Internet Service Providers (ISPs): 3 (2000)
Internet users: 135,000(2001)','37adab918aed168acbec34ae1a9677744bf2d507183c9d036f94b9b6d1d4ee9f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63f49f4871b473ae425a0d3e00118f980b05ec2e6ee8e10600c022f89788e5fc',2002,'TN','Tunisia','communications',686,'Telephones - main lines in use: 25 million (1999)
Telephones - mobile cellular: 20.5 million (1999)
Telephone system:
general assessment: modern, well developed, fast;
fully automated telephone, telex, and data services
domestic: high-capacity cable and microwave radio
relay trunks
international: satellite earth stations - 3 Intelsat (with a
total of 5 antennas - 3 for Atlantic Ocean and 2 for
Indian Ocean), 1 1nmarsat (Atlantic Ocean region),
and NA Eutelsat; 21 submarine cables
Radio broadcast stations: AM about 100, FM
about 4,600, shortwave 9 (1998)
Television broadcast stations: 358 (plus 4,728
repeaters) (1995)
Internet country code: .it
Internet Service Providers (ISPs): 93 (Italy and
Holy See) (2000)
Internet users: 19.25 million (2001)','9a8beb2ab0d5dde606b35cbd1554bd2ea7ee5ee89ccafe8a2eaeeb1ca694de13','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a87b576104b3bc632e4df18b1749069845b60327ecf88b9483ba7b104e9fbf5d',2002,'JM','Jamaica','communications',695,'Telephones - main lines in use: 353,000 (1996)
Telephones - mobile cellular: 54,640 (1996)
Telephone system:
general assessment: fully automatic domestic
telephone network
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 10, FM 13,
shortwave 0 (1998)
Television broadcast stations: 7 (1997)
Internet country code: .jm
Internet Service Providers (ISPs): 21 (2000)
Internet users: 60,000 (2000)','a46ca732bfcfbcc79e5714c6e630b33d63a535c287720de1eabd1ca161906537','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcebd8fe997631f0a5cce22ede757395d64155fb9dd3f388825613fed10785f1',2002,'IS','Iceland','communications',700,'Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: there is one radio and meteorological station
(1998)
Internet Service Providers (ISPs): 13 (Jan Mayen
and Svalbard) (2000)','82eee145af6860fcb5c09989c5ccf1a3babe404c2b358e1dab367766e602c431','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('defc1b81a37ed25cbf48b93d085d5719bbbd5300dae57078e8ad566753dd2d38',2002,'MH','Marshall Islands','communications',706,'Telephone system:
general assessment: 13 outgoing and 10 incoming
commercial lines; adequate telecommunications
domestic: 60-channel submarine cable (broken in
January 2002), 22 DSN circuits by satellite, Autodin
with standard remote terminal, digital telephone
switch, Military Affiliated Radio System (MARS
station), UHFA/HF air-ground radio, a link to the
Pacific Consolidated Telecommunications Network
(PCTN) satellite
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Television broadcast stations: commercial
satellite television system, with 16 channels (1997)
Internet Service Providers (ISPs): NA','c81782ae3998f1570aaa1c8ae929e067a05385db49c83b3e88f420fc75c7b04c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76d5e7d58e0c2be5c847f8957626d5734ded55285df27539ecb26fdf064766e1',2002,'KZ','Kazakhstan','communications',717,'Telephones - main lines in use: 1.92 million (2001)
Telephones - mobile cellular: 400,000 (2001)
Telephone system:
general assessment: service is poor; equipment
antiquated
domestic: intercity by landline and microwave radio
relay; mobile cellular systems are available in most of
international: international traffic with other former
Soviet republics and China carried by landline and
microwave radio relay; with other countries by satellite
and by the T rans-Asia-Europe (TAE) fiber-optic cable;
satellite earth stations - 2 Intelsat
Radio broadcast stations: AM 60, FM 17,
shortwave 9 (1998)
Television broadcast stations: 12 (plus nine
repeaters) (1998)
Internet country code: .kz
Internet Service Providers (ISPs): 10 (with their
own international channels) (2001)
Internet users: 85,000(2001)','b0c4be735115deb7a2c42f754690c749f9125ba135db8e77af5667f99e29ff39','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f9ab5fc157d9861b194beb35b82e983fafe78929206cc01dd6d11636b1d6f20',2002,'KE','Kenya','communications',726,'Telephones - main lines in use: 310,000 (2001)
Telephones - mobile cellular: 540,000 (2001)
Telephone system:
general assessment: unreliable; little attempt to
modernize except for service to business
domestic: trunks are primarily microwave radio relay;
business data commonly transferred by a very small
aperture terminal (VSAT) system
international: satellite earth stations - 4 Intelsat
Radio broadcast stations: AM 24, FM 18,
shortwave 6 (2001)
Television broadcast stations: 8 (2002)
276
Kenya (continued)
Internet country code: .ke
Internet Service Providers (ISPs): 65 (2001)
Internet users: 250,000(2001)','27a68558ca60f5d1b5727cafba9f3402b0dbbb2530f385d6eb02d6501573acdc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0aeaa5e78d304027f315ce241e93088d023e7d77cd02b9153f324284dedb28a',2002,'KI','Kiribati','communications',732,'Telephones • main lines In use: 3,800 (1999)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
note: Kiribati is being linked to the Pacific Ocean
Cooperative Telecommunications Network, which
should improve telephone service
Radio broadcast stations: AM 1 , FM 1 , shortwave 1
note: the FM and shortwave stations may be inactive
(2002)
Television broadcast stations: 1 (not reported to
be active) (2002)
Internet country code: .ki
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 ,000 (2000)
Telephones • main lines in use: 1.1 million (1997)
Telephones - mobile cellular: NA
Telephone system:
genera! assessment: NA
domestic: NA
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) and 1 Russian (Indian Ocean region); other
international connections through Moscow and Beijing
Radio broadcast stations: AM 16, FM 14,
shortwave 12 (1999)
Television broadcast stations: 38 (1999)
Internet country code: .kp
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: 24 million (2000)
Telephones - mobile cellular: 28 million
(September 2000)
Telephone system:
general assessment: excellent domestic and -
international services
domestic: NA
international: fiber-optic submarine cable to China; the
Russia-Korea-Japan submarine cable; satellite earth
stations - 3 Intelsat (2 Pacific Ocean and 1 1ndian
Ocean) and 1 1nmarsat (Pacific Ocean region)
Radio broadcast stations: AM 104, FM 136,
shortwave 5 (2001)
Television broadcast stations: 121 (plus 850
repeater stations and the eight-channel American
Forces Korea Network) (1999)
Internet country code: .kr
Internet Service Providers (ISPs): 1 1 (2000)
Internet users: 22.23 million (2001)','7e340f1a222ea650332e7c80e7ca85ac96f11d6496eace1e7eeedc2752e0847e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11f28b3de2959c16a8a3c625c734024c3dc1078fb1572c4f42f8171aad6751d3',2002,'KG','Kyrgyzstan','communications',740,'Telephones - main lines in use: 351 ,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poorly developed; about
100,000 unsatisfied applications for household
telephones
domestic: principally microwave radio relay; one
cellular provider, probably limited to Bishkek region
international: connections with other CIS countries by
landline or microwave radio relay and with other
countries by leased connections with Moscow
international gateway switch and by satellite; satellite
earth stations - 1 1ntersputnik and 1 1ntelsat;
connected internationally by the Trans-Asia-Europe
(TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater
stations), FM 14, shortwave 2 (1998)
Television broadcast stations: NA (repeater
stations throughout the country relay programs from
Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Internet country code: .kg
Internet Service Providers (ISPs): NA
Internet users: 51,600(2001)','a8a38c209ba48b421c2000634a0aa157c9f388e2dd1da2d8edeacbe7c02ed088','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce48c3a81332cbd7172eab4129e3ba3f61a39acd9ee7534cfbf44db27c633eff',2002,'LB','Lebanon','communications',751,'Telephones - main lines in use: 700,000 (1999)
Telephones - mobile cellular: 580,000 (1999)
Telephone system:
general assessment: telecommunications system
severely damaged by civil war; rebuilding well
underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean) (erratic
operations); coaxial cable to Syria; microwave radio
relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 20, FM 22,
shortwave 4 (1998)
Television broadcast stations: 15 (plus 5
repeaters) (1995)
Internet country code: Jb
Internet Service Providers (ISPs): 22 (2000)
Internet users: 300,000(2001)','1aca0d27cb1383bb7ed89077f18a3c5a4049602a8f7028e8686d54586ce2dff5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e929105f824af4ee2a9163db83b54110692f2561f65754deecc956e7c84b93ec',2002,'ZA','South Africa','communications',756,'Telephones - main lines in use: 22,200 (2000)
Telephones - mobile cellular: 21,600 (2000)
Telephone system:
general assessment: rudimentary system
domestic : consists of a few landlines, a small
microwave radio relay system, and a minor
radiotelephone communication system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 2, shortwave 1
(1998)
Television broadcast stations: 1 (2000)
Internet country code: .Is
Internet Service Providers (ISPs): 1 (2000)
Internet users: 4,000 (2000)
Telephones - main lines in use: 6,700 (2000)
Telephones - mobile cellular: 0 (1998)
Telephone system:
general assessment: telephone and telegraph service
via microwave radio relay network; main center is
Monrovia
domestic: NA
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 0, FM 7, shortwave2
(2001)
Television broadcast stations: 1 (plus four
low-power repeaters) (2001)
Internet country code: Jr
Internet Service Providers (ISPs): 2 (2001)
Internet users: 500 (2000)
Telephones - main lines in use: more than 5
million (2001)
Telephones - mobile cellular: 7.06 million (2001)
Telephone system:
general assessment: the system is the best
developed and most modern in Africa
domestic: consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, radiotelephone communication
stations, and wireless local loops; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria
international: 2 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean)
Radio broadcast stations: AM 14, FM 347 (plus
243 repeaters), shortwave 1 (1998)
Television broadcast stations: 556 (plus 144
network repeaters) (1997)
Internet country code: .za
Internet Service Providers (ISPs): 150 (2001)
Internet users: 2.4 million (2001)
Telephone system:
general assessment: NA
domestic: NA
international: coastal radiotelephone station at
Grytviken
Radio broadcast stations: none
Television broadcast stations: 0 (1997)
Internet country code: ,gs','9cf302610e2b4c1ef7f522fc151d9d04d61c1c2ab3f05db1abb0856909fcc5a6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41172d55beefb031b3a03126292186e438ee98a29598ce92b165c95434864230',2002,'LY','Libya','communications',768,'Telephones - main lines in use: 380,000 (1996)
Telephones - mobile cellular: NA
Telephone system:
general assessment: telecommunications system is
being modernized; mobile cellular telephone system
became operational in 1996
302
Libya (continued)
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations - 4 Intelsat,
NA Arabsat, and NA Intersputnik; submarine cables to
France and Italy; microwave radio relay to Tunisia and
Egypt; tropospheric scatter to Greece; participant in
Medarabtel (1999)
Radio broadcast stations: AM 17, FM4,
shortwave 3 (1998)
Television broadcast stations: 12 (plus one
low-power repeater) (1998)
Internet country code: Jy
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000(2001)','807961dff08d1102a396b81f931a9b554e85b459c7d6899654c0cd9dc1663b88','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5ac4e77db19053f56d9a9dedf6c773f517e9fb9bae3e8fca2eb73b9fec800c9',2002,'LT','Lithuania','communications',780,'Telephones ■ main lines in use: 20,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
general assessment: automatic telephone system
domestic: NA
international: linked to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: AM 0, FM 4, shortwave 0
(1998)
Television broadcast stations: NA (linked to Swiss
networks) (1997)
Internet country code: .li
Internet Service Providers (ISPs): 44
(Liechtenstein and Switzerland) (2000)
Internet users: NA
Telephones - main lines in use: 1 .142 million
(2001)
Telephones • mobile cellular: 500,000 (2001)
Telephone system:
general assessment: inadequate, but is being
modernized to provide an improved international
capability and better residential access
domestic: a national, fiber-optic cable, interurban, trunk
system is nearing completion; rural exchanges are
being improved and expanded; mobile cellular systems
are being installed; access to the Internet is available;
still many unsatisfied telephone subscriber applications
international: landline connections to Latvia and
Poland; major international connections to Denmark,
Sweden, and Norway by submarine cable for further
transmission by satellite
Radio broadcast stations: AM 29, FM 142,
shortwave 1 (2001)
Television broadcast stations: 27
note: Lithuania has approximately 27 broadcasting
stations, but may have as many as 100 transmitters,
including repeater stations (2001)
Internet country code: .It
Internet Service Providers (ISPs): 32 (2001 )
Internet users: 341,000(2001)','65b292a324ec8ec43164a07397488389e4ec6ef5e8d5190ca4af1950794a696c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('959f8a6fbd2c080c4256da9d317d397273750ec99c252301e20083660dc636af',2002,'KM','Comoros','communications',793,'Telephones - main lines in use: 55,000 (2000)
Telephones - mobile cellular: 63,100 (2000)
Telephone system:
general assessment: system is above average for the
region
domestic: open-wire lines, coaxial cables, microwave
radio relay, and tropospheric scatter links connect
regions
international: submarine cable to Bahrain; satellite
earth stations - 1 1ntelsat (Indian Ocean) and 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 2 (plus a number of
repeater stations), FM 9, shortwave 6 (2001)
Television broadcast stations: 1 (plus 36
repeaters) (2001)
Internet country code: .mg
Internet Service Providers (ISPs): 2 (2000)
Internet users: 30,000 (2000)','25a35bc333adcf4b2a0d16c4af73f3521d8a941c3aa873b6faea8fe283561e04','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e149acdba91516359248b158a1726b93bdd7a468a4758e515df34dedae001d8',2002,'MW','Malawi','communications',801,'Telephones • main lines in use: 38,000 (1999)
Telephones • mobile cellular: 49,000 (2000)
Telephone system:
general assessment: NA
domestic: system employs open-wire lines,
microwave radio relay links, and radiotelephone
communications stations
international: satellite earth stations • 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 9, FM 5 (plus 15
repeater stations), shortwave 2 (plus a third station
held in standby status) (2001)
Television broadcast stations: 1 (2001)
Internet country code: .mw
Internet Service Providers (ISPs): 7 (2001 )
Internet users: 15,000(2000)
Telephones - main lines in use: 4.6 million (2000)
Telephones - mobile cellular: 5 million (2000)
Telephone system:
general assessment: modern system; international
service excellent
domestic: good intercity service provided on
Peninsular Malaysia mainly by microwave radio relay;
adequate intercity microwave radio relay network
between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong,
and Singapore; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean) (2001)
Radio broadcast stations: AM 35, FM 391 ,
shortwave 15(2001)
Television broadcast stations: 1 (plus 15
high-power repeaters) (2001)
Internet country code: .my
Internet Service Providers (ISPs): 7 (2000)
Internet users: 4.1 million (2001)','711fea36b0c49462724a56cdf43cea5ea3d023844b25f2f504299a816c5e1e19','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c8a315ea15e0a5cab572a7f70a4ee829169e2d4ca96f80fcd7ac0c52b6b2e6',2002,'MV','Maldives','communications',810,'Telephones - main lines in use: 21,000 (1999)
Telephones - mobile cellular: 1 ,290 (1 997)
Telephone system:
general assessment: minimal domestic and
international facilities
domestic: interatoll communication through
microwave links; all inhabited islands are connected
with telephone and fax service
international: satellite earth station - 3 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave 1
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .mv
Internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000(2001)','af66001deb645f47549dd8029c8024729c622317d88cefca546298ec7d795299','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd660dbdf3ef3c69c974d527d597ac3a4466b36866d73cd10505246f63968fdc',2002,'ML','Mali','communications',818,'Telephones - main lines in use: 45,000 (2000)
Telephones - mobile cellular: 40,000 (2001)
Telephone system:
general assessment: domestic system unreliable but
improving; provides only minimal service
domestic: network consists of microwave radio relay,
open wire, and radiotelephone communications
stations; expansion of microwave radio relay in
progress
international: satellite earth stations - 2 Intelsat
(1 Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 1, FM 28,
shortwave 1
note: the shortwave station in Bamako has seven
frequencies and five transmitters and relays
broadcasts for China Radio International (2001)
Television broadcast stations: 1 (plus repeaters)
(2001)
Internet country code: .ml
Internet Service Providers (ISPs): 13 (2001 )
Internet users: 10,000(2000)
Telephones - main lines in use: 187,000 (1997)
Telephones - mobile cellular: 17,691 (1997)
Telephone system:
general assessment: automatic system satisfies
normal requirements
domestic: submarine cable and microwave radio relay
between islands
international: 2 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 18,
shortwave 6 (1999)
Television broadcast stations: 6 (2000)
Internet country code: ,mt
Internet Service Providers (ISPs): 2 (2000)
Internet users: 40,000 (2000)
Telephones - main lines in use: 51 ,000 (1 999)
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: landline, telefax, mobile cellular telephone
system
international: fiber-optic cable, microwave radio relay,
satellite earth station, submarine cable
Radio broadcast stations: AM 1 , FM 1 , shortwave 0
(1998)
Man, Isle Of (continued)
Television broadcast stations: 0 (receives
broadcasts from the UK and satellite) (1999)
Internet country code: .im
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones - main lines in use: 4,186 (2001)
Telephones - mobile cellular: 489 (2001)
Telephone system:
general assessment: digital switching equipment;
modern services include telex, cellular, internet,
international calling, caller ID, and leased data circuits
domestic: Majuro Atoll and Ebeye and Kwajalein
islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); US Government satellite
communications system on Kwajalein (2001)
Radio broadcast stations: AM 2, FM 1 , shortwave 0
note: additionally, the US Armed Forces Radio and
Television Services (Central Pacific Network) operate
one FM and one AM station on Kwajalein (2002)
Television broadcast stations: 2 (both are US
military stations) (2002)
331
Marshall Islands (continued)
Internet country code: .mh
Internet Service Providers (ISPs): 1 (2002)
Internet users: 537(2001)','fcce39906b8cb0c6316ab14e9dda4d97fcf1045c9bfeb59e673f6495a14d5ac3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ab1030b8c60bcd7378353116a55acf15f996d57af2cc6451199d4dc9bf8a2e',2002,'MR','Mauritania','communications',832,'Telephones - main lines in use: 26,500 (2001)
Telephones - mobile cellular: 35,000 (2001)
Telephone system:
general assessment: limited system of cable and
open-wire lines, minor microwave radio relay links,
and radiotelephone communications stations
(improvements being made)
domestic: mostly cable and open-wire lines; a recently
completed domestic satellite telecommunications
system links Nouakchott with regional capitals
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 2 Arabsat
Radio broadcast stations: AM 1 , FM 14,
shortwave 1 (2001)
Television broadcast stations: 1 (2002)
Internet country code: ,mr
Internet Service Providers (ISPs): 5 (200 1 )
Internet users: 7,500(2001)','0b1d2963ff59e62c996cc5a06bdb361ca3668e0e0bb87f53cda58910ec5ffda4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f0b0d34639966b06791f894699c3b461567b37e58ac9abae50e9a5926a4b47',2002,'MU','Mauritius','communications',841,'Telephones • main lines in use: 245,000 (1998)
Telephones ■ mobile cellular: 60,482 (1998)
Telephone system:
general assessment: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station • 1 1ntelsat (Indian
Ocean); new microwave link to Reunion; HF
radiotelephone links to several countries
Radio broadcast stations: AM 5, FM 9, shortwave2
(1998)
Television broadcast stations: 2 (plus several
repeaters) (1997)
Internet country code: .mu
Internet Service Providers (ISPs): 2 (2000)
Internet users: 87,000(2001)','8df48eac1638c15d2424dddab961613ca156b357a63802ac2bbac20d34662503','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe0220f1a41ae8e2f7a6076617c5c26e2c766a22e13194bd63880dda28124c0a',2002,'YT','Mayotte','communications',846,'Telephones - main lines in use: 9,314 (1997)
Telephones - mobile cellular: 0 (2000)
Telephone system:
general assessment: small system administered by
French Department of Posts and T elecommunications
domestic: NA
international: microwave radio relay and HF
radiotelephone communications to Comoros (2001 )
339
Mayotte (continued)
Radio broadcast stations: AM 1 , FM 5, shortwave 0
(2001)
Television broadcast stations: 3 (2001)
Internet country code: .yt
Internet Service Providers (ISPs): NA
Internet users: NA','cbf48df27bc73e32eefa0ca3fa9d88d9a6960f791d40f4bdf885c6764cce2ccc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('906b9b37b916d05b5d0f8e9839e2c875aeebb5a12757b4f4db16e60965b74dd1',2002,'FM','Micronesia, Federated States of','communications',858,'Telephones - main lines in use: 627,000 (1997)
Telephones • mobile cellular: 2,200 (1997)
Telephone system:
general assessment: inadequate, outmoded, poor
service outside Chisinau, some effort to modernize is
under way
domestic : new subscribers face long wait for service;
mobile cellular telephone service being introduced
international: service through Romania and Russia via
landline; satellite earth stations - Intelsat, Eutelsat,
and Intersputnik
Radio broadcast stations: AM 7, FM 50,
shortwave 3 (1998)
Television broadcast stations: 1 (plus 30
repeaters) (1995)
Internet country code: .md
Internet Service Providers (ISPs): 2 (1999)
Internet users: 15,000(2000)','8a687954fe4c390409f6db8d56a59641550664c8695a1aaf82f07824a91cfe00','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c27b9ff9a5e1b546854adb05bf61204f33c8e4ffa139b6a1d6baaf89221687',2002,'MC','Monaco','communications',864,'Telephones - main lines in use: 31,027 (1995)
Telephones - mobile cellular: NA
Telephone system:
general assessment: modern automatic telephone
system
domestic: NA
international: no satellite earth stations; connected by
cable into the French communications system
Radio broadcast stations: AM 1, FM NA,
shortwave 8 (1998)
Television broadcast stations: 5 (1998)
Internet country code: .me
Internet Service Providers (ISPs): 2 (2000)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains, grassy
steppe, mountains in west and southwest; Gobi
Desert in south-central
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil (Huyten Orgil)
4,374 m
Natural resources: oil, coal, copper, molybdenum,
tungsten, phosphates, tin, nickel, zinc, wolfram,
fluorspar, gold, silver, iron, phosphate
Land use:
arable land: 1%
permanent crops: 0%
other: 99% (1998 est.)
Irrigated land: 840 sq km (1998 est.)
Natural hazards: dust storms, grassland and forest
fires, drought, and "zud", which is harsh winter
conditions
Environment - current issues: limited natural fresh
water resources in some areas; policies of the former
Communist regime promoting rapid urbanization and
industrial growth have raised concerns about their
negative effects on the environment; the burning of
soft coal in power plants and the lack of enforcement
of environmental laws have severely polluted the air in
Ulaanbaatar; deforestation, overgrazing, the
converting of virgin land to agricultural production
have increased soil erosion from wind and rain;
desertification and mining activities have also had a
deleterious effect on the environment
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species. Environmental Modification, Hazardous
Wastes, Law of the Sea. Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; strategic location
between China and Russia
internet users: NA','4087e4ff2b3ad282c4be2462b5390dbab74ada9a8b8877237a68d8b80050dbf9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a19e77f250920d1f169c9d98b9e51448f7059b01e5e9f0ae47b7ec8156e160ec',2002,'MS','Montserrat','communications',871,'Telephones - main lines in use: 4,000 (1997)
Telephones - mobile cellular: 70 (1994)
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 2, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .ms
Internet Service Providers (ISPs): 17 (2000)
Internet users: NA','1130273b2c4e01f95d2cc506bd7a9595904e31ffe41655f5aae85cf500ef035d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de775ae7c60a8d68b4794fdbe32888fed3cc209919e3601ac88c9c17a9641881',2002,'NA','Namibia','communications',881,'Telephones - main lines in use: 11 0,200 (2000)
Telephones - mobile cellular: 82,000 (2000)
Telephone system:
general assessment: good system; about 6
telephones for each 1 00 persons
domestic: good urban services; fair rural service;
microwave radio relay links major towns; connections
to other populated places are by open wire; 100%
digital
international: fiber-optic cable to South Africa,
microwave radio relay link to Botswana, direct links to
other neighboring countries; connected to Africa ONE
and South African Far East (SAFE) submarine cables
through South Africa; satellite earth stations - 4
Intelsat (2002)
Radio broadcast stations: AM 2, FM 39,
shortwave 4 (2001)
Television broadcast stations: 8 (plus about 20
low-power repeaters) (1997)
Internet country code: .na
Internet Service Providers (ISPs): 2 (2000)
Internet users: 30,000(2001)
Telephones - main lines in use: 2,000 (1996)
Telephones - mobile cellular: 450 (1994)
Telephone system:
general assessment: adequate local and international
radiotelephone communication provided via
Australian facilities
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 1 (1997)
Internet country code: .nr
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','f7b35fe7f11c0a16e847c032ed764516d69ff5daa79730f72921e2b2507a146c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2860370171240a9b2b784ba3bdd891dd78f789922f7061664a289ea7e4127f8',2002,'NL','Netherlands','communications',885,'Telephones - main lines in use: 236,816
(January 2000)
Telephones - mobile cellular: NA
Telephone system:
general assessment: poor telephone and telegraph
service; fair radiotelephone communication service
and mobile cellular telephone network
domestic: NA
international: radiotelephone communications;
microwave landline to India; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 5, shortwave 1
(January 2000)
Television broadcast stations: 1 (plus 9 repeaters)
(1998)
Internet country code: .np
Internet Service Providers (ISPs): 6 (2000)
Internet users: 50,000(2001)
Telephones - main lines in use: 9,132,400 (1999)
Telephones • mobile cellular: 4,081,891
(April 1999)
Telephone system:
general assessment: highly developed and well
maintained
domestic: the existing system of multi-conductor
cables is gradually being replaced by fiber-optic
cables; the density of cellular telephone traffic is
rapidly increasing and further modernization of the
system is expected in 2001 , with the introduction of
the third generation of the Global System for Mobile
Communications (GSM)
international: 5 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean), 1 Eutelsat, and 1 1nmarsat (Atlantic and
Indian Ocean regions) (1996)
Radio broadcast stations: AM 4, FM 58,
shortwave 3 (1998)
Television broadcast stations: 21 (plus 26
repeaters) (1995)
Internet country code: .nl
Internet Service Providers (ISPs): 52 (2000)
Internet users: 8.7 million (2001)
Telephones - main lines in use: 76,000 (1995)
Telephones - mobile cellular: 13,977 (1996)
Telephone system:
general assessment: generally adequate facilities
domestic: extensive interisland microwave radio relay
links
international: submarine cables - 2; satellite earth
stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4, shortwave 0
(1998)
Television broadcast stations: 3 (there is also a
cable service which supplies programs received from
various US satellite networks and two Venezuelan
channels) (1997)
Internet country code: .an
Internet Service Providers (ISPs): 6
Internet users: 2,000 (2000)','a2ce61f20cd7d3e63f8f65f62d5dfd41754e5fc77b3dd9799011ebb045f926b9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3885e9f5a8bdcc890a8b6b2dd4eec9c41512c92af7b9b5fb7077142a16deee8d',2002,'VU','Vanuatu','communications',901,'Telephones - main lines in use: 1 .92 million (2000)
Telephones - mobile cellular: 2.2 million (2000)
Telephone system:
general assessment: excellent domestic and
international systems
domestic: NA
international: submarine cables to Australia and Fiji;
satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 124, FM 290,
shortwave 4 (1998)
Television broadcast stations: 41 (plus 52
medium-power repeaters and over 650 low-power
repeaters) (1997)
Internet country code: ,nz
Internet Service Providers (ISPs): 36 (2000)
Internet users: 1.78 million (2001)
Telephones - main lines in use: 140,000 (1996)
Telephones - mobile cellular: 7,911 (1997)
Telephone system:
general assessment: inadequate system being
upgraded by foreign investment
domestic: low-capacity microwave radio relay and
wire system being expanded; connected to Central
American Microwave System
international: satellite earth stations • 1 1ntersputnik
(Atlantic Ocean region) and 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 63, FM 32,
shortwave 1 (1998)
Television broadcast stations: 3 (plus seven
low-power repeaters) (1997)
Internet country code: ,ni
Internet Service Providers (ISPs): 3 (2000)
Internet users: 20,000 (2000)
Telephones - main lines in use: 5,500 (1998)
Telephones - mobile cellular: 310 (2000)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 1
(2002)
Television broadcast stations: 1 (2002)
Internet country code: ,vu
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)
Telephones • main lines in use: 2,6 million
(however, 3,500,000 have been installed) (1998)
Telephones • mobile cellular: 2 million (1998)
Telephone system:
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth
stations; recent substantial improvement in telephone
service in rural areas; substantial increase in
digitalization of exchanges and trunk lines; installation
of a national interurban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador,
Peru, and Bolivia in the construction of an
international fiber-optic network
Radio broadcast stations: AM 201 , FM NA (20 in
Caracas), shortwave 11 (1998)
Television broadcast stations: 66 (plus 45
repeaters) (1997)
Internet country code: ,ve
Internet Service Providers (ISPs): 16 (2000)
Internet users: 950,000(2001)
Telephones • main lines in use: 2.6 million (2000)
Telephones - mobile cellular: 730,155 (2000)
Telephone system:
general assessment: Vietnam is putting considerable
effort into modernization and expansion of its
telecommunication system, but its performance
continues to lag behind that of its more modem
neighbors
domestic: all provincial exchanges are digitalized and
connected to Hanoi, Da Nang, and Ho Chi Minh City
by fiber-optic cable or microwave radio relay
networks; since 1991, main lines in use have been
substantially increased and the use of mobile
telephones is growing rapidly
554
Vietnam (continued)
international: satellite earth stations - 2 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 65, FM 7,
shortwave 29 (1999)
Television broadcast stations: at least 7 (plus 13
repeaters) (1998)
Internet country code: .vn
Internet Service Providers (ISPs): 5 (2000)
Internet users: 1 60,000 (2001 )','37255d4299bca658050109cb4f1ad71161ee54850254aa866d5ed552e8b9b093','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5707abea86cf18adf165d2b557f740cbdf43861e8398f5f4dc80a5153bc33222',2002,'NE','Niger','communications',903,'domestic: wire, radiotelephone communications, and
microwave radio relay; domestic satellite system with
3 earth stations and 1 planned
international: satellite earth stations • 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 5, FM 6, shortwave 4
(2001)
Television broadcast stations: 3 (plus seven
low-power repeaters) (2002)
Internet country code: .ne
Internet Service Providers (ISPs): 1 (2000)
Internet users: 3,000 (2000)','d5a69a9025aaab2aa92d8542680e7fd623b2e336f69164909f48f8b314319bd1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afeadd788886c1df50f0278b958bbf7cd0c8d1461b78c862483bc1c0d752baa',2002,'MP','Northern Mariana Islands','communications',917,'Telephones - main lines in use: 21,000 (1996)
Telephones • mobile cellular: 1,200 (1995)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth stations - 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM2, FM 3, shortwave 1
(1998)
Television broadcast stations: 1 (on Saipan and
one station planned for Rota; in addition, two cable
services on Saipan provide varied programming from
satellite networks) (1997)
Internet country code: .mp
Internet Service Providers (ISPs): 1 (2001)
Internet users: NA
Telephone system:
general assessment: satellite communications; 1
DSN circuit off the Overseas Telephone System
(OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA,
shortwave NA
note: Armed Forces Radio/Television Service
(AFRTS) radio service provided by satellite (1998)
Television broadcast stations: 0 (1997)','8744cbdbfb8a22eed1880a097a38b5e5c431918df788d24fd426750896b31cd7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed354ed20eaac17bdb3cdc408b0c8b31efa620a3aacafde6efb3525892457e9a',2002,'PK','Pakistan','communications',927,'Telephones - main lines in use: 2.861 million
(March 1999)
Telephones - mobile cellular: 1 58,000 (1 998)
Telephone system:
general assessment: the domestic system is
mediocre, but improving; service is adequate for
government and business use, in part because major
businesses have established their own private
systems; since 1988, the government has promoted
investment in the national telecommunications system
on a priority basis, significantly increasing network
capacity; despite major improvements in trunk and
urban systems, telecommunication services are still
not readily available to the majority of the rural
population
domestic: microwave radio relay, coaxial cable,
fiber-optic cable, cellular, and satellite networks
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean); 3 operational
international gateway exchanges (1 at Karachi and 2
at Islamabad); microwave radio relay to neighboring
countries (1999)
Radio broadcast stations: AM 27, FM 1 ,
shortwave 21 (1998)
Television broadcast stations: 22 (plus seven
low-power repeaters) (1997)
Internet country code: ,pk
Internet Service Providers (ISPs): 30 (2000)
Internet users: 1.2 million (2000)
397
Pakistan (continued)','4f3291da4aa9fab279741414443318b0387f1247d1b194726c6d2a4531153941','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33172cbe9a2164796c642e18677f0d60e6d066d675231153c7f0aae56a20de2d',2002,'PW','Palau','communications',936,'Telephones - main lines in use: 6,700 (2002)
Telephones - mobile cellular: 1 ,000 (2002)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 4, shortwave 1
(2002)
Television broadcast stations: 1 (1997)
Internet country code: ,pw
Internet Service Providers (ISPs): 1 (2002)','af9b99e973a57f66219ecbde5e69f21c7c40bce90bef994e4552673054943104','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526c60c0be87962ad2ba9ba3a80455663d3cdfac9c548f3dd564b3ec1373dacd',2002,'PA','Panama','communications',944,'Telephones - main lines in use: 396,000 (1997)
Telephones - mobile cellular: 17,000 (1997)
Telephone system:
general assessment: domestic and international
facilities well developed
domestic: NA
international: 1 coaxial submarine cable; satellite
earth stations - 2 Intelsat (Atlantic Ocean); connected
to the Central American Microwave System
Radio broadcast stations: AM 101, FM 134,
shortwave 0 (1998)
Television broadcast stations: 38 (including
repeaters) (1998)
Internet country code: .pa
Internet Service Providers (ISPs): 6 (2000)
Internet users: 45,000 (2000)','581e1e8aac1a2072efb47ed4f8bd118a27fc378905dea0b158173c283000698e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26419fd36efbc30e75e8ab4cebd32846b4e580b148d386f78a66ee43ea48fadc',2002,'AR','Argentina','communications',956,'Telephones - main lines in use: 290.475 (2001)
Telephones - mobile cellular: 510,000 (2001)
Telephone system:
general assessment: meager telephone service;
principal switching center is Asuncion
domestic: fair microwave radio relay network
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 46, FM 27,
shortwave 6 (three inactive) (1998)
Television broadcast stations: 4 (2001)
Internet country code: ,py
Internet Service Providers (ISPs): 4 (2000)
Internet users: 20,000 (2000)','5d4b55905cc6791e378f53a5f1ccf1e5b2cd8e63825d9e7f4061fd50afb0033f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('830a245699571c73f37504e7a988c75e9f656d5998c93ecff7eb45e571baa9d2',2002,'QA','Qatar','communications',972,'Telephones - main lines in use: 142,000 (1997)
Telephones - mobile cellular: 43,476 (1997)
Telephone system:
general assessment: modern system centered in
Doha
domestic: NA
425
Qatar (continued)
international: tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 1ndian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5, shortwave 1
(1998)
Television broadcast stations: 1 (plus three
repeaters) (2001)
Internet country code: .qa
Internet Service Providers (ISPs): 1 (2000)
Internet users: 75,000(2001)','1d1ea81c5077bc2dd15153c79f8056b5b98ca67fb2c2f52201abb5b04c66187d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ffddcc47afbab23990769c67839e08c588377f78cda23ddfd829a75f4d7da2',2002,'UA','Ukraine','communications',984,'Telephones - main lines in use: 30 million (1998)
Telephones - mobile cellular: 2.5 million
(October 2000)
Telephone system:
general assessment: the telephone system has
undergone significant changes in the 1990s; there are
more than 1 ,000 companies licensed to offer
communication services; access to digital lines has
improved, particularly in urban centers; Internet and
e-mail services are improving; Russia has made
progress toward building the telecommunications
infrastructure necessary for a market economy;
however, a large demand for main line service
remains unsatisfied
domestic: cross-country digital trunk lines run from
Saint Petersburg to Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in 60 regional
capitals have modem digital infrastructures; cellular
services, both analog and digital, are available in
many areas; in rural areas, the telephone services are
still outdated, inadequate, and low density
international: Russia is connected internationally by
three undersea fiber-optic cables; digital switches in
several cities provide more than 50,000 lines for
international calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat, Inmarsat,
and Orbita systems
Radio broadcast stations: AM 420, FM 447,
shortwave 56 (1998)
Television broadcast stations: 7,306 (1998)
Internet country code: .ru
Internet Service Providers (ISPs): 35 (2000)
Internet users: 9.2 million (2000)
Telephones - main lines in use: 1 1 ,000 (1999)
Telephones - mobile cellular: 1 1 ,000 (1 999)
note: Rwanda has mobile cellular service between
Kigali and several prefecture capitals (2002)
Telephone system:
general assessment: telephone system primarily
serves business and government
domestic: the capital, Kigali, is connected to the
centers of the prefectures by microwave radio relay
and, recently, by cellular telephone service; much of
the network depends on wire and HF radiotelephone
international: international connections employ
microwave radio relay to neighboring countries and
satellite communications to more distant countries;
satellite earth stations - 1 1ntelsat (Indian Ocean) in
Kigali (includes telex and telefax service)
Radio broadcast stations: AM 0, FM 3 (two main
FM programs are broadcast through a system of
repeaters and the third FM program is a 24 hour BBC
program), shortwave 1 (2002)
Television broadcast stations: NA
Internet country code: ,rw
Internet Service Providers (ISPs): 1 (2000)
Internet users: 5,000(2001)
Telephones - main lines in use: 9.45 million
(April 1999)
Telephones - mobile cellular: 236,000 (1998)
Telephone system;
general assessment: Ukraine''s telecommunication
development plan, running through 2005, emphasizes
improving domestic trunk lines, international
connections, and the mobile cellular system
domestic: at independence in December 1991 ,
Ukraine inherited a telephone system that was
antiquated, inefficient, and in disrepair; more than 3.5
million applications for telephones could not be
satisfied; telephone density is now rising slowly and
the domestic trunk system is being improved; the
mobile cellular telephone system is expanding at a
high rate
international: two new domestic trunk lines are a pari
of the fiber-optic Trans-Asia-Europe (TAE) system
and three Ukrainian links have been installed in the
fiber-optic Trans-European Lines (TEL) project which
connects 18 countries; additional international service
is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in
the Intelsat, Inmarsat, and Intersputnik satellite
systems
Radio broadcast stations: AM 134, FM 289,
shortwave 4 (1998)
Television broadcast stations: at least 33 (plus 21
repeaters that relay broadcasts from Russia) (1997)
Internet country code: .ua
Internet Service Providers (ISPs): 260 (2001 )
Internet users: 750,000(2001)','6abe64c01baef0b3e994ec33d0cfaaabdd9d852b2b5baa6bd31a32928ff4f23f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebf910fe7057c11e99e81e8d82b8070f771f8c6ea724becb46eb7878d3a5e7d1',2002,'UG','Uganda','communications',991,'Telephones - main lines in use: 2,000 (1997)
Telephones ■ mobile cellular: 0 (1997)
Telephone system:
general assessment: can communicate worldwide
domestic: automatic network
international: HF radiotelephone from Saint Helena to
Ascension which is a major coaxial submarine cable
relay point between South Africa, Portugal, and UK ;
satellite earth stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1998)
Television broadcast stations: 0 (1997)
Internet country code: ,sh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Communications - note: Gough Island has a
meteorological station','f12790d4f16ed9efb303ba5990c0d649a2e96d2590a2c0642aaa8d929aa38407','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96bbec5cb030068f69884518e5680171b53e2809a05b9da06084879911b5f83c',2002,'TT','Trinidad and Tobago','communications',997,'Telephones - main lines in use: 17,000 (1997)
Telephones - mobile cellular: 205 (1997)
Telephone system:
general assessment: good interisland and
international connections
domestic: interisland links to Antigua and Barbuda
and Saint Martin (Guadeloupe and Netherlands
Antilles) are handled by VHF/UHF/SHF
radiotelephone
international: international calls are carried by
radiotelephone to Antigua and Barbuda and switched
there to submarine cable or to Intelsat; or carried to
Saint Martin (Guadeloupe and Netherlands Antilles)
by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 3, FM 1 , shortwave 0
(1998)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Internet country code: ,kn
Internet Service Providers (ISPs): 16 (2000)
Internet users: 2,000 (2000)','18a72685c9d95b701194bf573f48bd39703234d480610c32217fe6b2a4fc96e6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb5d7e3792c9cf27fc90423ab82ddf40627ec3c0ed9ee9591af465722fef2f26',2002,'MQ','Martinique','communications',1001,'Radio broadcast stations: AM 2, FM 7 (plus 3
repeaters), shortwave 0 (1998)
Television broadcast stations: 3 (of which two are
commercial stations and one is a community antenna
television or CATV channel) (1997)
Internet country code: ,1c
Internet Service Providers (ISPs): 15 (2000)
Internet users: 5,000 (2000)
Telephones - main lines in use: 4,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone communication with
most countries in the world; 1 earth station in French
domestic satellite system
Radio broadcast stations: AM 1 , FM 4, shortwave 0
(1998)
Television broadcast stations: 0 (there are,
however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Internet country code: .pm
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','f4a676fdabf37bb3f374d2f34102e5e65695c4f48d1f4ada4292d0b7552307ba','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbb61ddd6ed1dd483f29647be2e94c98ebdeb540e41bb45661502069ec587132',2002,'WS','Samoa','communications',1012,'Telephones - main lines in use: 8,183 (1998)
Telephones ■ mobile cellular: 1 ,545
(February 1998)
Telephone system:
general assessment : adequate
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 3, shortwave 0
(1998)
Television broadcast stations: 6 (1997)
Internet country code: .ws
Internet Service Providers (ISPs): 2 (2000)
Internet users: 500 (2000)','e56367b5e1e6980ae546b9879d5c6d7ffa89d09771254f122e7249a57beaf756','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37491c64422aaa8bbc111f3f459944e72036b2c621f75f857ca435e8d58cdb01',2002,'SM','San Marino','communications',1020,'Telephones - main lines in use: 18,000 (1998)
Telephones - mobile cellular: 3,010 (1998)
Telephone system:
general assessment: adequate connections
domestic: automatic telephone system completely
integrated into Italian system
international: connected to Italian international
network
Radio broadcast stations: AM 0, FM 3, shortwave 0
(1998)
Television broadcast stations: 1 (San Marino
residents also receive broadcasts from Italy) (1997)
Internet country code: .sm
Internet Service Providers (ISPs): 2 (2000)
Internet users: NA','5a8225bd277ad5df211cc357ed62d0b39309686a220447ec1786114f056a68c7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('940efaa5f1b1e06c43044696f4eeeaf0b3cde9652db3000066b057bbd01a9b3b',2002,'SA','Saudi Arabia','communications',1029,'Telephones - main lines in use: 3.1 million (1998)
Telephones - mobile cellular: 1 million
note: in 1 998, the government contracted for the
installation of 575,000 additional Group Speciale
Mobile (GSM) cellular telephone lines over 15 months
to raise the total number of subscribers to more than
one million; Riyadh planned to further expand the
GSM system in 1999 by adding an additional one
million lines (1998)
Telephone system:
general assessment: modern system
domestic: extensive microwave radio relay, coaxial
cable, and fiber-optic cable systems
international: microwave radio relay to Bahrain,
Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine cable
to Djibouti, Egypt and Bahrain; satellite earth
stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian
Ocean), 1 Arabsat, and 1 1nmarsat (Indian Ocean
region)
Radio broadcast stations: AM 43, FM 31 ,
shortwave 2 (1998)
Television broadcast stations: 117 (1997)
Internet country code: .sa
Internet Service Providers (ISPs): 42 (2001 )
Internet users: 570,000(2001)','8681bfdcbdc81b9293c8d782c694c14ca354f0058edf59bfc53f73d8a9d0db76','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fe578ae9abd5e8501524894f342b50d8c6410debb9eb5a026c8f7b3dc160052',2002,'SN','Senegal','communications',1037,'Telephones - main lines in use: 234,916 (2001)
Telephones - mobile cellular: 373,965 (2001)
Telephone system:
general assessment: good system
domestic: above-average urban system; microwave
radio relay, coaxial cable and fiber-optic cable in trunk
system
international: 4 submarine cables; satellite eadh
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 14,
shortwave 0 (1998)
Television broadcast stations: 1 (1997)
Internet country code: .sn
Internet Service Providers (ISPs): 15 (2002)
Internet users: 40,000(2001)','90de79f3bff92ed9022353e15fe789b2f32070610b2ca243da314a20fac4915f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6fbee61f653fd9adecd0818784e3632a0a4d2ae505363a1110c70b523c407c4',2002,'SC','Seychelles','communications',1046,'Telephones - main lines in use: 19,635 (1997)
Telephones - mobile cellular: 16,316 (1999)
Telephone system:
general assessment: effective system
domestic: radiotelephone communications between
islands in the archipelago
international: direct radiotelephone communications
with adjacent island countries and African coastal
countries; satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 1 , FIJI 2, shortwave 2
(1998)
Television broadcast stations: 2 (plus 9 repeaters)
(1997)
Internet country code: .sc
Internet Service Providers (ISPs): 1 (2000)
Internet users: 6,000(2001)','828a7f6499992e34d30718a9799f5809f30754fc4b3999f6f4e68d733d334fe9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b45b7ba08aa05717b1d20cb71cc7e66bd6821b7bb9c1e39ffe3b691f1745d01',2002,'SL','Sierra Leone','communications',1054,'Telephones - main lines in use: 25,000 (2001)
Telephones - mobile cellular: 30,000 (2001)
Telephone system:
general assessment: marginal telephone and
telegraph service
domestic: national microwave radio relay trunk
system, made unserviceable by military activities, is
now operating from Freetown to Bo and Kenema
(April 2001)
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 9, shortwave 1
(1999)
Television broadcast stations: 2 (1999)
Internet country code: .si
Internet Service Providers (ISPs): 1 (2000)
Internet users: 20,000(2001)','7a7e83b135bd87ba871c2819e070611e84e622101c0362a2fde8efd4a9ac794d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ade87611940088b28a413f12e9242eb93a5d35d89e8509e365e1ebb29bbee26',2002,'SK','Slovakia','communications',1064,'Telephones - main lines in use: 1,934,558 (1998)
Telephones - mobile cellular: 736,662 (April 1999)
Telephone system:
general assessment: a modernization and
privatization program is increasing accessibility to
telephone service, reducing the waiting time for new
subscribers, and generally improving service quality
domestic: predominantly an analog system that is now
receiving digital equipment and is being enlarged with
fiber-optic cable, especially in the larger cities; mobile
cellular capability has been added
international: three international exchanges (one in
Bratislava and two in Banska Bystrica) are available;
Slovakia is participating in several international
telecommunications projects that will increase the
availability of external services
Radio broadcast stations: AM 15, FM 78,
shortwave 2 (1998)
Television broadcast stations: 38 (plus 864
repeaters) (1995)
Internet country code: .sk
Internet Service Providers (ISPs): 6 (2000)
Internet users: 700,000 (2000)
T ransportation
Railways:
total: 3,660 km
broad gauge: 1 02 km 1 .520-m gauge
standard gauge: 3,507 km 1.435-m gauge (1,505 km
electrified; 1,011 km double-tracked)
narrow gauge: 51 km (46 km 1,000-m gauge; 5 km
0.750-m gauge) (2001)
Highways:
total: 17,710 km
paved: 17,533 km (including 288 km of expressways)
unpaved: 177 km (1998 est.)
Waterways: 172 km (all on the Danube)
Pipelines: petroleum products NA km; natural gas
2,700 km
Ports and harbors: Bratislava, Komarno
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 15,191
GRT/19,489 DWT
ships by type: cargo 3 (2002 est.)
Airports: 34(2001)
Airports - with paved runways:
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437m: 3
914 to 1,523 m: 3
under 914 m:7 (2001)
Airports • with unpaved runways:
total: 17
2,438 to 3,047 m:1
914 to 1,523 m: 9
under 91 4 m: 7 (2001)
Heliports: 1 (2001)','016e2d648c6620a8adba2b7d628535601e8294cf71d21a547a996e7f49b2941e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4bda52d78b215b75d15ec19321fb98388a04f310a5326823608f3cefef55fb5',2002,'SO','Somalia','communications',1072,'Telephones ■ main lines in use: NA
Telephones ■ mobile cellular: NA
Telephone system:
genera! assessment: the public telecommunications
system was almost completely destroyed or
dismantled by the civil war factions; private wireless
companies offer service in most major cities and
charge the lowest international rates on the continent
domestic: local cellular telephone systems have been
established in Mogadishu and in several other
population centers
international: international connections are available
from Mogadishu by satellite (2001)
Radio broadcast stations: AM 0, FM 1 , shortwave 5
(2001)
Television broadcast stations: 3
note: two in Mogadishu; one in Hargeisa (2001)
Internet country code: .so
Internet Service Providers (ISPs): 3 (one each in
Boosaaso, Hargeisa, and Mogadishu) (2000)
Internet users: 200(2000)','cfa8bab66d912e29d12bc6cdfaa1dac2512d67177afea3f6c052d3fb3fc117ad','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('360867c58215506a7053e60a15c6dcb70aa7c7fe5bfe4b41340aec11d8edfb65',2002,'DZ','Algeria','communications',1083,'Telephones - main lines in use: 17.336 million
(1999)
Telephones - mobile cellular: 8.394 million (1999)
Telephone system:
general assessment: generally adequate, modern
facilities; teledensity is 44 main lines for each 100
persons
domestic: NA
international: 22 coaxial submarine cables; satellite
earth stations • 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric scatter to
adjacent countries
Radio broadcast stations: AM 208, FM 715,
shortwave 1 (1998)
Television broadcast stations: 224 (plus 2,105
repeaters)
note: these figures include 11 television broadcast
stations and 88 repeaters in the Canary Islands (1995)
Internet country code: .es
Internet Service Providers (ISPs): 56 (2000)
Internet users: 7.38 million (2001)
Telephones - main lines In use: 494,509 (1998)
Telephones - mobile cellular: 228,604 (1999)
Telephone system:
general assessment: very inadequate domestic
service, particularly in rural areas; likely improvement
with privatization of national telephone company and
encouragement to private investment; good
international service (1999)
domestic: national trunk network consists mostly of
digital microwave radio relay; fiber-optic links now in
use in Colombo area and two fixed wireless local
loops have been installed; competition is strong in
mobile cellular systems; telephone density remains
low at 2.6 main lines per 100 persons (1999)
international: submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian
Ocean) (1999)
Radio broadcast stations: AM 26, FM 45,
shortwave 1 (1998)
Television broadcast stations: 21 (1997)
Internet country code: .Ik
Internet Service Providers (ISPs): 5 (2000)
Internet users: 121,500(2001)','b18fb43d4a757deabc4095e79616be5e55edcc5f86eea2c1c408ee4e8b952a6e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a78c323029bf5d9cbe5a716ae8bd2251eb36182015d97a6f35867dfe526eb09e',2002,'TK','Tokelau','communications',1108,'Telephones - main lines in use: NA
Telephones - mobile cellular: 0 (2001)
Telephone system:
general assessment: adequate
domestic: radiotelephone service between islands
international: radiotelephone service to Samoa;
government-regulated telephone service (TeleTok),
with 3 satellite earth stations, established in 1997
Radio broadcast stations:
note: each atoll has a radio broadcast station of
unknown type that broadcasts shipping and weather
reports (1998)
Internet country code: .tk
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA','1355282c17be4e4ec7b599c44f4d9daf6dac9ed03faa83a2a31b4c252c350217','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47722c751eaf79097ef9f20ce05077870f01de29cf789384daca49a8d7226225',2002,'TM','Turkmenistan','communications',1119,'Telephones - main lines in use: 363,000 (1997)
Telephones - mobile cellular: 4,300 (1998)
Telephone system:
general assessment: pooriy developed
domestic: NA
international: linked by cable and microwave radio
relay to other CIS republics and to other countries by
leased connections to the Moscow international
gateway switch; a new telephone link from Ashgabat
to Iran has been established; a new exchange in
Ashgabat switches international traffic through Turkey
via Intelsat; satellite earth stations - 1 Orbita and 1
Intelsat
Radio broadcast stations: AM 16, FM 8,
shortwave 2 (1998)
Television broadcast stations: 3 (much
programming relayed from Russia and T urkey) (1997)
Internet country code: .tm
Internet Service Providers (ISPs): NA
Internet users: 2,000 (2000)','bb82ac2bbba4f0cd7ed91ba0767df05f282c6d6f1dbd98f4ca6f1239e5d79ca4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a419cc80796f07dd32c8aa92a42c410d569f10c2439f5cf8be984410e982d5e3',2002,'TV','Tuvalu','communications',1129,'Telephones ■ main lines in use: 1 ,000 (1997)
Telephones - mobile cellular: 0 (1994)
Telephone system:
general assessment: serves particular needs for
internal communications
domestic : radiotelephone communications between
islands
international: NA
Radio broadcast stations: AM 1 , FM 0, shortwave 0
(1999)
Television broadcast stations: 0 (1997)
Internet country code: .tv
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones • main lines in use: 50,074; however,
80,868 main lines have been installed (1998)
Telephones - mobile cellular: 9,000 (1998)
Telephone system:
general assessment: seriously inadequate; two
cellular systems have been introduced, but a sharp
increase in the number of main lines is essential;
e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio
relay, and radiotelephone communication stations,
fixed and mobile cellular systems for short range
traffic
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 1nmarsat; analog links to
Kenya and Tanzania
Radio broadcast stations: AM 7, FM 33,
shortwave 2 (2001)
Television broadcast stations: 8 (plus one
low-power repeater) (2001)
Internet country code: .ug
Internet Service Providers (ISPs): 2 (2000)
Internet users: 25,000 (2000)','d4c8765de5825fd0540e8684948946750d472ef40535a8a7d1647a1ced5bceb9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf54b03c23ee1303deefbcea34a7cbeb8bf1ccef2da233aae29d7d7a21206136',2002,'OM','Oman','communications',1139,'Telephones - main lines in use: 915,223 (1998)
Telephones • mobile cellular: 1 million (1999)
Telephone system:
general assessment: modern system of microwave
radio relay and coaxial cable; key centers are Abu
Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and
Pakistan; tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 13, FM 7,
shortwave 2 (1998)
Television broadcast stations: 15 (1997)
Internet country code: .ae
Internet Service Providers (ISPs): 1 (2000)
Internet users: 735,000(2001)','fc087d1219fdc39b4919e571582497d684b4645b146bc93398e2a744aa5ac010','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eb081418a793870c922ed90b0991ef5e80a786d43343121200711175a06c44b',2002,'UY','Uruguay','communications',1148,'Telephones - main lines in use: 929,141 (2001)
Telephones • mobile cellular: 350,000 (2001)
Telephone system:
general assessment: fully digitalized
domestic: most modern facilities concentrated in
Montevideo: new nationwide microwave radio relay
network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean) (2002)
Radio broadcast stations: AM 91, FM 149,
shortwave 7 (2001)
Television broadcast stations: 20 (2001)
Internet country code: .uy
Internet Service Providers (ISPs): 1 4 (2001 )
Internet users: 370,000(2001)','2b1b47f1c1e7870ec3afa7e1bc8f8f75b9108929ada12ceef93a8885b2b9ddca','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5247a66d53ab765cf1cbc3f1db6dd9df1d639f0594625cc9d94613406a8911d1',2002,'UZ','Uzbekistan','communications',1157,'Telephones • main lines in use: 1.98 million (1999)
Telephones - mobile cellular: 26,000 (1998)
Telephone system:
general assessment: antiquated and inadequate; in
serious need of modernization
domestic: the domestic telephone system is being
expanded and technologically improved, particularly
in Tashkent and Samarqand, under contracts with
prominent companies in industrialized countries;
moreover, by 1998, six cellular networks had been
placed in operation - four of the GSM type (Global
System for Mobile Communication), one D-AMPS
type (Digital Advanced Mobile Phone System), and
one AMPS type (Advanced Mobile Phone System)
International: linked by landline or microwave radio
relay with CIS member states and to other countries
by leased connection via the Moscow international
gateway switch; after the completion of the Uzbek link
to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities
for international communications; Inmarsat also
provides an international connection, albeit an
expensive one; satellite earth stations - NA (1998)
Radio broadcast stations: AM 20, FM 7,
shortwave 10 (1998)
Television broadcast stations: 4 (plus two
repeaters that relay Russian, Kazakh, Kyrgyz, and
Tajik programs) (1997)
Internet country code: .uz
Internet Service Providers (ISPs): 42 (2000)
Internet users: 7,500 (2000)','d92786c00a53471c803989f2e9657c2ace694f5967918ace05f8338e19d09005','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46f20d6de664453dc6774f84e202e5b35a74c77e4d6895dacd8af6ae7568c7c',2002,'PR','Puerto Rico','communications',1164,'Telephones - main lines in use: 62,000 (1997)
Telephones - mobile cellular: 2,000 (1992)
Telephone system:
general assessment: NA
domestic: modern, uses fiber-optic cable and
microwave radio relay
international: submarine cable and satellite
communications; satellite earth stations - NA
Radio broadcast stations: AM 5, FM 1 1 ,
shortwave 0 (2002)
Television broadcast stations: 2 (2002)
Internet country code: .vi
Internet Service Providers (ISPs): 50 (2000)
Internet users: 12,000(2000)','b9c1621353a4f27240b9b1d80ab6cbe13b3e9e7826d49e4c29e6661a5c6f992e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df9a52cbeef1c0607c85e44a57983b658e2335454ddeb43c41a71e94cd75be5',2002,'EH','Western Sahara','communications',1175,'Telephones • main lines in use: about 2,000
(1999 est.)
Telephones - mobile cellular: 0 (1999)
Telephone system:
general assessment: sparse and limited system
domestic: NA
international: tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and
satellite; satellite earth stations - 2 Intelsat (Atlantic
Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0, shortwave 0
(1998)
Television broadcast stations: NA
Internet country code: .eh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Television broadcast stations: NA
Internet Service Providers (ISPs): 10,350
(2000 est.)
Internet users: 513.41 million (2001 est.)','e6e52ace68ec4a4073018486d3ad9eabb7611cc87004fe1f8c223e1db136d5a2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('702087671e79c536a88ae35034259f9b429054c0ff0c06937462b4525981f688',2002,'YE','Yemen','communications',1184,'Telephones - main lines in use: 291,359 (1999)
Telephones - mobile cellular: 32,042 (2000)
Telephone system:
general assessment: since unification in 1990, efforts
have been made to create a national
telecommunications network
domestic: the national network consists of microwave
radio relay, cable, tropospheric scatter, and GSM
cellular mobile telephone systems
international: satellite earth stations - 3 Intelsat (2
Indian Ocean and 1 Allantic Ocean), 1 1ntersputnik
(Atlantic Ocean region), and 2 Arabsat; microwave
radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 6, FM 1 , shortwave 2
(1998)
Television broadcast stations: 7 (plus several
low-power repeaters) (1997)
Internet country code: .ye
Internet Service Providers (ISPs): 1 (2000)
Internet users: 14,000 (2001)
Telephones - main lines in use: 2.017 million
(1995)
Telephones - mobile cellular: 87,000 (1997)
Telephone system:
general assessment: NA
domestic: NA
international: satellite earth station ■ 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 113, FM 194,
shortwave 2 (1998)
Television broadcast stations: more than 771
(including 86 strong stations and 685 low-power
stations, plus 20 repeaters in the principal networks;
also numerous local or private stations in Serbia and
Vojvodina) (1997)
Internet Service Providers (ISPs): 9 (2000)
Internet users: 400,000(2001)','4345f42d7985ad12fda0057aaf5b6c4a6362e0167329a01b73b4963a1fc6bdf0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a275b898bdae5200eb1fe22dc7e4bbf6fb75be01c5a956f01df124ac0f28d2a6',2002,'ZM','Zambia','communications',1192,'Telephones - main lines in use: 130,000 (including
more than 40,000 fixed telephones in wireless local
loop connections) (1997)
Telephones - mobile cellular: 75,000 (2001)
Telephone system:
general assessment: facilities are aging but still
among the best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay
connects most larger towns and cities; several cellular
telephone services in operation; Internet service is
widely available; very small aperture terminal (VSAT)
networks are operated by private firms
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 19, FM 5,
shortwave 4 (2001)
Television broadcast stations: 9 (2002)
Internet country code: ,zm
Internet Service Providers (ISPs): 5 (2001)
Internet users: 15,000(2000)','45bc5185e2dfb303798551d821062a7173a20235745570594645867ca53470fc','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3be231ea576bf7199efe085737b7b61f61d79acaac2668ded77a5b2dc16ef0e9',2002,'ZW','Zimbabwe','communications',1200,'Telephones - main lines in use: 212,000 (in
addition, there are about 20,000 fixed telephones in
wireless local loop connections) (1997)
Telephones - mobile cellular: 1 1 1 ,000 (2001 )
Telephone system:
general assessment : system was once one of the
best in Africa, but now suffers from poor maintenance;
more than 100,000 outstanding requests for
connection despite an equally large number of
installed but unused main lines
domestic: consists of microwave radio relay links,
open-wire lines, radiotelephone communication
stations, fixed wireless local loop installations, and a
substantial mobile cellular network; Internet
connection is available in Harare and planned for all
major towns and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare
and Gweru)
Radio broadcast stations: AM 7, FM 20 (plus 17
repeater stations), shortwave 1 (1998)
Television broadcast stations: 16 (1997)
Internet country code: .zw
Internet Service Providers (ISPs): 6 (2000)
Internet users: 30,000(1999)
T ransportation
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km
electrified; 42 km double-tracked)
note: includes the 318 km Bulawaya-Beitbridge
Railway Company line (2001)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (2002)
Waterways: chrome ore is transported from Harare -
by way of the Mazoe River - to the Zambezi River in','e7d668c83a4666428efb5a86b32f02e41934b2867cac3c8887f8054e4ac92aa0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea534357cccff67bf5eb667bd0abbe848a4cb2a72d23abc44b0d359880ab5d3f',2002,'ZW','Zimbabwe','communications',238,'CBSS : Council of the Baltic Sea States
CCC : Customs Cooperation Council
CDB : Caribbean Development Bank
CE : Council of Europe
CEI : Central European Initiative
CEMA : Council for Mutual Economic Assistance;
also known as CMEA or Comecon
CEPGL : Economic Community of the Great Lakes
Countries
CERN : European Organization for Nuclear
Research
c.i.f. : cost, insurance, and freight
CIS : Commonwealth of Independent States
CITES : see Endangered Species
Climate Change : United Nations Framework Convention on
Climate Change
Climate Change-Kyoto Protocol : Kyoto Protocol to the United Nations
Framework Convention on Climate Change
COCOM : Coordinating Committee on Export
Controls
Comsat : Communications Satellite Corporation
CP : Colombo Plan
CY : calendar year
DC : developed country
Desertification : United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
DSN : Defense Switched Network
DWT : deadweight ton
EADB : East African Development Bank
EAPC : Euro-Atlantic Partnership Council
EBRD : European Bank for Reconstruction and
Development
EC : European Community
ECA : Economic Commission for Africa
ECE : Economic Commission for Europe
ECLAC : Economic Commission for Latin America
and the Caribbean
ECO : Economic Cooperation Organization
ECOSOC : Economic and Social Council
ECOWAS : Economic Community of West African
States
ECS : European Coal and Steel Community
EEC : European Economic Community
EFTA : European Free Trade Association
EIB : European Investment Bank
EMU : European Monetary Union
Endangered Species : Convention on the International Trade in
Endangered Species of Wild Flora and
Fauna (CITES)
Entente : Council of the Entente
Environmental Modification : Convention on the Prohibition of
Military or Any Other Hostile Use of
Environmental Modification Techniques
ESA : European Space Agency
ESCAP : Economic and Social Commission for Asia
and the Pacific
ESCWA : Economic and Social Commission for
Western Asia
est. : estimate
EU : European Union
Euratom : European Atomic Energy Community
Eutelsat : European Telecommunications Satellite
Organization
Ex-Im : Export-Import Bank of the United States
FAO : Food and Agriculture Organization
FAX : facsimile
f.o.b. : free on board
FLS : Front Line States
FRG : Federal Republic of Germany (West
Germany); used for information dated
before 3 October 1990 or CY91
FSU : former Soviet Union
FY : fiscal year
FYROM : The Former Yugoslav Republic of
Macedonia
FZ : Franc Zone
G-2 : Group of 2
G-3 : Group of 3
G-5 : Group of 5
G-6 : Group of 6
G-7 : Group of 7
G-8 : Group of 8
G-9 : Group of 9
G-10 : Group of 10
G-11 : Group of 11
G-15 : Group of 15
G-19 : Group of 19
G-24 : Group of 24
G-30 : Group of 30
G-33 : Group of 33
G-77 : Group of 77
GATT : General Agreement on Tariffs and Trade;
now WTrO
GCC : Gulf Cooperation Council
GDP : gross domestic product
GDR : German Democratic Republic (East
Germany); used for information dated
before 3 October 1990 or CY91
GNP : gross national product
GRT : gross register ton
GWP : gross world product
Hazardous Wastes : Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
HF : high-frequency
IADB : Inter-American Development Bank
IAEA : International Atomic Energy Agency
IBEC : International Bank for Economic
Cooperation
IBRD : International Bank for Reconstruction
and Development (World Bank)
ICAO : International Civil Aviation
Organization
ICC : International Chamber of Commerce
ICJ : International Court of Justice (World
Court)
ICRC : International Committee of the Red Cross
ICRM : International Red Cross and Red Crescent
Movement
IDA : International Development Association
IDB : Islamic Development Bank
IEA : International Energy Agency
IFAD : International Fund for Agricultural
Development
IFC : International Finance Corporation
IFCTU : International Federation of Christian
Trade Unions
IFRCS : International Federation of Red Cross
and Red Crescent Societies
IGAD : Inter-Governmental Authority on
Development
IGADD : Inter-Governmental Authority on Drought
and Development
IHO : International Hydrographic Organization
IIB : International Investment Bank
ILO : International Labor Organization
IMF : International Monetary Fund
IMO : International Maritime Organization
Inmarsat : International Mobile Satellite
Organization
InOC : Indian Ocean Commission
Intelsat : International Telecommunications
Satellite Organization
Interpol : International Criminal Police
Organization
Intersputnik : International Organization of Space
IOC : International Olympic Committee
IOM : International Organization for Migration
ISO : International Organization for
Standardization
ITU : International Telecommunication Union
kHz : kilohertz
km : kilometer
kW : kilowatt
kWh : kilowatt hour
LAES : Latin American Economic System
LAIA : Latin American Integration Association
Law of the Sea : United Nations Convention on the Law of
the Sea (LOS)
LDC : less developed country
LLDC : least developed country
London Convention : see Marine Dumping
LOS : see Law of the Sea
m : meter
Marecs : Maritime European Communications
Satellite
Marine Dumping : Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation : Convention on Fishing and Conservation
of Living Resources of the High Seas
MARPOL : see Ship Pollution
Medarabtel : Middle East Telecommunications Project
of the International Telecommunications
Union
Mercosur : Southern Cone Common Market
MHz : megahertz
MINURSO : United Nations Mission for the
Referendum in Western Sahara
MONUC : United Nations Organization Mission in
the Democratic Republic of the Congo
NA : not available
NAM : Nonaligned Movement
NATO : North Atlantic Treaty Organization
NC : Nordic Council
NEA : Nuclear Energy Agency
NEGL : negligible
NIB : Nordic Investment Bank
NIC : newly industrializing country
NIE : newly industrializing economy
NM : nautical mile
NMT : Nordic Mobile Telephone
NSG : Nuclear Suppliers Group
Nuclear Test Ban : Treaty Banning Nuclear Weapons Tests in
the Atmosphere, in Outer Space, and
Under Water
NZ : New Zealand
OAPEC : Organization of Arab Petroleum Exporting
Countries
OAS : Organization of American States
OAU : Organization of African Unity
ODA : official development assistance
OECD : Organization for Economic Cooperation
and Development
OECS : Organization of Eastern Caribbean States
OIC : Organization of the Islamic Conference
OOF : other official flows
OPCW : Organization for the Prohibition of
Chemical Weapons
OPEC : Organization of Petroleum Exporting
Countries
OSCE : Organization for Security and
Cooperation in Europe
Ozone Layer Protection : Montreal Protocol on Substances That
Deplete the Ozone Layer
PCA : Permanent Court of Arbitration
PDRY : People''s Democratic Republic of Yemen
[Yemen (Aden) or South Yemen]; used for
information dated before 22 May 1990 or
CY91
PFP : Partnership for Peace
Ramsar : see Wetlands
RG : Rio Group
SAARC : South Asian Association for Regional
Cooperation
SACU : Southern African Customs Union
SADC : Southern African Development Community
SFRY : Socialist Federal Republic of Yugoslavia
SHF : super-high-frequency
Ship Pollution : Protocol of 1978 Relating to the
International Convention for the
Prevention of Pollution From Ships, 1973
(MARPOL)
Sparteca : South Pacific Regional Trade and
Economic Cooperation Agreement
SPC : South Pacific Commission
SPF : South Pacific Forum
sq km : square kilometer
sq mi : square mile
TAT : Trans-Atlantic Telephone
Tropical Timber 83 : International Tropical Timber Agreement,
1983
Tropical Timber 94 : International Tropical Timber Agreement,
1994
UAE : United Arab Emirates
UDEAC : Central African Customs and Economic
Union
UHF : ultra-high-frequency
UK : United Kingdom
UN : United Nations
UNAMIR : United Nations Assistance Mission for
** Group of 24 (G-24) **
established - 1 August 1989
aim - to promote the interests of developing countries in Africa, Asia,
and Latin America within the IMF
members - (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic
of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana, Guatemala,
India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines,
South Africa, Sri Lanka, Syria, Trinidad and Tobago, Venezuela
** Group of 77 (G-77) **
established - 15 June 1964 was set up; NA October 1967 first ministerial
meeting
aim - to promote economic cooperation among developing countries; name
persists in spite of increased membership
members - (131 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq,
Jamaica, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Federated States of
Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda,
UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
Zimbabwe, Palestine Liberation Organization
** Gulf Cooperation Council (GCC) **
note - also known as the Cooperation Council for the Arab States of
the Gulf
established - 25 May 1981
aim - to promote regional cooperation in economic, social, political,
and military affairs
members - (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
** high-income countries **
another term for the industrialized countries with high per capita GDPs;
see developed countries (DCs)
** Indian Ocean Commission (InOC) **
established - 21 December 1982
aim - to organize and promote regional cooperation in all sectors,
especially economic
members - (5) Comoros, France (for Reunion), Madagascar, Mauritius,
** International Court of Justice (ICJ) **
note - also known as the World Court
established - 3 February 1946 superseded Permanent Court of International
Justice
aim - primary judicial organ of the UN
members - (15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems
** International Criminal Police Organization (Interpol) **
established - NA September 1923 set up as the International Criminal
Police Commission; 13 June 1956 constitution modified and present
name adopted
aim - to promote international cooperation among police authorities in
fighting crime
members - (179) Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
subbureaus - (14) American Samoa, Anguilla, Bermuda, British Virgin
Islands, Cayman Islands, Gibraltar, Guam, Hong Kong, Macau, Montserrat,
Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands,
Virgin Islands
** International Development Association (IDA) **
established - 26 January 1960; effective - 24 September 1960
aim - UN specialized agency and IBRD affiliate that provides economic
loans for low-income countries
members - (163)
Part I - (27 developed countries) Australia, Austria, Belgium, Canada,
Denmark, EU, Finland, France, Germany, Iceland, Ireland, Italy, Japan,
Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UAE, UK, US
Part II - (136 less developed countries) Afghanistan, Albania, Algeria,
Angola, Argentina, Armenia, Azerbaijan, Bangladesh, Barbados, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cyprus, Czech Republic, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji,
Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati, South Korea,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Uzbekistan, Vanuatu, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** International Energy Agency (IEA) **
established - 15 November 1974
aim - to promote cooperation on energy matters, especially emergency
oil sharing and relations between oil consumers and oil producers;
established by the OECD
members - (26) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain,
Sweden, Switzerland, Turkey, UK, US
** International Federation of Red Cross and Red Crescent **
Societies (IFRCS) note - formerly known as League of Red Cross and Red
Crescent Societies (LORCS)
established - 5 May 1919
aim - to organize, coordinate, and direct international relief actions;
to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members - (179) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members - (7 plus the Palestine Liberation Organization)
Comoros, Cook Islands, Eritrea, Israel, Kazakhstan, Federated States of
Micronesia, Tuvalu, Palestine Liberation Organization
** International Finance Corporation (IFC) **
established - 25 May 1955; effective - 24 July 1956
aim - to support private enterprise in international economic development;
a UN specialized agency and IBRD affiliate
members - (175) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** International Fund for Agricultural Development (IFAD) **
established - NA November 1974
aim - to promote agricultural development; a UN specialized agency
members - (162)
Category I - (23 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal,
Spain, Sweden, Switzerland, UK, US
Category II - (12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
Category III - (127 aid recipients) Afghanistan, Albania, Angola,
Antigua and Barbuda, Argentina, Armenia, Azerbaijan, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos, Lebanon,
Lesotho, Liberia, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
** International Hydrographic Organization (IHO) **
note - name changed from International Hydrographic Bureau on 22
September 1970
established - NA June 1919; effective - NA June 1921
aim - to train hydrographic surveyors and nautical cartographers
to achieve standardization in nautical charts and electronic chart
displays; to provide advice on nautical cartography and hydrography;
to develop the sciences in the field of hydrography and techniques used
for descriptive oceanography
members - (70) Algeria, Argentina, Australia, Bahrain, Bangladesh,
Belgium, Brazil, Canada, Chile, China (including Hong Kong and Macau),
Colombia, Democratic Republic of the Congo, Croatia, Cuba, Cyprus,
Denmark, Dominican Republic, Ecuador, Egypt, Estonia, Fiji, Finland,
France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran,
Italy, Jamaica, Japan, North Korea, South Korea, Malaysia, Monaco,
Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Singapore,
South Africa, Spain, Sri Lanka, Suriname, Sweden, Syria, Thailand, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay,
Venezuela, Yugoslavia
membership pending - (3) Bulgaria, Mauritania, Qatar
** International Labor Organization (ILO) **
established - 28 Ju','d1b30b19c5996218c79cfd0abbcdeb88e71ef8dda16033276e6a9edef8a81408','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5eeda05da644cacdaa52e03933319bde4bdc98ff68b322db3327c8f7bdb9a2d',2002,'ZW','Zimbabwe','communications',239,'ne 1919 set up as part of Treaty of Versailles;
11 April 1919 became operative; 14 December 1946 affiliated with the UN
aim - to deal with world labor issues; a UN specialized agency
members - (175) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,
** International Maritime Organization (IMO) **
note - name changed from Intergovernmental Maritime Consultative
Organization (IMCO) on 22 May 1982
established - 6 March 1948 set up as the Inter-Governmental
Maritime Consultative Organization; effective - 17 March 1958
aim - to deal with international maritime affairs; a UN specialized agency
members - (161) Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil,
Brunei, Bulgaria, Burma, Cambodia, Cameroon, Canada, Cape Verde, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Latvia, Lebanon, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia
associate members - (2) Hong Kong, Macau
** International Monetary Fund (IMF) **
established - 22 July 1944; effective - 27 December 1945
aim - to promote world monetary stability and economic development;
a UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** International Olympic Committee (IOC) **
established - 23 June 1894
aim - to promote the Olympic ideals and administer the Olympic games:
2002 Winter Olympics in Salt Lake City, United States; 2004 Summer
Olympics in Athens, Greece; 2006 Winter Olympics in Turin, Italy
National Olympic Committees - (199 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, American Samoa, Andorra,
Angola (suspended), Antigua and Barbuda, Argentina, Armenia, Aruba,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands,
Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
** International Organization for Migration (IOM) **
note - established as Provisional Intergovernmental Committee for the
Movement of Migrants from Europe; renamed Intergovernmental Committee for
European Migration (ICEM) on 15 November 1952; renamed Intergovernmental
Committee for Migration (ICM) in November 1980; current name adopted 14
November 1989
established - 5 December 1951
aim - to facilitate orderly international emigration and immigration
members - (91) Albania, Algeria, Angola, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bangladesh, Belgium, Belize, Benin, Bolivia,
Bulgaria, Burkina Faso, Canada, Cape Verde, Chile, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Finland, France, The Gambia, Georgia, Germany,
Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iran,
Israel, Italy, Japan, Jordan, Kenya, South Korea, Kyrgyzstan, Latvia,
Liberia, Lithuania, Luxembourg, Madagascar, Mali, Morocco, Netherlands,
Nicaragua, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Senegal, Sierra Leone, Slovakia, Slovenia, South
Africa, Sri Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania,
Thailand, Tunisia, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Yemen,
Yugoslavia, Zambia
observers - (36) Afghanistan, Belarus, Bhutan, Bosnia and Herzegovina,
Brazil, Cambodia, China, Cuba, Estonia, Ethiopia, Ghana, Holy See, India,
Indonesia, Ireland, Jamaica, Kazakhstan, The Former Yugoslav Republic
of Macedonia, Malta, Mexico, Moldova, Mozambique, Namibia, Nepal, NZ,
Papua New Guinea, Russia, Rwanda, San Marino, Sao Tome and Principe,
Somalia, Spain, Turkey, Turkmenistan, Vietnam, Zimbabwe
** International Organization for Standardization (ISO) **
established - NA February 1947
aim - to promote the development of international standards with a
view to facilitating international exchange of goods and services and
to developing cooperation in the sphere of intellectual, scientific,
technological and economic activity
members - (93 national standards organizations) Algeria, Argentina,
Armenia, Australia, Austria, Bangladesh, Barbados, Belarus, Belgium,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile,
China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Ecuador, Egypt, Ethiopia, Finland, France, Germany, Ghana,
Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Libya, Luxembourg, The Former Yugoslav Republic
of Macedonia, Malaysia, Malta, Mauritius, Mexico, Mongolia, Morocco,
Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines, Poland,
Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania,
Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yugoslavia, Zimbabwe
correspondent members - (36) Albania, Azerbaijan, Bahrain, Bolivia,
Brunei, Cameroon, Democratic Republic of the Congo, Cote d''Ivoire, El
Salvador, Estonia, Guatemala, Hong Kong, Kyrgyzstan, Latvia, Lebanon,
Lithuania, Macau, Madagascar, Malawi, Moldova, Mozambique, Namibia,
Nepal, Nicaragua, Oman, Papua New Guinea, Paraguay, Peru, Qatar, Rwanda,
Saint Lucia, Seychelles, Sudan, Swaziland, Turkmenistan, Uganda
subscriber members - (13 plus the Palestine Liberation Organization)
Antigua and Barbuda, Benin, Burkina Faso, Cambodia, Comoros, Dominica,
Dominican Republic, Fiji, Grenada, Guyana, Honduras, Lesotho, Mali,
Saint Lucia, Palestine Liberation Organization
** International Red Cross and Red Crescent Movement (ICRM) **
established - NA 1928
aim - to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International Federation
of Red Cross and Red Crescent Societies (IFRCS; formerly League of Red
Cross and Red Crescent Societies or LORCS) in peacetime
National Societies - (176 countries);
note - same as membership for International Federation of Red Cross and
Red Crescent Societies (IFRCS)
** International Telecommunication Union (ITU) **
established - 17 May 1865 set up as the International Telegraph Union;
9 December 1932 adopted present name
effective - 1 January 1934; affiliated with the UN - 15 November 1947
aim - to deal with world telecommunications issues; a UN specialized
agency
members - (189) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** Islamic Development Bank (IDB) **
established - 15 December 1973 by declaration of
intent; effective - 12 August 1974
aim - to promote Islamic economic aid and social development
members - (52 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait,
Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco,
Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra
Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, UAE, Yemen, Palestine Liberation Organization
** Latin American Economic System (LAES) **
note - also known as Sistema Economico Latinoamericana (SELA)
established - 17 October 1975
aim - to promote economic and social development through regional
cooperation
members - (28) Argentina, The Bahamas, Barbados, Belize, Bolivia,
Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador,
El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica,
Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
** Latin American Integration Association (LAIA) **
note - also known as Asociacion Latinoamericana de Integracion (ALADI)
established - 12 August 1980; effective - 18 March 1981
aim - to promote freer regional trade
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador,
Mexico, Paraguay, Peru, Uruguay, Venezuela
observers - (23) China, Commission of the European Communities,
Corporacion Andina de Fomento, Costa Rica, Dominican Republic,
El Salvador, Guatemala, Honduras, Inter-American Development Bank,
Inter-American Institute for Cooperation on Agriculture, Italy, Latin
America Economic System, Nicaragua, Organization of American States,
Panama, Panamerican Health Organization, Portugal, Romania, Russia,
Spain, Switzerland, United Nations Development Program, United Nations
Economic Commission for Latin America and the Caribbean
** least developed countries (LLDCs) **
that subgroup of the less developed countries (LDCs) initially identified
by the UN General Assembly in 1971 as having no significant economic
growth, per capita GDPs normally less than $1,000, and low literacy rates;
also known as the undeveloped countries; the 42 LLDCs are: Afghanistan,
Bangladesh, Benin, Bhutan, Botswana, Burkina Faso, Burma, Burundi, Cape
Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial
Guinea, Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti,
Kiribati, Laos, Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique,
Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia,
Sudan, Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
** less developed countries (LDCs) **
the bottom group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries (LDCs);
mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000
and often less than $1,500; however, the group also includes a number of
countries with high per capita incomes, areas of advanced technology,
and rapid rates of growth; includes the advanced developing countries,
developing countries, Four Dragons (Four Tigers), least developed
countries (LLDCs), low-income countries, middle-income countries,
newly industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands,
Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde,
Cayman Islands, Central African Republic, Chad, Chile, China, Christmas
Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands,
Fiji, French Guiana, French Polynesia, Gabon, The Gambia, Gaza Strip,
Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guatemala,
Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong,
India, Indonesia, Iran, Iraq, Jamaica, Jersey, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya,
Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man, Marshall
Islands, Martinique, Mauritania, Mauritius, Mayotte, Federated States of
Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria,
Niue, Norfolk Island, Northern Mariana Islands, Oman, Palau, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands,
Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga,
Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE,
Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis
and Futuna, West Bank, Western Sahara, Yemen, Zambia, Zimbabwe;
note - similar to the new International Monetary Fund (IMF) term
"developing countries" which adds Malta, Mexico, South Africa, and
Turkey but omits in its recently published statistics American Samoa,
Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas
Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands,
French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland,
Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle
of Man, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue,
Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto
Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga,
Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna,
West Bank, Western Sahara
** low-income countries **
another term for those less developed countries with below-average per
capita GDPs; see less developed countries (LDCs)
** middle-income countries **
another term for those less developed countries with above-average per
capita GDPs; see less developed countries (LDCs)
** Monetary and Economic Community of Central Africa (CEMAC) **
note - was formerly the Central African Customs and Economic Union (UDEAC)
established - 8 December 1964; effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (7) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, Gabon, Sao Tome and Principe
** Near Abroad **
Russian term for the 14 non-Russian successor states of the USSR, in
which 25 million ethnic Russians live and in which Moscow has expressed
a strong national security interest; the 14 countries are Armenia,
Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
** new independent states (NIS) **
a term referring to all those countries of the FSU except the Baltic
countries (Estonia, Latvia, Lithuania)
** newly industrializing countries (NICs) **
former term for the newly industrializing economies; see newly
industrializing economies (NIEs)
** newly industrializing economies (NIEs) **
that subgroup of the less developed countries (LDCs) that has experienced
particularly rapid industrialization of their economies; formerly known
as the newly industrializing countries (NICs); also known as advanced
developing countries; usually includes the Four Dragons (Hong Kong,
South Korea, Singapore, Taiwan), and Brazil
** Nonaligned Movement (NAM) **
established - 1-6 September 1961
aim - to establish political and military cooperation apart from the
traditional East or West blocs
members - (113 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central A','cd2ee869ace877931ebdf43bca23ebbc4ca39e8c313055afc20af4534145434a','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('315e51c3f1bc710a8cadd064549e8d65968b20e1ca449e6df247f93216ca0dcd',2002,'ZW','Zimbabwe','communications',240,'frican Republic, Chad,
Chile, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, India, Indonesia,
Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New
Guinea, Peru, Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan,
Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe, Palestine Liberation Organization
observers - (16) Antigua and Barbuda, Armenia, Azerbaijan, Brazil,
China, Costa Rica, Croatia, Dominica, Dominican Republic, El Salvador,
Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests - (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria,
Canada, Finland, France, Germany, Greece, Holy See, Hungary, Ireland,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, UK, US
** Nordic Council (NC) **
established - 16 March 1952; effective - 12 February 1953
aim - to promote regional economic, cultural, and environmental
cooperation
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers - (3) the Sami (Lapp) local parliaments of Finland, Norway,
and Sweden
** Nordic Investment Bank (NIB) **
established - 4 December 1975; effective - 1 June 1976
aim - to promote economic cooperation and development
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
** North **
a popular term for the rich industrialized countries generally located
in the northern portion of the Northern Hemisphere; the counterpart of
the South; see developed countries (DCs)
** North Atlantic Treaty Organization (NATO) **
established - 4 April 1949
aim - to promote mutual defense and cooperation
members - (19) Belgium, Canada, Czech Republic, Denmark, France, Germany,
Greece, Hungary, Iceland, Italy, Luxembourg, Netherlands, Norway, Poland,
Portugal, Spain, Turkey, UK, US
** Nuclear Energy Agency (NEA) **
note - also known as OECD Nuclear Energy Agency
established - 1 February 1958
aim - to promote the peaceful uses of nuclear energy; associated with OECD
members - (27) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
** Nuclear Suppliers Group (NSG) **
note - also known as the London Suppliers Group or the London Group
established - NA 1974; effective - NA 1975
aim - to establish guidelines for exports of nuclear materials, processing
equipment for uranium enrichment, and technical information to countries
of proliferation concern and regions of conflict and instability
members - (39) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, Cyprus, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Latvia,
Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US
observer - (1) European Commission (a policy-planning body for the EU)
** Organization for Economic Cooperation and Development (OECD) **
established - 14 December 1960; effective - 30 September 1961
aim - to promote economic cooperation and development
members - (30) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member - (1) EU
** Organization for Security and Cooperation in Europe (OSCE) **
note - formerly the Conference on Security and Cooperation in Europe
(CSCE) established 3 July 1975
established - 1 January 1995
aim - to foster the implementation of human rights, fundamental freedoms,
democracy, and the rule of law; to act as an instrument of early warning,
conflict prevention, and crisis management; and to serve as a framework
for conventional arms control and confidence building measures
members - (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece,
Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway,
Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
Uzbekistan, Yugoslavia partners for cooperation - (9) Algeria, Egypt,
Israel, Japan, Jordan, South Korea, Morocco, Thailand, Tunisia
** Organization for the Prohibition of Chemical Weapons (OPCW) **
established - 29 April 1997
aim - to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among
the signatories of the Convention
members - (145) Albania, Algeria, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burundi, Cameroon, Canada, Chile, China, Colombia,
Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Ecuador, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guinea, Guyana, Holy See, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia, Lesotho,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Lucia, San Marino, Saudi Arabia, Senegal, Seychelles,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
signatory states - (29) Afghanistan, The Bahamas, Bhutan, Burma, Cambodia,
Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Djibouti, Dominican Republic,
Grenada, Guatemala, Guinea-Bissau, Haiti, Honduras, Israel, Kyrgyzstan,
Liberia, Madagascar, Marshall Islands, Rwanda, Saint Kitts and Nevis,
Saint Vincent and the Grenadines, Samoa, Sierra Leone, Thailand; note -
states have signed but not ratified the convention
** Organization of African Unity (OAU) **
established - 25 May 1963
aim - to promote unity and cooperation among African states
members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana,
Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar,
Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria,
Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
** Organization of American States (OAS) **
established - 14 April 1890 as the International Union of American
Republics; 30 April 1948 adopted present charter; effective - 13
December 1951
aim - to promote regional peace and security as well as economic and
social development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,
Trinidad and Tobago, US, Uruguay, Venezuela
observers - (51) Algeria, Angola, Armenia, Austria, Azerbaijan, Belgium,
Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech Republic,
Denmark, Egypt, Equatorial Guinea, EU, Finland, France, Germany,
Ghana, Greece, Holy See, Hungary, India, Ireland, Israel, Italy, Japan,
Kazakhstan, South Korea, Latvia, Lebanon, Morocco, Netherlands, Norway,
Pakistan, Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia,
Spain, Sri Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine,
UK, Yemen
** Organization of Arab Petroleum Exporting Countries (OAPEC) **
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, UAE
** Organization of Eastern Caribbean States (OECS) **
established - 18 June 1981; effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate members - (2) Anguilla, British Virgin Islands
** Organization of Petroleum Exporting Countries (OPEC) **
established - 14 September 1960
aim - to coordinate petroleum policies
members - (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
** Organization of the Islamic Conference (OIC) **
established - 22-25 September 1969
aim - to promote Islamic solidarity in economic, social, cultural,
and political affairs
members - (56 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei, Burkina
Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt, Gabon,
The Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran, Iraq, Jordan,
Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives,
Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan,
Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname,
Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Uzbekistan, Yemen, Palestine Liberation Organization
observers - (3) Bosnia and Herzegovina, Central African Republic, Thailand
** Pacific Community **
note - formerly known as the South Pacific Commission (SPC)
established - 6 February
1947; effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (27) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and Futuna
** Pacific Island Forum **
note - used to the South Pacific Forum (SPF)
established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua New Guinea,
Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
observer - (1) New Caledonia
** Paris Club **
established - 1956
aim - to provide a forum for debtor countries to negotiate rescheduling
of debt service payments or loans extended by governments or official
agencies of participating countries; to help restore normal trade and
project finance to debtor countries
members - (19) Austria, Australia, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Japan, Netherlands, Norway, Russia,
Spain, Sweden, Switzerland, UK, US
** Partnership for Peace (PFP) **
established - 10-11 January 1994
aim - to expand and intensify political and military cooperation
throughout Europe, increase stability, diminish threats to peace, and
build relationships by promoting the spirit of practical cooperation and
commitment to democratic principles that underpin NATO; program under
the auspices of NATO
members - (29) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria,
Croatia, Czech Republic, Estonia, Finland, Georgia, Hungary, Ireland,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic
of Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia,
Sweden, Switzerland, Turkmenistan, Ukraine, Uzbekistan
** Permanent Court of Arbitration (PCA) **
established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (96) Argentina, Australia, Austria, Belarus, Belgium,
Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada,
Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic,
Ecuador, Egypt, El Salvador, Eritrea, Fiji, Finland, France, Germany,
Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Iran, Iraq, Israel, Italy, Japan, Jordan, South Korea, Kyrgyzstan, Laos,
Latvia, Lebanon, Libya, Liechtenstein, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malta, Mauritius, Mexico, Morocco, Netherlands,
NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland,
Portugal, Romania, Russia, Saudi Arabia, Senegal, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Yugoslavia, Zambia, Zimbabwe
** Rio Group (RG) **
note - formerly known as Grupo de los Ocho, established in December 1986;
composed of the Contadora Group and the Lima Group
established - NA 1988
aim - to consult on regional Latin American issues
members - (19) Argentina, Bolivia, Brazil, Chile, Colombia, Costa Rica,
Dominican Republic, Ecuador, El Salvador, Guatemala, Guyana, Honduras,
Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay, Venezuela
** Second World **
another term for the traditionally Marxist-Leninist states of the USSR
and Eastern Europe, with authoritarian governments and command economies
based on the Soviet model; the term is fading from use; see centrally
planned economies
** socialist countries **
in general, countries in which the government owns and plans the use of
the major factors of production;
note - the term is sometimes used incorrectly as a synonym for communist
countries
** South **
a popular term for the poorer, less industrialized countries generally
located south of the developed countries; the counterpart of the North;
see less developed countries (LDCs)
** South Asian Association for Regional Cooperation (SAARC) **
established - 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan,
countries that have signed, but not yet ratified - (2) Afghanistan, Liberia
*Wetlands:
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
*Whaling:
see International Convention for the Regulation of Whaling
===============================================================================
Appendix D --Cross-Reference List of Country Data Codes
FIPS 10-4:
Countries, Dependencies, Areas of Special Sovereignty, and Their Principal
Administrative Divisions (FIPS PUB 10-4) is maintained by the Office of
the Geographer and Global Issues (Department of State) and published by
the National Institute of Standards and Technology (Department of Commerce).
FIPS 10-4 codes are intended for general use throughout the US Government,
especially in activities associated with the mission of the Department of
State and national defense programs.
ISO 3166:
Codes for the Representation of Names of Countries (ISO 3166) is prepared
by the International Organization for Standardization. ISO 3166 includes
two- and three-character alphabetic codes and three-digit numeric codes that
may be needed for activities involving exchange of data with international
organizations that have adopted that standard. Except for the numeric codes,
ISO 3166 codes have been adopted in the US as FIPS 104-1:American National
Standard Codes for the Representation of Names of Countries, Dependencies,
and Areas of Special Sovereignty for Information Interchange.
Internet:
The Internet country code is the two-letter digraph maintained by the
International Organization for Standardization (ISO) in the ISO 3166 Alpha-2
list and used by the Internet Assigned Numbers Authority (IANA) to establish
country-coded top-level domains (ccTLDs).
__________________________________________________________________________
Entity | FIPS 10-4 | ISO 3166 | Internet | Comment
--------------------------------------------------------------------------
__________________________________________________________________________
Afghanistan_______________|AF____|AF|AFG|004|.af|_________________________
Albania___________________|AL____|AL|ALB|008|.al|_________________________
Algeria___________________|AG____|DZ|DZA|012|.dz|_________________________
American Samoa____________|AQ____|AS|ASM|016|.as|_________________________
Andorra___________________|AN____|AD|AND|020|.ad|_________________________
Angola____________________|AO____|AO|AGO|024|.ao|_________________________
Anguilla__________________|AV____|AI|AIA|660|.ai|_________________________
Antarctica |AY |AQ|ATA|010|.aq|ISO defines as the
| | | | | |territory south of 60
__________________________|______|__|___|___|___|degrees south latitude___
Antigua and Barbuda_______|AC____|AG|ATG|028|.ag|_________________________
Argentina_________________|AR____|AR|ARG|032|.ar|_________________________
Armenia___________________|AM____|AM|ARM|051|.am|_________________________
Aruba_____________________|AA____|AW|ABW|533|.aw|_________________________
Ashmore and Cartier |AT |--|---|---|---|ISO includes with
Islands___________________|______|__|___|___|___|Australia________________
Australia |AS |AU|AUS|036|.au|ISO includes Ashmore and
| | | | | |Cartier Islands, Coral
__________________________|______|__|___|___|___|Sea Islands______________
Austria___________________|AU____|AT|AUT|040|.at|_________________________
Azerbaijan________________|AJ____|AZ|AZE|031|.az|_________________________
Bahamas, The______________|BF____|BS|BHS|044|.bs|_________________________
Bahrain___________________|BA____|BH|BHR|048|.bh|_________________________
Baker Island |FQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Bangladesh________________|BG____|BD|BGD|050|.bd|_________________________
Barbados__________________|BB____|BB|BRB|052|.bb|_________________________
Bassas da India |BS |--|---|---|---|ISO includes with the
| | | | | |Miscellaneous(French)
__________________________|______|__|___|___|___|Indian Ocean Islands_____
Belarus___________________|BO____|BY|BLR|112|.by|_________________________
Belgium___________________|BE____|BE|BEL|056|.be|_________________________
Belize____________________|BH____|BZ|BLZ|084|.bz|_________________________
Benin_____________________|BN____|BJ|BEN|204|.bj|_________________________
Bermuda___________________|BD____|BM|BMU|060|.bm|_________________________
Bhutan____________________|BT____|BT|BTN|064|.bt|_________________________
Bolivia___________________|BL____|BO|BOL|068|.bo|_________________________
Bosnia and Herzegovina____|BK____|BA|BIH|070|.ba|_________________________
Botswana__________________|BC____|BW|BWA|072|.bw|_________________________
Bouvet Island_____________|BV____|BV|BVT|074|.bv|_________________________
Brazil____________________|BR____|BR|BRA|076|.br|_________________________
British Indian Ocean |IO |IO|IOT|086|.io|
Territory_________________|______|__|___|___|___|_________________________
British Virgin Islands____|VI____|VG|VGB|092|.vg|_________________________
Brunei____________________|BX____|BN|BRN|096|.bn|_________________________
Bulgaria__________________|BU____|BG|BGR|100|.bg|_________________________
Burkina Faso______________|UV____|BF|BFA|854|.bf|_________________________
Burma_____________________|BM____|MM|MMR|104|.mm|ISO uses the name Myanmar
Burundi___________________|BY____|BI|BDI|108|.bi|_________________________
Cambodia__________________|CB____|KH|KHM|116|.kh|_________________________
Cameroon__________________|CM____|CM|CMR|120|.cm|_________________________
Canada____________________|CA____|CA|CAN|124|.ca|_________________________
Cape Verde________________|CV____|CV|CPV|132|.cv|_________________________
Cayman Islands____________|CJ____|KY|CYM|136|.ky|_________________________
Central African Republic__|CT____|CF|CAF|140|.cf|_________________________
Chad______________________|CD____|TD|TCD|148|.td|_________________________
Chile_____________________|CI____|CL|CHL|152|.cl|_________________________
China_____________________|CH____|CN|CHN|156|.cn|see also Taiwan__________
Christmas Island__________|KT____|CX|CXR|162|.cx|_________________________
Clipperton Island |IP |--|---|---|---|ISO includes with French
__________________________|______|__|___|___|___|Polynesia________________
Cocos (Keeling) Islands___|CK____|CC|CCK|166|.cc|_________________________
Colombia__________________|CO____|CO|COL|170|.co|_________________________
Comoros___________________|CN____|KM|COM|174|.km|_________________________
Congo, Democratic |CG |ZR|ZAR|180|.cd|formerly Zaire
Republic of the___________|______|__|___|___|___|_________________________
Congo, Republic of the____|CF____|CG|COG|178|.cg|_________________________
Cook Islands______________|CW____|CK|COK|184|.ck|_________________________
Coral Sea Islands |CR |--|---|---|---|ISO includes with
__________________________|______|__|___|___|___|Australia________________
Costa Rica________________|CS____|CR|CRI|188|.cr|_________________________
Cote d''Ivoire_____________|IV____|CI|CIV|384|.ci|_________________________
Croatia___________________|HR____|HR|HRV|191|.hr|_________________________
Cuba______________________|CU____|CU|CUB|192|.cu|_________________________
Cyprus____________________|CY____|CY|CYP|196|.cy|_________________________
Czech Republic____________|EZ____|CZ|CZE|203|.cz|_________________________
Denmark___________________|DA____|DK|DNK|208|.dk|_________________________
Djibouti__________________|DJ____|DJ|DJI|262|.dj|_________________________
Dominica__________________|DO____|DM|DMA|212|.dm|_________________________
Dominican Republic________|DR____|DO|DOM|214|.do|_________________________
East Timor________________|TT____|TP|TMP|626|.tp|_________________________
Ecuador___________________|EC____|EC|ECU|218|.ec|_________________________
Egypt_____________________|EG____|EG|EGY|818|.eg|_________________________
El Salvador_______________|ES____|SV|SLV|222|.sv|_________________________
Equatorial Guinea_____','fe323f3449ec95ac77d13d2c9b6aa1d320acd69b1044c06ecf511454385cbd7f','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a26038c5fbd0bc0f6027c7127813683fdd5462403eb3fb36790538de7796b96b',2002,'ZW','Zimbabwe','communications',241,'____|EK____|GQ|GNQ|226|.gq|_________________________
Eritrea___________________|ER____|ER|ERI|232|.er|_________________________
Estonia___________________|EN____|EE|EST|233|.ee|_________________________
Ethiopia__________________|ET____|ET|ETH|231|.et|_________________________
Europa Island |EU |--|---|---|---|ISO includes with the
| | | | | |Miscellaneous (French)
__________________________|______|__|___|___|___|Indian Ocean Islands_____
Falkland Islands (Islas |FA |FK|FLK|238|.fk|
Malvinas)_________________| ____|__|___|___|___|_________________________
Faroe Islands_____________|FO____|FO|FRO|234|.fo|_________________________
Fiji______________________|FJ____|FJ|FJI|242|.fj|_________________________
Finland___________________|FI____|FI|FIN|246|.fi|_________________________
France____________________|FR____|FR|FRA|250|.fr|_________________________
France, Metropolitan |------|FX|FXX|249|.fx|ISO limits to the
| | | | | |European part of France,
| | | | | |excluding French Guiana,
| | | | | |French Polynesia, French
| | | | | |Southern and Antarctic
| | | | | |Lands, Guadeloupe,
| | | | | |Martinique, Mayotte, New
| | | | | |Caledonia, Reunion, Saint
| | | | | |Pierre and Miquelon,
__________________________|______|__|___|___|___|Wallis and Futuna________
French Guiana_____________|FG____|GF|GUF|254|.gf|_________________________
French Polynesia |FP |PF|PYF|258|.pf|ISO includes Clipperton
__________________________|______|__|___|___|___|Island___________________
French Southern and |FS |TF|ATF|260|.tf|FIPS 10-4 does not
Antarctic Lands | | | | | |include the French-------
| | | | | |claimed portion of
__________________________| ____|__|___|___|___|Antarctica (Terre Adelie)
Gabon_____________________|GB____|GA|GAB|266|.ga|_________________________
Gambia, The_______________|GA____|GM|GMB|270|.gm|_________________________
Gaza Strip________________|GZ____|--|---|---|---|_________________________
Georgia___________________|GG____|GE|GEO|268|.ge|_________________________
Germany___________________|GM____|DE|DEU|276|.de|_________________________
Ghana_____________________|GH____|GH|GHA|288|.gh|_________________________
Gibraltar_________________|GI____|GI|GIB|292|.gi|_________________________
Glorioso Islands |GO |--|---|---|---|ISO includes with the
| | | | | |Miscellaneous (French)
__________________________|______|__|___|___|___|Indian Ocean Islands_____
Greece____________________|GR____|GR|GRC|300|.gr|_________________________
Greenland_________________|GL____|GL|GRL|304|.gl|_________________________
Grenada___________________|GJ____|GD|GRD|308|.gd|_________________________
Guadeloupe________________|GP____|GP|GLP|312|.gp|_________________________
Guam______________________|GQ____|GU|GUM|316|.gu|_________________________
Guatemala_________________|GT____|GT|GTM|320|.gt|_________________________
Guernsey |GK |--|---|---|.gg|ISO includes with the
__________________________|______|__|___|___|___|United Kingdom___________
Guinea____________________|GV____|GN|GIN|324|.gn|_________________________
Guinea-Bissau_____________|PU____|GW|GNB|624|.gw|_________________________
Guyana____________________|GY____|GY|GUY|328|.gy|_________________________
Haiti_____________________|HA____|HT|HTI|332|.ht|_________________________
Heard Island and |HM |HM|HMD|334|.hm|
McDonald Islands__________|______|__|___|___|___|_________________________
Holy See (Vatican City)___|VT____|VA|VAT|336|.va|_________________________
Honduras__________________|HO____|HN|HND|340|.hn|_________________________
Hong Kong_________________|HK____|HK|HKG|344|.hk|_________________________
Howland Island |HQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Hungary___________________|HU____|HU|HUN|348|.hu|_________________________
Iceland___________________|IC____|IS|ISL|352|.is|_________________________
India_____________________|IN____|IN|IND|356|.in|_________________________
Indonesia_________________|ID____|ID|IDN|360|.id|_________________________
Iran______________________|IR____|IR|IRN|364|.ir|_________________________
Iraq______________________|IZ____|IQ|IRQ|368|.iq|_________________________
Ireland___________________|EI____|IE|IRL|372|.ie|_________________________
Israel____________________|IS____|IL|ISR|376|.il|_________________________
Italy_____________________|IT____|IT|ITA|380|.it|_________________________
Jamaica___________________|JM____|JM|JAM|388|.jm|_________________________
Jan Mayen |JN |--|---|---|---|ISO includes with
__________________________|______|__|___|___|___|Svalbard_________________
Japan_____________________|JA____|JP|JPN|392|.jp|_________________________
Jarvis Island |DQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Jersey |JE |--|---|---|.je|ISO includes with the
__________________________|______|__|___|___|___|United Kingdom___________
Johnston Atoll |JQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Jordan____________________|JO____|JO|JOR|400|.jo|_________________________
Juan de Nova Island |JU |--|---|---|---|ISO includes with the
| | | | | |Miscellaneous (French)
__________________________|______|__|___|___|___|Indian Ocean Islands_____
Kazakhstan________________|KZ____|KZ|KAZ|398|.kz|_________________________
Kenya_____________________|KE____|KE|KEN|404|.ke|_________________________
Kingman Reef |KQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Kiribati__________________|KR____|KI|KIR|296|.ki|_________________________
Korea, North______________|KN____|KP|PRK|408|.kp|_________________________
Korea, South______________|KS____|KR|KOR|410|.kr|_________________________
Kuwait____________________|KU____|KW|KWT|414|.kw|_________________________
Kyrgyzstan________________|KG____|KG|KGZ|417|.kg|_________________________
Laos______________________|LA____|LA|LAO|418|.la|_________________________
Latvia____________________|LG____|LV|LVA|428|.lv|_________________________
Lebanon___________________|LE____|LB|LBN|422|.lb|_________________________
Lesotho___________________|LT____|LS|LSO|426|.ls|_________________________
Liberia___________________|LI____|LR|LBR|430|.lr|_________________________
Libya_____________________|LY____|LY|LBY|434|.ly|_________________________
Liechtenstein_____________|LS____|LI|LIE|438|.li|_________________________
Lithuania_________________|LH____|LT|LTU|440|.lt|_________________________
Luxembourg________________|LU____|LU|LUX|442|.lu|_________________________
Macau_____________________|MC____|MO|MAC|446|.mo|_________________________
Macedonia, The Republic of|MK____|MK|MKD|807|.mk|_________________________
Madagascar________________|MA____|MG|MDG|450|.mg|_________________________
Malawi____________________|MI____|MW|MWI|454|.mw|_________________________
Malaysia__________________|MY____|MY|MYS|458|.my|_________________________
Maldives__________________|MV____|MV|MDV|462|.mv|_________________________
Mali______________________|ML____|ML|MLI|466|.ml|_________________________
Malta_____________________|MT____|MT|MLT|470|.mt|_________________________
Man, Isle of |IM |--|---|---|.im|ISO includes with the
__________________________|______|__|___|___|___|United Kingdom___________
Marshall Islands__________|RM____|MH|MHL|584|.mh|_________________________
Martinique________________|MB____|MQ|MTQ|474|.mq|_________________________
Mauritania________________|MR____|MR|MRT|478|.mr|_________________________
Mauritius_________________|MP____|MU|MUS|480|.mu|_________________________
Mayotte___________________|MF____|YT|MYT|175|.yt|_________________________
Mexico____________________|MX____|MX|MEX|484|.mx|_________________________
Micronesia, Federated |FM |FM|FSM|583|.fm|
States of_________________|______|__|___|___|___|_________________________
Midway Islands |MQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Miscellaneous (French) |------|--|---|---|---|ISO includes Bassas da
Indian Ocean Islands | | | | | |India, Europa Island,
| | | | | |Glorioso Islands, Juan de
| | | | | |Nova Island, Tromelin
__________________________|______|__|___|___|___|Island___________________
Moldova___________________|MD____|MD|MDA|498|.md|_________________________
Monaco____________________|MN____|MC|MCO|492|.mc|_________________________
Mongolia__________________|MG____|MN|MNG|496|.mn|_________________________
Montserrat________________|MH____|MS|MSR|500|.ms|_________________________
Morocco___________________|MO____|MA|MAR|504|.ma|_________________________
Mozambique________________|MZ____|MZ|MOZ|508|.mz|_________________________
Myanmar___________________|------|--|---|---|---|see Burma________________
Namibia___________________|WA____|NA|NAM|516|.na|_________________________
Nauru_____________________|NR____|NR|NRU|520|.nr|_________________________
Navassa Island____________|BQ____|--|---|---|---|_________________________
Nepal_____________________|NP____|NP|NPL|524|.np|_________________________
Netherlands_______________|NL____|NL|NLD|528|.nl|_________________________
Netherlands Antilles______|NT____|AN|ANT|530|.an|_________________________
New Caledonia_____________|NC____|NC|NCL|540|.nc|_________________________
New Zealand_______________|NZ____|NZ|NZL|554|.nz|_________________________
Nicaragua_________________|NU____|NI|NIC|558|.ni|_________________________
Niger_____________________|NG____|NE|NER|562|.ne|_________________________
Nigeria___________________|NI____|NG|NGA|566|.ng|_________________________
Niue______________________|NE____|NU|NIU|570|.nu|_________________________
Norfolk Island____________|NF____|NF|NFK|574|.nf|_________________________
Northern Mariana Islands__|CQ____|MP|MNP|580|.mp|_________________________
Norway____________________|NO____|NO|NOR|578|.no|_________________________
Oman______________________|MU____|OM|OMN|512|.om|_________________________
Pakistan__________________|PK____|PK|PAK|586|.pk|_________________________
Palau_____________________|PS____|PW|PLW|585|.pw|_________________________
Palmyra Atoll |LQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Panama____________________|PM____|PA|PAN|591|.pa|_________________________
Papua New Guinea__________|PP____|PG|PNG|598|.pg|_________________________
Paracel Islands___________|PF____|--|---|---|---|_________________________
Paraguay__________________|PA____|PY|PRY|600|.py|_________________________
Peru______________________|PE____|PE|PER|604|.pe|_________________________
Philippines_______________|RP____|PH|PHL|608|.ph|_________________________
Pitcairn Islands__________|PC____|PN|PCN|612|.pn|_________________________
Poland____________________|PL____|PL|POL|616|.pl|_________________________
Portugal__________________|PO____|PT|PRT|620|.pt|_________________________
Puerto Rico_______________|RQ____|PR|PRI|630|.pr|_________________________
Qatar_____________________|QA____|QA|QAT|634|.qa|_________________________
Reunion___________________|RE____|RE|REU|638|.re|_________________________
Romania___________________|RO____|RO|ROM|642|.ro|_________________________
Russia____________________|RS____|RU|RUS|643|.ru|_________________________
Rwanda____________________|RW____|RW|RWA|646|.rw|_________________________
Saint Helena______________|SH____|SH|SHN|654|.sh|_________________________
Saint Kitts and Nevis_____|SC____|KN|KNA|659|.kn|_________________________
Saint Lucia_______________|ST____|LC|LCA|662|.lc|_________________________
Saint Pierre and |SB |PM|SPM|666|.pm|
Miquelon__________________|______|__|___|___|___|_________________________
Saint Vincent and the |VC |VC|VCT|670|.vc|
Grenadines________________|______|__|___|___|___|_________________________
Samoa_____________________|WS____|WS|WSM|882|.ws|_________________________
San Marino________________|SM____|SM|SMR|674|.sm|_________________________
Sao Tome and Principe_____|TP____|ST|STP|678|.st|_________________________
Saudi Arabia______________|SA____|SA|SAU|682|.sa|_________________________
Senegal___________________|SG____|SN|SEN|686|.sn|_________________________
Seychelles________________|SE____|SC|SYC|690|.sc|_________________________
Sierra Leone______________|SL____|SL|SLE|694|.sl|_________________________
Singapore_________________|SN____|SG|SGP|702|.sg|_________________________
Slovakia__________________|LO____|SK|SVK|703|.sk|_________________________
Slovenia__________________|SI____|SI|SVN|705|.si|_________________________
Solomon Islands___________|BP____|SB|SLB|090|.sb|_________________________
Somalia___________________|SO____|SO|SOM|706|.so|_________________________
South Africa______________|SF____|ZA|ZAF|710|.za|_________________________
South Georgia and the |SX |GS|SGS|239|.gs|
Islands___________________|______|__|___|___|___|_________________________
Spain_____________________|SP____|ES|ESP|724|.es|_________________________
Spratly Islands___________|PG____|--|---|---|---|_________________________
Sri Lanka_________________|CE____|LK|LKA|144|.lk|_________________________
Sudan_____________________|SU____|SD|SDN|736|.sd|_________________________
Suriname__________________|NS____|SR|SUR|740|.sr|_________________________
Svalbard__________________|SV____|SJ|SJM|744|.sj|ISO includes Jan Mayen___
Swaziland_________________|WZ____|SZ|SWZ|748|.sz|_________________________
Sweden____________________|SW____|SE|SWE|752|.se|_________________________
Switzerland_______________|SZ____|CH|CHE|756|.ch|_________________________
Syria_____________________|SY____|SY|SYR|760|.sy|_________________________
Taiwan____________________|TW____|TW|TWN|158|.tw|_________________________
Tajikistan________________|TI____|TJ|TJK|762|.tj|_________________________
Tanzania__________________|TZ____|TZ|TZA|834|.tz|_________________________
Thailand__________________|TH____|TH|THA|764|.th|_________________________
Togo______________________|TO____|TG|TGO|768|.tg|_________________________
Tokelau___________________|TL____|TK|TKL|772|.tk|_________________________
Tonga_____________________|TN____|TO|TON|776|.to|_________________________
Trinidad and Tobago_______|TD____|TT|TTO|780|.tt|_________________________
Tromelin Island |TE |--|---|---|---|ISO includes with the
__________________________|______|__|___|___|___|Miscellaneous Islands____
Tunisia___________________|TS____|TN|TUN|788|.tn|_________________________
Turkey____________________|TU____|TR|TUR|792|.tr|_________________________
Turkmenistan______________|TX____|TM|TKM|795|.tm|_________________________
Turks and Caicos Islands__|TK____|TC|TCA|796|.tc|_________________________
Tuvalu____________________|TV____|TV|TUV|798|.tv|_________________________
Uganda____________________|UG____|UG|UGA|800|.ug|_________________________
Ukraine___________________|UP____|UA|UKR|804|.ua|_________________________
United Arab Emirates______|AE____|AE|ARE|784|.ae|_________________________
United Kingdom |UK |GB|GBR|826|.uk|ISO includes Guernsey,
__________________________|______|__|___|___|___|Isle of Man, Jersey______
United States_____________|US____|US|USA|840|.us|_________________________
United States Minor |------|UM|UMI|581|.um|ISO includes Baker
Outlying Islands | | | | | |Island, Howland Island,
| | | | | |Jarvis Island, Johnston
| | | | | |Atoll, Kingman Reef,
| | | | | |Midway Islands, Palmyra
__________________________|______|__|___|___|___|Atoll, Wake Island_______
Uruguay___________________|UY____|UY|URY|858|.uy|_________________________
Uzbekistan________________|UZ____|UZ|UZB|860|.uz|_________________________
Vanuatu___________________|NH____|VU|VUT|548|.vu|_________________________
Venezuela_________________|VE____|VE|VEN|862|.ve|_________________________
Vietnam___________________|VM____|VN|VNM|704|.vn|_________________________
Virgin Islands____________|VQ____|VI|VIR|850|.vi|_________________________
Virgin Islands (UK) |------|--|---|---|.vg|see British Virgin
__________________________|______|__|___|___|___|Islands__________________
Virgin Islands (US)_______|------|--|---|---|.vi|see Virgin Islands_______
Wake Island |WQ |--|---|---|---|ISO includes with the US
__________________________|______|__|___|___|___|Minor Outlying Islands___
Wallis and Futuna_________|WF____|WF|WLF|876|.wf|_________________________
West Bank_________________|WE____|--|---|---|---|_________________________
Western Sahara____________|WI____|EH|ESH|732|.eh|_________________________
Western Samoa_____________|------|--|---|---|.ws|see Samoa________________
World |------|--|---|---|---|the Factbook uses the W
| | | | | |data code from DIAM 65-18
| | | | | |Geopolitical Data
| | | | | |Elements and Related
| | | | | |Features, Data Standard
| | | | | |No. 3, December 1994,
| | | | | |published by the Defense
__________________________|______|__|___|___|___|Intelligence Agency______
Yemen_____________________|YM____|YE|YEM|887|.ye|_________________________
Yugoslavia________________|YI____|YU|YUG|891|.yu|_________________________
Zaire |------|--|---|---|---|see Democratic Republic
__________________________| ____|__|___|___|___|of the Congo_____________
Zambia____________________|ZA____|ZM|ZWB|894|.zm|_________________________
Zimbabwe__________________|ZI____|ZW|ZWE|716|.zw|_________________________
===============================================================================
Appendix E - Cross-Reference List of Hydrographic Data Codes
IHO 23-4th:
Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986,
published by the International Hydrographic Bureau of the International
Hydrographic Organization
IHO 23-3rd:
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953,
published by the International Hydrographic Organization
ACIC M 49-1:
Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC), United
States Air Force; note - ACIC is now part of the National Imagery and Mapping
Agency (NIMA)
DIAM 65-18:
Geopolitical Data Elements and Related Features, Data Standard No. 4,
Defense Intelligence Agency Manual 65-18, December 1994, published by the
Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4 country
codes. The names and limits of the following oceans and seas are not always
directly comparable because of differences in the customers, needs, and
requirements of the individual organizations. Even the number of principal
water bodies varies from organization to organization. Factbook users, for
example, find the Atlantic Ocean and Pacific Ocean entries useful, but none
of the following standards include those oceans in their entirety. Nor is
there any provision for combining codes or overcodes to aggregate water
bodies.The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
_________________________________________________________________________
_______________________|IHO_23-4th|IHO_23-3rd*|ACIC_M_49-1____|DIAM_65-18
Arctic Ocean___________|9_________|17_________|A______________|5A________
Atlantic Ocean_________|-_________|-__________|-______________|-_________
North Atlantic Ocean___|1_________|23_________|B______________|1A________
South Atlantic Ocean___|4_________|32_________|C______________|2A________
Baltic Sea_____________|2_________|1__________|B26____________|7B________
Indian Ocean___________|5_________|45_________|F______________|6A________
Mediterranean Sea______|3.1_______|28_________|B11____________|-_________
Eastern Mediterranean__|3.1.2_____|28_B_______|-______________|8E________
Western Mediterranean__|3.1.1_____|28_A_______|-______________|8W________
Pacific Ocean__________|-_________|-__________|-______________|-_________
North Pacific Ocean____|7_________|57_________|D______________|3A________
South Pacific Ocean____|8_________|61_________|E______________|4A________
South China and Eastern|6 |49, 48 |D18 plus |3U plus
Archipelagic Seas______|__________|___________|others_________|others____
*The letters after the numbers are subdivisions, not footnotes.
===============================================================================
Appendix F - Cross-Reference List of Geographic Names
___________________________________________________________________________
Name |Entry in The World Factbook|Latitude |Longitude
| |(deg min)|(deg min)
___________________________|___________________________|_________|_________
___________________________________________________________________________
Abidjan (capital)___________|Cote d''Ivoire________________| 5 19 N| 4 02 W
Abkhazia (region)___________|Georgia______________________|43 00 N| 41 00 E
Abu Dhabi (capital)_________|United Arab Emirates_________|24 28 N| 54 22 E
Abu Musa (island)___________|Iran_________________________|25 52 N| 55 03 E
Abuja (capital)_____________|Nigeria______________________| 9 12 N| 7 11 E
Abyssinia (former name for |Ethiopia | 8 00 N| 38 00 E
Ethiopia)___________________|_____________________________|_______|________
Acapulco (city)_____________|Mexico_______________________|16 51 N| 99 55 W
Accra (capital)_____________|Ghana________________________| 5 33 N| 0 13 W
Adamstown (capital)_________|Pitcairn Islands_____________|25 04 S|130 05 W
Addis Ababa (capital)_______|Ethiopia_____________________| 9 02 N| 38 42 E
Adelie Land (Terre Adelie) |Antarctica |66 30 S|139 00 E
(claimed by France)_________|_____________________________|_______|________
Aden (city)_________________|Yemen________________________|12 46 N| 45 01 E
Aden, Gulf of_______________|Indian Ocean_________________|12 30 N| 48 00 E
Admiralty Island____________|United States (Alaska)_______|57 44 N|134 20 W
Admiralty Islands___________|Papua New Guinea_____________| 2 10 S|147 00 E
Adriatic Sea________________|Atlantic Ocean_______________|42 30 N| 16 00 E
Adygey (region)_____________|Russia_______________________|44 30 N| 40 10 E
Aegean Islands______________|Greece_______________________|38 00 N| 25 00 E
Aegean Sea__________________|Atlantic Ocean_______________|38 30 N| 25 00 E
Afars and Issas, French |Djibouti |11 30 N| 43 00 E
Territory of the (FTAI) | | |
(former name for Djibouti)__|_____________________________|_______|________
Afghanestan (local name for |Afghanistan |33 00 N| 65 00 E
Afghanistan)________________|_____________________________|_______|________
Agalega Islands_____________|Mauritius____________________|10 25 S| 56 40 E
Agana (city; former name for|Guam |13 28 N|144 45 E
Hagatna)____________________|_____________________________|_______|________
Ajaccio (city)______________|France (Corsica)_____________|41 55 N| 8 44 E
Ajaria (region)_____________|Georgia______________________|41 45 N| 42 10 E
Akmola (city; former name |Kazakhstan |51 10 N| 71 30 E
for Astana)_________________|_____________________________|_______|________
Aksai Chin (region) |China (de facto), India |35 00 N| 79 00 E
____________________________|(claimed)____________________|_______|________
Al Arabiyah as Suudiyah |Saudi Arabia |25 00 N| 45 00 E
(local name for Saudi | | |
Arabia)_____________________|_____________________________|_______|________
Al Bahrayn (local name for |Bahrain |26 00 N| 50 33 E
Bahrain)____________________|_____________________________|_______|________
Al Imarat al Arabiyah al |United Arab Emirates |24 00 N| 54 00 E
Muttahidah (local name for | | |
the United Arab Emirates)___|_____________________________|_______|________
Al Iraq (local name for |Iraq |33 00 N| 44 00 E
Iraq)_______________________|_____________________________|_______|________
Al Jaza`ir (local name for |Algeria |28 00 N| 3 00 E
Algeria)____________________|_________________','e78009b47660e3f00d6904d57fd3c77a9cb1cecf856d26f600f1ee0fc562f7b8','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd23a289f2711864686c6619bb7bb70ed06061d09e256503da2aa08776b83e30',2002,'ZW','Zimbabwe','communications',242,'____________|_______|________
Al Kuwayt (local name for |Kuwait |29 30 N| 45 45 E
Kuwait)_____________________|_____________________________|_______|________
Al Maghrib (local name for |Morocco |32 00 N| 5 00 W
Morocco)____________________|_____________________________|_______|________
Al Urdun (local name for |Jordan |31 00 N| 36 00 E
Jordan)_____________________|_____________________________|_______|________
Al Yaman (local name for |Yemen |15 00 N| 48 00 E
Yemen)______________________|_____________________________|_______|________
Aland Islands_______________|Finland______________________|60 15 N| 20 00 E
Alaska (state)______________|United States________________|65 00 N|153 00 W
Alaska, Gulf of_____________|Pacific Ocean________________|58 00 N|145 00 W
Alboran Sea_________________|Atlantic Ocean_______________|36 00 N| 2 30 W
Aldabra Islands (Groupe |Seychelles | 9 25 S| 46 22 E
d`Aldabra)__________________|_____________________________|_______|________
Alderney (island)___________|Guernsey_____________________|49 43 N| 2 12 W
Aleutian Islands____________|United States (Alaska)_______|52 00 N|176 00 W
Alexander Archipelago |United States (Alaska) |57 00 N|134 00 W
(island group)______________|_____________________________|_______|________
Alexander Island____________|Antarctica___________________|71 00 S| 70 00 W
Alexandretta (region; former|Turkey |36 34 N| 36 08 E
name for Iskenderun)________|_____________________________|_______|________
Alexandria (city)___________|Egypt________________________|31 12 N| 29 54 E
Algiers (capital)___________|Algeria______________________|36 47 N| 2 03 E
Alhucemas, Penon de (island |Spain |35 13 N| 3 53 W
group)______________________|_____________________________|_______|________
Alma-Ata (city; former name |Kazakhstan |43 15 N| 76 57 E
for Almaty)_________________|_____________________________|_______|________
Almaty (former capital)_____|Kazakhstan___________________|43 15 N| 76 57 E
Alofi (capital)_____________|Niue_________________________|19 01 S|169 55 E
Alphonse Island_____________|Seychelles___________________| 7 01 S| 52 45 E
Alsace (region)_____________|France_______________________|48 30 N| 7 20 E
Amami Strait________________|Pacific Ocean________________|28 40 N|129 30 E
Amindivi Islands (former |India |11 30 N| 72 30 E
name for Laccadive Islands) |_____________________________|_______|________
Amirante Isles (Les |Seychelles | 6 00 S| 53 10 E
Amirantes) (island group)___|_____________________________|_______|________
Amman (capital)_____________|Jordan_______________________|31 57 N| 35 56 E
Amsterdam (capital)_________|Netherlands__________________|52 23 N| 4 54 E
Amsterdam Island (Ile |French Southern and Antarctic|37 52 S| 77 32 E
Amsterdam)__________________|Lands________________________|_______|________
Amundsen Sea________________|Southern Ocean_______________|72 30 S|112 00 W
Amur River__________________|China, Russia________________|52 56 N|141 10 E
Amurskiy Liman (strait)_____|Pacific Ocean________________|53 00 N|141 30 E
Anadyrskiy Zaliv (gulf)_____|Pacific Ocean________________|64 00 N|177 00 E
Anatolia (region)___________|Turkey_______________________|39 00 N| 35 00 E
Andaman Islands_____________|India________________________|12 00 N| 92 45 E
Andaman Sea_________________|Indian Ocean_________________|10 00 N| 95 00 E
Andorra la Vella (capital)__|Andorra______________________|42 30 N| 1 30 E
Andros (island)_____________|Greece_______________________|37 45 N| 24 42 E
Andros Island_______________|The Bahamas__________________|24 26 N| 77 57 W
Anegada Passage_____________|Atlantic Ocean_______________|18 30 N| 63 40 W
Angkor Wat (ruins)__________|Cambodia_____________________|13 26 N|103 50 E
Anglo-Egyptian Sudan (former|Sudan |15 00 N| 30 00 E
name for Sudan)_____________|_____________________________|_______|________
Anjouan (island)____________|Comoros______________________|12 15 S| 44 25 E
Ankara (capital)____________|Turkey_______________________|39 56 N| 32 52 E
Annobon (island)____________|Equatorial Guinea____________| 1 25 S| 5 36 E
Antananarivo (capital)______|Madagascar___________________|18 52 S| 47 30 E
Antigua (island)____________|Antigua and Barbuda__________|14 34 N| 90 44 W
Antipodes Islands___________|New Zealand__________________|49 41 S|178 43 E
Antwerp (city)______________|Belgium______________________|51 13 N| 4 25 E
Aomen (local Chinese short- |Macau |22 10 N|113 33 E
form name for Macau)________|_____________________________|_______|________
Aozou Strip (region)________|Chad_________________________|22 00 N| 18 00 E
Apia (capital)______________|Samoa________________________|13 50 S|171 44 N
Aqaba, Gulf of______________|Indian Ocean_________________|29 00 N| 34 30 E
Arab, Shatt al (river)______|Iran, Iraq___________________|29 57 N| 48 34 E
Arabian Sea_________________|Indian Ocean_________________|15 00 N| 65 00 E
Arafura Sea_________________|Pacific Ocean________________| 9 00 S|133 00 E
Aral Sea____________________|Kazakhstan, Uzbekistan_______|45 00 N| 60 00 E
Argun River_________________|China, Russia________________|53 20 N|121 28 E
Aru Sea_____________________|Pacific Ocean________________| 6 15 S|135 00 E
Ascension Island____________|Saint Helena_________________| 7 57 S| 14 22 W
Ashgabat (capital)__________|Turkmenistan_________________|37 57 N| 58 23 E
Ashkhabad (see Ashgabat)____|Turkmenistan_________________|37 57 N| 58 23 E
Asmara (capital)____________|Eritrea______________________|15 20 N| 38 53 E
Asmera (see Asmara)_________|Eritrea______________________|15 20 N| 38 53 E
As-Sudan (local name for |Sudan |15 00 N| 30 00 E
Sudan)______________________|_____________________________|_______|________
Assumption Island___________|Seychelles___________________| 9 46 S| 46 34 E
Astana (Akmola) (capital)___|Kazakhstan___________________|51 10 N| 71 30 E
Asuncion (capital)__________|Paraguay_____________________|25 16 S| 57 40 W
Asuncion Island_____________|Northern Mariana Islands_____|19 40 N|145 24 E
Atacama (desert)____________|Chile________________________|23 00 S| 70 10 W
Atacama (region)____________|Chile________________________|24 30 S| 69 15 W
Athens (capital)____________|Greece_______________________|37 59 N| 23 44 E
Attu Island_________________|United States________________|52 55 N|172 57 E
Auckland Islands____________|New Zealand__________________|51 00 S|166 30 E
Australes, Iles (Iles |French Polynesia |23 20 S|151 00 W
Tubuai) (island group)______|_____________________________|_______|________
Avarua (capital)____________|Cook Islands_________________|21 12 S|159 46 W
Axel Heiberg Island_________|Canada_______________________|79 30 N| 90 00 W
Azad Kashmir (region)_______|Pakistan_____________________|34 30 N| 74 00 E
Azarbaycan (local name for |Azerbaijan |40 30 N| 47 30 E
Azerbaijan)_________________|_____________________________|_______|________
Azerbaidzhan (local name for|Azerbaijan |40 30 N| 47 30 E
Azerbaijan)_________________|_____________________________|_______|________
Azores (islands)____________|Portugal_____________________|38 30 N| 28 00 W
Azov, Sea of________________|Atlantic Ocean_______________|49 00 N| 36 00 E
___________________________________________________________________________
Bab el Mandeb (strait)______|Indian Ocean_________________|12 40 N| 43 20 E
Babuyan Channel_____________|Pacific Ocean________________|18 44 N|121 40 E
Babuyan Islands_____________|Philippines__________________|19 10 N|121 40 E
Baffin Bay__________________|Arctic Ocean_________________|73 00 N| 66 00 W
Baffin Island_______________|Canada_______________________|68 00 N| 70 00 W
Baghdad (capital)___________|Iraq_________________________|33 21 N| 44 25 E
Baki (see Baku)_____________|Azerbaijan___________________|40 23 N| 49 51 E
Baku (capital)______________|Azerbaijan___________________|40 23 N| 49 51 E
Baky (see Baku)_____________|Azerbaijan___________________|40 23 N| 49 51 E
Balabac Strait______________|Pacific Ocean________________| 7 35 N|117 00 E
Balearic Islands____________|Spain________________________|39 30 N| 3 00 E
Balearic Sea (Iberian Sea)__|Atlantic Ocean_______________|40 30 N| 2 00 E
Bali (island)_______________|Indonesia____________________| 8 20 S|115 00 E
Bali Sea____________________|Indian Ocean_________________| 7 45 S|115 30 E
Balintang Channel___________|Pacific Ocean________________|19 49 N|121 40 E
Balintang Islands___________|Philippines__________________|19 55 N|122 10 E
Balkan Peninsula |Albania, Bosnia and |42 00 N| 23 00 E
|Herzegovina, Bulgaria, | |
|Croatia, Greece, Romania, | |
|Serbia and Montenegro, | |
|Slovenia, The Former Yugoslav| |
|Republic of Macedonia, Turkey| |
____________________________|(European part)______________|_______|________
Balleny Islands_____________|Antarctica___________________|67 00 S|163 00 E
Balochistan (region)________|Pakistan_____________________|28 00 N| 63 00 E
Baltic Sea__________________|Atlantic Ocean_______________|57 00 N| 19 00 E
Bamako (capital)____________|Mali_________________________|12 39 N| 8 00 W
Banaba (Ocean Island)_______|Kiribati_____________________| 0 52 S|169 35 E
Banat (region)______________|Hungary, Romania, Yugoslavia |45 30 N| 21 00 E
Banda Sea___________________|Pacific Ocean________________| 5 00 S|128 00 E
Bandar Seri Begawan |Brunei | 4 52 S|114 55 E
(capital)___________________|_____________________________|_______|________
Bangka (island)_____________|Indonesia____________________| 2 30 S|106 00 E
Bangkok (capital)___________|Thailand_____________________|13 45 N|100 31 E
Bangui (capital)____________|Central African Republic_____| 4 22 N| 18 35 E
Banjul (capital)____________|The Gambia___________________|13 28 N| 16 39 W
Banks Island________________|Australia____________________|10 12 S|142 16 E
Banks Island________________|Canada_______________________|75 15 N|121 30 W
Banks Islands (Iles Banks)__|Vanuatu______________________|14 00 S|167 30 E
Barbuda (island)____________|Antigua and Barbuda__________|17 38 N| 61 48 W
Barents Sea_________________|Arctic Ocean_________________|74 00 N| 36 00 E
Barranquilla (city)_________|Colombia_____________________|10 59 N| 74 48 W
Bashi Channel_______________|Pacific Ocean________________|22 00 N|121 00 E
Basilan Strait______________|Pacific Ocean________________| 6 49 N|122 05 E
Basque Provinces____________|Spain________________________|43 00 N| 2 30 W
Bass Strait_________________|Pacific Ocean________________|39 20 S|145 30 E
Basse-Terre (capital)_______|Guadeloupe___________________|16 00 N| 61 44 W
Basseterre (capital)________|Saint Kitts and Nevis________|17 18 N| 62 43 W
Bastia (city)_______________|France (Corsica)_____________|42 42 N| 9 27 E
Basutoland (former name for |Lesotho |29 30 S| 28 30 E
Lesotho)____________________|_____________________________|_______|________
Batan Islands_______________|Philippines__________________|20 30 N|121 50 E
Bavaria (Bayern) (region)___|Germany______________________|48 30 N| 11 30 E
Beagle Channel______________|Atlantic Ocean_______________|54 53 S| 68 10 W
Bear Island (see Bjornoya)__|Svalbard_____________________|74 26 N| 19 05 E
Beaufort Sea________________|Arctic Ocean_________________|73 00 N|140 00 W
Bechuanaland (former name |Botswana |22 00 S| 24 00 E
for Botswana)_______________|_____________________________|_______|________
Beijing (capital)___________|China________________________|39 56 N|116 24 E
Beirut (capital)____________|Lebanon______________________|33 53 N| 35 30 E
Bekaa Valley________________|Lebanon______________________|34 00 N| 36 05 E
Belau (Palau Islands)_______|Palau________________________| 7 30 N|134 30 E
Belep Islands (Iles Belep)__|New Caledonia________________|19 45 S|163 40 E
Belgian Congo (former name |Democratic Republic of the | 0 00 N| 25 00 E
for Democratic Republic of |Congo | |
the Congo)__________________|_____________________________|_______|________
Belgie (local name for |Belgium |50 50 N| 4 00 E
Belgium)____________________|_____________________________|_______|________
Belgique (local name for |Belgium |50 50 N| 4 00 E
Belgium)____________________|_____________________________|_______|________
Belgrade (capital)__________|Yugoslavia___________________|44 50 N| 20 30 E
Belize City (capital)_______|Belize_______________________|17 30 N| 88 12 W
Belle Isle, Strait of_______|Atlantic Ocean_______________|51 35 N| 56 30 W
Bellingshausen Sea__________|Southern Ocean_______________|71 00 S| 85 00 W
Belmopan (capital)__________|Belize_______________________|17 15 N| 88 46 W
Belorussia (former name for |Belarus |53 00 N| 28 00 E
Belarus)____________________|_____________________________|_______|________
Benadir (region; former name|Somalia | 4 00 N| 46 00 E
of Italian Somaliland)______|_____________________________|_______|________
Bengal, Bay of______________|Indian Ocean_________________|15 00 N| 90 00 E
Berau, Gulf of______________|Pacific Ocean________________| 2 30 S|132 30 E
Bering Island_______________|Russia_______________________|55 00 N|166 30 E
Bering Sea__________________|Pacific Ocean________________|60 00 N|175 00 W
Bering Strait_______________|Pacific Ocean________________|65 30 N|169 00 W
Berkner Island______________|Antarctica___________________|79 30 S| 49 30 W
Berlin (capital)____________|Germany______________________|52 31 N| 13 24 E
Berlin, East (former name |Germany |52 30 N| 13 33 E
for eastern sector of | | |
Berlin)_____________________|_____________________________|_______|________
Berlin, West (former name |Germany |52 30 N| 12 20 E
for western sector of | | |
Berlin)_____________________|_____________________________|_______|________
Bern (capital)______________|Switzerland__________________|46 57 N| 7 26 E
Bessarabia (region)_________|Moldova, Romania, Ukraine____|47 00 N| 28 30 E
Bharat (local name for |India |20 00 N| 77 00 E
India)______________________|_____________________________|_______|________
Bhopal (city)_______________|India________________________|23 16 N| 77 24 E
Biafra (region)_____________|Nigeria______________________| 5 30 N| 7 30 E
Big Diomede Island__________|Russia_______________________|65 46 N|169 06 W
Bijagos, Arquipelago dos |Guinea-Bissau |11 25 N| 16 20 W
(island group)______________|_____________________________|_______|________
Bikini Atoll________________|Marshall Islands_____________|11 35 N|165 23 E
Bilbao (city)_______________|Spain________________________|43 15 N| 2 58 W
Bioko (island)______________|Equatorial Guinea____________| 3 30 N| 8 42 E
Biscay, Bay of______________|Atlantic Ocean_______________|44 00 N| 4 00 W
Bishkek (capital)___________|Kyrgyzstan___________________|42 54 N| 74 36 E
Bishop Rock_________________|United Kingdom_______________|49 52 N| 6 27 W
Bismarck Archipelago (island|Papua New Guinea | 5 00 S|150 00 E
group)______________________|_____________________________|_______|________
Bismarck Sea________________|Pacific Ocean________________| 4 00 S|148 00 E
Bissau (capital)____________|Guinea-Bissau________________|11 51 N| 15 35 W
Bjornoya (Bear Island)______|Svalbard_____________________|74 26 N| 19 05 E
Black Forest (region)_______|Germany______________________|48 00 N| 8 15 E
Black Rock (island) |South Georgia and the South |53 39 S| 41 48 W
____________________________|Sandwich Islands_____________|_______|________
Black Sea___________________|Atlantic Ocean_______________|43 00 N| 35 00 E
Bloemfontein (city, judicial|South Africa |29 12 S| 26 07 E
center)_____________________|_____________________________|_______|________
Bo Hai (gulf)_______________|Pacific Ocean________________|38 00 N|120 00 E
Boa Vista (island)__________|Cape Verde___________________|16 05 N| 22 50 W
Bogota (capital)____________|Colombia_____________________| 4 36 N| 74 05 W
Bohemia (region)____________|Czech Republic_______________|50 00 N| 14 30 E
Bombay (see Mumbai)_________|India________________________|18 58 N| 72 50 E
Bonaire (island)____________|Netherlands Antilles_________|12 10 N| 68 15 W
Bonifacio, Strait of________|Atlantic Ocean_______________|41 01 N| 14 00 E
Bonin Islands_______________|Japan________________________|27 00 N|140 10 E
Bonn (capital)______________|Germany______________________|50 44 N| 7 05 E
Bophuthatswana (enclave |South Africa |26 30 S| 25 30 E
region)_____________________|_____________________________|_______|________
Bora-Bora (island)__________|French Polynesia_____________|16 30 S|151 45 W
Bordeaux (city)_____________|France_______________________|44 50 N| 0 34 W
Borneo (island)_____________|Brunei, Indonesia, Malaysia__| 0 30 N|114 00 E
Bornholm (island)___________|Denmark______________________|55 10 N| 15 00 E
Bosna i Hercegovina (local |Bosnia and Herzegovina |44 00 N| 18 00 E
name for Bosnia and | | |
Herzegovina)________________|_____________________________|_______|________
Bosnia (political region)___|Bosnia and Herzegovina_______|44 00 N| 18 00 E
Bosporus (strait)___________|Atlantic Ocean_______________|41 00 N| 29 00 E
Bothnia, Gulf of____________|Atlantic Ocean_______________|63 00 N| 20 00 E
Bougainville (island)_______|Papua New Guinea_____________| 6 00 S|155 00 E
Bougainville Strait_________|Pacific Ocean________________| 6 40 S|156 10 E
Bounty Islands______________|New Zealand__________________|47 43 S|174 00 E
Bourbon Island (former name |Reunion |21 06 S| 55 36 E
of Reunion)_________________|_____________________________|_______|________
Brasilia (capital)__________|Brazil_______________________|15 47 S| 47 55 W
Bratislava (capital)________|Slovakia_____________________|48 09 N| 17 07 E
Brazzaville (capital)_______|Republic of the Congo________| 4 16 S| 15 17 E
Bridgetown (capital)________|Barbados_____________________|13 06 N| 59 37 W
Brisbane (city)_____________|Australia____________________|27 28 S|153 02 E
Bristol Bay_________________|Pacific Ocean________________|57 00 N|160 00 W
Bristol Channel_____________|Atlantic Ocean_______________|51 18 N| 3 30 W
Britain (see Great Britain) |United Kingdom_______________|54 00 N| 2 00 W
British Bechuanaland |South Africa |27 30 S| 23 30 E
(region; former name for | | |
northwest South Africa)_____|_____________________________|_______|________
British Central African |Malawi |13 30 S| 34 00 E
Protectorate (former name | | |
of__Nyasaland)______________|_____________________________|_______|________
British East Africa (former |Kenya, Tanzania, Uganda | 1 00 N| 38 00 E
name for British possessions| | |
in eastern Africa)__________|_____________________________|_______|________
British Guiana (former name |Guyana | 5 00 N| 59 00 W
for Guyana)_________________|_____________________________|_______|________
British Honduras (former |Belize |17 15 N| 88 45 W
name for Belize)____________|_____________________________|_______|________
British Solomon Islands |Solomon Islands | 8 00 S|159 00 E
(former name for Solomon | | |
Islands)____________________|_____________________________|_______|________
British Somaliland (former |Somalia |10 00 N| 49 00 E
name for northern Somalia)__|_____________________________|_______|________
Brussels (capital)__________|Belgium______________________|50 50 N| 4 20 E
Bubiyan (island)____________|Kuwait_______________________|29 47 N| 48 10 E
Bucharest (capital)_________|Romania______________________|44 26 N| 26 06 E
Budapest (capital)__________|Hungary______________________|47 30 N| 19 05 E
Buenos Aires (capital)______|Argentina____________________|34 36 S| 58 27 W
Bujumbura (capital)_________|Burundi______________________| 3 23 S| 29 22 E
Bukovina (region)___________|Romania, Ukraine_____________|48 00 N| 26 00 E
Byelarus (local name for |Belarus |53 00 N| 28 00 E
Belarus)____________________|_____________________________|_______|________
Byelorussia (former name for|Belarus |53 00 N| 28 00 E
Belarus)____________________|_____________________________|_______|________
___________________________________________________________________________
Cabinda (province)__________|Angola_______________________| 5 33 S| 12 12 E
Cabo Verde (local name for |Cape Verde |16 00 N| 24 00 W
Cape Verde)_________________|_____________________________|_______|________
Cabot Strait________________|Atlantic Ocean_______________|47 20 N| 59 30 W
Caicos Islands______________|Turks and Caicos Islands_____|21 56 N| 71 58 W
Cairo (capital)_____________|Egypt________________________|30 03 N| 31 15 E
California, Gulf of_________|Pacific Ocean________________|28 00 N|112 00 W
Cameroun (local name for |Cameroon | 6 00 N| 12 00 E
Cameroon)___________________|_____________________________|_______|________
Campbell Island_____________|New Zealand__________________|52 33 S|169 09 E
Campeche, Bay of____________|Atlantic Ocean_______________|20 00 N| 94 00 W
Canal Zone (former name for |Panama | 9 00 N| 79 45 W
US possessions in Panama)___|_____________________________|_______|________
Canarias Sea________________|Atlantic Ocean_______________|28 00 N| 16 00 W
Canary Islands______________|Spain________________________|28 00 N| 15 30 W
Canberra (capital)__________|Australia____________________|35 17 S|149 08 E
Cancun (city)_______________|Mexico_______________________|21 10 N| 86 50 W
Canton (Guangzhou) (city)___|China________________________|23 06 N|113 16 E
Canton Island (Kanton |Kiribati | 2 49 S|171 40 W
Island)_____________________|_____________________________|_______|________
Cape Juby (region; former |Morocco |27 53 N| 12 58 W
name for Southern Morocco)__|_____________________________|_______|________
Cape of Good Hope (cape; |South Africa |34 15 S| 18 25 E
also alternate name for Cape| | |
Province of South Africa)___|_____________________________|_______|________
Cape Province (region; |South Africa |31 30 S| 22 30 E
former name for Northern, | | |
Western, and Eastern Cape | | |
Provinces of South Africa)__|_____________________________|_______|________
Cape Town (legislative |South Africa |33 57 S| 18 28 W
capital)____________________|_____________________________|_______|________
Caracas (capital)___________|Venezuela____________________|10 30 N| 66 56 W
Cargados Carajos Shoals_____|Mauritius____________________|16 25 S| 59 38 E
Caribbean Sea_______________|Atlantic Ocean_______________|15 00 N| 73 00 W
Caroline Islands |Federated States of | 7 30 N|148 00 E
____________________________|Micronesia, Palau____________|_______|________
Carpatho-Ukraine (region; |Ukraine |48 22 N| 23 32 E
former name for Zakarpats`ka| | |
oblast`)____________________|_____________________________|_______|________
Carpentaria, Gulf of________|Pacific Ocean________________|14 00 S|139 00 E
Castries (capital)__________|Saint Lucia__________________|14 01 N| 61 00 W
Catalonia (region)__________|Spain________________________|42 00 N| 2 00 E
Cato Island_________________|Australia____________________|23 15 S|155 32 E
Caucasus (region)___________|Russia_______________________|42 00 N| 45 00 E
Cayenne (capital)___________|French Guiana________________| 4 56 N| 52 20 W
Celebes (island)____________|Indonesia____________________| 2 00 S|121 00 E
Celebes Sea_________________|Pacific Ocean________________| 3 00 N|122 00 E
Celtic Sea__________________|Atlantic Ocean_______________|51 00 N| 6 30 W
Central African Empire |Central African Republic | 7 00 N| 21 00 E
(former name for Central | | |
African Republic)___________|_____________________________|_______|________
Ceram (Seram) Sea___________|Pacific Ocean________________| 2 30 S|129 30 E
Ceska Republika (local name |Czech Republic |49 45 N| 15 30 E
for Czech Republic)_________|_____________________________|_______|________
Ceskoslovensko (former local|Czech Republic, Slovakia |49 00 N| 17 30 E
name for Czechoslovakia)____|_____________________________|_______|________
Ceuta (city)________________|Spain________________________|35 53 N| 5 19 W
Ceylon (former name for Sri |Sri Lanka | 7 00 N| 81 00 E
Lanka)______________________|_____________________________|_______|________
Chafarinas, Islas (island)__|Spain________________________|35 12 N| 2 26 W
Chago','6c7bb14f621c110401c9432e0b563cd025917b8482eb6fa257510c66449943bf','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3526300ce97638d396d3ebe62bbefd5146506f4c2328d665c2fc201d6f32d0f',2002,'ZW','Zimbabwe','communications',243,'s Archipelago (Oil |British Indian Ocean | 6 00 S| 71 30 E
Islands)____________________|Territory____________________|_______|________
Challenger Deep (Mariana |Pacific Ocean |11 22 N|142 36 E
Trench)_____________________|_____________________________|_______|________
Channel Islands_____________|Guernsey, Jersey_____________|49 20 N| 2 20 W
Charlotte Amalie (capital)__|Virgin Islands_______________|18 21 N| 64 56 W
Chatham Islands_____________|New Zealand__________________|44 00 S|176 30 W
Chechnya (Chechnia) (region)|Russia_______________________|43 15 N| 45 40 E
Cheju Strait________________|Pacific Ocean________________|34 00 N|126 30 E
Cheju-do (island)___________|Korea, South_________________|33 20 N|126 30 E
Chennai (Madras) (city)_____|India________________________|13 04 N| 80 16 E
Chesterfield Islands (Iles |New Caledonia |19 52 S|158 15 E
Chesterfield)_______________|_____________________________|_______|________
Chihli, Gulf of (see Bo Hai)|Pacific Ocean________________|38 30 N|120 00 E
Chiloe (island)_____________|Chile________________________|42 50 S| 74 00 W
China, People''s Republic of |China________________________|35 00 N|105 00 E
China, Republic of__________|Taiwan_______________________|23 30 N|105 00 E
Chisinau (capital)__________|Moldova______________________|47 00 N| 28 50 E
Choiseul (island)___________|Solomon Islands______________| 7 05 S|121 00 E
Chosen (local name for North|North Korea |40 00 N|127 00 E
Korea)______________________|_____________________________|_______|________
Christmas Island (Indian |Australia |10 25 S|105 39 E
Ocean)______________________|_____________________________|_______|________
Christmas Island |Kiribati | 1 52 N|157 20 W
(Kiritimati) (Pacific Ocean)|_____________________________|_______|________
Chukchi Sea_________________|Arctic Ocean_________________|69 00 N|171 00 W
Chuuk Islands (Truk Islands)|Federated States of | 7 25 N|151 47 W
____________________________|Micronesia___________________|_______|________
Cilicia (region)____________|Turkey_______________________|36 50 N| 34 30 E
Ciskei (enclave)____________|South Africa_________________|33 00 S| 27 00 E
Citta del Vaticano (local |Holy See |41 54 N| 12 27 E
name for Vatican City)______|_____________________________|_______|________
Cochin China (region)_______|Vietnam______________________|11 00 N|107 00 E
Coco, Isla del (island)_____|Costa Rica___________________| 5 32 N| 87 04 W
Cocos Islands_______________|Cocos (Keeling) Islands______|12 30 S| 96 50 E
Colombo (capital)___________|Sri Lanka____________________| 6 56 N| 79 51 E
Colon, Archipielago de |Ecuador | 0 00 N| 90 30 W
(Galapagos Islands)_________|_____________________________|_______|________
Commander Islands |Russia |55 00 N|167 00 E
(Komandorskiye Ostrova)_____|_____________________________|_______|________
Comores (local name for |Comoros |12 10 S| 44 15 E
Comoros)____________________|_____________________________|_______|________
Con Son (islands)___________|Vietnam______________________| 8 43 N|106 36 E
Conakry (capital)___________|Guinea_______________________| 9 31 N| 13 43 W
Confederatio Helvetica |Switzerland |47 00 N| 8 00 E
(local name for Switzerland)|_____________________________|_______|________
Congo (Brazzaville) (former |Republic of the Congo | 1 00 S| 15 00 E
name for Republic of the | | |
Congo)______________________|_____________________________|_______|________
Congo (Leopoldville) (former|Democratic Republic of the | 0 00 N| 25 00 E
name for the Democratic |Congo | |
Republic of the Congo)______|_____________________________|_______|________
Constantinople (city; former|Turkey |41 01 N| 28 58 E
name for Istanbul)__________|_____________________________|_______|________
Cook Strait_________________|Pacific Ocean________________|41 15 S|174 30 E
Copenhagen (capital)________|Denmark______________________|55 40 N| 12 35 E
Coral Sea___________________|Pacific Ocean________________|15 00 S|150 00 E
Corfu (island)______________|Greece_______________________|39 40 N| 19 45 E
Corinth (region)____________|Greece_______________________|37 56 N| 22 56 E
Corisco (island)____________|Equatorial Guinea____________| 0 55 N| 9 19 E
Corn Islands (Islas del |Nicaragua |12 15 N| 83 00 W
Maiz)_______________________|_____________________________|_______|________
Corocoro Island_____________|Guyana, Venezuela____________| 3 38 N| 66 50 W
Corsica (Corse) (island)____|France_______________________|42 00 N| 9 00 E
Cosmoledo Group (Atoll de |Seychelles | 9 43 S| 47 35 E
Cosmoledo) (island group)___|_____________________________|_______|________
Cotonou (capital)___________|Benin________________________| 6 21 N| 2 26 E
Cotopaxi (volcano)__________|Ecuador______________________| 0 39 S| 78 26 W
Courantyne River____________|Guyana, Suriname_____________| 5 57 N| 57 06 W
Cozumel (island)____________|Mexico_______________________|20 30 N| 86 55 W
Crete (island)______________|Greece_______________________|35 15 N| 24 45 E
Crimea (region)_____________|Ukraine______________________|45 00 N| 34 00 E
Crimean Peninsula___________|Ukraine______________________|45 00 N| 34 00 E
Crooked Island Passage______|Atlantic Ocean_______________|22 55 N| 74 35 W
Crozet Islands (Iles Crozet)|French Southern and Antarctic|46 30 S| 51 00 E
____________________________|Lands________________________|_______|________
Cyclades (island group)_____|Greece_______________________|37 00 N| 25 10 E
Cyrenaica (region)__________|Libya________________________|31 00 N| 22 00 E
Czechoslovakia (former name |Czech Republic, Slovakia |49 00 N| 18 00 E
for the entity that | | |
subsequently split into the | | |
Czech Republic and Slovakia)|_____________________________|_______|________
___________________________________________________________________________
Dagestan (region)___________|Russia_______________________|43 00 N| 47 00 E
Dahomey (former name for |Benin | 9 30 N| 2 15 E
Benin)______________________|_____________________________|_______|________
Daito Islands_______________|Japan________________________|43 00 N| 17 00 E
Dakar (capital)_____________|Senegal______________________|14 40 N| 17 26 W
Dalmatia (region)___________|Croatia______________________|43 00 N| 17 00 E
Daman (Damao) (city)________|India________________________|20 10 N| 73 00 E
Damascus (capital)__________|Syria________________________|33 30 N| 36 18 E
Danger Islands (see Pukapuka|Cook Islands |10 53 S|165 49 W
Atoll)______________________|_____________________________|_______|________
Danish Straits______________|Atlantic Ocean_______________|58 00 N| 11 00 E
Danish West Indies ( former |Virgin Islands |18 20 N| 64 50 W
name for the Virgin Islands)|_____________________________|_______|________
Danmark (local name)________|Denmark______________________|56 00 N| 10 00 E
Danzig (city; former name |Poland |54 23 N| 18 40 E
for Gdansk)_________________|_____________________________|_______|________
Dao Bach Long Vi (island)___|Vietnam______________________|20 08 N|107 44 E
Dar es Salaam (capital)_____|Tanzania_____________________| 6 48 S| 39 17 E
Dardanelles (strait)________|Atlantic Ocean_______________|40 15 N| 26 25 E
Davis Strait________________|Atlantic Ocean_______________|67 00 N| 57 00 W
Dead Sea____________________|Israel, Jordan, West Bank____|32 30 N| 35 30 E
Deception Island____________|Antarctica___________________|62 56 S| 60 34 W
Denmark Strait______________|Atlantic Ocean_______________|67 00 N| 24 00 W
D''Entrecasteaux Islands_____|Papua New Guinea_____________| 9 30 S|150 40 E
Desolation Islands (Isles |French Southern and Antarctic|49 30 S| 69 30 E
Kerguelen)__________________|Lands________________________|_______|________
Deutschland (local name for |Germany |51 00 N| 9 00 E
Germany)____________________|_____________________________|_______|________
Devils Island (Ile du |French Guiana | 5 17 N| 52 35 W
Diable)_____________________|_____________________________|_______|________
Devon Island________________|Canada_______________________|76 00 N| 87 00 W
Dhaka (capital)_____________|Bangladesh___________________|23 43 N| 90 25 E
Dhivehi Raajje (local name |Maldives | 3 15 N| 73 00 E
for Maldives)_______________|_____________________________|_______|________
Dhofar (region)_____________|Oman_________________________|17 00 N| 54 10 E
Diego Garcia (island) |British Indian Ocean | 7 20 S| 72 25 E
____________________________|Territory____________________|_______|________
Diego Ramirez (islands)_____|Chile________________________|56 30 S| 68 43 W
Dilmun (former name for |Bahrain | 7 00 N| 81 00 E
Bahrain)____________________|_____________________________|_______|________
Diomede Islands |Russia (Big Diomede), United |65 47 N|169 00 W
____________________________|States (Little Diomede)______|_______|________
Diu (region)________________|India________________________|20 42 N| 70 59 E
Djibouti (capital)__________|Djibouti_____________________|11 30 N| 43 15 E
Dnieper (river) |Belarus, Russia, Ukraine |46 30 N| 32 18 E
____________________________|(Dnyapro, Dnepr, Dnipro)_____|_______|________
Dniester (river) |Moldova, Ukraine (Nistru, |46 18 N| 30 17 E
____________________________|Dnister)_____________________|_______|________
Dobruja (region)____________|Bulgaria, Romania____________|43 30 N| 28 00 E
Dodecanese (island group)___|Greece_______________________|36 00 N| 27 05 E
Dodoma (city)_______________|Tanzania_____________________| 6 11 S| 35 45 E
Doha (capital)______________|Qatar________________________|25 17 N| 51 32 E
Donets Basin________________|Russia, Ukraine______________|48 15 N| 38 30 E
Douala (city)_______________|Cameroon_____________________| 4 03 N| 9 42 E
Douglas (capital)___________|Man, Isle of_________________|54 09 N| 4 28 W
Dover, Strait of____________|Atlantic Ocean_______________|51 00 N| 1 30 E
Drake Passage |Atlantic Ocean, Southern |60 00 S| 60 00 W
____________________________|Ocean________________________|_______|________
Druk Yul (local name for |Bhutan |27 30 N| 90 30 E
Bhutan)_____________________|_____________________________|_______|________
Dubai (city)________________|United Arab Emirates_________|25 18 N| 55 18 E
Dubayy (see Dubai)__________|United Arab Emirates_________|25 18 N| 55 18 E
Dublin (capital)____________|Ireland______________________|53 20 N| 6 15 W
Dushanbe (capital)__________|Tajikistan___________________|38 35 N| 68 48 E
Dutch Antilles (former name |Netherlands Antilles |52 05 N| 4 18 E
for the Netherlands | | |
Antilles)___________________|_____________________________|_______|________
Dutch East Indies (former |Indonesia | 5 00 S|120 00 E
name for Indonesia)_________|_____________________________|_______|________
Dutch Guiana (former name |Suriname | 4 00 N| 56 00 W
for Suriname)_______________|_____________________________|_______|________
Dutch West Indies (former |Netherlands Antilles |52 05 N| 4 18 E
name for the Netherlands | | |
Antilles)___________________|_____________________________|_______|________
Dzungarian Gate (valley)____|China, Kazakhstan____________|45 25 N| 82 25 E
___________________________________________________________________________
East China Sea______________|Pacific Ocean________________|30 00 N|126 00 E
East Frisian Islands________|Germany______________________|53 44 N| 7 25 E
East Germany (German |Germany |52 00 N| 13 00 E
Democratic Republic) (former| | |
name for eastern portion of | | |
Germany)____________________|_____________________________|_______|________
East Korea Strait (Eastern |Pacific Ocean |34 00 N|129 00 E
Channel or Tsushima Strait) |_____________________________|_______|________
East Pakistan (former name |Bangladesh |24 00 N| 90 00 E
for Bangladesh)_____________|_____________________________|_______|________
East Siberian Sea___________|Arctic Ocean_________________|74 00 N|166 00 E
Easter Island (Isla de |Chile |27 07 S|109 22 W
Pascua)_____________________|_____________________________|_______|________
Eastern Channel (East Korea |Pacific Ocean |34 00 N|129 00 E
Strait or Tsushima Strait)__|_____________________________|_______|________
Eastern Samoa (former name |American Samoa |14 20 S|170 00 W
for American Samoa)_________|_____________________________|_______|________
Eesti (local name for |Estonia |59 00 N| 26 00 E
Estonia)____________________|_____________________________|_______|________
Eire (local name for |Ireland |53 00 N| 8 00 W
Ireland)____________________|_____________________________|_______|________
Elba (island)_______________|Italy________________________|42 46 N| 10 17 E
Elemi Triangle (region) |Ethiopia (claimed), Kenya (de| 5 00 N| 35 30 E
____________________________|facto), Sudan (claimed)______|_______|________
Ellada (local name for |Greece |39 00 N| 22 00 E
Greece)_____________________|_____________________________|_______|________
Ellas (local name for |Greece |39 00 N| 22 00 E
Greece)_____________________|_____________________________|_______|________
Ellef Ringnes Island________|Canada_______________________|78 00 N|103 00 W
Ellesmere Island____________|Canada_______________________|81 00 N| 80 00 W
Ellice Islands______________|Tuvalu_______________________| 8 00 S|178 00 E
Ellsworth Land (region)_____|Antarctica___________________|75 00 S| 92 00 W
Elobey, Islas de (island |Equatorial Guinea | 0 59 N| 9 33 E
group)______________________|_____________________________|_______|________
Enderbury Island____________|Kiribati_____________________| 3 08 S|171 05 W
Enewetak Atoll (Eniwetok |Marshall Islands |11 30 N|162 15 E
Atoll)______________________|_____________________________|_______|________
England (region)____________|United Kingdom_______________|52 30 N| 1 30 W
English Channel_____________|Atlantic Ocean_______________|50 20 N| 1 00 W
Eniwetok Atoll (see Enewetak|Marshall Islands |11 30 N|162 15 E
Atoll)______________________|_____________________________|_______|________
Eolie, Isole (island group) |Italy________________________|38 30 N| 15 00 E
Epirus, Northern (region)___|Albania, Greece______________|40 00 N| 20 30 E
Ertra (local name for |Eritrea |15 00 N| 39 00 E
Eritrea)____________________|_____________________________|_______|________
Espana______________________|Spain________________________|40 00 N| 4 00 W
Essequibo (region) (claimed |Guyana | 6 59 N| 58 23 W
by Venezuela)_______________|_____________________________|_______|________
Etorofu (Iturup) (island)___|Russia (de facto)____________|44 55 N|147 40 E
___________________________________________________________________________
Farquhar Group (Atoll de |Seychelles |10 10 S| 51 10 E
Farquhar) (island group)____|_____________________________|_______|________
Fergana Valley |Kyrgyzstan, Tajikistan, |41 00 N| 72 00 E
____________________________|Uzbekistan___________________|_______|________
Fernando de Noronha (island |Brazil | 3 51 S| 32 25 W
group)______________________|_____________________________|_______|________
Fernando Po (island) (see |Equatorial Guinea | 3 30 N| 8 42 E
Bioko)______________________|_____________________________|_______|________
Filipinas (local name for |Philippines |13 00 N|122 00 E
the Philippines)____________|_____________________________|_______|________
Finland, Gulf of____________|Atlantic Ocean_______________|60 00 N| 27 00 E
Flores (island)_____________|Indonesia____________________| 8 45 S|121 00 E
Flores Sea__________________|Pacific Ocean________________| 7 40 S|119 45 E
Florida, Straits of_________|Atlantic Ocean_______________|25 00 N| 79 45 W
Fongafale (capital)_________|Tuvalu_______________________| 8 30 S|179 12 E
Former Soviet Union (FSU) |Armenia, Azerbaijan, Belarus,| |
|Estonia, Georgia, Kazakhstan,| |
|Kyrgyzstan, Latvia, | |
|Lithuania, Moldova, Russia, | |
|Tajikistan, Turkmenistan, | |
____________________________|Ukraine, Uzbekistan__________|_______|________
Formosa (island)____________|Taiwan_______________________|23 30 N|121 00 E
Formosa Strait (see Taiwan |Pacific Ocean |24 00 N|119 00 E
Strait)_____________________|_____________________________|_______|________
Foroyar (local name for |Faroe Islands |62 00 N| 7 00 W
Faroe Islands)______________|_____________________________|_______|________
Fort-de-France (capital)____|Martinique___________________|14 36 N| 61 05 W
Franz Josef Land (island |Russia |81 00 N| 55 00 E
group)______________________|_____________________________|_______|________
Freetown (capital)__________|Sierra Leone_________________| 8 30 N| 13 15 W
French Cameroon (former name|Cameroon | 6 00 N| 12 00 E
for Cameroon)_______________|_____________________________|_______|________
French Guinea (former name |Guinea |11 00 N| 10 00 W
for Guinea)_________________|_____________________________|_______|________
French Indochina (former |Cambodia, Laos, Vietnam |15 00 N|107 00 E
name for French possessions | | |
in southeast Asia)__________|_____________________________|_______|________
French Morocco (former name |Morocco |32 00 N| 5 00 W
for Morocco)________________|_____________________________|_______|________
French Somaliland (former |Djibouti |11 30 N| 43 00 W
name for Djibouti)__________|_____________________________|_______|________
French Sudan (former name |Mali |17 00 N| 4 00 W
for Mali)___________________|_____________________________|_______|________
French Territory of the |Djibouti |11 30 N| 43 00 E
Afars and Issas (FTAI) | | |
(former name for Djibouti)__|_____________________________|_______|________
French Togoland (former name|Togo | 8 00 N| 1 10 E
for Togo)___________________|_____________________________|_______|________
French West Indies (former |Guadeloupe, Martinique |16 30 N| 62 00 W
name for French possessions | | |
in the West Indies)_________|_____________________________|_______|________
Friendly Islands____________|Tonga________________________|20 00 S|175 00 W
Frisian Islands_____________|Denmark, Germany, Netherlands|53 35 N| 6 40 E
Frunze (city; former name |Kyrgyzstan |42 54 N| 74 36 E
for Bishkek)________________|_____________________________|_______|________
Funafuti (former name for |Tuvalu | 8 30 S|179 12 E
Fongafale)__________________|_____________________________|_______|________
Fundy, Bay of_______________|Atlantic Ocean_______________|45 00 N| 66 00 W
Futuna Islands (Hoorn |Wallis and Futuna |14 19 S|178 05 W
Islands/Iles de Horne)______|_____________________________|_______|________
Fyn (island)________________|Denmark______________________|55 20 N| 10 25 E
___________________________________________________________________________
Gaborone (capital)____________|Botswana___________________|24 45 S| 25 55 E
Galapagos Islands |Ecuador | 0 00 N| 90 30 W
(Archipielago de Colon)_______|___________________________|_______|________
Galicia (region)______________|Poland, Ukraine____________|49 30 N| 23 00 E
Galicia (region)______________|Spain______________________|42 45 N| 8 10 E
Galilee (region)______________|Israel_____________________|32 54 N| 35 20 E
Galleons Passage______________|Atlantic Ocean_____________|11 00 N| 60 55 W
Gambier Islands (Iles Gambier)|French Polynesia___________|23 09 S|134 58 W
Gaspar Strait_________________|Pacific Ocean______________| 3 00 S|107 00 E
Gdansk (Danzig) (city)________|Poland_____________________|54 23 N| 18 40 E
Geneva (city)_________________|Switzerland________________|46 12 N| 6 10 E
Genoa (city)__________________|Italy______________________|44 25 N| 8 57 E
George Town (capital)_________|Cayman Islands_____________|19 20 N| 81 23 W
George Town (city)____________|Malaysia___________________| 5 26 N|100 16 E
George Town (city)____________|The Bahamas________________|23 30 N| 75 46 W
Georgetown (capital)__________|Guyana_____________________| 6 48 N| 58 10 W
Georgetown (city)_____________|The Gambia_________________|13 30 N| 14 47 W
German Democratic Republic |Germany |52 00 N| 13 00 E
(East Germany) (former name | | |
for eastern portion of | | |
Germany)______________________|___________________________|_______|________
German Southwest Africa |Namibia |22 00 S| 17 00 E
(former name for Namibia)_____|___________________________|_______|________
Germany, Federal Republic of__|Germany____________________|51 00 N| 9 00 E
Gibraltar (city, peninsula)___|Gibraltar__________________|36 11 N| 5 22 W
Gibraltar, Strait of__________|Atlantic Ocean_____________|35 57 N| 5 36 W
Gidi Pass_____________________|Egypt______________________|30 13 N| 33 09 E
Gilbert Islands_______________|Kiribati___________________| 1 25 N|173 00 E
Goa (state)___________________|India______________________|14 20 N| 74 00 E
Gobi (desert)_________________|China, Mongolia____________|42 30 N|107 00 E
Godthab (Nuuk) (capital)______|Greenland__________________|64 11 N| 51 44 W
Golan Heights (region)________|Syria______________________|33 00 N| 35 45 E
Gold Coast (former name for |Ghana | 8 00 N| 2 00 W
Ghana)________________________|___________________________|_______|________
Golfo San Jorge (gulf)________|Atlantic Ocean_____________|46 00 S| 66 00 W
Golfo San Matias (gulf)_______|Atlantic Ocean_____________|41 30 S| 64 00 W
Good Hope, Cape of____________|South Africa_______________|34 24 S| 18 30 E
Goteborg (city)_______________|Sweden_____________________|57 43 N| 11 58 E
Gotland (island)______________|Sweden_____________________|57 30 N| 18 33 E
Gough Island__________________|Saint Helena_______________|40 10 S| 9 45 W
Graham Land (region)__________|Antarctica_________________|65 00 S| 64 00 W
Gran Chaco (region)___________|Argentina, Paraguay________|24 00 S| 60 00 W
Grand Bahama (island)_________|The Bahamas________________|26 40 N| 78 35 W
Grand Banks (fishing ground)__|Atlantic Ocean_____________|47 06 N| 55 48 W
Grand Cayman (island)_________|Cayman Islands_____________|19 20 N| 81 20 W
Grand Turk (Cockburn Town) |Turks and Caicos Islands |21 28 N| 71 08 W
(capital)_____________________|___________________________|_______|________
Great Australian Bight________|Indian Ocean_______________|35 00 S|130 00 E
Great Belt (Store Baelt) |Atlantic Ocean |55 30 N| 11 00 E
(strait)______________________|___________________________|_______|________
Great Bitter Lake_____________|Egypt______________________|30 20 N| 32 23 E
Great Britain (island)________|United Kingdom_____________|54 00 N| 2 00 W
Great Channel_________________|Indian Ocean_______________| 6 25 N| 94 20 E
Great Inagua (island)_________|The Bahamas________________|21 00 N| 73 20 W
Great Rift Valley_____________|Ethiopia, Kenya____________| 0 30 N| 36 00 E
Greater Sunda Islands_________|Brunei, Indonesia, Malaysia| 2 00 S|110 00 E
Green Islands_________________|Papua New Guinea___________| 4 30 S|154 10 E
Greenland Sea_________________|Arctic Ocean_______________|79 00 N| 5 00 W
Grenadines, Northern (island |Saint Vincent and the |13 15 N| 61 12 W
group)________________________|Grenadines_________________|_______|________
Grenadines, Southern (island |Grenada |12 07 N| 61 40 W
group)________________________|___________________________|_______|________
Grytviken (South Georgia) |South Georgia and the South|54 15 S| 36 45 W
(town)________________________|Sandwich Islands___________|_______|________
Guadalcanal (island)__________|Solomon Islands____________| 9 32 S|160 12 E
Guadalupe, Isla de (island)___|Mexico_____________________|29 11 N|118 17 W
Guantanamo Bay (US Naval Base)|Cuba_______________________|20 00 N| 75 08 W
Guatemala (capital)___________|Guatemala__________________|14 38 N| 90 31 W
Guinea Ecuatorial (local name |Equatorial Guinea | 2 00 N| 10 00 E
for Equatorial Guinea)________|___________________________|_______|________
Guinea, Gulf of_______________|Atlantic Ocean_____________| 3 00 N| 2 30 E
Guine-Bissau (local name for |Guinea-Bissau |12 00 N| 15 00 W
Guinea-Bissau)________________|___________________________|_______|________
Guinee (local name for Guinea)|Guinea_____________________|11 00 N| 10 00 W
Guyane (Francaise) (local name|French Guiana | 4 00 N| 53 00 W
for French Guiana)____________|___________________________|_______|________
______','92fa8a85b262344e273b873e5fff1b6bed4bf4bad86b315ca42ec46ed921f7c0','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85125325cec51a5e3079fccc44f51b3dd040cb4b331289315b84cb12e27dc814',2002,'ZW','Zimbabwe','communications',244,'_____________________________________________________________________
Ha''apai Group (island group) |Tonga_______________________|19 42 S|174 29 W
Habomai Islands______________|Russia (de facto)___________|43 30 N|146 10 E
Hadhramaut (region)__________|Yemen_______________________|15 00 N| 50 00 E
Hagatna (Agana) (capital)____|Guam________________________|13 28 N|144 45 E
Hague, The (seat of |Netherlands |52 05 N| 4 18 E','c8266e9d9e462b1fba9b6871f94c99591f965c665aa25a90fb0ddfdaa07ade93','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8666d24a39fb91793cc60f13c4f13ee33e01d327f8a44730086590c53134876e',2002,'RW','Rwanda','communications',245,'UNAMSIL : United Nations Mission in Sierra Leone
UNAVEM III : United Nations Angola Verification
Mission III
UNCRO : United Nations Confidence Restoration
Operation in Croatia
UNCTAD : United Nations Conference on Trade and
Development
UNDOF : United Nations Disengagement Observer
Force
UNDP : United Nations Development Program
UNEP : United Nations Environment Program
UNESCO : United Nations Educational, Scientific,
and Cultural Organization
UNFICYP : United Nations Peace-keeping Force in','3bab77069c854a77b834c8f18c27533bd6bea3bc09d3d1e53e3ce7efa78fd09f','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d008c41efec90ab48ae43ad5a07d337d7c5e5104eb718c8adeecaa75dc5225c2',2002,'CY','Cyprus','communications',246,'UNHCR : United Nations High Commissioner for
Refugees
UNICEF : United Nations Children''s Fund
UNIDO : United Nations Industrial Development
Organization
UNIFIL : United Nations Interim Force in Lebanon
UNIKOM : United Nations Iraq-Kuwait Observation
Mission
UNITAR : United Nations Institute for Training
and Research
UNMIBH : United Nations Mission in Bosnia and
Herzegovina
UNMIK : United Nations Interim Administration
Mission in Kosovo
UNMOGIP : United Nations Military Observer Group
in India and Pakistan
UNMOP : United Nations Mission of Observers in
Prevlaka
UNMOT : United Nations Mission of Observers in','1abe5663d93e00906a84273ea659ab6d1f369b72447ea6ab7286a4c09a425e68','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2946c55d388b3417b39c5670733410f08c347a04da6140da89197171f677d88',2002,'TJ','Tajikistan','communications',247,'UNMOVIC : United Nations Monitoring and
Verification Commission
UNOMIG : United Nations Observer Mission in','befd442dae305e69fc0964c6345985d518b6d551aa63e8a7f42c3e62b448c2a1','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aea68e6917f832e4666a7108d007cb9ff976d49e9ef862469ac86ceadd55164',2002,'SL','Sierra Leone','communications',248,'UNRISD : United Nations Research Institute for
Social Development
UNRWA : United Nations Relief and Works Agency
for Palestine Refugees in the Near East
UNSMIH : United Nations Support Mission in Haiti
UNTAET : United Nations Transitional
Administration in East Timor
UNTSO : United Nations Truce Supervision
Organization
UNU : United Nations University
UPU : Universal Postal Union
US : United States
USSR : Union of Soviet Socialist Republics
(Soviet Union); used for information
dated before 25 December 1991
USSR/EE : Union of Soviet Socialist Republics/
Eastern Europe
VHF : very-high-frequency
VSAT : very small aperture terminal
WADB : West African Development Bank
WAEMU : West African Economic and Monetary Union
WCL : World Confederation of Labor
Wetlands : Convention on Wetlands of International
Importance Especially As Waterfowl
Habitat
WEU : Western European Union
WFC : World Food Council
WFP : World Food Program
WFTU : World Federation of Trade Unions
Whaling : International Convention for the
Regulation of Whaling
WHO : World Health Organization
WIPO : World Intellectual Property Organization
WMO : World Meteorological Organization
WP : Warsaw Pact
WTO : see WToO for World Tourism Organization
or WTrO for World Trade Organization
WToO : World Tourism Organization
WTrO : World Trade Organization
YAR : Yemen Arab Republic [Yemen (Sanaa) or
North Yemen]; used for information dated
before 22 May 1990 or CY91
ZC : Zangger Committee
===============================================================================
Appendix B - International Organizations and Groups
** advanced developing countries **
another term for those less developed countries (LDCs) with particularly
rapid industrial development; see newly industrializing economies (NIEs)
** advanced economies **
a term used by the International Monetary FUND (IMF) for the top group
in its hierarchy of advanced economies, countries in transition, and
developing countries; it includes the following 28 advanced economies:
Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany,
Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea,
Luxembourg, Netherlands, NZ, Norway, Portugal, Singapore, Spain, Sweden,
Switzerland, Taiwan, UK, US;
note - this group would presumably also cover the following seven smaller
countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein,
Monaco, and San Marino which are included in the more comprehensive
group of "developed countries"
** African, Caribbean, and Pacific Group of States **
(ACP Group)
established - 6 June 1975
aim - to manage their preferential economic and aid relationship with
the EU
members - (77) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cook Islands, Cote d''Ivoire, Djibouti,
Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia, Fiji,
Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti,
Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali,
Marshall Islands, Mauritania, Mauritius, Federated States of Micronesia,
Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau, Papua New
Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sudan, Suriname,
Swaziland, Tanzania, Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda,
Vanuatu, Zambia, Zimbabwe
** African Development Bank (AfDB) **
note - also known as Banque Africaine de Developpement (BAD)
established - 4 August 1963
aim - to promote economic and social development
regional members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia,
Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar,
Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo,
Tunisia, Uganda, Zambia, Zimbabwe
nonregional members - (24) Argentina, Austria, Belgium, Brazil, Canada,
China, Denmark, Finland, France, Germany, India, Italy, Japan, South
Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain,
Sweden, Switzerland, UK, US
** Agency for the French-Speaking Community (ACCT) **
note - formerly Agency for Cultural and Technical Cooperation
established - 20 March 1970; name changed 1996
aim - to promote cultural and technical cooperation among French-speaking
countries
members - (51) Albania, Belgium, Benin, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cote d''Ivoire, Djibouti, Dominica, Egypt, Equatorial Guinea, France,
French Community of Belgium, Gabon, Guinea, Guinea-Bissau, Haiti, Laos,
Lebanon, Luxembourg, Former Yugoslav Republic of Macedonia, Madagascar,
Mali, Mauritania, Mauritius, Moldova, Monaco, Morocco, New Brunswick
(Canada), Niger, Quebec (Canada), Romania, Rwanda, Saint Lucia, Sao
Tome and Principe, Senegal, Seychelles, Switzerland, Togo, Tunisia,
Vanuatu, Vietnam
observers - (4) Czech Republic, Lithuania, Poland, Slovenia
** Agency for the Prohibition of Nuclear Weapons **
in Latin America and the Caribbean (OPANAL) note - acronym from Organismo
para la Proscripcion de las Armas Nucleares en la America Latina y el
Caribe (OPANAL)
established - 14 February 1967 under the Treaty of Tlatelolco;
effective - 25 April 1969 on the 11th ratification of the treaty
aim - to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons
members - (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Dominica,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, Uruguay, Venezuela; note - Cuba signed
the treaty but did not ratify it
** Andean Community of Nations (CAN) **
note - formerly known as the Andean Group (AG), the Andean Parliament,
and most recently as the Andean Common Market (Ancom)
established - 26 May 1969; present name established 1
October 1992; effective - 16 October 1969
aim - to promote harmonious development through economic integration
members - (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
** Arab Bank for Economic Development in Africa **
(ABEDA) note - also known as Banque Arabe de Developpement Economique
en Afrique (BADEA)
established - 18 February 1974; effective - 16 September 1974
aim - to promote economic development
members - (17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine
Liberation Organization;
note - these are all the members of the Arab League excluding Comoros,
Djibouti, Somalia, Yemen
** Arab Cooperation Council (ACC) **
established - 16 February 1989
aim - to promote economic cooperation and integration, possibly leading
to an Arab Common Market
members - (4) Egypt, Iraq, Jordan, Yemen
** Arab Fund for Economic and Social Development **
(AFESD)
established - 16 May 1968
aim - to promote economic and social development
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia
(suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation
Organization
** Arab League (AL) **
note - also known as League of Arab States (LAS)
established - 22 March 1945
aim - to promote economic, social, political, and military cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria,
Tunisia, UAE, Yemen, Palestine Liberation Organization
** Arab Maghreb Union (AMU) **
established - 17 February 1989
aim - to promote cooperation and integration among the Arab states of
northern Africa
members - (5) Algeria, Libya, Mauritania, Morocco, Tunisia
** Arab Monetary Fund (AMF) **
established - 27 April 1976; effective - 2 February 1977
aim - to promote Arab cooperation, development, and integration in
monetary and economic affairs
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria,
Tunisia, UAE, Yemen, Palestine Liberation Organization
** Asia-Pacific Economic Cooperation (APEC) **
established - 7 November 1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific Economic
Cooperation Conference, Pacific Islands Forum
** Asian Development Bank (AsDB) **
established - 19 December 1966
aim - to promote regional economic cooperation
regional members - (43) Afghanistan, Australia, Azerbaijan, Bangladesh,
Bhutan, Burma, Cambodia, China, Cook Islands, Fiji, Hong Kong, India,
Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia,
Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan,
Thailand, Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members - (16) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Italy, Netherlands, Norway, Spain, Sweden, Switzerland,
Turkey, UK, US
** Association of Southeast Asian Nations (ASEAN) **
established - 8 August 1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
associate member - (1) Papua New Guinea
dialogue partners - (12) Australia, Canada, China, EU, India, Japan,
Pakistan, South Korea, NZ, Russia, US, UNDP
** ASEAN Regional Forum (ARF) **
established - NA 1994
aim - to foster constructive dialogue and consultation on political and
security issues of common interest and concern
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners - (13) Australia, Canada, China, EU, India, Japan,
North Korea, South Korea, Mongolia, NZ, Papua New Guinea, Russia, US
** Australia Group **
established - NA 1984
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (34) Argentina, Australia, Austria, Belgium, Bulgaria, Canada,
Cyprus, Czech Republic, Denmark, European Commission, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea,
Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia,
Spain, Sweden, Switzerland, Turkey, UK, US
** Australia-New Zealand-United States Security **
Treaty (ANZUS)
established - 1 September 1951; effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although the
US suspended security obligations to NZ on 11 August 1986; Australia
and the US continue to hold annual meetings
members - (3) Australia, NZ, US
** Bank for International Settlements (BIS) **
established - 20 January 1930; effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (50) Argentina, Australia, Austria, Belgium, Bosnia and
Herzegovina, Brazil, Bulgaria, Canada, China, Croatia, Czech Republic,
Denmark, Estonia, European Central Bank, Finland, France, Germany, Greece,
Hong Kong, Hungary, Iceland, India, Ireland, Italy, Japan, South Korea,
Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Malaysia,
Mexico, Netherlands, Norway, Poland, Portugal, Romania, Russia, Saudi
Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Thailand, Turkey, UK, US, Yugoslavia
** Benelux Economic Union (Benelux) **
note - acronym from Belgium, Netherlands, and Luxembourg
established - 3 February 1958; effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
** Big Seven **
note - membership is the same as the Group of 7
established - NA 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
** Big Six **
note - not to be confused with the Group of 6
established - NA 1967
aim - to foster economic cooperation
members - (6) Canada, France, Germany, Italy, Japan, UK
** Black Sea Economic Cooperation Zone (BSEC) **
established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Turkey, Ukraine
observers - (7) Austria, Egypt, Israel, Italy, Poland, Slovakia, Tunisia
** Caribbean Community and Common Market (Caricom) **
established - 4 July 1973; effective - 1 August 1973
aim - to promote economic integration and development, especially among
the less developed countries
members - (15) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad
and Tobago;
note - when Haiti has deposited an appropriate instrument of accession
with the Secretary General, it will become a full member of the Community
associate members - (3) Anguilla, British Virgin Islands, Turks and
Caicos Islands
observers - (10) Aruba, Bermuda, Cayman Islands, Colombia, Dominican
Republic, Mexico, Netherlands Antilles, Puerto Rico, Venezuela
** Caribbean Development Bank (CDB) **
established - 18 October 1969; effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago,
Turks and Caicos Islands, Venezuela
nonregional members - (5) Canada, China, Germany, Italy, UK
** Central African Customs and Economic Union (UDEAC) **
see Monetary and Economic Community of Central Africa (CEMAC)
** Central African States Development Bank (BDEAC) **
note - acronym from Banque de Developpement des Etats de l''Afrique
Centrale
established - 3 December 1975
aim - to provide loans for economic development
members - (11) African Development Bank (AfDB), Cameroon, Central African
States Bank (BEAC), Central African Republic, Chad, Republic of the Congo,
Equatorial Guinea, France, Gabon, Germany, Kuwait
** Central American Bank for Economic Integration **
(BCIE) note - acronym from Banco Centroamericano de Integracion Economico
established - 13 December 1960 signature of Articles of Agreement;
31 May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (4) Argentina, Colombia, Mexico, Taiwan
** Central American Common Market (CACM) **
established - 13 December 1960, collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional cooperation
** Central European Initiative (CEI) **
note - evolved from the Quadrilateral Initiative and the Hexagonal
Initiative
established - 11 November 1989 as the Quadrilateral Initiative, 27 July
1991 became the Hexagonal Initiative, NA July 1992 present name adopted
aim - to form an economic and political cooperation group for the region
between the Adriatic and the Baltic Seas
members - (17) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia,
Ukraine, Yugoslavia
** centrally planned economies **
a term applied mainly to the traditionally communist states that looked
to the former USSR for leadership; most are now evolving toward more
democratic and market-oriented systems; also known formerly as the
Second World or as the communist countries; through the 1980s, this group
included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia, GDR,
Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam,
Yugoslavia
** Colombo Plan (CP) **
established - NA May 1950 proposal was adopted; 1 July 1951 commenced
full operations
aim - to promote economic and social development in Asia and the Pacific
members - (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma,
Cambodia, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, US
provisional member - (1) Mongolia
** Commonwealth (C) **
note - also known as Commonwealth of Nations
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a voluntary
association that evolved from the British Empire
members - (54) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati,
Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique,
Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua New Guinea,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Seychelles, Sierra Leone, Singapore, Solomon Islands, South
Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad and Tobago,
Tuvalu, Uganda, UK, Vanuatu, Zambia, Zimbabwe (suspended)
** Commonwealth of Independent States (CIS) **
established - 8 December 1991; effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a mechanism
for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
** communist countries **
traditionally the Marxist-Leninist states with authoritarian governments
and command economies based on the Soviet model; most of the original
and the successor states are no longer communist; see centrally planned
economies
** Coordinating Committee on Export Controls (COCOM) **
established in 1949 to control the export of strategic products and
technical data from member countries to proscribed destinations; members
were Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy,
Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US;
abolished 31 March 1994; COCOM members established a new organization,
the Wassenaar Arrangement, with expanded membership on 12 July 1996
which focuses on nonproliferation export controls as opposed to East-West
control of advanced technology
** Council for Mutual Economic Assistance (CEMA) **
note - also known as CMEA or Comecon established 25 January 1949
to promote the development of socialist economies and abolished 1
January 1991; members included Afghanistan (observer), Albania (had not
participated since 1961 break with USSR), Angola (observer), Bulgaria,
Cuba, Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer),
Mongolia, Mozambique (observer), Nicaragua (observer), Poland, Romania,
USSR, Vietnam, Yemen (observer), Yugoslavia (associate)
** Council of Arab Economic Unity (CAEU) **
established - 3 June 1957; effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (11 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, UAE, Yemen,
Palestine Liberation Organization
** Council of Europe (CE) **
established - 5 May 1949; effective - 3 August 1949
aim - to promote increased unity and quality of life in Europe
members - (43) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malta, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK
guests - (2) Bosnia and Herzegovina, Yugoslavia
observers - (6) Canada, Holy See, Israel, Japan, Mexico, US
** Council of the Baltic Sea States (CBSS) **
established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas of
aid to new democratic institutions, economic development, humanitarian
aid, energy and the environment, cultural programs and education, and
transportation and communication
members - (12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
** Council of the Entente (Entente) **
established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
** countries in transition **
a term used by the International Monetary FUND (IMF) for the middle
group in its hierarchy of advanced economies, countries in transition,
and developing countries; recently published IMF statistics include the
following 28 countries in transition: Albania, Armenia, Azerbaijan,
Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic,
Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
The Former Yugoslav Republic of Macedonia, Moldova, Mongolia, Poland,
Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan, Yugoslavia; note - this group is identical to the group
traditionally referred to as the "former USSR/Eastern Europe" except
for the addition of Mongolia
** Customs Cooperation Council (CCC) **
note - also known as World Customs Organization (WCO)
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (157) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Benin, Bermuda, Bolivia, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Macau, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritiu','0536382461e91b3224d48c42791621cdab4e6001ba79200842782b8e892b41d1','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e92590fe82089e11782962f2d803375a26b5f4eda0e899018a9f3bce58933b8',2002,'SL','Sierra Leone','communications',249,'s, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Netherlands Antilles,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
** developed countries (DCs) **
the top group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries
(LDCs); includes the market-oriented economies of the mainly democratic
nations in the Organization for Economic Cooperation and Development
(OECD), Bermuda, Israel, South Africa, and the European ministates; also
known as the First World, high-income countries, the North, industrial
countries; generally have a per capita GDP in excess of $10,000 although
four OECD countries and South Africa have figures well under $10,000 and
two of the excluded OPEC countries have figures of more than $10,000;
the 35 DCs are: Andorra, Australia, Austria, Belgium, Bermuda, Canada,
Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy See,
Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg,
Malta, Mexico, Monaco, Netherlands, NZ, Norway, Portugal, San Marino,
South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note - similar
to the new International Monetary Fund (IMF) term "advanced economies"
which adds Hong Kong, South Korea, Singapore, and Taiwan but drops Malta,
Mexico, South Africa, and Turkey
** developing countries **
a term used by the International Monetary Fund (IMF) for the bottom
group in its hierarchy of advanced economies, countries in transition,
and developing countries; recently published IMF statistics include
the following 126 developing countries: Afghanistan, Algeria, Angola,
Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran,
Iraq, Jamaica, Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE,
Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe;
note - this category would presumably also cover the following 46 other
countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British
Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands,
Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French
Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guernsey, Jersey, North Korea, Macau, Isle of Man, Martinique, Mayotte,
Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana
Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena,
Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands,
Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
** East African Development Bank (EADB) **
established - 6 June 1967; effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
** Economic and Social Council (ECOSOC) **
established - 26 June 1945; effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes five
regional commissions (Economic Commission for Africa, Economic Commission
for Europe, Economic Commission for Latin America and the Caribbean,
Economic and Social Commission for Asia and the Pacific, Economic
and Social Commission for Western Asia) and 9 functional commissions
(Commission for Social Development, Commission on Human Rights, Commission
on Narcotic Drugs, Commission on the Status of Women, Commission on
Population and Development, Statistical Commission, Commission on Science
and Technology for Development, Commission on Sustainable Development,
and Commission on Crime Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
** Economic Community of the Great Lakes Countries **
(CEPGL) note - acronym from Communaute Economique des Pays des Grands Lacs
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda
** Economic Community of West African States (ECOWAS) **
established - 28 May 1975
aim - to promote regional economic cooperation
members - (15) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The Gambia,
Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger, Nigeria, Senegal,
Sierra Leone, Togo
** Economic Cooperation Organization (ECO) **
established - 27-29 January 1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
associate member - (1) "Turkish Republic of Northern Cyprus"
** Euro-Atlantic Partnership Council (EAPC) **
note - began as the North Atlantic Cooperation Council (NACC); an
extension of NATO
established - 8 November 1991; effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium,
Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
** European Bank for Reconstruction and Development **
(EBRD)
established - 8-9 January 1990 (proposals made); 15 April 1991 (bank
inaugurated)
aim - to facilitate the transition of seven centrally planned economies
in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market economies by committing 60%
of its loans to privatization
members - (61) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech
Republic, Denmark, Egypt, EU, European Investment Bank (EIB), Estonia,
Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland,
Israel, Italy, Japan, Kazakhstan, South Korea, Kyrgyzstan, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Mexico, Moldova, Mongolia, Morocco, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
Uzbekistan, Yugoslavia
** European Community (or European Communities, **
EC) was established 8 April 1965 to integrate the European Atomic Energy
Community (Euratom), the European Coal and Steel Community (ESC), the
European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe;
merged into the European Union (EU) on 7 February 1992; member states
at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
** European Free Trade Association (EFTA) **
established - 4 January 1960; effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
** European Investment Bank (EIB) **
established - 25 March 1957; effective - 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
** European Monetary Union (EMU) **
note - an integral part of the European Union; also known as the European
Economic and Monetary Union
proposed - 1-2 December 1969 at summit conference of heads
of government; signed - 7 February 1992 - Maastricht Treaty
aim - to promote a single market by creating a single
currency, the euro; time table - 2 May 1998: European exchange rates
fixed for 1 January 1999; 1 January 1999: all banks and stock exchanges
begin using euros; 1 January 2002: the euro goes into circulation;
1 July 2002 local currencies no longer accepted
members - (12) Austria, Belgium, Finland, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain; note - Denmark,
Sweden, and UK decided not to join
** European Organization for Nuclear Research (CERN) **
note - acronym retained from the predecessor organization Conseil
Europeenne pour la Recherche Nucleaire
established - 1 July 1953; effective - 29 September 1954
aim - to foster nuclear research for peaceful purposes only
members - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Italy, Netherlands, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers - (7) European Commission, Israel, Japan, Russia, Turkey, United
Nations Educational, Scientific, and Cultural Organization (UNESCO), US
** European Space Agency (ESA) **
established - 31 May 1975
aim - to promote peaceful cooperation in space research and technology
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Ireland, Italy, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland,
UK
cooperating state - (1) Canada
** European Union (EU) **
note - evolved from the European Community (EC)
established - 7 February 1992; effective - 1 November 1993
aim - to coordinate policy among the 15 members in three fields:
economics, building on the European Economic Community''s (EEC) efforts
to establish a common market and eventually a common currency to be
called the ''euro'', which superseded the EU''s accounting unit, the ECU;
defense, within the concept of a Common Foreign and Security Policy
(CFSP); and justice and home affairs, including immigration, drugs,
terrorism, and improved living and working conditions
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
membership applicants - (13) Bulgaria, Cyprus, Czech Republic, Estonia,
Hungary, Latvia, Lithuania, Malta, Poland, Romania, Slovakia, Slovenia,
Turkey
** First World **
another term for countries with advanced, industrialized economies;
this term is fading from use; see developed countries (DCs)
** Food and Agriculture Organization (FAO) **
established - 16 October 1945
aim - to raise living standards and increase availability of agricultural
products, as a UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, EC, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
** former Soviet Union (FSU) **
former term often used to identify as a group the successor nations to
the Soviet Union or USSR; this group of 15 countries consists of Armenia,
Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
** former USSR/Eastern Europe (former USSR/EE) **
the middle group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries
(LDCs); these countries are in political and economic transition and
may well be grouped differently in the near future; this group of 27
countries consists of Albania, Armenia, Azerbaijan, Belarus, Bosnia
and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia,
Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Russia, Slovakia,
Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia;
this group is identical to the IMF group "countries in transition"
except for the IMF''s inclusion of Mongolia
** Four Dragons **
the four small Asian less developed countries (LDCs) that have experienced
unusually rapid economic growth; also known as the Four Tigers; this
group consists of Hong Kong, South Korea, Singapore, Taiwan; these
countries are included in the IMF''s "advanced economies" group
** Franc Zone (FZ) **
note - also known as Conference des Ministres des Finances des Pays de
la Zone Franc
established - NA 1964
aim - to form a monetary union among countries whose currencies are
linked to the French franc
members - (16) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d''Ivoire, Equatorial Guinea,
France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo;
note - France includes metropolitan France, the four overseas departments
of France (French Guiana, Guadeloupe, Martinique, Reunion), the two
territorial collectivities of France (Mayotte, Saint Pierre and Miquelon),
and the three overseas territories of France (French Polynesia, New
Caledonia, Wallis and Futuna)
** Front Line States (FLS) **
established to achieve black majority rule in South Africa; has since
gone out of existence; members included Angola, Botswana, Mozambique,
Namibia, Tanzania, Zambia, Zimbabwe
** General Agreement on Tariffs and Trade (GATT) **
see the World Trade Organization (WTrO)
** Group of 2 (G-2) **
informal term that came into use about 1986; to facilitate bilateral
economic cooperation between the two most powerful economic giants;
members were Japan, US
** Group of 3 (G-3) **
established - NA September 1990
aim - mechanism for policy coordination
members - (3) Colombia, Mexico, Venezuela
** Group of 5 (G-5) **
established - 22 September 1985
aim - to coordinate the economic policies of five major noncommunist
economic powers
members - (5) France, Germany, Japan, UK, US
** Group of 6 (G-6) **
note - also known as Groupe des Six Sur le Desarmement; not to be confused
with the Big Six
established - 22 May 1984
aim - to achieve nuclear disarmament
members - (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
** Group of 7 (G-7) **
note - membership is the same as the Big Seven
established - 22 September 1985
aim - to facilitate economic cooperation among the seven major
noncommunist economic powers
members - (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada
and Italy
** Group of 8 (G-8) **
established - NA October 1975
aim - to facilitate economic cooperation among the developed countries
(DCs) that participated in the Conference on International Economic
Cooperation (CIEC), held in several sessions between NA December 1975
and 3 June 1977
members - (9) Canada, EU (as one member), France, Germany, Italy, Japan,
Russia, UK, US
** Group of 9 (G-9) **
established - NA
aim - to discuss matters of mutual interest on an informal basis
members - (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Sweden, Yugoslavia
** Group of 10 (G-10) **
note - also known as the Paris Club; includes the wealthiest members
of the IMF who provide most of the money to be loaned and act as the
informal steering committee; name persists in spite of the addition of
Switzerland on NA April 1984
established - NA October 1962
aim - to coordinate credit policy
members - (11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US nonstate participants - (4)
BIS, EU, IMF, OECD
** Group of 11 (G-11) **
note - also known as the Cartagena Group; established in 21-22 June 1984,
in Cartagena, Colombia; aim was to provide a forum for largest debtor
nations in Latin America; members were Argentina, Bolivia, Brazil, Chile,
Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay, Venezuela
** Group of 15 (G-15) **
note - byproduct of the Nonaligned Movement established - NA September
1989
aim - to promote economic cooperation among developing nations; to act
as the main political organ for the Nonaligned Movement
members - (16) Algeria, Argentina, Brazil, Chile, Egypt, India, Indonesia,
Jamaica, Kenya, Malaysia, Mexico, Peru, Senegal, Sri Lanka, Venezuela,','61b18185dc6a0118f1846b3ffa83a8ccf3d8c916ccfe61cf67c975226dc655e0','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23c76d2b145aaf67984bb9bc9757c375d0beacc6b6cc4b548bdc17b344c3015a',2002,'SC','Seychelles','communications',250,'** industrial countries **
another term for the developed countries; see developed countries (DCs)
** Inter-American Development Bank (IADB) **
note - also known as Banco Interamericano de Desarrollo (BID)
established - 8 April 1959; effective - 30 December 1959
aim - to promote economic and social development in Latin America
members - (46) Argentina, Austria, The Bahamas, Barbados, Belgium,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Croatia,
Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France,
Germany, Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica,
Japan, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru,
Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and
Tobago, UK, US, Uruguay, Venezuela
** Inter-Governmental Authority on Development (IGAD) **
note - formerly known as Inter-Governmental Authority on Drought and
Development (IGADD)
established - 15-16 January 1986 as the Inter-Governmental
Authority on Drought and Development; revitalized - 21 March 1996 as
the Inter-Governmental Authority on Development
aim - to promote a social, economic, and scientific community among
its members
members - (7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan, Uganda
** International Atomic Energy Agency (IAEA) **
established - 26 October 1956; effective - 29 July 1957
aim - to promote peaceful uses of atomic energy
members - (133) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium,
Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso,
Burma, Cambodia, Cameroon, Canada, Central African Republic, Chile,
China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finland,
France, Gabon, Georgia, Germany, Ghana, Greece, Guatemala, Haiti, Holy
See, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait,
Latvia, Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malaysia, Mali,
Malta, Marshall Islands, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe;
note - Honduras membership has been approved; membership will take effect
once legal instruments have been deposited
** International Bank for Reconstruction and Development **
(IBRD) note - also known as the World Bank
established - 22 July 1944; effective - 27 December 1945
aim - to provide economic development loans; a UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** International Chamber of Commerce (ICC) **
established - NA 1919
aim - to promote free trade and private enterprise and to represent
business interests at national and international levels
members - (80 national committees) Algeria, Argentina, Australia, Austria,
Bahrain, Bangladesh, Belgium, Brazil, Burkina Faso, Cameroon, Canada,
Caribbean, Chile, China, Colombia, Cuba, Cyprus, Czech Republic, Denmark,
Ecuador, Egypt, Finland, France, Germany, Ghana, Greece, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan,
Jordan, South Korea, Kuwait, Lebanon, Lithuania, Luxembourg, Mexico,
Monaco, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia,
Senegal, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia,
Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
** International Civil Aviation Organization (ICAO) **
established - 7 December 1944; effective - 4 April 1947
aim - to promote international cooperation in civil aviation; a UN
specialized agency
members - (187) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Palau, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** International Committee of the Red Cross (ICRC) **
established - 17 February 1863
aim - to provide humanitarian aid in wartime
members - (25 individuals) all Swiss nationals
** International Confederation of Free Trade Unions (ICFTU) **
established - NA December 1949
aim - to promote the trade union movement
members - (225 affiliated organizations in the following 148 countries)
Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria,
Azerbaijan, The Bahamas, Bangladesh, Barbados, Belgium, Belize, Benin,
Bermuda, Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, El Salvador, Eritrea,
Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Holy See, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, South Korea, Latvia, Lebanon, Liberia, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Montserrat, Morocco, Mozambique,
Namibia, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Romania, Russia, Rwanda, Saint Helena,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland,
Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UK, US, Vanuatu, Venezuela, Yemen, Yugoslavia, Zambia,','df9a0d83a92b15193576bdc15827fef409cce9958946484cc963297c28982fa5','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('398f8a10f8c1d1c05d069ac7d8f33d80a83db9df360b0f89f971e15b7119f393',2002,'LK','Sri Lanka','communications',251,'** South Pacific Forum (SPF) **
note - see Pacific Island Forum
** South Pacific Regional Trade and Economic Cooperation Agreement **
(Sparteca)
established - NA 1981
aim - to redress unequal trade relationships of Australia and New Zealand
with small island economies in the Pacific region
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua New Guinea,
Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
** Southern African Customs Union (SACU) **
established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
** Southern African Development Community (SADC) **
note - evolved from the Southern African Development Coordination
Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (14) Angola, Botswana, Democratic Republic of the Congo,
Lesotho, Malawi, Mauritius, Mozambique, Namibia, Seychelles, South Africa,
Swaziland, Tanzania, Zambia, Zimbabwe
** Southern Cone Common Market (Mercosur) or Southern Common Market **
note - also known as Mercado Comun del Cono Sur (Mercosur)
established - 26 March 1991
aim - to increase regional economic cooperation
members - (4) Argentina, Brazil, Paraguay, Uruguay
associate member - (2) Bolivia, Chile
** Third World **
another term for the less developed countries; the term is obsolescent;
see less developed countries (LDCs)
** underdeveloped countries **
refers to those less developed countries with the potential for
above-average economic growth; see less developed countries (LDCs)
** undeveloped countries **
refers to those extremely poor less developed countries (LDCs) with
little prospect for economic growth; see least developed countries (LLDCs)
** United Nations (UN) **
established - 26 June 1945;
effective - 24 October 1945
aim - to maintain international peace and security and to promote
cooperation involving economic, social, cultural, and humanitarian
problems
constituent organizations - the UN is composed of six principal organs
and numerous subordinate agencies and bodies as follows: 1) Secretariat
2) General Assembly: International Research and Training Institute
for the Advancement of Women (INSTRAW), United Nations Center for
Human Settlements (Habitat), United Nations Children''s Fund (UNICEF),
United Nations Conference on Trade and Development (UNCTAD), United
Nations Development Program (UNDP), United Nations Drug Control Program
(UNDCP), United Nations Environment Program (UNEP), United Nations High
Commissioner for Human Rights (UNHCHR), United Nations High Commissioner
for Refugees (UNHCR), United Nations Institute for Disarmament Research
(UNIDIR), United Nations Institute for Training and Research (UNITAR),
United Nations Interregional Crime and Justice Research Institute
(UNICRI), United Nations Population Fund (UNFPA), United Nations Office
of Project Services (UNOPS), United Nations Relief and Works Agency for
Palestine Refugees in the Near East (UNRWA), United Nations Research
Institute for Social Development (UNRISD), United Nations System Staff
College (UNSSC), and United Nations University (UNU), World Food Program
(WFP) 3) Security Council: International Criminal Tribunal for the Former
Yugoslavia (ICTY), International Criminal Tribunal for Rwanda (ICTR),
United Nations Compensation Commission, United Nations Disengagement
Observer Force (UNDOF), United Nations Interim Administration Mission
in Kosovo (UNMIK), United Nations Interim Force in Lebanon (UNIFIL),
United Nations Iraq/Kuwait Boundary Demarcation Commission, United Nations
Iraq-Kuwait Observation Mission (UNIKOM), United Nations Military Observer
Group in India and Pakistan (UNMOGIP), United Nations Mission for the
Referendum in Western Sahara (MINURSO), United Nations Mission in Bosnia
and Herzegovina (UNMIBH), United Nations Mission in Ethiopia and Eritrea
(UNMEE), United Nations Mission in Sierra Leone (UNAMSIL), United Nations
Mission of Observers in Prevlaka (UNMOP), United Nations Monitoring and
Verification Commission (UNMOVIC), United Nations Observer Mission in
Georgia (UNOMIG), United Nations Organization Mission in the Democratic
Republic of the Congo (MONUC), United Nations Peace-Keeping Force in
Cyprus (UNFICYP), United Nations Transitional Administration in East Timor
(UNTAET), and United Nations Truce Supervision Organization (UNTSO) 4)
Economic and Social Council (ECOSOC): Commission for Social Development,
Commission on Crime Prevention and Criminal Justice, Commission on
Human Rights, Commission on Narcotics Drugs, Commission on Population
and Development, Commission on Science and Technology for Development,
Commission on Sustainable Development, Commission on the Status of Women,
Economic and Social Commission for Asia and the Pacific (ESCAP), Economic
and Social Commission for Western Asia (ESCWA), Economic Commission for
Africa (ECA), Economic Commission for Europe (ECE), Economic Commission
for Latin America and the Caribbean (ECLAC), Food and Agriculture
Organization of the United Nations (FAO), International Atomic Energy
Agency (IAEA), International Bank for Reconstruction and Development
(IBRD), International Center for Secretariat of Investment Disputes
(ICSID), International Civil Aviation Organization (ICAO), International
Development Association (IDA), International Finance Corporation (IFC),
International Fund for Agricultural Development (IFAD), International
Labor Organization (ILO), International Maritime Organization (IMO),
International Monetary Fund (IMF), International Telecommunication Union
(ITU), Multilateral Investment Geographic Agency (MGIA), Statistical
Commission, United Nations Educational, Scientific, and Cultural
Organization (UNESCO), United Nations Industrial Development Organization
(UNIDO), Universal Postal Union (UPU), World Health Organization (WHO),
World Intellectual Property Organization (WIPO), World Meteorological
Organization (WMO), World Tourism Organization (WToO), and World Trade
Organization (WTrO) 5) Trusteeship Council (inactive; no trusteeships at
this time) 6) International Court of Justice (ICJ) UN members - (189)
Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe; note -
all UN members are represented in the General Assembly; East Timor and
Switzerland are scheduled to become UN members in September 2002
observers - (2 plus the Palestine Liberation Organization) Holy See,
Switzerland, Palestine Liberation Organization
** United Nations Children''s Fund (UNICEF) **
note - acronym retained from the predecessor organization, UN
International Children''s Emergency Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (36) selected on a rotating basis from all regions
** United Nations Civilian Police Mission in Haiti (MIPONUH) **
established 28 November 1997; to support the professionalization of the
Haitian National Police; established by UN Security Council; members
were Argentina, Benin, Canada, France, India, Mali, Niger, Senegal,
Togo, Tunisia, US; mission ended March 2000
** United Nations Conference on Trade and Development (UNCTAD) **
established - 30 December 1964
aim - to promote international trade
members - (191) all UN members plus Holy See, Switzerland
** United Nations Development Program (UNDP) **
established - 22 November 1965
aim - to provide technical assistance to stimulate economic and social
development
members (executive board) - (36) selected on a rotating basis from
all regions
** United Nations Disengagement Observer Force (UNDOF) **
established - 31 May 1974
aim - to observe the 1973 Arab-Israeli cease-fire; established by the
UN Security Council
members - (6) Austria, Canada, Japan, Poland, Slovakia, Sweden
** United Nations Educational, Scientific, and Cultural Organization **
(UNESCO)
established - 16 November
1945; effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (188) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
associate members - (6) Aruba, British Virgin Islands, Cayman Islands,
Macau, Netherlands Antilles, Tokelau
** United Nations Environment Program (UNEP) **
established - 15 December 1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
** United Nations General Assembly **
established - 26 June 1945;
effective - 24 October 1945
aim - to function as the primary deliberative organ of the UN
members - (189) all UN members are represented in the General Assembly
** United Nations High Commissioner for Refugees (UNHCR) **
established - 3 December
1949; effective - 1 January 1951
aim - to ensure the humanitarian treatment of refugees and find permanent
solutions to refugee problems members (executive committee) - (57)
Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Cote
d''Ivoire, Denmark, Ethiopia, Finland, France, Germany, Greece, Holy See,
Hungary, India, Iran, Ireland, Israel, Italy, Japan, South Korea, Lebanon,
Lesotho, Madagascar, Mexico, Morocco, Mozambique, Namibia, Netherlands,
Nicaragua, Nigeria, Norway, Pakistan, Philippines, Poland, Russia,
Somalia, South Africa, Spain, Sudan, Sweden, Switzerland, Tanzania,
Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela
** United Nations Industrial Development Organization (UNIDO) **
established - 17 November
1966; effective - 1 January 1967
aim - UN specialized agency that promotes industrial development
especially among the members
members - (169) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE,
UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia,
Zambia, Zimbabwe
** United Nations Institute for Training and Research (UNITAR) **
established - 11 December 1963 adoption of the resolution establishing
the Institute; effective - 24 March 1965
aim - to help the UN become more effective through training and research
members (Board of Trustees) - (20) Austria, Brazil, Cameroon, Chile,
China, Egypt, France, Ghana, Ireland, Japan, Kuwait, Mexico, Netherlands,
Nigeria, Russia, South Africa, Sweden, Switzerland, Thailand, US;
note - the UN Secretary General can appoint up to 30 members
** United Nations Interim Administration Mission in Kosovo (UNMIK) **
established - 10 June 1999
aim - to promote the establishment of substantial autonomy and
self-government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and
humanitarian and disaster relief
members - (53) Argentina, Austria, Bangladesh, Belgium, Benin, Bulgaria,
Cameroon, Canada, Czech Republic, Denmark, Dominican Republic, Egypt,
Estonia, Fiji, Finland, France, The Gambia, Germany, Ghana, Greece,
Hungary, Iceland, India, Ireland, Italy, Jordan, Kenya, Kyrgyzstan,
Lithuania, Malawi, Malaysia, Nepal, Niger, Nigeria, Norway, Pakistan,
Philippines, Poland, Portugal, Romania, Russia, Senegal, Slovenia, Spain,
Sweden, Switzerland, Tunisia, Turkey, Ukraine UK, US, Zambia, Zimbabwe
** United Nations Interim Force in Lebanon (UNIFIL) **
established - 19 March 1978
aim - to confirm the withdrawal of Israeli forces, and assist in
reestablishing Lebanese authority in southern Lebanon; established by
the UN Security Council
members - (10) Fiji, Finland, France, Ghana, India, Ireland, Italy,
Nepal, Poland, Ukraine
** United Nations Iraq-Kuwait Observation Mission (UNIKOM) **
established - 9 April 1991
aim - to observe and monitor the demilitarized zone established between
Iraq and Kuwait; established by the UN Security Council
members - (33) Argentina, Austria, Bangladesh, China, Denmark, Fiji,
Finland, France, Germany, Ghana, Greece, Hungary, India, Indonesia,
Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania,
Russia, Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay,
Venezuela
** United Nations Military Observer Group in India and Pakistan **
(UNMOGIP)
established - 24 January 1949
aim - to observe the 1949 India-Pakistan cease-fire; established by the
UN Security Council
members - (9) Austria, Belgium, Chile, Denmark, Finland, Italy, South
Korea, Sweden, Uruguay
** United Nations Mission for the Referendum in Western Sahara (MINURSO)
**
established - 29 April 1991
aim - to supervise the cease-fire and conduct a referendum in Western
Sahara; established by the UN Security Council
members - (25) Argentina, Austria, Bangladesh, Belgium, China, Egypt,
El Salvador, France, Ghana, Greece, Guinea, Honduras, Hungary, Ireland,
Italy, Kenya, South Korea, Malaysia, Nigeria, Pakistan, Poland, Portugal,
Russia, US, Uruguay
** United Nations Mission in Bosnia and Herzegovina (UNMIBH) **
established - 21 December 1995
aim - to establish an International Police Task Force (IPTF) to implement
the Dayton Peace Agreement in Bosnia and Herzegovina
members - (44) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile,
China, Czech Republic, Denmark, Egypt, Estonia, Fiji, Finland, France,
Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland,
Italy, Jordan, Kenya, Malaysia, Nepal, Netherlands, Norway, Pakistan,
Poland, Portugal, Romania, Russia, Senegal, Spain, Sweden, Switzerland,
Thailand, Turkey, Ukraine, UK, US, Vanuatu
** United Nations Mission in Ethiopia and Eritrea (UNMEE) **
established - 31 July 2000
aim - to monitor the cessation of hostilities
members - (45) Algeria, Australia, Austria, Bangladesh, Benin, Bosnia and
Herzegovina, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark,
Finland, France, The Gambia, Ghana, Greece, India, Ireland, Italy, Jordan,
Kenya, Malaysia, Namibia, Nepal, Netherlands, Nigeria, Norway, Paraguay,
Peru, Poland, Romania, Russia, Singapore, Slovakia, South Africa, Spain,
Sweden, Switzerland, Tanzania, Tunisia, Ukraine, US, Uruguay, Zambia
** United Nations Mission in Sierra Leone (UNAMSIL) **
established - 22 October 1999 aim - to cooperate with the Government
of Sierra Leone and the other parties to the Peace Agreement in the
implementation of the agreement; to monitor the military and security
situation in Sierra Leone; to monitor the disarmament and demobilization
of combatants and members of the Civil Defense Forces (CFD); to assist
in monitoring respect for international humanitarian law
members - (32) Bangladesh, Bolivia, Canada, China, Croatia, Czech
Republic, Denmark, Egypt, France, The Gambia, Ghana, Guinea, Indonesia,
Jordan, Kenya, Kyrgyzstan, Malaysia, Mali, Nepal, NZ, Nigeria, Norway,
Pakistan, Paraguay, Russia, Slovakia, Sweden, Tanzania, Thailand, Ukraine,
UK, Uruguay, Zambia
** United Nations Mission of Observers in Prevlaka (UNMOP) **
established - 1 February 1996
aim - to monitor the demilitarization of the Prevlaka peninsula in
southern Croatia
members - (24) Argentina, Bangladesh, Belgium, Brazil, Czech Republic,
Denmark, Egypt, Finland, Ghana, Indonesia, Ireland, Jordan, Kenya,
Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Sweden,
Switzerland, Ukraine
** United Nations Mission of Observers in Tajikistan (UNMOT) **
established 16 December 1994; to monitor and investigate violations
of the cease-fire of 17 September 1994 between Tajikistan and the Tajik
opposition and to assist in the political negotiation process; established
by the UN Security Council; members were Austria, Bangladesh, Bulgaria,
Czech Republic, Denmark, Ghana, Indonesia, Jordan, Nepal, Nigeria,
Poland, Ukraine, Uruguay; mission ended May 2000
** United Nations Monitoring and Verification Commission (UNMOVIC) **
note - formerly known as United Nations Special Commission for the
Elimination of Iraq''s Weapons of Mass Destruction (UNSCOM)
established - NA December 1999
aim - to identify, account for, and eliminate Iraq''s weapons of mass
destruction and the capacity to produce them
commissioners - (15) Argentina, Brazil, Canada, China, Finland, France,
Germany, India, Japan, Nigeria, Russia, Senegal, Ukraine, UK, US
** United Nations Observer Mission in Georgia (UNOMIG) **
established - 24 August 1993
aim - to verify compliance with the cease-fire agreement, to monitor
weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members - (22) Albania, Austria, Bangladesh, Czech Republic, Denmark,
Egypt, France, Germany, Greece, Hungary, Indonesia, Jordan, South Korea,
Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US, Uruguay
** United Nations Organization Mission in the Democratic Republic **
of the Congo (MONUC)
established - 30 November 1999
aim - to establish contacts with the signatories to the cease-fire
agreement and to plan for the observation of the cease-fire and
disengagement of forces
members - (42) Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina
Faso, Cameroon, Canada, China, Czech Republic, Denmark, Egypt, France,
Ghana, India, Indonesia, Ireland, Italy, Jordan, Kenya, Malawi, Malaysia,
Morocco, Mozambique, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru,
Poland, Romania, Russia, Senegal, South Africa, Sweden, Switzerland,
Tunisia, Ukraine, UK, Uruguay, Zambia
** United Nations Peace-keeping Force in Cyprus (UNFICYP) **
established - 4 March 1964
aim - to serve as a peacekeeping force between Greek Cypriots and Turkish
Cypriots in Cyprus; established by the UN Security Council
members - (9) Argentina, Austria, Canada, Finland, Hungary, Ireland,
Nepal, Slovakia, UK
** United Nations Population Fund (UNFPA) **
note - acronym retained from predecessor organization UN Fund for
Population Activities
established - NA July 1967
aim - to assist both developed and developing countries to deal with
their population problems members (executive board
) - (36) selected on a rotating basis from all regions
** United Nations Preventive Deployment Force (UNPREDEP) **
established 31 March 1995; to monitor border activity in the Former
Yugoslav Republic of Macedonia; members were Argentina, Bangladesh,
Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, Ghana,
Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan,
Poland, Portugal, Russia, Sweden, Switzerland, Turkey, Ukraine, US;
mandate ended 25 March 1999
** United Nations Relief and Works Agency for Palestine Refugees **
in the Near East (UNRWA)
established - 8 December 1949
aim - to provide a','6df352d7d6315406e79982a4a93294e0cf976d0e8fd6014c257a65c89e5bd5c8','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1771797ec6e1c5bf8492769aa9ef9353d15609ce1c62555e18fe3c10b3c6ad25',2002,'LK','Sri Lanka','communications',252,'ssistance to Palestinian refugees members (advisory
commission) - (10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria,
Turkey, UK, US
** United Nations Research Institute for Social Development (UNRISD) **
established - NA 1963
aim - to conduct research into the problems of economic development
during different phases of economic growth
members - no country members, but a Board of Directors consisting of a
chairman appointed by the UN secretary general and 11 individual members
** United Nations Secretariat **
established - 26 June 1945;
effective - 24 October 1945
aim - to serve as the primary administrative organ of the UN; a Secretary
General is appointed for a five-year term by the General Assembly on
the recommendation of the Security Council
members - the UN Secretary General and staff
** United Nations Security Council **
established - 26 June 1945;
effective - 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN General
Assembly; Bulgaria (2002-03), Cameroon (2002-03), Colombia (2001-02),
Guinea (2002-03), Ireland (2001-02), Mauritius (2001-02), Mexico
(2002-03), Norway (2001-02), Singapore (2001-02), Syria (2002-03)
** United Nations Transitional Administration in East Timor (UNTAET) **
established - 25 October 1999
aim - to provide security throughout the territory of East Timor;
to establish an effective administration; to ensure the coordination
and delivery of humanitarian assistance; to support capacity-building
for self-government
members - (28) Australia, Bangladesh, Bolivia, Brazil, Chile, Denmark,
Egypt, Fiji, Ireland, Jordan, South Korea, Malaysia, Mozambique, Nepal,
NZ, Norway, Pakistan, Philippines, Portugal, Russia, Singapore, Slovakia,
Sweden, Thailand, Turkey, UK, US, Uruguay
** United Nations Truce Supervision Organization (UNTSO) **
established - NA June 1948
aim - to supervise the 1948 Arab-Israeli cease-fire; currently supports
timely deployment of reinforcements to other peacekeeping operations in
the region as needed; initially established by the UN Security Council
members - (22) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Estonia, Finland, France, Ireland, Italy, Netherlands,
NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
** United Nations Trusteeship Council **
established on 26 June 1945, effective on 24 October 1945, to supervise
the administration of the 11 UN trust territories; members were China,
France, Russia, UK, US; it formally suspended operations 1 November
1995 after the Trust Territory of the Pacific Islands (Palau) became the
Republic of Palau, a constitutional government in free association with
the US; the Trusteeship Council was not dissolved
** United Nations University (UNU) **
established - 3 December 1973
aim - to conduct research in development, welfare, and human survival
and to train scholars
members - (24 members of UNU Council and the Rector are appointed by
the Secretary General of the United Nations and the Director General
of UNESCO)
** Universal Postal Union (UPU) **
established - 9 October
1874, affiliated with the UN 15 November 1947; effective - 1 July 1948
aim - to promote international postal cooperation; a UN specialized agency
members - (189) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Overseas Territories of the UK, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** Warsaw Pact (WP) **
established 14 May 1955 to promote mutual defense; members met 1 July
1991 to dissolve the alliance; member states at the time of dissolution
were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR;
earlier members included GDR and Albania
** West African Development Bank (WADB) **
note - also known as Banque Ouest-Africaine de Developpement (BOAD);
is a financial institution of WAEMU
established - 14 November 1973
aim - to promote regional economic development and integration
regional members - (9) Central Bank of West African States, Benin,
Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional
members - (5) African Development Bank, Belgium, European Investment Bank,
France, Germany
** West African Economic and Monetary Union (WAEMU) **
note - also known as Union Economique et Monetaire Ouest Africaine (UEMOA)
established - 1 August 1994
aim - to increase competitiveness of members'' economic markets; to create
a common market
members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
** Western European Union (WEU) **
established - 23 October
1954; effective - 6 May 1955
aim - to provide mutual defense and to move toward political unification
members - (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
associate members - (6) Czech Republic, Hungary, Iceland, Norway,
Poland, Turkey
associate partners - (7) Bulgaria, Estonia, Latvia, Lithuania, Romania,
Slovakia, Slovenia
observers - (5) Austria, Denmark, Finland, Ireland, Sweden
** World Bank Group **
includes International Bank for Reconstruction and Development (IBRD),
International Development Association (IDA), and International Finance
Corporation (IFC)
** World Confederation of Labor (WCL) **
established - 19 June 1920 as the International Federation of Christian
Trade Unions (IFCTU), renamed 4 October 1968
aim - to promote the trade union movement
members - (101 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire
Island, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Central African
Republic, Chad, Chile, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech
Republic, Dominica, Dominican Republic, Ecuador, El Salvador, France,
French Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran,
Italy, Japan, Kazakhstan, South Korea, Liberia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malaysia, Malta, Martinique, Mauritania, Mauritius, Mexico, Montserrat,
Morocco, Namibia, Netherlands, Netherlands Antilles, Nicaragua, Niger,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the Grenadines,
Sao Tome and Principe, Senegal, Sierra Leone, Singapore, Slovakia, South
Africa, Spain, Sri Lanka, Suriname, Switzerland, Taiwan, Thailand, Togo,
Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam, Windward
Islands, Zimbabwe
** World Federation of Trade Unions (WFTU) **
established - 3 October 1945
aim - to promote the trade union movement
members - (125 and the Palestine Liberation Organization) Afghanistan,
Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji,
Finland, France, French Guiana, The Gambia, Ghana, Greece, Guadeloupe,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India,
Indonesia, Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea,
Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique,
Nepal, New Caledonia, NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua
New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico, Reunion,
Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent
and the Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia,
Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
** World Food Program (WFP) **
established - 24 November 1961
aim - to provide food aid in support of economic development or disaster
relief; an ECOSOC organization
members - (36) selected on a rotating basis from all regions
** World Health Organization (WHO) **
established - 22 July 1946;
effective - 7 April 1948
aim - to deal with health matters worldwide; a UN specialized agency
members - (191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members - (2) Puerto Rico, Tokelau
observers - (2) Holy See, Liechtenstein
** World Intellectual Property Organization (WIPO) **
established - 14 July 1967;
effective - 26 April 1970
aim - to furnish protection for literary, artistic, and scientific works;
a UN specialized agency
members - (178) Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
** World Meteorological Organization (WMO) **
established - 11 October
1947; effective - 4 April 1951
aim - to sponsor meteorological cooperation; a UN specialized agency
members - (185) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, British Caribbean Territories,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
French Polynesia, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Lithuania, Luxembourg, Macau, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, Netherlands
Antilles, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
** World Tourism Organization (WToO) **
established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (138) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina,
Armenia, Austria, Azerbaijan, Bahrain, Bangladesh, Benin, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Ethiopia, Fiji, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras,
Hungary, India, Indonesia, Iran, Iraq, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos,
Lebanon, Lesotho, Libya, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, Nicaragua, Niger, Nigeria, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, San Marino, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Switzerland, Syria, Tanzania, Thailand, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
associate members - (6) Aruba, Flanders, Hong Kong, Macau, Madeira
Islands, Netherlands Antilles
observers - (2) Holy See, Palestine Liberation Organization
** World Trade Organization (WTrO) **
note - succeeded General Agreement on Tariff and Trade (GATT)
established - 15 April 1994;
effective - 1 January 1995
aim - to provide a means to resolve trade conflicts between members
and to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members - (144) Albania, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, EU,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lesotho, Liechtenstein, Lithuania, Luxembourg, Macau, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland,
Taiwan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Uganda, UAE, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
observers - (31) Algeria, Andorra, Armenia, Azerbaijan, The Bahamas,
Belarus, Bhutan, Bosnia and Herzegovina, Cambodia, Cape Verde, Ethiopia,
The Former Yugoslav Republic of Macedonia, Holy See, Kazakhstan, Laos,
Lebanon, Nepal, Russia, Samoa, Sao Tome and Principe, Saudi Arabia,
Seychelles, Sudan, Tajikistan, Tonga, Ukraine, Uzbekistan, Vanuatu,
Vietnam, Yemen, Yugoslavia;
note - must start accession negotiations within five years of becoming
observers
** Zangger Committee (ZC) **
established - early 1970s
aim - to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members - (35) Argentina, Australia, Austria, Belgium, Bulgaria, Canada,
China, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
===============================================================================
Appendix C - Selected International Environmental Agreements
*Air Pollution:
see Convention on Long-Range Transboundary Air Pollution
*Air Pollution-Nitrogen Oxides:
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Nitrogen Oxides or Their Transboundary
Fluxes
*Air Pollution-Persistent Organic Pollutants:
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
on Persistent Organic Pollutants
*Air Pollution-Sulphur 85:
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
on the Reduction of Sulphur Emissions or Their Transboundary Fluxes by
at least 30%
*Air Pollution-Sulphur 94:
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
on Further Reduction of Sulphur Emissions
*Air Pollution-Volatile Organic Compounds:
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
*Antarctic-Environmental Protocol:
see Protocol on Environmental Protection to the Antarctic Treaty
*Antarctic Treaty:
opened for signature - 1 December 1959
entered into force - 23 June 1961
objective - to ensure that Antarctica is used for peaceful purposes
only (such as international cooperation in scientific research); to defer
the question of territorial claims asserted by some nations and not recognized
by others; to provide an international forum for management of the region;
applies to land and ice shelves south of 60 degrees South latitude
parties - (44) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic, Denmark,
Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary, India,
Italy, Japan, North Korea, South Korea, Netherlands, NZ, Norway, Papua
New Guinea, Peru, Poland, Romania, Russia, Slovakia, South Africa, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay, Venezuela
*Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal:
note - abbreviated as Hazardous Wastes
opened for signature - 22 March 1989
entered into force - 5 May 1992
objective - to reduce transboundary movements of wastes subject
to the Convention to a minimum consistent with the environmentally sound
and efficient management of such wastes; to minimize the amount and toxicity
of wastes generated and ensure their environ','38cc067c17c6e9e72976fcf91d7abb8ce9565ede3894633b2a38344fce9579b8','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('131ac312380c30e07ce0c25353ec42aba668ff4d968bd40b6fff6bc778df5cda',2002,'LK','Sri Lanka','communications',253,'mentally sound management
as closely as possible to the source of generation; and to assist LDCs
in environmentally sound management of the hazardous and other wastes
they generate
parties - (143) Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil,
Bulgaria, Burkina Faso, Burundi, Cameroon, Canada, Cape Verde, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Costa Rica,
Cote d`Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU,
Finland, France, The Gambia, Georgia, Germany, Greece, Guatemala, Guinea,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE,
UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia
countries that have signed, but not yet ratified - (3) Afghanistan,
Haiti, US
*Biodiversity:
see Convention on Biological Diversity
*Convention for the Conservation of Antarctic Seals:
note - abbreviated as Antarctic Seals
opened for signature - NA
entered into force - NA
objective - NA
parties - (16) Argentina, Australia, Belgium, Brazil, Canada,
Chile, France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
UK, US
countries that have signed, but not yet ratified - (1) NZ
*Convention on Biological Diversity:
note - abbreviated as Biodiversity
opened for signature - 5 June 1992
entered into force - 29 December 1993
objective - to develop national strategies for the conservation
and sustainable use of biological diversity
parties - (180) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d`Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE,
UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (7) Afghanistan,
Kuwait, Libya, Thailand, Tuvalu, US, Yugoslavia
*Climate Change:
see United Nations Framework Convention on Climate Change
*Climate Change-Kyoto Protocol:
see Kyoto Protocol to the United Nations Framework Convention on Climate
Change
*Convention on Fishing and Conservation of Living Resources of the High Seas:
note - abbreviated as Marine Life Conservation
opened for signature - 29 April 1958
entered into force - 20 March 1966
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas, considering
that because of the development of modern technology some of these resources
are in danger of being overexploited
parties - (38) Australia, Belgium, Bosnia and Herzegovina, Burkina
Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji, Finland,
France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra Leone,
Solomon Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad
and Tobago, Uganda, UK, US, Uruguay, Venezuela, Yugoslavia
countries that have signed, but not yet ratified - (21) Afghanistan,
Argentina, Bolivia, Canada, China, Costa Rica, Cuba, Ghana, Iceland, Indonesia,
Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama,
Sri Lanka, Tunisia
*Convention on Long-Range Transboundary Air Pollution:
note - abbreviated as Air Pollution
opened for signature - 13 November 1979
entered into force - 16 March 1983
objective - to protect the human environment against air pollution
and to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties - (48) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark,
Estonia, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova,
Monaco, Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Yugoslavia
countries that have signed, but not yet ratified - (2) Holy See,','4bb5be49b667d511f797fe26ba4414a7d3ef856c2e2506cb2b163671912f38f1','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98a508ecd03a19bfd103f7a0659fb6d6dac6c17767141525d26bf00318ebd4ca',2002,'SM','San Marino','communications',254,'*Convention on the Conservation of Antarctic Marine Living Resources:
note - abbreviated as Antarctic-Marine Living Resources
opened for signature - NA
entered into force - NA
objective - NA
parties - (30) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada,
Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan, South
Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa,
Spain, Sweden, Ukraine, UK, US, Uruguay
*Convention on the International Trade in Endangered Species of Wild :
Flora and Fauna (CITES)
note - abbreviated as Endangered Species
opened for signature - 3 March 1973
entered into force - 1 July 1975
objective - to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties - (152) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d`Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Latvia, Liberia, Liechtenstein, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (3) Ireland,
Kuwait, Lesotho
*Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention):
note - abbreviated as Marine Dumping
opened for signature - 29 December 1972
entered into force - 30 August 1975
objective - to control pollution of the sea by dumping and to
encourage regional agreements supplementary to the Convention
parties - (78) Afghanistan, Antigua and Barbuda, Argentina, Australia,
Azerbaijan, Barbados, Belarus, Belgium, Brazil, Canada, Cape Verde, Chile,
China, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Finland, France, Gabon,
Germany, Greece, Guatemala, Haiti, Honduras, Hong Kong (associate member),
Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, South Korea, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco,
Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles,
Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland,
Tonga, Tunisia, Ukraine, UAE, UK, US, Vanuatu, Yugoslavia
*Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques:
note - abbreviated as Environmental Modification
opened for signature - 10 December 1976
entered into force - 5 October 1978
objective - to prohibit the military or other hostile use of environmental
modification techniques in order to further world peace and trust among
nations
parties - (68) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil, Bulgaria,
Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary,
Iceland, India, Ireland, Italy, Japan, North Korea, South Korea, Kuwait,
Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan,
Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Saint Vincent
and the Grenadines, Sao Tome and Principe, Sierra Leone, Slovakia, Solomon
Islands, Spain, Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine,
UK, US, Uruguay, Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified - (15) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iran, Iraq, Lebanon,
Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Syria, Turkey, Uganda
*Convention on Wetlands of International Importance Especially as Waterfowl
Habitat (Ramsar):
note - abbreviated as Wetlands
opened for signature - 2 February 1971
entered into force - 21 December 1975
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific,
and recreational value
parties - (123) Albania, Algeria, Argentina, Armenia, Australia,
Austria, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Canada, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d`Ivoire, Croatia, Czech Republic, Denmark,
Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kenya, South Korea, Latvia, Lebanon, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mexico, Moldova, Monaco, Mongolia,
Morocco, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Sierra Leone, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Ukraine, UK, US, Uruguay, Venezuela, Vietnam, Yugoslavia, Zambia
*Desertification:
see United Nations Convention to Combat Desertification in those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
*Endangered Species:
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
*Environmental Modification:
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
*Hazardous Wastes:
see Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
*International Convention for the Regulation of Whaling:
note - abbreviated as Whaling
opened for signature - 2 December 1946
entered into force - 10 November 1948
objective - to protect all species of whales from overhunting;
to establish a system of international regulation for the whale fisheries
to ensure proper conservation and development of whale stocks; and to
safeguard for future generations the great natural resources represented
by whale stocks
parties - (41) Antigua and Barbuda, Argentina, Australia, Austria,
Brazil, Chile, China, Costa Rica, Denmark, Dominica, Finland, France,
Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South Korea,
Mexico, Monaco, Morocco, Netherlands, NZ, Norway, Oman, Peru, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Senegal, Solomon Islands, South Africa, Spain, Sweden, Switzerland, UK,
US
*International Tropical Timber Agreement, 1983:
note - abbreviated as Tropical Timber 83
opened for signature - 18 November 1983
entered into force - 1 April 1985; this agreement expired when
the International Tropical Timber Agreement, 1994, went into force
objective - to provide an effective framework for cooperation
between tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties - (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo, Republic
of the Congo, Cote d`Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland,
France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia,
Ireland, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal,
Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru, Philippines,
Portugal, Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad
and Tobago, UK, US, Venezuela
*International Tropical Timber Agreement, 1994:
note - abbreviated as Tropical Timber 94
opened for signature - 26 January 1994
entered into force - 1 January 1997
objective - to ensure that by the year 2000 exports of tropical
timber originate from sustainably managed sources; to establish a fund
to assist tropical timber producers in obtaining the resources necessary
to reach this objective
parties - (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d`Ivoire,
Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana,
Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South
Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway,
Panama, Papua New Guinea, Peru, Philippines, Portugal, Spain, Suriname,
Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Uruguay,
Vanuatu, Venezuela
countries that have signed, but not yet ratified - (1) Ireland
*Kyoto Protocol to the United Nations Framework Convention on Climate Change:
note - abbreviated as Climate Change-Kyoto Protocol
opened for signature - 16 March 1998, but not yet in force
objective - to further reduce greenhouse gas emissions by enhancing
the national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties - (32) Antigua and Barbuda, Azerbaijan, The Bahamas, Barbados,
Bolivia, Cyprus, Ecuador, El Salvador, Equatorial Guinea, Fiji, Georgia,
Guatemala, Guinea, Honduras, Jamaica, Kiribati, Lesotho, Maldives, Mexico,
Federated States of Micronesia, Mongolia, Nicaragua, Niue, Palau, Panama,
Paraguay, Samoa, Trinidad and Tobago, Turkmenistan, Tuvalu, Uruguay, Uzbekistan
countries that have signed, but not yet ratified - (64) Argentina,
Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Cook
Islands, Costa Rica, Croatia, Cuba, Czech Republic, Denmark, Egypt, Estonia,
EU, Finland, France, Germany, Greece, Indonesia, Ireland, Israel, Italy,
Japan, Kazakhstan, South Korea, Latvia, Liechtenstein, Lithuania, Luxembourg,
Malaysia, Mali, Malta, Marshall Islands, Monaco, Netherlands, NZ, Niger,
Norway, Papua New Guinea, Peru, Philippines, Poland, Portugal, Romania,
Russia, Saint Lucia, Saint Vincent and the Grenadines, Seychelles, Slovakia,
Slovenia, Solomon Islands, Spain, Sweden, Switzerland, Thailand, Ukraine,
UK, US, Vietnam, Zambia
*Law of the Sea:
see United Nations Convention on the Law of the Sea (LOS)
*Marine Dumping:
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
*Marine Life Conservation:
see Convention on Fishing and Conservation of Living Resources of the
High Seas
*Montreal Protocol on Substances That Deplete the Ozone Layer:
note - abbreviated as Ozone Layer Protection
opened for signature - 16 September 1987
entered into force - 1 January 1989
objective - to protect the ozone layer by controlling emissions
of substances that deplete it
parties - (175) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cameroon, Canada, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia,
Senegal, Seychelles, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
*Nuclear Test Ban:
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
*Ozone Layer Protection:
see Montreal Protocol on Substances That Deplete the Ozone Layer
*Protocol of 1978 Relating to the International Convention for the Prevention
of Pollution From Ships, 1973 (MARPOL):
note - abbreviated as Ship Pollution
opened for signature - 17 February 1978
entered into force - 2 October 1983
objective - to preserve the marine environment through the complete elimination of pollution by oil and other harmful substances and the minimization
of accidental discharge of such substances
parties - (115) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, The Bahamas, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia,
Comoros, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Equatorial Guinea,
Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guyana, Hong Kong (associate member), Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan,
Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania,
Luxembourg, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Monaco, Morocco, Netherlands, NZ, Nicaragua, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Peru, Poland, Portugal, Romania, Russia, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome
and Principe, Senegal, Seychelles, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US,
Uruguay, Vanuatu, Venezuela, Vietnam, Yugoslavia
*Protocol on Environmental Protection to the Antarctic Treaty:
note - abbreviated as Antarctic-Environmental Protocol
opened for signature - 4 October 1991
entered into force - 14 January 1998
objective - to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the area
covered by the Antarctic Treaty
parties - (27) Argentina, Australia, Belgium, Brazil, Bulgaria,
Chile, China, Ecuador, Finland, France, Germany, India, Italy, Japan,
South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa,
Spain, Sweden, UK, US, Uruguay
countries that have signed, but not yet ratified - (16) Austria,
Canada, Colombia, Cuba, Czech Republic, Denmark, Greece, Guatemala, Hungary,
North Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey,','2166464784700e5dd38da7f4149d0d0d32ec45d09e7cd4b7b7698c4b92c19968','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e601cdcaf12834372b837b1bbc606ec527b61581d7a8dbba21d926d43278fd7',2002,'UA','Ukraine','communications',255,'*Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution :
Concerning the Control of Emissions of Nitrogen Oxides or Their Transboundary
Fluxes
note - abbreviated as Air Pollution-Nitrogen Oxides
opened for signature - 31 October 1988
entered into force - 14 February 1991
objective - to provide for the control or reduction of nitrogen
oxides and their transboundary fluxes
parties - (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, EU, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia,
Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified - (1) Poland
*Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution :
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
note - abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature - 18 November 1991
entered into force - 29 September 1997
objective - to provide for the control and reduction of emissions
of volatile organic compounds in order to reduce their transboundary fluxes
so as to protect human health and the environment from adverse effects
parties - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein, Luxembourg,
Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified - (7) Canada,
EU, Greece, Norway, Portugal, Ukraine, US
*Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution :
on Further Reduction of Sulphur Emissions
note - abbreviated as Air Pollution-Sulphur 94
opened for signature - 14 June 1994
entered into force - 5 August 1998
objective - to provide for a further reduction in sulfur emissions
or transboundary fluxes
parties - (23) Austria, Belgium, Canada, Croatia, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Ireland, Italy, Liechtenstein,
Luxembourg, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified - (5) Bulgaria,
Hungary, Poland, Russia, Ukraine
*Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution :
on Persistent Organic Pollutants
note - abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature - 24 June 1998, but not yet in force
objective - to provide for the control and reduction of emissions
of persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (6) Canada, Luxembourg, Netherlands, Norway, Sweden,','209ea6eb97a06b08b98cb33eea66fef6ea8a856a0147c87b4f998c7ab489d185','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('528fce8a35617152e3787fc3721597e13ff5c98567abbd0d6550b7d4607031af',2002,'CH','Switzerland','communications',256,'countries that have signed, but not yet ratified - (30) Armenia,
Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark,
EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Moldova, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Ukraine, UK, US
*Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution :
on the Reduction of Sulphur Emissions or Their Transboundary Fluxes by
at Least 30%
note - abbreviated as Air Pollution-Sulphur 85
opened for signature - 8 July 1985
entered into force - 2 September 1987
objective - to provide for a 30% reduction in sulfur emissions
or transboundary fluxes by 1993
parties - (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden,
Switzerland, Ukraine
*Ship Pollution:
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
*Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water:
note - abbreviated as Nuclear Test Ban
opened for signature - 5 August 1963
entered into force - 10 October 1963
objective - to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons, including
nuclear weapons
parties - (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada, Central
African Republic, Chad, China, Colombia, Democratic Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia,
Germany, Ghana, Greece, Guatemala, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar,
Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New
Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San
Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UK, US, Venezuela, Yugoslavia, Zambia
countries that have signed, but not yet ratified - (17) Algeria,
Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali,
Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
*Tropical Timber 83:
see International Tropical Timber Agreement, 1983
*Tropical Timber 94:
see International Tropical Timber Agreement, 1994
*United Nations Convention on the Law of the Sea (LOS):
note - abbreviated as Law of the Sea
opened for signature - 10 December 1982
entered into force - 16 November 1994
objective - to set up a comprehensive new legal regime for the
sea and oceans; to include rules concerning environmental standards as
well as enforcement provisions dealing with pollution of the marine environment
parties - (135) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Barbados, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burma,
Cameroon, Cape Verde, Chile, China, Comoros, Democratic Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India,
Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South
Korea, Kuwait, Laos, Lebanon, Luxembourg, The Former Yugoslav Republic
of Macedonia, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Philippines,
Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda, Ukraine,
UK, Uruguay, Vanuatu, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (35) Afghanistan,
Bangladesh, Belarus, Bhutan, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Chad, Colombia, Republic of the Congo, Denmark,
Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea,
Lesotho, Liberia, Libya, Liechtenstein, Madagascar, Malawi, Morocco, Niger,
Niue, Qatar, Rwanda, Swaziland, Switzerland, Thailand, Tuvalu, UAE
*United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification,
Particularly in Africa:
note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects
of drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership arrangements
parties - (172) Afghanistan, Albania, Algeria, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
*United Nations Framework Convention on Climate Change:
note - abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas concentrations
in the atmosphere at a low enough level to prevent dangerous anthropogenic
interference with the climate system
parties - (186) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d`Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','cfa4435e2302af598dce1666623af474063ceb4c3aea761300fe1382c96713d4','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

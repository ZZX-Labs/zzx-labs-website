SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6f3933d46cb620f7efc1fdba43f8be1a7cea97ad0bbf08f0d28eac8d2280a3',1987,'AF','Afghanistan','economy',7,'GNP: $3.52 billion, $250 per capita (1985);
real growth rate 2.5% (1975-79); current
growth rate figures uot available (1986)
Natural resources: natural gas, oil, coal,
copper, talc, barites, sulphur, lead, zinc,
iron, salt, precious and semiprecious stones
Agriculture: subsistence farming and
animal husbandry; main crops—wheat,
fruits, nuts, karakul pelts, wool, mutton; an
illegal producer of opium poppy and
cannabis for the international drug trade
Major industries: small-scale production
of textiles, soap, furniture, shoes, fertilizer,
and cement for domestic use; handwoven
carpets for export
Electric power: 476,000 kW capacity;
1,390 million kWh produc. d, 90 kWh per
capita (1986)
Exports: $778 million (f.0.b., 1985); mostly
fruits aud nuts, natural gas, and carpets
Imports: $902 million (c.i-f., 1985); mostly
food supplies and petroleum products
Major trade partners: exports—mostly
USSR aud other Eastern bloc countries;
imports—mostly USSR and other Eastern
bloc countries
Afghanistan (continued)
Budget: current expenditure Af42.6 bil-
lion, capital expenditure Af16.0 billion
(FY86 est.)
Monetary conversion rate: 50.6
afghanis=US$1 (November 1986)
Fiscal year: 21 March-20 March','dbfd4a22052f1f2dc6be97b2316b4c092f8e98c1ca620a6275e6f2ca4d5e6737','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5665a22f6c5300a7a01749cfeeb0248018c60e86cfafb5f031cf0ae75f135cf6',1987,'AL','Albania','economy',13,'GNP: $2.7-2.9 billion (1986); about $930
per capita (1986)
Natural resources: oil, gas, coal, chro-
mium
Agriculture: corn, wheat, potatoes, to-
bacco, sugar beets, cotton
Major industries: agricultural products
and processing, textiles and clothing,
lumber, and extractive industries (chrome
and oil)
Shortages: spare parts, machinery and
equipment, some food products and con-
sumer goods
Electric power: 1,840,000 kW capacity;
4,900 million kWh produced, 1,610 kWh
per capita (1986)
Exports: $345 million (1985 est.); asphalt,
bitumen, petroleum products, metals and
metallic ores, electricity, oil, vegetables,
fruits, and tobacco
Imports: $335 million (1985 est.); machin-
ery, machine tools, iron and steel products,
textiles, chemicals, pharmaceuticals
Major trade partners: exports—Yugosla-
via, Czechoslovakia, Romania, Italy, Po-
land, France; imports—Yugoslavia, Czech-
oslovakia, FRG, Romania, Poland, Italy,
Greece, France
Budget: revenues $2.24 billion, expendi-
tures $2.23 billion; state investment $1.1
billion (1986)
Monetary conversion rate: 4.14
leks=US$1 (1986)
Fiscal year: calendar year','b7fb0b2d3ad2a0028a3831c215a27777a5ddaf2948665531cc628b00c8054d05','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a89ec69d2046f2c40ecf9410b2bf59c11723e5617e2c17fa985709a0c5fb4e69',1987,'DZ','Algeria','economy',18,'GDP: $57 billion (1985 est.), $2,420 per
capita; inflation rate about 15% (1986)
Natural resources: crude oil, natural gas,
iron ore, phosphates, uranium, lead, zinc,
mercury
Agriculture: wheat, barley, oats, grapes,
olives, citrus, fruits, dates, vegetables;
sheep, cattle
Major industries: petroleum, light indus-
tries, natural gas, mining, petrochemical,
electrical, automotive plants (under con-
struction), and food processing
Crude steel: 842,000 metric tons produced
(1982)
Electric power: 3,148,000 kW capacity;
12,410 million kWh produced, 540 kWh
per capita (1986)
Exports: $7.0 billion (f.0.b., 1986); petro-
leum and gas account for 98.0% of exports;
US 39.0%, France 23.0% (1984)
Imports: $6.0 billion (f.0.b., 1986); major
items—capital goods 35.0%, semifinished
goods 25.0%, foodstuffs 18.0%; France
25.7%, US 6.0%
Major trade partners: US, FRG, France,
Italy, Belgium, Netherlands, Canada
Budget: $20 billion revenue, $20 billion
expenditure (1984)
Monetary conversion rate; 4.81 Algerian
dinars=US$1 (November 1986)
Fiscal year: calendar year','43a20e210b10eaa5b77fd94019c300be938b5244460068c9162f484f4e75e29f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d432adda8b73926c613b9cd4cf04628d1d95a408b5c1454ebc755a083bbae77',1987,'ES','Spain','economy',23,'Natural resources: hydroelectric power,
mineral water
Agriculture: sheep raising; small quantities
of tobacco, rye, wheat, barley, oats, and
some vegetables
Major industries: tourism (particularly
skiing), sheep, timber, tobacco, and smug-
gling
Electric power: 35,000 kW capacity; 140
million kWh produced, 2,860 kWh per
capita (1986); power is mainly exported to
Spain and France
Major trade partners: Spain, France
Monetary conversion rate: 6.62 French
francs=US$1, 136.13 Spanish
pesetas= US$1 (November 1986)
GNP: $187.6 billion (1986 est.); 70% pri-
vate consumption, 138% government con-
sumption, 17% gross fixed capital invest-
ment; 0.2% change in stocks; 2% net ex-
ports; real growth rate 2.9% (1986); 8.6%
inflation (1986)
Natural resources: coal, lignite, iron ore,
uranium, mercury, pyrites, fluorspar,
gypsum, zinc, lead, tungsten, copper,
kaolin, hydroelectric power
Agriculture: grains, citrus, fruits, vegeta-
bles; virtually self-sufficient in good crop
years
Fishing: catch, 1,100,000 metric tons
(1985)
Major industries: textiles and apparel
(including footwear), food and beverages,
metals and metal manufactures, chemicals,
shipbuilding, automobiles
Crude steel: 14.2 million metric tons
produced (1985), 370 kg per capita
Electric power: 41,120,000 kW capacity;
134,380 million kWh produced, 3,440
kWh per capita (1986)
Exports: $24.0 billion (f.o.b., 1985); iron
and steel products, machinery, automo-
227
biles, citrus, fruits, vegetables, wine, soy-
bean oil, feed barley, textiles, footwear
Imports: $28.0 billion (c.i.f., 1985); fuels
(88%), machinery, chemicals, iron and
steel, automobiles, corn, soybeans, coffee,
tobacco, forest products, hides and skins,
cotton, live cattle
Major trade partners: (1985) 42% EC,
81% less developed countries, 11% other
developed countries, 11% US, 5% Commu-
nist countries
Aid: US authorizations, $1.9 billion, in-
cluding Ex-Im (FY70-85); other Western
bilateral (ODA and OOF), $545.0 million
(1970-79)
Military transfers: US (FY70-85), $2.4
billion
Budget: revenues, $56 billion; expendi-
tures, $67 billion; deficit, $10 billion (1985)
Monetary conversion rate: 136.13
pesetas=US $1 (October 1986)
Fiscal year: calendar year','cb31d3f1bcc85c3727815157715c04ef13a68edf4837fd1aaa014073b149179b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8a72a267baf1a8ecedbc075601fce143061fe235be6e99cba3af1c829093f45',1987,'AO','Angola','economy',29,'GDP: $3.0 billion, $390 per capita, 0%
real growth (1986 est.)
Natural resources: petroleum, diamonds,
iron, phosphates, copper, feldspar, gold,
bauxite, uranium
Agriculture: cash crops—coffee, sisal, corn
cotton, sugar, manioc, and tobacco; food
crops—cassava, corn, vegetables, plantains
bananas, and other local foodstuffs; disrup-
tions caused by civil war require food
imports
Fishing: catch 112,000 metric tons (1982)
Major industries: mining (oil, diamonds),
fish processing, brewing, tobacco, sugar
processing, textiles, cement, food process-
ing plants, building construction
Electric power: 540,000 kW capacity; 851
million kWh produced, 100 kWh per
capita (1986)
Exports: $1.2 billion (f.0.b., 1986 est.) oil,
coffee, diamonds, sisal, fish and fish prod-
ucts, timber, and cotton
Imports: $1.4 billion (f.0.b., 1986 est.);
capital equipment (machinery and electri-
cal equipment), food, vehicles and spare
parts, textiles and clothing, medicines;
substantial military deliveries
Major trade partners: US, USSR, Cuba,
Portugal, and Brazil
Budget: total expenditures $2.7 billion
(1986 est.)
Monetary conversion rate: official rate
80.214 kwanza=US$1; black market rate
reportedly 1,200-1,500 kwanza=US$1
(December 1986)
Fiscal year: calendar year','6c25b45b1a59c468e69eb67d18e5368742ee56e9443b0aed1fae04a9d22f177a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9732fff38d26ebfa55733e2226b87c595b4c98ded9e584c2a8f35985a0d5957c',1987,'AI','Anguilla','economy',34,'GDP: $6 million, $6,000 per capita (1983
est.)
Agriculture: pigeon peas, corn, sweet
potatoes, sheep, goats, pigs, cattle, poultry
Fishing: inshore and reef fishing
Major industries: tourism, lobster exports,
salt, fishing
Electric power: 3,000 kW capacity; 9
million kWh produced, 1,320 kWh per
capita (1986)
Exports: lobsters
Budget: revenues, $4.8 million; expendi-
tures, $5.8 million (1984)
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (December 1986)
Fiscal year: probably calendar
Anguilla (continued)','120acba3ae68d54203ae5b8e875e81566ccf1ae0ebd9f22509cfc9dc9ea41b5f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b562795aac7b4316cd3760d8048a63f45262d9969fd59008b46d0f46fb422c1',1987,'AG','Antigua and Barbuda','economy',39,'GDP: $158 million (1984), $1,980 per
capita; inflation rate 4.0% (1985)
Natural resources: negligible
Agriculture: cotton (main crop), sugar,
livestock
Major industries: tourism 15.2%, construc-
tion 7.7%, manufacturing 0.5%
Electric power: 29,000 kW capacity; 63.8
million kWh produced, 780 kWh per
capita (1986)
Exports: $41 million (f.0.b., 1984); cloth-
ing, rum, lobsters
Imports: $134 million (f.0.b., 1984); fuel,
food, machinery
Major trade partners: exports—47%
Trinidad and Tobago, 8% Barbados, 1%
US; imports—49% US, 13% UK, 4% Ja-
maica, 2% Trinidad and Tobago (1983)
Aid: bilateral commitments, ODA and
OOF (1970-80) from Western (non-US)
countries, $20 million
Budget: (current) revenues, $40 million;
expenditures, $44 million (1984)
Monetary conversion rate: 2.70 East
Caribbean (EC) dollars=US$1 (November
1986)
Fiscal year: 1 April-31 March','b13c25507ccf1d9a54b54b12405a91b23f81e9ed899da8aa80b3fc2338c8f41f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6e402749d1b05d6a87daafe41cac96c3751440c80ab1b6ecb2b9c5e45b0da31',1987,'AR','Argentina','economy',44,'GDP: $63.3 billion at average official
exchange rate (1985), $2,090 per capita;
80% consumption, 15% investment; 5% net
exports; 4.4% real GDP decline (1985);
economic activity grew by 2-3% in 1986
Natural resources: pampas, lead, zinc, tin,
copper, iron, manganese, oil, uranium
Agriculture: main products—cereals,
oilseed, livestock products; major world
exporter of temperate zone foodstuffs
Fishing: catch 377,200 metric tons; exports
$127.4 million (1985)
Major industries: food processing (espe-
cially meat packing), motor vehicles,
consumer durables, textiles, chemicals,
printing, and metallurgy
Steel: 2.9 million metric tons produced, 95
kg per capita (1985)
Electric power: 15,300,000 kW capacity;
42,790 million kWh produced, 1,370 kWh
per capita (1986)
Exports: $8.4 billion (f.0.b., 1985); wheat,
corn, oilseed, hides, wool
Imports: $4.1 billion (f.0.b., 1985); chemi-
cal products, machinery, metallurgical
products, fuel and lubricants
Major trade partners: exports—20%
USSR, 13% US, 9% Netherlands, 5% Bra-
zil, 5% Italy, 5% Japan, 4% FRG; im-
ports—18% US, 16% Brazil, 14% FRG, 9%
Bolivia, 7% Japan, 6% France (1985)
Budget: (1986) general government reve-
nues $26.4 billion; current and capital
expenditures $31.3 billion at average
official exchange rate for 1986
Monetary conversion rate: 1.25
australes=US$1 (31 December 1986)
Fiscal year: calendar year','be3e8544e09948f6e4ae3bb64cbb9b96cae959e5c2b4b821149df14cb1efeac3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef455d0c15922c102cbca61866531fafc77fb1c7afe955f007c2ce5b5222c3a',1987,'AW','Aruba','economy',49,'GNP: $461.4 million, $6,885 per capita;
real growth rate - 5.8% (1984)
Agriculture: little production
Major industries: petrochemicals, oil
refining, petroleum transshipment facili-
ties, tourism, light manufacturing
Electric power: 310,000 kW capacity, 945
million kWh produced, 1,410 kWh per
capita (1986)
Budget: revenues, $100 million; expendi-
tures $150 million (1985)
Monetary conversion rate: 1.8 Aruban
florins=US$1 (1986)','7acf7681f96db03d62e0cecaf9398f4efaf1f54c2936fcbc1b06c82955e905e2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c173337d2b774e31858d92087defd57f1a39ffcad33a5d6b0842ebbce2b0bac5',1987,'AU','Australia','economy',54,'GDP: $153.0 billion (1985), $9,760 per
capita; 60% private consumption, 22%
investment, 17.1% government expendi-
ture; 1.25% average annual real growth
rate (1986); inflation rate 8.9% (October
1986)
Natural resources: bauxite, coal, iron ore,
copper, tin, silver, uranium, nickel, tung-
sten, mineral sands, lead, zinc, diamonds,
natural gas, oil
Agriculture: large areas devoted to graz-
ing; 60% of area used for crops is planted
in wheat; major products—wool, lamb,
beef, wheat, fruits, sugarcane; self-
sufficient in food
Major industries: mining, industrial and
transportation equipment, food processing,
chemicals
Crude steel]: 6.6 million metric tons pro-
duced, 420 kg per capita (1985)
Electric power: 34,616,000 kW capacity;
125,000 million kWh produced, 7,810
kWh per capita (1986)
Exports: $22.9 billion (f.0.b., 1985); princi-
pal products—wheat, barley, beef, lamb,
dairy products, wool, coal, iron ore
Imports: $26.0 billion (c.i-f., 1985) princi-
pal products—manufactured raw materi-
als, capital equipment, consumer goods
Major trade partners: (1983-84) exports—
26% Japan, 11% US, 6% New Zealand, 4%
North Korea, 4% Singapore, 3% USSR;
imports—22% US, 22% Japan, 7% UK, 6%
FRG, 4% New Zealand
Aid; donor—ODA and OOF economic aid
commitments (1970-84), $7 billion
Budget: (FY86-87 proj.) expenditures,
$49.3 billion; revenues, $47.0 billion;
deficit, $2.3 billion
Monetary conversion rate: 1.55 Australian
dollars=US$1 (14 January 1987)
Fiscal year: 1 July-80 June','5f45650c9d735d247c5e8d4092c899fd1f63d54c18fc5ecf0f29c803661de4ee','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfea61ed553f2005d2027abfb2c296eaa1aa050df02e5ee6a4ae463f4487cb72',1987,'AT','Austria','economy',59,'GDP; $66.26 billion, $8,888 per capita;
57% private consumption, 22% investment,
19% public consumption; real GNP growth
rate, 2.9%; 3.3% inflation rate (1985)
Natural resources: iron ore, petroleum,
timber, magnesite, aluminum, coal, lignite,
cement, copper
Agriculture: livestock, forest products,
cereals, potatoes, sugar beets; 84% self-
sufficient
Major industries: foods, iron and steel,
machinery, textiles, chemicals, electrical,
paper and pulp
Crude steel: 5.8 million metric tons pro-
duced (1984)
Electric power: 15,846,000 kW capacity;
46,460 million kWh produced, 6,160 kWh
per capita (1986)
14
Exports: $17.1 billion (f.0.b., 1985); iron
and steel products, machinery and equip-
ment, lumber, textiles, paper products,
chemicals
Imports: $20.8 billion (c.i.f., 1984); ma-
chinery and equipment, chemicals, textiles
and clothing, petroleum, foodstuffs, vehi-
cles, office machines, pharmaceuticals
Major trade partners: (1984) imports—
41% FRG, 8.2% Italy, 7.3% East Europe
(excluding USSR), 4.5% Switzerland, 4.4%
USSR, 3.7% US; exports—30.1% FRG,
9.6% East Europe (excluding USSR), 9.0%
Italy, 6.7% Switzerland, 6.0% OPEC, 4.7%
US
Aid; donor—ODA and OOF economic aid
commitments (1970-84), $1.4 billion
Budget: expenditures, $22.10 billion;
revenues, $18.80 billion; deficit, $3.3
billion (1986)
Monetary conversion rate: 14.26
schillings=US$I (November 1986)
Fiscal year: calendar year
GDP: $2.1 billion, $8,950 per capita; real
growth rate 2% (1986 est.); inflation rate
4.0% (1985)
Natural resources: salt, aragonite, timber
Agriculture: food importer; produces
vegetables, tomatoes, pineapples, bananas,
citrus fruits; pigs, sheep
Major industries: banking, tourism, ce-
ment, oil refining and transshipment,
lumber, salt production, rum, aragonite,
pharmaceuticals, spiral weld, and steel
pipe
Electric power: 850,000 kW capacity; 885
million kWh produced, 3,770 kWh per
capita (1986)
Exports: $296 million (f.0.b., 1985); phar-
maceuticals, cement, rum, crawfish
Imports: $891 million (f.0.b., 1985); food-
stuffs, manufactured goods, mineral fuels
Major trade partners: exports—US 90%,
UK 10%; imports—Iran 30%, Nigeria 20%,
US 10%, EC 10%, Gabon 10% (1981)
Aid: US economic commitments, including
Ex-Im (1970-80), from US, $42 million;
ODA and OOF economic commitments
(1970-84), $168 million
Budget: (June 1986 est.) revenues, $422.4
million; expenditures, $414.9 million
Monetary conversion rate: 1.175 Baha-
mian dollars=US$1 (November 1986)
Fiscal year: calendar year','a68f1616f4755e4bab4371b886c001f84f9e78f5ee3835b00318a362bab3bdb1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e796eee03d0bf38137ea05365b3dc01841432eb8b1399d4d601832dfa1d59c82',1987,'BH','Bahrain','economy',64,'GDP: $4.6 billion, $11,190 per capita; real
growth rate 7.5% (1984 est.)
Natural resources: oil, associated and
nonassociated natural gas, fish
Agriculture: not self-sufficient in food
production; produces some fruit and
vegetables; engages in dairy and poultry
farming and in shrimping and fishing
Major industries: petroleum processing
and refining, aluminum smelting, offshore
banking, ship repairing
Electric power: 1,552,000 kW capacity;
6.800 million kWh produced, 16,110 kWh
per capita (1986)
Exports: $2.8 billion (f.0.b., 1985); nonoil
exports $400 million; oil exports $2.4
billion (1985)
Imports: $2.8 billion (f.0.b., 1985); nonoil
imports $1.4 billion; oil imports $1.0
billion (1985)
Major trade partners: UK, Japan, US,','5b6df0d95f2a7c30ba617c9d5ab3a58bf7e3002f5b13a41ee34d78110726b293','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6fb5e2eab4fd260cc61667f6eb2def52925aacc17d5dca2d528e7041adb13b6',1987,'SA','Saudi Arabia','economy',65,'Budget: $952 million current expenditures,
$510 million capital expenditures (1986)
Monetary conversion rate: 0.38 Bahrain
dinar=US$1 (November 1986)
Fiscal year: calendar year
GDP: $133.6 billion (FY85), $9,920 per
capita; annual growth in nonoil GDP in
constant 1969/70 prices about 7%
(1981-84)
Natural resources: oil, natural gas, iron
ore, gold, copper
214
Agriculture: dates, grains, livestock; not
self-sufficient in food except wheat
Major industries: crude oil production 5.0
million b/d (1986); oil revenue payments
to Saudi Arabian Government, $15 billion
(FY86); petroleum refining, basic petro-
chemicals, cement production and small
steel-rolling mill; several other light indus-
tries, including factories producing deter-
gents, plastic products, furniture
Electric power: 20,005,000 kW capacity;
43,810 million kWh produced, 3,800 kWh
per capita (1986)
Exports: $37 billion (f.0.b., 1985); 95%
petroleum and petroleum products
Imports: $34 billion (c.i.f., 1985); manufac-
tured goods, transportation equipment,
construction materials, and processed food
products
Major trade partners: exports and reex-
ports—Japan 32%, US 6%, Bahrain 5%,
Italy 4%; imports—US 21%, Japan 18%,
Italy 8%, FRG 8% (1985)
Budget: (FY87 proposed) appropriations,
$31 billion; expenditures, $45 billion
Monetary conversion rate: 3.74 Saudi
riyals=US$1 (December 1986)
Fiscal year: calendar year as of 1 January
1987 (previously followed Islamic calendar
months Rajab through Jumada II)
Aid: Western (non-US) countries (1970-84),
$630 million; US, including Ex-Im (FY70-
85), $590 million
Military transfers: US (FY70-85), $2.3
million
Budget: (1985) revenues, $5.55 billion;
expenditures, $5.55 billion;
Monetary conversion rate: 2.14 Singapore
dollars=US$) (14 January 1987)
Fiscal year: 1 April-381 March
GNP: $1.1 billion (1985 est.), $500 per
capita
Natural resources: fish, oil, minerals (gold,
copper, lead)
Agriculture: cotton is main cash crop;
cereals, dates, qat (a mild narcotic), coffee,
and livestock are raised, and there is a
growing fishing industry; large amount of
food must be imported (particularly for
Aden); cotton, hides, skins, dried and
salted fish are exported
Major industries: petroleum refinery at
Little Aden operates on imported crude
Electric power: 254,000 kW capacity; 556
million kWh produced, 240 kWh per
capita (1986)
Exports: $316 million (f.0.b. 1985 est.)
Imports: $762 million (f.o.b., 1985 est.)
Major trade partners: 1985 imports
mainly from USSR 14%, Australia 9%, UK
7%; exports mainly to Japan 36%, North
Yemen 23%, Singapore 10%
Budget: (1985 est.) total receipts $433
million, current expenditures $495 million,
development expenditures $327 million
Monetary conversion rate: 0.3454
dinar=US$1 (November 1986)
Fiscal year: calendar year','0495dacb8d05467a99b3b9e7b7743679430d78dfdd32416576a01eb964c50229','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbd15e4c7c4af3e53ebb5e7629ddcbd8f82fb887f4dda0dbb730c671c7eb91b5',1987,'IN','India','economy',72,'GNP: $13.9 billion (FY85, current prices),
$140 per capita; 4.5% real growth (FY86);
11% inflation rate (FY86)
Natural resources: natural gas, uranium
Agriculture: large-scale subsistence farm-
ing, heavily dependent on monsoon rain-
18
fall; main crops are jute, tea, and rice;
grain, cotton, and oilseed shortages
Fishing: production 751,000 metric tons
(1984)
Major industries: jute manufactures, food
processing, and cotton textiles
Electric power: 1,212,000 kW capacity;
4,590 million kWh produced, 40 kWh per
capita (1986)
Exports: $934 million (f.0.b., FY85); raw
and manufactured jute, leather, tea
Imports: $2.6 billion (c.i.f., FY85); food-
grains, fuels, raw cotton, fertilizer, manu-
factured products
Major trade partners: exports—Middle
East 19%, US 18%, Japan 7%, UK 5%,
Italy 4.7%; imports—US 13.7%, Western
Europe 11.5%, Middle East 11%, Japan 7%
(FY85)
Budget: (FY87) current expenditures,
$1.25 billion; capital expenditures, $1.59
billion
Monetary conversion rate: 30.48
takas=US$1 (November 1986)
Fiscal year: ] July-30 June
GNP: $190 billion (FY85/86 at current
prices), $250 per capita; real growth 4%
(FY85/86 est.)
Natural resources: coal, iron ore, manga-
nese, mica, bauxite, chromite, natural gas
Agriculture: rice, other cereals, pulses,
oilseed, cotton, jute, sugarcane, tobacco,
tea, coffee; an illegal producer of opium
poppy and cannabis for the international
drug trade
Fishing: catch 2.34 million metric tons
(1984); exports $337 million (1982)
Major industries: textiles, food processing,
steel, machinery, transportation equip-
ment, cement, jute manufactures
Crude steel: 10.9 million metric tons, 14
kg per capita (1985)
Electric power: 46,663,000 kW capacity;
170,000 million kWh produced, 220 kWh
per capita (1986)
Exports: $8.3 billion (f.0.b., FY85/86),
engineering goods, textiles and clothing,
tea
Imports: $15.0 billion (c.i.f., FY85/86);
machinery and transport equipment,
petroleum, edible oils, fertilizers
Major trade partners: US, UK, USSR,','6963e0f49e7203d6796f7ce284c664127ec690a647f8eb9fcf1b54223266d05f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c49dc6bd4966a665c897895b62f83ccc4bfea62860e2412b2e47321e3732e62',1987,'BB','Barbados','economy',78,'GDP: $1,151.7 million (1984), $4,560 per
capita; real GDP growth rate 2.5% (1986
est.) inflation rate 7.0% (1985)
Natural resources: negligible
Agriculture: main products—-sugarcane,
subsistence foods
Major industries: tourism, sugar milling,
light manufacturing, component assembly
for export
Electric power: 120,000 kW capacity; 389
million kWh produced, 1,540 kWh per
capita (1986)
Exports: $352 million (f.o.b., 1985); sugar
and sugarcane byproducts, electrical parts,
clothing
Imports: $552 million (f.0.b., 1985); food-
stuffs, consumer durables, machinery, fuels
Major trade partners: exports—42% US,
22% CARICOM, 7% UK; imports—48%
US, 12% CARICOM, 8% UK, 6% Canada
(1984)
Aid: US, including Ex-Im (FY70-84), $14
million; ODA and OOF commitments
from other Western countries (1970-84),
$125 million
Budget: (FY84) revenues, $288 million;
expenditures, $323 million
Monetary conversion rate: 2.01 Barbados
dollars=US$I (November 1986)
Fiscal year: 1 April-31 March','6507a2c17061ef168f9ec07142d99073c3f8ab3a7320a78ad78e9ef7c2fa1413','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d553e4491bec2018eb362f7cf7b6d21ba02bf05722ba80f97534c2bcd1978c',1987,'BE','Belgium','economy',83,'GNP: $79.9 billion (1985), $8,100 per
capita; 65.3% private consumption, 17.9%
government consumption, 15.6% invest-
ment, 1.2% net foreign balance (1983);
1.1% real growth rate (1985); average
exchange rate 59.378 Belgian francs=
US$1 (1985)
21
Natural resources: coal
Agriculture: livestock production predomi-
nates; main crops—egrains, sugar beets, flax,
potatoes, other vegetables, fruits
Fishing: catch 44,308 metric tons (1985);
exports $83.52 million, imports $300.12
million
Major industries: engineering and metal
products, processed food and beverages,
chemicals, basic metals, textiles, glass,
petroleum
Crude steel: 14.6 million metric tons
capacity; 10.7 million metric tons pro-
duced, 1,086 kg per capita (1985)
Electric power: 16,921,000 kW capacity;
57,450 million kWh produced, 5,820 kWh
per capita (1986)
Exports: (Belgium-Luxembourg Economic
Union) $53.8 billion (f.o.b., 1985); iron and
steel products (cars), petroleum products,
chemicals
Imports: (Belgium-Luxembourg Economic
Union) $55.8 billion (c.i-f., 1985); fuels,
foodstuffs, chemicals
Major trade partners:
(Belgium-Luxembourg Economic Union,
1985) exports—69.1% EC (19.0% France,
18.7% FRG, 14.8% Netherlands, 9.7% UK),
6.3% US, 2.8% Communist countries;
imports—68.9% EC (21.1% FRG, 18.7%
Netherlands, 15.2% France, 9.0% UK),
5.7% US, 3.4% Communist countries
Aid: ODA and OOF economic aid com-
mitments (1970-84), $3.8 billion
Budget: revenues, $23.3 billion; expendi-
tures, $32.5 billion; deficit, $9.2 billion
(1985)
Monetary conversion rate: 40.17 Belgian
francs=US$1 (8 January 1987)
Fiscal year: calendar year','6a1b778e4c20f90c0cb498c999cb93612cf3452621a23cbda994fb9a47b2fa3a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e460c15967b218114c16094d022f83a45bde8b03120e6dfa7aaf87b0269e6a2a',1987,'GT','Guatemala','economy',88,'GDP: $193 million (1985), $1,190 per
capita; real growth rate 1.5% (1984)
Natural resources: arable land, timber,
fish
Agriculture: main products—sugarcane,
citrus fruits, corn, molasses, rice, beans,
bananas, livestock products, honey; net
importer of food; an illegal producer of
cannabis for the international drug trade
Fishing: catch 1,349 metric tons (1980)
Major industries: sugar refining, garments,
timber and forest products, furniture, rum,
soap, beverages, cigarettes
Electric power: 34,340 kW capacity; 71
million kWh produced, 420 kWh per
capita (1986)
Exports: $90.1 million (1985 est.); sugar,
garments, seafood, molasses, citrus fruits,
wood and wood products
Imports: $128 million (1985 est.); machin-
ery and transportation equipment, food,
manufactured goods, fuels, chemicals,
pharmaceuticals
Major trade partners: exports—US 36%,
UK 22%, Trinidad and Tobago 11%,
Canada 10%; imports—US 55%, UK 17%,
Netherlands Antilles 8%, Mexico 7% (1983)
Aid: US economic commitments, including
Ex-lm (FY70-85), $56 million; ODA and
OOF commitments from Western (non-
US) countries (1970-84), $174 million
Budget: revenues, $49 million; expendi-
tures, $90 million (FY84/85)
Monetary conversion rate: 2 Belize
dollars=US$1 (November 1986)
Fiscal year: } April-31 March
GDP: $9.2 billion (1985), $1,120 per
capita; 26% commerce, 25% agriculture,
9% financial services, 7% transportation
and communication, 6% government, 27%
other; average annual real growth rate
5.7% (1975-80); real growth rate 0.0%
(1986)
Natural resources: oil, nickel, rare woods,
fish, chicle
Agriculture: coffee, cotton, corn, beans,
sugarcane, bananas, livestock; an illegal
producer of opium poppy and cannabis
Fishing: catch 4,300 metric tons (1982)
Major industries: food processing, textiles
and clothing, furniture, chemicals, non-
metallic minerals, metals
Electric power: 878,000 kW capacity;
2.250 million kWh produced, 260 kWh
per capita (1986)
Exports: $1.2 billion (f.0.b., 1985); coffee,
cotton, sugar, bananas, meat
Imports: $1.3 billion (c.i.f., 1985); manu-
factured products, machinery, transporta-
tion equipment, chemicals, fuels
Major trade partners: exports (1985)—
85% US, 17% El Salvador, 6% Honduras,
5% Costa Rica; imports (1983)—33% US,
10% El Salvador, 8% Netherland Antilles,
7% Mexico, 7% Venezuela
Aid: US, including Ex-Im (FY70-85), $432
million; from other Western (non-US)
countries, ODA and OOF (1970-84), $6.7
billion
Military transfers: US (FY70-85), $22
million
Budget: expenditures, $1.710 billion;
revenues, $975 million (1986 est.)
Monetary conversion rate: 1
quetzal=US$1 (official, November 1986);
3.30 quetzals=US$1 (unofficial, December
1985)
Fiseal year: calendar year','9346d7a60d1747029d0bf5812b27ae9c5ae94dae4fc92e1315645b1128ef650a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2e37e733cb265b0108463264e69dd104dd0260e28d31e47ff58813ffd2934c',1987,'BJ','Benin','economy',94,'GNP: $974.2 million (1984 est.), $250 per
capita (1983); 1.6% growth (1984)
Natural resources: small offshore oil
deposits; no other known minerals in
commercial quantity
Agriculture: major cash crop is palm oil;
peanuts, cotton, coffee, shea nuts, and
tobacco also produced commercially; main
food crops—corn, cassava, yams, rice,
sorghum, millet; livestock, fish
Fishing: catch 21,000 metric tons (1983)
Major industries: palm oil and palm
kernel oil processing, textiles, beverages
Electric power: 28,000 kW capacity; 24
million kWh produced, 5 kWh per capita
(1986)
Exports: $172.5 million (f.0.b., 1984 est.);
palm products, cotton, other agricultural
products
Imports: $225.4 million (f.0.b. 1984 est.);
thread, cloth, clothing and other consumer
goods, construction materials, iron, steel,
fuels, foodstuffs, machinery, and transport
equipment
Major trade partners: France, EC, france
zone; preferential tariffs to EC and franc
zone countries
Budget: revenues $119 million; expendi-
tures, $119 million (1985 est.)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year','c8398e33e60023858beecd41bf65b66b313c336232582ee7bd1bb3c266264b60','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fa238155c160ffeba11093fadef5428c1c879b4ce1fa960b67b1abd2abe517c',1987,'BM','Bermuda','economy',99,'GDP: $1,148.1 million (1985-86), $19,800
per capita—factor cost (1984-85); real
growth rate 1.1% (1983-84); average infla-
tion rate 3.8% (1984-85)
Natural resources: limestone (used prima-
rily for building)
Agriculture: main products—bananas,
vegetables, Easter lilies, dairy products,
citrus fruits
Major industries: tourism (33%), finance,
structural concrete products, paints, per-
fumes, furniture
Electric power: 118,000 kW capacity; 378
million kWh produced, 6,410 kWh per
capita (1986)
Exports: $38 million (1984); semitropical
produce, light manufactures
Imports: $404 million (1984); fuel, food-
stuffs, machinery
Major trade partners: 56% US, 11%
Caribbean countries, 8% UK, 6% Canada,
19% other; tourists, 90% US
Aid: bilateral commitments, including
Ex-Im (FY70-81), from US $34 million;
from Western (non-US) countries, ODA
and OOF (1970-84), $265 million
Budget: revenues, $208 million; expendi-
tures, $218 million (FY85/86 est.)
Monetary conversion rate: 1 Bermuda
dollar=US$1 (September 1986)
Fiscal year: 1 April-31 March','97b5be7dd4cabbd8dabb7a5efa702850aeaee34e43862f0b9d603478a4f5fc8c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43380da7d80d29d5c66b0c5036cd00ac871b631dc37ff6c0c7ed9d7a0093c80e',1987,'BT','Bhutan','economy',104,'GDP: $300 million, $210 per capita; 6.7%
real GDP growth (FY84/85)
Natural resources: timber, hydroelectric
power
Agriculture: rice, corn, barley, wheat,
potatoes, fruit, spices
Major industries: cement, chemical prod-
ucts, mining, distilling, food processing,
handicrafts
Electric power: 352,000 kW capacity;
1,950 million kWh produced, 13 kWh per
capita (1986)
Exports: $15.1 million (FY84/85); agricul-
tural and forestry products, coal
Imports: total imports $69.4 million
(FY84/85); imports from India $61.0
million; textiles, cereals, vehicles, fuels,
machinery
Major trade partner: India
Budget: total receipts, $59.168 million;
expenditures, $66.86] million (FY85/86
est.)
Monetary conversion rate: both ngul-
trums and Indian rupees are legal tender;
12.88 ngultrums=12.88 Indian
rupees=US$1 (October 1985)
Fiscal year: 1 April-31 March
GDP: $3.79 billion (1986 est.), $610 per
capita; 79.2% private consumption, 16.6%
public consumption, 12.0% gross domestic
investment; - 11.0% current account bal-
ance (1983); real growth rate - 3.7% (1986)
Natural resources: tin, natural gas, petro-
leum, zinc, tungsten, antimony, silver, iron
ore
Agriculture: main crops—potatoes, corn,
rice, sugarcane, yucca, bananas, coffee;
imports significant quantities of wheat; an
illegal producer of coca for the interna-
tional drug trade
Major industries: mining, smelting, petro-
leum refining, food processing, textiles,
and clothing
Electric power: 508,000 kW capacity;
2,080 million kWh produced, 330 kWh
per capita (1986)
Bolivia (continued)
Exports: $673 million (f.0.b., 1985); tin,
natural gas, silver, tungsten, zinc, anti-
mony, lead, bismuth, gold, coffee, sugar,
cotton
Imports: $582 million (c.i.f., 1985); food-
stuffs, chemicals, capital goods, pharma-
ceuticals, transportation
Major trade partners: exports—Argentina
44%, US 24%, EC 19%, FRG 6%, UK 4%;
imports—Brazil 22%, US 16%, EC 16%,
Argentina 14%, Japan 138%, FRG 4% (1984)
Budget: revenues, $476.9 million; expendi-
tures, $669.8 million (1986 est.)
Monetary conversion rate: 1,923,000
pesos=US$1 (December 1986); currency
changed to boliviano on 1 January 1987
with a one-year transition period; 1.92
bolivianos=US$1 (1 January 1987)
Fiscal year: calendar year','5b628708bbc3819cfad7a7adec638e4a0a5b5eb63cd294802079af7631cc1dc5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8487e41334d39a3f43a1933aae103c4f891601269d2e9d136246434ece4e48f2',1987,'BW','Botswana','economy',109,'GDP: $905 million, $880 per capita;
average annual real growth 2% (FY83/84)
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal
Agriculture: principal crops are corn,
sorghum, millet, cowpeas; livestock raised
and exported; heavy dependence on im-
ported food
Major industries: livestock processing;
mining of diamonds, copper, nickel, coal,
salt, soda ash, potash; tourism
Electric power: 174,000 kW capacity; 583
million kWh produced, 480 kWh per
capita (1986)
Exports: $653 million (f.0.b. 1985); dia-
monds, cattle, animal products, copper,
nickel
Imports: $535 million (c.i.f., 1985); food-
stuffs, vehicles, textiles, petroleum products
Major trade partners: Switzerland, US,
UK, other EC members of Southern Afri-
can Customs Union
Budget: revenues, $433 million; expendi-
tures, $35] million (FY84/85 est.)
Monetary conversion rate: 1.88
pula=US$1 (November 1986)
Fiscal year: ] April-31 March
29','8f01953374a5c28778463639042a9dd3ba8341be03d8c19581a826a3c60066c5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f7eed9236dc603e09674d3cd2dadaf8572e5bc480ef0323db9e2f31ceb9740',1987,'BR','Brazil','economy',114,'GNP: $250 billion, $1,740 per capita (1986
est.); 83% consumption, 16% gross invest-
ment, 2% net foreign balance (1984 est.);
real growth rate 8.38% (1985); inflation rate
about 70% (1986)
Natural resources: iron ore, manganese,
bauxite, nickel, uranium, tin, gemstones,
hydroelectric power
Agriculture: main products—coffee, rice,
corn, sugarcane, cocoa, soybeans, cotton,
manioc, oranges; nearly self-sufficient
except for wheat; an illegal producer of
coca and cannabis for the international
drug trade
Fishing: catch 958,908 metric tons (1984);
exports, $174 million (f.0.b., 1984); im-
ports, $36 million (f.0.b., 1984)
Major industries: textiles and other con-
sumer goods, chemicals, cement, lumber,
iron ore, steel, motor vehicles, other metal-
working industries, capital goods, tin
Crude steel: 20.0 million metric tons
capacity; 17.5 million metric tons pro-
duced (1985); 125 kg per capita
Electric power: 42,945,000 kW capacity;
1,680,000 million kWh produced, 1,170
kWh per capita (1986)
Exports: $25.1 billion (f.0.b., 1985); soy-
beans, coffee, transport equipment, iron
ore, steel products, chemicals, machinery,
orange juice, shoes, sugar
Imports: $12.7 billion (f.0.b., 1985); petro-
leum, machinery, chemicals, fertilizers,
wheat, copper
Major trade partners: exports—27% US,
27% EC, 9% Latin America, 5% Japan,
32% other (1985); imports—35% Middle
East and Africa, 20% US, 12% Latin
America, 15% EC, 4% Japan, 14% other
(1985)
Budget: public sector—revenues, 92,529
million cruzados; current expenditures,
75,541 million cruzados; capital expendi-
tures, 35,070 million cruzados (1984)
Monetary conversion rate: 14.11
cruzados=US$1 (November 1986)
Fiscal year: calendar year
Electric power: provided by US military
GDP: $77.1 million (1983)
Agriculture: limited—livestock (including
poultry), fish, fruit, and vegetables
Fishing: 293 metric tons fish, 25 metric
tons crustaceans (1975)
Major industries: tourism (over 45%),
construction, rum, concrete block
Electric power: 7,500 kW capacity; 33
million kWh produced, 2,750 kWh per
capita (1986)
Exports: $2.0 million (1981); fresh fish,
gravel, sand, fruits, and vegetables
Imports: $49.8 million (1981); building
materials, automobiles, foodstuffs, machin-
ery
Major trade partners: mostly with neigh-
boring US Virgin Islands
Budget: revenues, $19.79 million; expendi-
tures, $19.0 million (1984 est.)
Monetary conversion rate: official cur-
rency is the US dollar
Fiscal year: 1 April-31 March
GDP: $3.422 billion, $14,750 per capita
(1985)
Natural resources: oil, natura! gas
Agriculture: rice, pepper; imports most
food
Major industry: crude petroleum, lique-
fied natural gas, construction
Electric power: 163,000 kW capacity; 470
million kWh produced, 2,000 kWh per
capita (1986)
Exports: $3.1 billion (1985); 98-99% crude
oil, liquefied natural gas, and petroleum
products
Imports: $640 million (1985); includes
machinery and transport equipment,
manufactured goods, food, beverages,
tobacco, and other; most consumer goods
imported
Major trade partners: exports—{erude
petroleum and liquefied natural gas)
roughly two-thirds to Japan; imports—
Singapore 24%, Japan 20%, US 16% (1985)
Budget: revenues, $2,109 million; expendi-
tures, $1,219 million; surplus $890 million
(1985)
Monetary conversion rate: 2.16 Brunei
dollars=US$1 (March 1986) inflation under
2.0% (1985/86)
Fiscal year: calendar year','d85c4e6f274fe0898091ad457ed08a7966734cbfa55bb33a2dd5baf4026250b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ed23fcb33faafe6a0e18e4fbc4db8101caca8e6fab9d34c10e828ac94504e1c',1987,'BG','Bulgaria','economy',119,'GNP: $57.8 billion, $6,460 per capita; real
growth rate, — 0.8% (1985)
Natural resources: bauxite, copper, lead,
zinc, coal, lignite, lumber
Agriculture: mainly self-sufficient; main
crops—grain, tobacco, fruits, vegetables,
sheep, hogs, poultry, cheese, sunflower
seeds
Fishing: catch 121,000 metric tons (1983)
Major industries: food processing, ma-
chine and metal building, electronics,
chemicals
Shortages: some raw materials; scattered
energy and food shortages in 1985
Crude steel: 2.9 million metric tons pro-
duced (1985), 324 kg per capita
Electric power: 11,298,000 kW capacity;
45,000 million kWh produced, 4,956 kWh
per capita (1986)
Exports: $ 13.8 billion (f.o.b., 1986 est.);
54% machinery and equipment; 19%
agricultural products; 10% fuels, mineral
raw materials, and metals; 10% manufac-
tured consumer goods; 7% other
Imports: $14.1 billion (f.0.b., 1986 est.);
47% fuels and minerals, 33% machinery
and equipment, 5% chemicals, 4% manu-
factured consumer goods, 11% other (1982)
35
Major trade partners: 56% USSR, 19%
other Communist countries, 25% non-
Communist countries
Monetary conversion rate: 0.95
leva=US$1 (July 1986)
Fiscal year: calendar year
GDP: $1.1 billion, $170 per capita; real
growth, - 1.3% (1983)
Natural resources: manganese, limestone,
marble, gold, antimony, copper, nickel,
bauxite, lead, phosphates
Agriculture: cash crops—peanuts, shea
nuts, sesame, cotton; food crops—sorghum,
millet, corn, rice; livestock; food deficiency
Fishing: catch 7,000 metric tons (1983 est.)
Major industries: agricultural processing
plants, brewery, bottling, and brick plants;
a few other light industries
Electric power: 73,000 kW capacity; 159
million kWh produced, 22 kWh per capita
(1986)
Exports: $110 million (f.o.b., 1983); live-
stock (on the hoof), peanuts, shea nut
products, cotton, sesame
Imports: $230 million (f.0.b., 1983); tex-
tiles, food, and other consumer goods,
transport equipment, machinery, fuels
Major trade partners; lvory Coast and
Ghana; overseas trade mainly with France
and other EC countries; preferential tariff
to EC and franc zone countries
Aid: Western (non-US) countries, ODA
and OOF (1970-84), $1.8 billion; US autho-
rized, including Ex-Im (FY70-85), $223
million; Communist countries (1970-85),
$64 million
Budget: revenues, $220 million; current
expenditures, $148 million; development
expenditures, $16] million (1983)
Monetary conversion rate: about 331.24
Communauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year
GDP: $7.05 billion (in current prices),
$190 per capita; real growth rate 6.2%; 7%
inflation rate (FY85/86)
Natural resources: oil, timber, tin, copper,
tungsten, lead, asbestos, some marble,
limestone, precious stones; possibly chro-
mium, gypsum
Agriculture: accounts for 64% of total
employment and about 27% of GDP; main
crops—paddy, beans, pulses, maize, oil-
seeds, sugarcane, peanuts; almost 100%
self-sufficient; most rice grown in deltaic
land; an illegal producer of opium poppy
and cannabis for the international drug
trade
Fishing: catch 585,800 metric tons (1983)
Major industries: agricultural processing;
textiles and footwear; wood and wood
products; petroleum refining; mining of
copper, tin, tungsten, iron; construction
materials
Electric power: 826,000 kW capacity;
1,750 million kWh produced, 50 kWh per
capita (1986)
Exports: $317.27 million (f.0.b., FY85/86);
teak and hardwoods, rice, pulses and
beans, base metals, ores, marine products,
rubber
Imports: $602.32 million (f.0.b., FY85/86);
machinery and transportation equipment,
building materials, oil industry equipment
Major trade partners: exports—Singapore,
Western Enrope, China, UK, Japan; im-
ports—Japan, Western Europe, Singapore,
UK
Budget: revenues, $3,754 million; expendi-
tures, $4,381 million (FY85/86 est.)
Monetary conversion rate: 7.18
kyats=US$1 (November 1986)
Fiscal year: 1 April-31 March','1d5e6314e8ac0dd95f17f646b6afafc52e9d62c157bb4529fdba3b14550e1b75','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75b51494119d8840435b8868d7fbbade70569d725a60bb45bb2e24aee328e0b4',1987,'BI','Burundi','economy',124,'GDP: $963 million (1984 est.), $217 per
capita (1985); 3% real growth rate (1983)
Natural resources: nickel, uranium, rare
earth oxide, peat, cobalt, copper, platinum
(not yet exploited)
Agriculture: major cash crops—coffee,
cotton, tea; main food crops—manioc,
yams, peas, corn, sorghum, bananas, hari-
cot beans
Major industries: light consumer goods
such as blankets, shoes, soap; assembly of
imports; public works construction; food
processing
Electric power: 34,000 kW capacity; 44
million kWh produced, 9 kWh per capita
(1986)
Exports: $83.5 million (1984); coffee (87%),
tea, cotton, hides and skins
Imports: $158 million (1984); textiles,
foodstuffs, transport equipment, petroleum
products
Major trade partners: US, EC countries
Budget: revenues, $121.4 million; expendi-
tures, $146.4 million (1983)
Monetary conversion rate: 121.7 Burundi
francs=US$ 1 (November 1986)
Fiscal year: calendar year','41be5967767faa850ee6091bccdf14792728ecced6692c927047e3f06bf79cb9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af7fc77f3bada8dd6de8b81923ec80587c6e6d553ef4ed845a2556e9ebc4d6e',1987,'TH','Thailand','economy',129,'Natural resources: timber, gemstones,
some iron ore, manganese, phosphates,
hydroelectric power (potential)
Agriculture: mainly subsistence except for
rubber plantations; main crops—rice,
rubber, corn; food shortages—rice, meat,
vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing,
wood and wood products, rubber
Shortages: fossil fuels
Electric power: 125,000 kW capacity; 142
million kWh produced, 20 kWh per capita
(1986)
Exports: probably less than $10 million
(1983 est.); natural rubber, rice, pepper,
wood
Imports: probably less than $30 million
(1983); international food aid; Soviet bloc
economic development aid (post-1979)
Trade partners: Vietnam, USSR, Eastern
Europe, Japan, India
Aid: US (FY70-85), $715 million; other
Western (1970-84), $265 million
Military transfers: US (FY70-82), $1.2
billion
Monetary conversion rate; 4 riels=US$1
(1984)
Fiscal year: calendar year
Budget: revenues, $25.0 million; expendi-
tures, $43.00 million (at average 1985
official rate of 7.09 rufiyas=US$1) (1985
est.)
Monetary conversion rate: 7.24 Maldivian
rufiyas=US§1, official rate; 7.0 Maldivian
rufiyas=US$1, market rate (November
1986)
Fiscal year: calendar year
GNP: $37.2 billion (1985), $720 per capita;
4.0% real growth in 1985
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, fisheries prod-
ucts
Agriculture: main crops—rice, sugar, corn,
rubber, manioc; an illegal producer of
opium poppy and cannabis for the inter-
national drug trade
Fishing: catch 2.2 million metric tons
(1984); major fishery export, shrimp,
24,041 metric tons, about $126 million
(1985)
Major industries: textiles and garments,
agricultural processing, beverages, tobacco,
cement, other light manufacturing; tin and
tungsten ore mining; world’s second largest
tungsten producer and third largest tin
producer
Shortages: fuel sources, including coal and
petroleum; scrap iron; and fertilizer
Electric power: 6,400,000 kW capacity;
24,060 million kWh produced, 460 kWh
per capita (1986)
Exports: $7.1 billion (f.0.b., 1985); textiles
and garments, rice, tapioca, rubber, inte-
grated circuits, corn, gems, sugar, tin,
canned and frozen seafood, fruit
Imports: $9.2 billion (c.i.f., 1985); machin-
ery and transport equipment, fuels and
lubricants, base metals, chemicals, and
fertilizer
Major trade partners: exports—US, Japan,
the Netherlands, Singapore, Malaysia,
Hong Kong; imports—Japan, US, Saudi
Arabia, Singapore, Malaysia, FRG; about
1% or less trade with Communist countries
Budget: (FY85) estimate of expenditures,
$7.8 billion; revenues $6.0 billion; deficit
$1.8 billion
Monetary conversion rate: 26.27
baht=US$1 (November 1986)
Fiscal year: 1 October-30 September','570040d754cd16099c13165706a4d9eb3786685c72ece3379a1fc85acc157568','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b3e913b2e78259121a9f02a5c91d1a9e8c5897c1bd6360e03ea14b570d1dcc',1987,'CM','Cameroon','economy',134,'GDP: $7.3 billion (1983-84), about $770
per capita; average annual growth rate
6.5% (1984); average inflation rate 15%
(1984)
Natural resources: oil, natural gas, baux-
ite, iron ore, timber
Agriculture: commercial and food crops—
coffee, cocoa, timber, cotton, rubber,
bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet,
sorghum, and rice
Fishing: 75,000 metric tons (1984)
Major industries: crude oil production,
small aluminum plant, food processing,
light consumer goods industries; sawmills
Electric power: 604,000 kW capacity;
4,200 million kWh produced, 2,540 kWh
per capita (1986)
Exports: $855.2 million (f.o.b., 1984);
crude oil, cocoa, coffee, timber, aluminum,
cotton, natural rubber, bananas, peanuts,
tobacco, tea, mineral products, food,
alcohol, metal and metal products, textiles,
wood products
Imports: $1.101 billion (f.o.b., 1984);
consumer goods, machinery, transport
equipment, alumina for refining, petro-
leum products, food, beverages, electrical
equipment, chemical products
Major trade partners: most trade with
France, other EC countries, and the US
Budget: revenues, $1.6 billion; current
expenditures, $2.3 billion (1986-87 pro-
jected)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine
francs=US$1 (November 1986)
Fiscal year: | July-30 June','04a2a16d199253114da4f74afc8eaff1d63c35877958030c1d6e645e5e1d6718','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36c83fa529a1f9f51372cd7de1bcba0ab79cb6b9a64daff538db6e3d517435d',1987,'CA','Canada','economy',139,'GDP: $366.0 billion, $14,280 per capita;
61.4% consumption, 19.7% investment,
17.2% government, 0.8% net foreign trade;
no change in inventories (1986); real
growth rate 3.0% (1985-86); inflation rate
4.2% (1986)
Natural resources: nickel, zinc, copper,
gold, lead, molybdenum, potash, silver,
fish, forests, wildlife
Agriculture: livestock, grains (principally
wheat), dairy products, feedgrains, oil-
seeds, tobacco; food shortages—fresh fruits
and vegetables
Fishing; catch 1.25 million metric tons
(1984)
Major industries: processed and unproc-
essed minerals, food products, wood and
paper products, transportation equipment,
chemicals, fish products, petroleum and
natural gas
Shortages: rubber, fruits, precision instru-
ments
Crude steel: 15.0 million metric tons
produced (1985); 590 kg per capita
43
Electric power: 99,298,000 kW capacity;
448,840 million kWh produced, 17,500
kWh per capita (1986)
Exports: $88.1 billion (f.0.b., 1985); princi-
pal items—transportation equipment;
wood and wood products, including paper;
ferrous and nonferrous ores; crude petro-
leum; wheat; Canada is a major food
exporter
Imports: $75.3 billion (f.0.b., 1985); princi-
pal items—transportation equipment,
machinery, crude petroleum, communica-
tion equipment, textiles, steel, fabricated
metals, office machines, fruits and vege-
tables
Major trade partners: imports—71.6% US,
5.9% Japan, 3.0% UK; exports—78.5% US,
4.9% Japan, 2.0% UK, 1.3% USSR (1985)
Aid: US, including Ex-Im Bank (FY70-84),
$1.9 billion; ODA and OOF economic aid
commitments (1970-84), $18.5 billion
Budget: total revenues $61.32 billion;
current expenditures $84.91 billion; budget
deficit $23.59 billion (1985)
Monetary conversion rate: C$1.873=US$1
(8 January 1987)
Fiseal year: 1 April-31 March
GNP: $110 million, $320 per capita (1983)
Natural resources: salt, basalt rock, pozzo-
lana, limestone, kaolin
Agriculture: main crops—bananas, coffee,
sugarcane, corn, beans
Fishing: catch 13,205 metric tons (1983);
largely undeveloped but provides major
source of export earnings
Major industries: salt mining
Electric power: 14,000 kW capacity; 18
million kWh produced, 56 kWh per capita
(1986)
Exports: $1.6 million (f.0.b., 1983); fish,
bananas, salt, flour
Imports: $68.1 million (c.i.f., 1983); petro-
leum products, corn, rice, machinery,
textiles
Major trade partners: Portugal, UK,
Japan, Angola, Zaire
Budget: public revenues, $20.4 million;
current expenditures, $26.7 million (1984)
Monetary conversion rate: 89.21
escudos=US$1 (December 1985)
Fiscal year: calendar year','4c21b80ee3431fd4629005ca8d6a8714a1aacf2f52c7b1773b0f54059b937b91','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f8edf163b61c0da15229607fcaec54f830a3503e5cacb50198cf056fff50bc0',1987,'KY','Cayman Islands','economy',144,'GDP: $225.0 million, $10,227 per capita
(1982)
Agriculture: minor production of vegeta-
bles and livestock, turtle farming
Major industries: tourism, banking, insur-
ance and finance, real estate and construc-
tion
Electric power: 29,000 kW capacity; 90
million kWh produced, 4,090 kWh per
capita (1986)
Cayman Islands (continued)
Exports: $2.4 million (1983); turtle prod-
ucts
Imports: $140.4 million (1983)
Major trade partners: exports—mostly
US; imports—US, Trinidad and Tobago,
UK, Netherlands Antilles
Budget: current revenues, $41.6 million;
current expenditures, $31 million (1983)
Monetary conversion rate: .833 Cayman
dollar=US$1 (1985)
Fiscal year: 1 April-31 March','252d9f9cd9c6156b416b961050de968269e0f982326fe69a657aaa527ee23aff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b052102b70eb76af9512e88edeeafddc04a20aedae71eaeca309c173fa481078',1987,'CF','Central African Republic','economy',149,'GDP: $764 million, $300 per capita,
—8.7% real growth; 4% inflation rate
(1984)
Natural resources: diamonds, uranium,
timber, gold, oil
Agriculture: commercial—cotton, coffee,
peanuts, sesame, tobacco, timber; main
food crops manioc, corn, millet, sorghum,
peanuts, rice, potatoes; livestock
Major industries: sawmills, breweries,
diamond mining, textiles, soap, footwear
Electric power: 35,000 kW capacity; 61
million kWh produced, 22 kWh per capita
(1986)
Exports: $145.2 million (f.0.b., 1984);
diamonds, cotton, coffee, timber, tobacco
Imports: $139.6 million (f.0.b., 1984 est.);
textiles, petroleum products, machinery,
electrical equipment, motor vehicles,
chemicals, pharmaceuticals
Major trade partners: exports—France,
Belgium, Japan, US; imports—France and
other EC countries, Japan, Algeria, Yugo-
slavia
Budget: (1984) revenues $93.3 million;
current expenditures $90.8 million; official
foreign debt $223 million (1984)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year','542456a7d7b630b9aa48acf73cd5d83320cc6960b56868b69707ac926129a685','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04251575d8e0cab41801d980716ff117cbef2388ea2ab8ef08989d8fd04bb1cc',1987,'TD','Chad','economy',154,'During the last decade droughts and
plagues of locusts have caused widespread
food shortages, and years of civil war have
devastated the economy.
GDP: $405.7 million, $90 per capita (1985
est.); real annual growth rate —2.8%
(1960-82 est.)
Natural resources: petroleum (unexploited
but exploration beginning), uranium,
natron, kaolin
Agriculture: commercial—cotton, gum
arabic, livestock, peanuts, fish; food
crops—millet, sorghum, rice, sweet pota-
toes, yams, cassava, dates; imports food
Fishing: catch 110,000 metric tons (1983
est.)
Major industries: agricultural and live-
stock processing plants (cotton textile mills,
slaughterhouses, brewery), natron
Electric power: 38,000 kW capacity; 66
million kWh produced, 12 kWh per capita
(1986)
Exports: $113.15 million (f.0.b., 1984);
cotton (80%), meat, fish, animal products
Imports: $114.38 million (f.0.b., 1984);
cement, petroleum, flour, sugar, tea, ma-
chinery, textiles, motor vehicles
48
Major trade partners: France and Central
African Customs and Economic Union
countries
Budget: total revenues, $57.4 million; total
expenditures $76.5 million (1986 est.)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year','18603e60740b0c429328ba8d00333ce6ca55b3b44134f03491587baed977889e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07a9f5046c4cc7794d8489705c5363996e819b686d7f59ae7177364c80af996d',1987,'CL','Chile','economy',159,'GDP; $16.1 billion, $1,330 per capita;
51.6% private consumption, 26.9% govern-
ment consumption; 13.7% gross invest-
ment; real growth rate 2.4% (1985)
Natural resources: copper, timber, iron
ore, nitrates, precious metals, molybdenum
Agriculture: main crops—wheat, potatoes,
corn, sugar beets, onions, beans, fruits; net
agricultural importer
Fishing: catch 4 million metric tons
(1983); exports $275.5 million (1984)
Major industries: copper, other minerals,
foodstuffs, fish processing, iron and steel,
pulp, paper, and forestry products
Crude steel: 765,000 metric tons capacity
(1980), 684,000 metric tons produced
(1985), 55 ke per capita
Electric power: 3,315,000 kW capacity;
13,950 million kWh produced, 1,100 kWh
per capita (1986)
Exports: $3.7 billion (f.0.b., 1985); copper,
molybdenum, iron ore, paper products,
steel products, fishmeal, fruits, wood
products
Imports: $3.0 billion (f.0.b., 1985); petro-
leum, sugar, wheat, capital goods, vehicles
Major trade partners: exports—26% US,
11% Japan, 10% FRG, 6.2% Brazil, 5.4%
UK (1984); imports—21.5% US, 9% Japan,
8.5% Brazil, 7.2% Venezuela, 6.2% FRG
(1983)
Budget: revenues, $4.6 billion; expendi-
tures, $5.1 billion (1985)
Monetary conversion rate: 202
pesos=US$1 (December 1986)
Fiscal year: calendar year','9a68e57d52520c1955ef43c0c3fe19d675e343ba7786e4d26c2b41dbdee3a5fc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a2c1ca7afb0fdfd2500afe8edd4193c3cf2c8f9f4de457d5f9c3eadc3871f72',1987,'CN','China','economy',164,'GNP: $262 billion, $250 per capita (1986
est.)
Natural resources: coal, iron, petroleum,
mercury, tin, tungsten, antimony, manga-
nese, molybdenum, vanadium, magnetite,
aluminum, lead, zinc, uranium, hydroelec-
tric power (world’s largest potential)
51
Agriculture: main crops—rice, wheat,
other grains, oilseed, cotton; agriculture
mainly subsistence; grain imports 5.4
million metric tons; grain exports (mostly
corn) 9 million metric tons (1985)
Major industries: iron, steel, coal, ma-
chine building, armaments, textiles, petro-
leum
Shortages: complex machinery and equip-
ment, highly skilled scientists and techni-
cians, energy, and transport
Crude steel: 46.6 million metric tons
produced, 45 kg per capita (1985)
Electric power: 91,300,000 kW capacity;
430,000 million kWh produced, 410 kWh
per capita (1986)
Exports: $31.3 billion (f.0.b., 1985); manu-
factured goods, agricultural products, oil,
minerals
Imports: $39.5 billion (f.0.b., 1985); grain,
chemical fertilizer, steel, industrial raw
materials, machinery, equipment
Major trade partners: Japan, Hong Kong,
US, FRG, Singapore, USSR, Italy, Brazil
(1985)
Monetary conversion rate: 3.7] renminbi
yuan=US$1 (October 1986)
Fiscal year: calendar year
GNP: $1,979 billion (at 167.1 yen=US$1);
$16,290 per capita; 58% personal con-
sumption, 28% investment, 10% govern-
ment current expenditure, negligible
stocks, and 4% foreign balance; real
growth rate 2.1% (1986); average annual
growth rate 3.6% (1981-86)
Natural resources: negligible mineral
resources, fish
Agriculture: land intensively cultivated;
rice, sugar, vegetables, fruits; 64% self-
sufficient in food (1984); food shortages—
wheat, corn, beans
Fishing: catch 12.2 million metric tons
(1985)
127
Major industries: metallurgical and engi-
neering industries, electrical and electronic
industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw
materials
Crude steel: 105.3 million metric tons
produced (1985), 870 kg per capita
Electric power: 181,000,000 kW capacity;
665,000 billion kWh produced, 5,500 kWh
per capita (1986)
Exports: $175.6 billion (f.0.b., 1985); 97%
manufactures (including 30% machinery,
25% motor vehicles, 8% consumer elec-
tronics
Imports: $129.5 billion (c.i.f., 1985); 44%
fossil fuels, 25% manufactures, 14% food-
stuffs, 16% non-fuel raw materials
Major trade partners: exports—37% US,
19% Southeast Asia, 14% Western Europe,
7% Middle East, 9% Communist countries;
imports—23% Middle East, 23% Southeast
Asia, 20% US, 10% Western Europe, 7%
Communist countries
Aid: donor—ODA and OOF economic
commitments (1970-84), $36.6 billion
Budget: revenues, $243 billion; expendi-
tures, $332 billion; deficit, $89 billion
(general account for fiscal year ending
March 1987 converted at 162.0 yen=US$1)
Monetary conversion rate: 162.0
yen=US$1 (17 December 1986)
Fiscal year: 1 April-31 March
Budget: revenues, $154 million; expendi-
tures and net lending, $169 million (1982)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year','0a1d2ba1a0f2f2fc440599904a8f15748c9ab0ce1cbe3d9b89ae33d2c336c783','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('416e165629dc534c0ca8f5baa48f01042a89b90edec839c6678c7c37b16a880c',1987,'CX','Christmas Island','economy',169,'National resources: phosphates
Major industries: phosphate extraction
(near depletion)
Electric power: 11,000 kW capacity; 38
million kWh produced, 12,670 kWh per
capita (1986)
Exports: about 1.2 million metric tons of
phosphate exported to Australia, New
Zealand, and some Asian nations
Major trade partners: Australia, New
Zealand
Monetary conversion rate: 1.55 Australian
dollars=US$1 (November 1986)
Fiscal year: ] July-80 June','732f4413939384c433c583398915d6da760ac933849f1157d5fc66bd2771f9a4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eae67a0a8d5fabb20b3c0ba688b317568c1d94711b9ada6a15b283acbeb052c',1987,'CO','Colombia','economy',174,'GNP: $31 billion; $1,129 per capita (1986
est.); 73% private consumption, 19% gross
investment, 11% public consumption
(1984); growth rate 5% (1986); 21.0%
inflation rate (1986)
Natural resources: petroleum, natural
gas, coal, iron ore, nickel, gold, copper,
emeralds
Colombia (continued)
Agriculture: main crops—coffee, rice,
corn, sugarcane, plantains, bananas, cotton,
tobacco; an illegal producer of coca and
cannabis for the international drug trade
Fishing: catch 75,351 metric tons (1984)
Major industries: textiles, food processing,
clothing and footwear, beverages, chemi-
cals, metal products, cement; mining—
gold, coal, emeraJds, iron, nickel, silver,
salt
Crude steel: 498,600 metric tons produced
(1984), 18 kg per capita
Electric power: 8,488,000 kW capacity;
29,580 million kWh produced, 990 kWh
per capita (1986)
Exports: $3.6 billion (f.0.b., 1985); coffee,
coal, fuel oil, cotton, tobacco, sugar, tex-
tiles, cattle and hides, bananas, fresh cut
flowers
Imports: $4.1 billion (c.i.f., 1985); trans-
portation equipment, machinery, industrial
metals and raw materials, chemicals and
pharmaceuticals, fuels, fertilizers, paper
and paper products, foodstuffs, beverages
Major trade partners: exports—40% US,
14% FRG, 4% UK, 4% Netherlands, 4%
Japan, 3% Italy; imports—33% US, 11%
Japan, 8% Venezuela, 7% FRG, 4%
France, 3% Canada, 3% UK, 3% Spain, 3%
Brazil, 3% Italy (1985)
Budget: revenues, $5.1 billion; expendi-
tures, $5.6 billion (1987 est.)
Monetary conversion rate: 212.56
pesos=US$1 (November 1986)
Fiscal year: calendar year','43ea594a22788a3baf67c2ef5fe1cc5e3285cbfdd701649825ac0d5477812012','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0a85606ef4a09e209b62c635d602a2a813cc9ee2f33e795c695984c6bb3e3ed',1987,'YT','Mayotte','economy',180,'GNP: $114 million, about $290 per capita
(1985 est.)
Agriculture: food crops—rice, manioc,
maize, fruits, vegetables, coconuts, cinna-
mon, yams; export crops—essential oils for
perfumes (mainly ylang-ylang), vanilla,
copra, cloves
Major industry: perfume distillation
Electric power: 4,000 kW capacity; 5
million kWh produced, 1) kWh per capita
(1986)
Exports: $15 million (f.0.b., 1985 est.);
perfume oils, vanilla, copra, cloves
Imports: $25 million (f.0.b., 1985 est.); rice
and other foodstuffs, cement, fuels, chemi-
cals, textiles
Major trade partners: exports—France,
FRG, US; imports—France, Kenya, Re-
union
Budget: domestic revenues, $11 million;
external grants, $29 million; current ex-
penditures, $14 million; capital expendi-
tures, $7 million; extrabudgetary expendi-
tures, $44 million (1984)
Monetary conversion rate: 331 Commun-
auté Financiére Africaine (CFA)
francs=US$1 (September 1986)','0ecd8ba2d0365d0efff950bea28384657298f696ed15b9e593afd7dbd442c17e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f07ccaed77595dccd8d5bab69c07b2833d1fbe5132bb7726f45b00ed51eaaaf',1987,'CG','Congo','economy',185,'GDP: about $1.8 billion, $1,140 per capita;
real growth rate 2.5% per year (1984); 80%
of economy is private sector, predomi-
nantly French owned and operated
Natural resources: petroleum, wood,
potash, lead, zinc, uranium, phosphates,
natural gas
Agriculture: cash crops—sugarcane, wood,
coffee, cocoa beans, palm kernels, bananas,
peanuts, tobacco; food crops—root crops,
rice, corn, bananas, manioc, fish, goats,
chickens
Fishing: catch 31,000 metric tons (1983)
Major industries: crude oil, cement,
sawmills, brewery, sugar mill, palm oil,
soap, cigarettes
Electric power: 120,000 kW capacity; 262
million kWh produced, 140 kWh per
capita (1986)
Exports: $1.3 billion (f.0.b., 1984); oil
(90%), lumber, tobacco, veneer, plywood,
coffee, cocoa, sugar
Imports: $618 million (f.0.b., 1984); ma-
chinery, transport equipment, manufac-
tured consumer goods, iron and steel,
foodstuffs, chemical products,
Major trade partners: France, Italy, FRG,
US
Budget: revenues, $721 million; current
expenditures, $508 million; development
expenditures, $241 million (1984)
56
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year','3870f4061c6f1c1e4606bf4840ca9b0a763f9726b3008f88e33f38789e1fea95','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0118f4fc1d69dcfac60a9a4d4f8445488a5ffdd9cbfb8d537fe460d84b258ca',1987,'CK','Cook Islands','economy',190,'GDP: $21.0 million, $1,170 per capita
(1983)
Agriculture: export crops include copra,
citrus fruits, pineapples, tomatoes, and
bananas, with subsistence crops of yams
and taro
Major industry: fruit processing, tourism
Electric power: 4,750 kW capacity; 15
million kWh produced, 880 kWh per
capita (1986)
Exports: $4.20 million (1983); copra, fresh
and canned fruit
Imports: $24.36 million (1983); foodstuffs,
textiles, fuels
57
Major trade partners: (1970) exports—
98% New Zealand; imports—76% New
Zealand, 7% Japan
Aid: $9.34 million (1983) New Zealand,
Australia, and Western sources
Budget: $121 million (1977)
Monetary conversion rate: $1.94 New
Zealand=US$1 (November 1986)','c83f27fcd76431a003fc7f851460bec328f376464ea0c7d8242d4c143a3e9fac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0442b56ce4bf11095b85277e0248a5c223e4c479b591837bf2b3b510ee6ccbf7',1987,'CR','Costa Rica','economy',195,'GDP: $3.7 billion (1985 est.), $1,427 per
capita; 62% private consumption, 16%
public consumption, 23% gross domestic
investment, —1% net foreign balance; 2%
real growth rate (1986)
Natural resources: hydroelectric power
Agriculture: main products—coffee, ba-
nanas, sugarcane, rice, corn, cocoa, live-
stock products; an illegal producer of
cannabis for the international drug trade
Fishing: catch 10,902 metric tons (1982)
Major industries: food processing, textiles
and clothing, construction materials, fertil-
izer
Electric power: 820,000 kW capacity;
2,770 million kWh produced, 1,020 kWh
per capita (1986)
Exports: $994 million (f.0.b., 1985); coffee,
bananas, beef, sugar, cocoa
Imports: $1,126 million (c.i.f., 1985);
manufactured products, machinery, trans-
portation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade partners: exports—47% US,
18% CACM, 9% FRG; imports—40% US,
12% Japan, 11% CACM, 4% FRG (1983)
Aid: bilateral commitments—US autho-
rized (FY70-85), including Ex-Im, $823
million, other Western countries ODA and
OOF (1970-85), $401 million, Communist
countries (1971-85), $27 million
Military transfers: US (FY70-85), $32
million
Budget: consolidated public sector—total
revenues, $1,009 million; total expendi-
tures, including debt amortization, $1,058
million (1983)
Monetary conversion rate: 58
colones=US$1 (November 1986)
Fiscal year: calendar year','43d9d22f727d8ed160e857a15e1d6106ef46b59b0ee44de3217de57212fa9167','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('335cb055bbc35a28454b7730a2bcdce743ecc395c8b51b8003ccef7b974ad190',1987,'CU','Cuba','economy',200,'GNP; $18.0 billion in 1974 dollars; $1,757
per capita in 1974 dollars; real growth rate
2.3% (1986 est.)
Natural resources: cobalt, nickel, iron,
copper, manganese, salt, forests
Agriculture: sugar, tobacco, rice, potatoes,
tubers, citrus, coffee
Fishing: catch 198,400 metric tons (1984);
exports $102 million (1984 est.)
Major industries: sugar milling, petroleum
refining, food and tobacco processing,
textiles, chemicals, paper and wood prod-
ucts, metals, cement
Shortages: spare parts for transportation —
and industrial machinery, consumer goods
Crude steel: 412,900 metric tons produced
(1985); 40 kg per capita
Electric power: 3,461,000 kW capacity;
14,030 million kWh produced, 1,370 kWh
per capita (1986)
Exports: $6.5 billion (f.0.b., 1985); sugar,
nickel, shellfish, tobacco, coffee, citrus
Imports: $8.6 billion (c.i.f., 1985); capital
goods, industrial raw materials, food,
petroleum
Major trade partners: exports—72%
USSR, 17% other Communist countries;
imports—66% USSR, 18% other Commu-
nist countries (1984)
Budget: $15.1 billion (1986 est.)
Monetary conversion rate: 0.93
peso=US$1 (December 1986 official)
Fiscal year: calendar year','7d1c3e0eab9e6139cfaf86b7ea18231e9cfcbec4e52a6fea2bd2cd64bfcd3be0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b4ebbc77f0df3a46d4a7d0c35e26be6f4e105992c5efe1b1d2a9b6d8894f1ea',1987,'CY','Cyprus','economy',205,'GDP: $2.4 billion (1984), $3,609 per cap-
ita; real growth rate 1.3% (1984 est.):
Turkish sector—$205.9 million, $1,344 per
capita (1983)
Natural resources: copper, pyrites, asbes-
tos, gypsum, lumber, salt, marble, clay
earth pigment
Agriculture: potatoes and other vegetables,
grapes, citrus, wheat, carob beans, olives
Major industries: mining (iron pyrites,
gypsum, asbestos), manufactures princi-
pally for local consumption—beverages,
footwear, clothing, cement
Electric power: 620,000 kW capacity;
1,520 million kWh produced, 2,260 kWh
per capita (1986)
Exports: $561.2 million (f.0.b., 1985);
principal items—food and beverages,
including citrus, raisins, potatoes, wine;
also cement and clothing; Turkish sector—
$48.8 million (f.o.b., 1984); principal
items—citrus, potatoes, metal pipes, py-
rites
Imports: $1,469.7 million (c.i.f., 1985);
principal items manufactured goods,
machinery and transport equipment, fuels,
food; Turkish sector—$170 million (c.i.f.,
1984); principal items—foodstuffs, raw
materials, fuels, machinery
Major trade partners: imports (1984)—
12.1% UK, 12% Japan, 10.5% Italy, 8.3%
FRG, 5.2% lraq; exports (1984)—17% UK,
14.1% Lebanon, 11.4% Libya, 7.5% Saudi
Arabia, 3.4% USSR; Turkish sector—
imports (1984)—46% Turkey, 36% EC,
17% Arab countries; exports (1984)—61%
EC, 22% Turkey, 16% Arab countries
Budget: revenues, $663.2 million; expendi-
tures, $804.9 million; deficit, $141.7 mil-
lion (1984); Turkish sector—revenues,
$46.3 million; expenditures, $110.9 million;
deficit, $64.6 million (1986)
Monetary conversion rate: .52 Cyprus
pound=US$1 (January 1987); Turkish
sector—755 Turkish liras=US$1 (January
1987)
Fiscal year: calendar year
GNP: $135.6 billion in 1985 (in 1985
dollars), $8,700 per capita; 1985 real
growth rate 1.6%
Natural resources: coal, coke, timber,
lignite, uranium, magnesite
Agriculture: diversified agriculture; main
crops—wheat, rye, oats, corn, barley,
potatoes, sugar beets, hogs, cattle, horses;
net food importer—meat, wheat, vegetable
oils, fresh fruits and vegetables
Major industries: iron and steel, machin-
ery and equipment, cement, sheet glass,
motor vehicles, armaments, chemicals,
ceramics, wood, paper products
Shortages: ores, crude oil
Crude steel: 15.0 million metric tons
produced (1985), 965 kg per capita
Electric power: 21,445,000 kW capacity;
83,000 million kWh produced, 5,260 kWh
per capita (1986)
Exports: $17.84 billion (f.0.b., 1985); 54.8%
machinery and equipment; 16.2% manu-
factured consumer goods; 14.2% fuels,
minerals, and metals; 6.7% agricultural
and forestry products, 8.1% other products
(1984 est.)
Imports: $17.94 billion (f.0.b., 1985);
41.1% fuels, minerals, and metals; 33.2%
machinery and equipment; 12.1% agricul-
tural and forestry products; 5.7% manufac-
tured consumer goods; 7.9% other products
(1984)
63
Major trade partners: USSR, GDR, Po-
land, Hungary, FRG, Yugoslavia, Austria,
Bulgaria, Romania; 80% with Communist
countries, 20% with non-Communist
countries (1986)
Monetary conversion rate: 6.875
koronas=US$1 (1985 average)
Fiscal year: calendar year','6e8249741e01bea792a254a9acea39dd90ef5b6c825a5e308cf713f6694b358f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('955be6b4ce0bcc984853e254abaad0151142ea96c6727a24b6553df707e6f98e',1987,'DK','Denmark','economy',210,'GNP: $38.4 billion, $7,533 per capita;
56.3% private consumption, 20.0% private
investment, 26.4% government consump-
tion, investment; —3.7% net exports of
goods and services; 1% increase in stocks;
growth rate, 2.7% (1985)
Natural resources: oil, gas, fish
Agriculture: highly intensive, specializes in
dairying and animal husbandry; main
crops—cereals, root crops; food imports—
oilseed, grain, animal feedstuffs
Fishing: catch 1.67 million metric tons,
exports $842 million, imports $360 million
(1985)
Major industries: food processing, ma-
chinery and equipment, textiles and cloth-
ing, chemical products, electronics, con-
struction, furniture, and other wood prod-
ucts
Crude steel: 0.5 million metric tons pro-
duced (1985), 100 kg per capita
Electric power: 9,973,000 kW capacity;
28,290 million kWh produced, 5,550 kWh
per capita (1986)
Exports: $17.1 billion (f.0.b., 1985); princi-
pal items—meat, dairy products, industrial
machinery and equipment, textiles and
clothing, chemical products, transport
equipment, fish, furs, furniture
Imports: $18.2 billion (c.if., 1985); princi-
pal items—industrial machinery, transport
equipment, petroleum, textile fibers and
yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 1985 exports—
42.3% EC, 15.4% FRG, 12.2% Sweden,
12.0% UK, 10.1% US, 6.8% Norway
Aid: donor—ODA and OOF economic aid
commitments (1970-84) $3.6 billion
Budget: expenditures, $32.55 billion;
revenues, $32.56 billion (1986)
Monetary conversion rate: 7.64
kroner=US$1 (November 1986)
Fiscal year: calendar year','cf8776fb4a2df2b879d0bb34ebcd7af60fbfaf842e9d6f890e6c100c8562dc78','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654df19130948d91a699469c3feadc9bfee0aa02c5c96523d3e10c9adf2d77b3',1987,'DJ','Djibouti','economy',215,'GDP: $344 million; per capita income
$1,130 (1986 est.)
Natural resources: none
Agriculture: livestock; limited commercial
crops, including fruit and vegetables
Major industries: transit trade, port,
railway, services; live cattle and sheep
exports to Saudi Arabia; secondary services
to French military
Electric power: 80,000 kW capacity; 140
million kWh produced, 460 kWh per
capita (1986)
Exports: $96 million (f.0.b., 1986 est.);
hides and skins and transit of coffee; a
large portion consists of reexports to for-
eign residents of Djibouti
Imports: $197 million (f.0.b., 1986 est.);
almost all domestically needed goods—
foods, machinery, transport equipment
Budget: estimated in percent of GDP—
revenues 30.7%, grants 4.0%, expenditures
45.7% (1986)
Monetary conversion rate: 176.14
Djibouti francs=US$1 (average January-
September 1986)
Fiscal year: calendar year','5e955c2ccfe935826fa08a57d46c533f95bdcc70e9d780ec9a7a9dffdbc9e3cc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2170ac62832f69e04e8fbdb2677d95a5e42438b431603fc8be4ee6eaa2a05829',1987,'DM','Dominica','economy',220,'GDP: $85.4 million (1984 est.), $1,034 per
capita; real growth rate 1.2% (1986 est.)
Natural resources: timber
Agriculture: bananas, citrus, coconuts,
cocoa, essential oils
Major industries: agricultural processing,
tourism, soap and other coconut-based
products, cigars
Electric power: 7,000 kW capacity; 16
million kWh produced, 220 kWh per
capita (1986)
Exports: $28.7 million (f.o.b., 1985); ba-
nanas, coconuts, lime juice and oil, cocoa,
reexports
Imports: $57.0 million (f.0.b., 1985); ma-
chinery and equipment, foodstuffs, manu-
factured articles, cement
Major trade partners: (1984) exports—
46% UK, 16% Jamaica, 15% Trinidad and
Tobago, 2% US, 0.8% other EC; imports—
27% US, 13% UK, 8% Trinidad and To-
bago, 6% other EC
Aid: bilateral ODA and OOF (1970-80),
from Western (non-US) countries, $22.6
million
Budget: revenues, $33.4 million; expendi-
tures, $38.5 million (FY84)
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (November 1986)
Fiscal year: 1 July-30 June','76c0da556f48072cb08cd8e2e02c1d1f56e1367b253a17dd4abe1279940605a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6accae67ec1b6b7a79a74a0392f4134affde0fec061ac852d67c89624ff0230',1987,'DO','Dominican Republic','economy',225,'GDP: $14.9 billion, $858 per capita; real
GDP growth 2.0% (1986 est.)
Natural resources: nickel, bauxite, gold,
silver
Agriculture: sugarcane, coffee, cocoa,
tobacco, rice, corn
Major industries: tourism, sugar process-
ing, nickel mining, gold mining, textiles,
cement
Electric power: 1,332,000 kW capacity;
8,800 million kWh produced, 560 kWh
per capita (1986)
Exports: $735 million (f.0.b., 1985); sugar,
nickel, coffee, tobacco, cocoa, gold, silver
Imports: $1.5 billion (c.i.f., 1985); food-
stuffs, petroleum, industrial raw materials,
capital equipment
Major trade partners: exports—77% US,
including Puerto Rico (1984 est.); im-
ports—45% US, including Puerto Rico
(1980)
Aid: US economic commitments, including
Ex-Im (FY70-85), from US, $868 million;
ODA and OOF from other Western coun-
tries (1970-84), $330 million
Military transfers: US (1970-85), $48
million
Budget: revenues, $828 million; expendi-
tures, $750 million (1985 est.)
Monetary conversion rate: 3.05
pesos=US$1 (November 1986)
Fiscal year: calendar year
68','d4f10af6ab8020c69aee3f5ffa97a61d88088b277a0d560caea0519677f2fd8f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ede55d41486776826c58bbf53b1a898654efe98705f3bf7ae58bf99bd895709e',1987,'EC','Ecuador','economy',230,'GNP: $10.7 billion (1985), $1,140 per
capita; 66% private consumption, 21%
gross investment, 12% public consumption,
27% foreign (1984); real growth rate 3.2%
(1985); inflation rate 24.5% (1986)
Natural resources: petroleum, fish, timber
Ecuador (continued)
Agriculture: main crops—bananas, coffee,
cocoa, sugarcane, corn, potatoes, rice; an
illegal producer of coca for the interna-
tional drug trade
Fishing: catch 307,300 metric tons (1983);
shrimp production 36,230 metric tons
(1985); exports $260 million (1985), imports
negligible
Major industries: food processing, textiles,
chemicals, fishing, petroleum
Electric power: 1,791,000 kW capacity;
4,540 million kWh produced, 470 kWh
per capita (1986)
Exports: $2.1 billion (f.0.b., 1986); petro-
leum, shrimp, fish products, coffee, ba-
nanas, cocoa
Imports: $1.7 billion (f.0.b., 1986); agricul-
tural and industrial machinery, industrial
raw materials, building supplies, chemical
products, transportation and communica-
tion equipment
Major trade partners: exports—54% US,
10% Latin America and Caribbean, 4%
EC, 2% Japan; imports—33% US, 16%
Latin America and Caribbean, 23% EC,
12% Japan (1985)
Aid: Western (non-US) ODA and OOF
commitments (1970-84), $721 million; US
economic (FY70-85), $330 million; Com-
munist countries (1970-85), $64 million
Military transfers: US (FY70-85) $71
million
Budget: revenues, $1,718 million; expendi-
tures, $1,876 million (1987)
Monetary conversion rate: 146
sucres=US$1 (1 January 1987)
Fiscal year: calendar year','366697c557d95dda63fb83caf7aa5994779bde61e2bf5ad47cd20cf80c9a9ebb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('681c1e26aec08a01dc4ac00dcfd7d3ae525917d2af951187d66d5e88a80123fd',1987,'EG','Egypt','economy',235,'GDP: $21.2 billion, $430 per capita; 3.5%
real growth (1985)
Natural resources: petroleum, natural gas,
iron ore, phosphates, manganese, lime-
stone, gypsum, talc, asbestos, lead, zinc
7)
Agriculture: main cash crop—cotton; other
crops—rice, onions, beans, citrus fruit,
wheat, corn, barley; not self-sufficient in
food
Major industries: textiles, food processing,
chemicals, petroleum, construction, cement
Electric power: 8,427,000 kW capacity;
40,600 million kWh produced, 800 kWh
per capita (1986)
Exports: $3.2 billion (f.0.b., 1985/86 est.);
crude petroleum, raw cotton, cotton yarn,
fabric
Imports: $9.0 billion (c.i.f., 1985/86 est.);
foodstuffs, machinery and equipment,
fertilizers, woods
Major trade partners: US, EC countries
Monetary conversion rate; official rate
0.70 Egyptian pound=US$1; commercial
bank rate 1.35 Egyptian pounds=US$1,
free market rate 1.95 Egyptian
pounds=US$1 (December 1986)
Fiseal year: 1 July-30 June
Communicalions
Railroads: 4,857 km total; 951 km double
track; 25 km electrified; 4,510 km 1,435-
meter standard gauge, 347 km 0.750-meter
gauge
Highways: 28,500 km total; 15,000 km
surfaced, 13,500 km unsurfaced
Inland waterways: 3,360 km (including
the Nile River, Lake Nasser, Alexandria-
Cairo Waterway, the Ismailia Canal, and
numerous smaller canals in the Delta);
Suez Canal, 162 km long, used by ocean-
going vessels drawing up to 16.1 meters of
water
Freight carried: Suez Canal—257.6 mil-
lion metric tons, of which 94 million
metric tons were petroleums, oils, and
lubricants (1985)
Pipelines: crude oil, 1,107 km; refined
products, 596 km; natural gas, 460 km
Ports: 4 major (Alexandria, Port Said,
Suez, Bur Safajah); 15 minor; 9 petroleum,
oil, and lubricant terminals
Civil air: 42 major transport aircraft
Airfields: 102 total, 86 usable; 64 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 45 with runways
2,440-3,659 m, 22 with runways
1,220-2,439 m
Egypt (continued)
Telecommunications: system is large but
still inadequate for needs; principal centers
are Alexandria, Cairo, Al Mansdrah,
Ismailia, and Tanta; intercity connections
by coaxial cable and microwave; extensive
upgrading in progress; est. 600,000 tele-
phones (1.2 per 100 popl.); 25 AM, 5 FM,
47 TV stations; 1 Atlantic Ocean and 1
Indian Ocean INTELSAT station; 3 sub-
marine coaxial cables; tropospheric scatter
to Sudan; radio-relay to Libya
Defense Forces
Branches: Army, Navy, Air Force, Air
Defense Command
Military manpower: males 15-49,
12,203,000; 7,949,000 fit for military
service; 513,000 reach military age (20)
annually
Military budget: operating expenditures
for fiscal year ending 30 June 1985, $3.7
billion; 18% of central government budget
EI] Salvador
Boundary representation is
not neceasarily authoritative
Chalatenango
Santa Ana
SAN SALVADOR
eeoaas * San Vicente
North Pacific Ocean
See regional map IIL
GDP: $4.36 billion, $870 per capita (1985
est.)
Natural resources: hydroelectric and
geothermal power
Agriculture: coffee, cotton, corn, sugar,
beans, rice, sorghum, wheat
Fishing: catch 10,500 metric tons (1984
est.)
Major industries: food processing, textiles,
clothing, petroleum products
Electric power: 705,000 kW capacity;
1,710 billion kWh produced, 340 kWh per
capita (1986)
Exports: $772 million (f.0.b., 1985); coffee,
cotton, sugar, shrimp
Imports: $1,052 million (c.i-f., 1985);
machinery, intermediate goods, petroleum,
construction materials, fertilizers, food-
stuffs
73
Major trade partners: exports—33% US,
15% FRG, 12% Guatemala; imports—39%
US, 18% Guatemala, 9% Mexico
Aid: authorized from US, including Ex-Im
(FY70-85), $1.3 billion; ODA and OOF
commitments by other Western countries
(1970-84), $170 million
Military transfers: US (FY70-85), $548
million
Budget: government revenues, $502 mil-
lion; expenditures, $582 million (1983)
Monetary conversion rate: 5.0
colones=US$1 (November 1986)
Fiscal year: calendar year','daad8018358f22b847766a7b65cd1af5001017f532b24d65d1c20ebdeaf7de02','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93901fb5b57364fe3f316f7664f79acfb977e437d8cbb54cc987ee4e49564b88',1987,'GN','Guinea','economy',240,'GNP: $75 million, $420 per capita (1983);
economy destroyed during regime of
former President Masie Nguema
Natural resources: timber, petroleum
minerals, agriculture
74
Agriculture: major cash crops—Rio Muni,
timber, coffee; Bioko, cocoa; main food
products—rice, yams, cassava, bananas, oil
palm nuts, manioc, livestock
Major industries: fishing, sawmilling
Electric power: 10,000 kW capacity; 17
million kWh produced, 47 kWh per capita
(1986)
Exports: $16.9 million (1982 est.); cocoa,
coffee, wood
Imports: $41.5 million (1982 est.); food-
stuffs, chemicals and chemical products,
textiles
Major trade partner: Spain
Budget: receipts, $17.67 million; expendi-
tures $16.96 million (1985)
Monetary conversion rate: ekuele re-
placed by Communauté Financiére
Africaine (CFA) franc in 1985; 415 CFA
francs=US$1 (1986)
Fiscal year: calendar year
GNP: $1.6 billion (1984), $300 per capita;
real growth rate 1.3% (1984 est.)
Natural resources: bauxite, iron ore,
diamonds, gold, uranium, hydroelectric
power, fish
Agriculture: cash crops—coffee, bananas,
palm products, peanuts, citrus fruits,
pineapples; staple food crops—cassava,
rice, millet, corn, sweet potatoes; livestock
raised in some areas
Major industries: bauxite mining, alu-
mina, diamond mining, light manufactur-
ing and processing industries
Electric power: 108,000 kW capacity; 236
million kWh produced, 41 kWh per capita
(1986)
Exports: $537 million (f.0.b., 1984 est.);
bauxite, alumina, diamonds, coffee, pine-
apples, bananas, palm kernels
Imports: $403 million (f.0.b., 1984 est.);
petroleum products, metals, machinery
and transport equipment, foodstuffs, tex-
tiles
Major trade partners: imports—France,
USSR, US, Italy; exports—US, USSR, FRG,
France, Spain
Budget: public revenues, $444 million,
current expenditures, $330 million; devel-
opment expenditures, $104 million (1983)
Monetary conversion rate: 400 Guinean
francs=US$1 (December 1986)
Fiscal year: calendar year
GNP: $85 billion (1986 est.), about $510
per capita; real average annual growth,
8.6% (1981-85); real annual growth rate
0.0% (1986 est.)
Natural resources: oil, tin, natural gas,
nickel, timber, bauxite, copper
Agriculture: subsistence food production,
and smallholder and plantation production
for export; rice, cassava, peanuts, rubber,
cocoa, coffee, copra, other tropical prod-
ucts; an illegal producer of cannabis for
the international drug trade
Fishing: catch 2.2 million metric tons;
shrimp exports $194 million, imports $4
million (1984)
Major industries: petroleum, textiles,
mining, cement, chemical fertilizer pro-
duction, timber
Electric power: 10,800,000 kW capacity;
30,000 million kWh produced, 170 kWh
per capita (1986)
Exports: $18.6 billion (1986); petroleum
and liquefied natural gas, timber, rubber,
coffee, tin, animal and vegetable oils, tea,
copper
Imports: $10.3 billion (c.i.f., 1985); wheat
flour, wheat grains, and other cereals and
cereal products, textiles, chemical prod-
ucts, iron and steel products, machinery,
transport equipment
Major trade partners: (1984) exports—
47% Japan, 21% US, 9% Singapore; im-
ports—23% Japan, 18% US, 12%
Singapore, 11% Saudi Arabia, 4% FRG
Budget: receipts, $10.5 billion; expendi-
tures, $13.9 billion (1987/88)
Monetary conversion rate: 1,648
rupiahs=US$1 (November 1986)
Fiscal year: 1 April-31 March
GNP: $82.4 billion, $1,690 per capita, real
GNP —13.4% (1986)
Natural resources: petroleum, natural gas,
coal, chromium, copper, iron, lead, man-
ganese, zinc, barite, sulfur, coal, emeralds,
turquoise
Agriculture: wheat, barley, rice, sugar
beets, cotton, dates, raisins, tea, tobacco,
sheep, goats; an illegal producer of opium
poppy for the international drug trade
Major industries: crude oil production
(2.0 million b/d in 1986) and refining,
textiles, cement and other building materi-
als, food processing (particularly sugar
refining and vegetable oil production),
metal fabricating (steel and copper)
Electric power: 12,601,000 kW capacity;
33,120 million kWh produced, 710 kWh
per capita (1986)
Exports: $7.8 billion (1986 est.); 90%
petroleum; also carpets, fruits, nuts,
cement
Imports: $10.0 billion (1986 est.); machin-
ery, military supplies, foodstuffs, pharma-
ceuticals, technical services, refined oil
products
Major trade partners: exports—Japan,
Turkey, Syria, Italy, Netherlands, Spain,
France, FRG; imports—FRG, Japan,
Turkey, UK, Italy
Budget: proposed expenditures about $40
billion; actual expenditures were less as a
result of slump in oil market (FY86)
Monetary conversion rate: 73.36
rials=US$1 (December 1986); unofficial
exchange rate on black market up to ten
times as many rials per $1
Fiscal year: 21 March-20 March','3574e80aa4db3ae67948c2b0af2c941043a2d2f1a76b48340a20d5255d1ba7a9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9992ea264cb2f676d25833360eb535ea66f2a145c24b08c4fee1e4982490a106',1987,'ET','Ethiopia','economy',246,'GDP: $5.0 billion, $120 per capita
(1983/84 est.)
Natural resources: potash, salt, gold,
copper, platinum
Agriculture: main crop—coffee; also
cereals, pulses, oilseeds, meat, hides and
skins
Major industries: cement, sugar refining,
cotton textiles, food processing, oil refinery
Electric power: 330,000 kW capacity; 722
million kWh produced, 14 kWh per capita
(1986)
Exports: $520 million (f.0.b., 1985/86 est.);
75% coffee
Imports: $1,037 million (c.if., 1985/86)
Major trade partners: exports—US, FRG,
Djibouti, Japan, Saudi Arabia, France,
Italy; imports—USSR, Italy, FRG, Japan,
UK, US
Budget: as shares of GDP—revenues,
25.1%; expenditures, 31.8%; deficit, 6.7%
(1986)
Ethiopia (continued)
External debt: $1.7 billion, 1985; total
debt service as a share of exports of goods
and services 22% (1985)
Monetary conversion rate: 2.07 Ethiopian
birr=US$1 (November 1986)
Fiscal year: 8 July-7 July
Agriculture: predominantly sheep farming
Major industry: wool processing
Electric power: 3,500 kW capacity; 6
million kWh produced, 3,050 kWh per
capita (1986)
Exports: to UK, $21.9 million (1986); wool,
hides and skins, and other
Imports: from UK, $17.9 million (1986);
food, clothing, fuels, and machinery
Major trade partners: exports—nearly all
to the UK, some to the Netherlands and
Japan; imports—Curacao, Japan, and UK
Aid: (1970-79) Western (non-US) countries,
ODA and OOF, $24 million
Budget: revenues, $5 million; expendi-
tures, $4.8 million (1982)
Monetary conversion rate: 0.70 Falkland
Island pound=0.70 pound sterling=US$1
(November 1986)','e4ab1abe745564ea2623abd1a7fed7a2de16d736b2bf8c1a302a80c802be4237','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4a583ba5f482b60f84acf05cc3e662574f4c078e1e18601b391498d46b40525',1987,'FO','Faroe Islands','economy',251,'GDP: $369.3 million, about $8,800 per
capita (1980)
Natural resources: fish
Agriculture: sheep and cattle grazing
Fishing: catch 329,900 metric tons (1983);
exports, $162.3 million (1980)
Major industry: fishing
Electric power: 80,000 kW capacity; 225
million kWh produced, 4,890 kWh per
capita (1986)
Exports: $178.7 million (f.0.b., 1980);
mostly fish and fish products
Imports: $222.1 million (c.i.f., 1980);
machinery and transport equipment,
petroleum and petroleum products, food
products
Major trade partners: exports 21.3%
Denmark, 13.4% UK, 12.4% FRG, 11.7%
US (1980)
Budget: expenditures, $98.8 million; reve-
nues, $98.8 million (FY8])
Monetary conversion rate: 7.37 Danish
kroner=US$1 (December 1986)
Fiscal year: calendar year
GDP: $1.099 billion (1986 est.), $1,254 per
capita; annual growth rate, 2.5% (1986)
Natural resources: timber, fish, gold,
copper
Agriculture: sugar, copra, ginger, rice;
major, deficiency, grains
Major industries: sugar refining, tourism,
gold, lumber, small industries
Electric power: 213,000 kW capacity; 220
million kWh produced, 310 kWh per
capita (1986)
Exports: $240 million (f.o.b., 1985); 70%
sugar; also copra
Imports: $447 million (c.i.f., 1985); 24%
manufactured goods, 20.0% machinery,
16.3% foodstuffs, 16% fuels
Major trade partners: Australia, New
Zealand, Japan, UK, Singapore, US
Aid; Western (non-US) countries (1980-84),
$527 million
Budget: revenues, $323 million; expendi-
tures, $402 million (1986 est.)
Monetary conversion rate: 1.16 Fiji
dollars=US$1 (November 1986)
Fiscal year: calendar year','09c6f764364103b0d5adf9b004f3141dca472ad4cbeadec3ed55530deaedee63','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70aa0c134ecb9a666ddeaf1db01e8c0969729f5ac7b0997c29a9fbb57d2c227f',1987,'FI','Finland','economy',256,'GNP: $54.4 billion (1985), $11,100 per
capita; 55.6% private consumption, 23.4%
gross fixed capital formation; 20.2% gov-
ernment consumption; 0.8% net exports of
80
goods and services; 1985 growth rate 2.9%
(1980 prices)
Natural resources: forests, copper, zinc,
iron, farmland
Agriculture: animal husbandry, especially
dairying, predominates; forestry important
secondary occupation for rural population;
main crops—cereals, sugar beets, potatoes;
85% self-sufficient; shortages—food and
fodder grains
Fishing: catch 157,100 metric tons (1983)
Major industries: metal manufacturing
and shipbuilding, forestry and wood pro-
cessing (pulp, paper), copper refining,
foodstuffs, textiles, clothing
Shortages: fossil fuels; industrial raw
materials (except wood, iron ore)
Crude steel: 2.5 million metric tons pro-
duced (1985), 580 kg per capita
Electric power: 12,389,000 kW capacity;
45,590 million kWh produced, 9,250 kWh
per capita (1986)
Exports: $13.54 billion (f.0.b., 1985); tim-
ber, paper and pulp, ships, machinery,
clothing and footwear
Imports: $13.14 billion (c.i-f., 1985); food-
stuffs, petroleum and petroleum products,
chemicals, transport equipment, iron and
steel, machinery, textile yarn and fabrics
Major trade partners: (1985) exports—
35.2% EC (10.6% UK, 9.0% FRG), 21.4%
USSR, 13.1% Sweden, 6.2% US; imports—
86.9% EC (14.9% FRG, 7.2% UK), 20.6%
USSR, 11.7% Sweden, 5.4% US
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $998 million
Budget: expenditures, $16.3 billion; reve-
nues, $14.4 billion (1985)
Monetary conversion rate: 6.206 Finn-
marks (Fim)=US$I (830 December 1986)
Fiscal year: calendar year','7d9e168aba24ce126b5332f2b46130320266b379adb4f4e412f70f647d996645','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9882c790422135847d679551c4d464f432b681309267f0b0f216bd170349de7',1987,'FR','France','economy',261,'GNP: $510.3 billion (1985), $9,280 per
capita; 65% private consumption, 18.9%
investment (including government), 16.5%
government consumption; -0.4% net for-
eign balance; 1985 real growth rate, 1.2%;
average annual growth rate (1975-84),
2.1%
Natural resources: coal, iron cre, bauxite,
fish, forests
Agriculture: Western Europe''s foremost
producer; beef, dairy products, cereals,
sugar beets, potatoes, wine grapes; self-
sufficient for most temperate zone food-
stuffs; agricultural shortages include fats
and oils, tropical produce
Fishing: catch 721,809 metric tons; exports
of fish and fish products $363 million,
imports $1,014 million (1985)
Major industries: steel, machinery and
equipment, textiles and clothing, chemi-
cals, automobiles, food processing, metal-
lurgy, aircraft, electronics
Shortages: crude oil, natural gas, textile
fibers, most nonferrous ores, coking coal,
fats and oils
82
Crude steel: 23.0 million metric tons
capacity, 18.6 million metric tons pro-
duced (1985); 837 kg per capita
Electric power: 94,577,000 kW capacity;
348,620 million kWh produced, 6,310
kWh per capita (1986)
Exports: $100.9 billion (f.0.b., 1985); ma-
chinery and transportation equipment,
chemicals, foodstuffs, agricultural products,
iron and steel products, textiles and cloth-
ing
Imports: $107.3 billion (c.i.f., 1985); crude
petroleum, machinery and equipment,
agricultural products, chemicals, iron and
steel products
Major trade partners: (1985) imports—
51.8% EC, 9.7% petroleum exporting
countries, 11.2% other West European
countries, 7.6% US, 2.8% Japan, 2.3%
USSR, 2.0% other Communist countries;
exports—49.6% EC, 7.4% petroleum ex-
porting countries, 12.1% other West Euro-
pean countries, 8.6% US, 1.9% USSR, 2.5%
other Communist countries, 1.2% Japan
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $37.8 billion
Budget: revenues, $144.8 billion; expendi-
tures, $164.9 billion; deficit, $20.1 billion,
2.5% of GDP (1987 proposed)
Monetary conversion rate: 6.39 French
francs=US$1 (6 January 1987)
Fiscal year: calendar year
Monetary conversion rate: 6.62 French
francs=US$1 (November 1986)','70fd17d5a1b6e6de13f82198f0050e0bfa21537ace7c1fbb78d0df5e9d62807e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b160500f3ddbfb2c62f4cc5ea9fe071e0f0458904bd4760b1f0f5fa8f772216d',1987,'GF','French Guiana','economy',266,'GDP: $2.0 billion, $3,239 per capita (1981)
Natural resources: bauxite, timber, gold
(widely scattered), cinnabar, clay, low-
grade iron ore
Agriculture: limited vegetables for local
consumption; rice, corn, manioc, cocoa,
bananas, sugar
Fishing: catch 1,430 metric tons (1983 est.)
Major industries: construction, shrimp
processing, forestry products, rum, gold
mining
Electric power: 31,000 kW capacity; 156
million kWh produced, 1,770 kWh per
capita (1986)
Exports: $37.0 million (1982); shrimp,
timber, rum, rosewood essence
Imports: $276.0 million (1982); food
(grains, processed meat), other consumer
goods, producer goods, and petroleum
Major trade partners: exports—54% US,
17% Japan, 15% France, 5% Martinique;
imports—53% France, 15% Trinidad and
Tobago, 10% US (1981)
Aid: bilateral commitments, ODA and
OOF (FY70-79), from Western (non-US)
countries, $700 million
Budget: $101 million (1982)
Monetary conversion rate: 6.62 French
francs=US$1 (November 1986)
Fiscal year: calendar year','0160403616baae7dedc1640c9c7c6e011973cf85b3a232b7f26b53a2aa594620','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d455b5f27f5e6e0b57c5e6c7c994f4ea3860d6d05977bea1f9dd9ed5ed6205',1987,'PF','French Polynesia','economy',271,'GDP: A$931.3 million, US$6,400 per
capita (1980)
_ Agriculture: coconuts
Major industries: maintenance of French
nuclear test base, tourism
Electric power: 72,000 kW capacity; 265
million kWh produced, 1,470 kWh per
capita (1986)
| Exports: $21 million (1977); 79% coconut
products, 14% mother-of-pearl, vanilla','1aff48f6783fa3608c311ad0ec7c5ea32bdd44a34a70768076272fccd05889b4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45736d9c6dd355ad57d0fc96a804ffb9ddc5239c127ec2c16b66479e12b928e8',1987,'GA','Gabon','economy',272,'Imports: $419 million (1977); fuels, food-
stuffs, equipment —150km
Major trade partners: imports—59%
France, 14% US; exports—86% France
Budget: $180 million in 1979; ODA and
OOF commitments from Western (non-US
countries)
Monetary conversion rate: 127.05 Colo-
nial Francs Pacifique (CFP)=US$1 (Febru-
ary 1984)
Communications es
Railroads: none Guinea
Highways: 600 km (1982) See regional map VII
Inland waterways: none
Ports: 1 major (Papeete), 6 minor Geography
Airfields: 41 total, 41 usable; 25 with Total area: 267,670 km? land area:
permanent-surface runways, 2 with run- 957 670 km?
ways 2,440-3,659 m, 14 with runways y
1,220-2,439 m Comparative area: about the size of
Colorado
Civil air: about 6 major transport aircraft
Telecommunications: 33,200 telephones Land boundaries: 2,422 km total
(18.8 per 100 popl.); 80,000 radio and Coastline: 885 km
26,000 TV sets; 5 AM, 2 FM, 6 TV sta- Maritime claims:
tions; ] satellite ground station Exclusive fishing zone: 150 nm
Territorial sea: 100 nm
Defense Forces Boundary disputes: none; maritime dis-
Defense is responsibility of France pute with Equatorial Guinea
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly inter-
ior; savanna in east and south
Land use: 1% arable land; 1% permanent
crops; 18% meadows and pastures; 78%
forest and woodland; 2% other
Environment: deforestation
Special notes: none
GDP: $3.3 billion, $3,800 per capita; real
growth rate - 5.0% (1985)
Natural resources: oil, manganese, ura-
nium, gold, wood, iron ore
Agriculture: commercial—cocoa, coffee,
wood, palm oil, rice; main food crops—
pineapples, bananas, manioc, peanuts, root
crops; imports food
Fishing: catch 52,638 metric tons (1982)
Major industries: petroleum production,
sawmills, petroleum refinery, food and
beverage processing; mining of increasing
importance; major minerals—manganese,
uranium, iron (not produced)
Electric power: 280,000 kW capacity; 981
million kWh produced, 960 kWh per
capita (1986)
Exports: $2.0 billion (f.0.b., 1984); crude
petroleum, wood and wood products,
minerals (manganese, uranium concen-
trates, gold)
Imports: $0.9 billion (c.i.f., 1985); mining,
roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade partners: France, US, FRG
Budget: revenues, $1.25 billion; current
expenditures, $1.31 billion (1984)
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: calendar year
86','f68abb53b2ad712fdbdbf8a6c9bbf9e4c94ff840fe4d45371ecd60e68baf7a34','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('875b6d134459b037c270879d39601546a19e7d3dfae3da6bca40e3638038ff60',1987,'SN','Senegal','economy',279,'GDP: $125 million, about $200 per capita;
real growth rate —7.8% (FY84)
Natural resources: fish
Agriculture: peanuts, millet, sorghum, rice,
maize, palm kernels, cotton
Fishing: catch 9,600 metric tons (1983)
Major industries: peanut processing,
tourism, brewing, soft drinks, agricultural
machinery assembly, small woodworking
and metalworking, clothing
Electric power: 29,000 kW capacity; 63
million kWh produced, 81 kWh per capita
(1986)
Exports: $59 million (f.o.b., FY85 est.)
peanuts and peanut products, fish, palm
kernels
Imports: $73 million (f.0.b., FY85 est.);
textiles, foodstuffs, tobacco, machinery,
petroleum products, chemicals
Major trade partners: exports—mainly
EC, Africa; imports—EC, Africa
Aid: Western (non-US) countries, ODA
and OOF (1970-84), $283 million; US
(FY70-85), $54 million
Budget: revenues, $44.2 million; current
expenditures, $34.90 million; development
expenditures, $19.7 million (1982-83 est.)
Monetary conversion rate: 7.52
dalasi=US$1 (November 1986)
Fiscal year: 1 July-30 June
GNP: $174.7 billion, $10,400 per capita;
growth rate 2.4% (1985)
Natural resources: lignite coal, potash,
uranium, copper, natural gas
Agriculture: food deficit area; potatoes,
rye, wheat, barley, oats
Fishing: catch 264,900 metric tons (1985)
Major industries: metal fabrication,
chemicals, light industry, brown coal,
shipbuilding
Shortages: grain, vegetables, vegetable oil,
beef, coking coal, coke, crude oil, rolled
steel products, nonferrous metals
Crude steel}: 7.9 million metric tons pro-
duced, 471 kg per capita (1985)
Electric power: (including East Berlin)
23,704,000 kW capacity; 118,000 million
kWh preduced, 7,070 kWh per capita
(1986)
Exports: $23.9 billion (f.0.b., 1985 est.)
Imports: $22.2 billion (f.0.b., 1985 est.)
Major trade partners: 66.1% Socialist
countries, 29.4% developed West, 4.5% less
developed countries (1985)
Monetary conversion rate: 1.95
marks=US$] (January 1987)
Fiscal year: calendar year
GNP: $628.2 billion, $10,300 per capita;
56.4% private consumption, 19.4% invest-
ment, 19.8% public consumption, 3.9% net
foreign balance; real growth rate 2.5%;
average annual exchange rate
DM2.94=US$1 (1985)
Natural resources: iron, coal, potash
Agriculture: grains, potatoes, sugar beets;
75% self-sufficient
Fishing: catch 293,170 metric tons, $112.1
million; exports $192 million, imports $589
million (1984)
Major industries: among world’s largest
producers of iron, steel, coal, cement,
chemicals, machinery, ships, vehicles,
machine tools
Shortages: fats and oils, pulses, tropical
products, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous
metals, sulfur
Crude steel: 60 million metric tons capac-
ity (est.); 37.1 million metric tons pro-
duced, 610 kg per capita (1986)
Electric power: (including West Berlin)
99,670,000 kW capacity; 414,000 million
kWh produced, 6,820 kWh per capita
(1986)
Exports: $174 billion (f.0.b., 1985); manu-
factures 85% (including machines and
machine tools, chemicals, motor vehicles,
iron and steel products), agricultural prod-
ucts 6%, fuels 3%, raw materials 3%, other
3%
Imports: $145.4 billion (f.0.b., 1985);
manufactures 56%, fuels 20%, agricultural
products 12%, raw materials 9%, other 3%
Major trade partners: (1984) EC 47.8%
(France 11.6%, Netherlands 10.83%, UK
8%, ltaly 7.8%, Belgium-Luxembourg
6.8%), other Europe 16.7%, less developed
countries 14.5%, US 8.4%, Communist
6.5%, OPEC 5.7%
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $43.4 billion
Budget: revenues, $80.3 billion; federal
government expenditures, $88.1 billion;
deficit, $7.8 billion (1985)
Monetary conversion rate: 2.03
marks=US$1 (November 1986)
Fiscal year: calendar year
GDP: $2.3 billion, $850 per capita; real
growth rate 3.8% (1984)
Natural resources: fish, phosphates
Agriculture: peanuts (primary cash crop),
millet, sorghum, manioc, maize, rice,
livestock; deficit production of food
Fishing: catch 230,000 metric tons (1984);
exports $120 million (1984)
Major industries: fishing, agricultural
processing plants, light manufacturing,
mining
Electric power: 187,000 kW capacity; 737
million kWh produced, 105 kWh per
capita (1986)
Exports: $525 million (f.0.b., 1984); pea-
nuts and peanut products, phosphate rock,
fish, petroleum products (reexport)
Imports: $805 million (f.0.b., 1984); food,
consumer goods, machinery, transport
equipment, petroleum
Major trade partners: France, other EC,
and franc zone
Budget: (1984/85) public revenues, $467
million; current expenditures, $489 mil-
lion; capital expenditures, $75 million
Monetary conversion rate: about 331.24
Communauté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: 1 July-30 June','571cf26da236e104cc6ec992b0aa69ba5ac57b6663d5b0c98cb98c07c3d8b853','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1c5bdd000965c8d958a47891cc2464d66bc8572d5f75e69427ba63299f94315',1987,'GH','Ghana','economy',286,'GNP: $10.5 billion; real growth rate
—7.2% (1982 est.)
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish
Agriculture: main crop—cocoa; others—
root crops, corn, sorghum, millet, coffee,
peanuts; not self-sufficient but has that
potential
Fishing: catch 241,000 metric tons (1982)
Major industries: mining, lumbering, light
manufacturing, fishing, aluminum
Electric power: 1,200,000 kW capacity;
8,680 million kWh produced, 270 kWh
per capita (1986)
Exports: $617 million (f.0.b., 1985); cocoa
(about 60%), wood, gold, diamonds, man-
ganese, bauxite, aluminum (aluminum
regularly excluded from balance-of-
payments data)
Imports: $731 million (c.i-f., 1985); textiles
and other manufactured goods, food, fuels,
transport equipment
Major trade partners: UK, EC, US
Budget: revenues, $1.8 billion; expendi-
tures and net lending, $3.5 billion
(1981/82) ;
Monetary conversion rate: 90.09
cedis=US$1 (November 1986)
Fiscal year: calendar year','57b5bf0950eaad7ffd4a35ad5869214b52a2d644a011cc5dfdc6f4362bb146c9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bcbdda65e3b1fde56a2771570f1dae29c1cd587db69a4a716939bfd35ecc07a',1987,'GI','Gibraltar','economy',291,'Economic activity in Gibraltar centers on
commerce and large British naval and air
bases; nearly all trade in the well-
developed port is transit trade and port
serves also as important supply depot for
fuel, water, and ships’ wares; recently built
dockyards and machine shops provide
maintenance and repair services to 3,500-
4,000 vessels that call at Gibraltar each
year; UK military establishments and the
civil government employ nearly half the
insured labor force, and a recently an-
nounced decision to close the Royal Navy
dockyard will significantly add to unem-
ployment; local industry is confined to
manufacture of tobacco, roasted coffee,
ice, mineral waters, candy, beer, and
canned fish; some factories for manufac-
ture of clothing are being developed; a
small segment of the local population
makes its livelihood by fishing; in recent
years tourism has increased in importance
Electric power: 60,000 kW capacity; 200
million kWh produced, 6,570 kWh per
capita (1986)
Exports: $47.8 million (1983); principally
reexports of tobacco, petroleum, and wine
Imports: $136.8 million (1983); principally
manufactured goods, fuels, and foodstuffs;
65% from UK
Major trade partners: UK, Morocco,
Portugal, Netherlands
Budget: revenues, $89 million; expendi-
tures, $84.2 million (FY82)
Monetary conversion rate: 0.70 Gibraltar
pound=0.70 pound sterling=US$1 (No-
vember 1986)','4d122cc12302800c872a7aae7451b3e02c3aa0bd7ff3631c61a9ac8cabf0d2ff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b6902126d683e002a2e250474e895afa49716e2759b1758229f29f11ebf40d8',1987,'GR','Greece','economy',296,'GNP: $82.8 billion, $3,300 per capita; real
growth rate 2.1% (1985)
Natural resources: bauxite, lignite, mag-
nesite, oil
Agriculture: wheat, olives, tobacco, cotton,
raisins, fruit; nearly self-sufficient
Major industries: food and tobacco pro-
cessing, textiles, chemicals, metal products
Crude steel: 1.3 million metric tons pro-
duced (1984 est.), 132 ke per capita
Electric power: 11,223,000 kW capacity;
29.580 million kWh produced, 2,970 kWh
per capita
Exports: $8.5 billion (f.0.b., 1985); tobacco,
minerals, fruits, textiles
Imports: $10.1 billion (c.i.f., 1985); ma-
chinery and automotive equipment, petro-
leum and petroleum products, manufac-
tured consumer goods, chemicals, meat
and live animals
Major trade partners: (1985 est.) im-
ports—18.0% FRG, 9.8% Italy, 8.5% Saudi
Arabia, 6.7% France, 6.1% Netherlands;
exports—20.0% FRG, 11.3% Italy, 8.1%
US, 8.0% France, 4.1% Netherlands
Aid: US, including Ex-fm, $525 million
(1970-81); other Western bilateral (ODA
and OOF), $1.1 billion (1970-84); Commu-
nist countries (1970-85), $430 million
Military transfers: US (FY70-85) $2.6
billion
Budget: central government revenues,
$12.4 billion; expenditures $15.8 billion;
deficit, $3.4 billion (1986)
Monetary conversion rate: 135.0 Greek
drachmas=US$1 (January 1987)
Fiscal year: calendar year','a7471a0b75e515394aee3f7542d2498dad93d93e3ed0d2d7345ad244e726e2ef','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6fc7a784b155de9a6309776fcc59e965babe5eec30644683f138b88eeac6f95',1987,'GL','Greenland','economy',301,'GNP: included in that of Denmark
Natural resources: zinc, lead, iron ore,
coal, molybdenum, cryolite, uranium, fish
Agriculture: arable areas largely in hay;
sheep grazing; garden produce
Fishing: catch 107,725 tons (1983); exports
$108.6 million (1980)
Major industries: mining, fishing, sealing
Electric power: 84,000 kW capacity; 170
million kWh produced, 3,150 kWh per
capita (1986)
Exports: $168.4 million (f.0.b., 1980); fish
and fish products, metallic ores and con-
centrates
Imports: $259.4 million (c.i.f., 1980);
petroleum and petroleum products, ma-
chinery and transport equipment, food
products
Major trade partners: (1980) Denmark
49.4%, Finland 9.5%, FRG 8.1%, US 6.3%,
UK 2.9%
Monetary conversion rate: 7.37 Danish
kroner=US$1 (December 1986)
Fiscal year: calendar year','89e58d359f5272c4d2e3e674a45675fb2cd29f99e23ac571b37619df0f04c503','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f35599e93b0365bfc268dac6a5fe46b61a6d7ac99e8dbd579a8bce18e66b8017',1987,'GD','Grenada','economy',306,'GDP: $86.8 million (1984 est.), $1,000 per
capita; real growth rate 3.0% (1986 est.);
average inflation rate 6.0% (1985 est.)
Agriculture: cocoa, nutmeg, mace, and
bananas
Electric power: 11,380 kW capacity; 24
million kWh produced, 280 kWh per
capita (1986)
Exports: $22.1 million (f.0.b., 1985); cocoa
beans, nutmeg, bananas, mace
Imports: $62.6 million (f.0.b., 1985); food,
machinery and transport equipment, oil,
building materials
Major trade partners: exports—35% UK,
9% FRG, 6% Netherlands, 6% US, (1984
est.); imports—20% UK, 17% US, 17%
Trinidad and Tobago (1983)
Budget: revenues, $32 million; expendi-
tures, $61 million (1984)
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (November 1986)
97
Fiscal year: calendar year','8d7aa680223f6af596e11976025b7885ab98450001ea9da26371ba394e007309','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54996f2a2816ee3e119e33f8209d1160a86d22126f3e719446ca644390c76131',1987,'GP','Guadeloupe','economy',311,'GNP: $998 million (1983), $3,151 per
capita; real growth rate 15.7% (1979-80
average)
Natural resources: scenery, cultivable land
Agriculture: sugarcane, bananas, pineap-
ples, vegetables
Major industries: construction, cement,
rum, light industry, tourism
Electric power: 103,000 kW capacity; 315
million kWh produced, 940 kWh per
capita (1986)
Exports: $89.2 million (1981); bananas,
sugar, rum
Imports: $560 million (1981); vehicles,
foodstuffs, clothing and other consumer
goods, construction materials, petroleum
products
Major trade partners: exports—88% franc
zone; imports—73% franc zone, 3% Italy
(1981)
Aid: bilateral ODA and OOF commit-
ments (1970-79) from Western (non-US)
countries, $2.4 billion
Budget: $198 million (1981)
Monetary conversion rate: 6.62 French
francs=US$1 (November 1986)
Fiscal year: calendar year','368ed54523a35e6140687420228220d9fbf476fe8e8ff94acfcd9ae6121b3539','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c6819a84f1495a08822ba4c48be58e1b18046bdec28fe2e548072a70d493966',1987,'GG','Guernsey','economy',316,'Agriculture: principal crops—tomatoes
and flowers (mostly grown under glass);
sweet peppers, eggplant, plants, other
vegetables and fruit; Guernsey cattle
Major industries: tourism, banking
Electric power: 160,000 kW capacity; 510
million kWh produced, 9,620 kWh per
capita (1986)
101
Exports: tomatoes, flowers and ferns, sweet
peppers, eggplant, other vegetables, plants
Imports: coal, gasoline and oil
Major trade partners: UK (regarded as
internal trade)
Budget: total revenues for Guernsey and
Alderney, 63,836 million pounds; total
expenditures for Guernsey and Alderney,
65,708 million pounds (1983)
Monetary conversion rate: 0.70 pound
sterling=US$1 (November 1986)
Fiscal year: calendar year','f4faf3e00edde15967ce6a6f46145fa01de64c06d8c77c68604db6c30d2a3c34','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01bad86f5bf8517e8e9698644b7a7ab0c611d4665bb1bcb589b92a2385d31645',1987,'GW','Guinea-Bissau','economy',323,'GDP; $154 million (FY83), $180 per
capita, real growth rate —5.1% (1983)
Natural resources: potential petroleum,
bauxite, phosphates
Agriculture: rice, palm products, root
crops, coconuts, peanuts, wood
Fishing: catch 6,000 metric tons (1983)
Major industries: agricultural processing,
beer, soft drinks
Electric power: 22,000 kW capacity; 28
million kWh produced, 32 kWh per capita
(1986)
Exports: $8.6 million (1983); principally
peanuts; also palm kernels, shrimp, fish,
lumber
Imports: $57.1 million (1983); foodstuffs,
manufactured goods, fuels, transport
equipment
Major trade partners: mostly Portugal,
Spain, and other European countries
Budget: revenues, $12.2 million; current
expenditures, $27.4 million; investment
expenditures, $27.9 million (1983 est.)
Monetary conversion rate: 83.528 Guinea
Bissauan pesos=US$1 (November 1984)
Fiscal] year: calendar year','79de1d242e0565ac85dd1bbb71eaadcebf798f4452e2bdd1885c925f8f256298','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3afe3460281bfefccc2bec36ae5b5116eb27deaebfec33bbf24250d7f349ae4a',1987,'GY','Guyana','economy',328,'GDP: $480 million (1984), $630 per capita;
real growth 4.0% (1986 est.); inflation rate
4.0% (1985) j
Natural resources: bauxite, gold, dia-
monds, hardwood timber, shrimp, fish
Agriculture: sugarcane, rice, other food
crops; food shortages—wheat flour, cooking
oil, processed meat, dairy products
Major industries: bauxite mining, sugar
and rice milling, timber, fishing (shrimp),
textiles, gold mining
Electric power: 105,000 kW capacity; 500
million kWh produced, 650 kWh per
capita (1986)
Exports: $214.0 million (f.0.b., 1985);
bauxite, sugar, rice, shrimp, molasses,
timber, rum
Imports: $209.1 million (f.0.b., 1985);
manufactures, machinery, food, petroleum
Major trade partners: exports—29% UK,
17% US, 17% CARICOM, 6% Canada;
imports—33% CARICOM, 21% US, 11%
UK, 3% Canada (1983)
Budget: revenues, $954.4 million; expendi-
tures, $1,531.5 million (1985 est.)
Monetary conversion rate: 4.30 Guyanese
dollars=US$1 (November 1986)
Fiscal year: calendar year','95d847bbcbda52d15dce65bb309a5f0e2f02809252ec4545bcfae61121650d1f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed07e0c6ab80a9fa9f473083ca95ffb23c796476ad03f5b99d44274be7ef33dd',1987,'HT','Haiti','economy',333,'GDP: $1.8 billion (1986 est.), $300 per
capita; real growth rate, - 2.0% (1986)
Natural resources: bauxite
Agriculture: coffee, sugarcane, rice, corn,
sorghum
Major industries: sugar refining, textiles,
flour milling, cement manufacturing,
bauxite mining, tourism, light assembly
industries
Electric power: 196,000 kW capacity; 332
million kWh produced, 940 kWh per
capita (1986)
Exports: $206.6 million (f.0.b., 1984);
mangos, coffee, light industria] products,
essential oils, sisal, sugar
Imports: $337.9 million (f.0.b., 1984);
consumer durables, foodstuffs, industrial
equipment, petroleum products, construc-
tion materials
Major trade partners: exports—59% US;
imports—45% US (1978) ;
Aid: US commitments, including Ex-Im
(FY70-85), $419 million; ODA and OOF
from other Western countries (1970-84),
$427 million
106
Military transfers: US (FY70-85), $5
million
Budget: revenues, $220 million; expendi-
tures, $357 million (1984)
Monetary conversion rate: 5.0
gourdes=US$1 (November 1986)
Fiscal year: 1 October-80 September
Real GDP: $2.6 billion (1986), $560 per
capita; real growth rate average —3.1%
(1980-83); real growth rate 3.0% (1986)
Natural resources: forests, gold, silver,
copper, lead, zinc, iron, antimony, coal,
fish
Agriculture: bananas, coffee, corn, beans,
sugarcane, rice, tobacco
Fishing: catch 8,400 metric tons (1983)
Major industries: agricultural processing,
textiles, clothing, wood products
Electric power: 580,000 kW capacity;
1,400 million kWh produced, 300 kWh
per capita (1986)
Exports: $933 million (f.0.b., 1986); ba-
nanas, coffee, lumber, meat, minerals,
sugar, seafood
Imports: $873 million (f.0.b., 1986); manu-
factured products, machinery, transporta-
tion equipment, chemicals, petroleum
Major trade partners: exports—48% US,
34% Europe, 8% Japan, 3% CACM (1985);
imports—39% US, 10% Venezuela, 9%
CACM, 6% Japan, 5% Trinidad and
Tobago (1985)
Aid: US, including Ex-Im (FY70-85), $809
million loans; other Western (non-US)
countries, ODA and ODF (1970-84), $507
million
Military transfers: US (FY79-85), $256
million
Budget: revenues, $389 million; expendi-
tures, $605 million (1983)
Monetary conversion rate:
2 lempiras=US$1 (November 1986)
Fiscal year: calendar year','71bf13d8a6fb68a98f86b3b27d9162657ed74032fb873bb25f5d20e31afca05e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbff5214b413bb00e614d8262c95efc14fbba4cd623f12a142cd33185ac234c1',1987,'HK','Hong Kong','economy',338,'GDP: $34.2 billion, $6,180 per capita; real
growth, 1.0% (1985 est.)
Agriculture: agriculture occupies a minor
position in the economy; rice, vegetables,
dairy products; less than 20% self-
sufficient; shortages of rice, wheat, water
Major industries: textiles and clothing,
tourism, electronics, plastics, toys, watches,
and clocks
Shortages: industrial raw materials
Electric power: 6,383,000 kW capacity;
18,000 million kWh produced, 3,270 kWh
per capita (1986)
Exports: $30.2 billion (f.0.b., 1985), includ-
ing $13.5 billion reexports; clothing, plastic
articles, textiles, electrical goods, wigs,
footwear, light metal manufactures
Imports: $29.7 billion (c.i.f., 1985)
Major trade partners: exports—31% US,
26% China, 4% Japan, 4% UK, 4% FRG;
imports—25% China, 23% Japan, 9% US
(1985)
Budget: $5.1 billion (1985/86)
Monetary conversion rate: 7.81 Hong
Kong dollars=US$1 (July 1986)
Fiscal year: 1 April-31 March
109','2a839e15e16207e3b849309dddaca6a2c5e9f4b07778262a1cb56ce46399ac18','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('befd7b7383ecae2bfeb77adece0acd7f3fd82fbc3d3806c73ae09a3949c4efbd',1987,'HU','Hungary','economy',343,'GNP: $80.1 billion in 1985 (at 1985 US
dollars), $7,520 per capita; 1985 growth
rate, - 0.8%
Natural resources: bauxite, brown coal,
natural gas
Agriculture: normally self-sufficient; corn,
wheat, potatoes, sugar beets, barley
Major industries: mining, metallurgy,
engineering industries, processed foods,
textiles, chemicals (especially pharmaceuti-
cals)
Shortages: metallic ores (except bauxite),
copper, high grade coal, forest products,
crude oil
Crude steel: 3.6 million metric tons pro-
duced (1985), 339 kg per capita
Electric power: 6,851,000 kW capacity;
27,250 million kWh produced, 2,570 kWh
per capita (1986)
Exports: $13.5 billion (f.0.b., 1985); 34.8%
fuels, raw materials, and semifinished
products; 28.8% machinery and equip-
ment; 21.8% agricultural and forestry
products; 15.1% manufactured consumer
goods
Imports: $13.0 billion (c.i.f., 1985); 66.7%
fuels, raw materials, and semifinished
products; 15.8% machinery and equip-
ment; 10.4% manufactured consumer
goods; 7.1% agricultural and forestry
products
Major trade partners: 31.8% USSR, 9.6%
FRG (1985)
Monetary conversion rate: 46.50
forints=US$1 (October 1986)
Fiscal year: calendar year','d542931264f8033bc19cf01f071a0c5888fa333e8d4297a97ce54c156cce23f7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6acd224c5cdbdcd4a092106b4c22efbe6b96d5d7603e0f21683b384ab6c4a4b7',1987,'IS','Iceland','economy',348,'GDP: $2.7 billion (1985), $11,300 per
capita; 60.4% private consumption, 21.4%
private investment, 17.9% public consump-
tion, 4.3% net export of goods and services;
change in stockbuilding —0.5%; real
growth rate —5.5% (1983)
Natural resources: fish, hydroelectric and
geothermal power, diatomite
Agriculture: cattle, sheep, dairying, hay,
potatoes, turnips
Fishing: catch, 1,670,000 metric tons (1985
est.); marine product exports, $533 million
(1985)
Major industries: fish processing, alumi-
num smelting, diatomite production,
hydroelectricity
Shortages: grains, sugar, vegetables and
vegetable fibers, fuel, wood, minerals
Electric power: 918,000 kW capacity;
4,460 million kWh produced, 18,290 kWh
per capita (1986)
Exports: $814 million (f.0.b., 1985); fish
and fish products, animal products, alumi-
num, diatomite
Imports: $904 million (c.i-f., 1985); ma-
chinery and transportation equipment,
petroleum, foodstuffs, textiles
Major trade partners: (1985) exports—EC
39.3% (UK 18.0%, FRG 8.3%), 27.0% US,
9.0% LDC, 6.7% USSR; imports—EC
49.5% (FRG 13.3%, Denmark 9.1%, UK
9.6%), LDC 23.0%, USSR 8.0%, US 6.8%
Aid: US, including Ex-Im, $19.1 million
(FY70-81)
Budget: revenues, $704.9 million; expendi-
tures, $647.8 million (converted at 41.508
kronur=US$1 1985 average) (1985)
Monetary conversion rate: 40.72
kronur=US$1 (November 1986)
Fiscal year: calendar year','abf5bb21fad290dc5a44c99102231f38c269dad5dee0c59fb87042285d68599e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33825a43d7c3b690ccdf735af5c229222369727936a4266a0b06d29b28d6722',1987,'JP','Japan','economy',349,'Budget: central government revenue and
capital receipts, $41 billion; disbursements,
$45 billion (FY85/86)
Monetary conversion rate: 13.09
rupees=US$1 (November 1986)
Fiscal year: 1 April-31 March
India (continued)
Aid: Australia, commitments (1970-84)
$4.4 billion; US, including Ex-Im (FY70-
85), $220 million; other Western countries,
ODA and OOF bilateral commitments
(1980-85), $5 million
Budget: (1986) total revenues $804 million;
total expenditures (1985) $820 million
Monetary conversion rate: .96]
kina=US$1 (November 1986)
Fiscal year: calendar year
Budget: (FY86) revenues, $9.08 billion;
expenditures, $10.7 billion; deficit, $1.6
billion
Monetary conversion rate: 747.07 Turkish
liras=US$1 (December 1986)
Fiscal year: calendar year
GDP: $15 million, per capita GDP $2,020
(1980)
Natural resources: spiny lobster, conch
Agriculture: corn, beans
Fishing: catch 1,050 metric tons (1983)
Major industries: fishing, tourism
Electric power: 1,500 kW capacity; 6
million kWh produced, 810 kWh per
capita (1986)
Exports: $2.5 million (1982); crawfish,
dried and fresh conch, conch shells
Imports: $20.9 million (1982); foodstuffs,
drink, tobacco, clothing
249
Major trade partners: US (lobster, conch,
tourism) and UK
Budget: revenues, $5.9 million; expendi-
tures, $7.2 million (1981/82)
Monetary conversion rate: uses the US
dollar
Fiscal year: calendar','2a7b5e7d4f64e7730792c6ad868df70fdb8c5cafe1d8e91e9bf1ad20bdc99b2e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6082facc1625e0ce9f08dde5044f0630f6bdb9a31c1fec7346204a48359ae783',1987,'IQ','Iraq','economy',355,'GNP: $35 billion (1986 est.), $2,140 per
capita
Natural resources: oil, natural gas, phos-
phates, sulfur
Agriculture: dates, wheat, barley, rice,
cotton, livestock
Major industry: crude petroleum 1.8
million b/d; petroleum revenues, $7.0
billion (1986 est.)
Electric power: 7,734,000 kW capacity;
22,560 million kWh produced, 1,410 kWh
per capita (1986)
Exports: $7.45 billion (f.0.b., 1986 est.);
from nonoil receipts, $450 million
Imports: $9.5 billion (f.0.b., 1986 est.); 5%
from Communist countries (1985)
Major trade partners: exports—France,
Italy, Brazil, Japan, Turkey, UK, Spain,
USSR, other Communist countries; im-
ports—FRG, Japan, France, Italy, US, UK,
Turkey, USSR, other Communist countries
(1986)
118
Budget: public revenues, $20.0 billion;
current expenditures, $18.6 billion; devel-
opment expenditures, $11.0 billion (1984
est.)
Monetary conversion rate: .31 Iraqi
dinar=US$1 (January 1987)
Fiseal year: calendar year
GDP: $19.7 billion, $11,510 per capita
GNP (1985); ~4% annual growth rate
(1986)
Natural resources: petroleum, fish, shrimp
Agriculture: virtually none; dependent on
imports for food; about 75% of potable
water must be distilled or imported
Major industries: crude petroleum pro-
duction average for 1986, 1.4 million b/d;
petroleum refining (capacity about 0.6
million b/d); other major industries in-
clude petrochemicals, retail trade, and
manufacturing; water desalination capacity
618 million liters per day (1983 est.)
Electric power: 5,335,000 kW capacity;
16,360 million kWh produced, 9,240 kWh
per capita (1986)
Exports: $8.0 billion (f.0.b., 1986), of
which crude petroleum accounted for
about 78%
Imports: $7.0 billion (f.0.b., 1986)
Major trading partners: exports—Japan,
US, FRG, Italy; imports—Japan, FRG,
UK, US
Budget: revenues, $11.2 billion; current
and capital expenditures, $11.1 billion
(1985/86 est.)
Monetary conversion rate: .29 Kuwaiti
dinar=US$1 (October 1986)
Fiscal year: 1 July-30 June
GNP: $765 million, $220 per capita (1984
est.)
Natural resources: tin, timber, gypsum,
hydroelectric power
Agriculture: rice (overwhelmingly domi-
nant), corn, vegetables, tobacco, coffee,
cotton; formerly self-sufficient; food short-
ages (due in part to distribution deficien-
cies) include rice; an illegal producer of
opium poppy and cannabis for the inter-
national drug trade
Major industries: tin mining, timber,
green coffee, electric power
Shortages: capital equipment, petroleum,
transportation system, trained personnel
Electric power: 175,000 kW capacity; 900
million kWh produced, 240 kWh per
capita (1986)
Exports: $36 million (f.0.b., 1984 est.);
electric power, forest products, tin concen-
trates; coffee, undeclared exports of opium
and tobacco
Imports: $98 million (c.i.f., 1984 est.); rice
and other foodstuffs, petroleum products,
machinery, transportation equipment
Major trade partners: imports—Thailand,
USSR, Japan, France, Vietnam; exports—
Thailand, Malaysia
Aid: Western (non-US) countries ODA and
OOF (1970-84), $409 million; US (FY70-
79), $276 million
Budget: receipts, $100 million; expendi-
tures, $19] million; deficit, $91 million
(1979 est.)
Monetary conversion rate: official—10
kips=US$]; commercial—35 kips=US$1,
inward remittances—108 kips=US$1
(December 1985)
Fiscal year: ] July-30 June','565a0d63d50153651ea2bb4b92ec5cc0348352f5b257881523afaa0617740f14','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b516ff7a53cfe384e42b1a05718beed365ac4149e41417ee4b2ccf66f254a9d1',1987,'IE','Ireland','economy',360,'GNP: $14.3 billion, $4,040 per capita;
64.2% consumption, 23.6% investment,
21.5% government, 1.2% inventories;
—J0.5% net foreign demand; 2.4% real
GNP (1985)
Natural resources: zinc, lead, natural gas,
barite, copper, gypsum, limestone, dolo-
mite, peat, silver
Agriculture: livestock and dairy products,
turnips, barley, potatoes, sugar beets,
wheat; 85% self-sufficient; food shortages—
grains, fruits, vegetables
Fishing: catch 179,700 metric tons; exports
of fish and fish products $100 million,
imports of fish and fish products $35
million (1985)
Major industries: food products, brewing,
textiles and clothing, chemicals and phar-
maceuticals, machinery and transportation
equipment
Crude steel: 330,000 metric ton capacity
(1984); 203,000 metric tons produced, 55
kg per capita (1985)
Electric power: 4,177,000 kW capacity;
12,630 million kWh produced, 3,490 kWh
per capita (1986)
Ireland (continued)
Exports: $10.39 billion (f.0.b., 1985 con-
verted at 0.93 IR pound=US$1); foodstuffs
(primarily dairy and meat products), data
processing equipment, live animals, ma-
chinery, chemicals, pharmaceuticals,
clothing
Imports: $10.05 billion (c.i.f., 1985 con-
verted at 0.93 IR pound=US$1); machin-
ery, petroleum and petroleum products,
chemicals, semifinished goods, cereals
Major trade partners: exports—67.5% EC
(33.0% UK, 10.1% FRG, 8.4% France),
9.8% US, 0.9% Communist; imports—
64.7% EC (42.7% UK, 7.7% FRG, 4.8%
France), 17.0% US, 1.8% Communist
(1985)
Budget: expenditures, $8.65 billion; reve-
nues, $7.30 billion; deficit, $1.35 billion
(1986 est.)
Monetary conversion rate: 0.75 Irish
pound=US$1 (December 1986)
Fiscal year: calendar year
GNP: $443.2 billion (1985), $7,860 per
capita; 59.8% consumption, 17.0% invest-
ment, 21.1% government; 0.3% stockbuild-
ing, 1.8% net foreign balance, real growth
8.4% (1985)
Natural resources: coal, oil, gas (North
Sea), tin, limestone, iron, salt, clay, chalk,
gypsum, lead, silica
Agriculture: wheat, barley, potatoes, sugar
beets, livestock, dairy products; 62.1%
self-sufficient (1983); dependent on imports
for more than half of consumption of
refined sugar, butter, oils and fats, bacon
and ham
Fishing: catch 746,000 metric tons (1985);
imports $774 million, exports $377 million
(1985)
Major industries: machinery and trans-
port equipment, metals, food processing,
paper and paper products, textiles, chemi-
cals, clothing
Crude steel: 15.8 million metric tons
produced (1985); 280 kg per capita (1985);
23.6 million tons capacity (1984)
Electric power: 95,213,000 kW capacity;
312.700 million kWh produced, 5,540
kWh per capita (1986)
Exports: $101.0 billion (f.0.b., 1985); man-
ufactured goods, machinery, fuels, chemi-
cals, semifinished goods, transport equip-
ment
Imports: $109.1 billion (c.i.f., 1985); manu-
factured goods, machinery, semifinished
goods, foodstuffs, consumer goods
Major trade partners: exports—46.2% EC
(11.4% FRG, 9.9% France, 9.4% Nether-
lands), 14.8% US, 2.3% Communist coun-
tries; imports—46.2% EC (14.9% FRG,
7.8% France, 7.7% Netherlands), 11.9%
US, 2.4% Communist countries (1985)
Aid: donor—ODA and OOF commitments
(1970-84) $15.4 billion
Budget: national and local government
revenues (FY86 est.), $222.3 billion; expen-
ditures, $232.2 billion; deficit $9.9 billion
Monetary conversion rate: 0.674 pound
sterling=US$1 (December 1986)
Fiscal year: 1 April-31 March','ebc05f28f14bcb36e5764dd7fb765f9f80795a8be50ce9c493aa5076657272cf','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6776d8003b5f6b0bf865aca769c71dccba6f31b4d306961c51b48457f3268ad3',1987,'IL','Israel','economy',365,'GNP: $21.0 billion, $5,070 per capita; real
GNP growth rate 1.6% (est. 1986),
Natural resources: copper, phosphates,
bromide, potash, clay, sand, sulfur, bitu-
men, manganese
Agriculture: citrus and other fruits, vege-
tables, cotton, beef and dairy products,
poultry products
Major industries: food processing, dia-
mond cutting and polishing, textiles and
clothing, chemicals, metal products, trans-
port equipment, electrical equipment,
miscellaneous machinery, potash mining,
high-technology electronics
Electric power: 4,284,000 kW capacity;
16,320 million kWh produced, 3,880 kWh
per capita (1986)
Exports: $6.3 billion (1985); polished
diamonds, citrus and other fruits, textiles
and clothing, processed foods, fertilizer
and chemical products, electronics; tourism
is important source of foreign exchange
Imports: $9.4 billion (f.0.b., 1985); military
equipment, rough diamonds, oil, chemi-
cals, machinery, iron and steel, cereals,
textiles, vehicles, ships, aircraft
Major trade partners: exports—US, UK,
FRG, France, Belgium, Luxembourg,
Italy; imports—US, FRG, UK, Switzerland,
Italy, Belgium, Luxembourg
Budget: public revenues, $11.3 billion,
expenditures, $14.8 billion (FY85/86)
Monetary conversion rate: 1.5 new
sheqalims=US$1 (December 1986), ex-
change rate calculated from a basket of
foreign currencies
Fiscal year: 1 April-31 March
Exports: West Bank—$184.5 million
(1984); Gaza Strip—$114.9 million (1984)
Imports: West Bank—$406.8 million
(1984); Gaza Strip—$279.4 million (1984)
Major trade partners: West Bank—Jordan
and Israel; Gaza Strip—Egypt and Israel
Budget: within the occupied territories,
each municipality has its own budget; the
following data represent the sum of the
revenues and expenditures of the munici-
palities in each area for fiscal year begin-
ning 1 April 1984; West Bank—revenues,
$26.7 million and expenditures, $27.1
million; Gaza Strip— revenues, $14.2
million and expenditures, $18.2 million
Monetary conversion rate: West Bank—
units of currency used are Israeli new
sheqalim (1.1788=US$1, 1985 average),
Jordanian dinar (0.884=US$1, 1984 aver-
age) and US dollar; Gaza Strip—aunits of
currency used are Israeli new sheqalim
(1.1788=US$1, 1985 average), Egyptian
pound (1.48=US$1, February 1984 aver-
age), and US dollar','f4c73d67bd90d0fefe024067447b3ec48f3e6960519b98767716f1a7cab052d3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5662d62610e122eec65040db647e8b1f292382d84c5de7936caa198e5655364',1987,'IT','Italy','economy',370,'GDP: $357.8 billion, $6,260 per capita;
63.5% private consumption, 18.0% gross
fixed investment, 20.0% government,
—2.1% net foreign balance, 0.7% change
in stocks; growth rate —2.38% (constant
market prices) (1985)
Natural resources: mercury, potash, mar-
ble, sulfur, dwindling natural gas reserves,
fish
Agriculture: fruits, vegetables, cereals,
potatoes, olives; 95% self-sufficient; food
shortages—fats, meat, fish, and eggs
Fishing: catch 478,350 metric tons (1983);
exports $94 million, imports $709 million
(1984)
Major industries: machinery and trans-
portation equipment, iron and steel, chem-
icals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 23.7 million metric tons
produced (1985), 415 kg per capita
Electric power: 52,068,000 kW capacity;
189,270 million kWh produced, 3,310
kWh per capita (1986)
Exports: $78.4 billion (f.0.b., 1985); tex-
tiles, chemicals, footwear
Imports: $90.5 billion (c.i.f., 1985); petro-
leum, machinery and transport equipment,
foodstuffs, ferrous and nonferrous metals,
wool, cotton
Major trade partners: (1985) 45.5% EC
(16.4% FRG, 13.2% France, 5.9% UK,
8.9% Switzerland), 8.9% US, 8.3% Middle
East (2.9% Libya), 2.7% USSR, 8% Eastern
Europe
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $9.0 billion
Monetary conversion rate: 1,337.0
lire=US$1 (January 1987)
Fiscal year: calendar year
GDP: $8 billion, $772 per capita (1986);
real average annual growth rate, 4.9%
(1985 est.)
Natural resources: petroleum, diamonds,
manganese
Agriculture: commercial—coffee, cocoa,
wood, bananas, pineapples, palm oil; food
crops—corn, millet, yams, rice; other
commodities—cotton, rubber, tobacco, fish
Fishing: catch 92,469 metric tons (1982);
exports $44.7 million, imports $71.9 mil-
lion (1979)
Major industries: food and lumber pro-
cessing, oil refinery, automobile assembly
plant, textiles, soap, flour mill, matches,
three small shipyards, fertilizer plant, and
battery factory
Electric power: 480,000 kW capacity;
2,150 million kWh produced, 200 kWh
per capita (1986)
Exports: $3.5 billion (1985 est.); cocoa
(30%), coffee (20%), tropical woods (11%),
cotton, bananas, pineapples, palm oil,
cotton
Imports: $1.6 billion (1985 est.); manufac-
tured goods and semifinished products
(50%), consumer goods (40%), raw materi-
als and fuels (10%)
Aid: Western (non-US) ODA and OOF
(1970-84), $3.4 billion; US authorizations,
including Ex-lm (FY70-85), $341 million
Major trade partners: (1984) exports—
France, Nigeria, FRG, Netherlands, US
Budget: revenues, $1.4 billion; current
expenditures, $1.4 billion (1984 est.)
Monetary conversion rate: 475 Commun-
auté Financiére Africaine (CFA)
francs=US$1 (1985)
Fiscal year: calendar year
GNP: $129.4 billion, $5,600 per capita;
real growth rate 0.2% (1985)
Natural resources: coal, copper, bauxite,
timber, iron, antimony, chromium, lead,
zinc, asbestos, mercury, crude oil, nickel,
uranium
Agriculture: diversified agriculture with
many small private holdings and large
agricultural combines; main crops—corn,
wheat, tobacco, sugar beets, and sun-
flowers; occasionally a net exporter of
corn, tobacco, foodstuffs, live animals
Yugoslavia (continued)
Fishing: catch 75,057 metric tons (1985)
Major industries: metallurgy, machinery
and equipment, oil refining, chemicals,
textiles, wood processing, food processing,
electric power
Crude steel: 4.5 million metric tons pro-
duced (1985), 195 kg per capita
Electric power: 20,113,000 kW capacity;
79,000 million kWh produced, 3,380 kWh
per capita (1986)
Exports: $10.6 billion (f.0.b., 1985); 49%
raw materials and semimanufactures, 31%
consumer goods, 20% equipment
Imports: $12.2 billion (c.i-f., 1985); 81%
raw materials and semimanufactures, 14%
equipment, 4% consumer goods
Major trade partners: 59% non-Com-
munist countries; 41% Communist coun-
tries, of which 24% USSR (1985)
Monetary conversion rate: 408.0
dinars=US$1 (November 1986)
Fiscal year: calendar year
GDP: $4.7 billion (1985), $150 per capita;
1.8% real growth (1986 est.)
Natural resources: cobalt, copper, cad-
mium, petroleum, industrial and gem
diamonds, gold, silver, zinc, manganese,
tin, germanium, uranium, radium, bauxite,
iron, coal, hydroelectric power (potential)
Agriculture: main cash crops—coffee,
palm oil, rubber, quinine; main food
crops—manioc, bananas, root crops, corn;
some provinces self-sufficient
Fishing: catch 102,000 metric tons (1983)
Major industries: mining, mineral process-
ing, consumer products (including textiles,
footwear, and cigarettes), processed foods
and beverages, cement
Electric power: 2,412,000 kW capacity;
5,280 million kWh produced, 170 kWh
per capita (1986)
Exports: $1.913 billion (f.0.b., 1985);
$1.824 billion (1986 est.) copper (37%),
cobalt, diamonds, petroleum, coffee
Imports: $1.383 billion (f.0.b., 1985 est.);
$1.411 billion (1986 est.) consumer goods,
foodstuffs, mining and other machinery,
transport equipment, fuels
Major trade partners: Belgium, US,
France, and West Germany
Budget: (1985) revenues, $827 million;
total expenditures, $1,096 million
Monetary conversion rate: 65.94
zaires=US$1 (November 1986)
271
Fiscal year: calendar year','80002b7e582658c5e9940126e65683d2bbc9fbc35f3e41c3332459fb1c751e2e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8dec18b56f82d1c535563a3636bb9a6d74dbbd4278f0c4103b3a78bdcd600e',1987,'JM','Jamaica','economy',375,'GDP: $2.0 billion, $820 per capita; real
growth rate 5.0% (1986 est.)
Natural resources: bauxite, gypsum,
limestone
Agriculture: sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa,
tobacco; an illegal producer of cannabis
for the international drug trade
Major industries: tourism, bauxite mining,
textiles, food processing, light manufac-
tures
Electric power: 1,119,000 kW capacity;
1,520 million kWh produced, 660 kWh
per capita (1986)
Exports: $568.6 million (f.0.b., 1985);
alumina, bauxite, sugar, bananas, citrus
fruits and fruit products, rum, cocoa
Imports: $998.8 million (f.0.b., 1985);
fuels, machinery, transportation and elec-
trical equipment, food, fertilizer
Major trade partners: exports—US 48%,
Canada 14%, UK 13%, Norway 3%, im-
ports—US 46%, Netherlands Antilles 13%,
Venezuela 8%, UK 5% (1984)
Budget: revenues, $545.0 million; expendi-
tures, $818.0 million (1985)
Monetary conversion rate: 5.48 Jamaican
dollars=US$1 (November 1986)
Fiscal year: 1 April-81 March','5f4385fd54bb91a189c360140ca3a6fb529e7d4abc2d1000dd0f892b3e9170b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf8c7c2af9d3d3e52afd9abebf8dc4280fcbcd9871744e742c2417e72f754c06',1987,'JE','Jersey','economy',380,'Agriculture: potatoes, cauliflowers, toma-
toes; dairy and cattle farming
Major industries: tourism, banking and
finance
Electric power: 50,000 kW standby capac-
ity (1986); power supplied by France
Exports: 19.8 million pounds sterling
(1983); light industry, electrical manufac-
turing, textiles
Imports: machinery and transport equip-
ment, manufactured goods, food, mineral
fuels, chemicals
Major trade partners: UK
Budget: revenues, 143,680 million pounds;
expenditures, 115,902 million pounds
(1983)
Monetary conversion rate: .70 Jersey
pound=.70 pound sterling=US$1 (Novem-
ber 1986)
Fiscal year: 31 April-1May
GNP: about $478 million, $730 per capita;
real growth 11% (1984)
Natural resources: asbestos, coal, clay, tin,
diamonds, hydroelelectric power, forests
Agriculture: maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining, pulping
Electric power: 46,000 kW capacity; 120
million kWh produced, 170 kWh per
capita (1986)
Exports: $174 million (f.o.b., 1985); sugar,
asbestos, wood and forest products, citrus,
and canned fruit
Imports: $322 million (f.0.b., 1985); motor
vehicles, chemicals, petroleum products,
and foodstuffs
Major trade partners: South Africa, UK,
US; member of South African Customs
Union
Aid: Western (non-US) countries, ODA
and OOF (1970-84), $369 million; US
(FY70-85), $90 million
Budget: revenues, $204 million; current
expenditures, $149 million (1984/85 est.)
Monetary conversion rate: the Swazi
lilangeni exchanges at par with the South
African rand; 2.2 emalangeni=US$I (29
January 1986)
Fiscal year: 1 April-3] March','36a23b1ba3b41511198626e794c08a60e7700ee40d4bb22513912a367aa19f92','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4324bca145ef8e8516c11fc4b8c4f6457a48f87a9e49ae1e609281cae7225e43',1987,'JO','Jordan','economy',385,'GNP: $4.9 billion, $1,900 per capita; 2.0%
real growth rate (1984)
Natural resources: phosphates, potash,
shale oil
Agriculture: vegetables, fruits, olive oil,
wheat; self-sufficient in few foodstuffs
Major industries: phosphate mining,
petroleum refining, cement production,
light manufacturing
Electric power: 972,000 kW capacity;
2,840 million kWh produced, 1,080 kWh
per capita (1986)
Exports: $789 million (f.0.b., 1985); fruits
and vegetables, phosphates, fertilizers
Imports: $2,733 million (c.i.f., 1985); crude
oil, petroleum, textiles, capital goods,
motor vehicles, foodstuffs
Aid: US, including Ex-Im (1970-84), $1.3
billion; Western (non-US) countries, ODA
and OOF (1970-84), $988 million; Com-
munist countries (1970-85), $71 million
Military transfers: US (FY70-85), $2.2
billion
Budget: total revenues, $1,836 million;
current expenditures, $1,267 million;
capital expenditures, $675 million (1984)
Monetary conversion rate: .35 Jordanian
dinar=US$1 (November 1986)
Fiscal year: calendar year','53f2c43904b618fb98dc4d12f7678040fe2cf319b3b568f81e7990fb956d973e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec10d321fb921f1657506eac6caa3a49671a41099d1df8d539d3e91408da670e',1987,'KE','Kenya','economy',390,'GDP: $4.8 billion (1985), $230 per capita,
real growth rate, 4.1% (1985 est.)
Natural resources: gold, limestone,
diotomite, salt barytes, magnesite, feldspar,
sapphires, fluorspar, garnets, wildlife, land
Agriculture: main cash crops—coffee, tea,
sisal, pyrethrum, cotton, livestock; food
crops—corn, wheat, sugarcane, rice, cas-
sava; largely self-sufficient in food
Major industries: small-scale consumer
goods (plastic, furniture, batteries, textiles,
soap, cigarettes, flour), agricultural process-
ing, oil refining, cement, tourism
Electric power: 556,000 kW capacity;
1,950 million kWh produced, 90 kWh per
capita (1986)
Exports: $942 million (f.0.b., 1985); reex-
porting of petroleum products, coffee, tea,
sisal, livestock products, pyrethrum, soda
ash, wattle-bark tanning extract
Imports: $1,289 million (f.o.b., 1985);
machinery, transport equipment, crude oil,
paper and paper products, iron and steel
products, and textiles
Major trade partners: EC, Japan, Middle
East, US, Rwanda, Uganda
Budget: as percent of GDP—revenues and
grants 24%; total expenditures and net
lending - 28% (1985/86 est.)
External debt: $3.7 billion; debt service
ratio 36% (1985 est.)
131
Monetary conversion rate: 16.15 Kenyan
shillings=US$1 (October 1986)
Fiscal year: 1 July-30 June
External debt: $225 million (1983), exter-
nal debt ratio 4.5% (1983)
Budget: (1983 est.) revenues, $161.5 mil-
lion; current expenditures, $164.3 million;
development expenditures, $30.6 million
Monetary conversion rate: 85.9 Rwanda
francs=US$1 (November 1986)
Fiseal year: calendar year
GDP: $66.7 million, $1,250 per capita;
1.0% real growth (1986 est.)
Agriculture: main crops—sugar on St.
Christopher, cotton on Nevis
Major industries: sugar processing, tour-
ism, cotton, salt, copra
Electric power: 11,380 kW capacity; 32
million kWh produced, 800 kWh per
capita (1986)
Exports: $30.6 million (1983); sugar
Imports: $47.3 million (1983); foodstuffs,
manufactures, fuel
Major trade partners: exports—50% US,
35% UK; imports—21% UK, 17% Japan,
11% US (1978)
Aid: bilateral commitments, including
Ex-lm, from Western (non-US) countries
(1970-81), $15 million
Budget: (1984) revenues, $19 million;
expenditures, $26 million
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (December 1985)
Natural resources: Ascension—sea turtle
and sooty tern breeding ground; no
minerals
Agriculture: maize, potatoes, vegetables;
timber production being developed;
crawlishing on Tristan da Cunha
Fishing: 214 metric ton catch (1983)
Major industries: crafts (furniture,
lacework, fancy woodwork)
Electric power: 9,800 kW capacity; 8
million kWh produced, 1,140 kWh per
capita (1986)
Exports: fish (frozen skipjack, tuna, salt-
dried skipjack), handicrafts
Imports: food, drink, tobacco, fuel oils,
animal feed, building materials, motor
vehicles and parts, machinery and parts
(1981/82)
Major trade partners: imports—59% UK,
29% South Africa
Aid: development aid from UK—7.5
million pounds sterling (1984 est.)
Budget: revenue, 5,656,518 pounds ster-
ling; expenditure, 5,681,933 pounds ster-
ling (1981/82)
Monetary conversion rate: UK currency;
.70 pound sterling=US$1 (November 1986)
Fiscal year: 1 April-31 March
GDP: $148.1 million (1984), $1,220 per
capita; 5.8% real GDP growth (1986 est.);
average annual inflation rate 2.4% (1985)
Natural resources: forests, beaches, miner-
als (pumice), mineral springs
Agriculture: bananas, coconuts, sugar,
cocoa, spices
Major industries: garments, electronic
components, beverages, corrugated boxes,
tourism, lime processing, tropical agricul-
ture
Shortages: food, machinery, capital goods
Electric power: 19,025 kW capacity; 80
million kWh produced, 650 kWh per
capita (1986)
Exports: $49.7 million (f.o.b., 1983);
bananas, cocoa
Imports: $106.8 million (c.i.f., 1983);
foodstuffs, machinery and equipment,
fertilizers, petroleum products
Major trade partners: exports—58% UK,
16% US, 24% CARICOM; imports—37%
US, 138% UK, 17% CARICOM, 9% Trin-
idad and Tobago (1984 est.)
Aid: bilateral commitments, ODA and
OOF, Western (non-US) countries
(1970-81), $34 million
Budget: (1984) revenues, $61 million;
expenditures, $64 million
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (August 1986)
GDP: $108 million (1985), $850 per capita;
7% real growth (1986 est.)
Agriculture: bananas, arrowroot
Major industries: food processing
Electric power: 14,440 kW capacity; 31
million kWh produced, 300 kWh per
capita (1986)
Exports: $42.0 million (f.o.b., 1983);
bananas, arrowroot, copra
Imports: $64.9 million (c.i.f., 1983); food-
stuffs, machinery and equipment, chemi-
cals and fertilizers, minerals and fuels
Major trade partners: exports—32% UK,
57% CARICOM, 34% Trinidad and
Tobago (1983); imports 11% UK, 83% US,
32% CARICOM, 24% Trinidad and
Tobago, 6% Canada (1983 est.)
Aid: bilateral commitments, ODA and
OOF, from Western (non-US) countries
(1970-81), $25 million
Budget: (1984) revenues, $32 million;
expenditures, $34 million
Monetary conversion rate: 2.70 East
Caribbean dollars=US$1 (August 1986)','5c660b3bf353840dc6f6c79ed0f8eafeaae96ff65d285d297d80a077cc880955','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('242e399857102cf8c6c66a900d241cb15f513dab354a3cdc2e357252a747b1cc',1987,'KI','Kiribati','economy',395,'GDP: A$25.839 million (1985 est.), $410
per capita
Agriculture: coconuts, copra; subsistence
crops of roots and tubers, vegetables,
melons, bananas; pigs, chickens; domestic
fishing
Fishing: catch 24,212 metric tons (1983)
Industry: formerly phosphate production
(supply exhausted by mid-1981)
Electric power: 2,750 kW capacity; 8
million kWh produced, 125 kWh per
capita
Exports: A$4.10 (1986 est.); 54% copra,
18% fish; phosphate, formerly 80% of
exports, exhausted in 198)
Imports: A$32.64 million (1986 est.);
foodstuffs, fuel, transportation equipment
Major trade partners: Australia, New
Zealand, UK, Japan, US, Papua New
Guinea, Fiji
132
Aid: Western (non-US) commitments ODA
and OOF (1970-84), $205 million; Austra-
lia (1970-84), $28 million
Budget: A29.7 million (1986 est.)
Monetary conversion rate: $1.50
Australian=US$1 (February 1987); Austra-
lian dollar is the official currency
GNP: $24 billion (1985 in 1985 dollars),
$1,180 per capita
Natural resources: coal, lead, tungsten,
zine, graphite, magnesite, iron, copper,
gold, phosphates, salt, fluorspar, hydroelec-
tric power
Agriculture: corn, rice, vegetables; food
shortages—meat, cooking oils; production
of foodstuffs adequate for domestic needs
Major industries: machine building,
electric power, chemicals, mining, metal-
lurgy, textiles, food processing
Shortages: advanced machinery and
equipment, coking coal, coal, petroleum,
electric power, transport
Crude steel: 4.0 million metric tons pro-
duced (1985), 195 kg per capita
Electric power: 5,910,000 kW capacity;
40,000 million kWh produced, 1,925 kWh
per capita (1986)
Coal: 52 million tons (1984)
Exports: $1.38 billion (1985); minerals,
metallurgical products, agricultural prod-
ucts, manufactures
Imports: $1.72 billion (1985); petroleum,
machinery and equipment, coking coal,
grain
Major trade partners: total trade turnover
$3.10 billion (1985); 65% with Communist
countries, 35% with non-Communist
countries
Monetary conversion rate: 2 wons=US$1
(December 1984)
Fiscal year: calendar year
GNP: $94.) billion (1986, in 1986 prices),
$2,371 per capita; real growth 12.2%
(1986); real growth 8.7% (1982-86 average)
Natural resources: coal (limited), tungsten,
graphite
Agriculture: 9.0 million people (22% of the
population) live in farm households, but
agriculture, forestry, and fishing constitute
15% of GNP; main crops—rice, barley,
vegetables, and legumes
Fishing: catch 3,102,605 metric tons (1985)
Major industries: textiles and clothing,
footwear, food processing, chemicals, steel,
electronics, automobile production, ship
building
Shortages: heavily dependent on imports
of iron ore, crude oil, base metals, lumber,
and certain food grains
Crude steel: 13.6 million metric tons
produced (1985), 335 kg per capita
Electric power: 18,000,000 kW capacity;
65,000 million kWh produced, 1,500 kWh
per capita (1986)
Exports: $34.8 billion (f.0.b., 1986); textiles
and clothing, electrical machinery, foot-
wear, steel, automobiles, ships, fish
Imports: $31.2 billion (c.i.f., 1986); ma-
chinery, oil, steel, transport equipment,
textiles, organic chemicals, grains
Major trade partners: exports—40% US,
15% Japau; imports—33% Japan, 21% US
(1986)
Aid: US, including Ex-Im (FY70-85), $3.9
billion committed
Military transfers: US (FY70-85), $4
billion
Budget: planned expenditures, $18.0
billion (1987)
Monetary conversion rate: 861
won=US$1 (9 January 1987)
Fiscal year: calendar year','0de78838f0be3735a8bb7eed0d40033b01c681a026e4c7b17eca69af53872bf7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('731ac5c6669edb2b1b1aa5fceb3d930ebf15b4ccacc73a09c47c046717a5e3bf',1987,'LB','Lebanon','economy',401,'GDP: $5.3 billion (1983 est.)
Natural resources: limestone, iron
Agriculture: fruits, wheat, corn, barley,
potatoes, tobacco, olives, onions; not self-
sufficient in food; an illegal producer of
opium poppy and cannabis for the inter-
national drug trade
Major industries: service industries, food
processing, textiles, cement, oil refining,
chemicals, some metal fabricating
Electric power: ],297,000 kW capacity;
2,270 million kWh produced, 850 kWh
per capita (1986)
Exports: $482 million (f.0.b., 1985)
Imports: $2.2 billion (c.i.f., 1985)
Budget: public revenues, $500 million;
public expenditures, $].5 billion (1985 est.)
Monetary conversion rate: from 1 Janu-
ary through 31 December 1986 the Leba-
nese pound fell from 18 pounds to 95
pounds per US$1
Fiscal year: calendar year','7797fb6e72de07a205e3b159f407bae8c0cb90d97602241c8bcc404bc4a71044','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('122e03815c84b8bb05929271135e5cdbd95d0e4e0881c694f19305edd83a0674',1987,'ZA','South Africa','economy',405,'GDP: $325 million (1984)
Natural resources: some diamonds and
other minerals, water, agricultural and
grazing land
Agriculture: exceedingly primitive, mostly
subsistence farming and livestock; princi-
pal crops are corn, wheat, pulses, sorghum,
barley
Major industries: none
Electric power: power supplied by South
Africa
Exports: labor to South Africa (remittances
$300 million est. in 1985); $21 million
(f.0.b., 1985), wool, mohair, wheat, cattle,
peas, beans, corn, hides, skins, tourism,
diamonds
Imports: $326 million (f.0.b., 1985); mainly
corn, building materials, clothing, vehicles,
machinery, medicines, petroleum, oil, and
lubricants
Major trade partner: South Africa
Budget: revenues, $160 million; current
expenditures, $130 million; development
(capital) expenditures, $50 million
(FY84/85)
141
Monetary conversion rate: 2.25
maloti=2.25 South African rands=US$1
(November 1986)
Fiscal year: 1 April-31 March','4d071e261968728163351879d61876d780280106e761f9ef88fd68b1a675f47d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d2ce070f8c115aa7c54c0eb894f60038839b3dd7044e1875366e5487b177d8',1987,'LR','Liberia','economy',411,'GDP: $1.14 billion, $490 per capita; 2%
real annual growth rate (1984)
Natural resources: iron ore, rubber, tim-
ber, diamonds, gold
Agriculture: rubber, rice, oil palm, cas-
sava, coffee, cocoa; imports of rice, wheat,
and livestock are necessary for basic diet
Fishing: catch 18,553 metric tons (1982)
Major industries: rubber processing, food
processing, construction materials, furni-
ture, palm oil processing, mining (iron ore,
diamonds)
Electric power: 374,000 kW capacity; 655
million kWh produced, 280 kWh per
capita (1986)
Exports: $432 million (f.0.b., 1984); iron
ore, rubber, diamonds, lumber and logs,
coffee, cocoa
Imports: $366 million (c.i.f., 1984); ma-
chinery, transportation equipment, petro-
leum products, manufactured goods,
foodstuffs
Major trade partners: US, FRG, Nether-
lands, Italy, Belgium
Aid; Western (non-US), ODA and OOF
(1970-84), $587 million; US authorizations
(including Ex-Im) (FY70-85), $512 million;
Communist (1970-85), $73.0 million
Military transfers: US (FY70-85), $70
million
Budget: revenues, $192 million; current
expenditures, $238 million; development
and nonbudgetary expenditures, $151
million (FY84-85)
Monetary conversion rate: uses the US
dollar and the Liberian dollar, which trade
officially at par
Fiscal year: 1 July-30 June','72f049d46db170f060ccd456ff18100ac1ae88317502b7188f1b5b99ef84603a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7efb3f2cd2499a9d605e7023f312a28ff08dfd011edd219070ce482ee891eda5',1987,'LY','Libya','economy',416,'GDP: roughly $20 billion (1986 est.),
$6,260 per capita; inflation rate 15% (1986)
Natural resources: petroleum, natural gas,
gypsum
Agriculture: wheat, barley, olives, dates,
citrus fruits, peanuts; 65% of food is im-
ported
Major industries: petroleum, food process-
ing, textiles, handicrafts
Electric power: 4,110,000 kW capacity;
12,600 million kWh produced, 3,250 kWh
per capita (1986)
Exports: $5.0 billion (f.0.b., 1986); petro-
leum
Imports: $5.0 billion (f.0.b., 1986); manu-
factures, food
Major trade partners: imports—lItaly,
FRG; exports—Italy, FRG, Spain, France,
Japan, UK
Budget: revenues, $10 billion; expendi-
tures, $9.9 billion, including development
expenditure of $5.7 billion (1985 est.)
Monetary conversion rate: .317
dinars=US$1 (November 1986)
Fiscal year: calendar year','56e0414ef24610b8b02f79823f1e75398c4618d8dde72aa289f25db7b73218b0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6292143c5a3e540b9b46a517dc58bc8a0c9639fe9bb591d2984f26957995a3d',1987,'LI','Liechtenstein','economy',421,'Note: Liechtenstein has a prosperous
economy based primarily on small-scale
light industry and some farming; industry
accounts for 54% of total employment,
service sector 42%, and agriculture and
forestry 4%; the sale of postage stamps to
collectors, estimated at $10 million annu-
ally, provides for 10% of state budget;
companies incorporated in Liechtenstein
solely for tax purposes provide an addi-
tiona] 30% of the state budget; low busi-
ness taxes (maximum tax rate is 20%) and
easy incorporation rules have induced
about 25,000 holding or so-called letter
box companies, to establish nominal offices
there; economy is tied closely to that of
Switzerland in a customs union; no na-
tional accounts data are available
GNP: about $15,000 per capita (1984)
Natural resources: hydroelectric power
Agriculture: livestock, vegetables, corn,
wheat, potatoes, grapes
Major industries: electronics, metal manu-
facturing, textiles, ceramics, pharmaceuti-
cals, food products
Electric power: 23,000 kW capacity; 150
million kWh produced, 5,360 kWh per
capita (1986)
Exports: (1984) $440 million; 39% EC,
82% EFTA (24% Switzerland), 29% other
Budget: revenues, $108 million; expendi-
tures, $86 million (1983)
Monetary conversion rate: 1.69 Swiss
francs=US$1 (November 1986)
145','4f9de2b7bd910f765e7ab93a0e6f01b61c087cd0ad7a6baca53e2a99588233f8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86689a78dfaa40ab744a83a07ea237c34a38f4bd901b8a82b66244331240feac',1987,'LU','Luxembourg','economy',426,'GNP: $3.2 billion, $9,240 per capita;
57.9% private consumption, 22.2% invest-
ment, 15.7% government consumption,
8.2% stockbuilding, 1.0% net foreign
balance; 2.8% real GDP growth (1984)
Natural resources: iron ore
Agriculture: mixed farming, dairy prod-
ucts, wine
Major industries: banking, iron and steel,
food processing, chemicals, metal products,
engineering, tires
Crude steel: 3.9 million metric tons pro-
duced, 10.6 metric tons per capita; 5.4
metric ton capacity (1985)
Electric power: 1,497,000 kW capacity;
1,010 million kWh produced, 2,740 kWh
per capita (1986)
Exports, imports, major trade partners:
Luxeinbourg has a customs union with
Belgium under which foreign trade is
recorded jointly for the two countries;
Luxembourg’s principal exports are iron
and steel products, principal imports are
minerals, metals, foodstuffs, and machin-
ery; most of its foreign trade is with FRG,
Belgium, France, and other EC countries
(for totals, see Belgium)
Budget: revenues, $1.37 billion; expendi-
tures, $1.26 billion; surplus, $0.11 million
(average 1985 exchange rate, LF
59.378=US$1) (1985 est.)
Monetary conversion rate: 42.0 Luxem-
bourg francs=US$1 (December 1986);
under the BLEU agreement, the Luxem-
bourg franc is equal in value to the Bel-
gian franc, which circulates freely in
Fiscal year: calendar year
GNP: $1.08 billion (1985)
Agriculture: rice, vegetables; food short-
ages—rice, vegetables, meat; depends
mostly on imports for food requirements
Major industries: textiles, toys, plastic
products, furniture
Electric power: 123,000 kW capacity; 335
million kWh produced, 840 kWh per
capita (1986)
Exports: $90] million (f.0.b., 1985); textiles
and clothing
Macau (continued)
Imports: $772 million (c.i.f., 1985); food-
stuffs
Major trade partners: exports—32% US,
18% Hong Kong, 10% FRG, 10% France;
imports—43% Hong Kong, 21% China
(1985)
Budget: expenditures, $300 million (1985)
Monetary conversion rate:
8 patacas=US$1 (June 1986)
Fiscal year: calendar year','87943ca15851698bd98a673c5211dba61fbb9e6d46ebdfa9c1940abceeed02a9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c95a8743b468bb3ed98c2b2b10d74865eaa7515f209b4a597b2a42bed3215c',1987,'MG','Madagascar','economy',431,'GDP: $2.4 billion, about $250 per capita;
real growth rate 2.1% (1984)
Natural resources: graphite, chrome, coal,
bauxite, ilmenite, tar sands, semiprecious
stones
Agriculture: cash crops—coffee, vanilla,
cloves, sugar, tobacco, sisal, raffia, pepper,
cocoa; food crops—rice, cassava, cereals,
potatoes, corn, beans, bananas, coconuts,
and peanuts; animal husbandry wide-
spread; imports some rice, milk, and cereal
Fishing: catch 54,500 (1983); marketed
output—22,150 metric tons fish; 6,695
metric tons shellfish (1984 est.)
Major industries: agricultural processing
(meat canneries, soap factories, brewery,
tanneries, sugar refining), light consumer
goods industries (textiles, glassware), ce-
ment plant, auto assembly plant, paper
mill, oil refinery
Electric power: 114,000 kW capacity; 479
million kWh produced, 46 kWh per capita
(1986)
Exports: $350 million (f.0.b., 1985 est.);
coffee, vanilla, sugar, cloves; agricultural
and livestock products account for about
85% of export earnings
Imports: $353 million (f.0.b., 1985 est.);
27.5% raw materials, 25.3% equipment,
23.1% energy, 12.6% food, 11.5% con-
sumer goods
Major trade partners: exports—34%
France, 13.1% US, 10.4% Japan, 7.6%
Indonesia, 5.5% Italy; imports—32.5%
France, 8.6% USSR, 6.1% FRG, 5.7%
Qatar, 5.6% US (1985)
149
Budget: overall government operations—
total revenues, $420 million; current ex-
penditures, $300 million; capital expendi-
tures, $150 million; other expenditures,
$90 million (1984)
External debt: $2.2 billion disbursed; debt
service payment 33% of exports after
rescheduling (1984)
Monetary conversion rate: 747 Malagasy
francs=US$1 (September 1986)
Fiscal year: calendar year','7a7c6e5869fdebdb17098a97f6001b8505a034bbf57d679f658a6b8f3fbb0d78','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a71d211296c37e23fb16c782b38ca002532520f59f719da694c63f465fc57247',1987,'MW','Malawi','economy',436,'GDP: $1.11 billion, $160 per capita (1985);
real growth rate 3.0% (1982)
Natural resources: limestone, uranium
potential
Agriculture: cash crops—tobacco, tea,
sugar, peanuts, cotton, tung oil, maize;
subsistence crops—corn, sorghum, millet,
pulses, root crops, fruit, vegetables, rice;
self-sufficient in food production
Electric power: 152,000 kW capacity; 466
million kWh produced, 63 kWh per capita
(1986)
Major industries: agricultural processing
(tea, tobacco, sugar), sawmilling, cement,
consumer goods
Exports: $271.8 million (c.i.f., 1985);
tobacco, tea, sugar, peanuts, cotton, corn
Imports: $291.3 billion (c.i-f., 1985); manu-
factured goods, machinery and transport
equipment, building and construction
materials, fuel, fertilizer
Major trade partners: exports—UK, FRG,
US, Netherlands, South Africa; imports—
South Africa, UK, Japan, US, FRG
Aid: Western (non-US) countries, ODA
and OOF (1970-84), $1.3 billion; US autho-
rized (FY70-85), $82 million
Budget: revenues, $211.9 million; expendi-
tures, $231.9 million (1983)
Monetary conversion rate: 2.00 Malawi
kwacha=US$1 (November 1986)
Fiscal year: 1 April-31 March','975bf12c50b467907ab4e08a3cc39bf918db7fb966a476b9543737571b0b4abd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9edcd0c6bec5631b78b4ebeec7cb5321ad8a3e1be7882ecbb2aa4a381fb70329',1987,'MY','Malaysia','economy',441,'GNP; $29.0 billion, $1,870 per capita;
annual growth -8.2% (1985); converted at
August 1986 exchange rate 2.6] Malaysian
ringgit (M$)=US$1, inflation rate less than
1% (1985)
Natural resources: tin, petroleum, timber,
copper, iron, liquefied natural gas
Agriculture: Peninsular Malaysia—natural
rubber, palm oil, rice; 10-15% of rice
requirements imported; Sabah—mainly
152
subsistence, main crops are rubber, timber,
coconut, rice (rice is also a food deficit),
Sarawak—main crops are rubber, timber,
pepper with rice a food deficit
Fishing: catch 741,000 metric tons (1983)
Major industries: Peninsular Malaysia—
rubber and oi] palm processing and manu-
facturing, light manufacturing industry,
electronics, tin mining and smelting,
logging and processing timber; Sabah—
logging, petroleum production; Sarawak—
agriculture processing, petroleum produc-
tion and refining, logging
Electric power: Peninsular Malaysia—
2,821,000 kW capacity, 10,700 million
kWh produced, 820 kWh per capita;
Sabah—430,000 kW capacity, 1,250 mil-
lion kWh produced, 970 kWh per capita;
Sarawak—350,000 kW capacity, 1,020
million kWh produced, 670 kWh per
capita (1986)
Exports: $15.4 billion (f.0.b., 1985); natural
rubber, palm oil, tin, timber, petroleum,
light manufactures
Imports: $12.8 billion (c.i-f., 1985)
Major trade partners: exports—25%
Japan, 20% Singapore, 14% EC, 18% US;
imports—23% Japan, 16% Singapore, 15%
US, 14% EC (1985)
Budget: operating expenditures, $7.4
billion; development expenditures, $2.9
billion; deficit, $3.5 billion (1986)
Monetary conversion rate: 2.6] Malaysian
ringgits (M$)=US$1 (November 1986)
Fiscal year: calendar year','927e0cdbf0279bf30990787160cda15200ebcac76cc84763bb33be56055f1310','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff0870c97dc4493f20accdeca756c7ac1b82939896c56e6f2bde5a3f35d9b1c6',1987,'MV','Maldives','economy',445,'GDP: $76.7 million, $440 per capita
(1984); 10% real growth rate (1983 est.)
Natural resources: fish
Agriculture: crops—coconut, limited
production of millet, corn, pumpkins,
sweet potatoes; shortages—rice, sugar, flour
Fishing: catch 179,000 metric tons (1985)
Major industries: fishing, tourism, some
coconut processing, garment industry,
woven mats, shipping, coir (rope)
Electric power: 4,690 kW capacity; 9
million kWh produced, 50 kWh per capita
(1986)
Exports: $22.8 million (1985)
Imports: $52.0 million (1985)
Major trade partners: Japan, Sri Lanka,','4d5ad1eef2640cc5ed2a4911de6620810bbce6e5bc47f0d3eaccdbf81cfc9c1c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4accae17994b46455da14e8a307b5f797f719320dfc42a76e1fdcc12c8efc810',1987,'ML','Mali','economy',450,'GDP: $1.1 billion, $150 per capita (1983);
4.4% annual real growth rate (1982)
Natural resources: gold, phosphates,
kaolin, salt, limestone; bauxite, iron ore,
manganese, lithium, and uranium deposits
are known or suspected but not exploited
Agriculture: millet, sorghum, rice, corn,
peanuts; cash crops—peanuts, cotton,
livestock
Fishing: catch 33,000 tons (1983 est.)
Major industries: small local consumer
goods and processing
Electric power: 92,000 kW capacity; 161
million kWh produced, 20 kWh per capita
(1986)
Exports: $174.5 million (f.0.b., 1985);
livestock, peanuts, dried fish, cotton, skins
Imports: $294.6 million (f.o.b., 1985);
textiles, vehicles, petroleum products,
machinery, sugar, cereals
Major trade partners: mostly frane zone
and Western Europe; also with USSR,','1cd8b9d77bfb4762d3c6762c296f2d279fa255e07448611d28870c3a3f0d36a2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f48e0918ba2b0f63da8a62465628691a96f5bad7a73bb08889eec3e82a2707',1987,'MT','Malta','economy',455,'GDP: $1.4 billion, $3,920 per capita;
68.9% private consumption, 27.4% gross
investment; 17.4% government consump-
tion, —15.2% net foreign sector; change in
stocks 1.0%; 3.1% real GDP growth (1985)
Natural resources: limestone, salt
Agriculture: overall, 20% self-sufficient;
main products—potatoes, cauliflower,
grapes, wheat, barley, tomatoes, citrus, cut
flowers, green peppers, hogs, poultry, eggs;
generally adequate supplies of vegetables,
poultry, milk, and pork products; seasonal
or periodic shortages in grain, animal
fodder, fruits, other basic foodstuffs
Major industries: tourism, ship repair
yard, clothing, building industry, food
manufacturing, textiles
Shortages: most consumer and industrial
needs (fuels and raw materials) must be
imported
Electric power: 217,000 kW capacity; 835
million kWh produced, 2,360 kWh per
capita (1986)
Exports: $399.8 million (f.0.b., 1985);
clothing, textiles, ships, printed matter
Imports: $756.7 million (c.i-f., 1985)
Major trade partners: 74% EC (24% Italy,
22% FRG, 17% UK); 6% US
Budget: revenues, $475 million; expendi-
tures, $486 million (1984 est.)
Monetary conversion rate: 2.62 Maltese
lira=US$1 (November 1986)
Fiscal year: 1 April-31 March
GNP: 195 million pounds (1983/4); finan-
cial services 21%, manufacturing 13.7%,
tourism 10.8%, construction 10.4% (1984)
Natural resources: lead, iron
Agriculture: cereals and vegetables; cattle,
sheep, pigs, poultry
Fishing: 8,300 metric tons with a value of
170,934 pounds sterling (1983)
Major industries: an important offshore
financial center; financial services, light
manufacturing, tourism
Electric power: 61,000 kW capacity; 185
million kWh produced, 2,850 kWh per
capita (1986)
Exports: tweeds, herring, processed shell-
fish meat
Imports: timber, fertilizers, fish
Major trade partners: UK
Budget: revenues, 108,214 million pounds;
expenditures, 94,949 million pounds
(FY84/85 est.)
Monetary conversion rate: .70 Isle of Man
pound=.70 pound sterling)=US$1 (Novem-
ber 1986)
Fiscal year: 1 April-31 March','b78e0e260e478b09cecf527a626c0398b75ec08e4fa4d8870f83f934b47b5e17','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfdd953c4c8494b53db847d14beeda5e02e951f859e1c9479a3c2be681acf851',1987,'MQ','Martinique','economy',460,'GDP; $1.3 billion, $4,036 per capita (1981)
Natural resources: scenery, cultivable land
Agriculture: bananas, pineapples, vegeta-
bles, flowers, sugarcane for rum
Major industries: construction, rum,
cement, oil refining, light industry, tourism
Electric power: 108,000 kW capacity; 330
million kWh produced, 1,010 kWh per
capita (1986)
Exports: $115 million (1983); refined
petroleum products, bananas, rum, pine-
apples
Imports: $744 million (1983); petroleum
products, foodstuffs, construction materials,
vehicles, clothing and other consumer
goods
Major trade partners: exports—56%
France (1978); imports—62% France, 28%
EC and franc zone, 4.5% US, 5.5% other
(1977)
Aid: bilateral ODA and OOF commit-
ments (1970-81) from Western (non-US)
countries, $3.1 billion
Budget: expenditures, $215 million (1981)
Monetary conversion rate: 6.62 French
francs=US$1 (November 1986)
Fiscal year: calendar year','6c50f556aa0cfacbe447e6a6f9644353e40818534b0c5668dba7f29adc54de12','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4925db169e1f39762611723ace17c3723673a2f8cb0d1941564c1b0b09c6fe99',1987,'MR','Mauritania','economy',465,'GNP: $800 million, $450 per capita (1985
est.)
Natural resources: iron ore, gypsum, fish
Agriculture: most Mauritanians are no-
mads or subsistence farmers; livestock,
cereals, vegetables, dates; cash crop—gum
arabic
Fishing: catch, 53,800 metric tons (1983)
Major industries: mining of iron ore and
gypsum, fish processing
Electric power: 57,000 kW capacity; 74
million kWh produced, 43 kWh per capita
(1986)
Exports: $340 million (f.0.b., 1986); iron
ore, processed fish, and small amounts of
gum arabic and gypsum; also unrecorded
but numerically significant cattle exports
to Senegal
Imports: $250 million (f.0.b., 1986); food-
stuffs and other consumer goods, petro-
leum products, capital goods
Major trade partners: France and other
EC members, Senegal, and US
Budget: $225 million budgeted in 1984;
$184 million revenues (planned 1984)
Monetary conversion rate: 73.7
ouguiyas=US$1 (30 September 1986)
Fiscal year: calendar year','b48ed4e893bae81109a3c49dbe89a09bb275f07e76dbdbc74dcca893a4726971','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('901adbb8337a461197ccbf427fc755d9b1806b0abab554fc9bce70b2e37d0b69',1987,'MU','Mauritius','economy',470,'GDP: $1.0 billion, $940 per capita; 6%
real growth rate (1985/86 est.)
Agriculture: sugar crop is a major eco-
nomic asset; about 90% of cultivated land
area is planted in sugar; also sugar deriva-
tives, tea, tobacco; most food imported
Major industries: mainly food manufac-
turing (largely sugar milling), textiles and
wearing apparel, chemical and chemical
products, metal products, transport equip-
ment, and nonelectrical machinery
Electric power: 237,000 kW capacity; 373
million kWh produced, 370 kWh per
capita (1986)
Exports: $442 million (merchandise, f.o.b.,
1985); sugar about 40%, Export Processing
Zone exports about 50%
Imports: $463 million (f.o.b., 1985); food,
petroleum products, manufactured goods
161
Major trade partners: all EC countries
and US have preferential treatment, UK
buys almost all of Mauritius’s sugar export
at subsidized prices; small amount of sugar
exported to Canada, US, and Italy; nonoil
imports from UK and EC primarily, also
from South Africa, Australia, US, and
Japan; some minor trade with China
Budget: as percent of GDP, revenues
22.7%, external grants 1.6%, current ex-
penditures 23.7%; capital expenditures,
4.9% (1986/87)
Monetary conversion rate: 13.34 Mauri-
tian rupees=US$1 (November 1986)
Fiscal year: 1 July-30 June
Aid: Western (non-US) countries, ODA
and OOF (1970-81), $4.0 billion
Monetary conversion rate: 7.974 French
francs=US$1 (81 October 1983)
Fiscal year: probably calendar year','f2f0ffd6cabfac8219db017c3a44ab5c531a850e8b99506b5601b3caf63a4acb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bd183ae83077da9b1fc03c46f2e2a518e8c61107915d5b92e88770d7e3823c8',1987,'KM','Comoros','economy',474,'Agriculture: vanilla, ylang-ylang, coffee,
copra
Fishing: annual catch, about 2,000 tons
Major industries; newly created lobster
and shrimp industry
Electric power: no data
Exports: 5 million francs (1982); ylang-
ylang, vanilla
Imports: 116 million francs (1982); build-
ing materials, transport equipment, rice,
clothing, flour
Major trade partners: imports—France
57%, Kenya 16%, South Africa 11%, Paki-
stan 8%; exports—France 79%, Reunion
19%, Comoros 10%
Budget: 144.3 million francs (1982)
Monetary conversion rate: 6.62 French
francs=US$I (November 1986)
Fiscal year: calendar year
162','28fe0c71dc710f116fcd117bcc27367647d06db31294f48f77eb8e7ffe484704','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2154040ded31ff18adbce40b81d79aee174650dfd3a8611e48e50a779948df',1987,'MX','Mexico','economy',479,'GDP: $147.2 billion, $1,870 per capita;
62% private consumption, 11% private
investment, 9% public consumption, 7%
public investment; net foreign balance 5%;
real growth rate, 2.7%; average inflation
rate 58% (1985)
Natural resources: petroleum, silver,
copper, gold, lead, zinc, natural gas,
timber
Agriculture: corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseed, pulses, and
vegetables; an illegal producer of opium
poppy and cannabis for the international
drug trade
Mexico (continued)
Fishing: catch 1,500,000 metric tons
(1985); exports valued at $481 million,
imports at $21.9 million (1982)
Major industries: processing of food,
beverages, and tobacco; chemicals, basic
metals and metal products, petroleum
products, mining, textiles and clothing, and
transport equipment
Crude steel: 10 million metric tons capac-
ity (1984); 7.3 million metric tons pro-
duced, 95 kg per capita (1985)
Electric power: 23,054,000 kW capacity;
90,490 million kWh produced, 1,110 kWh
per capita (1986)
Exports: $21.866 billion (f.0.b., 1985);
cotton, coffee, nonferrous minerals (includ-
ing lead and zinc), shrimp, petroleum,
sulfur, salt, cattle and meat, fresh fruit,
tomatoes, machinery and equipment
Imports: $13.460 billion (f.0.b., 1985);
machinery, equipment, industrial vehicles,
and intermediate goods
Major trade partners: exports—60% US,
10% EC, 8% Japan (1985); imports—67%
US, 11% EC, 5% Japan
Aid: US, including Ex-Im (FY70-85), $2.9
billion; (ODA and OOF) Western (non-US)
countries (1970-84), $4.3 billion; Commu-
nist countries (1970-85), $110 million
Military transfers: US (FY70-85), $8
million
Budget: (at average controlled rate of
exchange) public sector, budgeted reve-
nues, $73.3 billion; budgeted expenditures,
$86.5 billion (1985)
Monetary conversion rate: dual exchange
rates—controlled rate 1,022 pesos=US$1;
free rate 1,019=US$1 (both rates as of 16
February 1987, set daily by the Mexican
GDP: $56.7 billion in 1984, $13,700 per
capita; 49.6% private consumption; 18.9%
government consumption; 25.4% gross
fixed investment; 3.3% change in stock-
building; net exports of goods and services
8.0%; real growth rate 3.5% (1985)
Natural resources: oil, copper, gas, pyrites,
nickel, iron, zinc, lead, fish, timber, hydro-
electric power
Agriculture: animal husbandry predomi-
nates; main crops—feed grains, potatoes,
187
fruits, vegetables; 40% self-sufficient; food
shortages—food grains, sugar
Fishing: catch 2.48 million metric tons
(1984); exports $765 million (1985)
Major industries: oil and gas, food pro-
cessing, shipbuilding, wood pulp, paper
products, metals, chemicals
Shortages: most raw materials except
timber, petroleum, iron, copper, and
ilmenite ore; dairy products and fish
Crude petroleum: 785,000 b/d, exports
$6.5 billion (1985)
Crude steel: 924,000 metric tons produced
(1985), 228 kg per capita
Electric power: 23,435,000 kW capacity;
122,650 million kWh produced, 29,450
kWh per capita (1986)
Exports: $18.7 billion (f.0.b., 1985); oil,
natural gas, metals, chemicals, machinery,
fish and fish products, pulp and paper,
ships
Imports: $14.5 billion (c.i.f., 1985); ma-
chinery, fuels and lubricants, transport
equipment, chemicals, foodstuffs, clothing,
ships
Major trade partners: exports—68.8% EC
(35.6% UK, 15.6% FRG), 8.8% Sweden,
8.1% LDC, 5.17 US; imports—47.4% EC
(16.1% FRG, 10.0% UK), 17.8% Sweden,
7.2% US, 6.7% LDC (1985)
Aid: donor—ODA and OOF commitments
(1970-84), $2.4 billion
Budget: revenues $25.9 billion, expendi-
tures, $23.1 billion, (converted at 1985
exchange rate of Nkr 8.597=US$]1)
Monetary conversion rate: 7.5 Norwegian
kroners=US$1 (October 1986)
Fiscal year: calendar year
GDP: $9.0 billion, $7,800 per capita (1985
est.)
Natural resources: oil, copper, asbestos,
some marble, limestone, chromium, gyp-
sum
Agriculture: based on subsistence farming
(fruits, dates, cereals, cattle, camels),
fishing
Major industries: crude petroleum pro-
duction 550,000 b/d (1986)
Electric power: 1,111,000 kW capacity;
2,920 million kWh produced, 2,300 kWh
per capita (1986)
Exports: $5.0 billion (f.0.b., 1985), mostly
petroleum; nonoil consist mostly of re-
exports, processed copper, and some agri-
cultural goods
Imports: $3.4 billion ( c.i.f., 1985), ma-
chinery, transportation equipment, manu-
factured goods, food, livestock, lubricants
Major trade partners: exports—-59%
Japan, 15% Korea, 7% Thailand; imports—
23% UK, 20% Japan, 16% UAE, 7% FRG
(1985)
Budget: (1985) revenues, $4.5 billion;
expenditures, $5.7 billion
Monetary conversion rate: .385
rial=US$1 (January 1987)
Fiscal year: calendar year
GNP: $240.6 billion (1985), $6,420 per
capita; growth rate 1.6%; inflation rate
15% (1985)
Natural resources: coal, sulfur, copper,
natural gas, silver
Agriculture: self-sufficient for minimum
requirements; main crops—grain, sugar
beets, oilseed, potatoes, exporter of live-
stock products and sugar; importer of
grains
Fishing: catch 650,000 million metric tons
(1985)
Major industries: machinebuilding, iron
and steel, extractive industries, chemicals,
shipbuilding, food processing
Crude steel: 16.1 million metric tons
produced, about 430 kg per capita (1985)
Electric power: 80,737,000 kW capacity;
141,500 million kWh produced, 3,740
kWh per capita (1986)
Exports: $17.8 billion (f.0.b., 1985); 89.7%
machinery and equipment; 23.8% fuels,
minerals, and metals; 9.5% chemicals, 7.4%
manufactured consumer goods; 4.7%
agricultural and forestry products; 14.9%
other (1985)
Imports: $17.4 billion (f.0.b., 1985); 33.7%
machinery and equipment; 30.4% fuels,
minerals, and metals; 14.2% chemicals,
7.3% manufactured consumer goods, 4.7%
agricultural and forestry products; 9.7%
other (1985)
Major trade partners: $34.6 billion (1985);
61% Communist countries, 32% developed
countries, 7% less developed countries
Monetary conversion rate: 148 zlotys=
US$1 (December 1985)
Fiscal year: calendar year
GNP: $18.1 billion, $300 per capita (1984)
at official exchange rates of 12.1
dong=US$1
Natural resources: phosphates, coal, man-
ganese, bauxite, apatite, chromate, possible
offshore oil deposits, forests
Agriculture: main crops—rice, rubber,
fruits and vegetables; some corn, manioc,
sugarcane; major food imports—wheat,
corn, dairy products
Fishing: catch 539,000 metric tons (1984)
Major industries: food processing, textiles,
machinebuilding, mining, cement, chemi-
cal fertilizer, glass, tires, oil
Shortages: foodgrains, petroleum, capital
goods and machinery, fertilizer
Electric power: 1,914,000 kW capacity;
5,400 million kWh produced, 90 kWh per
capita (1986)
Exports: $763 million (1984); agricultural
and handicraft products, coal, minerals,
ores
Imports: $1,823 million (1984); petroleum,
steel products, railroad equipment, chemi-
cals, medicines, raw cotton, fertilizer, grain
Major trade partners: exports—USSR,
East European countries, Japan, other
Asian markets; imports—USSR, East
Europe, Japan
Monetary conversion rate: official rate 80
dong=US$1 (November 1986)
Fiscal year: calendar year','a5db78de0642955e2276e56810e847816f916c3358f76492bdf16c9b0bd673ab','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cee5a4c86ccad5554271216d720a6a78f381728a1c7cd71c436eae19083c45f9',1987,'MC','Monaco','economy',483,'GNP: 55% tourism; 25-30% industry (small
and primarily tourist oriented); 10-15%
registration fees and sales of postage
stamps; about 4% traceable to the Monte
Carlo casino
Major industries: chemicals, food process-
ing, precision instruments, glass making,
printing
Electric power: 8,000 kW standby capac-
ity (1986); power supplied by France
Trade: full customs integration with
France, which collects and rebates Mona-
can trade duties; also participates in EC
market system through customs union with','44bc123abda8182d936efb9ba8e0a5a8c88fe01704da8f5a34b2a8fcc0f1e868','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63c4d821c2712746b49ed94af14e54b05dc914ec619de2effe14a671eb2c92ec',1987,'MN','Mongolia','economy',488,'GDP: $1.67 billion, $880 per capita (1985
est.); average annual real growth, 3.6%
(1976-85 est.)
Natural resources: coal, copper, molybde-
num, tungsten, phosphates, tin, nickel,
zinc, wolfram, fluorspar, gold
Agriculture: livestock raising predomi-
nates; wheat, oats, barley
Major industries: processing of animal
products; building materials; mining
Electric power: 607,000 kW capacity;
2,800 million kWh produced, 1,410 kWh
per capita (1986)
Exports: livestock, animal products, wool,
hides, fluorspar, nonferrous metals,
minerals
Imports: machinery and equipment,
petroleum, clothing, building materials,
sugar, tea, chemicals
Major trade partners: nearly all trade
with Communist countries (about 80%
with USSR); total turnover about $1.0
billion
Aid: heavily dependent on USSR
Monetary conversion rate: 3.36
tugriks=US$1 (February 1984)
Fiscal year: calendar year','e5484c5b00f6483d3e743fa34ef3ab33fb34ccc959120cfc06f114b2f4da9588','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62e72335dbb0299bac459b1c1043b5c63d84633eb3dfba4204e0b1b3d8b35e0c',1987,'MS','Montserrat','economy',493,'GDP: $32.4 million, $2,760 per capita
(1983); 4.6% real GDP growth rate (1986);
25% of GDP from tourism
Agriculture: cotton, limes, potatoes, toma-
toes, hot peppers, livestock
Fishing: catch 150 metric tons (1983)
167
Major industries: tourism; light manufac-
turing—plastic bags, textiles, electronic
appliances
Electric power: 5,000 kW capacity; 12.5
million kWh produced, 1,040 per capita
(1986)
Exports: $1.6 million (1983); plastic bags,
electronic parts, textiles; hot peppers, live
plants; cattle
Imports: $20 million (1983); machinery
and transport equipment, foodstuffs, man-
ufactured goods, fuels, lubricants, and
related materials
Major trade partners: UK
Budget: revenues, $8.0 million; expendi-
tures, $11.0 million (1984)
Monetary conversion rate: $2.70 East
Caribbean=US$1 (1986)
Fiscal year: 1 April-31 March','a0ed9ce5b650873d80fd010037b5235856b35d51e64cae1de7d66e562108f34d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e12538065329765390ca9039f20a8efed0c72c90ac686ada69d6d6f8c0c4a64',1987,'MA','Morocco','economy',498,'GDP: $11.9 billion, about $510 per capita
(1985); average annual real growth 4.7%
(1986 est.)
Natural resources: phosphates, iron, man-
ganese, lead, zinc, fish
Agriculture: not self-sufficient in food;
cereal farming and livestock raising pre-
dominate; barley, wheat, citrus fruit, wine,
vegetables, olives; some fishing; an illegal
producer of cannabis for the international
drug trade
Fishing: catch 463,000 metric tons (1985)
Major industries: mining and mineral
processing, food processing, textiles, con-
struction and tourism
Electric power: 2,080,000 kW capacity;
6,920 million kWh produced, 290 kWh
per capita (1986)
Exports: $2.2 billion (f.0.b., 1985); 24%
phosphates, 76% other
Imports: $3.8 billion (c.i.f., 1985); 25%
petroleum products, 75% other
Major trade partners: France, FRG, Italy,
Saudi Arabia, Benelux, Iraq
Budget: revenues, $4.5 billion; current
expenditures, $3.6 billion; development
expenditures, $2.0 billion (1984 est.)
Monetary conversion rate: 8.84
dirhams=US$1 (November 1986)
Fiscal year: calendar year','562715ca3744638b825444ad350a899c5ff5955ef49ebc5fd29b50ad2d9075fa','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4757469c6c056d2c6d0376dc73c8ac94850d7ee6cf1cef72f141a5784396fcb',1987,'MZ','Mozambique','economy',503,'GNP: $1.3 billion, about $90 per capita
(1986 est.); average annual growth rate
—8.5% (1981-85 est.)
Natural resources: coal, natural gas,
copper, bauxite, titanium
Agriculture: cash crops—cotton, cashew
nuts, sugar, tea, copra, sisal, rice; other
crops—corn, wheat, peanuts, potatoes,
beans, sorghum, cassava; imports—corn
Fishing: 13,500 metric tons (1984)
Major industries: food processing (chiefly
sugar, tea, wheat, flour, cashew kernels);
chemicals (vegetable oil, oilcakes, soap,
paints); petroleum products; beverages;
textiles; nonmetallic mineral products
(cement, glass, asbestos, cement products);
tobacco
Electric power: 2,225,000 kW capacity;
1,640 million kWh produced, 120 kWh
per capita (1986)
Exports: $90 million (1986 est.); cashews,
shrimp, sugar, tea, cotton
Imports: $525 million (1986 est.); refined
petroleum products, machinery, transpor-
tation goods, spare parts, consumer goods,
military arms and equipment
Major trade partners: exports—US, West-
ern Europe; imports—Western and East-
ern Europe, USSR
Budget: deficit $250 million (1986 est.)
Monetary conversion rate: 42
meticais= US$1 (January 1987)
Fiscal year: calendar year','16453a789300e52d361e7bc2fcd365510e97cc1e71330106ea266268afa23c78','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcb75cf9369f342620dcdc0111b1ecb844ed34b4ffbd788b348b58779eb8bf2e',1987,'NA','Namibia','economy',508,'Natural resources: diamonds, copper,
uranium, lead, tin, zinc, salt, vanadium
Agriculture: livestock raising (cattle and
sheep) predominates; subsistence crops
(millet, sorghum, corn, and some wheat)
are raised, but most food must be im-
ported
Fishing: catch 341,000 metric tons (1983);
processed mostly in Walvis Bay, South
Africa
Major industries: (nearly all for export)
meatpacking, fish processing, dairy prod-
ucts, copper, lead, zinc, diamond, and
uranium mining
Electric power: 395,000 kW capacity; 692
million kWh produced, 610 kWh per
capita (1986)
Monetary conversion rate: 2.5 South
African rands=US$1 (29 January 1986)
Fiscal year: 1 April-31 March
GDP: $51 billion (1985), about $1,560 per
capita; 2.0% real growth (1986)
Natural resources: gold, chromium, anti-
mony, coal, iron, manganese, nickel, phos-
phates, tin, uranium, gem diamonds,
platinum, copper, vanadium
Agriculture: corn, wheat, sugarcane,
tobacco, citrus, fruits; cattle and dairy
products; sheep and wool; self-sufficient in
foodstuffs
Fishing: catch 599,897 metric tons (1983)
Major industries: mining, automobile
assembly, metalworking, machinery,
textile, iron and steel, chemical, fertilizer
Electric power: 29,954,000 kW capacity;
148,450 million kWh produced, 4,470
kWh per capita (1986)
Exports: $9.2 billion (f.0.b., 1985), gold,
coal, diamonds, corn, uranium, other
mineral and agricultural products; net gold
output $7.0 billion (1985)
Imports: $10.4 billion (f.0.b., 1985); ma-
chinery, motor vehicle parts, petroleum
products, textiles, chemicals
Major trade partners: US, FRG, Japan,
UK, Southern African Customs Union
Budget: (FY85/86) revenues, $10.6 billion;
current expenditures, $12.3 billion
Monetary conversion rate: 2.5 South
African rands=US$1 (29 January 1986)
Fiscal year: 1] April-3] March
GNP: $2,062.6 billion (1985, in 1985
geometric mean prices), $7,396 per capita;
in 1985 percentage shares were—50%
consumption, 30% investment, 20% gov-
ernment and other, including elements of
defense (based on 1982 rubles at adjusted
225
factor cost); average annual growth rate of
real GNP 2.4% (1971-85); average annual
growth rate 2.1% (1976-85); 1.2% (1985)
Natural resources: fossil fuels, hydroelec-
tric power, timber, manganese, lead, zinc,
nickel, mercury, potash, phosphates
Agriculture: principal food crops—grain
(especially wheat), potatoes; main indus-
trial crops—sugar beets, cotton, sunflowers,
and flax; degree of self-sufficiency depends
on fluctuations in crop yields, particularly
grain; large grain importer over past
decade
Fishing: catch 10.7 million metric tons;
exports 501,598 metric tons, 418,912
metric tons; exports exclude canned fish,
canned crab, and caviar (1985)
Major industries: diversified, highly
developed capital goods industries; con-
sumer goods industries comparatively less
developed
Shortages: fertilizer, pesticides, feed,
natural rubber, bauxite and alumina,
tantalum, tin, tungsten, fluorspar, molyb-
denum, and finished steel products
Crude steel: 174 million metric ton capac-
ity; 155 million metric tons produced, 558
kg per capita (1985)
Electric power: 327,000,000 kW capacity;
1,600,000 million kWh produced, 5,670
kWh per capita (1986)
Exports: $86,956 billion (f.0.b., 1985);
petroleum and petroleum products, natural
gas, metals, wood, agricultural products,
and a wide variety of manufactured goods
(primarily capital goods and arms)
Imports: $82,922 billion (f.o.b., 1985);
grain and other agricultural products,
machinery and equipment, steel products
(including large diameter pipe), consumer
manufactures
Major trade partners: $169.9 billion (1985
total turnover); 61% Communist countries,
27% industrialized West, 12% with less
developed countries
Aid: total extended to non-Communist less
developed countries (1954-85), $33 billion
Monetary conversion rate: official, 0.838
ruble=US$1 (1985 average); the exchange
rate is administratively set and should not
be used to convert domestic rubles to
dollars
Fiscal year: calendar year
Soviet Union (continued)','0d2786c81323d0bcdc42ed3aa2aef2c6fb251bb3a6e42b7ee42a9c5b12830b7a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465d51e946547d59d7928956e298169e3dfe236e6756ce03d81efb90b3ed0c39',1987,'NR','Nauru','economy',513,'GNP: over $160 million, $20,000 per
capita (1984)
Natural resources: phosphates
Agriculture: negligible; almost completely
dependent on imports for food and water
Major industries: mining of phosphates,
about 2 million tons per year
Electric power: 13,250 kW capacity; 48
million kWh produced, 6,000 kWh per
capita (1986)
Exports: $93 million (f.o.b., 1984)
Imports: $14 million (c.i.f., 1982); food,
fuel, water
Major trade partners: exports—75%
Australia and New Zealand; imports—
Australia, UK, New Zealand, Japan
Budget: revenues, A$59.5 million
(FY86/87 est.)
Monetary conversion rate: 1.50 Australian
dollars=US$1 (February 1987)
Fiseal year: 1 July-30 June','0daa0d4292eb65d6503181a21811ae1f080479c9969c750afa5b8d88dac7155d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a6fcdb716e794d7c50530f35bc3a5a9bbb49fde16431ef891283352a47da41a',1987,'NP','Nepal','economy',518,'GDP: $2.4 billion (FY85/86 current
prices), $140 per capita; 3% real growth
(FY84/85 est.)
Natural resources: quartz, water, timber,
hydroelectric potential, scenic beauty
Agriculture: over 90% of population
engaged in agriculture; rice, corn, wheat,
sugarcane, oilseeds; an illegal producer of
cannabis for the international drug trade
Major industries: small rice, jute, sugar,
and oilseed mills; match, cigarette, and
brick factories
Electric power: 160,000 kW capacity; 395
million kWh produced, 25 kWh per capita
(1986)
Exports: $162 million (FY85/86 est.); rice
and other food products, jute, timber,
manufactured goods
Imports: $460 million (FY85/86),; manu-
factured consumer goods, fuel, construc-
tion materials, fertilizers, food products
Major trade partner: India
Budget: domestic revenues, $300 million;
expenditures, $536 million (FY84/85 est.)
Monetary conversion rate; 21.8 Nepalese
rupees=US$1 (October 1986)
Fiscal year: 15 July-14 July','5491b6052b7ddf674c1350279845afd112f53c2c6460cb0156f33cdb96632a7a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a5a3a259eac7806627cfe2b005dee899bcf503a8ea6c9ccfa742b7dd6640e84',1987,'NL','Netherlands','economy',523,'GDP: $124.2 billion, $8,570 per capita;
59.2% private consumption, 18.4% invest-
ment, 16.3% government consumption,
1.1% inventories, 5.1% net foreign de-
mand, 2.0% real GNP growth (1985)
Natural resources: natural gas, oil
Agriculture: animal husbandry predomi-
nates; horticultural crops, grains, potatoes,
sugar beets; food shortages—erains, fats,
oils
Fishing: catch 480,000 metric tons; exports
of fish and fish products, $535.6 million;
imports, $303.3 million (1985)
Major industries: food processing, metal
and engineering products, electrical and
electronic machinery and equipment,
chemicals, petroleum products, natural gas
Shortages: crude petroleum, raw cotton,
base metals and ores, pulp, pulpwood,
lumber, feedgrains, oilseeds
Crude steel: 7.4 million metric ton capac-
ity, 5.5 million metric tons produced, 380
kg per capita (1985)
Electric power: 20,956,000 kW capacity;
63,090 million kWh produced, 4,340 kWh
per capita (1986)
Exports: $67.9 billion (f.o.b., 1985); food-
stuffs, machinery, chemicals, petroleum
products, natural gas, textiles
Imports: $64.9 billion (c.i.f., 1985); ma-
chinery, transportation equipment, crude
petroleum, foodstuffs, chemicals, raw
cotton, base metals and ores, pulp
Major trade partners: (1984) exports—
71.9% EC (29.8% FRG, 18.8% Belgium-
Luxembourg, 10.5% France, 9.4% UK),
5.0% US, 1.9% Communist countries;
imports—53.3% EC (21.8% FRG, 11.4%
Belgium-Luxembourg, 8.7% UK), 8.8% US,
5.3% Communist countries
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $12.0 billion
Budget: revenues, $40.6 billion; expendi-
tures, $49.5 billion; deficit, $8.9 billion
(1985 est.); 3.3214 guilders=US$1 (1985
average)
Netherlands (continued)
Monetary conversion rate: 2.3
guilders=US$1 (October 1985)
Fiscal year: calendar year
GDP: $1.36 billion, $9,140 per capita;
1.0% real growth rate (1984)
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Agriculture: corn, pulses
Major industries: petroleum refining on
Curacao (refinery currently closed but may
reopen); petroleum transshipment facilities
on Curacao and Bonaire; tourism on Cur-
acao and St. Martin; light manufacturing
on Curacao
Electric power: 120,000 kW capacity; 365
million kWh produced, 1,550 kWh per
capita (1986)
Exports: $3.7 billion (f.0.b., 1984); 98%
petroleum products, phosphate
Imports: $4.0 billion (c.i.f., 1984); 64%
crude petroleum, food, manufactures
Major trade partners: exports—46% US,
2% Canada, 1% Netherlands; imports—
35% Venezuela, 11% US, 4% Netherlands
(1977)
Aid: bilateral ODA and OOF commit-
ments (1970-79), Western (non-US) coun-
tries $353 million
Budget: central government revenues,
$616 million; central government expendi-
tures, $656 million (1984)
Monetary conversion rate: 1.8 Nether-
lands Antillean guilders or florins
(NAF)=US$1 (August 1986)
Fiscal year: calendar year','73ec6bf7a3a05d9929716eab7ebfcaa11341d301219e52e1ddc157978dd542c9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('683d84f552102439faebf2f93b8cc5f2a9e18628783aa6b3204f2ca43809f4b7',1987,'NC','New Caledonia','economy',528,'GNP: $1.21 billion, $8,050 per capita
(1983)
Natural resources: nickel, chrome, iron,
cobalt, manganese, silver, gold, lead,
copper
Agriculture: large areas devoted to cattle
grazing; coffee, maize, wheat, vegetables;
60% self-sufficient in beef
Industry: nickel mining
Electric power: 400,000 kW capacity;
2,200 million kWh produced, 14,800 kWh
per capita (1986)
Exports: $217.8 million (1983); 95% nickel
metal (95%), nickel ore
Imports: $350 million (1983); fuels and
minerals, machines and electrical equip-
ment
Major trade partners: exports—54.9%
France; imports—32.5% France (1980)
Budget: revenues, $187.1 million; expendi-
tures, $168.3 million (1981)
Monetary conversion rate: 127.05 francs
CFP=US$1 (December 1982)','a7b077da3e21250cb1d76327d3a66fcfa0168a34c8a5522890e78b88c0927240','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36dd1032242ce8033406d95e26e745377534a2cedf2445ef55447c8c558f1fda',1987,'TK','Tokelau','economy',534,'GDP; $24.1 billion (FY ending March
1985), $7,420 per capita; real growth rate
1.1% (1975-85); 17.5% average inflation
rate (FY ending March 1987 est.)
Natural resources: natural gas, iron, sand,
coal, timber
Agriculture: fodder and silage crops, wool,
meat, dairy products; food surplus country
Fishing: catch 138,000 metric tons (1983);
exports—130,000 metric tons valued at
$300 million (1984)
Major industries: food processing, wood
and paper products, textile production,
machinery, transport equipment, banking
and insurance, tourism
Electric power: 7,593,000 kW capacity;
27,000 million kWh produced, 8,180 kWh
per capita (1986)
Exports: $5.75 billion (f.0.b., FY ending
June 1986); beef, wool, dairy products
Imports: $6.2 billion (c.i.f., FY ending
June 1986); petroleum, cars, trucks, ma-
chinery and electrical equipment, iron and
steel, petroleum products
Major trade partners: exports—16%
Australia, 15% Japan, 15% US, 9% UK
(trade year 1982/83); imports—20.5%
Japan, 17.2% Australia, 16.5% US, 9.2%
UK (1985)
179
Aid; ODA and OOF commitments
(1970-84), $380 million
Budget: expenditures, $7.3 billion; re-
ceipts, $6.0 billion; deficit, $1.3 billion
(1984/85)
Monetary conversion rate:
NZ$1.88=US$1 (14 January 1987)
Fiscal year: 1 April-31 March
GDP: $1 million, $670 per capita (1983)
Natural resources: negligible
Agriculture: coconuts, copra; basic subsis-
tence crops—pulaka, breadfruit, pawpaw,
bananas; pigs, poultry
Fishing: ocean and lagoon fish and shell-
fish for local consumption
Major industries: copra production, wood
work, plaited craft goods, stamps, coins
Electric power: 200 kW capacity; .80
million kWh produced, 200 kWh per
capita (1986)
Exports: $98,000 (1983); stamps, handi-
crafts
Imports: $323,400 (1983); foodstuffs,
machinery, fuel
Major trade partner: New Zealand
Budget: (1983/4) expenditures, $1,358,105;
revenue, $208,419; New Zealand subsidy,
$1,149,686
Monetary conversion rate: New Zealand
currency and the Tokelau souvenir coin
are legal tender—NZ$1.93=US$1 (Novem-
ber 1986); Western Samoan currency is
also used
Fiscal year: 1 April-31 March','d9325a00b31e36bd04a0b3907606c6b6ea1dea7f81b5880ceb2c143a1e5e0f14','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87d96e3ceb1d58796c761332846b30e63b852c84980abcd3b0aca424cf3eee53',1987,'NI','Nicaragua','economy',540,'GDP: $1.6 billion (1985), $510 per capita;
real GDP growth rate 1986, - 5% (conver-
sion from national currency made at 70
cordobas=US$$1, the highly overvalued
official exchange rate)
Natural resources: gold, silver, copper,
tungsten, arable land, timber, livestock,
fish
Agriculture: cotton, coffee, sugarcane, rice,
corn, beans, cattle
Major industries: food processing, chemi-
cals, metal products, textiles and clothing,
petroleum, beverages
Electric power: 398,000 kW capacity;
1,200 million kWh produced, 360 kWh
per capita (1986)
Exports: $218 million (f.0.b., 1986); coffee,
cotton, sugar, seafood, bananas
Imports: $840 million (f.0.b., 1986); food
and nonfood agricultural products, chemi-
cals and pharmaceuticals, transportation
equipment, machinery, construction mate-
rials, clothing, petroleum
Major trade partners: exports—40% EC,
20% Japan, 8% CACM, 7% US, 5% CEMA,
20% other; imports—438% CEMA, 12% EC,
10% Mexico, 8% US, 6% CACM, 21%
other (1985)
Aid: US, including Ex-Im (FY70-82), $290
million; Western (non-US) countries, ODA
and OOF (1970-84), $634 million; Com-
munist countries (1970-85), $1455 million
Military transfers: US commitments
(FY70-79), $20 million
Budget: expenditures, $900 million; reve-
nues, $0.5 billion; converted at 70
cordobas=US$1, official exchange rate
(1985)
Monetary conversion rate: multiple
exchange policy; official rate 70
cordobas=US$1 (January 1986); free mar-
ket 3,000 cordobas=US$1 (January 1986)
Fiscal year: calendar year','2f53858efe62139d79120efa914e6c9375e4dfeabb68a8fdc53a65d749c48ec8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7e3243ccb493dd9029e1a577f66605140fefec314880fcdb6dd81dcba8afcd3',1987,'NE','Niger','economy',545,'GDP: $1.2 billion, $180 per capita; annual
real growth rate - 3.1% (1985 est.)
Natural resources: uranium, coal, iron,
tin, phosphates
Agriculture: commercial—cowpeas,
groundnuts, cotton; main food crops—
millet, sorghum, rice
Major industries: cement plant, brick
factory, rice mill, small cotton gins, oil
presses, slaughterhouse, and a few other
small light industries; uranium production
began in 1971
Electric power: 101,000 kW capacity; 265
million kWh produced, 39 kWh per capita
(1986)
Exports: $250.6 million (f.0.b., 1985);
uranium, livestock, cowpeas, onions, hides,
skins; exports understated because much
regional trade not recorded
Imports: $309.4 million (f.0.b., 19825);
petroleum products, primary materials,
machinery, vehicles and parts, electronic
equipment, pharmaceuticals, chemical
products, cereals, foodstuffs
Major trade partners: France (about half),
other EC countries, Nigeria, UDEAC
countries; US (8.8%, 1981); preferential
tariff to EC and franc zone countries
Budget: (1986 est.) revenue $173 million,
(1986 est.) $364.6 million expenditures
Monetary conversion rate: 33] Commun-
auté Financiére Africaine (CFA)
francs=US$1 (November 1986)
Fiscal year: ] October-30 September','038850a1392255ac81972ef07d41c01cccd8be13ca17b1ee0622813846d550e9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('825d05e08809c45a87c67af64ec206a97ef535cdc9725bd8fe515049f17aa5d1',1987,'NG','Nigeria','economy',548,'GDP: $53.4 billion (1985), $520 per capita;
1.0% growth rate (1985 est.); 5% inflation
rate (1985)
Natural resources: petroleum, tin, colum-
bite, iron ore, coal, limestone, lead, zinc
Agriculture: peanuts, cotton, cocoa, rub-
ber, yams, cassava, sorghum, palm kernels,
millet, corn, rice; livestock; an illegal
producer of cannabis for the international
drug trade
Fishing: catch 515,000 metric tons (1983);
imports nonprocessed and processed fish
Major industries: mining—crude oil,
natural gas, coal, tin, columbite; processing
industries—oil palm, peanut, cotton, rub-
ber, petroleum, wood, hides, skins; manu-
facturing industries—textiles, cement,
building materials, food products, foot-
wear, chemical, printing, ceramics
Electric power: 4,900,000 kW capacity;
10,730 million kWh produced, 100 kWh
per capita (1986)
Exports: $12.6 billion (f.0.b., 1985); oil
(97%), cocoa, palm products, rubber, .
timber, tin
Imports: $8.3 billion (f.0.b., 1985); machin-
ery and transport equipment, manufac-
tured goods, chemicals, wheat ‘
Major trade partners: UK, EC, US
Budget: (1985) revenues, $15.0 billion;
current expenditures, $12.0 billion; capital
expenditures $5.0 billion
Monetary conversion rate: 3.3
naira=US$1 (December 1986 market rate)
Fiscal year: calendar year','fed8da82cfd1371c3bac4b16779953e0444ef3a7853743a3fc7f37a1c328f694','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1162bb88b8fff4bc912e23ab6440293c646ab40c812b738f32c575b47dc1d04',1987,'NU','Niue','economy',553,'GNP: $3 million (1984), per capita GDP
$1,080 (1984)
Agriculture: coconuts, passion fruit, honey,
limes; subsistence crops—taro, yams,
cassava (tapioca), sweet potatoes; pigs,
poultry, beef cattle
Fishing: 930,000 metric tons (1982)
Major industries: small tourist industry
Electric power: 1,500 kW capacity; 3
million kWh produced, 1,120 kWh per
capita (1986)
Exports: $301,224 (f.0.b. 1983); canned
coconut cream, copra, honey, passion fruit
products, pawpaw, root crops, limes,
footballs, handicrafts
Imports: $1,504,180 (c.i.f. 1983); food and
live animals, manufactured goods, machin-
ery, fuels, lubricants, chemicals, drugs
Major trade partners; exports—New
Zealand, Fiji, Cook Islands, Australia;
imports—New Zealand, Fiji, Japan, West-
ern Samoa, Australia, US
Budget: revenues (including New Zealand
subsidy of $2.3 million) $3.2 million;
expenditures, $3.8 million (FY83/84 est.)
Monetary conversion rate: uses New
Zealand currency; NZ$1.93=US$1 (No-
vember 1986)
Fiseal year: ] April-31 March','d17f2ff97e3f468a5713c6a6b674fa1280d700c977882fa37d198340b6a3e2ea','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d51495874b4208f5452a8414ebb458ba26f2b9cd6563c6b0f8f597ac8027b04f',1987,'NF','Norfolk Island','economy',558,'Agriculture: Kentia palm seed, cereals,
vegetables, fruit
Major industries: tourism ($10 million)
Electric power: 7,000 kW capacity; 8
million kWh produced, 3,240 kWh per
capita (1986)
Exports: $2.9 billion (1982-83); seed of the
Norfolk Island pine; Kentia palm seeds,
small quantities of avocados
Imports: $15.1 million (1982-83)
Major trade partners: imports—Australia
and Pacific Islands, New Zealand, Asia,
Europe; exports—Australia and Pacific
Islands, New Zealand, Asia, and Europe
Budget: revenue, $2.7 million; expendi-
ture, $3.3 million (1983); main source of
income is sale of postage stamps and
customs duties; expenses—administrative
$1.2 million, education $0.5 million, health
$0.5 million, welfare $0.2 million, mainte-
nance $0.4 million
Monetary conversion rate: 1.55 Australian
dollars=US$1 (November 1986)
Fiscal year: 1 July-30 June','dc74e567effbff36857e0f63a032511d072a520cb958719f14102c5dcace5feb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd866ddded3928a43243c123747521d983484b2821f094ea067da8e81ac6cf0',1987,'PK','Pakistan','economy',566,'GNP: $82 billion (FY86 est.); $310 per
capita (FY86); real growth 7.3% (FY86)
Natural resources: land, extensive natural
gas, limited petroleum, poor quality coal,
iron ore
Agriculture: wheat, rice, sugarcane, cotton;
an illegal producer of opium poppy and
cannabis for the international drug trade
Fishing: catch 343,400 metric tons (1983)
Major industries: cotton textiles, steel,
food processing, engineering, chemicals,
natural gas
Electric power: 5,731,000 kW capacity;
22,590 million kWh produced, 220 kWh
per capita (1986)
Exports: $3.1 billion (c.i.f., FY86); pri-
marily rice, cotton, and textiles
Imports: $5.6 billion (f.0.b., FY86); petro-
leum (crude and products), cooking oil,
machinery
Major trade partners: exports—US 10%,
Japan 10%, UK 8%; imports—Japan 15%,
US 12%, Germany 9% (FY86)
Budget: current expenditures, $5.4 billion;
development expenditures, $2.6 billion
(FY86)
Monetary conversion rate: 17.2
rupees=US$1 (FY86 average)
Fiscal year: 1 July-30 June','5c8dbccd110e9134d98de3d8dc479ad83d878bda24c244e218d18f92920339e7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dda003072daa187ca771325f47b84db10dc17e6b76958f83a2dafc7033f70eef',1987,'PA','Panama','economy',571,'GNP: $4.4 billion (1984), $2,060 per cap-
ita; real growth - 3.3% (1985)
Natural resources: copper, mahogany
forests, shrimp
Agriculture: bananas, rice, sugarcane,
coffee, corn; self-sufficient in basic foods;
an illegal producer of cannabis for the
international drug trade
Fishing: catch 143,000 metric tons (1983);
exports $53.2 million (1984)
Major industries: food processing, bever-
ages, petroleum products, construction
materials, clothing, paper products
Electric power: 1,109,000 kW capacity;
8,120 million kWh produced, 1,400 kWh
per capita (1986)
Exports: $410 million (f.0.b., 1985); petro-
leum products, bananas, shrimp, sugar
Imports: $1.34 billion (f.0.b., 1985); petro-
leum products, manufactured goods,
machinery and transportation equipment,
chemicals, foodstuffs
Major trade partners: exports—59.1% US,
17% Central America and Caribbean, 16%
EC, 8% other; imports—-30% US, 19%
Central America and Caribbean, 10%
Mexico, 8% Japan, 8% Venezuela, 6% EC,
15% other (1984)
Aid: US, including Ex-Im commitments
(FY70-85), $468 million; Western (non-US)
countries, ODA and OOF (1970-84), $494
million; Communist countries (1970-85), $4
million
Military transfers: US (FY70-85), $47
million
Budget: (1984) revenues, $886 million;
expenditures, $1.175 billion
Monetary conversion rate:
1 balboa=US$1 (January 1986)
Fiscal year: calendar year
192','fb73d5f78761c214d1742b30055bf40be86406a0ea60c594f889f9d0563109a4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e987f0c3f4364b6f37dcad8042043922b46f9332cc2118ac1efb8da7440a17eb',1987,'PG','Papua New Guinea','economy',576,'GNP: $2.2 billion, $680 per capita; real
growth 2.2% (1984); 3.7% inflation rate
(1985)
Natural resources: gold, copper, silver, gas
Agriculture: coffee, cocoa, coconuts, tim-
ber, tea
Major industries: sawmilling and timber
processing, copper mining (Bougainville),
fish canning
Electric power: 750,000 kW capacity;
1,700 million kWh produced, 500 kWh
per capita (1986)
Exports: $920 million (f.0.b., 1985); gold,
copper, coffee, palm oil, logs, cocoa, copra,
coconut oil, tea
Imports: $969 million (f.0.b., 1984); ma-
chinery and equipment, fuels and lubri-
cants, food and live animals, chemicals,
other manufactured goods
Major trade partners: Australia, UK,','46bb99f8beef115470f20c20d54fc6bb76ebaec956d21ae21530b246c593d2f5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59fca5697225a657e3c1c8f46382bf7b4aab9ab1c2388d2460e89a2650b147b7',1987,'PY','Paraguay','economy',581,'GDP: $3.8 billion 1986, $950 per capita
(1986), 66% private consumption, 7%
public consumption (1983); 28% gross
domestic investment; real growth rate
1985, 4.5%; 40% inflation rate (mid-1986)
Natural resources: iron, manganese,
limestone, hydroelectric power, forests
Agriculture: oilseeds, soybeans, cotton,
wheat, manioc, sweet potatoes, tobacco,
corn, rice, sugarcane; self-sufficient in most
foods; illegal producer of cannabis for the
international drug trade
Major industries: meat packing, oilseed
crushing, milling, brewing, textiles, light
consumer goods, cement, construction
Electric power: 1,675,000 kW capacity;
1,130 million kWh produced, 280 kWh
per capita (1986)
Exports: $350 million (f.0.b., 1986); cotton,
oilseeds, meat products, tobacco, timber,
coffee, essential oils, tung oil
Imports: $730 million (f.o.b., 1986); fuels
and lubricants, machinery and motors,
motor vehicles, beverages and tobacco,
foodstuffs
Major trade partners: exports—26%
Brazil, 18% Netherlands, 11% Argentina,
11% Switzerland, 7% US, 6% FRG; im-
ports—33% Brazil, 16% Argentina, 18%
US, 7% Algeria, 6% Japan, 5% FRG, 5%
UK (1986)
Aid: bilateral commitments, US (FY70-85)
$157 million; other Western countries,
ODA and OOF (1970-84), $648 million
Military transfers: US (FY70-85), $18
million
Budget: (1986 est.) revenues, $620 million;
expenditures, $762 million
Monetary conversion rate: 240
guaranies=US$1 at fixed rate, 650
guaranies=US$) at floating rate (Novem-
ber 1986)
Fiscal year: calendar year','13732234078b190d222f3cd1c27410816a920a975ab5b28c5454e7f9f5e90587','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6e45008581ca35de3434bbd1aa2968b31daf9642001e7535e6ec18132c47d4d',1987,'PE','Peru','economy',586,'GNP: $19 billion, $970 per capita (1985);
68% private consumption, 11% public
consumption, 12.5% gross investment; 8.5%
net foreign balance (1983); real growth
rate, 1.6% (1985)
Natural resources: minerals, metals, petro-
leum, forests, fish
Agriculture: main crops—wheat, potatoes,
beans, rice, barley, coffee, cotton, sugar-
cane; imports—wheat, meat, lard and oils,
rice, corn; an illegal producer of coca for
the international drug trade
Fishing: catch 4.1 million metric tons
(1985); exports—oil, $7 million; edible
products, $98 million; fishmeal, $118
million (1985)
Major industries: mining of metals, petro-
leum, fishing, textiles and clothing, food
processing, cement, auto assembly, steel,
shipbuilding, metal fabrication
Electric power: 3,964,000 kW capacity;
13,700 million kWh produced, 680 kWh
per capita (1986)
Exports: $2.4 billion (f.0.b., 1986 est.);
fishmeal, cotton, sugar, coffee, copper, iron
ore, refined silver, lead, zinc, crude petro-
Jeum and byproducts
Imports: $2.2 billion (f.0.b., 1986 est.);
foodstuffs, machinery, transport equip-
ment, iron and steel semimanufactures,
chemicals, pharmaceuticals
196
Major trade partners: exports—36% US,
23% EC, 11% Latin America, 10% Japan,
4% UK; imports—25% US, 20% Latin
America, 19% EC, 7% Japan, 6% FRG
(1985)
Budget: revenues, $3.3 billion; expendi-
tures, $3.9 billion (1985)
Monetary conversion rate: 13.95
intis=US$1 (December 1986)
Fiscal year: calendar year','e725a8ffb22e04364c1e0fe0087274b1c20d95f1ba7ce589d3d254130d134a28','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dafafe56c67c9295b46d91de998cda3c2f470abdb5984aa772c5ca428fe7cfb',1987,'PH','Philippines','economy',591,'GNP: $34.5 billion, $580 per capita; 1%
real growth, (1986 est.)
Natural resources: timber, petroleum,
nickel, iron, cobalt, silver, gold
Agriculture: rice, corn, coconut, sugarcane,
bananas, abaca, tobacco; illegal producer
of cannabis for the international drug
trade
Fishing: catch 1.8 million metric tons
(1983)
Major industries: textiles, pharmaceuti-
cals, chemicals, wood products, food pro-
cessing, electronics assembly
Electric power: 6,350,000 kW capacity;
22,000 million kWh produced, 370 kWh
per capita (1986)
Exports: $4.6 billion (f.0.b., 1986 est.);
coconut products, sugar, logs and lumber,
copper concentrates, bananas, garments,
nickel, electrical components, gold
Imports: $5.2 billion (f.0.b., 1986 est.);
petroleum, industrial equipment, wheat
Major trade partners: (1983) exports—
36% US, 20% Japan; imports—23% US,
17% Japan
Philippines (continued)
Budget: revenues, $4.3 billion, expendi-
tures, $5.7 billion, deficit, $1.4 billion
(1986)
Monetary conversion rate: (floating) 20.43
pesos=US$1 (December 1986)
Fiscal year: calendar year
GNP: expenditure $NZ911,000 (1981/82);
bartering important part of life
Natural resources: miro trees (used for
handicrafts)
Agriculture: local use—citrus, sugarcane,
watermelons, bananas, yams, taro, beans,
pumpkin, coconuts, wild goats, poultry
Fishing: plentiful
Major industries: postage stamp sales
Electric power: 25 kW capacity; .05
million kWh produced, 810 kWh per
capita (1986)
Exports: fruits, vegetables, curios
Imports: fuel oil, machinery, building
materials, flour, sugar, other foodstuffs
Budget: revenue $NZ812,639, expenditure
$NZ1,119,882 (1983/84 est.)
Monetary conversion rate:
NZ$1.93=US$1 (November 1986)
Fiscal year: 1 April-31 March','ce2e1098f6baec3e33db4633229d25c3d4afaded6678cb47b5fd0004d848ad50','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6cd8dd9c6fe357652b42e2ea6161e50ce097dfba0c0283fb992d0f938958901',1987,'PT','Portugal','economy',598,'GNP: $20.7 billion (1985); 68% private
consumption; 23% fixed capital formation,
16% government consumption, —0.5%
change in stocks; —5% net exports; real
growth rate 3.3% (1985)
Natural resources: fish, forests (cork),
tungsten, iron, uranium ores
Agriculture: generally underdeveloped;
main crops—grains, potatoes, olives, grapes
for wine; deficit foods—sugar, grain, meat,
fish, oilseed
Fishing: catch 254,577 metric tons (1985)
Major industries: textiles and footwear;
wood pulp, paper, and cork; metalwork-
ing; oil refining; chemicals; fish canning;
wine
201
Crude steel: 420,000 tons produced, 40 kg
per capita (1985 est.)
Electric power: 5,615,000 kW capacity;
17,240 million kWh produced, 1,710 kWh
per capita (1986)
Exports: $5.7 billion (f.0.b., 1985); cotton
textiles, cork and cork products, canned
fish, wine, timber and timber products,
resin, machinery, and appliances
Imports: $7.1 billion (c.i.f., 1985); petro-
leum, cotton, foodgrains, industrial ma-
chinery, iron and steel, chemicals
Major trade partners: 47% EC, 10% US,
2% Communist countries, 19% other devel-
oped countries, 22% less developed coun-
tries
Aid: US, including Ex-lm, $1.6 billion
(FY70-85); other Western countries (ODA
and OOF), $848 million (1970-84)
Military transfers: US, $605 million
(FY70-85)
Budget: (1985) expenditures, $8.5 billion;
revenues, $6.0 billion; deficit, $2.5 billion
Monetary conversion rate: 149.40
escudos=US$1 (November 1986)
Fiscal year: calendar year','65280ef4c2cab28230e0e02b7fd4078e7cafd25e64782a98308ec2fd167153d6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c4b2231f1761de9c819958fd4884feaa9d70d207657137bb5d41d41d22cf32c',1987,'QA','Qatar','economy',603,'GNP: $6.4 billion; $22,940 per capita
(1984)
Natural resources: petroleum, natural gas,
fish
Agriculture: farming and grazing on small
scale; commercial fishing increasing in
importance; most food imported; rice and
dates staple diet
Major industries: oil production and
refining; crude oil production averaged
860,000 b/d (1986); oil revenues accrued
$2.6 billion, representing 85% of govern-
ment revenue (FY86 est.)
Electric power: 1,305,000 kW capacity;
4,000 million kWh produced, 18,180 kWh
per capita (1986)
Exports: $2.6 billion (f.0.b., 1986), of
which petroleum accounted for $2.1 bil-
lion
Imports: $1.1 billion (f.0.b., 1986)
Budget: revenues, $2.8 billion; expendi-
tures, $3.1 billion (FY86)
Monetary conversion rate: 3.64 Qatar
riyals=US$1 (October 1986)
Fiscal year: 1 April-31 March
Agriculture: cash crops—almost entirely
sugarcane, small amounts of vanilla and
perfume plants; food crops—tropical fruit
and vegetables, manioc, bananas, corn,
market garden produce, some tea, tobacco,
and coffee; food crop inadequate, most
food needs imported
Major industries: 12 sugar processing
mills, rum distilling plants, cigarette fac-
tory, 2 tea plants, fruit juice plant, canning
factory, a slaughterhouse, and several
small shops producing handicraft items
Electric power: 180,000 kW capacity; 394
million kWh produced, 730 kWh per
capita (1986)
Exports: $128 million (f.0.b., 1980); 90%
sugar, 5% rum and molasses, 4% perfume
essences, 1% vanilla and tea
Imports: $871 million (c.i.f., 1980); manu-
factured goods, food, beverages, tobacco,
machinery and transportation equipment,
raw materials, and petroleum products
Major trade partners: France and','d2f253efa31e5025ff59212c0c1b6f20f5ccbe4ec6b20c63ab914f031e9a3b8a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0368ef057bc555d93140d0ed04a95734501813fc166919355d5482c708b80aa',1987,'RO','Romania','economy',608,'GNP: $123.7 billion (1985), $5,450 per
capita; real growth rate, 1.8% (1985)
Natural resources: oil, timber, natural gas,
coal
Agriculture: net exporter; main crops—
corn, wheat, oilseed; livestock—cattle,
hogs, sheep; consumer and food supplies
weak
Fishing: catch 243,000 metric tons (1983)
Major industries: mining, forestry, con-
struction materials, metal production and
processing, chemicals, machine-building,
food processing
Shortages: energy, iron ore, coking coal,
metallurgical coke, cotton fibers, natural
rubber
Crude steel: 13.8 million metric tons
produced, 608 kg per capita (1985)
Electric power: 20,899,000 kW capacity;
72,500 million kWh produced, 3,160 kWh
per capita (1986)
Exports: $12.2 billion (f.0.b., 1985); 32.0%
machinery and equipment; 28.0% fuels,
minerals, and metals; 16.0% manufactured
consumer goods; 12.0% agricultural mate-
rials and forestry products; 12.0% other
(1984)
Imports: $10.4 billion (f.0.b. 1985); 24.7%
machinery and equipment; 52.6% fuels,
minerals, and metals; 10.8% agricultural
and forestry products; 4.2% manufactured
consumer goods; 7.7% other (1984)
Major trade partners: $22.6 billion in
1984; 40% non-Communist countries, 60%
Communist countries (1984)
Romania (continued)
Monetary conversion rate: 15.6 lei=US$1
(November 1986)
Fiscal year: calendar year','13ff5e2831ac6751b8e64057f18a4f877d84d9ed7396dacf2db309bc44136bb8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0cf306680646c8c4e9440ba9f511924d43bb072ab6670860084108865af1efb',1987,'RW','Rwanda','economy',612,'GDP: $1.6 billion, $270 per capita; real
growth rate, 5.5% (1984 est.)
Natural resources: gold, cassiterite, wol-
framite
Agriculture: cash crops—mainly coffee,
tea, some pyrethrum; main food crops—
bananas, cassava; stock raising; self-
sufficiency declining; country imports
foodstuffs
Major industries: mining of cassiterite (tin
ore) and wolframite (tungsten ore), tin
factory, cement factory, agricultural proc-
essing, and production of beer, soft drinks,
soap, furniture, shoes, plastic goods, tex-
tiles, cigarettes
Electric power: 42,000 kW capacity; 110
million kWh produced, 16 kWh per capita
(1986)
Exports: $130.6 million (f.0.b., 1985 est.);
mainly coffee, tea, cassiterite, wolframite,
pyrethrum
Imports: $298.7 million (c.i.f., 1985 est.);
textiles, foodstuffs, machines, equipment,
capital goods, steel, petroleum products,
cement and construction material
Major trade partners: US, Belgium, FRG,','76ac35d74fafac59e7fcd4c10d8c957827ba4fe4f112a12dea9fe8774b11e3f4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c10190b7f0a1087dbfbe948c762b643eb4e0d0fbc0303cda14ee43206bb1740e',1987,'SM','San Marino','economy',617,'Principal economic activities of San Mar-
ino are farming, livestock raising, light
manufacturing, and tourism; the largest
share of government revenue is derived
from the sale of postage stamps throughout
the world and from payments by the
Italian Government in exchange for Italy’s
monopoly in retailing tobacco, gasoline,
and a few other goods; main problem is
finding additional funds to finance badly
needed water and electric power systems
expansions
Natural resources: building stones
Agriculture: wheat, grapes, other grains,
fruits, vegetables, animal feedstuffs,
cheese, livestock hides
Electric power: supplied by Italy
Manufacturing: cotton textiles, brick and
tile production, cement, pottery, tanned
hides, paper, candy, baked goods, Moscato
wine, gold and silver souvenirs
Foreign transactions: dominated by
tourism (in summer months about 25,000
foreigners visit every day); remittances
from Sanmarinese abroad also represent an
important net foreign inflow; commodity
trade consists primarily of exchanging
building stone, lime, wood, chestnuts,
wheat, wine, baked goods, hides, and
ceramics for a wide variety of consumer
manufactures
Monetary conversion rate: 1337.0 Italian
lire=US$1 (January 1987)
212','fc8864785712771faa37f8019348746872982f1e4925d316e2f52464d30a7a4c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fb505ce17c2d42c6bc1373981e1c8e7a1916d54612409483544a10c975606c4',1987,'ST','Sao Tome and Principe','economy',620,'GDP: $30 million (1981 est.); per capita
income $260 (1983 est.); average annual
growth rate —10% (1981 est.); average
inflation rate 10% (1981)
213
Natural resources: agricultural products,
fish
Agriculture: cash crops—cocoa, copra,
coconuts, coffee, palm oil, bananas
Fishing: catch 4,050 metric tons (1983)
Major industries: light construction, shirts,
soap, beer, fisheries, shrimp processing
Electric power: 4,300 kW capacity; 3
million kWh produced (1986), 27 kWh per
capita (1986)
Exports: $8.8 million (f.0.b., 1981 est.);
mainly cocoa (90%), copra (7%), coffee,
palm oil
Imports: $20.0 million (f.0.b., 1981 est.);
food products, machinery and electrical
equipment, fuels
Major trade partners: main partner Neth-
erlands, followed by Portugal, US, and
FRG
Aid: Western (non-US) countries, ODA
and OOF (1970-81), $583 million; US
(FY77-85), $3.7 million; Communist coun-
tries (1970-85), $23 million
Budget: (1981 est.) central government
budget $22.0 million; (1979 est.) revenues,
$15.7 million; current expenditures, $10.4
million; capital expenditures, $9.1 million
Monetary conversion rate: 46.2051
dobras=US$1 (December 1984)
Fiscal year: calendar year','76e6b10ed7b379e92200f47ef8ca2f041b3de3b8e1e92d344094c3ab00d5aa8f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e55f7815ce55920ac68d4815cb956114b6af479178a0cff09192c2e1ba447ca7',1987,'SC','Seychelles','economy',628,'GDP: $175 million, $2,670 per capita, real
growth rate 6.0% (1985)
Natural resources: fish, copra, spices
Agriculture: islands depend largely on
coconut production and export of copra;
cinnamon, vanilla, and patchouli (used for
perfumes) are other cash crops; food
crops—small quantities of sweet potatoes,
cassava, sugarcane, and bananas; islands
not self-sufficient in foodstuffs and the
bulk of the supply must be imported; fish
is an important food source
Major industries: tourism is largest indus-
try; processing of coconut and vanilla,
fishing, small-scale manufacture of con-
sumer goods, coir rope factory, tea factory
Electric power: 25,000 kW capacity; 59
million kWh produced, 880 kWh per
capita (1986)
Exports: $4.5 million (f.0.b., 1985); fish,
copra, cinnamon bark
Imports: $90 million (f.0.b., 1985); manu-
factured goods, food, tobacco, beverages,
machinery and transport equipment, and
petroleum products
Major trade partners: exports—Pakistan,
France, Reunion, UK, Mauritius; im-
ports—Bahrain, UK, South Africa, Si-
ngapore, Japan, France
Aid: Western (non-US) countries, ODA
and OOF (1978-84), $232 million; US
(FY78-85), $14 million, Communist coun-
tries (1970-85), $42 million
Budget: (1984) revenues, $61 million;
grants, $4 million; current expenditures,
$64 million; capital expenditures, $11
million; net lending, $3.5 million
Monetary conversion rate: 5.99 Seychelles
rupees=US$1 (January 1987)
Fiscal year: calendar year','6ebda6959b3be16c22f58338555c8709bf399c2336cd33a9fe2b33d21ad89a52','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('792f270c10a362c473fec8c255216e1af422057a9b1ae12c65f648c444f2ba2a',1987,'SL','Sierra Leone','economy',633,'GDP: (current factor cost) $1 billion
(1983/84 est.); real growth rate 0.5%
(1983/84)
Natural resources: diamonds, rutile,
bauxite, iron ore, gold, chromite
Agriculture: palm kernels, coffee, cocoa,
rice, yams, millet, ginger, cassava; much of
cultivated land devoted to subsistence
farming; food crops insufficient for domes-
tic consumption
Fishing: catch 53,000 metric tons (1983)
Major industries: mining (diamonds, iron
ore, bauxite, rutile), manufacturing, bever-
ages, textiles, cigarettes, construction goods,
one oil refinery
Electric power: 65,000 kW capacity; 85
million kWh produced, 21 kWh per capita
(1986)
Exports: $137 million (f.0.b., 1985); dia-
monds, iron ore, palm kernels, cocoa,
coffee
Imports: $167 million (c.i.f., 1985); ma-
chinery and transportation equipment,
manufactured goods, foodstuffs, petroleum
products
Major trade partners: UK, EC, US, Japan,
Communist countries
Budget: (1983/84) revenues, $109 million;
current expenditures, $146 million; devel-
opment expenditures, $68 million
Monetary conversion rate: 40
leones=US$1 (March 1987)
Fiscal year: 1 July-30 June','20336d4ef01928dec22b18150b269336dcb1d019786034f2ddd3911d9dca5e7f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2d48ba1460fe8f611e6fdbbded09b30b89b9a97fc982b3eb5f711d8b9ddd8bd',1987,'SG','Singapore','economy',638,'GDP: $17.25 billion (1985 est.), $6,740 per
capita; (1985 est.) real growth rate 1.9%
(1986 est.)
Agriculture: occupies a position of minor
importance in the economy, self-sufficient
in pork (but pig farming outlawed as of
1985), poultry, and eggs; must import
much of its other food requirements;
major crops—rubber, copra, fruit and
vegetables
Fishing: catch 22,76] metric tons, im-
ports—102,189 metric tons, exports 56,841
metric tons (1985)
Major industries: petroleum refining,
electronics, oil drilling equipment, rubber
processing and rubber products, processed
food and beverages, ship repair, entrepot
trade, financial services, biotechnology
Electric power: 3,486,000 kW capacity;
10,080 million kWh produced, 3,900 kWh
per capita (1986)
Exports: $22.8 billion (f.0.b., 1985); manu-
factured goods, petroleum, rubber, elec-
tronics
Imports: $26.3 billion (c.i.f., 1985); major
retained imports—capital equipment,
manufactured goods, petroleum
Major trade partners: exports—US, Ma-
laysia, Japan, Hong Kong, Thailand, Aus-
tralia, FRG; imports—Japan, US, Malaysia,','db1c7ab3d53774f9a092853704ef6e4ba4aeb0199f7d27589b0828f9add209fc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c71d8e0a7c0122ba984378f2a6c81bacc178845bfe89fbb0a9d0cd6ff582a45',1987,'SB','Solomon Islands','economy',643,'GDP: $137 million (1985), $640 per capita
Natural resources: fish, forests, agricul-
tural land, minerals (gold and bauxite)
Agriculture: dominated by coconut pro-
duction with subsistence crops of yams,
taro, bananas, rice
Electric power: 15,000 kW capacity; 30
million kWh produced, 110 kWh per
capita (1986)
Exports: $70.1 million (f.0.b., 1985); copra,
timber, fish, palm oil, seashells and shell
products
Imports: $83.2 million (c.if., 1985)
Major trade partners: exports—Japan
87%, UK 11%, Australia 3%; imports—
Australia 31%, Singapore 16%, Japan 15%,
UK 9% (1981)
Aid: economic commitments from Austra-
lia and other Western donors, $16.1 mil-
lion (1985)
Budget: (1985) million revenues, $37.4
million; expenditures, $51.0 million
Monetary conversion rate: 1.4808 So-
lomon Island dollars=US$1 (February
1986)','07221c83776453946a11f5bd48e857afde261e92ff82d861e9e00a9293c53efb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e750af376cf57b641147c905dc19e4777b05dd70b481e8c74c3f553122b0a9b3',1987,'SO','Somalia','economy',648,'GDP: $1.4 billion, about $200 per capita
(1982 est.)
Natural resources: uranium, iron, tin,
gypsum, bauxite
Agriculture: mainly a pastoral country,
raising livestock; crops—bananas, sugar-
cane, cotton, cereals
Major industries: a few small industries,
including sugar refining, tuna, beef can-
ning, textiles, iron rod plant, and petro-
leum refining
Electric power: 63,000 kW capacity; 137
million kWh produced, 17 kWh per capita
(1986)
Exports: $108 million (f.0.b., 1986 est.);
livestock, hides, skins, bananas
Imports: $407 million (c.i-f., 1986 est.);
textiles, cereals, transport equipment,
machinery, construction materials and
equipment, petroleum products; also
military materiel] in 1977
Major trade partners: exports—Saudi
Arabia 34.6%, Italy 19.6%; imports—Italy
26%, Saudi Arabia 12%, US 17% (1985)
External debt: $1.6 billion (1985 est.);
external debt service 78% of exports of
goods and services
Budget: (1985 est. in percent of GDP)
revenues and grants, 10.2%; current expen-
ditures, 8.5%; investment expenditures,
6.8%
Monetary conversion rate: official rate—
86.5 Somali shillings=US$1; legal free
market—140 Somali shiJlings=US$1 (No-
vember 1986)
Fiscal year: calendar year','c38f4090e7019b08fe73c49731f39dfc3b97d76e9348e4e82826cf88ed0b7065','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0328b13a4537dde310a35291ab17210f19794f208a30b0ab08c56ffc7972a6a0',1987,'LK','Sri Lanka','economy',656,'GDP: $6.3 billion, $390 per capita (1985);
real growth rate 5% (1984); 50% services,
26% agriculture, forestry, and fishing, 15%
manufacturing, 7% construction, 2% min-
ing and quarrying (1985)
Natural resources: limestone, graphite,
mineral sands, gems, phosphates
Agriculture: agriculture accounts for about
26% of GDP; main crops—paddy, coco-
nuts, tea, rubber
Fishing: catch 140,000 metric tons (1985
est.)
Major industries: processing of rubber,
tea, coconuts, and other agricultural com-
modities; consumer goods manufacture;
garment industry
Electric power: 982,000 kW capacity;
8,200 million kWh produced, 190 kWh
per capita (1986)
Exports: $].4 billion (f.0.b., 1985); tea,
textiles and garments, petroleum products,
coconut, rubber, agricultural products,
gems and jewelry, marine products
Imports: $2.0 billion (c.i.f., 1985); petro-
leum, machinery and equipment, textiles
and textile materials, wheat, transport
equipment, electrical machinery, sugar,
rice
Major trade partners: (1985) exports—US
(22%), UAR, lraqg, UK, FRG, Singapore,
Japan; imports—Japan, Saudi Arabia, US,
India, Singapore, FRG, UK, Iran
Budget: (1985) revenues, $1.4 billion;
expenditures, $2.0 billion
Monetary conversion rate: 28.5
rupees=US$1 (October 1986)
Fiscal year: calendar year','3e1d72782e2b98a9a46babaa7ded620d087ffadaf7e78b85ec1fb367a1d337c7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ad5e2ee32c7965c69cd1bd95809b228054238fa8cf5d05f808064e5fa3f9beb',1987,'SD','Sudan','economy',661,'GDP: $7.31 billion at current prices
(FY84), $330 per capita (FY84)
Natural resources: modest reserves of oil,
iron ore, copper, chrome, and other indus-
trial minerals
Agriculture: main crops—sorghum, millet,
wheat, sesame, peanuts, beans, barley; not
self-sufficient in food production; main
cash crops—cotton, gum arabic, peanuts,
sesame
Major industries: cotton ginning, textiles,
brewery, cement, edible oils, livestock,
soap, distilling, shoes, pharmaceuticals
Electric power: 552,000 kW capacity;
1,210 million kWh produced, 52 kWh per
capita (1986)
Exports: $557 million (f.o.b., 1985); cotton
(26%), gum arabic, livestock, peanuts,
sesame; $40 million to Communist coun-
tries (FY82)
Imports: $1,235 million (c.i.f., 1985);
textiles, petroleum products, foodstuffs,
machinery and equipment, manufactured
goods
Major trade partners: UK, FRG, US,
Saudi Arabia, France, Egypt, Japan
Budget: (FY86) public revenues $630
million, total expenditures $1,023 million,
including development expenditure of
$255 million
Monetary conversion rate: 2.50 Sudanese
pounds=US$] (October 1986) official; 5.00
Sudanese pounds=US$1 free market (De-
cember 1986)
Fiscal year: 1 July-30 June','217f90687378a7d315976112cb5d456a3d22292d67915c63c2db6986a274f401','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('105c6c3dde5ef86cd986427d354b020be7a2026a9f5e7cf318608339c3ac1649',1987,'GE','Georgia','economy',667,'GDP: $1.1 billion (1985); $2,920 per capita
(1985); real growth rate 2.0% (1985); an-
nual inflation rate 20-30% (1986)
Natural resources: forests, hydroelectric
power potential, fish, shrimp, bauxite, iron
ore, and other minerals
Agriculture: rice, bananas, palm oil, tim-
ber
Major industries: bauxite mining, alumina
and aluminum production, lumbering,
food processing
Electric power: 420,000 kW capacity;
1,610 million kWh produced, 4,230 kWh
per capita (1986)
Exports: $314 million (f.0.b., 1985); alu-
mina, bauxite, aluminum, rice, wood and
wood products
Imports: $299 million (f.0.b., 1985); capital
equipment, petroleum, iron and steel,
cotton, flour, meat, dairy products
Major trade partners: exports—26%
Netherlands, 17% US, 18% FRG; im-
ports—30% US, 21% Trinidad and Tobago,
9% Netherlands (1983)
Aid: bilateral commitments, including
Ex-lm—US (FY70-83), $2.5 million; West-
ern (non-US) countries, ODA and OOF
(1970-84), $1.4 billion
Budget: revenues, $270.9 million; expendi-
tures, $469.0 million (1985)
Monetary conversion rate: 1.78 Suriname
guilders=US$1 (August 1986)
Fiscal year: calendar year','a4e3a369408123a448bbde441f473b926767aacd8769216208b7c0160369031d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dfd033f07e82aa8a5bce01d24acf243892367705ae0e366f2c9d5ebfb5c8d2f',1987,'SE','Sweden','economy',673,'GDP: $99 billion, $11,850 per capita;
50.8% private consumption, 27.8% govern-
ment consumption, 13.1% private invest-
ment; 5.9% public investment, —0.2%
change in stock building; 0.2% net exports
of goods and services; growth rate, 2.2%;
average exchange rate 8.6] kronors=US$1
(1985)
Natural resources: zinc, iron, lead, copper,
silver, gold, forests, hydroelectric power
Agriculture: animal husbandry predomi-
nates, with milk and dairy products ac-
counting for 37% of farm income; main
crops—grains, sugar beets, potatoes; 100%
self-sufficient in grains and potatoes, 85%
self-sufficient in sugar beets
Fishing: catch 285,000 metric tons (1984);
exports $74 million, imports $195.0 million
(1985)
Major industries: iron and steel, precision
equipment (bearings, radio and telephone
parts, armaments), wood pulp and paper
products, processed foods, motor vehicles
Shortages: coal, petroleum, textile fibers,
potash, salt, oils and fats, tropical products
Crude steel: 4.8 million metric tons pro-
duced (1985), 575 ke per capita
Electric power: 39,016,000 kW capacity;
150,500 million kWh produced, 18,010
kWh per capita (1986)
Exports: $30.5 billion (f.0.b., 1985); ma-
chinery, motor vehicles, paper products,
pulp and wood, iron and steel products,
chemicals, petroleam and petroleum
products
Imports: $28.5 billion (c.i.f., 1985); ma-
chinery, petroleum and petroleum prod-
ucts, chemicals, motor vehicles, foodstuffs,
iron and steel, clothing
Major trade partners: exports—EC 47.0%
(FRG 11.4%, UK 9.9%, Denmark 8.3%),
US 11.7%, Norway 10.5%; imports—EC
58.9% (FRG 17.9%, UK 14.1%, Denmark
6.8%), US 8.4%, less developed countries
7.6%
Aid: donor—ODA and OOF economic aid
commitments (1970-84), $6 billion
Budget: (1985/86) revenues $35.87 billion,
expenditures $42.3 billion, deficit $7.7
billion
Monetary conversion rate: 7.0
kronors=US$1 (November 1986)
Fiscal year: 1 July-30 June','377e96102ebc9852f039563c9fd67108568c99391b188c31705933523f5ca416','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca33f989be159a6ebab95ac274298b27d332d32324f0c89171e5f5391bdf5535',1987,'CH','Switzerland','economy',678,'GNP: $97.1 billion, $14,030 per capita;
58% consumption, 22% investment, 13%
government, 0% net foreign balance; real
growth rate 3.2% (1985); annual average
exchange rate 2.46 Swiss francs (SF)=US$1
(1985)
Natural resources: hydroelectric power
(potential), timber, salt
Agriculture: dairy farming predominates;
less than 50% self-sufficient; food short-
ages—fish, refined sugar, fats and oils
(other than butter), grains, eggs, fruits,
vegetables, meat
Major industries: machinery, chemicals,
watches, textiles, precision instruments
Shortages: practically all important raw
materials except hydroelectric energy
Electric power: 17,690,000 kW capacity;
57,330 million kWh produced, 8,870 kWh
per capita (1986)
236
Exports: $27.4 billion (f.0.b., 1985), ma-
chinery and equipment, chemicals, preci-
sion instruments, metal products, textiles,
foodstuffs
Imports: $30.7 billion (c.i.f., 1985); ma-
chinery and transportation equipment,
metals and metal products, foodstuffs,
chemicals, textile fibers and yarns
Major trade partners: 59% EC, 21% other
developed, 17% less developed countries,
3% Communist
Aid: donor—ODA and OOF economic aid
committed (1970-84), $1.6 billion
Budget: receipts, $8.50 billion; expendi-
tures, $8.7 billion; deficit, $0.20 billion
(1985)
Monetary conversion rate: 1.69 Swiss
francs (SF)=US$1 (November 1986)
Fiseal year: calendar year
GDP: $21.46 billion (1985), $2,040 per
capita; real GDP growth rate —3% (1984)
Natural resources: crude oil, phosphates,
chrome and manganese ores, asphalt, iron
ore, rock salt, marble, gypsum
Agriculture: cotton, wheat, barley, to-
bacco; sheep and goat raising; self-
sufficient in most foods in years of good
weather
Major industries: textiles, food processing,
beverages, tobacco; petroleum—210,000
b/d production (1986), 229,000 b/d re-
fining capacity
Electric power: 2,296,000 kW capacity;
8,050 million kWh produced, 740 kWh
per capita (1986)
Exports: $1.6 billion (f.0.b., 1985); petro-
leum, textiles and textile products, tobacco,
fruits and vegetables, cotton
Imports: $3.6 billion (f.0.b., 1985); petro-
leum, machinery and metal products,
textiles, fuels, foodstuffs
Major trade partners: exports—Romania,
Italy, France, USSR; imports—lIran, FRG,
Italy, Libya
Budget: 1985—revenues $6.3 billion
(excluding aid payments); expenditures
$10.9 billion
Monetary conversion rate: 3.925 Syrian
pounds=US$1 (official rate, February
1986); several other rates are sanctioned by
the government, including a promotional
rate for specific transactions and others
guided by supply and demand
Fiscal year: calendar year
GDP: $4.2 billion (1984), $210 per capita;
real growth rate, 0.8% (1984 est.)
Natural resources: hydroelectric power
potential, large unexploited iron and coal,
gemstone and gold mines, natural gas,
nickel
Agriculture: cotton, coffee, sisal on main-
land; cloves and coconuts on Zanzibar
Major industries: primarily agricultural
processing (sugar, beer, cigarettes, sisal
twine), diamond mine, oil refinery, shoes,
cement, textiles, wood products
Electric power: 379,000 kW capacity; 830
million kWh produced, 37 kWh per capita
(1986)
Exports: $255 million (f.0.b., 1985); coffee,
cotton, sisal, cashew nuts, meat, cloves,
tobacco, tea, coconut products
Imports: $1.0 billion (c.i-f., 1985); manu-
factured goods, machinery and transport
equipment, cotton piece goods, crude oil,
foodstuffs
Major trade partners: exports—FRG, UK,
US; imports—FRG, UK, US, Iran
External debt: $2.8 billion (1983); debt
service ratio 68.1% (1984—not including
IMF)
Budget: (1984/85) revenues, $891.8 mil-
lion; current expenditures, $1.017 billion;
development expenditures, $359.5 million
239
Monetary conversion rate: 45 Tanzanian
shillings=US$1 (November 1986)
Fiscal year: 1 July-80 June','bafee0c4b4c3a260a0e9b7ddd6cf1e0ca14c45b6b88c98bf1da5525599e9535e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aa4822bfd449e37cd942321715454bff5dda2bf45120d58468648f8b3cb7b02',1987,'TG','Togo','economy',683,'GNP: $790 million (1983 est.), about $280
(1983 est.) per capita; 3.2% real growth in
1982
Natural resources: phosphates, limestone,
marble
Agriculture: main cash crops—coffee,
cocoa, cotton; major food crops—yams,
cassava, corn, beans, rice, millet, sorghum,
fish
Fishing: catch 14,556 metric tons (1983)
Major industries: phosphate mining,
agricultural processing, cement, handi-
crafts, textiles, beverages
Electric power: 116,000 kW capacity; 203
million kWh produced, 65 kWh per capita
(1986)
Exports: $191 million (f.0.b., 1984); phos-
phates, cocoa, coffee, palm kernels
Imports: $233 million (f.0.b., 1984); con-
sumer goods, fuels, machinery, tobacco,
foodstuffs
Major trade partners: ‘mostly France and
other EC countries
Budget: (1984 proj.), revenues, $184.4
million; current expenditures, $219 mil-
lion; development expenditures, $89 mil-
lion
Monetary conversion rate: 331.24 Com-
munauté Financiére Africaine (CFA)
francs=US$1 (average to midyear 1986)
Fiscal year: calendar year','8324444d0a3a9e81a6dd9e1cf0ebf821bbb0ec91c6466e9e0ec24b7488c06e92','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('361649f6d57528ab22742b7397cef0a906f28960649917a11b59f1c5f7e9ca52',1987,'TO','Tonga','economy',690,'GDP; $100 million, $1,030 per capita
(1985)
Natural resources: fish
Agriculture: largely dominated by coconut
and banana production; vanilla beans, taro,
yams, sweet potatoes, breadfruit, fruits and
vegetables
Major industry: tourism
Electric power: 5,000 kW capacity; 8
million kWh produced, 80 kWh per capita
(1986)
Exports: $7.83 million (1985 est.); coconut
oil, vanilla, copra, bananas, taro, vanilla
beans, fruits and vegetables
Imports: $41.36 million (1985 est.); textiles,
food, consumers products, machinery,
petroleum, building supplies
Major trade partners: exports—36%
Australia, 34% New Zealand, 14% US;
imports 38% New Zealand, 31% Australia,
6% Japan, 5% Fiji (1979)
Aid: $6.2 million; Australia and other
Western donors (1985 est.)
Budget: (1985 est.) revenues, 22.0 million
pa’anga; expenditures, 19.1 million pa’anga
Monetary conversion rate: .8463
pa’anga=US$1 (December 1985)
Fiscal year: 1 July-30 June','b09c61c03e24a8b8a938711ad5d1a0e7eec9c3bebed47201cc03b34f7779aa14','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c21a63ea4f9e7faac371ace976e092124e9b266e3797179fd4a16f5fff80ae87',1987,'TT','Trinidad and Tobago','economy',695,'GDP: $7.8 billion (1986 est.), $6,390 per
capita; real growth rate (1986 est.), —3.5%;
inflation rate 7.0% (1985)
Natural resources: oil, gas, petroleum,
asphalt
Agriculture: sugar, cocoa, coffee, rice,
citrus, bananas; largely dependent upon
imports of food
Fishing: catch 4,46] metric tons (1983)
Major industries: petroleum, chemicals,
tourism, food processing, cement
Electric power: 1,171,000 kW capacity;
2,720 million kWh produced, 2,260 kWh
per capita (1986)
Exports: $2.0 billion (f.0.b., 1985); petro-
leum and petroleum products, ammonia,
fertilizer, chemicals, sugar, cocoa, coffee,
citrus; includes exports of oil under pro-
cessing agreement
245
Imports: $1.4 billion (f.0.b., 1985); crude
petroleum (33%), machinery, fabricated
metals, transportation equipment, manu-
factured goods, food, chemicals; includes
imports under processing agreement
Major trade partners: (1984 est.) exports—
US 56%, CARICOM 10%, UK 8%; im-
ports—US 37%, UK 10%, CARICOM 7%
Aid: bilateral commitments, US, including
Ex-lm (FY70-85), $370 million; (1970-84)
other Western countries, ODA and OOF,
$369 million
Budget: (1985 est.) consolidated central
government revenues, $2.6 billion; expen-
ditures, $3.0 billion (current, $2.4 billion;
capital, $438 million)
Monetary conversion rate: 3.60 Trinidad
and Tobago dollars=US$1 (August 1986)
Fiscal year: calendar year','b567197f03c10938be6d818330fbb3e34751a29cb6063406e296e703802c955e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc05f881329d71c327eb2f0847251fe561b0fe5a2cfd8405d3e487482f397337',1987,'TN','Tunisia','economy',700,'GNP: $9.0 billion, $1,250 per capita (1985
est.); 63% private consumption, 16.5%
government consumption, 30.5% gross
fixed capital formation; real growth rate,
4.6% (1985)
Natural resources: oil, phosphates, iron,
ore, lead, zinc
Agriculture: not food self-sufficient; main
crops—cereals (barley and wheat), olives,
grapes, citrus fruits, and vegetables
Major sectors: agriculture, manufacturing,
mining (phosphate), energy (petroleum,
natural gas), services (transport, telecom-
munications, tourism, government)
Electric power: 1,502,000 kW capacity;
3,820 million kWh produced, 510 kWh
per capita (1986)
Exports: $1.6 billion (f.0.b., 1985); 40%
hydrocarbons, 18% agricultural, 18%
phosphates and chemicals
Imports: $2.9 billion (c.i.f., 1985); 57%
industrial goods, 13% hydrocarbons, 12%
food, 18% other
Major trade partners: France, Italy, FRG,
US
Tourism and foreign worker remittances:
$780 million (1985)
Budget: (1985 est.) total revenues, $3.04
billion; operating budget, $2.5 billion;
capital budget, $1.2 billion
Monetary conversion rate: 1.14 Tunisian
dinars (TD)=US$1 (7 May 1986)
Fiscal year: calendar year
GNP: $52.9 billion, $1,020 per capita;
7.8% real growth, 6.3% average annual
real growth (1984-86); inflation rate 33.7%
(1986)
Natural resources: antimony, coal, chro-
mium, mercury, copper, borate, oil
Agriculture: main products—cotton,
tobacco, cereals, sugar beets, fruits, nuts,
and livestock products; self-sufficient in
food in average years; a legal producer of
opium poppy for the pharmaceutical trade
Major industries: textiles, food processing,
mining (coal, chromite, copper, boron
minerals), steel, petroleum, construction
Crude steel: 3.5 million tons produced, 70
kg per capita (1984)
Electric power: 9,765,000 kW capacity;
38,490 million kWh produced (1986), 740
kWh per capita (1986)
Exports: $7,958 million (f.0.b., 1985);
cotton, tobacco, fruits, nuts, metals, live-
stock products, textiles, clothing, cement,
leather, glass, ceramics
Imports: $1],344 million (c.i.f., 1985);
crude oil, machinery, transport equipment,
metals, pharmaceuticals, dyes, plastics,
rubber, mineral fuels, fertilizers, chemicals
Major trade partners: (1986) exports—
18.2% FRG, 11.7% Iran, 10.7% Iraq, 6.6%
Italy, 5.4% US; imports—15.9% FRG,
10.6% US, 8.4% lraq, 7.7% Italy, 5.6%','688c6cfd68eefde673eab9df8645c564e8f88f54263e371e1e6722d78e8d3ba4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8be08d5d3fa5196c2fda58ff5ad4f6121b165141ea939854a3984af26ba9e64',1987,'TV','Tuvalu','economy',708,'GNP: $4 million (1984), $500 per capita
Agriculture: limited; coconut palms, copra
Major industry: copra
Electric power: 2,600 kW capacity; 3
million kWh produced, 380 kWh per
capita (1986)
Exports: $1.0 million (1983 est.)
Imports: $2.8 million (1983); food and
mineral fuels
Major trade partners: UK, Australia
Aid: $4.2 million (1983); Western (non-US)
countries, ODA (1970-79), $22 million
Budget: (1983 est.) revenues, $2.59 million;
expenditures, $3.6 million
Monetary conversion rate: 1.54 Australian
dollars=US$1 (November 1986)','d3bde901426b5bc40c1c787e876622860f2550fde746374dfdb2874be140d593','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b4c77413d289bc412402b8345b46424251333e1849b91d13badd9dec8cf877',1987,'UG','Uganda','economy',713,'GDP: $5.9 billion; $220 per capita (1983
est.)
Natural resources: copper, cobalt, lime-
stone
Agriculture: cash crops—coffee (150,000
metric tons produced (1984/85 est.), cot-
ton, tobacco, tea, sugar, fish, livestock
Major industries: agricultural processing
(coffee, plywood, beer)
Electric power: 164,000 kW capacity; 287
million kWh produced, 18 kWh per capita
(1986)
Exports: $352 million (f.0.b., 1985/86 est.);
coffee (over 90%), cotton, tea
Imports: $325 million (c.i.f., 1985/86 est.);
petroleum products, machinery, cotton
piece goods, metals, transport equipment,
food
Major trade partners: exports—27% US,
14% UK, 9% Spain; imports—39% Kenya,
17% UK, 7% Japan (1985)
Budget: in percent of GDP—tax revenues
11.6%, grants 1.6%, expenditures, 15.5%
(FY85/86)
Monetary conversion rate: 400 Uganda
shillings=US$1 (December 1986)
Fiscal year: 1 July-30 June','9a1ee48e926c9afb2c1f9582e3a05fc88715fa3fa4187759d4f354200c06405b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2252ef296f0ac39914372069b3287e93b3e5558055d5423cf745a0776cfcac96',1987,'AE','United Arab Emirates','economy',718,'GDP: $24.0 billion, $18,900 per capita;
real growth - 3.0% (1986 est.)
Natural resources: oil and natural gas; oil
production 1.38 million b/d (1986)
Agriculture: food imported; some dates,
alfalfa, vegetables, fruit, tobacco raised
Electric power: 5,158,000 kW capacity;
16,440 million kWh produced, 12,400
kWh per capita (1986)
Exports: $9.8 billion (f.0.b., 1986); $8.3
billion in crude oil, $1.45 billion consisting
mostly of gas, reexports, dried fish, dates
Imports: $6.6 billion (f.0.b., 1986); food,
consumer and capital goods
Major trade partners: Japan, EC, US
Budget: current expenditures, $3.5 billion;
development, $0.14 billion; revenue, $3.1
billion (1985)
Monetary conversion rate: 3.67 UAE
dirhams=US$1 (October 1986)
Fiscal year: calendar year','f6360d09864d6b1afa6bb0ca3d6cc24acf1f3717afcaf4cb07a2451620d8c344','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe5fd7160609c96113dceb59bf782787c6ae4a08c8ac084a8112cfad8711a783',1987,'US','United States','economy',727,'GNP: $3,988.5 billion (1985); $2,186.5
billion (65%) personal consumption, $501.0
billion (14.9%) private investment, $701.8
billion (20.9%) government, - $25.9 billion
(—.1%) net exports; $16,710 per capita;
2.3 % real growth (1985)
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, baux-
ite, gold, iron, mercury, nickel, potash,
silver, tungsten, zinc
Agriculture: food grains, feed crops, oil-
bearing crops, cattle, dairy products
Fishing: catch 4,143 thousand metric tons
(1983); 5.5 kg per capita consumption
(1981); imports $4.173 billion (1981);
exports $1.156 billion, (1981); est. value,
$2.388 billion (1981)
Crude steel: 80.1 million metric tons
produced, 335 kg per capita (1985)
Natural gas: 16.5 trillion cubic feet pro-
duced (1985)
Electric power: 717,643,000 kW capacity;
2,733,630 billion kWh produced, 11,850
kWh per capita (1986)
Exports: $213,144 billion (f.0.b., 1985);
machinery, chemicals, transport equip-
ment, agricultural products
Imports: $361,627 billion (c.i.f., 1985);
crude and partly refined petroleum, ma-
chinery, transport equipment (mainly new
automobiles)
Major trade partners: exports—$4,030
million Canada, $1,925.7 million Japan,
$1,015.7 million Mexico, $842.8 million
UK, $651.4 million FRG (1985); imports—
$6,153.8 million Canada, $6,451.8 million
Japan, $1,479.4 million Mexico, $1,300.1
million UK, $1,807.5 million FRG (1985)
Aid: including Ex-Im (FY80-85), $54.2
billion
Military transfers: (FY80-85) $27.4 billion
Budget: (1986) receipts, $769.1 billion;
outlays, $989.8 billion; deficit, $220.7
billion
Fiscal year: 1 October-30 September','8c84a9f14c38258a8d2524110adb6e6ce0cfb7f0f5d1eeda0d20bd3f64151878','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c91f2f4e8614b3b9e7283d83bb8292222f2aa48ad1212359e2597e1fab757dd',1987,'UY','Uruguay','economy',732,'GDP: $5.2 billion, $1,760 per capita
(1986); 89% consumption, 138% gross invest-
ment, —2.0% foreign; real growth rate
1986, 3.0%
Natural resources: soil, hydroelectric
power (potential), minor minerals
Agriculture: large areas devoted to exten-
sive livestock grazing; main crops—wheat,
rice, corn, sorghum; self-sufficient in most
basic foodstuffs
Major industries: meat processing, wool
and hides, rice, textiles, footwear, leather
apparel, tires, cement, fishing, petroleum
refining
Electric power: 1,379,000 kW capacity;
8,730 million kWh produced, 1,260 kWh
per capita (1986)
Exports: $960 million (f.0.b., 1986); meat,
textiles, wool, hides, leather products, fish,
rice, furs
Imports: $708 million (f.0.b., 1986 est.);
fuels and lubricants (87%), metals, machin-
ery, transportation equipment, industrial
chemicals
Major trade partners: exports—20%
Brazil; 15% US, imports—39% LAIA (13%
Brazil, 11% Argentina), 15% EC, 7% US
(1986 est.)
Aid: US authorized, including Ex-Im
(FY70-84), $78 million; other Western
countries, ODA and OOF (1970-84) $175
million; Communist countries (1970-85),
$65 million
Military transfers: US authorized (FY70-
85) $39 million
258
Budget: (1986 est.) revenues, $709 million,
expenditures, $90] million
Monetary conversion rate: 173.36 new
pesos=US$1 (November 1986)
Fiscal year: calendar year','601bb8dcdd2ca7035bd7a3bfdc809ce3ab9af6562cc52e9a257867fcaefd4976','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbdc134608e428ab74a1aa962dfe9e53cba2e70de78f3834742d522dfa0e6f52',1987,'VU','Vanuatu','economy',737,'GDP: $79 million, $600 per capita (1984);
GDP decline of 2.0% (1986 est.)
Natural resources: manganese, hardwood
forests, cattle
Agriculture: export crops of copra, cocoa,
coffee, some livestock and fish production;
subsistence crops of copra, taro, yams
Fishing: catch, 2,470 metric tons (1983)
Major industries: fish-freezing, canneries,
tourism
Electric power: 10,000 kW capacity; 20
million kWh produced, 150 kWh per
capita (1986)
Exports: $18.1 million (1985); 24% copra,
59% frozen fish, meat
Imports: $52.3 million (1985); 18% food
Aid: Australia (1970-84), $43.0 million
259
Monetary conversion rate: 118.57
vatu=US$1; 1.55 Australian dollars=US$1
(6 February 1986)
The Vatican City, seat of the Holy See, is
supported financially by contributions
(known as Peter’s pence) from Roman
Catholics throughout the world; some
income derived from sale of Vatican
postage stamps and tourist mementos, fees
for admission to museums, and sale of
260
publications; industrial activity consists
solely of printing and production of a
small amount of mosaics and staff uni-
forms; worldwide banking and financial
activities; the Institute for Religious Works
(IOR) carries out fiscal operations and
invests and transfers funds of Roman
Catholic religious communities throughout
the world; the Administration of the
Patrimony of the Holy See manages the
Holy See’s capital assets
Electric power: 3,000 kW capacity
(1986)—power supplied by Italy
Monetary conversion rate: the Vatican
issues its own coinage, which is inter-
changeable with the Italian lira; 1,337.0
lira=US$1 (January 1987)
GDP: $57 billion (1986 est.), $3,200 per
capita (1986 est.), 58% private consump-
tion, 13% public consumption, 16% gross
investment (1986); real growth rate 3%
(1986); 11.5% inflation rate (1986)
Natural resources: petroleum, natural gas,
iron ore, gold, bauxite, other minerals,
hydroelectric power
Agriculture: cereals, fruits, sugar, coffee,
rice; an illegal producer of cannabis for
the international drug trade
Fishing: catch 301,372 metric tons (1985);
exports $31.9 million (1985), imports $30.0
million (1982)
Major industries: petroleum, iron-ore
mining, construction, food processing,
textiles, steel, aluminum, motor vehicles
Crude steel: 2.8 million metric tons pro-
duced (1985), 160 kg per capita
Electric power: 17,000,000 kW capacity;
50,240 million kWh produced, 2,820 kWh
per capita (1986)
Exports: $12.3 billion (f.0.b.1985) petro-
leum (84%)
Imports: $8.2 billion (c.i-f., 1985)
Major trade partners: imports—50% US,
6% Italy, 5% Japan, 5% FRG, 4.5%
France, 4% Brazil, 3% UK; exports—41%
US, 17% Netherlands Antilles, 7% FRG,
5% Canada, 4% Italy (1985)
Budget: revenues, $12.2 billion; expendi-
tures, $16.6 billion (1987 est.)
Venezuela (continued)
Monetary conversion rate: (official) 7.5
bolivares=US$1 (November 1986)
Fiscal year: calendar year','3b137d26749aa27e0f609c46e3c40d21044fc50851bd93ae26f6f20888e16157','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec292d17f3094887de0ecaad8eb154ab42458a947ead025e0fcd62cc8186b823',1987,'WF','Wallis and Futuna','economy',742,'GDP: Colonial Francs Pacifique (CFP)
1,100 million (est. 1985)
Agriculture: dominated by coconut pro-
duction, with subsistence crops of yams,
taro, bananas
Electric power: 1,000 kW capacity; 1
million kWh produced, 70 kWh per capita
(1986)
Exports: negligible
Imports: $3.4 million (1977); largely food-
stuffs and some equipment associated with
development programs
Aid: (1978) France, European Develop-
ment Fund, $2.6 million
Monetary conversion rate: 138.23 Colo-
nial Francs Pacifique (CFP)=US$1 (De-
cember 1985)','13accd6c577a75eeae943578842a0b436b3249f17d5b9e5757bf280f95c87fef','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16f614dc67ef1fd713f824b6ea6d83fa6bfa64451b94ccd21b63fe32bb36fda8',1987,'EH','Western Sahara','economy',747,'Natural resources: phosphates, iron ore
Agriculture: practically none; some barley
is grown in nondrought years; fruit and
vegetables in the few oases; food imports
are essential; camels, sheep, and goats are
kept by the nomadic natives; cash econ-
omy exists largely for the garrison forces
Major industries: phosphate, fishing, and
handicrafts
Shortages: water
Electric power: 60,000 kW capacity; 78
million kWh produced, 850 kWh per
capita (1986)
Exports: up to $5 million in phosphates,
all other exports valued at under $3 mil-
lion (1982)
Imports: up to $30 million (1982); fuel for
fishing fleet, foodstuffs
Major trade partners: Morocco claims
administrative control over Western Sa-
hara and controls all trade with the coun-
try; Western Sahara trade figures are
included in overall] Moroccan accounts
Aid: previously received small amounts
from Spain; Morocco is now the major
source of support
Monetary conversion rate: uses Moroccan
dirham; 10.06 dirham=US$1 (1984)
GDP: $86.8 million, $532 per capita (1985)
Natural resources: hardwood forests, fish
Agriculture: cocoa, bananas, copra; staple
foods include coconuts, bananas, taro,
yams
Major industries: timber, tourism, light
industry
Electric power: 62,000 kW capacity; 79
million kWh produced, 480 kWh per
capita (1986)
Exports: $16 million (f.0.b., 1985); copra
43.3%, cocoa 32.3%, timber 2.0%, mineral
fuel, bananas
Imports: $63 million (c.i.f., 1985); food
30%, manufactured goods 25%, machinery
Major trade partners: exports—31% FRG,
26% New Zealand, 12% US, 2% Australia;
imports—30% US, 28% New Zealand, 10%
Australia, 6% UK (1981)
Aid: US (FY70-85), $13 million; Western
(non-US) countries, ODA and OOF
(1970-84), $195 million
Budget: (1982 est.) revenues, $36.9 million;
expenditures, $37.6 million; development
expenditure, $34.9 million
Monetary conversion rate: 2.256 WS
tala=US$1 (November 1986)
GDP: $3.1 billion, $520 per capita (1984)
Natural resources: petroleum, rock salt,
marble; small deposits of coal, nickel, and
copper
Agriculture: sorghum and millet, qat (a
mild narcotic), cotton, coffee, fruits and
vegetables, livestock
Major industries: small scale production
of cotton textiles and leather goods; food
processing; handicrafts; fishing; small
aluminum products factory; cement
Electric power: 254,000 kW capacity; 556
million kWh produced, 240 kWh per
capita (1986)
Exports: $9.5 million (f.o.b., 1985); aat,
cotton, coffee, hides, vegetables
Imports: $1.2 billion (f.0.b., 1985); textiles
and other manufactured consumer goods,
petroleum products, sugar, grain, flour,
other foodstuffs, and cement (one of the
worst export/import ratios in the world)
Major trade partners: exports (1985)—
41% US, 14% PDRY, 12% Japan; imports
(1985)—10% Italy, 9% Saudi Arabia, 9%
Japan, 8% UK
Budget: (1985 est.) total receipts, $942
million; current expenditures, $946 mil-
lion; development expenditures, $580
million
Monetary conversion rate: 7.44
rials=US$1 (November 1986)
Fiscal year: 1 July-30 June','cf437be78ad99185d98763b5c33ad72b025e2991f0f5db6fad8e9950a46191c9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3b23b693303f7b6603e5dc141ec9fec73d8dc23240bfbf61274959d1640472',1987,'ZM','Zambia','economy',754,'GDP: $2.3 billion (1985), $340 per capita;
real growth rate 3.4% (1985 est.)
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, uranium,
hydroelectric power
Agriculture: corn, tobacco, cotton; net
importer of most major agricultural prod-
ucts
Major industries: copper mining and
refinery, transport,, construction, foodstuffs,
beverages, chemicals, textiles, and fertilizer
Electric power: 1,900,000 kW capacity;
11,100 million kWh produced, 1,570 kWh
per capita (1986)
Exports: $788 million (f.0.b., 1985); cop-
per, zinc, cobalt, lead, tobacco
Imports: $513 million (c.i.f., 1985); ma-
chinery, transport equipment, foodstuffs,
fuels, manufactures
Major trade partners: EC, Japan, South
Africa, US
Budget: revenues $610 million; expendi-
tures $733 million (1984 est.)
Monetary conversion rate: 13.5 Zambian
kwachas=US$1 (December 1986)
Fiscal year: calendar year','32abf44552d9a77a25d6eeb8c11bc6d79bc0748227da1cc146ab20b2703003cf','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a57c6597758900d9e10667c6bb5e1deb88b169700048f05fd7bfca557a05917',1987,'ZW','Zimbabwe','economy',759,'GDP; $2.3 billion, $260 per capita; real
growth 6.0% (1985)
Natural resources: coal, chrome, asbestos,
gold, nickel, copper, iron ore, vanadium,
lithium
Agriculture: tobacco, corn, tea, sugar,
cotton; livestock
Major industries: mining, steel, textiles,
chemicals, vehicles
Electric power: 1,600,000 kW capacity;
4,670 million kWh produced, 520 kWh
per capita (1986)
Exports: $1.1 billion (f.0.b., 1985), includ-
ing net gold sales and reexports; tobacco,
asbestos, cotton, copper, tin, chrome, gold,
nickel, meat, clothing, sugar, iron ore,
silver
Imports: $930 million (f.0.b. 1985); ma-
chinery, petroleum products, wheat, trans-
port equipment
Major trade partners: South Africa, UK
Aid: Western (non-US) countries, ODA
and OOF (1970-84), $1.3 billion; US,
including Ex-lm (1980-85), $327 million;
Communist countries (1970-85), $118
million
Budget: (CY85) revenues, $1.42 billion;
expenditures, $1.81 billion
Monetary conversion rate: 1.70 Zimbab-
wean dollars=US$1 (November 1986)
Fiscal year: 1 July-30 June
GNP: $60.0 billion (1985), $3,110 per
capita; 8.0% real growth (1986)
Natural resources: small deposits of coal,
natural gas, limestone, marble, and asbes-
tos
Agriculture: rice, sweet potatoes, sugar-
cane, bananas, pineapples, citrus fruits;
food shortages—wheat, corn, soybeans
Fishing: catch 930,582 metric tons (1983)
Major industries: textiles, clothing, chemi-
cals, electronics, food processing, plywood,
sugar milling, cement, shipbuilding
Electric power: 16,200,000 kW capacity;
54,000 million kWh produced, 2,760 kWh
per capita (1986)
Exports: $30.4 billion (f.0.b., 1984 est.);
20.5% textiles, 18.8% electrical machinery,
9% general machinery and equipment, 9%
275
telecommunications equipment, 7.4% basic
metals and metal products, 5.4% food-
stuffs, 2.5% plywood and wood products
Imports: $21.6 billion (c.i-f., 1984 est.);
25% machinery and equipment, 17.7%
crude oil, 11.9% chemical and chemical
products, 6.7% basic metals, 6.3% food-
stuffs
Major trade partners: exports—49% US,
10% Japan; imports—29% Japan, 23% US,
8.6% Saudi Arabia (1983)
Aid: US authorizations, including Ex-Im
(FY46-82), $4.6 billion; Western (non-US)
countries, ODA and OOF (1970-84), $414
million
Budget: central government expenditure,
$42.5 billion (FY83)
Monetary conversion rate: NT (New
Taiwan) 40.39 dollars=US$1 (September
1985)
Fiscal year: 1 July-30 June
GNP: West Bank—$1.1 billion (1983);
Gaza Strip—$550 million (1983)
Agriculture: olives, citrus, and other fruits,
vegetables, beef, and dairy products
Major industries: the Israelis have estab-
lished some small-scale modern industries
in the settlements and industrial centers (3
in West Bank and J in Gaza Strip); gener-
ally small family businesses that produce
cement, textiles, soap, olive wood carvings,
and mother-of-pearl souvenirs
Electric power: the Israel Electric Corpo-
ration, Ltd., exported 285 million kWh
during 1985 (exported is understood to
mean power provided to occupied territo-
ries); West Bank—bulk of installed capac-
ity contained in two diesel power plants:
Jerusalem-Shoufat plant (22,000 kW),
which is owned and operated by the East
Jerusalem Electric Co., and Nablus plant
(19,600 kW), which is owned and operated
by the Nablus municipality; total esti-
mated capacity for all West Bank power
plants is 45,000 kW (1985); 59 million
kWh produced (1985), 63 kWh per capita
(1986); Gaza Strip—no known installed
capacity; power probably obtained from','f04ed6f6aef89c88edf57b729b262e442a7ef078dcb70edadb12536fa4f3ecb2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e578c09c425dcb0c720956b61a02b2002ef300b73cc987c5205d986ceffabd',1987,'','','raw',1,'aie iy re} ‘5
ee | reas
sh
Oe
\\ “tu
A
een f
en Ox *
nelecaya, ain ae
Rice hae
ie an Hale
ths
aie nex
ae }
Si se = se |
Ai yi ae a an) Mies
‘|
ti
‘ell! «!
UNIVERSITY OF
ILLINOIS LIBRARY
AT URBANA-CHAMPAIGN
BOOKSTACKS
eV? . a
eee ae |
=. te Red “a
The piled
World
Factbook
1987
an a a b&b 2 & &» @ , .
A07 GEEEAPLOLLS
LEE: FEAUA ARAYA AUE EEL E SS
LLL AGRALARALLLLOLLLLS
LUUBAE Aa?
CPAS WF 87-001
US Government officials should obtain copies of
The World Factbook directly from their own
organization or through liaison channels from the
Central Intelligence Agency.
Requesters in the Department of Defense may
obtain copies from:
Defense Intelligence Agency
RTS-2C
Washington, D.C. 20340-3344
Tel: (202) 373-3869 or Autovon 243-3869
Requesters in the Department of State may
obtain copies from:
Department of State
INR/IC/CD
Room 8646 New State
Washington, D.C. 20520
Tel: (202) 647-9673.
Requesters outside the US Government may
purchase copies from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
Tel: (202) 783-3238
Requesters outside the US Government may
obtain a subscription from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4630
or: Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
Tel: (202) 287-9527
Requesters outside the US Government may
purchase this publication in photocopy or micro-
form from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4650
or: Photoduplication Service
Library of Congress
Washington, D.C. 20540
Tel: (202) 287-5640
SD
{c)
Central
Intelligence
Agency
DOC.
PREX 3.1%:
a7
The
World
Factbook
1987
The World Factbookis |. vi .
by the Directorate of 1k_———————
Central Intelligence Ag
United States Governm
style, format, coverage,
designed to meet their
requirements.
Comments and queries
may be addressed to:
Central Intelligence Age yyp
Attn: Public Affairs
Washington, D.C. 20508
(703) 351-2053
CPAS WF 87-001
JS
AT USERS 7
a N Fy
*CHangslNors
(Supersedes CR WF 86-001)
June 1987
Contents
Page
Notes, Definitions, and Abbreviations - ix
Afghanistan = 2a = 1
Albania — = © = . 2
Algeria 5 3
Andorra ue 5
Angola : 6
Anguilla Se 7
Antigua and Barbuda _ 8
Argentina a)
Aruba - ll
Australia - ae 12
Austria —_ -£ 13
Bahamas, The aaa 15
Bahrain 16
Bangladesh a 17
Barbados 19
Belgium : ; 7. 20
Belize — 22
Benin 23
Bermuda : 25
Bhutan 7 _ 26
Bolivia 27
Botswana s 28
Brazil - 30
British Indian Ocean Territory 31
British Virgin Islands _ 32
Brunei 33
Bulgaria ee. |
Burkina 36
Burma 37
Burundi 38
Cambodia 40
Cameroon ——— 41
Canada 7 - 42
Cape Verde _ 44
Cayman Islands a =D
Central African Republic __ a 46
Chad 47
Chile 7 ; —- 49
China (Taiwan entry on page 274) 50
Christmas Island _ __ 62
Colombia _ 5 — =s * 53
Comoros 54
iii
Page','daf214824bf82086b8691017bec1ceaba294fe081946c7faba62d8054df235b0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b33697448706a733e86db4b0e5981366f142ae16086473c4a79bcc769a1dbd',1987,'GA','Gabon','raw',2,'Gambia, The
Gaza Strip (see West Bank and Gaza Strip entry on page 276)
German Democratic Republic (East Germany)
Congo 55
Cook Islands 57
Costa Rica 58
Cuba 59
Cyprus 61
Czechoslovakia 62
Denmark 64
Djibouti 65
Dominica 66
Dominican Republic 67
Ecuador 69
Egypt 70
EI Salvador 72
Equatorial Guinea 74
Ethiopia 75
Falkland Islands (Islas Malvinas) 76
Faroe Islands 77
Fiji 78
Finland 79
France 81
83
84
85
87
Germany, Federal Republic of (West Germany) 90
Ghana 91
Gibraltar 93
Greece 94
Greenland 95
Grenada 96
Guadeloupe 98
Guatemala 99
Guernsey 101
Guinea 102
Guinea-Bissau 103
Guyana 104
Haiti 105
Honduras 107
Hong Kong 108
Hungary 110','346f26ae431a5b5165b1437fd11704e6122181ac867b621df4830e3946960414','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ac105d8c37c3675b165771c3fde77280b94faf1d5a27ca5d43bb315005b5cc4',1987,'MZ','Mozambique','raw',3,'N Namibia 171
Nauru 172
Nepal 173 :
Netherlands 174
Netherlands Antilles 176
New Caledonia 177
New Zealand 178
Nicaragua 180 _
Niger 182
Nigeria 183
Niue 184
Norfolk Island 185,
Norway 186 — .
O Oman 188
P Pakistan 189
Panama 191
Papua New Guinea 193
Paraguay 194 |
Peru 195
Philippines WT
Pitcairn Islands 198
Poland 199 i
Portugal 2000
Q Qatar 202 -
R Reunion 203 7
Romania 205
Rwanda 206 x
S St. Christopher and Nevis 207
St. Helena 208 -
St. Lucia 209 ;
St. Vincent and the Grenadines 210 © =
San Marino Pt :
Sao Tome and Principe 213
Saudi Arabia 214
Senegal 215
Seychelles 216
Sierra Leone 218 =
Singapore 219
Solomon Islands 220
Somalia 221 :
South Africa 223
Soviet Union 224
Spain 226
Page
Sri Lanka 228
Sudan 230
Suriname 231
Swaziland 232
Sweden 234
Switzerland 235
Syria 237
Taiwan (see Taiwan entry on page 274)
Tanzania 238
Thailand 240
Togo 241
Tokelau 242
Tonga 243
Trinidad and Tobago 244
Tunisia 246
Turkey 247
Turks and Caicos Islands 249
Tuvalu 250
Uganda 251
United Arab Emirates 252
United Kingdom 253
United States 255
Uruguay 257
Vanuatu 259
Vatican City 260
Venezuela 261
Vietnam 262
Wallis and Futuna 263
West Bank (see West Bank and Gaza Strip entry on page 276)
Western Sahara 264
Western Samoa 265
Yemen Arab Republic (North Yemen) 266
Yemen, People’s Democratic Republic of (South Yemen) 267
Yugoslavia 269
Zaire 270
Zambia 272
Zimbabwe 273
Taiwan 274
West Bank and Gaza Strip 276
vii
Page
Appendixes
A. The United Nations System 278 | =,
B. International Organizations 279
C. Country Membership in International Organizations 282
D. Mathematical Conversions 290
Maps
I. The World (Guide to Regional Maps)
Il. North America
IV. South America
V. Europe
VI. Middle East
VII. Africa :
VIIL. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
_ XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
viii
Notes, Definitions,
and Abbreviations
There have been some significant changes in this edition. A new
Geography section has replaced the former Land and Water sections.
Entries in the new section include area (total and land), comparative
area, land boundaries, coastline, maritime claims, boundary disputes,
climate, terrain, land use, environment, and special notes. In the
Government section, a new entry on dependent areas has also been
added.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate
of all surfaces delimited by international boundaries and/or coastlines,
excluding inland water bodies (lakes, reservoirs, rivers). Comparative
areas are based on total area equivalents.
Boundary disputes: Every international land boundary in dispute
from the “Guide to International Boundaries” published by the
Department of State is included; the absence of this entry or
“none” indicates no boundaries are in dispute. Additional information
may follow that is border- or frontier-relevant, such as maritime
disputes, geopolitical questions, or irredentist issues. However, inclu-
sion does not necessarily constitute official acceptance or recognition
by the US Government.
Contributors: The data are provided by the Central Intelligence
Agency, the Defense Intelligence Agency, the Bureau of the Census,
and the Department of State.
Country abbreviations:
CAR Central African Republic
FRG Federal Republic of Germany (West Germany)
GDR ~— German Democratic Republic (East Germany)
PDRY People’s Democratic Republic of Yemen (South
Yemen)
UAE United Arab Emirates
UK United Kingdom
US United States
USSR Union of Soviet Socialist Republics (Soviet Union)
YAR Yemen Arab Republic (North Yemen)
Dates of information: In general, information available as of 1
January 1987 was used in the preparation of this edition, with the
following exceptions: population figures are projected for 1 July 1987,
with the average annual population growth rates estimated for mid-
1986 through mid-1987; major political events have been updated
through 26 March 1987; military age figures are projected for
1987-91.
Notes, Definitions,
and Abbreviations (continued)
Economic abbreviations:
ave. average
bbl barrel (159 liters, 42 gallons)
b/d barrel(s) per day
cif cost, insurance, and freight
est. estimate
Ex-Im Export-Import Bank of the United States
f.o.b. free on board
GDP gross domestic product
GNP gross national product
kw kilowatt
kWh kilowatt-hour
ODA official development assistance
OOF other official lows
proj. projected
International organization abbreviations: see Appendix B
Land use abbreviations:
NA% data not available
NEGL% negligible (magnitude of data is less than 0.5%)
0% none (a determined value, not the absence of data)
Maritime claims: Inclusion of a claim does not necessarily constitute
official acceptance or recognition by the US Government. Also, the
proximity of neighboring states may prevent some national claims
from being fully extended.
Money: All money figures are in US dollars unless otherwise
indicated.
Political entities: Some of the countries, entities, dependencies, areas
of special sovereignty, and governments included in this publication
are not independent, and others are not officially recognized by the
US Government.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY) or otherwise.','8275ce3cde4e93560afb1132dee796795ca3553be35f6ad119c72588ec6a3144','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

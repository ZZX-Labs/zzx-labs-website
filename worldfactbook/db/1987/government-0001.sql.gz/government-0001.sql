SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a7afc45367f4ec86c242d2e26516a8fe9b4e980fa83e80bdfefb61cfba0cbcd',1987,'AF','Afghanistan','government',6,'Official name: Democratic Republic of
Type: Communist regime backed by
multidivisional Soviet force
Capital; Kabul
Administrative divisions: 29 provinces
with centrally appointed governors
Legal system: not established; has not
accepted compulsory ICJ jurisdiction
Branches: Revolutionary Council acts as
legislature and final court of appeal;
Chairman of Council acts as chief of state;
Cabinet and judiciary responsible to Coun-
cil; Presidium chosen by Council has full
authority when Council not in session;
Loya Jirga (Grand National Assembly)
supposed to convene eventually and ap-
prove permanent constitution
Government leaders: NAJIB, General
Secretary, People’s Democratic Party of
Afghanistan (since May 1986); Haji
Mohammad CHAMKANI, Acting Chair-
man of the Revolutionary Council (since
November 1986); Soltan Ali
KESHTMAND, Prime Minister (since June
1981)
Suffrage: universal from age 18
Political parties and leaders: the ruling
People’s Democratic Party of Afghanistan
(PDPA) has two factions—the Parchami
faction has been in power since December
1979; members of the deposed Khalai
faction continue to hold some important
posts
Communists: the PDPA claims 160,000
members (1986)
Other political or pressure groups: the
military and other brauches of internal
security are being rebuilt by the Soviets;
insurgency continues throughout the coun-
try; widespread opposition on religious
grounds; widespread anti-Soviet sentiment
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IAEA, IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, INTELSAT, ITU, NAM,
UN, UNESCO, UPU, WFTU, WHO,
WMO, WTO, WSG; suspended from OIC
in January 1980','b9266ff6bc891bf95cd63b1dd4806521a5151550c50abf3ddaa9b2336e916e70','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb715d5d9dd0ae7c5a4e788bcb429d54a4359c4ac0b986840a1386012a1a68cf',1987,'AL','Albania','government',12,'Official name: People’s Socialist Republic
of Albania
Type: Communist state
Capital: Tirané
Administrative divisions: 26 rrethet
(districts)
Legal system: based on constitution
adopted in 1976; judicial review of legisla-
tive acts only in the Presidium of the
People’s Assembly, which is not a true
court; has not accepted compulsory ICJ
jurisdiction
National holiday: Liberation Day, 29
November
Branches: legislature (People’s Assembly),
Council of Ministers, judiciary
Government leaders: Ramiz ALIA, Chair-
man, Presidium of the People’s Assembly
(chief of state, since November 1982); Adil
CARCANI, Chairman, Council of Minis-
ters (premier, since November 1982)
Suffrage: universal and compulsory over
age 18
Elections: national elections held every
four years; last elections 1 February 1987
Political parties and leaders: Albanian
Workers Party only; First Secretary,
Ramiz Alia (since April 1985)
Communists: 147,000 party members
(November 1986); 4.9% of population
Member of: CEMA, FAO, IAEA, IPU,
ITU, UN, UNESCO, UPU, WFTU, WHO,
WMO; has not participated in CEMA
since rift with USSR in 1961; officially
withdrew from Warsaw Pact 13 Septem-
ber 1968','88247c341119d47f5cbe544702dc8fc3c5739b509c4b9238929b80bea144a248','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('915c1ff03b8809b456ec676e6a316c24d3319282ffcc773df97f4006c1aca776',1987,'DZ','Algeria','government',17,'Official name: Democratic and Popular
Republic of Algeria
Type: republic
Capital: Algiers
Administrative divisions: 31 wilayas
(departments or provinces); 160 dairat
(administrative districts), 691 communes
Legal system: based on French and Is-
lamic law, with socialist principles; new
constitution adopted by referendum No-
vember 1976; judicial review of legislative
acts in ad hoc Constitutional Council
composed of various public officials, in-
cluding several Supreme Court justices;
Supreme Court divided into four cham-
bers; has not accepted compulsory ICJ
jurisdiction
National holiday: Anniversary of the
Revolution, 1 November
Branches: executive; unicameral legisla-
ture (National People’s Assembly); judi-
ciary
Government leaders: Col. Chadli
BENDJEDID, President (since February
1979); Abdelhamid BRAHIMI, Prime
Minister (since January 1984)
Suffrage: universal adult at age 18
Elections: presidential, 12 January 1984;
departmental] assemblies, 2 June 1974;
local assemblies, 30 March 1975; legisla-
tive, 5 March 1982
Political parties and leaders: National
Liberation Front (FLN), Secretary General
Chadli Bendiedid
Communists: 400 (est.); Communist Party
illegal (banned 1962)
Member of: AfDB, AIOEC, Arab League,
ASSIMER, FAO, G-77, GATT (de facto),
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, 1LO, IMF,
IMO, INTELSAT, International Lead and
Zinc Study Group, INTERPOL, IOOC,
ITU, NAM, OAPEC, OAU, OIC, OPEC,
UN, UNESCO, UPU, WHO, WIPO,
WMO :','6c699cadf40e06bff199894c1d0e57eba3e5d54b6e786c1c728599482ac9446a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73b7a4834e65fa9c6bc51430a49e99b389dd6a0016ade1d74c773069a5f56b95',1987,'AD','Andorra','government',21,'Official name: Principality of Andorra
Type: unique co-principality under formal
sovereignty of President of France and
Spanish Bishop of Seo de Urgel, who are
represented locally by officials called
verguers
Capital: Andorra la Vella
Administrative divisions: 7 districts
Legal system: based on French and Span-
ish civil codes; Plan of Reform adopted
1866 serves as constitution; no judicial
review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: legislative (General Council of
the Valleys) consisting of 28 members;
executive—syndic (manager) and a deputy
subsyndic chosen by General Council,
judiciary chosen by Co-Princes who ap-
point two civil judges, a judge of appeals,
and two battles (court prosecutors); final
appeal to the Supreme Court of Andorra
at Perpignan, France, or to the Ecclesiasti-
cal Court of the Bishop of Seo de Urgel,','daf330a844e6f44ece051313cde09b1fe8b62ce89152529847755d841d6234ab','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b05ce4b98e92b6304e89b57662d714f15625e43eeb7e0133d46ca123e63696',1987,'ES','Spain','government',22,'Government leaders: head of state—
French Co-Prince Francois MITTER-
RAND (President of France since 1981)
and Spanish Episcopal Co-Prince Mer.
Juan MARTI y Alanis (Bishop of Seo de
Urgel, Spain, since 1971); Syndic—Fran-
cesc CERQUEDA Pasauet (since 1982);
Subsyndic—Antoni GARRALLA Rossell
(since 1986); head of government—Josep
PINTAT Solans (Chief Executive since
1984; re-elected 1986)
Suffrage: those of 21 or over who are
third-generation Andorrans can vote for
General Council members
Elections: 28-member General Council
chosen every four years; last election
December 1985
Political parties and leaders: political
parties not yet legally recognized; tradi-
tionally no political parties but partisans
for particular independent candidates for
the General Council on the basis of com-
petence, personality, and orientation
toward Spain or France; various small
pressure groups developed in 1972; first
formal political party, Andorran Demo-
cratic Association, was formed in 1976 and
reorganized in 1979 as Andorran Demo-
cratic Party
Communists: negligible
Member of: UNESCO
Official name: Spanish State
Type: parliamentary monarchy
Capital: Madrid
Administrative divisions: 50 provinces
Dependent areas: Ceuta, Islas Chafarinas,
Melilla, Pefién de Alhucemas, Pefién de
Vélez de la Gomera
Legal system: civil law system, with
regional applications; constitution provides
for rule of law, established jury system as
well as independent constitutional court to
rule on constitutionality of laws and serve
as court of last resort in protecting liberties
and rights granted in constitution; does not
accept compulsory ICJ jurisdiction
National holiday: 24 June
Branches: executive, with acts of the king
subject to countersignature, Prime Minister
and his ministers responsible to lower
house; bicameral! legislature—Cortes Gen-
erales, consisting of more powerful Con-
gress of Deputies (850 members) and
Senate (208 members), with possible addi-
tion of one to six members from each new
autonomous region; judiciary, independent
Government leaders: JUAN CARLOS 1,
King (since November 1975); Felipe
GONZALEZ Marquez, Prime Minister
(since December 1982)
Suffrage: universal at age 18
Elections: parliamentary election held 22
June 1986 for four-year term; local elec-
tions for municipal and provincial councils
held April 1983; regional elections stag-
gered
Political parties and leaders: principal
national parties, from right to left—Popu-
lar Alliance (AP), Antonio Hernandez
Mancha; Popular Democratic Party (PDP),
Oscar Alzaga; Liberal Party (PL), José
Antonio Segurado; Social Democratic
Center (CDS), Adolfo Suarez; Spanish
Socialist Workers Party (PSOE), Felipe
Gonzalez Marquez; Spanish Communist
Party (PCE), Gerardo Iglesias; chief re-
gional parties—Convergence and Unity
(CiU), Jordi Pujol, in Catalonia; Basque
Nationalist Party (PNV), Xabier Arzallus;
Basque Solidarity (EA), Carlos Garaicoe-
txea; Basque Popular Unity (HB), Jon
Idigoras; Basque Left (EE), Kepa Aulestia;
Andalusian Party (PA), Luis Urufiuela;
Independent Canary Group (AIC); Aragon
Regional Party (PAR); Valencian Union
(UV)
Voting strength: (1986 parliamentary
election in lower house—350 seats) PSOE
44%, 184 seats; AP, PDP, and PL in coali-
tion 26%, 105 seats (dissolution of coalition
and party defections in 1986—AP 68 seats,
PDP 21 seats, PL 12 seats, independent 4
seats); CDS 9%, 19 seats; Communist-led
coalition 5%, 18 seats; CiU 5%, 18 seats:
Basque Nationalist Party 1%, 1 seat; Popu-
lar Unity 1%, 1 seat; Basque Left 1%, 1
seat; Independent Canary Group, 0%, 1
seat; Aragon Regional Party, 0%, 1 seat;
Valencian Union 0%, 1 seat; 6%, vote
other, no seats
Communists; PCE membership has de-
clined from a possible high of 160,000 in
1977 to roughly 60,000 today; the party
lost 64% of its voters and 20 deputies in
the 1982 election; remaining strength is in
labor, where it dominates the Workers
Commissions trade union (one of the
country’s two major labor centrals), which
claims a membership of about 1 million;
experienced a modest recovery in 1986
national election, nearly doubling the share
of the vote it received in 1982
Other political or pressure groups: on the
extreme left, the Basque Fatherland and
Liberty (ETA) and the First of October
Antifascist Resistance Group (GRAPO) use
terrorism to oppose the government; free
labor unions (authorized in April 1977)
include the Communist-dominated Work-
ers Commissions (CCOOQ); the Socialist
General Union of Workers (UGT), and the
smaller independent Workers Syndical
Union (USO); the Catholic Church; busi-
ness and landowning interests; Opus Dei;
university students
Member of: ‘Andean Pact (observer),
ASSIMER, Council of Europe, EC, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ICES, 1CO, IDA, 1DB—Inter-American
Development Bank, [EA, IFAD, IFC,
1HO, ILO, IMF, IMO, INTELSAT, Inter-
national Lead and Zinc Study Group,
INTERPOL, IOOC, IPU, ITC, ITU,
IWC—International Wheat Council,
NATO, OAS (observer), OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO','1a47c037c6a3710138e4cb8099e77d875784241fe1f93b2b02a8b2340f23f101','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fe5b5b9ad4b2e3c09537d1c6861ed86f3d58ddb38c06193cec57df203b56a60',1987,'AO','Angola','government',28,'Official name: People’s Republic of An-
gola
Type: Marxist people’s republic
Capital: Luanda
Administrative divisions: 18 provinces
Legal system: formerly based on Portu-
guese civil law system and customary law;
being modified along socialist model
National holiday: Independence Day, 11
November
Branches: the official party is the supreme
political institution; legislative—National
People’s Assembly
Government leader: José Eduardo dos
SANTOS, President (since September 1979)
Suffrage: to be determined
Elections: none held to date
Political parties and leaders: Popular
Movement for the Liberation of Angola -
Labor Party (MPLA - Labor Party), led by
dos Santos, is the only legal party; National
Union for the Total Independence of
Angola (UNITA), lost to the MPLA in
immediate postindependence struggle, now
carrying out insurgency
Member of: AfDB, FAO, G-77, GATT (de
facto), ICAO, IFAD, ILO, 1MO,
INTELSAT, ITU, NAM, OAU, SADCC,
UN, UNESCO, UNICEF, UPU, WFTU,
WHO, WMO','302fed8f0c9ecc7511285dc0048397636ea7450419bf7e6c2ad3a6ca7d12a356','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d6c73338b322a2258568439d959d4da62ad2ca57a022ff8bc7f29f5d836d35',1987,'AI','Anguilla','government',33,'Official name: Anguilla
Type: British dependent territory
Capital: The Valley
Legal system: based on English common
law; constitution came into effect on 1
April 1982
Branches: 11-member House of Assembly,
seven-member Executive Council
Government leaders: Allistair BAILLE,
Governor and President of Executive
Council (since 1983)
Suffrage: native born, resident before
separation from St. Christopher and Nevis,
or 15 years residence for belonger status
Elections: general election, March 1984
Political parties and leaders: Anguilla
National Alliance (ANA), Emile Gumbs;
Anguillan People’s Party (APP), Ronald
Webster
Voting strength: ANA, 4 seats; APP, 2
seats; 1 independent
Communists: none
Member of: Commonwealth','03e1d94954c425e879d83966b1ff0da8ad851cdd98cc575fe9e1a540d657bfc7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea06f581a99965d0ea31951569b119949c445aad55fc7addbfbc21431ade18c2',1987,'AG','Antigua and Barbuda','government',38,'Official name: Antigua and Barbuda
Type: independent state recognizing Eliza-
beth II as Chief of State
Capital: St. John’s
Administrative divisions: 6 parishes, 2
dependencies (Barbuda, Redonda)
Legal system: based on English common
law; British Caribbean Court of Appeal
has exclusive original jurisdiction and an
appellate jurisdiction
Branches: bicameral legislative,
17-member popularly elected House of
Representatives and 17-member Senate;
executive, Prime Minister and Cabinet;
judiciary, Court of Appeals
Government leaders: Vere Cornwall
BIRD, Sr., Prime Minister (since 1976);
Lester BIRD, Deputy Prime Minister
(since 1976); Sir Wilfred Ebenezer
JACOBS, Governor General (since 1967)
Suffrage: universal suffrage at age 18
Elections: every five years; last general
election 17 April 1984
Political parties and leaders: Antigua
Labor Party (ALP), Vere C. Bird, Sr.,
Lester Bird; United National Democratic
Party (UNDP), Dr. Ivor Heath
Voting strength: (1984 election) House of
Representatives—ALP, 16 seats; indepen-
dent, 1 seat
Communists: negligible
Other political or pressure groups: An-
tigua Caribbean Liberation Movement
(ACLM), a small leftist nationalist group
led by Leonard (Tim) Hector
Member of: CARICOM, Commonwealth,
FAO, G-77, IBRD, ICAO, ILO, IMF, ISO,
OAS, UN, UNESCO, WHO, WMO','d19f52ad0061dd9eded0036cc92351f7f352087460b374634ff9d9a0319cd978','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2d6e2240fbbb470b9d283b690ed12c4b697677c532bfdcd8491b1db3d39b019',1987,'AR','Argentina','government',43,'Official name: Argentine Republic
Type: republic
Capital: Buenos Aires
Administrative divisions: 22 provinces, 1
district (Federal Capital), and | territory
Legal system: mixture of US and West
European legal systems; constitution
adopted 1853 is in effect; has not accepted
compulsory IC] jurisdiction
National holiday: Independence Day, 25
May
Branches: executive (President, Vice
President, Cabinet); legislative (National
Congress—Senate, Chamber of Deputies);
national judiciary
Government leaders: Ral ALFONSIN,
President (since December [983); Victor
MARTINEZ, Vice President (since Decem-
ber 1983)
Argentina (continued)
Elections: general elections held 80 Octo-
ber 1983; Senate elections held November
1986; Gubernatorial and Congressional
elections scheduled for 1987; next general
election 1989
Political parties: operate under statute
passed in 1983 that sets out criteria for
participation in national elections; Radical
Civic Union (UCR}—moderately left of
center; Justicialist Party (JP)—Peronist
umbrella political organization; Intransi-
gent Party (Pl)—leftist party; Union of the
Democratic Center—conservative party);
several provincial parties
Communists: some 70,000 members in
various party organizations, including a
small nucleus of activists
Other political or pressure groups:
Peronist-dominated labor movement,
General Confederation of Labor (Peronist-
leaning umbrella labor organization),
Argentine Industrial Union (manufacturers’
association), Argentine Rural Society (large
landowners’ association), business organiza-
tions, students, the Catholic Church, the
Armed Forces
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, 1HO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOC, ISO, ITU, IWC—
International Whaling Commission,
IWC—International Wheat Council,
LAIA, NAM, OAS, PAHO, SELA, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WTO, WSG','d72178ef04f480ccb24c30fe3a15833854a768287986094aea6068f32e2773e3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78d853011c4f6d89dd39b29263c67d704180a50d9fcc7b626ed5741b452ccbb7',1987,'AW','Aruba','government',48,'Official name: Aruba
Capital: Oranjestad
Type: self-governing until complete inde-
pendence from the Netherlands is granted
in 1996
Legal system: based on Dutch civil law
system, with some English common law
influence
Government leaders: Acting Governor
Maximo CROES; Henny EMAN, Prime
Minister (since January 1986)
Suffrage: universal over age 18
Political parties and leaders: People’s
Electoral Movement (MEP), Nel Oduber,
acting leader; Aruban Patriotic Party
(PPA), Benny Nisbet; Aruban People’s
Party (AVP), Henny Eman; Democratic
Party of Aruba (PDA), Dr. Leo Berlinski;
National Democratic Action Party (ADN),
Pedro Kelly; governing coalition includes
the AVP, former PPA and PDA dissidents,
and the ADN (Berlinski, originally a mem-
ber of the coalition government, was
forced out of the Cabinet because of
corruption charges in 1986; a faction of his
PDA continues to support the coalition,
calling itself the Democratic Action Party
AD-86)','a1ba08214f4a437ee700b248dc0e1276416e9b5b6d88c98cc0989cf2e53a402a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29d6e7ad923cd555cb79cd407b3b393ce3f63f12f541eac137f6b3737df0be4b',1987,'AU','Australia','government',53,'Official name: Commonwealth of Austra-
lia
Type: federal parliamentary state recog-
nizing Elizabeth II as sovereign or head of
state
Capital; Canberra
Administrative divisions: 6 states and 2
territories
Dependent areas: Ashmore and Cartier
Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island
and McDonald Islands, Norfolk Island
Legal system: based on English common
law; constitution adopted 1900; High
Court has jurisdiction over cases involving
interpretation of the constitution; accepts
compulsory ICJ jurisdiction, with reserva-
tions
National holiday: Australia Day, 26
January
Branches: bicameral legislature (Federal
Parliament—Senate and House of Repre-
sentatives); Prime Minister and Cabinet
responsible to House; independent judi-
ciary
12
Government leaders: Sir Ninian
STEPHEN, Governor General (since July
1982); Robert HAWKE, Prime Minister
(since March 1983)
Suffrage: universal and compulsory over
age 18
Elections: held at three-year intervals or
sooner if Parliament is dissolved by Prime
Minister; last election 1 December 1984
Political parties and leaders: govern-
ment—Australian Labor Party (Robert
Hawke); opposition—Liberal Party (John
Howard), National Party (lan Sinclair),
Australian Democratic Party (Janine
Haines), Nuclear Disarmament Party
(Michael Denborough)
Voting strength: (1984 parliamentary
election) House of Representatives—Labor
Party 82 seats, Liberal-National coalition
66 seats; Senate—Labor Party 34 seats,
Liberal-National coalition 33 seats, Austra-
lian Democratic Party 7 seats, indepen-
dents 2 seats
Communists: 4,000 members (est.)
Other political or pressure groups: Aus-
tralian Democratic Labor Party (anti-
Communist Labor Party splinter group);
Peace and Nuclear Disarmament Action
(Nuclear Disarmament Party splinter
group)
Member of: ADB, AIOEC, ANZUS,
CIPEC (associate), Colombo Plan, Com-
monwealth, DAC, ELDO, ESCAP, FAO,
GATT, 1AEFA, IATP, IBA, IBRD, ICAC,
ICAO, 1CO, IDA, IEA, IFAD, IFC, IHO,
ILO, International Lead and Zinc Study
Group, IMF, IMO, INTELSAT,
INTERPOL, 1OOC, IPU, IRC, 1SO, ITC,
ITU, 1WC—International Whaling Com-
mission, |WC—International Wheat Coun-
cil, OECD, SPF, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG','553aca0301d2480971890c3443701466cb050bc255d39afae286c21a13711dfe','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e58160c3aa56895c066e470f210ffa7e6d129cd3ef8526c3365f2322cd8a04',1987,'AT','Austria','government',58,'Official name: Republic of Austria
Type: federal republic
Capital: Vienna
Administrative divisions: 9 states (lander)
Legal system: civil law system with Ro-
man law origin; constitution adopted 1920,
repromulgated 1945; judicial review of
legislative acts by a Constitutional Court;
separate administrative and civil/penal
supreme courts; has not accepted compul-
sory ICJ jurisdiction
National holiday: 26 October
Branches: bicameral legislature (Federal
Assembly—Federal Council, National
Council), directly elected President whose
functions are largely representational,
independent federal judiciary
Government leaders: Kurt WALDHEIM,
President (since July 1986); Franz
VRANITZKY, Chancellor (since June
1986)
Suffrage: universal over age 19; compul-
sory for presidential elections
Elections: presidential, every six years
(next 1992); parliamentary, every four
years (next 1990)
Political parties and leaders: Socialist
Party of Austria (SPO), Fred Sinowatz,
chairman; Austrian People’s Party (OVP),
Alois Mock, chairman; Freedom Party of
Austria (FPO), Jorg Haider, chairman;
Communist Party (KPO), Franz Muhri,
chairman; Green Alternative List (GAL),
Freda Meissner-Blau
Voting strength: 1986 parliamentary
election—SPO 43.1%, OVP 41.3%, FPO
9.7%, GAL 4.8%, KPO .7%, other .32%;
1986 presidential election—(53.9% of 4.7
million votes cast) SPO 80 seats, OVP 77
seats, FPO 18 seats, GAL 8 seats
Communists: membership 15,000 est.;
activists 7,000-8,000
Other political or pressure groups: Fed-
eral Chamber of Commerce and Industry;
Austrian Trade Union Federation (prima-
rily Socialist); three composite leagues of
the Austrian People’s Party (OVP) repre-
senting business, labor, and farmers; OVP-
oriented League of Austrian Industrialists;
Roman Catholic Church, including its
chief lay organization, Catholic Action
Member of: ADB, Council of Europe,
DAC, ECE, EFTA, EMA, ESRO (ob-
server), FAO, GATT, IAEA, IDB—Inter-
American Development Bank, IBRD,
ICAC, ICAO, IDA, IEA, IFAD, IFC, ILO,
International Lead and Zinc Study Group,
IMF, IMO, INTELSAT, INTERPOL, ITU,
IWC—International Wheat Council,
OECD, UN, UNESCO, UPU, WFTU,
WHO, WIPO, WMO, WTO, WSG
Official name: The Commonwealth of
The Bahamas
Type: independent commonwealth recog-
nizing Elizabeth I] as Chief of State
Capital: Nassau
Legal system: based on English common
law
National holiday: Independence Day, 10
July
Branches: bicameral legislature (Parlia-
ment—]6-member appointed Senate,
43-member elected House of Assembly);
executive (Prime Minister and Cabinet);
judiciary
Government leaders: Sir Lynden Oscar
PINDLING, Prime Minister (since 1969);
Sir Gerald C. CASH, Governor General
(since 1979)
Suffrage: universal over age 18
Elections: House of Assembly (June 1982);
next election constitutionally due in five
years
Political parties and leaders: Progressive
Liberal Party (PLP), Sir Lynden O. Pind-
ling; Free National Movement (FNM),
Kendal Isaacs
Voting strength: 73,309 registered voters
(July 1977); (1982 election) House of As-
sembly—PLP 32 seats, FNM 1] seats,
others 0 seats
Communists: none known
The Bahamas (continued)
Other political or pressure groups: Van-
guard Nationalist and Socialist Party
(VNSP), a small leftist party headed by
Lionel Carey; Trade Union Congress
(TUC), headed by Leonard Archer
Member of: CARICOM, CDB, Common-
wealth, FAO, G-77, GATT (de facto),
IBRD, ICAO, IDB—Inter-American De-
velopment Bank, ILO, IMF, IMO,
INTERPOL, ITU, NAM, OAS, PAHO,
UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO','476e52e087c72ee8074ee75d3149e7a2096b3dd3fb27da791678c245d665893a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a5a690465e2310cfc9bf135cfb1dcca6847c72c74866f51dd6ef0b6acb3bd3',1987,'BH','Bahrain','government',63,'Official name: State of Bahrain
Type: traditional monarchy; independent
since 1971
Capital; Manama
Legal system: based on Islamic law and
English common law; constitution went
into effect in December 1973
National holiday: 16 December
Branches: Amir rules with help of a
Cabinet led by Prime Minister; Amir
dissolved the National Assembly in August
1975 and suspended the constitutional
provision for election of the Assembly;
independent judiciary
Government leader: Isa bin Sulman Al
KHALIFA, Amir (since November 1961)
Suffrage: none
Political parties and pressure groups:
political parties prohibited; several small,
clandestine leftist and Shi‘a fundamentalist
groups are active
Communists: negligible
Member of: Arab League, FAO, G-77,
GATT (de facto), GCC, IBRD, ICAO,
[DB—Islamic Development Bank, ILO,
IMF, IMO, INTERPOL, ITU, NAM,
OAPEC, OIC, UN, UNESCO, UPU,
WHO','b97722f339ca501ac2dfc72f4612d1d8f0561fba77e2cb776af70da120c878d5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8470cbfe269aeaf3291c5bad64437680fa64f01a7e98f1056952ae4bbb47d7c7',1987,'IN','India','government',71,'Official name: People’s Republic of Ban-
gladesh
Type: republic; martial law lifted 10
November 1986
Capital: Dhaka
Administrative divisions: 4 divisions, 21
regions, 64 districts, 495 thanas (rural
townships consisting of 4,472 unions or
village groupings)
Legal system: civilian legal system sus-
pended; traditionally based on English
common law; constitution adopted Decem-
ber 1972, amended January 1975 to more
authoritarian presidential system, and
changed by proclamation in April 1977 to
reflect Islamic character of nation; further
change, by proclamation in December
1978, provided for the appointment of the
Prime Minister, Deputy Prime Minister,
and other Cabinet-rank ministers and
defined the powers of the President
National holiday: National Day, 26
March; Victory Day, 16 December
Branches: constitution provides for uni-
cameral legislature (Parliament), strong
President; independent judiciary; President
has substantial control over the judiciary
Government leaders: Hussain Mohammad
ERSHAD, President (since December
1983, elected in October 1986); Mizanur
Rahman CHOUDHURY, Prime Minister
(since July 1986)
Suffrage: universal over age 18
Elections: some local elections held in
December 1983; higher local elections held
in May 1985; last parliamentary elections
held in May 1986; last presidential election
held in October 1986 electing President to
a full five-year term
Political parties and leaders: Jatiyo Party,
Hussain Mohammad Ershad; Bangladesh
Nationalist Party, Begum Ziaur Rahman;
Awami League, Sheikh Hasina Wazed;
United People’s Party, Kazi Zafar Ahmed;
Democratic League, Khondakar Musht-
aque Ahmed; Muslim League, Khan A.
Sabur; Jatiya Samajtantrik Dal (National
Socialist Party), M. A. Jalil; Bangladesh
Communist Party (pro-Soviet), Mohammad
Farhad; numerous small parties; political
activity banned following March 1982
coup; ban lifted in March 1984, reimposed
in March 1985, and lifted again in January
1986
Voting strength: May 1986 parliamentary
elections—Jatiya Party (progovernment)
206 seats, Awami League 80 seats, Awami
League Allies 21 seats, Jamaat-E-Islami 10
seats, Independents 5 seats, Muslim
League 4 seats, JSD (Socialist) 4 seats
Communists: 2,500 members (est.)
Member of: ADB, Afro-Asian People’s
Solidarity Organization, Colombo Plan,
Commonwealth, ESCAP, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
10C, IRC, ITU, NAM, OIC, SAARC, UN,
UNCTAD, UNESCO, UPU, WHO,
WFTU, WMO, WTO
Official name: Republic of India
Type: federal republic
Capital: New Delhi
Administrative divisions: 24 states, 7
union territories
Legal system: based on English common
law; constitution adopted 1950; limited
judicial review of legislative acts; accepts
compulsory ICJ jurisdiction, with reserva-
tions
National holiday: Republic Day, 26
January
Branches: bicameral parliament (Council
of States, House of the People); relatively
independent judiciary
Government leaders: Rajiv GANDHI,
Prime Minister (since October 1984); Zail
SINGH, President (since July 1982)
Suffrage: universal over age 21
Elections: national and state elections
ordinarily held every five years; may be
postponed in emergency and may be held
more frequently if government loses confi-
dence vote; last general election in Decem-
ber 1984; state elections staggered
Politica] parties and leaders: Indian
National Congress, controlled national
government from independence to March
1977; split in January 1978 and 1979;
party currently headed by Prime Minister
Rajiv Gandhi; Lok Dal Party led by
Charan Singh; Janata Party led by Chan-
dra Shekhar; Bharatiya Janata Party led by
L. K. Advani; Communist Party of India
(CPI), led by C. Rajeswara Rao; Commu-
nist Party of India/Marxist (CP1/M) led by
E. M. S. Namboodiripad; Communist
Party of India/Marxist-Leninist (CP1/ML)
led by Satyanarayan Singh; All-India Anna
Dravida Munnetra Kazagham (AIADMK),
a regional party in Tamil Nadu, led by M.
G. Ramachandran; Akali Dal, led by Surijit
Singh Barnala, representing Sikh religious
community in the Punjab; Telugu Desam,
a regional party in Andhra Pradesh led by
N. T. Rama Rao; National Conference
(NC), a regional party in Jammu and
Kashmir, split into factions led by Farooq
Abdullah and G. M. Shah; Asom Gana
Parishad, a regional party in Assam led by
Prafulla Mahanta; Mizo National Front, a
regional party in Mizoram led by Lald-
enga; Congress (IG) Party, a breakaway
faction of Congress (I) Party, led by
Pranab Mukherjee and Gundu Rao
Voting strength: India Congress, 74%;
Telugu Desam Party, 5%; CPM, 4%;
Janata, 1.8%; CPl, 1.1%, DMKP, 0.5%;
BJP, 0.4%; other, 6.6%
Communists: 466,000 members claimed
by CPI, 270,000 members claimed by
CPI/M; Communist extremist groups,
about 15,000 members
113
Other political or pressure groups: vari-
ous separatist groups seeking reorganiza-
tion of states; numerous senas or militant/
chauvinistic organizations, including Shiv
Sena (in Bombay), Anand Marg, and
Rashtriya Swayamsevak Sangh
Member of: ADB, AIOEC, ANRPC,
Colombo Plan, Commonwealth, ESCAP,
FAO, G-77, GATT, IAEA, IBRD, ICAC,
ICAO, ICO, IDA, IFAD, IFC, IHO, ILO,
International Lead and Zine Study Group,
IMF, IMO, INTELSAT, INTERPOL, IPU,
IRC, ITC, ITU, IWC—International
Wheat Council, NAM, SAARC, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WSG, WTO','843bb31565a321e17ce4a0451b2c62766038fd7cc1a45757bcaa029e11c38319','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8679448929737b5b80cf48f8c524ebeeb73ebfb745d532ecf67bd82645c675',1987,'BB','Barbados','government',77,'Official name: Barbados
Type: independent sovereign state within
the Commonwealth recognizing Elizabeth
ll as Chief of State
Capital: Bridgetown
Administrative divisions: 11 parishes and
city of Bridgetown
Legal system: English common law;
constitution came into effect upon inde-
pendence in 1966; no judicial review of
legislative acts; has not accepted compul-
sory IC) jurisdiction
National holiday: Independence Day, 30
November
Branches: bicameral legislature (Parlia-
ment—21-member appointed Senate and
27-member elected House of Assembly),
Cabinet headed by Prime Minister
Government leaders: Errol BARROW,
Prime Minister (since May 1986), Sir Hugh
SPRINGER, Governor General (since 1984)
Suffrage: universal over age 18
Elections: House of Assembly members
have terms no longer than five years; last
general election held 28 May 1986
Political parties and leaders: Barbados
Labor Party (BLP), Henry Forde; Demo-
cratic Labor Party (DLP), Errol Barrow
Voting strength: (1981 election) BLP,
52.4%; DLP, 46.8%; independent, negligi-
ble; House of Assembly seats—BLP 24,
DLP 8
Communists: negligible
Other political or pressure groups:
People’s Progressive Movement, Bobby
Clarke; People’s Pressure Movement, Eric
Sealy; Workers’ Party of Barbados, Dr.
George Bell
Barbados (continued)
Member of: CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IBRD, ICAQ,
IDB—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, 1SO, ITU, IWC—Interna-
tional Wheat Council, NAM, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO, WMO','203fae453799aadcd3180fd576f8e741d8ede3eb7e11fab74131ac4504bea47b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5da8d7ede0b930f503fa69487cae4a208c65d27703943f4143950ad79dfd0907',1987,'BE','Belgium','government',82,'Official name: Kingdom of Belgium
Type: constitutional monarchy
Capital; Brussels
Administrative divisions: nine provinces;
as of 1 October 1980, Wallonia and Flan-
ders have regional subgovernments with
elected regional councils and executive
officials; those regional authorities have
limited powers over revenues and certain
areas of economic, urban, environmental,
and housing policy; Wallonia also has a
separate Walloon Cultural Council
Legal system: civil law system influenced
by English constitutional theory; constitu-
tion adopted 1831, since amended; fudicial
review of legislative acts; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: National Day, 21 July
Branches: executive branch consists of
King and Cabinet; Cabinet responsible to
bicameral parliament (Senate and Cham-
ber of Representatives); independent
judiciary; coalition governments are usual
Government leaders: BAUDOUIN I, King
(since August 1950); Wilfried MARTENS,
Prime Minister (since April 1979, with a
10-month interruption in 1981)
Suffrage: universal over age 18
Elections: held at least once every four
years; last held 13 October 1985
Political parties and leaders: Flemish
Social Christian (CVP), Frank Swaelen,
president; Walloon Social Christian (PSC),
Gérard Deprez, president; Flemish Social-
ist (SP), Karel van Miert, president; Wal-
loon Socialist (PS), Guy Spitaels, president,
Flemish Liberal (PVV), Annemie Neyts-
Uyttebroeck, president; Walloon Liberal
(PRL), Louis Michel, president; Fran-
cophone Democratic Front (FDF), Georges
Clerfayt, president; Volksunie (VU), Jaak
Gabriels, president; Communist Party
(PCB), Louis van Geyt, president; Walloon
Rally (RW), Fernand Massart; Ecologist
Party (ECOLO-AGALEV), loosely orga-
nized with no president; Anti-Tax Party
(UDRT-RAD), Robert Hendrick, president;
Vlaams Blok (VB), Karel Dillen
Voting strength: (1985 election) 212-seat
Chamber of Representatives—CVP 49
seats, PS 35 seats, PVV 22 seats, SP 32
seats, PRL 24 seats, VU 16 seats, PSC 20
seats, FDF 3, ECOLO-AGALEV 9 seats,
UDRT-RAD 1 seat, VB 1
Communists: under 5,000 members (De-
cember 1985 est.)
Other political or pressure groups: Chris-
tian and Socialist Trade Unions; Federa-
tion of Belgian Industries; numerous other
associations representing bankers, manu-
facturers, middle-class artisans, and the
legal and medical professions; various
organizations represent the cultural inter-
ests of Flanders and Wallonia; various
peace groups such as Flemish Action
Committee Against Nuclear Weapons and
Pax Christi
Member of: ADB, Benelux, BLEU, Coun-
cil of Europe, DAC, EC, ECE, ECOSOC,
EIB, ELDO, EMS, ESRO, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO,
1DA, 1DB—Inter-American Development
Bank, IEA, IFAD, IFC, ILO, International
Lead and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU,
ITC, 1TU, NATO, OAS (observer), OECD,
UN, UNESCO, UPU, WEU, WHO,
WIPO, WMO, WSG','d039923e8652a14041e7627b62f5194851e6e955850cd70f7eb5da05fae3c56d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a30c6f29a497bf7e82864fa4e34fed2ebf2235a6d5efbca8d664eddd16f7bf',1987,'GT','Guatemala','government',87,'Official name: Belize
Type: parliamentary; independent state; a
member of the Commonwealth
Capital: Belmopan
Administrative divisions: 6 districts
Legal system: English law
Branches: bicameral legislature (National
Assembly—electoral redistricting in Octo-
ber 1984 expanded House of Representa-
tives from 18 to 28 seats; eight-member
appointed Senate; either house may choose
its speaker or president, respectively, from
outside its membership); Cabinet; judiciary
Government leaders: Manuel A.
ESQUIVEL, Prime Minister (since Decem-
ber 1984); Dr. Elmira Minita GORDON,
Governor General (since December 1981)
Suffrage: universal adult at age 18
Elections: parliamentary elections held
December 1984; municipal elections held
December 1986 ''
Political parties and leaders: United
Democratic Party (UDP), Manuel
Esquivel, Curl Thompson, Dean Lindo,
People’s United Party (PUP), George Price,
Florencio Marin, Said Musa; Belize Popu-
lar Party (BPP), Louis Sylvestre
Voting strength: (December 1984) Na-
tional Assembly—UDP 2] seats (25,785—
54.1%), PUP 7 seats (20,971—44.0%);
before redistricting, PUP held 13 seats,
UDP 4 seats, and independents 1 seat
Communists: negligible
Other political or pressure groups: United
Workers Union, which is connected with
PUP
Member of: CARICOM, CDB, Common-
wealth, FAO, GATT, IBRD, IDA, IFAD,
IFC, ILO, IMF, G-77, ISO, ITU, UN,
UNESCO, UPU, WHO, WMO
Official name: Republic of Guatemala
Type: republic
Capital; Guatemala
Administrative divisions: 22 departments
Legal system: civil law system; constitu-
tion came into effect 1966 but suspended
following March 1982 coup; Constituent
Assembly elected in July 1984 completed
drafting new constitution and other elec-
toral laws in June 1985; judicial review of
legislative acts; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 15
September
Branches: traditionally dominant execu-
tive; new 100-member congress installed
14 January 1986; power vested in Office of
President; seven-member (minimum)
Supreme Court
Government leader: Marco Vinicio
CEREZO Arévalo, President (since Janu-
ary 1986)
Suffrage: universal over age 18, compul-
sory for literates, optional for illiterates
Guatemala (continued)
Elections: last congressional election held
3 November 1985; presidential runoff
election held 8 December 1985
Political parties and leaders: Christian
Democratic Party (DCG), Marco Vinicio
Cerezo Arévalo; National Centrist Union
(UCN), Jorge Carpio Nicolle; National
Liberation Movement (MLN), Mario
Sandoval Alarcén; Institutional Democratic
Party (PID) in coalition with MLN;
People’s Democratic Force (FDP) in coali-
tion with MLN; Democratic Party of
National Cooperation (PDCN), Jorge
Serrano Elias; Revolutionary Party (PR) in
coalition with PDCN; Social Democratic
Party (PSD), Mario Solarzano Martinez;
National Renewal Party (PNR), Alejandro
Maldonado Aguirre; National Authentic
Center (CAN), Mario David Garcia; Anti-
Communist Democratic Front (DUA) in
coalition with PUA; emerging Movement
for Harmony (MEC) in coalition with
PUA; 14 political groups participated in
national election for a civilian president,
congress, and mayoralties; in runoff elec-
tions between Vinicio Cerezo (DCG) and
Jorge Carpio (UCN), Cerezo won by a 2 to
I margin
Voting strength: (November 1985) DCG,
38.65%; UCN, 20.23%; PDCN/PR,
13.78%; MLN/PID, 12.56%; CAN, 6.28%;
PSD, 3.41%; PNR, 3.15%;
PUA/FUN/MEC, 1.91%; (December 1985)
DCB SI seats, UCN 22 seats, MLN 12
seats, PDCN/PR 11 seats, PSD 2 seats,
PNR 1 seat, CAN I seat
Communists: Guatemalan Labor Party
(PGT); main radical left guerrilla groups—
Guerrilla Army of the Poor (EGP), Revolu-
tionary Organization of the People in
Arms (ORPA), Rebel Armed Forces (FAR),
and PGT Dissidents
Other political or pressure groups: Feder-
ated Chambers of Commerce and Industry
(CACIF), Mutual Support Group (GAM)
Member of: CACM, FAO, G-77, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
IDB—Inter-American Development Bank
IFAD, 1FC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IRC, 180, ITU,
1WC—International Wheat Council, OAS,
ODECA, PAHO, SELA, UN, UNESCO,
UPEB, UPU, WFTU, WHO, WMO
’','03870f90b4fc928394265370bd46140e260a1cbbd64b93b41256bc9ccd1f3928','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca66223fb890b02a57c7c060e3b58919c8fded2f28bda641b87f90a72c741340',1987,'BJ','Benin','government',93,'Official name: People’s Republic of Benin
Type: Soviet-modeled civilian government
Capital: Porto-Novo (official), Cotonou (de
facto)
Administrative divisions: 6 provinces, 84
districts
Legal system: based on French civil law
and customary law; has not accepted
compulsory ICJ jurisdiction
National holiday: 30 November
Branches: Revolutionary National Assem-
bly, National Executive Council
Government leader: Brig. Gen. Mathieu
KEREKOU, President and Chief of State
(since 1972)
Suffrage: universal adult
Elections: National Assembly elections
were held in November 1979; Assembly
then formally elected Kérékou President in
February 1980
Political parties: People’s Revolutionary
Party of Benin (PRPB) is sole party
Communists: PRPB espouses Marxism-
Leninism
Member of: AfDB, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, G-77, GATT,
IBRD, ICAO, ICO, IDA, IFAD, ILO,
IMF, IMO, INTERPOL, ITU, NAM,
Niger River Commission, OAU, OCAM,
UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO, WTO
Official name: Federal Republic of','044a125c9801d43fda7bb51cc2b563645487e0405fe7830114ef01ff3c9631b1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6ae9af9b5b1cec5dc9d24176095a1d2ed26cbed296ee3d57e91d63aa6cacb17',1987,'BM','Bermuda','government',98,'Official name: Bermuda
Type: British dependent territory
Capital: Hamilton
Administrative divisions: 9 parishes, 2
municipalities
Legal system: English law
Branches: Executive Council (cabinet)
appointed by governor, led by government
leader; bicameral legislature with an
appointed Senate and a 40-member di-
rectly elected House of Assembly; Su-
preme Court
Government leaders: Viscount DUNROS-
SIL, Governor (since 1983); John William
David SWAN, Premier (since 1982)
Suffrage: universal adult over age 21
Elections: at east once every five years;
last general election October 1985
Political parties and leaders: United
Bermuda Party (UBP), John W. D. Swan;
Progressive Labor Party (PLP), Frederick
Wade; National Liberal Party, Gilbert
Darrell
Voting strength: 1985 elections—40 seats
total—UBP 31 House of Assembly seats;
PLP, 7; National Liberal Party, 2
Communists: negligible
Other political or pressure groups: Ber-
muda Industrial Union (BIU), headed by
Ottiwell Simmons
Member of: INTERPOL, WHO
25','769448ec6fb2123879ce5dcb1255d706cc4165dd6bbc501bcd9497f8bf83fb6e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39202a4d9ef179d27d22e02a29601b8ab88e9b57adfd4700537bd1d6ff0b44c5',1987,'BT','Bhutan','government',103,'Official name: Kingdom of Bhutan
Type: monarchy; special treaty relation-
ship with India
Capital: Thimphu; Paro is the administra-
tive capital
Administrative divisions: 4 regions (east,
central, west, south) divided into 18 dis-
tricts
Legal system: based on Indian law and
English common law; in 1907 the monarch
assumed full power—no written constitu-
tion or bill of rights; in 1968-69 a separate
judiciary that provided for local, district,
and national courts with appellate jurisdic-
tion was established; has not accepted
compulsory 1CJ jurisdiction
National holiday: 17 December
Branches: appointed ministers;
150-member indirectly elected National
Assembly consisting of 110 village elders
or heads of family, 10 monastic represen-
tatives, and 30 senior government adminis-
trators
Government leader: Jigme Singye
WANGCHUCK, King (since 1974)
Suffrage: each family has one vate
Elections: popular elections on village
level held every three years
Political parties: no legal parties
Communists: no overt Communist pres-
ence
Other political or pressure groups: Bud-
dhist clergy, Indian merchant community,
ethnic Nepalese organizations
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IBRD, IDA, IFAD, IMF,
NAM, SAARC, UNESCO, UPU, UN,
WHO
26
Official name: Republic of Bolivia
Type: republic
Capital; La Paz (seat of government);
Sucre (legal capital and seat of judiciary)
Administrative divisions: nine depart-
ments with limited autonomy
Legal system: based on Spanish law and
Code Napoleon; constitution adopted 1967;
constitution in force except where contrary
to dispositions dictated by governments
since 1969; has not accepted compulsory
ICJ jurisdiction
National holiday: Independence Day, 6
August
Branches: executive; bicameral legislature
(National Congress—Senate and Chamber
of Deputies); Congress began meeting
again in October 1982; judiciary
Government leader: Victor PAZ Estens-
soro, President (since August 1985)
Suffrage: universal and compulsory at age
18 if married, 21 if single
Elections: presidential election on 14 July
1985 did not produce the required major-
ity for any of the three leading candidates;
Victor Paz Estenssoro, center-left leader of
the Nationalist Revolutionary Movement
(MNR), placed second in the popular vote
to center-right Hugo Banzer, head of the
Nationalist Democratic Action (ADN);
however, the MNR won 94 congressional
seats compared to the ADN’s 5]; as a
27
result, the Bolivian Congress on 5 August
chose Paz Estenssoro to head the govern-
ment; he was inaugurated on 6 August
Political parties and leaders: the two
parties that garnered the most votes in the
1985 elections, the Nationalist Revolution-
ary Movement (MNR) and the Nationalist
Democratic Action (ADN), continue to
have a tactical alliance; MNR, Victor Paz
Estenssoro; ADN, Hugo Banzer; Movement
of the Revolutionary Left (MIR), Jaime
Paz Zamora; Nationalist Revolutionary
Movement of the Left (MNRI), Hernan
Siles Zuazo; Bolivian Socialist Falange
(FSB), Mario Gutiérrez; Authentic Revolu-
tionary Party (PRA), Walter Guevara;
Christian Democratic Party (PDC), Ben-
jamin Miguel; Nationalist Revolutionary
Party of the Left, Juan Lechin Oquendo
Voting strength: (1985 election) ADN
28.11%, MNR 26.66%; MIR 8.86%
Member of: FAO, G-77, IADB, IAEA,
IATP, IBRD, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IFC, ILO, IMF, INTELSAT, INTERPOL,
ISO, ITC, ITU, [WC—International
Wheat Council, LAIA and Andean Sub-
Regional Group (created in May 1969
within LAIA, formerly LAFTA), NAM,
OAS, PAHO, SELA, UN, UNESCO, UPU,
WHO, WMO, WTO','570346ca4eaf180f3ef782f3221426ee77cdfd485d5e1aadcf66cd01294377cd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a2d2e40daba695c2e61d755a2ef03e4ed69de0b3b0c950a2d2f844f009451d2',1987,'BW','Botswana','government',108,'Official name: Republic of Botswana
Type: parliamentary republic; independent
member of Commonwealth
Capital: Gaborone
Administrative divisions: ]0 administra-
tive districts
Legal system: based on Roman-Dutch law
and local customary law; constitution came
into effect 1966; judicial review limited to
matters of interpretation; has not accepted
compulsory ICJ jurisdiction
National holiday: Botswana Day, 30
September
Branches: executive—President appoints
and presides over the Cabinet, which is
responsible to National Assembly; bicam-
eral legislature (National Assembly with 34
popularly elected members and four
members elected by the 34 representatives;
House of Chiefs with deliberative powers
only); judicial—local courts administer
customary law, High Court and subordi-
nate courts have criminal jurisdiction over
all residents, Court of Appeal has appellate
jurisdiction
Government leader: Dr. Quett K. J.
MASIRE, President (since July 1980)
Suffrage: universa) adult at age 21
Elections: general elections held 8 Sep-
tember 1984
Politica) parties and leaders: Botswana
Democratic Party (BDP), Quett Masire;
Botswana National Front (BNF), Kenneth
Koma; Botswana People’s Party (BPP);
Botswana Independence Party (BIP),
Motsamai Mpho
Voting strength: (September 1984 election)
Legislative Assembly—BDP, 28 seats;
BNF, 5 seats; BPP, } seat
Communists: no known Communist orga-
nization; Koma of BNF has long history of
Communist contacts
Member of: Af{DB, Commonwealth, FAO,
G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, INTERPOL,
ITU, NAM, OAU, Southern African Cus-
toms Union, SADCC, UN, UNESCO,
UPU, WHO, WMO','3bb00e0e0809d4fa1377c9cf4a1c3ce63a39f0042d5dcc1610604a14e634f496','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('150e6f3c07b2d63129987d0f3d7b3d2046ebe16cb6243b83ea67a43a232d5729',1987,'BR','Brazil','government',113,'Official name: Federative Republic of
Type: federal republic; democratically
elected president since March 1985
Capital: Brasilia
Administrative divisions: 23 states, 3
territories, 1 federal district
Legal system: based on Latin codes; dual
system of courts, state and federal; consti-
tution adopted in 1967 and extensively
amended in 1969; has not accepted com-
pulsory ICJ jurisdiction
National holiday: Independence Day, 7
September
Branches: strong executive with very
broad powers; bicameral legislature (Na-
tional Congress) with growing powers,
comprised of Senate and Chamber of
Deputies that will combine to form a
Constituent Assembly in 1987 to draft a
new constitution; 11-man Supreme Court
Government leader: José SARNEY Costa,
President (since April 1985)
Suffrage: compulsory over age 18
Elections: Tancredo Neves indirectly
elected by an electoral college composed
of members of congress and delegates
from the state legislatures, ending 20 years
of military rule; died before assuming
30
office; municipal elections held November
1985; congressional and gubernatorial
elections held November 1986; constitu-
tional convention February 1987
Political parties and leaders: Brazilian
Democratic Movement Party (PMDB),
Ulysses Guimaraes, president; Liberal
Front Party of President Sarney’s govern-
ment coalition, Mauricio Campos, presi-
dent; other parties—Workers Party (PT),
Brazilian Labor Party (PTB), Democratic
Workers Party (PDT), and Social Demo-
cratic Party (PDS); Communist parties
legalized in March 1985—Brazilian Com-
munist Party (PCB) and Communist Party
of Brazil (PCdoB)
Voting strength: (November 1986 Con-
gressional elections) 77% government
coalition (PMDB and PFL), 7% PDS, 10%
leftist opposition parties (PT, PDT, PCB)
Communists: about 30,000
Other political or pressure groups: left
wing of the Catholic Church and labor
unions allied to leftist Worker’s Party are
critical of military government''s social and
economic policies
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
1DB—Inter-American Development Bank,
IFAD, IFC, 1HO, ILO, IMF, IMO,
INTELSAT, IPU, IRC, ISO, ITU, IWC—
International Wheat Council, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO,
WIPO, WMO, WTO
Official name: British Indian Ocean Terri-
tory
British Indian Ocean
Territory (continued)
Type: colony administered by United
Kingdom
Capital: none
Government leaders: W. Marsden, Com-
missioner (since 1986; resident in UK); T.
C. Stitt, Administrator (since 1986)
Official name: British Virgin Islands
Type: British dependent territory
Capital; Road Town
Administrative divisions: 9 electoral
districts
Legal system: English law; justice is ad-
ministered by the Eastern Caribbean
Supreme Court and Courts of Summary
Jurisdiction and Magistrates; there is a
resident puisne judge on the islands; new
constitution in 1977
National holiday: Territory Day, 1 July
Branches: Executive Council (cabinet)
consists of the Governor as chairman, four
ministers of the legislature, and an ex
officio member who is the attorney gen-
eral; Legislative Council consists of the
Speaker (elected from outside the Council),
nine elected members, and an ex officio
member who is the attorney general
Government leaders: Mark HERDMAN,
Governor and Chairman of the Executive
Council (since 1986); H. Lavitty STOUTT,
Chief Minister (since 1986)
Suffrage: universal adult over 18
Elections: at least once every five years;
last general election held 30 September
1986
Political parties and leaders: United
Party (UP), Conrad Maduro; Virgin Islands
Party (VIP), H. Lavitty Stoutt; Indepen-
dent, C. B. Romney
Voting strength: 1986 elections—UP 2
seats; VIP 5 seats; Independents 2 seats
Communists: probably none
Member of: Commonwealth
Official name: State of Brunei Darussalam
Type: constitutional sultanate; became a
sovereign state and fully independent from
United Kingdom on 1 January 1984
Capital: Bandar Seri Begawan
National holiday: National Day, 23 Feb-
ruary
Administrative divisions: four administra-
tive districts
Legal system: based on Islamic law; con-
stitution promulgated by the Sultan in
1959
Branches: chief of state is Sultan (advised
by appointed Privy Council), who appoints
Executive Council and Legislative Council
Government leader: Sir HASSANAL
Bolkiah, Sultan and Prime Minister (since
August 1968)
Suffrage: universal at 21; three-tiered
system of indirect elections; popular vote
cast for lowest level (district councilors)
Elections: last elections—March 1965;
further elections postponed indefinitely
Political parties and leaders: Brunei
National Democratic Party (established on
18 September 1985, the first legal political
party), Abdul Latif bin Abdul Hamid,
Chairman; Brunei National United Party
(established on 4 February 1986), Anak
Hasanuddin, chairman
Communists: probably none
Brunei (continued)
Member of: ASEAN, ESCAP (associate
member), IMO, INTERPOL, O1C, UN','a76a4f63b93077c136872adcf876b66db09f275dcd141dfaddf271a3bac19ed7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1661452136134371a411f7f34191d8f4d3a29540733881ecc6430e8949ae57bc',1987,'BG','Bulgaria','government',118,'Official name: People’s Republic of Bul-
garia
Type: Communist state
Capital: Sofia
Administrative divisions: 27 okrugs (dis-
tricts); capital city of Sofia has equivalent
status
Legal system: based on civil law system,
with Soviet law influence; new constitution
adopted in 1971; judicial review of legisla-
tive acts in the State Council; has accepted
compulsory ICJ jurisdiction
National holiday: National Liberation
Day, 9 September
Branches: legislative (National Assembly);
judiciary, Supreme Court
Government leaders: Todor Khristov
ZHIVKOV, Chairman, State Council
(President and Chief of State; since July
1971); Georgi Ivanov ATANASOV, Chair-
man, Council of Ministers (Premier; since
March 1986)
Suffrage: universal and compulsory over
age 18
Elections: held every five years for Na-
tional Assembly; last election held in June
1986; more than 99% of electorate voted
Political parties and leaders: Bulgarian
Communist Party, Todor Zhivkov, General
Secretary; Bulgarian National Agrarian
Union, a puppet party, Petur Tanchev,
secretary of Permanent Board
Communists: 932,055 party members
(April 1986)
Mass organizations and front groups:
Fatherland Front, Dimitrov Communist
Youth Union, Central Council of Trade
Unions, National Committee for Defense
of Peace, Union of Fighters Against Fas-
cism and Capitalism, Committee of Bul-
garian Women, All-National Committee
for Bulgarian-Soviet Friendship
Member of: CEMA, FAO, IAEA, ICAO,
ILO, International Lead and Zinc Study
Group, IMO, IPU, ITC, ITU, IWC—
International Wheat Council, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO; Warsaw Pact, International
Organization of Journalists, International
Medical Association, International Radio
and Television Organization
Official name: Burkina Faso (since August
1984)
Type: military; established by coup on 4
August 1983
Capital: Ouagadougou
Administrative divisions: 30 provinces;
250 departments
Legal system: based on French civil law
system and customary law
National holiday: Independence Day, 4
August
Branches: President is an army officer;
military council of unknown number;
21-member military and civilian Cabinet;
judiciary
Government leaders: Cdr. Thomas
SANKARA, President (since August 1983)
Suffrage: none
Elections: political process suspended; no
talk of returning to constitutional rule
Politica] parties and leaders: all political
parties banned following November 1980
coup
Communists: small Communist party
front group; some sympathizers
Other political or pressure groups: com-
mittees for the defense of the revolution,
watchdog/ political action groups estab-
lished by current regime throughout the
country in both organizations and commu-
nities
36
Member of: AfDB, CEAO, EAMA, ECA,
EIB (associate), Entente, FAO, GATT,
G-77, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, INTELSAT, INTERPOL, IPU, IRC,
ITU, NAM, Niger River Commission,
OAU, OCAM, OIC, UN, UNESCO, UPU,
WCL, WFTU, WHO, WIPO, WMO,
WTO
Official name: Socialist Republic of the
Union of Burma
Type: republic
Capital: Rangoon
Administrative divisions: seven divisions
(predominantly Burman population) and
seven states (based on ethnic minorities),
subdivided into townships, village-tracts
(rural), and wards (urban)
Legal system: People’s Justice system and
People''s Courts instituted under 1974
constitution; has not accepted compulsory
1CJ jurisdiction
National holiday: Independence Day, 4
January
Branches: Council of State rules through a
Council of Ministers; National Assembly
(Pyithu Hluttaw or People’s Congress) has
legislative power
Government leader: U SAN YU, President
and Chairman of Council of State (since
November 1981)
Suffrage: universal over age 18
Burma (continued)
Elections: National Assembly and local
People’s Councils elected in 1985
Political parties and leaders: government-
sponsored Burma Socialist Program Party
only legal party; U Ne Win, party chair-
man
Communists: est. 15,000 (primarily as an
insurgent group on the northeast frontier)
Other political or pressure groups:
Kachin Independence Army; Karen Na-
tionalist Union, several Shan factions (all
insurgent groups)
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, GATT, 1AEA, IBRD, 1CAO,
IDA, IFC, THO, ILO, IMF, IMO,
INTERPOL, IRC, ITU, UN, UNESCO,
UPU, WHO, WMO','aa8323d5329f57ec4eeaeef2e51cc5f80c38da5942aa6e48bf58cf86428f5988','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8bcf73fb3817a075b13958c763476aebf5894af8dced71d05ed5a3947e16a01',1987,'BI','Burundi','government',123,'Official name: Republic of Burundi
Type: republic
Capital; Bujumbura
Administrative divisions: 15 provinces,
subdivided into arrondissements and
communes according to a 1982 redistrict-
ing
Legal system: based on German and
French civil codes and customary law; has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 1
July
Branches: executive (President and Cabi-
net); judicial; legislature (National Assem-
bly) reestablished in 1982
Government leader: Col. Jean-Baptiste
BAGAZA, President and Head of State
(since 1976)
Suffrage: universal adult
Elections: new constitution approved by
national referendum in November 1981;
election to National Assembly held in
October 1982
Political parties and leaders: National
Party of Unity and Progress (UPRONA), a
Tutsi-led party, declared sole legitimate
party in 1966; second national party con-
gress held in 1984; Col. Jean-Baptiste
Bagaza confirmed as party president for
five-year term
Communists: no Communist party
Member of: AfDB, EAMA, ECA, FAO,
G-77, GATT, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, INTERPOL, ITU,
NAM, OAU, UN, UNE SCO, UPU, WHO,
WIPO, WMO, WTO','1b73fcbdc56ba9685f083529232bd21a2b5299e11e5e148a5a9c9a9fd98db512','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bbc22051fdf043ce89d645760902b94981cc4339bc4b80ebf8d22bb155843e5',1987,'TH','Thailand','government',128,'Official name: People’s Republic of Kam-
puchea (PRK; pro-Vietnamese, in Phnom
Penh); the three resistance groups function
collectively as the Coalition Government
of Democratic Kampuchea (CGDK)
Type: PRK is Communist; CGDK is na-
tionalist coalition of one Communist and
two non-Communist factions
Capital; Phnom Penh
Administrative divisions: 20 provinces
Legal system: no information
National holiday: 17 April for both re-
gimes
Branches: PRK—unicameral legislature
(National Assembly); highest authority of
the land is technically the Council of
State, whose chairman serves as the
country’s president; Council of Ministers
oversees implementation of party poli-
cies—chairman is equivalent of premier
Government leaders: PRK—HENG
SAMRIN, President (since January 1979),
HUN SEN, Prime Minister; CGDK—
Prince NORODOM SIHANOUK, Presi-
dent (since July 1982); SON SANN, Prime
Minister (since July 1982); KHIEU SAM-
PHAN, Vice President (since July 1982)
Suffrage: universal over age 18
Political parties and leaders: PRK—
Kampuchean Peoples Revolutionary Party,
the Communist party installed by Vietnam
in 1979; CGDK—an umbrella organization
for three resistance groups, including
Democratic Kampuchea under Khieu
Samphan, Khmer People’s National Liber-
ation Front (KPNLF) under Son Sann, and
National United Front for an Independent,
Neutral, Peaceful, and Cooperative Cam-
bodia under Prince Norodom Sihanouk
40
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, GATT (de facto), IAEA,
IBRD, ICAO, IDA, ILO, IMF, IMO,
INTERPOL, IRC, 1TU, Mekong Commit-
tee (inactive), NAM, UN, UNE SCO, UPU,
WFTU, WHO, WMO, WTO for CGDK;
none for PRK
Official name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Administrative divisions: 72 centrally
controlled provinces
Legal system: based on civil Jaw system,
with influences of common law; has not
accepted compulsory ICJ jurisdiction
National holiday: King’s Birthday, 5
December
Branches: King is head of state with
nominal powers; bicameral legislature
(National Assembly—Senate appointed by
King, elected House of Representatives);
judiciary relatively independent except in
important political subversion cases
Government leaders: BHUMIBOL
ADULYADE], King (since June 1946);
Gen. (Ret.) PREM TINSULANONDA,
Prime Minister (since March 1980)
Suffrage: universal at age 20
Elections: last held July 1986
Political parties: Social Action Party, Thai
Nation Party, Thai People’s Party, Thai
Citizens Party, Democrat Party, United
Democratic Party, United Democracy
Party, Community Action Party, People’s
Party, Progressive Party; other small
parties represented in parliament
Voting strength: (July 1986 parliamentary
election) total number of seats—347;
Democrat Party 100 seats, Thai Nation 63
seats, Social Action 5] seats, United Demo-
cratic 38 seats, Thai Citizens 24 seats,
National Democracy 3 seats, minor parties
68 seats
240
Communists: strength of illegal Commu-
nist Party is probably less than J ,000;
Communist insurgents throughout Thai-
land total an estimated 1,000
Member of: ADB, ANRPC, ASEAN,
ASPAC, Association of Tin Producing
Countries, Colombo Plan, GATT, ESCAP,
FAO, G-77, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, 1HO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITC,
ITU, UN, UNESCO, UPU, WHO, WMO,
WTO','bc6ae78e1c77e8d3b118669c83d3ac445865de1ffba08b4698b445d492a3acb1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d5db653d752ac0b18dbb3a86ebdf7dcdeec902d159866b66215b1d57a6ce756',1987,'CM','Cameroon','government',133,'Official name: United Republic of
Type: unitary republic; one-party presi-
dential regime
Capital: Yaoundé
Administrative divisions: 10 provinces
divided into departments, arrondissements,
districts, led by provincial governors ap-
pointed by President
Legal system: based on French civil law
system, with common law influence; uni-
tary constitution adopted 1972; judicial
review by Supreme Court when a question
of constitutionality is referred to it by the
President; has not accepted compulsory
1C] jurisdiction
National holiday: National Day, 20 May
Branches: executive (President), legislative
(National Assembly), and judicial (Supreme
Court)
Government leader: Paul BIYA, President
(since November 1982)
Suffrage: universal over age 21]
Elections: parliamentary elections held
May 1983; presidential elections held
January 1984
Cameroon (continued)
Political parties and leaders: Cameroon
People’s Democratic Movement (known as
the Cameroon People’s National Union
during 1966-85), Paul Biya, President
Communists: no Communist party or
significant number of sympathizers
Other political or pressure groups:
Cameroon People’s Union (UPC), remains
an illegal group with its factional leaders
in exile
Member of: AfBD, EAMA, ECA, EIB
(associate), FAO, G-77, GATT, IAEA,
IBRD, ICAC, ICAO, ICO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ISO, ITU, Lake Chad Basin Commis-
sion, NAM, Niger River Commission,
OAU, OIC, UDEAC, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO','3781c06cfd26970dffdb441557062b61baed4e11b1e54308b8b364f766d88bf2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654b12ec94a1e62abbe1c3acbfe124e2369160afdaf005561dd7247244db6edb',1987,'CA','Canada','government',138,'Official name: Canada
Type: federal state recognizing Elizabeth
II as sovereign
Capital: Ottawa
Administrative divisions: 10 provinces
and 2 territories
Legal system: based on English common
law, except in Quebec, where civil law
system based on French law prevails;
constitution as of 1982 (formerly British
North America Act of 1867 and various
amendments); accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Canada Day, 1 July
Branches: federal executive power vested
in cabinet collectively responsible to House
of Commons and headed by Prime Minis-
ter; federal legislative authority resides in
Parliament (282 seats) consisting of Queen
represented by Governor General, Senate,
and House of Commons; judges appointed
by Governor General on the advice of the
government; Supreme Court is highest
tribunal
Government leaders: Brian MULRONEY,
Prime Minister (since September 1984);
Jeanne SAUVE, Governor General (since
May 1984)
Suffrage: universal over age 18
Elections: legal limit of five years but in
practice usually held within four years;
last election September 1984; 75% voter
turnout
Political parties and leaders: Liberal,
John Turner; Progressive Conservative,
Brian Mulroney; New Democratic,
Edward Broadbent
Voting strength: (1984 election) Progres-
sive Conservative, 50%; Liberal, 28%; New
Democratic Party, 19%; parliamentary
seats as of December 1986—Progressive
Conservative 209, Liberal 40, New Demo-
cratic Party 30, vacant 3
Communists: 2,000
Member of: ADB, Colombo Plan, Com-
monwealth, DAC, FAO, GATT, IAEA,
IBRD, ICAO, ICES, ICO, ICRC, IDA,
IDB—Inter-American Development Bank,
IFA, IFAD, IFC, IHO, ILO, International
Lead and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IPU, ISO, ITC,
1TU, 1WC—International Whaling Com-
mission, 1WC—International Wheat Coun-
cil, NATO, OAS (observer), OECD,
PAHO, UN, UNCTAD, UNESCO, UPU,
WHO, WIPO, WMO, WSG
Official name: Republic of Cape Verde
Type: republic
Capital: Praia
Administrative divisions: 2 distritos
subdivided into 14 concelhos
Legal system: based on constitution
National holiday: Independence Day, 5
July
Branches: 56-member National People’s
Assembly; the official party is the supreme
political organization
Government leaders: Aristides PEREIRA,
President (since July 1975); Pedro PIRES,
Prime Minister (since July 1975)
Suffrage: universal over age 15
Elections: National Assembly election held
December 1985, the second since indepen-
dence
Political parties and leaders: only legal
party, African Party for Independence of
Cape Verde (PAICV), led by Aristides
Pereira, secretary general; PAICV estab-
lished in January 198] to replace the
former ruling party in both Cape Verde
and Guinea-Bissau, the African Party for
the Independence of Guinea-Bissau and
Cape Verde (PAIGC), in protest of the
November 1980 coup in Guinea-Bissau
Communists: a few Communists and some
sympathizers
Member of: FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, IFAD, ILO, IMF,
IMO, IPU, ITU, NAM, OAU, UN,
UNESCO, UPU, WHO, WMO','6913ab35771afef26893137dd39d90ecd403fead744f98df89b75a3b5cdd27b5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dabf23dd44a651eea1af31d7d60b98a439af38f344dcdc1b61983eedbd3fd25',1987,'KY','Cayman Islands','government',143,'Official name: Cayman Islands
Type: British dependent territory
Capital: George Town
Administrative divisions: 8 electoral
districts
Legal system: British common law and
local statutes
National holiday: Constitution Day, 8 July
Branches: executive—Governor and Exec-
utive Council (3 appointed official mem-
bers and 4 elected members chosen by the
Legislative Assembly from its elected
members); legislative—unicameral Legisla-
tive Assembly (12 elected members and 3
appointed by Governor), judicial—Sum-
mary Court, Grand Court, Cayman Islands
Court of Appeal, Her Majesty''s Privy
Council
Government leader: George Peter
LLOYD, Governor and President of the
Executive Council (since 1982)
Suffrage: universal adult over age 18
Elections: elections held every four years
Political parties and leaders: no formal
political parties
Communists: none
Member of: Commonwealth','161251357d1625332759f82f179fbef4042042c24a6819f67d68c720a285361a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c71d86034de2b28f127ab10d156b602d1c383310fada30516936398aebd323c2',1987,'CF','Central African Republic','government',148,'Official name: Central African Republic
Type: republic, under military rule since
September 1981
Capital: Bangui
Administrative divisions: 14 prefectures,
47 subprefectures
Legal system: based on French law;
constitution (approved in a November
1986 referendum); judiciary, Supreme
Court, court of appeals, criminal court,
and numerous lower courts
National holiday: Independence Day, 13
August; National Day, 1 December
Branches: Chief of State; a national legis-
lature; separate judiciary; assembly called
on Gen. André Dieudonné Kolingba to
form 44-member provisional council to
oversee party activities until special con-
vention elects ruling board
Government leader: Gen.
André-Dieudonné KOLINGBA is Chief of
State, chairman of the Centrafrican Demo-
cratic Rally Party, and head of govern-
ment since 1981
Suffrage: universal over age 21
Elections: none scheduled
Political parties and leaders: political
parties banned in September 1981; Cen-
trafrican Democratic Rally Party created
in February 1987 during National Conven-
tion is the only political party
Communists: no Communist party; small
number of Communist sympathizers
Member of: AfDB, CFA (Franc Zone),
Conference of East and Central African
States, EAMA, ECA, FAO, G-77, GATT,
IBRD, ICAO, iCO, IDA, IFAD, ILO,
IMF, INTELSAT, INTERPOL, ITU,
NAM, OAU, OCAM, UDEAC, UEAC,
UN, UNESCO, UPU, WHO, WIPO,
WMO','0442caaee867b32981c1cfe8a142b0e87f95b9d6f8bf4556ef96bbad3bb1b625','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35c18859619b7428634b07e4197ae78743849a624b8c3f4f23eb0e3f04338cd',1987,'TD','Chad','government',153,'Official name: Republic of Chad
Type: republic
Capital: N''Djamena
Administrative divisions: 14 prefectures,
54 subprefectures, 27 administrative posts,
9 municipalities
Legal system: based on French civil law
system and Chadian customary law; con-
stitution adopted in 1962; constitution
suspended and National Assembly dis-
solved in April 1975; Fundamental Act, a
quasi-constitution decreed in October
1982, provides juridical framework
whereby decrees are promulgated by the
President; has not accepted compulsory
IC] jurisdiction
National holiday: Independence Day, 11
August
Branches: presidency; Council of Minis-
ters; National Consultative Council, Court
of Appeal, and several lower courts
Government leaders: Hissein HABRE,
President (since June 1982)
Suffrage: universal over age 18
Elections: none planned
Political parties and leaders: National
Union for Independence and Revolution
(UNIR) established June 1984 with Habré
as President; numerous dissident groups
(several have returned to the government
since mid-]986)
Communists: no front organizations or
underground party; probably a few Com-
munists and some sympathizers
Other political or pressure groups: the
development of a stable government
continues to be hampered by prolonged
tribal and regional antagonisms; one rebel
group (with Libyan backing) occupies the
northern third of Chad (Aozou Strip)
Member of: AfDB, CEAO, Conference of
East and Central African States, EAMA,
ECA, EC (associate), FAO, G-77, GATT,
IBRD, ICAC, ICAO, 1DA, IDB—Islamic
Development Bank, IFAD, 1LO, IMF,
INTELSAT, INTERPOL, ITU, Lake Chad
Basin Commission, NAM, OAU, OCAM,
OIC, UN, UNESCO, UPU, WHO, WIPO,
WMO','db3aff7f280d20aee12cfa1031bb39acde084e2db83ceb7d0d087a5cdd9ec1b3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97166cdfc119fa20d55ed9ee00b840e66fe83f67f2f48fc41ce00a5ab1e04d6e',1987,'CL','Chile','government',158,'Official name: Republic of Chile
Type: republic
Capital: Santiago
Administrative divisions: 12 regions plus
Santiago metropolitan region, 41 provincial
subdivisions
Legal system: based on Code of 1857
derived from Spanish law and subsequent
codes influenced by French and Austrian
law; current constitution came into effect
in March 1981; the constitution provides
for continued direct rule unti] 1989, with a
phased return to full civilian rule by 1997;
judicial review of legislative acts in the
Supreme Court; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 18
September
Branches: four-man Military Junta, which
exercises constituent and legislative powers
and has delegated executive powers to
President; the President has announced a
plan for transition from military to civilian
rule pursuant to Constitution; state of siege
49
lifted January 1986; National Congress
(Senate, House of Representatives) dis-
solved; civilian judiciary remains
Government leaders: Gen. Angusto PINO-
CHET Ugarte, President (since September
1973); Adm. José Toribio MERINO Castro
(since September 1978), Air Force Gen.
Fernando MATTHEI Aubel (since July
1978), Army Lt. Gen. Humberto
GORDON Rubio (since December 1986),
Gen. Rodolfo STANGE Oecklers (since
August 1985), Junta members
Elections: none; voters are being regis-
tered for constitutionally mandated presi-
dential plebiscite in 1989 and congres-
sional election in 1990
Political parties and Jeaders: all political
parties are officially recessed or outlawed
but have been allowed to function on a
very limited basis since 1982 (a law allow-
ing political parties to renew restricted
activities has been approved by the Junta
and is slated for enactment in March
1987); National Renovation (RN), Ricardo
Rivadeneira; Radical Party (PR), Enrique
Silva Cimma; Social Democratic Party
(PSD), Rene Abeliuk; Christian Democratic
Party (PDC), Gabriel Valdés; Republican
Right, Hugo Zepeda; Socialist Party, Ri-
cardo Nujfiez; the PR, PSD, PDC, Republi-
can Right, and one faction of the Socialist
Party form the Democratic Alliance (AD);
Movement of Unitary Popular Action
(MAPU); Movement of Unitary Popular
Action—Workers/Peasants (MAPU-OC),
Oscar Garreton Purcell (in exile); Christian
Left (IC), Luis Maira; Communist Party of
Chile (PCCh), Luis Corvalan Leppe (in
exile); Socialist Party—Almeyda faction
(PSCh/Alm), Clodomiro Almeyda (in
exile); Socialist Party—Altamirano faction
(PSCh/Alt), Carlos Altamirano (in exile);
Movement of the Revolutionary Left
(MIR), Andrés Pascal Allende (in exile); the
MIR, PSCh/Alm, and PCCh form the
leftist Popular Democratic Movement
(MDP)
Voting strength: (1970 presidential elec-
tion) 36.6% Popular Unity coalition, 35.8%
conservative independent, 28.1% Christian
Democrat; (1973 congressional election)
56% Democratic Confederation (PDC and
Chile (continued)
PN), 44% Popular Unity coalition (socialists
and Communists)
Communists: 120,000 when PCCh was
legal in 1978; active militants now esti-
mated at about 20,000-50,000
Other political or pressure groups: revi-
talized university student federations at all
major universities dominated by political
groups; labor—National Workers Com-
mand (CNT) includes trade unionists from
the country’s five largest labor confedera-
tions; Roman Catholic Church
Member of: CIPEC, ECOSOC, FAO,
G-77, GATT, IADB, IAEA, IBRD, ICAO,
IDA, 1DB—Inter-American Development
Bank, IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU,
LAIA, OAS, PAHO, SELA, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO','3651c0bc8dd58955506389ca5ec4fa96380d855926f91c63895a82cb45c4079c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba0a05bb123b374c4b2780fe616e44431142efb43f70a32ad5437b0a1d5446e4',1987,'CN','China','government',163,'Official name: People’s Republic of China
Type: Communist state; real authority lies
with Communist Party’s Politburo; the
National People’s Congress, in theory the
highest organ of government, usually
ratifies the party’s programs; the State
Council actually directs the government
Capital: Beijing
Administrative divisions: 22 provinces, 3
centrally governed municipalities, 5 auton-
omous regions
Legal system: a complex amalgam of
custom and statute, largely criminal; little
ostensible development of uniform code of
administrative and civil law; highest judi-
cial organ is Supreme People’s Court,
which reviews lower court decisions; laws
and legal procedure subordinate to priori-
ties of party policy; regime has attempted
to write civil and Communist codes; new
legal codes in effect since 1 January 1980;
party and state constitutions revised in
September and November 1982, respec-
tively; continuing efforts are being made
to improve civil and commercial law
National holiday: National Day, 1 Octo-
ber
Branches: control is exercised by Chinese
Communist Party, through State Council,
which supervises ministries, commissions,
bureaus, etc., all technically under the
Standing Committee of the National
People’s Congress
Government leaders: ZHAO Ziyang,
Premier of State Council (since September
1980); LI Xiannian, President (since June
1983); PENG Zhen, Chairman of NPC
Standing Committee (since June 1983)
Suffrage: universal over age 18
Elections: elections held for People’s
Coneress representatives at county level
Political parties and leaders; Chinese
Communist Party (CCP), headed by Zhao
Ziyang as Acting General Secretary of
Central Committee
Communists: about 45 million party
members (1986)
Other political or pressure groups: such
opposition as exists consists of loose coali-
tions that vary by issue rather than orga-
nized groups
Member of: ADB, ESCAP, FAO, IAEA,
IBRD, ICAO, IDA, IFAD, IFC, HO, ILO,
IMF, IMO, INTELSAT, ITU, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO
Official name: Japan
Type: constitutional monarchy
Capital: Tokyo
Administrative divisions: 47 prefectures
Legal system: civil law system with
English-American influence; constitution
promulgated in 1946; judicial review of
legislative acts in the Supreme Court;
accepts compulsory IC) jurisdiction, with
reservations
National holiday: Foundation Day, 11
February
Branches: Emperor is symbol of state;
executive power is vested in Cabinet
appointed by the Prime Minister, chosen
by the lower house of the bicameral,
elective legislature—Diet (House of Coun-
cilors, House of Representatives); judiciary
is independent
Government leaders: HIROHITO, Em-
peror (since December 1926); Yasuhiro
NAKASONE, Prime Minister (since No-
vember 1982)
Suffrage: universal over age 20
Elections: general elections held every
four years or upon dissolution of lower
house, triennially for half of upper house
Political parties and leaders: Liberal
Democratic Party (LDP), Y. Nakasone,
president; Japan Socialist Party (JSP), T.
Doi, chairman; Democratic Socialist Party
(DSP), S. Tsukamoto, chairman; Japan
Communist Party (JCP), T. Fuwa, Presid-
ium chairman; Komeito (Clean Govern-
ment Party), J. Yano, chairman; Social
Democratic Federation (SDF), S. Eda
Voting strength: (1986 election) Lower
House—49.5% LDP (307 seats), 17.2% JSP
(88 seats), 9.4% Komeito (57 seats), 8.8%
JCP (27 seats), 6.4% DSP (29 seats), 0.8%
SDF (4 seats), 6.1% independents and
minor parties; Upper House—LDP 143
seats, JSP 40, Komeito 25 seats, JCP 16
seats, DSP 12 seats, SDF 1 seat, Niin Club
8 seats, Salaryman 8 seats, Zeikinto 2 seats,
independents 8 seats
Communists: about 470,000 registered
Communist Party members
Member of: ADB, ASPAC, Colombo Plan,
DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB—Inter-
American Development Bank, IEA, IFAD,
IFC, IHO, ILO, International Lead and
Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ISO,
ITC; ITU, IWC—International Whaling
Commission, [WC—International Wheat
Council, OECD, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WSG','7cff28cc1726b9ff2deaad1a4937a42f09698b1da403fd54be3f817f42c40ab8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2534c9ab07761c8b9bf37daa61c79bfb58b4399886ebf09f1d87da3f7926d7',1987,'CX','Christmas Island','government',168,'Official name: Territory of Christmas
Island
Type: Australian territory
Capita}: The Settlement
Legal system: Australian territory since 10
October 1958; administrator appointed by
Governor General of Australia; Supreme
Court; legislative, judicial, and administra-
tive system regulated by the Christmas
Island Act of 1958
Branches: Advisory Council advises ap-
pointed administrator
Government leader: T. F. PATERSON,
Administrator
Communists: none','de1ecced4f010a3e235b22411f777a0142fa3dc5cb611a7a6f7e588275663a2a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61203d98e5e4419fa88fb9e239c3d8d132fa064b007678caf08d9997b6751407',1987,'CO','Colombia','government',173,'Official name: Republic of Colombia
Type: republic; executive branch domi-
nates government structure
Capital: Bogota
Administrative divisions: 23 departments,
4 intendancies, 5 commissariats, Bogota
Special District
Legal system: based on Spanish law;
religious courts regulate marriage and
divorce; constitution decreed in 1886, with
amendments codified in 1946 and 1968;
judicial review of legislative acts in the
Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 20
July
Branches: President, bicameral legislature
(Congress—Senate, House of Representa-
tives), judiciary
Government leader: Virgilio BARCO
Vargas, President (since August 1986);
term ends 1990
Suffrage: age 18 and over
53
Elections: every fourth year; presidential
election held May 1986; congressional
election held March 1986; municipal and
departmental elections every two years,
next elections scheduled 1988
Political parties and leaders: Liberal
Party—Virgilio Barco Vargas, Alfonso
Lopez Michelsen; New Liberal faction is
headed by Luis Carlos Galan; Conservative
Party—Alvaro Gomez Hurtado, Misael
Pastrana Borrero; Belisario Betancur leads
a small faction; Communist Party (PCC),
Gilberto Vieira White; Communist
Party /Marxist-Leninist (PCC/ML), Maaist
orientation; Patriotic Union, (UP), political
movement formed by Revolutionary
Armed Forces of Colombia (FARC) and
PCC, Braulio Herrera (Jaime Pardo Leal
was 1986 presidential candidate)
Voting strength: (1986 presidentia! elec-
tion) Virgilio Barco Vargas 59%, Alvaro
Gomez Hurtado 36%, Jaime Pardo Leal
4%, others 1%
Communists: 18,000 members est., includ-
ing Communist Party Youth Organization
(JUCO)
Other political or pressure groups: Com-
munist Party (PCC), Gilberto Vieira
White; PCC/ML, Chinese Line Commu-
nist Party; Revolutionary Armed Forces of
Colombia’s Patriotic Union Party (FARC-
UP)
Member of: Contadora Group, FAO,
G-77, GATT, IADB, IAEA, IBRD, ICAC,
ICAO, 1CO, IDA, 1DB—Inter-American
Development Bank, IFAD, IFC, IHO,
1LO, IMF, IMO, INTELSAT, INTERPOL,
IRC, 1SO, ITU, LAIA and Andean Sub-
Regional Group, NAM, OAS, PAHO,
SELA, UN, UNESCO, UPEB, UPU,
WFTU, WHO, WIPO, WMO, WSG,
WTO','4adf869d0eecb7ff22c0f90c786c40a908fc30751d66abfb05e892546b248db6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19801456cff07f3367b3961459f127c50b13d05b974d337c5f72d9a89b8d61d8',1987,'YT','Mayotte','government',179,'Official name: Federal Islamic Republic
of the Comoros
Type: independent republic
Capital: Moroni
Administrative divisions: each of the
three main islands is an administrative
unit under a governor appointed by the
President, three separate municipalities
(Moroni, Mutsamudu, Domoni)
Legal system: French and Muslim law in
a new consolidated code
Branches: presidency; 38-member legisla-
ture (Federal Assembly)
Government leader: Ahmed ABDALLAH
ABDEREMANE, President (since October
1978)
Suffrage: universal adult
Elections: Abdallah Abderemane won
1984 presidential election with 99% major-
ity; Federal Assembly elected in March
1982
Political party: sole legal political party is
Comoran Union for Progress (UCP)
Voting strength: UCP holds 37 seats in the
Federal Assembly
Member of: AfDB, FAO, G-77, IBRD,
IDA, IDB—Islamic Development Bank,
IFAD, HO, IMF, ITU, NAM, OAU, OIC,
UN, UNESCO, UPU, WHO, WMO','23e6e076ee2f7f237b861d18d31cba9c89ae0ee41531f91d743eed5419dd65a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caa2e11823bcf80e965829d7674cbea5d23c3849d05b106b0c71bfbd1f41ca8c',1987,'CG','Congo','government',184,'Official name: People’s Republic of the
Type: people''s republic
Capital: Brazzaville
Administrative divisions: nine regions,
divided into districts, and capital district
Legal system: based on French civil law
system and customary law; constitution
adopted 8 July 1979
National holiday: National Day, 15 Au-
gust
Branches: presidential executive, Council
of State; judiciary; all policy made by
Congolese Labor Party Central Committee
and Politburo
Government leaders: Col. Denis SASSOU-
NGUESSO, President and party chairman
(since 1979); Ange Edouard POUNGUI,
Prime Minister (since July 1984)
Suffrage: universal over age 18
Elections: elections for local and regional
organs and the National Assembly were
held in July 1979—the first elections since
June 1973
Political parties and leaders: Congolese
Labor Party (PCT) is the only legal party;
Party Congress held in July 1984—Sassou
unanimously elected to another five-year
term as President and party chairman
Communists: unknown number of Com-
munists and sympathizers
Other political or pressure groups: Union
of Congolese Socialist Youth (UJSC), Con-
golese Trade Union Congress (CSC), Revo-
lutionary Union of Congolese Women
(URFC), General Union of Congolese
Pupils and Students (UGEEC)
Member of: Af{DB, Conference of East
and Central African States, EAMA, ECA,
EIB (associate), FAO, G-77, GATT, IBRD,
ICAO, ICO, IDA, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, ITU,
NAM, OAU, UDEAC, UEAC, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO','13f01852c65c420e12295987cdd74a659ee45f5eee8a17f9854fdb7a809426d1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f2578372c3a7358b081dc707730d649f0a3a8dbfb3b23965994a25d88cb454e',1987,'CK','Cook Islands','government',189,'Official name: Cook Islands
Type: self-governing in free association
with New Zealand; Cook Islands Govern-
ment fully responsible for internal affairs
and has the right at any time to move to
full independence by unilateral action;
New Zealand retains responsibility for
external affairs, in consultation with the
Cook Islands Government
Capital: Avarua
Branches: New Zealand Governor General
appoints Representative to Cook Islands,
who represents the Queen and the New
Zealand Government; Representative
appoints the Prime Minister; popularly
elected 24-member Parliament;
15-member House of Arikis (chiefs), ap-
pointed by Representative, is an advisory
body only
Government leader: Sir Thomas DAVIS,
Prime Minister (since July 1978)
Suffrage: universal adult
Elections: every five years, latest in No-
vember 1983
Political parties and leaders: Democratic
Party, Sir Thomas Davis; Cook Islands
Party, Geoffrey Henry
Voting strength: (1983) Parliament—
Democratic Party, 18 seats; Cook Islands
Party, 11 seats
Member of: ADB, IDA, IFC, IMF, SPF,
SPEC, ESCAP (associate member)','87349f42956f678ec853bbe6d8aa164a3b778c6a614fc843d1d10203aad630b4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d5d1efeaf37db150c7fd48b0626d5949694b1c7c59f466df1df8206ea7671d',1987,'CR','Costa Rica','government',194,'Official name: Republic of Costa Rica
Type: democratic republic
Capital: San José
Administrative divisions: 7 provinces
Legal system: based on Spanish civil law
system; constitution adopted in 1949;
judicial review of legislative acts in the
Supreme Court; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 15
September
Branches: executive—President (head of
government and chief of state), elected for
a single four-year term; two vice presi-
dents; legislative—57-delegate unicameral
Legislative Assembly elected at four-year
intervals; judiciary—Supreme Court of
Justice (17 magistrates elected by Legisla-
tive Assembly at eight-year intervals)
Government leader: Oscar ARIAS San-
chez, President (since May 1986)
Suffrage: universal and compulsory age 18
and over
Elections: every four years; last held in
February 1986
Political parties and leaders: National
Liberation Party (PLN), José (Fepe)
Figueres, Luis Alberto Monge, Daniel
Oduber, Oscar Arias Sanchez; the Social
Christian Unity Party (PUSC) comprises
58
the four Unity Coalition (UNIDAD) par-
ties—Republican Calderonista Party
(PRC), Rafael Angel Calderon Fournier;
Democratic Renovation Party (PRD),
leader unknown; Christian Democratic
Party (PDC), Rafael Grillo Rivera; Popular
Unity Party (PUP), Christian Tattenbach
Iglesias; the Popular Alliance (PA) is a
coalition comprising two parties—Marxist
Popular Vanguard Party (PVP), Humberto
Vargas Carbonell, and Leftist Broad Dem-
ocratic Front (FAD), Rodrigo Gutiérrez;
the United People (PU) is a leftist coalition
comprising four parties—New Republic
Movement (MNR), Sergio Erick Ardén;
Socialist Party (PS), Alvaro Montero Mejia;
People’s Party of Costa Rica (PPC),
Manuel Mora Valverde; and Radical
Democratic Party (PRD), Juan José Echev-
erria Brealey
Voting strength: (1986 election) PLN, 29
seats; UNIDAD, 25 seats; PVP, 1 seat;
PPC, 1 seat; other, I seat
Communists: 7,500 members and sympa-
thizers
Other political or pressure groups: Costa
Rican Confederation of Democratic Work-
ers (CCTD; Liberation Party affiliate),
Confederated Union of Workers (CUT;
Communist Party affiliate), Authentic
Confederation of Democratic Workers
(CATD; Communist Party affiliate), Cham-
ber of Coffee Growers, National Associa-
tion for Economic Development (ANFE),
Free Costa Rica Movement (MCRL;
rightwing militants), National Association
of Educators (ANDE)
Member of: CACM, Central American
Democratic Community, FAO, G-77,
IADB, IAEA, IBRD, ICAO, ICO, IDA,
[DB—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ITU, 1WC—Interna-
tional Wheat Council, OAS, ODECA,
PAHO, SELA, UN, UNESCO, UPEB,
UPU, WHO, WMO, WTO','55c91638fec287140ec8037b851436c582f82711ab6db2ab135ed7dd2d2505f2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('352f4bb018f07c0763ef159fcee401a79d79dc70c4703a742eefe1726d74043e',1987,'CU','Cuba','government',199,'Official name: Republic of Cuba
Type: Communist state
Capital: Havana
Administrative divisions: 14 provinces
and 169 municipalities
Legal system: based on Spanish and
American law, with large elements of
Communist legal theory; new constitution
2 December 1976; does not accept com-
pulsory ICJ jurisdiction
National holiday: Anniversary of the
Revolution, 1 January
Branches: executive; legislature (National
Assembly of the People’s Power); con-
trolled judiciary
Government leader: Fidel CASTRO Ruz,
President (since January 1959)
Suffrage: universal but not compulsory
over age 16
Elections: National People’s Assembly
(indirect election) every five years; last
election held December 1986
Political parties and leaders: Cuban
Communist Party (PCC), First Secretary
Fidel] Castro Ruz, Second Secretary Ranl
Castro Ruz
Communists: about 500,000 party mem-
bers
Member of: CEMA, ECLA, FAO, G-77,
GATT, IADB (nonparticipant), JAEA,
ICAO, IFAD, ICO, IHO, [LO, IMO, IRC,
ISO, ITU, [WC—International Wheat
Council, NAM, OAS (nonparticipant),
PAHO, Permanent Court of Arbitration,
Postal Union of the Americas and Spain,
SELA, UN, UNESCO, UNIDO, UPU,
WFTU, WHO, WIPO, WMO, WSG,
WTO','9d3ca996680b0f06af19435d6bbd432e22297f0a56cbfab89d02d5b1fe4c5b5a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dba2842b98356ceb486fad7e48c8cebf0d0b2d75263c1f901f204fbcf108305',1987,'CY','Cyprus','government',204,'Official name: Republic of Cyprus
Type: republic; a disaggregation of the two
ethnic communities inhabiting the island
began after the outbreak of communal
strife in 1963; this separation was further
solidified following the Turkish invasion of
the island in July 1974, which gave the
Turkish Cypriots de facto control in the
north; Greek Cypriots control the only
internationally recognized government; on
15 November 1983 Turkish Cypriot Presi-
dent Rauf Denktash declared indepen-
dence and the formation of a Turkish
Republic of Northern Cyprus, which has
been recognized only by Turkey; both
sides publicly call for the resolution of
intercommunal differences and creation of
a new federal system of government
Capital: Nicosia
Administrative divisions: 6 administrative
districts
Legal system: based on common law, with
civil law modifications; negotiations to
create the basis for a new or revised con-
stitution to govern the island and relations
between Greek and Turkish Cypriots have
been held intermittently
National holiday: Independence Day, 1
October
Branches: currently the Government of
Cyprus has effective authority over only
the Greek Cypriot community; headed by
61
President of the Republic and comprising
Council of Ministers, House of Representa-
tives, and Supreme Court; Turkish Cypri-
ots declared their own constitution and
governing bodies within the Turkish Fed-
erated State of Cyprus in 1975; state
renamed Turkish Republic of Northern
Cyprus in 1983; new constitution for the
Turkish sector passed by referendum in
May 1985
Government leaders: Spyros
KYPRIANOU, President (since 1977);
Turkish Sector—Rauf DENKTASH, Presi-
dent (since 1975)
Suffrage: universal at age 18
Elections: officially every five years (last
presidential election held in February
1988); parliamentary elections held in
December 1985; Turkish sector presiden-
tial elections last held in June 1985; assem-
bly elections held in June 1985
Political parties and leaders: Greek
Cypriot—Progressive Party of the Work-
ing People (AKEL; Communist Party),
Ezekias Papaioannou; Democratic Rally
(DESY), Glafkos Clerides; Democratic
Party (DEKO), Spyros Kyprianou; United
Democratic Union of the Center (EDEK),
Vassos Lyssarides; Turkish sector—Na-
tional Unity Party (NUP), Dervis Eroglu;
Communal Liberation Party (CLP), Ismail
Bozkurt; Republican Turkish Party (RTP),
Ozker Ozgur; New Birth Party (NBP),
Aytac Besheshler
Voting strength: in the 1983 presidential
election, incumbent Spyros Kyprianou
retained his position by winning 56% of
the vote; in the 1985 parliamentary elec-
tion, the pro-Western Democratic Rally
received 19 of the 56 seats; Kyprianou’s
center-right Democratic Party won 16
seats; Communist AKEL secured 15 seats;
and socialist EDEK won 6 seats; in 1985
presidential elections in the Turkish Cyp-
riot sector, Ranf Denktash won with 70
percent of the vote; in the 1985 assembly
elections the conservative National Unity
Party won 24 of 50 seats; the Communist
Republican Turkish Party received 12
seats; center-right Communal Liberation
Party secured 10 seats; and the rightwing
New Birth Party received 4 seats
Communists: about 12,000
Cyprus (continued)
Other political or pressure groups: United
Democratic Youth Organization (EDON;
Communist controlled); Union of Cyprus
Farmers (EKA; Communist controlled);
Cyprus Farmers Union (PEK; pro-West);
Pan-Cyprian Labor Federation (PEO;
Communist controlled); Confederation of
Cypriot Workers (SEK; pro- West); Federa-
tion of Turkish Cypriot Labor Unions
(Turk-Sen); Confederation of Revolution-
ary Labor Unions (Dev-Is)
Member of: Commonwealth, Council of
Europe, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, ITU,
NAM, UN, UNESCO, UPU, WFTU,
WHO, WMO, WTO; Turkish Federated
State of Cyprus OIC (observer)
Official name: Czechoslovak Socialist
Republic (CSSR)
Type: Communist state
Capital: Prague
Administrative divisions: 2 ostensibly
separate and nominally autonomous repub-
lics (Czech Socialist Republic and Slovak
Socialist Republic); 7 regions (kraj) in
Czech lands, 3 regions in Slovakia; repub-
lic capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on
Austro-Hungarian codes, modified by
Communist legal theory; revised constitu-
tion adopted 1960, and amended in 1968
and 1970; no judicial review of legislative
acts; has not accepted compulsory [CJ
jurisdiction
National holiday: Liberation Day, 9 May
Branches: executive—President (elected
by Federal Assembly), Cabinet (appointed
by President); legislative (Federal Assem-
bly; elected directly—Chamber of Nations,
Chamber of the People), Czech and Slovak
National Councils (also elected directly)
legislate on limited area of regional mat-
ters; judiciary, Supreme Court (elected by
Federal Assembly); entire governmental
structure dominated by Communist Party
Government leaders: Gustav HUSAK,
President (since 1975); Lubomir
STROUGAL, Premier (since 1970)
Suffrage: universal over age 18
Elections: governmental bodies and presi-
dent every five years; last election June
1986
Dominant political party and leader:
Communist Party of Czechoslovakia (KSC),
Gustév Husdk, General Secretary (since
1969); Communist Party of Slovakia (KSS)
has status of provincial KSC organization
Voting strength: (1986 election) 99.96%
for Communist-sponsored single slate
Communists: 1.6 million party members
(August 1984)
Other political groups: puppet parties—
Czechoslovak Socialist Party, Czechoslovak
People’s Party, Slovak Freedom Party,
Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA,
ICAO, ICO, ILO, International Lead and
Zine Study Group, IMO, I[PU, ISO, ITC,
ITU, UN, UNESCO, UPU, Warsaw Pact,
WFTU, WHO, WIPO, WMO, WSG,
WTO','3b8b635a8a198b41c418bc6350388aabb4a36597a321792dd8aaf439cd6994cf','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6909d696b45cae0ba4cc2e6fedfcb44b7e80076296749a506681462a595649be',1987,'DK','Denmark','government',209,'Official name: Kingdom of Denmark
Type: constitutional monarchy
Capital; Copenhagen
Administrative divisions: 14 counties, 275
communes (88 towns are included in
communes)
Dependent areas: Faroe Islands, Green-
land
Legal system: civil law system; constitu-
tion adopted 1953; judicial review of
legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: birthday of the Queen,
16 April
Branches: legislative authority rests jointly
with Crown and parliament (Folketing);
executive power vested in Crown but
exercised by Cabinet responsible to parlia-
ment; Supreme Court, 2 superior courts,
106 lower courts
Government leaders: MARGRETHE II,
Queen (since January 1972); Poul SCHLU-
TER, Prime Minister (since September
1982)
Suffrage: universal over age 21
Elections: on call of prime minister but at
least every four years; last election 10
January 1984
64
Political parties and leaders: Social Dem-
ocratic, Anker Jorgensen; Liberal, Uffe
Ellemann-Jensen; Conservative, Poul
Schlter; Radical Liberal, Niels Helveg
Petersen; Socialist People’s, Gert Petersen;
Communist, Jorgen Jensen; Left Socialist,
Preben Wilnjelm; Center Democratic,
Erhard Jakobsen; Christian People’s, Chris-
tian Christensen; Justice, Poul Gerhard
Kristiansen; Trade and Industry Party,
Asger J. Lindinger; Free Democratic
Party, Mogens Glistrup; Socialist Workers
Party, no chairman; Communist Workers’
Party (KAP), Benito Scocozza
Voting strength: (1984 election) 31.6%
Social Democratic, 23.4% Conservative,
12.1% Liberal, 11.5% Socialist People’s,
5.5% Radical Liberal, 4.6% Center Demo-
cratic, 3.6% Progress, 2.7% Christian
People’s, 2.6% Left Socialist, 1.5% Justice,
0.7% Communist, 0.2% others
Member of: ADB, Council of Europe,
DAC, EC, ELDO (observer), EMS, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ICES, ICO, IDA, IDB, Inter-American
Development Bank, IEA, IFAD, IFC,
IHO, ILO, International Lead and Zinc
Study Group, IMF, IMO, INTELSAT,
INTERPOL, IPU, ISO, ITC, ITU, IWC—
International Wheat Council, NATO,
Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG','c38da61622115fbf38982a042b59318fbe836e49ec24d6eca6e584627b8ee439','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a0189f23b7bc949597ff3257b1e2daeb8797466b450131dd00cf486d5518bfe',1987,'DJ','Djibouti','government',214,'Official name: Republic of Djibouti
National holiday: 27 June
Type: republic
Capital: Djibouti
Administrative divisions: 5 cercles (dis-
tricts)
Legal system: based on French civil law
system, traditional practices, and Islamic
law; partial constitution ratified January
1981 by National Assembly
Branches: legislative—65-member parlia-
ment (National Assembly), executive,
judiciary
Government leader: Hassan GOULED
Aptidon, President (since June 1977)
Suffrage: universal adult
Elections: parliament elected May 1982
Political party and leader: Peoples
Progress Assembly (RPP), Hassan Gouled
Aptidon; sole legal party
Communists: possibly a few sympathizers
Member of: AfDB, Arab League, FAO,
G-77, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTERPOL, ITU, NAM,
OAU, OIC, UN, UPU, WFTU, WHO,
WMO','5b738b2afc0643413f6989311e33c81f7e202d7b5eecbca7d2572f05c6462ee0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5feafc17672f96e1ed8ff315aee7f2863e36b6be310fa8250a0cd08802a8ced',1987,'DM','Dominica','government',219,'Official name: Commonwealth of Domin-
ica
Type: independent state within Common-
wealth
Capital: Roseau
Administrative divisions: 10 parishs
Legal system: based on English common
law; three local magistrate courts and the
British Caribbean Court of Appeals
Branches: legislative, 51-member bicam-
eral House of Assembly (1 ex-officio mem-
ber, 9 appointed members, and 21 popu-
larly elected members; executive, Cabinet
headed by Prime Minister; judicial,
magistrate’s courts and regional court of
appeals
Government leaders: (Mary) Eugenia
CHARLES, Prime Minister (since July
1980); Sir Clarence SEIGNORET, Presi-
dent (since December 1983)
Suffrage: universal adult suffrage at age 18
Elections: every five years; last held 2 July
1985
Political parties and leaders: Labor Party
of Dominica (DLP, a leftist-dominated
coalition), Michael Douglas; Dominica
Freedom Party (DFP), (Mary) Eugenia
Charles
Voting strength: (1985 election) House of
Assembly seats—DFP 15, LPD 5, indepen-
dent 1
Communists: negligible
Other political or pressure groups:
Dominica Liberation Movement (DLM), a
small leftist group
Member of: CARICOM, Commonwealth,
FAO, GATT (de facto), G-77, IBRD, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
OAS, UN, UNESCO, UPU, WHO, WMO','3f42adb82672aae36745cb454b4c94fdfd4c9984c10f8c5661333eeb6b2683a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('093bf9358a096321daae0f9aa9e49ac87c3f703ba4b526f7a1d6854624a0764f',1987,'DO','Dominican Republic','government',224,'Official name: Dominican Republic
Type: republic
Capital; Santo Domingo
Administrative divisions: 29 provinces
and the National District
Legal system: based on French civil codes;
1966 constitution
National holiday: Independence Day, 27
February
Branches: President popularly elected for
a four-year term; bicameral legislature
(National Congress—30-seat Senate and
120-seat Chamber of Deputies elected for
four-year terms); Supreme Court
Government leader: Joaquin BALAGUER
Ricardo, President (since August 1986)
Suffrage: universal and compulsory, over
age 18 or married, except members of the
armed forces and police, who cannot vote
Elections: ast national election 16 May
1986; next election 16 May 1990
Political parties and leaders: Dominican
Revolutionary Party (PRD), Salvador Jorge
Blanco, Jacobo Majluta, and José Francisco
Pefia Gomez; Social Christian Reformist
Party (PRSC), Joaquin Balaguer Ricardo
(formed in 1984 by merger of Reformist
Party and Social Christian Revolutionary
Party); Dominican Liberation Party (PLD),
Juan Bosch Gavino; The Structure (LE),
Andres Van Der Horst; Democratic
Quisqueyan Party (PQD), Elias Wessin y
Wessin; Constitutional Action Party (PAC),
Luis Arzeno Rodriguez; National Progres-
sive Force (FNP), Marino Vinicio Castillo;
Popular Christian Party (PPC), Rogelio
Delgado Bogaert; Dominican Communist
Party (PCD), Narciso Isa Conde; Anti-
Imperialist Patriotic Union (UPA), Ivan
Rodriguez; in 1983 several leftist parties,
including the PCD, joined to form the
Dominican Leftist Front (FID); however
they still retain individual party structures
Voting strength: (1986 election) 72% voter
turnout; 40.6% PRSC, 33.5% PRD, 18.3%
PLD; 5.8% LE; 2.3% minor parties
Communists: an estimated 8,000 to 10,000
members in several legal and illegal fac-
tions; effectiveness limited by ideological
differences and organizational inadequa-
cies
Member of: FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IRC,
ISO, ITU, OAS, PAHO, SELA, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WTO','9475d95213571b7a41d5fa3efea2b865ceef025331f731d20619fbdb47538e5b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c711cc6b1402f2330693778785c601aec655f4b927d17f6c78ddcc2ab337b26',1987,'EC','Ecuador','government',229,'Official name: Republic of Ecuador
National holiday: Independence Day, 10
August
Type: republic
Capital: Quito
Administrative divisions: 20 provinces
including Galapagos Islands
Legal system: based on civil law system;
progressive new constitution passed in
January 1978 referendum; came into effect
following the installation of a new civilian
government in August 1979; has not ac-
cepted compulsory 1CJ jurisdiction
Branches: executive; unicameral legisla-
ture (Chamber of Representatives); inde-
pendent judiciary
Government leader: Le6n FEBRES-
CORDERO Ribadeneyra, President (since
August 1984)
Suffrage: universal over age 18; compul-
sory for literate
Elections: parliamentary and presidential
elections held January 1984; second-stage
presidential election held May 1984;
government and legislature took office in
August 1984; an amendment to the consti-
tution in August 1983 changed the term of
office for the President from five to four
years; the 59 deputies elected by the
provinces serve for two years; the 12
at-large deputies serve for four years; next
presidential election scheduled for 1988
69
Political parties and leaders: Social Chris-
tian Party (PSC, the party of President
Leon Febres-Cordero), center-right; Popu-
lar Democracy (DP), Osvaldo Hurtado;
Christian Democratic, Julio César Trujillo;
Democratic Left (1D), Xavier Ledesma;
Social Democratic, Rodrigo Borja; Radical
Alfarist Front (FRA), Cecilia Calderén de
Castro, populist; Democratic Party (PD),
Francisco Huerta, center-left; Radical
Liberal Party, Eudoro Loor Rivadeneira,
center-right; Conservative Party, José
Teran, center-right; Concentration of
Popular Forces (CFP), Averroes Bucaram,
populist; People, Change, and Democracy
(PCD), Aquiles Rigail Santistevan, center-
left; Democratic Popular Movement
(MPD), Jaime Hurtado, Communist; Revo-
lutionary Nationalist Party (PNR), Carlos
Julio Arosemena, center-right; Broad
Leftist Front (FADI), René Mangé, pro-
Moscow Communist
Voting strength: results of May 1984
presidential runoff election—Le6én Febres-
Cordero of the Social Christian Party, who
headed the coalition National Reconstruc-
tion Front, 52.2%; Rodrigo Borja of the
Democratic Left, 47.8%
Communists: Communist Party of Ecua-
dor (PCE, pro-Moscow, René Maugé—
secretary general), 6,000 members; Com-
munist Party of Ecuador/Marxist Leninist
(PCMLE, Maoist), 6,000 members; Revolu-
tionary Socialist Party of Ecuador (PSRE,
pro-Cuba), 100 members plus an estimated
5,000 sympathizers
Member of: Andean Pact, ECOSOC,
FAO, G-77, IADB, IAEA, IBRD, ICAO,
ICO, IDA, IDB—Inter-American Develop-
ment Bank, IFAD, IFC, IHO, 1LO, IMF,
IMO, INTELSAT, INTERPOL, IRC, ITU,
LAIA, NAM, OAS, OPEC, PAHO, SELA,
UN, UNESCO, UPEB, UPU, WFTU,
WHO, WMO, WTO','c6c5662753afa1445b54f46c411fd32e486e4bf1203b7a5c7fc544cd9faa48b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce087c4798f4f4cd2b4f1733b41b11d000e69549b83092602f2a184ceefe4a75',1987,'EG','Egypt','government',234,'Official name: Arab Republic of Egypt
Type: republic
Capital: Cairo
Administrative divisions: 26 governorates
Legal system: based on English common
law, Islamic law, and Napoleonic codes;
permanent constitution written in 1971;
judicial review of limited nature in Su-
preme Court, also in Council of State,
which oversees validity of administrative
decisions; accepts compulsory [CJ jurisdic-
tion, with reservations
National holiday: National Day, 23 July
Branches: executive power vested in
President, who appoints Cabinet; People’s
Assembly is principal legislative body, with
Shura Council having consultative role;
independent judiciary administered by
Minister of Justice
Government leaders: Mohammed Hosni
MUBARAK, President (since 1981); “Atif
SIDQI (since November 1986)
Suffrage: universal over age 18
Elections: regular elections to People’s
Assembly every five years (next slated for
April 1987); two-thirds of Shura Council is
elected for six-year term (first elections
were in September 1980) with remaining
members appointed by President; presi-
dential election every six years; last held
October 1981
Political parties and leaders: formation of
political parties must be approved by
government; National Democratic Party,
led by Mubarak, is the dominant party;
legal opposition parties are Socialist Lib-
eral Party, Kamal Murad; Socialist Labor
Party, Ibrahim Shukri; National Progres-
sive Unionist Grouping, Khalid Muhyi-al-
Din; Umma Party, Ahmad al-Sabahi; and
New Wafd Party, Fu’ad Siraj al-Din
Communists: about 500 party members
Other political or pressure groups: Is-
lamic groups are illegal, but the largest
one, the Muslim Brotherhood, is tolerated
by the government; trade unions and
professional associations are officially
sanctioned
Member of: AAPSO, AfDB, FAO, G-77,
GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, LOOC, IPU, IRC, ITU,
1WC—lInternational Wheat Council,
NAM, OAU, OIC, UN, UNESCO, UPU,
WHO, WIPO, WMO, WPC, WSG, WTO,
Egypt suspended from Arab League and
OAPEC in April 1979
Official name: Republic of El Salvador
Type: republic
Capital: San Salvador
Administrative divisions: 14 departments
Legal system: based on Spanish law, with
traces of common law; new constitution
enacted in December 1983; judicial review
of legislative acts in the Supreme Court;
accepts compulsory ICJ jurisdiction, with
reservations
National holiday: Independence Day, 15
September
Branches: Legislative Assembly (60 seats),
Executive, Supreme Court
Government leaders: José Napoleén
DUARTE, President (since June 1984);
Rodolfo CASTILLO Claramount, Vice
President (since June 1984); Abraham
RODRIGUEZ, First Presidential Designate
(since September 1984); René FORTIN,
Magafia, Second Presidential Designate
(since September 1984)
Suffrage: universal over age 18
Elections: Legislative Assembly (formerly
Constituent Assembly), 28 March 1982;
presidential election, 25 March 1984;
presidential runoff election, 6 May 1984
(next scheduled for 1989); Legislative
Assembly election, 31 March 1985
Political parties and leaders: Christian
Democratic Party (PDC), José Antonio
Morales Erlich; National Conciliation
Party (PCN), Hugo Carrillo; Democratic
Action (AD), Ricardo Gonzdlez Camacho;
Salvadoran Popular Party (PPS), Francisco
Quifiénez; National Republican Alliance
(ARENA), Alfredo Cristiani; Salvadoran
Authentic Institutional Party (PAISA),
Roberto Escobar Garcia; Social Democratic
Party (PSD), Mario René Roldan; Patria
Libre, Hugo Barrera
Voting strength: Legislative Assembly—
PDC, 33 seats; ARENA, 13 seats; PAISA, 1
seat; PCN, 12 seats; independent, } seat
Other political or pressure groups: leftist
revolutionary movement—Unified Revolu-
tionary Directorate (DRU) and Farabundo
Marti National Liberation Front (FMLN),
leadership bodies of the insurgency; Popu-
lar Liberation Forces (FPL), Armed Forces
of National Resistance (FARN), People’s
Revolutionary Army (ERP), Salvadoran
Communist Party/Armed Forces of Liber-
ation (PCES/FAL), and Central American
Workers’ Revolutionary Party (PRTC)/
Popular Liberation Revolutionary Armed
Forces (FARLP); militant front organiza-
tions—Revolutionary Coordinator of
Masses (CRM; alliance of front groups),
Popular Revolutionary Bloc (BPR), Unified
Popular Action Front (FAPU), Popular
Leagues of 28 February (LP-28), National
Democratic Union (UDN), and Popular
Liberation Movement (MLP); Revolution-
ary Democratic Front (FDR), coalition of
CRM and Democratic Front (FD), con-
trolled by DRU; FD consists of moderate
leftist groups—Independent Movement of
Professionals and Technicians of El Salva-
dor (MIPTES), National Revolutionary
Movement (MNR), and Popular Social
Christian Movement (MPSC); extreme
rightist vigilante organizations or death
squads—Secret Anti-Communist Army
(ESA); Maximiliano Hernandez Brigade;
Organization for Liberation From Com-
munism (OLC)
Labor organizations: Federation of Con-
struction and Transport Workers Unions
(FESINCONSTRANS), independent;
Salvadoran Communal Union (UCS),
peasant association; Unitary Federation of
Salvadoran Unions (FUSS), leftist; National
Federation of Salvadoran Workers (FE-
NASTRAS), leftist; Democratic Workers
Central (CTD), moderate; General Confed-
eration of Workers (CGT), moderate;
Popular Democratic Unity (UPD), moder-
ate labor coalition which includes FESIN-
CONSTRANS, and other democratic labor
organizations
Business organizations: National Associa-
tion of Private Enterprise (ANEP), conser-
vative; Productive Alliance (AP), conserva-
tive; National Federation of Salvadoran
Small Businessmen (FENAPES), conserva-
tive
Member of: CACM, FAO, G-77, L[ADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ITU, !WC—International
Wheat Council, OAS, ODECA, PAHO,
SELA, UN, UNESCO, UPU, WFTU,
WHO, WIPO, WMO, WTO','a865e353956b0dc955485d8024a412cd223b00b78505072cc2c35ba4530ec42c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a82205931985b2b69163748e6edadd00b610b9f3d4154029a42899887f4d7f64',1987,'GN','Guinea','government',239,'Type: republic
Capital; Malabo
Administrative divisions: 6 provinces with
appointed governors
Legal system: in transition; constitution
approved 15 August 1982 by popular
referendum; in part based on Spanish civil
law and custom
National holiday: 12 October
Branches: constitution provides for presi-
dent with broad powers, prime minister,
unicameral legislature (House of Represen-
tatives of the People), and free judiciary
Government leader: Col. Teodoro
OBIANG NGUEMA MBASOGO, Presi-
dent (since August 1979)
Suffrage: universal for adults
Elections: parliamentary elections held
October 1983
Political parties and leaders: political
parties suspended; before coup of 3 August
1979, National Unity Party of Workers
(PUNT) was the sole legal party
Communists: no significant number of
Communists but some sympathizers
Member of: AfDB, Conference of East
and Central African States, ECA, FAO,
G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, ILO, IMF, IMO, INTERPOL,
ITU, NAM, OAU, UN, UNESCO, UPU,
WHO
Official name: Republic of Guinea
Type: republic
Capital: Conakry
Administrative divisions: 33 provinces,
divided into 36 prefectures
Legal system: based on French civil law
system, customary law, and decree; 1958
constitution suspended after military coup
on 3 April 1984; legal codes currently
being revised; has not accepted compul-
sory IC) jurisdiction
National holiday: Independence Day, 2
October; Anniversary of Committee for
National Redressment, 3 April
Branches: coup on 8 April 1984 estab-
lished 17-member Military Committee for
National Redressment (CMRN) to deter-
mine government policy; the highest
ranking CMRN member became Presi-
dent, with other CMRN assuming most
Cabinet portfolios
Government leader: Gen. Lansana
CONTE, Head of Government (since April
1984)
Suffrage: universal over age 18
Elections: none scheduled but CMRN has
promised to create a true and viable
democracy
Political parties and leaders: following 3
April 1984 coup all political activity was
banned
102
Communists: no Communist party, al-
though there are some sympathizers
Member of: AfDB, ECA, ECOWAS, FAO,
G-77, IBA, IBRD, ICAO, ICO, IDA,
IDB—Islamic Development Bank, IFAD,
ILO, IMF, IMO, INTELSAT, INTERPOL,
ITU, Mano River Union, Niger River
Commission, NAM, OAU, OATUU, OIC,
UN, UNESCO, UPU, WHO, WMO
Official name: Republic of Indonesia
Type: republic
Capital; Jakarta
Administrative divisions: 28 first-level
administrative subdivisions or provinces,
which are further subdivided into 282
second-level areas
Legal system: based on Roman-Dutch
law, substantially modified by indigenous
concepts and by new criminal procedures
code; constitution of 1945 is legal basis of
government; has not accepted compulsory
IC] jurisdiction
National holiday: Independence Day, 17
August
Branches: executive headed by President
who is chief of state and head of Cabinet;
Cabinet selected by President; unicameral
legislature (DPR or House of Representa-
tives) of 460 members (96 appointed, 364
elected); second body (MPR or People’s
Consultative Assembly) of 920 members
includes the legislature and 460 other
members (chosen by several processes, but
not directly elected); MPR elects President
and Vice President and theoretically
determines national policy; judicial, Su-
preme Court is highest court
Government leader: Gen. (Ret.)
SOEHARTO, President (since March 1968)
Suffrage: universal over age 18 and mar-
ried persons regardless of age
Political parties and leaders: Golkar
(quasi-official party based on functional
groups), Lt. Gen. Sudharmono; Indonesia
Democracy Party (federation of former
Nationalist and Christian Parties), Soeryad
(chairman) and Nicholas Daryanto (secre-
tary general); United Development Party
(federation of former {Islamic parties), John
Naro
Voting strength: (1982 election) Golkar
64.1%, Unity Development 28%, Indonesia
Democracy 7.9%
Communists: Communist Party (PKI) was
officially banned in March 1966; current
strength about 1,000-3,000, with less than
10% engaged in organized activity; pre-
October 1965 hardcore membership about
1.5 million
Member of: ADB, ANRPC, ASEAN,
Association of Tin Producing Countries,
CIPEC, ESCAP, FAO, G-77, GATT,
IAEA, IBA, IBRD, ICAO, ICO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, [IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ISO, 1TC, 1TU,
NAM, OIC, OPEC, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WTO
Official name: Islamic Republic of Iran
Type: theocratic republic
Capital: Tehran
Administrative divisions: 24 provinces,
subdivided into districts, subdistricts,
counties, and villages
Legal system: the new constitution codi-
fies Islamic principles of government
National holiday: Shi''a Islam religions
holidays observed nationwide
Branches: Ayatollah ol-Ozma Ruhollah
Khomeini, the leader of the revolution,
provides general guidance for the govern-
ment, which is divided into executive,
unicameral legislature (Islamic Consulta-
tive Assembly), and judicial branches
Government leaders: Ayatollah ol-Ozma
Ruhollah KHOMEINI, Guardian Jurispru-
dent (since February 1979); Ali KHAME-
NEI (cleric), President (since October
116
1981); Mir Hosein MUSAVI-KHAMENE],
Prime Minister (since Octoher 1981); Ali
Akbar HASHEMI RAFSANJANI (cleric),
Speaker of Islamic Consultative Assembly
(since July 1980); Ayatollah Hosein Ali
MONTAZERI, Designated Successor to
Ayatollah Ruhollah Khomeini (22 Novem-
ber 1985)
Suffrage: universal over age 15
Elections: elections to select a President
held in August 1985; those to select an
Assembly of Experts to name Khomeini’s
successor held in December 1982; parlia-
mentary elections held in 1984; next
presidential election to be held during the
summer of 1989; next parliamentary
elections to be held in 1988
Political parties and leaders: Islamic
Republic Party (IRP), Ali Khamenei;
Freedom Movement, Mehdi Bazargan
Voting strength: reliable figures not avail-
able; supporters of the Islamic Republic
dominate the parliament
Communists: 1,000 to 2,000 est. hardcore;
15,000 to 20,000 est. sympathizers; crack-
down in 1983 crippled the party; trials of
captured leaders began in late 1983 and
remain incomplete
Other political or pressure groups:
Mojahedin Khalq Organization (MKO),
People’s Fedayeen, and Kurdish Demo-
cratic Party are armed political groups
that have been almost completely re-
pressed by the government; other powerful
progovernment groups include Fedayeen
Islam Organization, Hezbollah, Hojjatiyeh
Society, Mojahedin of the Islamic Revolu-
tion, Muslim Students Following the Line
of the Imam, and Tehran Militant Clergy
Association
Member of: Colombo Plan, ESCAP, FAO,
G-77, IAEA, IBRD, ICAC, ICAO, IDA,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITU,
NAM, OIC, OPEC, Economic Cooperation
Organization, UN, UNESCO, UPU,
WFTU, WHO, WMO, WSG, WTO;
continued participation in some of these
organizations doubtful under the new
Islamic constitution
Official name: Democratic Republic of','f06408df541e8a1daa56a1edaad2ea77f5516a3540358d62c988abf522e91481','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155303076f03ceda2d8fcf1e0358b328d02544840ce531a4829190184013dbde',1987,'ET','Ethiopia','government',245,'Official name: Socialist Ethiopia
Type: under military rule since September
1974; monarchy abolished in March 1975,
republic to be formed in 1987
Capital: Addis Ababa
Administrative divisions: 14 provinces
Legal system: complex structure with
civil, Islamic, coramon, and customary law
influences; constitution suspended Septem-
ber 1974—military leaders have promised
a referendum on a new constitution in
early 1987; has not accepted compulsory
ICJ jurisdiction
National holiday: Popular Revolution
Commemoration Day, 12 September
Branches: executive power exercised by
the Provisional Military Administrative
Council (PMAC), dominated by its chair-
man and small circle of associates; pre-
dominantly civilian Cabinet holds office at
sufferance of military; legislature dissolved
September 1974; judiciary at higher levels
based on Western pattern, at lower levels
on traditional pattern, without jury system
in either
75
Government leader: Lt. Col. MENGISTU
Haile-Mariam, Chairman of the Provi-
sional Military Administrative Council
(since February 1977)
Suffrage: none
Elections: referendum on new constitution
promised for early 1987 to be followed by
elections for president and National As-
sembly
Political party and leader: Ethiopian
Workers Party (WPE), Mengistu Haile-
Mariam
Communists: government is officially
Marxist-Leninist
Other political or pressure groups: impor-
tant dissident groups include Eritrean
Liberation Front (ELF), Eritrean People’s
Liberation Front (EPLF) in Eritrea;
Tigrean People’s Liberation Front (TPLF)
in Tigray and Welo Provinces; Western
Somali Liberation Front (WSLF) in the
Ogaden region
Member of: AfDB, ECA, FAO, G-77,
IAEA, IBRD, ICO, ICAO, IDA, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ITU, NAM, OAU, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WTO
Official name: Colony of the Falkland
Islands
Type: British dependent territory
Capital: Stanley
Administrative divisions: Falkland, South
Georgia, and South Sandwich Islands (the
latter two are administered from Stanley)
Legal system: English common law
Branches: under the 1985 Constitution an
Executive Council was established; it
consists of three elected members from the
eight-member popularly elected Legisla-
tive Counil
Government leaders: Gordon W.
JEWKES, Governor (since 1985); Rear
Admiral Christopher CAYMAN, Com-
mander of the British Armed Forces (since
1986)
Suffrage: universal adult at age 18','f77a08b6685916426fb7344f86510f86da2bc8e2003dd7a51087d900c9930583','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333af366ba3b64215d7070366f7a9d1390e6890e96b230a395b5991c5657b150',1987,'FO','Faroe Islands','government',250,'Official name: Faroe Islands
Type: self-governing province within the
Kingdom of Denmark; 2 representatives in
Danish parliament
Capital: Torshavn on the island of
Streymoy
Administrative divisions: 7 districts, 49
communes, 1 town
Legal system: based on Danish law; Home
Rule Act enacted 1948
Branches: legislative authority rests jointly
with Crown, acting through appointed
High Commissioner, and 32-member
provincial parliament (Lagting) in matters
of strictly Faroese concern; executive
power vested in Crown, acting through
High Commissioner, but exercised by
provincial cabinet responsible to provincial
parliament
Government leaders: MARGRETHE II,
Queen (since January 1972); Atli DAM,
Lagmand, Prime Minister (since December
1984); Niels BENTSEN, Danish Governor
(since 1981)
Suffrage: universal, but not compulsory,
over age 2]
Elections: held every four years; most
recent, 8 November 1984
Political parties and leaders: four-party
ruling coalition—Social Democratic, Atli
Dam; Republican, Erlendur Patursson;
Home Rule, Tgbijern Poulsen; Peoples,
Jogvan Sundstéi.i
Voting strength! (January 1985) four-party
coalition—17 of 32 seats
Communists: insignificant number
Member of: Nordic Council
Faroe Islands (continued)
Official name: Fiji
Type: independent parliamentary state
within Commonwealth; Elizabeth II recog-
nized as chief of state
Capital: Suva
Administrative divisions: 4 divisions
Legal system: based on British system
National holiday: Fiji Day, 10 October
Branches: executive—Prime Minister and
Cabinet; legislative—52-member House of
Representatives; 22-member appointed
Senate; judicial—Supreme Court, Court of
Appeal, Magistrate’s Courts
Government leader: Ratu Sir Kamisese
MARA, Prime Minister (since 1966; was
Chief Minister before independence)
Suffrage: universal adult
Elections: every five years unless House
dissolves earlier; last held July 1982
Political parties: Alliance, primarily
Fijian, headed by Ratu Mara; National
Federation, primarily Indian, headed by
Siddiq Koya; Western United Front,
Fijian, Ratu Osea Gavidi; Fiji Labor Party
(founded in mid-1985), headed by Dr.
Timoci Bavadra
Voting strength: (July 1982) House of
Representatives—Alliance Party 28 seats,
National Federation Party/Western United
Front coalition 24 seats
Communists: some
Member of: ADB, Colombo Plan, Com-
monwealth, EC (associate), ESCAP, FAO,
G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ISO, ITU, SPF,
UN, UNESCO, UPU, WFTU, WHO,
WIPO, WMO','5ebefaf385a65496c2bee28d866fcc0596cf48c6e19d1daa019f0a2876e77548','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f622cf245397626d2eebcd5481abebf1d9f645dd0b8f0f8636b4f2416dd08d1',1987,'FI','Finland','government',255,'Official name: Republic of Finland
Type: republic
Capital: Helsinki
Administrative divisions: 12 provinces,
377 communes, 84 towns
Legal system: civil law system based on
Swedish law; constitution adopted 1919;
Supreme Court may request legislation
interpreting or modifying laws; accepts
compulsory IC) jurisdiction, with reserva-
tions
National holiday: Independence Day, 6
December
Branches: legislative authority rests jointly
with President and unicameral legislature
(Eduskunta); executive power vested in
President and exercised through coalition
Cabinet responsible to parliament; Su-
preme Court, four superior courts, 193
lower courts
Government leaders: Dr. Mauno
KOIVISTO, President (since January
1982); Kalevi SORSA, Prime Minister
(since February 1982)
Suffrage: universal, 18 years and over; not
compulsory
Elections: parliamentary, every four years
(next in March, 1991); presidential, every
six years (next in 1988)
Political parties and leaders: Social Dem-
ocratic Party, Kalevi Sorsa; Center Party,
Paavo Vayrynen; People’s Democratic
League (majority Communist front), Esko
Helle; Nationa! Coalition (Conservative)
Party, Ilkka Suominen; Liberal People’s
Party, Kyésti Lallukka; Swedish People’s
Party, Christoffer Taxell; Rural Party,
Pekka Vennamo; Finnish Communist
Party (majority Communist faction), Arvo
Aalto; Finnish Communist Party-Unity
(minority faction), Taisto Sinisalo; Demo-
cratic Alternative (minority Communist
front), Kristiina Halkola; Finnish Christian
League, Esko Almgren; Constitutional
Rightist Party, Georg Ehrnrooth; Finnish
Pensioners Party; Greens
Voting strength: (1987 parliamentary
election) 24.8% Social Democratic (56
seats), 23.9% Conservative (58 seats), 18.6%
Center-Liberal (40 seats), 9.4% People’s
Democratic League (16 seats), 6.8% Rural
(9 seats), 5.3% Swedish Peoples (18 seats),
4.3% Democratic Alternative (4 seats),
4.0% Greens (4 seats), 2.6% Christian
League (5 seats), 1.2% Pensioners (no seats),
0.1% Constitutional Rightist (no seats)
Communists: 28,000 registered members;
an additional 45,000 persons belong to
People’s Democratic League
Member of: ADB, CEMA (special cooper-
ation agreement), DAC, EC (free trade
agreement), EFTA (associate), FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES,
ICO, IDA, 1DB—Inter-American Develop-
ment Bank, IFAD, IFC, IHO, 1LO, Inter-
national Lead and Zinc Study Group,
IMF, IMO, INTERPOL, IPU, ITU,
IWC—Internationa] Wheat Council,
Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG','790631b67b0167afdb09ce4dfb94800d45aa2804117020b3651c40a9a77af0bc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a288bc727f7a746d91ab9094c2674f879a09b7d2883785d0d722c722c077e34',1987,'FR','France','government',260,'Official name: French Republic
Type: republic, with President whose
previously wide powers have been some-
what curtailed by current power-sharing
arrangement with Prime Minister
Capital: Paris
Administrative divisions: 22 regions with
96 metropolitan departments
Dependent areas: Bassas da India, Clip-
perton Island, Europa Island, French
Guiana, French Polynesia, French South-
ern and Antarctic Lands, Glorioso Islands,
Guadeloupe, Juan de Nova Island, Martin-
ique, Mayotte, New Caledonia, Reunion,
St. Pierre and Miquelon, Tromelin Island,
Wallis and Futuna Island
France (continued)
Legal system: civil law system with indig-
enous concepts; new constitution adopted
1958, amended concerning election of
President in 1962; judicial review of ad-
ministrative but not legislative acts
National holiday: National Day, 14 July
Branches: presidentially appointed Prime
Minister heads Council of Ministers, which
is formally responsible to National Assem-
bly; bicameral legislature—National As-
sembly (577 members), Senate (317 mem-
bers)—restricted by a delaying action;
judiciary independent in principle
Government leaders: Francois MITTER-
RAND, President (since May 1981);
Jacques CHIRAC, Prime Minister (since
March 1986)
Suffrage: universal over age 18; not com-
pulsory
Elections: National Assembly—every five
years, last election March 1986, two-round
majority system enacted in October 1986;
Senate—indirect collegiate system for nine
years, renewable by one-third every three
years, last election September 1986; Presi-
dent, direct, universal suffrage every seven
years, two ballots, last election May 1981
Political parties and leaders: majority
coalition—Rally for the Republic (RPR,
formerly UDR), Jacques Chirac; Union for
French Democracy (UDF, federation of
PR, CDS, and RAD), Jean Lecanuet;
Republicans (PR), Francois Léotard; Cen-
ter for Social Democrats (CDS), Pierre
Méhaignerie; Radical (RAD), André Rossi-
not; left opposition—Socialist Party (PS),
Lionel Jospin; Left Radical Movement
(MRG), Francois Doubin; Communist
Party (PCF), Georges Marchais; extreme
right party National Front (FN), Jean-
Marie Le Pen
Voting strength: (1986 election)
UDF/RPR/CNIP, 44.9%; PS/MRG 31.6%;
Communist, 9.8%; National Front, 9.7%;
diverse left, 1.0%; extreme left, 1.5%;
extreme right, 0.2%; other 1.2%
Communists: 700,000 claimed but proba-
bly closer to 150,000; Communist voters,
2.7 million in 1986 elections
Other political or pressure groups:
Communist-controlled labor union (Conféd-
ération Générale du Travail) nearly 2.4
million members (claimed); Socialist-
leaning labor union (Confédération Fran-
caise Démocratique du Travail—CFDT)
about 800,000 members est.; independent
labor union (Force Ouvriére) about
1,000,000 members est.; independent white
collar union (Confédération Générale des
Cadres) 840,000 members (claimed); Na-
tional Council of French Employers (Con-
seil National du Patronat Fran¢éais—CNPF
or Patronat)
Member of: ADB, Council of Europe,
DAC, EC, EIB, ELDO, EMA, EMS,
ESCAP, ESRO, FAO, GATT, JAEA, [ATP,
IBRD, ICAC, ICAO, ICES, ICO, IDA,
IDB—Inter-American Development Bank,
IFAD, 1FC, [HO, 1LO, International Lead
and Zine Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU,
IRC, ISO, ITC, ITU, [WC—International
Whaling Commission, NATO (signatory),
OAS (observer), OECD, South Pacific
Commission, UN, UNESCO, UPU, WEU,
WFTU, WHO, WIPO, WMO, WSG,
WTO','621473bb8f07b8127e8d92759046d593acef4e5cb0e8c36eee175f5bb9c74b3c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffea679bb67d7aaa39937a924fb95f48b09e4337c3b95a82c18edda327c67f4',1987,'GF','French Guiana','government',265,'Official name: Department of French
Guiana
Type: overseas department and region of
France; represented by one deputy in
French National Assembly and one senator
in French Senate
Capital: Cayenne
Administrative divisions: 2 arrondisse-
ments, 19 communes each with a locally
elected municipal council
Legal system: French legal system; highest
court is Court of Appeals based in Martin-
ique with jurisdiction over Martinique,
Guadeloupe, and French Guiana
Branches: executive—Prefect appointed
by Paris; legislative—popularly elected
16-member General Council and a Re-
gional Council composed of members of
the local General Council and of the
locally elected deputy and senator to the
French parliament; judicial, under jurisdic-
tion of French judicial system
Government leader: Bernard COURTOIS,
Prefect of the Republic (since 1984)
Suffrage: universal over age 18
Elections: General Council elections
normally are held every five years; last
election February 1983
Political parties and leaders: Guianese
Socialist Party (PSG), Raymond Tarcy
(senator), Léopold Helder; Union of the
Guianese People (UPG), weak leftist party
allied with and reported to have been
absorbed by the PSG; Rally for the Repub-
lic (RPR), Héctor Rivierez; National Anti-
Colonist Guianese Party (PANGA), Michel
Kapel; Popular and National Party of
Guiana (PNPG), Michael Alain
French Guiana (continued)
Communists: Communist party member-
ship negligible
Member of: WFTU','4f4d82b6548f1198a8ffbb44dfe2d5b78a41fa80bb42dc4ddbd844d66bd67fc3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3977dfdbd9c6a32b8a4325ebcb72fe121f9f34a387d0a432aaea797e71b0e6f',1987,'PF','French Polynesia','government',270,'Official name: Territory of French Poly-
nesia
Type: overseas territory of France
Capital: Papeete
|
Administrative divisions: 48 communes
Legal system: based on French; lower and
higher courts
Branches: 30-member Territorial Assem-
bly, popularly elected; five-member Coun-
cil of Government, elected by Assembly;
popular election of two deputies to Na-
tional Assembly and one senator to Senate
in Paris
Government leaders: Pierre ANGELI,
High Commissioner appointed by French
| Government (since April 1986); Jacques
TEUIRA, President of the Territorial
Government (since February 1987),
Jacques TEHEIURA, Vice President of the
Territorial Government
| Suffrage: universal adult
Elections: every five years; last held in
| May 1982
Political parties and leaders: Tahoeraa
- Huiraatira (Gaullist), Gaston Flosse; Ai’a
Api (New Country Party), Emile Vern-
audon; Here Ai’a, Jean Juventin; la Mana
(Socialist), Jacques Crollet; Te E’a Api
(Socialist), Jacques VII
Voting strength: (1982 election) Tahoeraa
Huiraatira, 13 seats; Ai’a Api, 3 seats; Here
Ai’a, 6 seats; la Mana, 3 seats; Indepen-
dents, 4 seats; Te E’a Api, 1 seat','be88c1b6af768cd164d8889658ee2f5bddc735c453a4ebb0a7faced834bee6f3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89bf8d1b39932a0c65fc1e0e59462dec88475e153abf188911093f4998a1647a',1987,'GA','Gabon','government',274,'Official name: Gabonese Republic
Type: republic; one-party presidential
regime since 1964
Capital: Libreville
Administrative divisions: nine provinces
subdivided into 36 prefectures
Legal system: based on French civil law
system and customary law; constitution
adopted 196]; judicial review of legislative
acts in Constitutional Chamber of the
Supreme Court; legal education at Center
of Higher and Legal Studies at Libreville;
compulsory ICJ jurisdiction not accepted
National holidays: Renovation Day, 12
March; Independence Day, 17 August;
major Islamic and Christian holidays
Branches: power centralized in President,
elected by universal suffrage for seven-
year term; unicameral legislature (98-
member National Assembly, including
nine members chosen by Omar Bongo) has
limited powers; constitution amended in
1979 so that Assembly deputies will serve
five-year terms; independent judiciary
Government leader: El Hadj Omar
BONGO, President (since December 1967)
Suffrage: universal over age 18
Elections: presidential election last held
autumn 1986; parliamentary election last
held February-March 1985; constitutional
change separates dates for presidential and
parliamentary elections
Politica] party and leader: Gabonese
Democratic Party (PDG) led by President
Bongo is only legal party
Communists: no organized party; probably
some Communist sympathizers
Member of: AfDB, African Wood Organi-
zation, Conference of East and Central
African States, BDECA (Central African
Development Bank), EAMA, EIB (associ-
ate), FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICCO, ICO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, 1PU,
ITU, NAM, OAU, OIC, OPEC, UDEAC,
UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO','49073808935db177d2474f80f94bb5499e786b78722816d238fa2438687cd165','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535878793544bc9962c2227bec75c939a2c1a526edecbcaa0a1f9bd9f34e09f7',1987,'SN','Senegal','government',278,'Official name: Republic of The Gambia
Type: republic; independent since Feb-
ruary 1965; in 1982 The Gambia and
Senegal formed a loose confederation
named Senegambia that calls for the
eventual integration of their armed forces
and economic cooperation
Capital: Banjul
Administrative divisions: Banjul and five
divisions
Legal system: based on a composite of
English common law, Koranic law, and
customary law; constitution came into
force upon independence in 1965, new
republican constitution adopted in April
1970; accepts compulsory 1CJ jurisdiction,
with reservations
National holiday: Independence Day, 18
February
Branches: unicameral legislative branch
(43-member parliament), in which four
seats are reserved for tribal chiefs, four are
government appointed, 35 are filled by
election for five-year terms, a Speaker is
elected by the House, and the Attorney
General is an appointed member; indepen-
dent judiciary
Government leader: Sir Dawda Kairaba
JAWARA, President (since February 1970)
Political parties and leaders: People’s
Progressive Party (PPP), secretary general,
Dawda K. Jawara; National Convention
Party (NCP), Sheriff Dibba; Gambian
People’s Party (GPP), Assan Musa Camara;
United Party (UP)
87
Suffrage: universal adult over 21
Elections: general election held March
1987
Voting strength: PPP 27 seats, NCP 4
seats, others 4 seats
Communists: no Communist party
Member of: AfBD, APC, Commonwealth,
ECA, ECOWAS, FAO, G-77, GATT,
IBRD, ICAO, IDA, 1DB—Inter-American
Development Bank, IFAD, IFC, IMF,
IMO, IRC, ITU, NAM, OAU, OIC, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WTO
Official name: German Democratic Re-
public
Type: Communist state
Capital: East Berlin (not officially recog-
nized by US, UK, and France, which
together with the USSR have special rights
and responsibilities in Berlin)
Administrative divisions: (excluding East
Berlin) 14 districts (Bezirke), 218 counties
(Kreise), 7,570 communities (Gemeinden)
Legal system: civil law system modified
by Communist legal theory; new constitu-
tion adopted 1974; court system parallels
administrative divisions; no judicial review
of legislative acts; has not accepted com-
pulsory IC) jurisdiction; more stringent
penal code adopted in 1968 and amended
in 1974 and 1979
National holiday: Foundation of German
Democratic Republic, 7 October
Branches: unicameral legislature (People’s
Chamber—Volkskammer, elected directly);
executive (Council of State, Council of
Ministers); judiciary (Supreme Court);
entire structure dominated by Socialist
Unity (Communist) Party
Government leaders: Erich HONECKER,
Chairman, Council of State (Head of State;
since October 1976); Willi STOPH, Chair-
man, Council of Ministers (Premier; since
October 1976)
Suffrage: all citizens age 18 and over
Elections: national every five years; pre-
pared by an electoral commission of the
National Front; ballot supposed to be
secret and voters permitted to strike names
off ballot; more candidates than offices
available; parliamentary election held 8
June 1986; local elections held 6 May 1984
Political parties and leaders: Socialist
Unity (Communist) Party of Germany
(SED), headed by General Secretary Erich
Honecker, dominates the regime; four
token parties (Christian Democratic Union,
National Democratic Party, Liberal Demo-
cratic Party, and Democratic Peasants’
Party) and an amalgam of special interest
organizations participate with the SED in
National Front
Voting strength: 1986 parliamentary
elections and 1984 local elections; over
99% voted the regime slate
Communists: 2.195 million party members
(1986)
Other special interest groups: Free Ger-
man Youth, Free German Trade Union
Federation, Democratic Women’s League,
Cultural Leagne of the German Demo-
cratic Republic (all Communist dominated)
Member of: CEMA, IAEA, ICES, ILO,
IMO, IPU, ITU, UN, UNESCO, UPU,
Warsaw Pact, WETU, WHO, WIPO,
WMO, WTO
Official name: Federal Republic of Ger-
many
Type: federal republic
Capital: Bonn
Administrative divisions: 10 lander
(states); Western sectors of Berlin are
ultimately controlled by US, UK, and
France; Eastern sector by USSR; the four
countries share special rights and responsi-
bilities in Berlin
Legal system: civil law system with indig-
enous concepts; constitution adopted 1949;
judicial review of legislative acts in the
Supreme Federal Constitutional Court; has
not accepted compulsory ICJ jurisdiction
Branches: bicameral parliament—Bun-
desrat (Federal Council, upper house),
Bundestag (National Assembly, lower
house); President (titular head of state),
Chancellor (executive head of govern-
ment); independent judiciary
90
Government leaders: Richard von
WEIZSACKER, President (since July
1984); Dr. Helmut KOHL, Chancellor
(since October 1982)
Suffrage: universal over age 18
Elections: national election generally held
every four years; last held on 25 January
1987; next scheduled for 1991
Political parties and leaders: Christian
Democratic Union (CDU), Helmut Kohl,
Heiner Geissler, Walter Wallmann,
Gerhard Stoltenberg, Ernst Albrecht,
Alfred Dregger, Lothar Spaeth; Christian
Social Union (CSU), Franz-Josef Strauss,
Gerold Tandler, Friedrich Zimmermann,
Theo Waigel; Free Democratic Party
(FDP), Martin Bangemann, Hans-Dietrich
Genscher, Wolfgang Mischnick, Helmut
Haussmann; Social Democratic Party
(SPD), Hans-Jochen Vogel, Johannes Rau,
Horst Ehmke, Egon Bahr, Oskar Lafon-
taine; National Democratic Party (NPD),
Martin Mussgnug; Communist Party
(DKP), Herbert Mies; Green Party
(Greens), Rainer Trampert, Otto Schily,
Lukas Beckmann, Joschka Fischer, Jutta
Ditfurth, Thomas Ebermann
Voting strength: (1987 election) 44.3%
CDU/CSU, 37.0% SPD, 9.1% FDP, 8.3%
Greens, 1.3% other
Communists: about 40,000 members and
supporters
Other political or pressure groups: expel-
lee, refugee, and veterans groups
Member of: ADB, Council of Europe,
DAC, EC, EIB, ELDO, EMS, ESRO,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ICES, ICO, IDA, 1DB—Inter-American
Development Bank, IFAD, IEA, IFC,
IHO, ILO, International Lead and Zinc
Study Group, IMF, IMO, INTELSAT,
INTERPOL, IPU, 1TC, ITU, NATO, OAS
(observer), OECD, UN, UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG, WTO
Official name: Republic of Senegal
Type: republic under multiparty demo-
cratic rule; (early in 1982, Senegal and
The Gambia formed a loose confederation
named Senegambia, which calls for the
eventual integration of their armed forces
and economic cooperation)
Capital: Dakar
Administrative divisions: 10 regions,
subdivided into 28 departments, 99 arron-
dissements
Legal system: based on French civil law
system; constitution adopted 1960, revised
1963, 1970, and 1981; judicial review of
legislative acts in Supreme Court, which
also audits the government’s accounting
office; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day,
4 April
Senegal (continued)
Branches: government dominated by the
President; unicameral legislature (120-
member National Assembly), elected for
five years; President elected for five-year
term by universal suffrage; judiciary
headed by Supreme Court, with members
appointed by President
Government leaders: Abdou DIOUF,
President (since January 1981)
Suffrage: universal adult
Elections: presidential and legislative
elections held February 1983; Socialist
Party holds 111 of 120 seats
Political parties and leaders: Socialist
Party (PS), Abdou Diouf; Senegalese Dem-
ocratic Party (PDS), Abdoulaye Wade; 18
other small uninfluential parties
Communists: small number of Commu-
nists and sympathizers
Other political or pressure groups: stu-
dents, teachers, labor, Muslim Brother-
hoods
Member of: AfDB, APC, CEAO, EAMA,
ECA, ECOWAS, EIB (associate), FAO,
G-77, GATT, IAEA, IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ITU, NAM, OAU, OCAM,
OIC, OMVS (Organization for the Devel-
opment of the Senegal River Valley), UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO','cd33c5d8bb4f3c935b6c6d44b8fb786650116fc51d5c24ace3d02c039810c326','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654f1382864daa2f5205b3cebdefd5bf569b2841b78a684bc1bd2aaf912e2b44',1987,'GH','Ghana','government',285,'Official name: Republic of Ghana
Type: military; 31 December 1981 coup
ended two-year-old civilian government,
suspended constitution and political
activity
Capital: Accra
Administrative divisions: 8 administrative
regions and separate Greater Accra Area;
regions subdivided into 58 districts and
267 loca] administrative districts
Legal system: based on English common
law and customary law; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 6
March
Branches: executive authority vested in
seven-member Provisional National De-
fense Council (PNDC); on 21 January 1982
PNDC appointed secretaries to head most
ministries
Government leader: Flt. Lt. (Ret.) Jerry
John RAWLINGS, Chairman of PNDC
(since December 1981)
Elections: none scheduled since 1981 coup
Political parties and leaders: political
parties outlawed after 31 December 198]
coup
Communists: a small number of Commu-
nists and sympathizers
Member of: Af{DB, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA,
IBA, IBRD, ICAO, ICO, IDA, IFAD, IFC,
1LO, IMF, IMO, INTELSAT, INTERPOL,
IRC, ISO, ITU, NAM, OAU, UN,
UNESCO, UPU, World Confederation of
Labor, WHO, WIPO, WMO, WTO','05042d095339ae6d127e7f2a39221a75312d82a43fbf6305168965a86d722acd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba77f1c72848c504731fb4c030cd596579a99504d3b920e61baa098878365a00',1987,'GI','Gibraltar','government',290,'Official name: Gibraltar
Type: British dependent territory
Capital: Gibraltar
Legal system: English law; constitutional
talks in July 1968; new system effected in
1969 after electoral inquiry
Branches: parliamentary system compris-
ing the Gibraltar House of the Assembly
(15 elected members and 3 ex officio
members), the Council of Ministers headed
by the Chief Minister, and the Gibraltar
Council; the Governor is appointed by the
Crown
Government leaders: Air Chief Marshal
Sir Peter TERRY, Governor and Com-
mander in Chief (since 1985); Sir Joshua A.
HASSAN, Chief Minister (1964-69 and
since 1972)
Suffrage: all adult Gibraltarians, plus other
UK subjects resident six months or more
Elections: every four years; last held in
January 1984
Political parties and leaders: Gibraltar
Labor Party/ Association for the Advance-
ment of Civil Rights (GCL/AACR), Sir
Joshua Hassan; Democratic Party of Brit-
ish Gibraltar (DPBG), Peter Isola; Socialist
Labor Party, Joe Bossano
Voting strength: (Jannary 1984) House of
the Assembly—GCL/AACR, 8 seats;
Socialist Labor, 7 seats
Communists: negligible
Other political or pressure groups:
Housewives Association, Chamber of
Commerce, Gibraltar Representatives
Organization
93','b1c7939e53d977a7f832b02d430fbe3dae353901481554f75484118ee93486c8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9896824510dbc67333e90a3c79c9e8e353f1268b5786d3be5dc568186b8e3181',1987,'GR','Greece','government',295,'Official name: Hellenic Republic
Type: presidential parliamentary govern-
ment; monarchy rejected by referendum 8
December 1974
Capital: Athens
Administrative divisions: 51 departments
(nomoi)
Legal system: new constitution enacted in
June 1975
National holiday: Independence Day, 25
March
Branches: executive consisting of a Presi-
dent, elected by the Vouli (Parliament), a
Prime Minister, and a Cabinet; unicameral
legislature consisting of the 300-member
Vouli; and an independent judiciary
Government leaders: Dr. Andreas
PAPANDREOU, Prime Minister (since
1981); Christos SARTZETAKIS, President
(since 1985)
Suffrage: universal age 18 and over
Elections: every four years; Papandreou’s
Panhellenic Socialist Movement defeated
the incumbent New Democracy govern-
ment of George Rallis in elections held on
18 October 1981; PASOK was reelected in
June 1985
Politica) parties and leaders: Panhellenic
Socialist Movement (PASOK), Andreas
Papandreou; New Democracy (ND), Con-
stantine Mitsotakis; Democratic Renewal
(DR), Constantine Stefanopoulos; Commu-
nist Party-Exterior (KKE-Ext), Harilaos
Florakis; Communist Party-Interior
(KKE-Int), Leonidas Kyrkos
Voting strength: Parliament—Panhellenic
Socialist Movement, 157 seats; New De-
mocracy, 111 seats; Democratic Renewal,
10 seats; Communists (Exterior), 10 seats;
Communists (Interior), 1 seat; indepen-
dents, 11 seats
Communists: an estimated 60,000 mem-
bers and sympathizers
Member of: EC, EIB (associate), EMA,
FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOOC, ITU,
{WC—International Wheat Council,
NATO, OECD, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG, WTO','dc7a2aabddd14d2aa01a551188a82cb3cb3c26d8d8865d34fb13b0c2752e3934','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5524e03a41d17a9491bff3762de43c92a06736078ceb2d88cbdc5edd409b1fb1',1987,'GL','Greenland','government',300,'Official name: Greenland
Type: self-governing province of Kingdom
of Denmark; two representatives in Danish
parliament; separate Minister for Green-
land in the Danish Cabinet (Ministry to be
phased out during 1986-87)
Capital: Godthab (Nuuk)
Administrative divisions: 3 counties, 18
communes
Legal system: Danish law; transformed
from colony to province in 1953; limited
home rule began in spring 1979
Branches: legislative authority rests jointly
with the elected 25-seat Landsting and
Danish parliament; executive power vested
in Premier and four-person council; 19
lower courts
Government leaders: MARGRETHE II,
Queen (since January 1972); Jonathan
MOTZFELDT, Prime Minister (since May
1979)
Suffrage: universal, but not compulsory,
over age 21
Elections: held every four years; most
recent, 6 June 1984
Political parties: Siumut, 1] seats (moder-
ate socialist, advocating more distinct
Greenland identity and greater autonomy
from Denmark); Atassut Party, 11 seats
(more conservative, favors continuing close
relations with Denmark); Inuit Ataqatigiit,
8 seats (Marxist-Leninist party favoring
complete independence from Denmark
rather than home rule)','7f4822b45d9e5455f5ee607d16f16b358739bb17280f3d16196661624cbfc6ed','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aef24693be97c19a8cde3630d84ac424a4880e11395db96b55ee9458a352f030',1987,'GD','Grenada','government',305,'Official name: Grenada
Type: independent state; recognizes Eliza-
beth II as Chief of State
Capital: St. George’s
Administrative divisicns: 6 parishes
Legal system: based on English common
law
National holiday: Independence Day, 7
February
Branches: bicameral legislature
(15-member elected House of Representa-
tives and 18-member appointed Senate);
executive is Cabinet led by the Prime
Minister; judiciary consists of Grenada
Supreme Court, composed of the High
Court of Justice and two-tier Court of
Appeals
Government leaders: Sir Paul SCOON,
Governor General (since 1978); Herbert
BLAIZE, Prime Minister (since December
1984)
Suffrage: universal adult
Elections: last general election held 3
December 1984
Political parties and leaders: New Na-
tional Party (NNP) is ruling party and was
formed in 1984 as a three-party centrist
coalition—Grenada National Party (GNP),
National Democratic Party (NDP), and
Grenada Democratic Movement (GDM);
currently the NDP, led by George Brizan,
and the GDM, led by Francis Alexis, are
not represented in the NNP; former Prime
Minister Sir Eric Gairy revived his Gren-
ada United Labor Party (GULP) in 1984;
Grenada Democratic Labor Party (GDLP)
was formed by Marcel Peters, who was
elected as a GULP candidate but changed
parties after assuming his seat in the
House of Representatives; Democratic
Labor Congress (DLC) was formed in 1986
by disaffected NNP member Kenny
Lalsingh and Winston Whyte of Christian
Democratic Labor Party (CDLP); the
Maurice Bishop Patriotic Movement
(MBPM) was formed in May 1984 and is
composed of pro-Cuban Socialists; the
New Jewel Movement (NJM) consists of
supporters of Bernard Coard and other
hardliners accused of killing Bishop in
1983; GDLP and DLC form the official
opposition; Marcel Peters was recently
replaced as leader of the parliamentary
opposition by Phinsley St. Louis, leader of
the newly formed Organization for Na-
tional Equality (ONE)
Voting strength: (1984 election) NNP 59%,
GULP 36%, MBPM 5%; parliamentary
seats—NNP, 14; GDLP, 1
Communists: the New Jewel Movement
(which is currently trying to revitalize) and
the less hardline Maurice Bishop Patriotic
Movement
Member of: CARICOM, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, ITU, NAM, OAS,
PAHO, SELA, UN, UNESCO, UPU,
WHO','cd27c0ff9e384133201c1c9b243824de21a1525a43f540c684dc695c074e3572','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eaed884cd8abfd9b3289a109b6a16a6214e453b2b0caa477302f92c74ad6c43',1987,'GP','Guadeloupe','government',310,'Official name: Department of Guadeloupe
Type: overseas department and region of
France; represented by three deputies in
the French Nationa! Assembly and two
senators in the Senate; last Assembly
election, 21 June 1981
Capital; Basse-Terre
Administrative divisions: 3 arrondisse-
ments; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest
court is a court of appeal) based in Martin-
ique with jurisdiction over Guadeloupe,
French Guiana, and Martinique
Branches: executive, Prefect appointed by
Paris; legislative, popularly elected General
Council of 36 members and a Regional
Council composed of members of the local
General Council and the locally elected
deputies and senators to the French parlia-
ment; judicial, under jurisdiction of
French judicial system
Government leader: Yves BONNET,
Prefect of the Republic (since 1985)
Suffrage: universal over age 18
Elections: General Council elections are
normally held every five years; last Gen-
eral Council election took place in June
1981; regional assembly elections held in
February 1983
Political parties and leaders: Rally for
the Republic (RPR), Gabriel Lisette; Com-
munist Party of Guadeloupe (PCG), Henri
Bangou; Socialist Party (MSG), leader
unknown; Progressive Party of Guadeloupe
(PPG), Henri Rodes; Independent Republi-
cans; Federation of the Left; Union for
French Democracy (UDF); Union for a
New Majority (UNM); Socialist Party
Federation of Guadeloupe (PS)
98
Voting strength: 3 deputies in French
National Assembly; 2 senators in Senate; 1
councillor on Economic and Social Coun-
cil; in Regional Council election of Febru-
ary 1983—RPR 21 seats, PCG 1] seats, PS
9 seats
Communists: 3,000 est.
Other political or pressure groups: Popu-
lar Union for the Liberation of Guade-
loupe (UPLG), Caribbean Revolutionary
Alliance (ARC), Popular Movement for
Independent Guadeloupe (MPGI), Union
for the Liberation of Guadeloupe (UPLG),
General Union of Guadeloupe Workers
(UGTG), General Federation of Guad-
eloupe Workers (CGT-G)
Member of: WFTU','1e1d347932bc3ee9992cf9eb2e794b5a101dd21a43df1ac35aa4f5b44de5fc5d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9133064c313638b62749f8d8ad642c0169ff3740f4420924743c427f62b3c20d',1987,'GG','Guernsey','government',315,'Official name: Bailiwick of Guernsey
Type: independent British crown depen-
dency
Capital: St. Peter Port
Administrative divisions: 10 douzaines or
parishes
Legal system: English law and local stat-
ute; justice is administered by the Royal
Court
Branches: the Lieutenant Governor and
Commander in Chief is the personal
representative of the Crown and is entitled
to sit and speak in the States of Delibera-
tion (parliament); parliament is composed
of the Bailiff (President ex officio), 12
Conseillers, 2 nonvoting Law Officers of
the Crown, 33 popularly elected People’s
Deputies, 10 Douzaine Representatives, 2
representatives of the States of Alderney;
States of Election (electoral college) elects
Jurats and Conseillers—it is composed of
the Bailiff, 12 Jurats, 12 Conseillers, 2 Law
Officers, 38 People’s Deputies, 34
Douzaine Representatives, and 4 Alderney
representatives (for election of Conseillers
only); Alderney has its own popularly
elected President and States (12 members)
and its own Court; Sark has mixture of
feudal and popular government
Government leaders: Lt. Gen. Sir Alexan-
der BOSWELL, Lieutenant Governor and
Commander in Chief (since 1985); Sir
Charles FROSSARD, Bailiff and President
of the States (since 1982)
Suffrage: universal adult over 18
Communists: none','f0f2478d791928e7a898e5bd602ee897658d411d830a2ff76b3ed58b157614ac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adb2876e9a7368ec5b0e54df43e7376200257ee6a767c64cd455e79e1b9a69c5',1987,'GW','Guinea-Bissau','government',322,'Official name: Republic of Guinea-Bissau
Type: republic; highly centralized one-
party regime since September 1974
Capital: Bissau
Administrative divisions: 9 regions, 3
circumscriptions (predominantly indige-
nous population)
Legal system: new constitution approved
May 1984
National holiday: Independence Day, 24
September
Branches: President and Cabinet; 150-
member National Popular Assembly,
overseen by 15-member Council of State
Government leader: Brig. Gen. Jodo
Bernardo VIEIRA, President, Council of
State (since November 1980)
Suffrage: universal over age 15
Elections: legislative elections held March
1984; legislature elected Vieira to serve a
five-year term as President in May 1984
Political parties and leaders: African
Party for the Independence of Guinea-
Bissau and Cape Verde (PAIGC), led by
President Vieira, only legal party; Guinea-
Bissau decided to retain the binational
party title despite its formal break with
Cape Verde
Communists: a few Communists, some
sympathizers
Member of: AfDB, CEAO, FAO, G-77,
GATT (de facto), IBRD, ICAO, ICO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, ISCON, ITU, NAM,
OAU, OIC, UN, UNESCO, UPU, WFTU,
WHO, WMO
Guinea-Bissau (continued)','f56c3f5a51fd92236b294e8a26a6167d88abffab7ea0277f39ff2cc495b970a3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5068c1d127e2dd5cfcca93a0732e79597da0e68226ce6c5241aa51472d3d041a',1987,'GY','Guyana','government',327,'Official name: Co-operative Republic of
Type: republic within Commonwealth
Capital: Georgetown
Administrative divisions: 10 administra-
tive regions
Legal system: based on English common
law with certain admixtures of Roman-
Dutch law; has not accepted compulsory
IC) jurisdiction
National holiday: Republic Day, 23
February
Branches: Executive President, who ap-
points and heads a cabinet; unicameral
legislature (53-member National Assembly)
elected by proportional representation
every five years
Government leaders: Hugh Desmond
HOYTE, President (since August 1985);
Hamilton GREEN, Prime Minister (since
August 1985)
Suffrage: universal adult over age 18
Elections: last held in December 1985
Political parties and leaders: People’s
National Congress (PNC), Hugh Desmond
Hoyte; People’s Progressive Party (PPP),
Cheddi Jagan; Working People’s Alliance
(WPA), Rupert Roopnarine, Eusi
Kwayana, Moses Bhagwan; United Force
(UF), Feilden Singh; Vanguard for Libera-
tion and Democracy (VLD; also known as
Liberator Party), Ganraj Kumar, Dr. J. K.
Makepeace Richmond; Democratic Labor
Movement (DLM), Dr. Paul Tennassee
Voting strength: (1985 election, unofficial
| returns) 78% PNC (42 seats), 16% PPP (8
seats), 4% UF (2 seats), 2% WPA (1 seat)
Communists: est. 100 hardcore within
PPP; top echelons of PPP and PYO (Pro-
gressive Youth Organization, militant wing
| of the PPP) include many Communists,
but rank and file is conservative and
non-Communist; small but unknown
number of orthodox Marxist-Leninists
within PNC, some of whom formerly
belonged to the PPP
Other political or pressure groups: Trades
Union Congress (TUC); Working People’s
Vanguard Party (WPVP); Guyana Council
of Indian Organizations (GCIO), Civil
Liberties Action Committee (CLAC); the
latter two organizations are small and
active but not well organized
Member of: CARICOM, CDB, FAO,
G-77, GATT, JADB, 1BA, IBRD, ICAO,
(IDA, JDB—Inter-American Development
Bank, IFAD, IFC, ILO, IMF, IMO,
INTERPOL, IRC, 1SO, 1TU, NAM, OAS
(observer), PAHO, SELA, UN, UNESCO,
UPU, WFTU, WHO, WMO','3e49a8743ad5070037f89986ee63366a44412219bd950625abe4ca2f31a92280','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc00ec3e6c8861f4e3f9949a33948a4b4afc73959201481c2615e37802f5c309',1987,'HT','Haiti','government',332,'Official name: Republic of Haiti
Type: republic
Capital: Port-au-Prince
Administrative divisions: 26 provinces, I
federal district
Legal system: based on Roman civil law
system; currently under revision, to be
completed early 1987; accepts compulsory
ICJ jurisdiction
National holiday: Independence Day, 1
January
Branches: interim government following
the end of 29 years of Duvalier family
rule; Consultative Council (45-member
advisory body); Constituent Assembly
(61-member body drafting new constitu-
tion); judiciary appointed by President
before coup
Government leaders: Lt. Gen. Henri
NAMPHY, President, National Council of
Government (CNG), since February 1986,
two other CNG members, and 18-member
cabinet
Suffrage: universal over age 18
Elections: National elections scheduled for
November 1987, inauguration 7 February
1988
Political parties and leaders: Haitian
Christian Democratic Party (PDCN),
Sylvio Claude; Haitian Social Christian
Party (PSCH), Grégoire Eugéne; Move-
ment To Install Democracy in Haiti
(MIDH), Marc Bazin; National Progressive
Democratic Group (RDNP), Leslie
Manigat
Voting strength: new voter registration
lists being compiled
Communists: United Party of Haitian
Communists (PUCH), René Théodore
(roughly 2,000 members)
Other political or pressure groups: United
Democratic Committee (KID); Liaison
Committee of Democratic Forces
Member of; FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, 1CO, IDA,
IDB—lInter-American Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IRC, ITU, OAS, PAHO,
SELA, UN, UNESCO, UPU, WHO,
WMO, WTO
Official name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Administrative divisions: 18 departments
Legal system: rooted in Roman and Span-
ish civil law; some influence of English
common law; new constitution became
effective in January 1982; the nine Su-
preme Court justices are appointed by
Congress; accepts ICJ jurisdiction, with
reservations
National holiday: Independence Day, 15
September
Branches: constitution provides for elected
President, unicameral legislature (134-
member National Congress), and national
judicia! branch
Government leader: José AZCONA Hoyo,
President (since January 1986)
Suffrage: universal and compulsory over
age 18
Elections: national election for president
and legislature held every four years; last
election held November 1985; legislature
chosen by proportional representation; 282
county councils
107
Political parties and leaders: Liberal
Party (PLH)—party president, Romualdo
Bueso Penalba; faction leaders, Carlos
Flores Facusse (Rodista faction), José
Azcona Hoyo (Azconista subfaction), Jorge
Bueso Arias (ALIPO faction), Jorge Arturo
Reina (M-Lider faction); National Party
(PNH)}—party president, Rafael Leonardo
Callejas; faction leaders, Juan Pablo Urru-
tia (MUC faction); Ricardo Zuniga Augus-
tinus (Officialista faction), Mario Rivera
Lépez (Riverista subfaction), and Rafael
Leonardo Callejas (MONARCA faction);
National Innovation and Unity Party
(PINU)}—Miguel Andonie Fernandez;
Christian Democratic Party (PDCH)—
Ruben Palma Carrasco
Voting strength: (1985 election) 1.6 mil-
lion out of 1.8 million eligible voters cast
ballots; PLH 51%, PNH 45%, PINU 1.5%,
PDCH 1.9%, legislative seats—PLH 67,
PNH 68, PINU 2, PDCH 2
Communists: up to 1,500; Honduran
leftist groups—Communist Party of Hon-
duras (PCH), Communist Party of
Honduras/Marxist-Leninist (PCMLH),
Morazanist Front for the Liberation of
Honduras (FMLH), People’s Revolutionary
Union/Popular Liberation Movement
(URP/MPL), Popular Revolutionary
Forces-Lorenzo Zelaya (FPR/LZ), Socialist
Party of Honduras Central American
Workers Revolutionary Party
(PASO/PRTC)
Other political or pressure groups: Na-
tional Association of Honduran Campesi-
nos (ANACH), Honduran Council of
Private Enterprise (COHEP), Confedera-
tion of Honduran Workers (CTH), Na-
tional Union of Campesinos (UNC), Gen-
eral Workers Confederation (CGT), United
Federation of Honduran Workers (FUTH),
Committee for the Defense of Human
Rights in Honduras (CODEH), Coordinat-
ing Committee of Popular Organizations
(CCOP)
Member of: CACM, FAO, G-77, IADB,
IBRD, ICAO, ICO, IDA, IDB—Inter-
American Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
ISO, ITU, OAS, PAHO, SELA, UN,
UNESCO, UPEB, UPU, WFTU, WHO,
WMO
Honduras (continued)','f581786a8dfa70401680b4ac56677b581158f010d9090e1587a237ea5be4ede3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56fd7703601947c37d1e63b2b1f4f5334f6d84246538d9ab5df0c5ec4d14e424',1987,'HK','Hong Kong','government',337,'Official name: Hong Kong
Type: British colony; scheduled to revert
to China in 1997
Capital: Victoria
Administrative divisions: Hong Kong,
Kowloon, and New Territories
Legal system: English common law
Branches: Governor assisted by advisory
Executive Council, legislates with advice
and consent of Legislative Council: Execu-
tive Council composed of governor, four
ex-officio senior officials, and 11 nominated
members; Legislative Council composed of
governor, three ex-officio members, 10
official members, 22 appointed unofficial
members and 24 unofficial members
elected indirectly by functional constituen-
cies and by an electoral college; Urban
Council, consisting of 15 elected members
and 15 appointed by Governor, responsible
for health, recreation, and resettlement in
urban areas; Regional Council (established
1 April 1986), comprising 12 directly
elected members, 9 indirectly elected, 12
appointed, and 8 ex officio, has similar
responsibilities in nonurban areas; indepen-
dent judiciary
Government leaders: David Clive
WILSON, Governor since April 1987; Sir
David AKERS-JONES, Chief Secretary
since December 1985
Suffrage: limited to 450,000 to 550,000
professional or skilled persons
Elections: on three-year cycle for Urban
and Regional Councils; last held March
1986; indirect elections for Legislative
Council held for first time in September
1985 and planned for three-year intervals
Political parties: insignificant
Communists: an estimated 4,000 cadres
affiliated with Communist Party of China
Other political or pressure groups: Feder-
ation of Trade Unions (Communist con-
trolled), Hong Kong and Kowloon Trade
Union Council (Nationalist Chinese domi-
nated), Hong Kong General Chamber of
Commerce, Chinese General Chamber of
Commerce (Communist controlled), Feder-
ation of Hong Kong Industries, Chinese
Manufacturers’ Association of Hong Kong,
Hong Kong Professional Teachers’ Union
Member of: ADB, ESCAP (associate
member), GATT, IMO, INTERPOL,
Multifiber Arrangement, WMO','a3b4227d7b285b18743f5305d7e91dc9dd4f74d7bdf1489160e15b02db3f95b3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59c44ff3cd95fe57ddf9dc0de08c754c274fc3beab41a2b535e5bc4716cff015',1987,'HU','Hungary','government',342,'Official name: Hungarian People’s Repub-
lic
Type: Communist state
Capital; Budapest
Administrative divisions: 19 megyes
(counties), 5 autonomous cities in county
status
Legal system: based on Communist legal
theory, with both civil law system (civil
code of 1960) and common law elements;
constitution adopted 1949 amended 1972;
Supreme Court renders decisions of princi-
ple that sometimes have the effect of
declaring legislative acts unconstitutional;
has not accepted compulsory ICJ jurisdic-
tion
National holiday: Liberation Day, 4 April
Branches: executive—Presidential Council
(elected by parliament); unicameral legisla-
ture—National Assembly (elected by direct
suffrage); judicial—Supreme Court (elected
by parliament)
Government leaders: Pa] LOSONCZI,
President, Presidential Council (since April
1967); Gyérgy LAZAR, Premier, Council
of Ministers (since May 1975)
Suffrage: universal over age 18
Elections: every five years (last election
June 1985); national and local elections are
held separately
Politica] parties and leaders: Hungarian
Socialist (Communist) Workers’ Party
(MSZMP), sole party; Janos Kadar, General
Secretary (since November 1956; his title
was changed from First Secretary to Gen-
eral Secretary in March 1985)
110
Voting strength: (1985 election) 7,700,000
(94%) turnout for multiple-candidate
election, with only some leading figures
running without opposition
Communists: about 870,992 party mem-
bers (January 1985)
Member of: CEMA, Danube Commission,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
ILO, International Lead and Zinc Study
Group, IMF, IMO, IPU, ISO, ITC, ITU,
UN, UNESCO, UPU, Warsaw Pact,
WFTU, WHO, WIPO, WMO','a826c7f312e5c9c05debb3b66591c18f6d9149b73316b250329aae5f7f34ae1e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de419e79ae2ca238be31b0952273a5bd91a01bf1850dfd3c280309ef0c4f8cde',1987,'IS','Iceland','government',347,'Official name: Republic of Iceland
Type: republic
Capital: Reykjavik
Administrative divisions: 23 counties, 200
parishes, 23 incorporated towns
Legal system: civil law system based on
Danish law; constitution adopted 1944;
does not accept compulsory 1CJ jurisdic-
tion
National holiday: Anniversary of the
Establishment of the Republic, 17 June
Branches: legislative authority rests jointly
with President and parliament (Althing);
executive power vested in President but
exercised by Cabinet responsible to parlia-
ment; Supreme Court and 29 lower courts
Government leaders: Vigdis FINNBOGA-
DOTTIR, President (since August 1980);
Steingrimur HERMANNSSON, Prime
Minister (since May 1983)
Suffrage: universal over age 20 but not
compulsory
Elections: parliamentary every four years,
last held 23 April 1983, next elections in
April 1987; presidential held every four
years; last held August 1984
Political parties and leaders: Indepen-
dence (conservative), Thorsteinn Palsson;
Progressive, Steingrimur Hermannsson,
Social Democratic, Jon Baldvin Hannibals-
son; People’s Alliance (left socialist), Svavar
Gestsson
Iceland (continued)
Voting strength: (1983 election) 38.7%
Independence, 18.5% Progressive, 17.3%
People’s Alliance, 11.7% Social Demo-
cratic, 13.8% other
Communists: est. less than 100, some of
whom participate in the People’s Alliance,
which drew 22,489 votes in the 1983
parliamentary elections
Member of: Council of Europe, EC (free
trade agreement pending resolution of
fishing limits issue), EFTA, FAO, GATT,
IAEA, IBRD, ICAO, ICES, 1DA, IFC,
IHO, 1LO, IMF, IMO, INTELSAT,
INTERPOL, 1PU, ITU, [WC—Interna-
tional Whaling Commission, NATO,
Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WMO, WSG','ae700822ee0718872b541612efa6475c1a9258cbdc7daa760b69a7770048d858','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bc5c3ebfbd91679588a05637b62aa7099a47f5686f893f3bcc2c2e51b0ac43',1987,'IQ','Iraq','government',354,'Official name: Republic of Iraq
Type: republic
Capital: Baghdad
Administrative divisions: 18 provinces
under centrally appointed officials
Legal system: based on Islamic law in
special religious courts, civil law system
elsewhere; provisional constitution adopted
in 1968; judicial review was suspended;
tion
National holidays: anniversaries of the
1958 and 1968 revolutions are celebrated
14 July and 17 July; various religious
holidays
has not accepted compulsory 1CJ jurisdic-
Branches: Ba‘th Party of Iraq has been in
power since 1968 coup; unicameral legisla-
ture (National Assembly)
Government leaders: Saddam HUSAYN,
President (since July 1979); Izzat
IBRAHIM, Deputy Chairman of the
Revolutionary Command Council (since
July 1979); Taha Yasin RAMADAN, First
Deputy Prime Minister (since July 1979)
Suffrage: universal adult
Elections: National Assembly elections
held October 1984; Legislative Council for
the Autonomous Region held September
1980
Communists: about 2,000 hardcore mem-
bers
Political or pressure groups: political
parties and activity severely restricted;
possibly some opposition to regime from
disaffected members of the regime, army
officers, and religious and ethnic dissidents
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, ITU,
NAM, OAPEC, OIC, OPEC, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WSG, WTO
Official name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Administrative divisions: 4 governorates
(Kuwait City, Hawalli, Ahmadi, Johra), 25
voting constituencies
Legal system: civil law system with Is-
lamic law significant in personal matters;
constitution took effect in 1963; popularly
elected 50-man National Assembly (the 15
cabinet members can also vote) reinstated
in March 1981] after being suspended in
1976, but in July 1986 parliament dis-
solved by the Amir; judicial review of
legislative acts not yet determined; has not
accepted compulsory ICJ jurisdiction
National holiday: National Day, 25 Feb-
ruary
Branches: Council of Ministers; legisla-
ture—National Assembly
Government leader: Jabir al-Ahmad
al-Jabir Al SABAH, Amir (since December
1977)
Suffrage: adult males who resided in
Kuwait before 1920 and their male de-
scendents (eligible voters, 8.3% of citi-
zenry)
136
Elections: National Assembly elected
February 1985 (suspended July 1986)
Political parties and leaders: political
parties prohibited, some small clandestine
groups are active
Communists: insignificant
Other political or pressure groups: large
(850,000) Palestinian community
Member of: Arab League, FAO, G-77,
GATT, GCC, IAEA, IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, [PU, ITU, NAM, OAPEC,
OIC, OPEC, UN, UNESCO, UPU,
WFTU, WHO, WMO, WTO
Official name: Lao People’s Democratic
Republic
Type: Communist state
Capital; Vientiane
Administrative divisions: 16 provinces
subdivided into districts, cantons, and
villages
Legal system: based on civil law system;
has not accepted compulsory ICJ jurisdic-
tion
National holiday: 2 December
Branches: President; 37-member Supreme
People’s Council; Cabinet; Cabinet is
totally Communist but Council contains a
few nominal neutralists and
non-Communists; National Congress of
People’s Representatives established the
current government structure in December
1975
Government leaders: PHOUMI
VONGVICHIT, Acting President (since
October 1986); KAYSONE PHOMVIHAN,
Chairman (since December 1975)
Suffrage: universal over age 18
Elections: elections for National Assembly,
originally scheduled for I April 1976, have
not yet been held
Political parties and leaders: Lao People’s
Revolutionary Party (Communist), Kaysone
Phomvihan, party chairman; includes Lao
Patriotic Front and Alliance Committee of
Patriotic Neutralist Forces; other parties
moribund
Other political or pressure groups: non-
Communist political groups moribund;
most leaders have fled the country
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFAD,
ILO, IMF, INTERPOL, IPU, IRC, ITU,
Mekong Committee, NAM, UN, UN-
CTAD, UNESCO, UPU, WFTU, WHO,
WMO, WTO
Laos (continued)','a1f25b122c17bd8a7ace2a2533c5300d3d89b75a1528ad12cf4972bd26292a0c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7ab48d3318973622f4f9719a5dc182787196a449b307be29693895099576910',1987,'IE','Ireland','government',359,'Official name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Administrative divisions: 26 counties
Legal system: based on English common
law, substantially modified by indigenous
concepts; constitution adopted 1937; judi-
cial review of legislative acts in Supreme
Court; has not accepted compulsory ICJ
jurisdiction
National holiday: St. Patrick’s Day, 17
March
Branches: elected President; bicameral
parliament (Seanad, Dail) reflecting pro-
portional and vocational representation;
judiciary appointed by President on advice
of government
Government leaders: Dr. Patrick J. HIL-
LERY, President (since 1976); Charles J.
HAUGHEY, Prime Minister (since March
1987)
Suffrage: universal over age 18
Elections: Dail (lower house) elected every
five years (last election February 1987);
President elected for seven-year term (last
election March 1987)
Political parties and leaders: Fianna Fail,
Charles Haughey; Labor Party, Richard
Spring; Fine Gael, Alan Dukes; Commu-
119
nist Party of Ireland, Michael O''Riordan;
Workers’ Party, Tomas MacGiolla; Sinn
Fein, Gerry Adams; Progressive Demo-
crats, Desmond O''Malley; Democratic
Socialist Party, Jim Kemmy
Voting strength: (1987 election) Dail—
Fianna Fail, 81 seats (44.1%); Fine Gael,
51 seats (27.1); Progressive Democrats, 14
seats (11.8%), Labor Party, 12 seats (6.4%);
Workers’ Party, 4 seats (3.8%); indepen-
dents, 3 seats; Democratic Socialist Party,
1 seat; Sinn Fein no seat (1.9%)
Communists: under 500
Member of: Council of Europe, EC, EMS,
ESRO (observer), FAO, GATT, IAEA,
IBRD, ICAO, ICES, IDA, IEA, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ISO, ITC, ITU, IWC—
International Wheat Council, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG
Dependent areas: Anguilla, Bermuda,
Britlsh Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Falkland
Islands, Gibraltar, Guernsey, Hong Kong,
Jersey, Isle of Man, Montserrat, Pitcairn
Islands, St. Helena, Turks and Caicos
Islands
Legal system: common law tradition with
early Roman and modern continental
influences; no judicial review of Acts of
Parliament; accepts compulsory ICJ juris-
diction, with reservations
National holiday: Birthday of the Queen,
16 June
Branches: legislative authority resides in
Parliament (House of Lords, House of
Commons); executive authority lies with
collectively responsible Cabinet led by
Prime Minister; House of Lords is supreme
judicial authority and highest court of
appeal
Government leaders: ELIZABETH II,
Queen (since 1952); Margaret
THATCHER, Prime Minister (since 1979)
Suffrage: universal over age 18
Elections: at discretion of Prime Minister
but must be held before expiration of a
five-year electoral mandate; last election
held 9 June 1983
Political parties and leaders: Conserva-
tive, Margaret Thatcher; Labor, Neil
Kinnock; Social Democratic, David Owen;
Communist, Gordon McLennan; Scottish
National, Donald Stewart; Plaid Cymru,
Dafydd Wigley; Official Unionist, James
Molyneaux; Democratic Unionist, lan
Paisley; Social Democratic and Labor,
John Hume; Provisional Sinn Fein, Gerry
Adams; Alliance, John Cushnahan; Liberal,
David Steel
Voting strength: (1983 election) House of
Commons—Conservative, 392 seats
(42.4%), Labor, 210 seats (27.6%); Social
Democratic-Liberal Alliance, 26 seats (19
Liberal, 7 SDP) (25.4%); Scottish National
Party, 2 seats; Plaid Cymru (Welsh Na-
tionalist), 2 seats; Ulster (Official) Unionist
(Northern Ireland), 10 seats; Ulster Demo-
cratic Unionist (Northern Ireland), 3 seats;
Ulster Popular Unionist (Northern Ireland),
I seat; Social Democratic and Labor
(Northern Ireland), 1 seat; Sinn Fein
(Northern Ireland), 1 seat
Communists: 15,961
Other political or pressure groups: Trades
Union Congress, Confederation of British
Industry, National Farmers’ Union, Cam-
paign for Nuclear Disarmament
254
Member of: ADB, CENTO, Colombo
Plan, Council of Europe, DAC, EC,
ELDO, ESCAP, ESRO, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO,
IDA, IDB—Inter-American Development
Bank, IEA, IFAD, IFC, IHO, ILO, Inter-
national Lead and Zinc Study Group,
IMF, IMO, INTELSAT, INTERPOL,
IOOC, IPU, IRC, ISO, ITC, ITU, IWC—
International Whaling Commission,
1WC—International Wheat Council,
NATO, OECD, UN, UPU, WEU, WHO,
WIPO, WMO, WSG','0b3e57bd9b821288b906065c92ccf5fd8861dca6712ede472ef6c01ba7b430b4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('178917f10c8ed6bb88e4eef51339a4aacf51107985ae8d3dc898e0b51941a09e',1987,'IL','Israel','government',364,'Official name: State of Israel
Type: republic
Capital: Jerusalem; Israel proclaimed
Jerusalem its capital in 1950; the United
States, like nearly all other countries,
maintains its Embassy in Tel Aviv
Administrative divisions: six administra-
tive districts
Legal system: mixture of English common
law, British Mandatory regulations, and, in
personal area, Jewish, Christian, and
Muslim legal systems; commercial matters
regulated substantially by codes adopted
since 1948; no formal constitution; some of
the functions of a constitution are filled by
the Declaration of Establishment (1948),
the basic laws of the Knesset (legislature)—
relating to the Knesset, Israeli lands, the
president, the government—and the Israel
citizenship law; no judicial review of
legislative acts; in December 1985 Israel
informed the UN Secretariat that it would
no longer accept compulsory JCJ jurisdic-
tion
National holidays: Israel declared inde-
pendence on 14 May 1948; because the
Jewish calendar is lunar, however, the
holiday varies from year to year; all major
Jewish religious holidays are also observed
as national holidays
Branches: President has largely ceremo-
nial functions, except for the authority to
decide which political leader should try to
form a ruling coalition following an elec-
tion or the fall of a previous government;
executive power vested in Cabinet; uni-
cameral parliament (Knesset) of 120 mem-
bers elected under a system of propor-
tional representation; legislation provides
fundamental laws in absence of a written
constitution; two distinct court systems
(secular and religious)
Government leaders: Chaim HERZOG,
President (since May 1983); Yitzhak
SHAMIR, Prime Minister (since October
1986), who replaced Shimon PERES under
an agreement whereby the positions of
Prime Minister and that of Vice Prime
Minister and Foreign Minister would be
traded in October 1986
Suffrage: universal over age 18
Elections: held every four years unless
required by dissolution of Knesset; last
election held in July 1984; next election
must be held by November 1988
Political parties and leaders: Israel cur-
rently has a national unity government
comprising eight parties that hold 97 of
the Knesset’s 120 seats; members of the
unity government—Labor Alignment, Vice
Premier and Foreign Minister Shimon
Peres; Likud Bloc, Prime Minister Yitzhak
Shamir; Shinui Party, Minister of Commu-
nications Amnon Rubenstein; National
Religious Party, Minister of Religious
Affairs Zvulun Hammer; SHAS, Yitzhak
Peretz; Agudat Israel, Avraham Shapira;
Morasha-Po’aley Agudat Yisra’el, Avraham
Verdiger; Ometz, Minister Without Portfo-
lio Yigael Hurwitz; opposition parties—
Tehiya-Tzomet, Yuval Ne’eman; MAPAM,
Eliezer Granot; Citizens’ Rights Move-
ment, Shulamit Aloni; RAKAH (Commu-
nist party), Meir Wilner; Progressive List
for Peace, Muhammad Mi ‘ari; TAMI,
Aharon Abuhatzeira; Kakh, Meir Kahane
Voting strength: Labor Alignment, 40
seats; Likud, 41 seats; MAPAM, 6 seats;
Tehiya-Tzomet, 5 seats; Citizens’ Rights
Movement, 4 seats; RAKAH, 4 seats;
SHAS, 4 seats; National Religious Party, 5
seats; Shinui Party, 3 seats; Morasha-
Po’aley Agudat Yisra’el, 1 seat; Agudat
Yisra’vl, 2 seats; Progressive List for Peace,
2 seats; Ometz, 1 seat; Kakh, 1 seat; TAMI,
1 seat
Communists: RAKAH (predominantly
Arab but with Jews in its leadership) has
some 1,500 members
Other political or pressure groups: Black
Panthers, a loosely organized youth group
seeking more benefits for oriental Jews;
Gush Emunim, Jewish nationalists advocat-
ing Jewish settlement on the West Bank
and Gaza Strip; Peace Now, critical of
government’s West Bank/Gaza Strip and
Lebanon policies
Member of: FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IDB—Inter-American
Development Bank, IFAD, IFC, ILO,
IMF, IMO, 1OOC, INTELSAT,
INTERPOL, IPU, 1TU, IWC—Interna-
tional Wheat Council, OAS (observer), UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO
121','94251c7fce2151cc8c73dd09102e73e0e004a97eb64951d754568e13fc4c0799','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa994bb23f1538dfc2e134bcf3c22ea3d9b7e12b85b7fb51f900e2354a34d82',1987,'IT','Italy','government',369,'Official name: Italian Republic
Type: republic
Capital: Rome
Administrative divisions: 20 regions; 95
provinces; 8,081 communes
Legal system: based on civil law system,
with ecclesiastical law influence; constitu-
tion came into effect 1 January 1948;
judicial review under certain conditions in
Constitutional Court; has not accepted
compulsory ICJ jurisdiction
National holiday: Anniversary of the
Republic, 2 June
Branches: executive (President empowered
to dissolve Parliament and call national
election; Commander of the Armed
Forces, presides over the Supreme Defense
Council); otherwise, authority to govern
invested in Council of Ministers; bicameral
legislature (popularly elected Parliament—
315-member Senate, 630-member Cham-
ber of Deputies); independent judicial
establishment
Government leaders: Francesco COS-
SIGA, President (since July 1985); Bettino
CRAXI, Premier (since August 1983)
Suffrage: universal over age 18 (except in
senatorial elections, where minimum age is
25)
Elections: national election for Parliament
every five years (last held June 1983);
provincial and municipal elections every
five years with some out of phase; regional
elections every five years (Jast held May
1985)
Political parties and leaders: Christian
Democratic Party (DC), Ciriaco DeMita
(political secretary); Communist Party
(PCI), Alessandro Natta (secretary general);
Socialist Party (PSI), Bettino Craxi (party
secretary); Social Democratic Party (PSD1),
Franco Nicolazzi (party secretary), Liberal
Party (PLI), Renato Altissimo (secretary
general); Italian Social Movement (MSI),
Giorgio Almirante (national secretary);
Republican Party (PRI), Giovanni Spado-
lini (political secretary)
Voting strength: (1983 election) 32.5%
DC, 30.5% PCI, 11.3% PSI, 6.6% MSI,
5.2% PRI, 4.0% PSDI, 3.0% PLI
Communists: ],673,751 members (1983)
Other political or pressure groups: the
Vatican; three major trade union confeder-
ations (CGIL—Communist dominated,
CISL—Christian Democratic, and UIL—
Social Democratic, Socialist, and Republi-
can); Italian manufacturers association
(Confindustria); organized farm groups
(Confcoltivatori)
Member of: ADB, ASSIMER, CCC, Coun-
cil of Europe, DAC, EC, ECOWAS, EIB,
ELDO, EMS, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICO, IDA, IDB—
Inter-American Development Bank, IFAD,
IEA, IFC, 1HO, ILO, International Lead
and Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU,
IRC, ITC, ITU, NATO, OAS (observer),
OECD, UN, UNESCO, UPU, WEU,
WHO, WIPO, WMO, WSG
Official name: Céte d''Ivoire
Type: republic; one-party presidential
regime established 1960
Capital: Abidjan (capital city changed to
Yamoussoukro in March 1983 but not
recognized by US)
Administrative divisions: 34 prefectures
subdivided into 161 subprefectures
Legal system: based on French civil law
system and customary law; constitution
adopted 1960; judicial review in the Con-
stitutional Chamber of the Supreme Court;
has not accepted compulsory IC) jurisdic-
tion
National holiday: 7 December
Branches: President has sweeping powers,
unicameral legislature (175-member Na-
tional Assembly), separate judiciary
Government leader: Félix HOUPHOUET-
BOIGNY, President (since 1960)
Suffrage: universal over age 21
Elections: legislative and municipal elec-
tions were held in October 1985;
Houphouét-Boigny reelected in October
1985 to his fifth consecutive five-year
term; next round of national elections
scheduled for October 1990
Political parties and leaders: Democratic
Party of the Ivory Coast (PDCI), only
party; Houphouét-Boigny firmly controls
party
124
Communists: no Communist party; possi-
bly some sympathizers
Member of: AfDB, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), Entente, FAO,
G-77, GATT, IAEA, IBRD, ICAO, ICO,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU, Niger
River Commission, NAM, OAU, OCAM,
UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO
Official name: Socialist Federal Republic
of Yugoslavia
Type: Communist state, federal republic in
form
Capital: Belgrade
Administrative divisions: six republics
Legal system: mixture of civil law system
and Communist legal theory; constitution
adopted 1974; has not accepted compul-
sory ICJ jurisdiction
National holiday: 29 November (Day of
the Republic)
Branches: bicameral legislature (Federal
Assembly—Federal Chamber, Chamber of
Republics and Provinces); executive in-
cludes cabinet (Federal Executive Council)
and the federal administration; judiciary;
the State Presidency is a collective, rotat-
ing policymaking body composed of a
representative from each republic and
province, Sinan Hasni presides as President
of the Republic until] May 1987, when he
will be replaced by the representative
from Macedonia, Lazar Mojsov
269
Government leader: Branko MIKULIC,
President of the Federal Executive Coun-
cil (since 1986); nonrenewable four-year
term expires May 1990
Suffrage: universal over age 18
Elections: Federal Assembly elected every
four years by a complicated, indirect
system of voting
Political parties and leaders: League of
Communists of Yugoslavia (LCY) only;
leaders are 23 members of party Presid-
ium selected proportionally from repub-
lics, provinces, and Yugoslav People’s
Army, with the president rotating on an
annual basis and the secretary rotating
every two years; president until June 1987
is Milanko Renovica from Bosnia-
Hercegovina
Communists: 2,167,860 party members
(December 1985)
Other political or pressure groups: Social-
ist Alliance of Working People of Yugosla-
via (SAWPY), the major mass front organi-
zation; Confederation of Trade Unions of
Yugoslavia (CTUY), League of Socialist
Youth of Yugoslavia, Federation of
Veterans’ Associations of Yugoslavia
(SUBNOR)
Member of: ASSIMER, CEMA (observer
but participates in certain commissions),
FAO, G-77, GATT, 1AEA, IBA, IBRD,
1CAC, ICAO, IDA, IDB—Inter-American
Development Bank, IFAD, IFC, JHO,
ILO, IMF, IMO, INTELSAT, International
Lead and Zinc Study Group, INTERPOL,
IPU, ITC, ITU, NAM, OECD (participant
in some activities), UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO
Official name: Republic of Zaire
Type: republic; constitution establishes
strong presidential system
Capital: Kinshasa
Administrative divisions: eight regions
and federal district of Kinshasa
Legal system: based on Belgian civil law
system and tribal law; new constitution
promulgated February 1978; has not
accepted compulsory ICJ jurisdiction
National holidays: Independence Day, 30
June; Anniversary of the Regime, 24
November
Branches: President elected originally in
1970 for seven-year term; Marshal Mobutu
reelected July 1984; limits on reelection
removed by new constitution; unicameral
legislature (310-member National Legisla-
tive Council elected for five-year term);
the official party is the supreme political
institution
Government leader: Marshal MOBUTU
Sese Seko, President (since 1965)
Suffrage: universal and compulsory over
age 18
Elections: elections for rural collectivities’
urban zone councils, and the Legislative
Council of the Popular Movement of the
Revolution were held June-September
1982; presidential referendum /election
held July 1984; presidential election/refer-
endum scheduled for 1991
Political parties and leaders: Popular
Movement of the Revolution (MPR), only
legal party
Voting strength: Mobutu polled 99.6% of
vote in the 1984 election
Communists: no Communist party
Member of: AfDB, APC, CIPEC, EAMA,
EIB (associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, ICO, LDA, IFAD, 1FC,
IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ITC, ITU, NAM, OAU,
OCAM, UDEAC, UN, UNESCO, UPU,
WHO, WIPO, WMO, WTO','a70e8915cbe6e37c556d4852affc95fd02b3effde7511301fc064cbe8e5a2356','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d7b99a5b6acbff580d51d76c14e320be64f89fc0646138597d6b0a6c89e1e9',1987,'JM','Jamaica','government',374,'Official name: Jamaica
Type: independent state within Common-
wealth, recognizing Elizabeth II as head of
state
Capital: Kingston
Administrative divisions: 14 parishes and
the Kingston-St. Andrew corporate area
Legal system: based on English common
law; has not accepted compulsory [CJ
jurisdiction
National holiday: Independence Day, first
Monday in August
Branches: Cabinet headed by Prime
Minister; bicameral legislature—
21-member Senate (13 nominated by the
Prime Minister, eight by opposition leader,
if any; currently no official opposition
because of People’s National Party boycott
of December 1983 election; eight non-
Jamaica Labor Party members appointed
to current Senate by Prime Minister
Seaga), 60-member elected House of
Representatives; judiciary follows British
tradition under a Chief Justice
Government leaders: Edward Philip
George SEAGA, Prime Minister (since
November 1980); Sir Florizel A. GLAS-
SPOLE, Governor General (since 1973)
Suffrage: universal adult at age 18
Elections: at discretion of Governor Gen-
eral upon advice of Prime Minister but
within five years; last held 15 December
1983
Jamaica (continued)
Political parties and leaders: Jamaica
Labor Party (JLP), Edward Seaga; People’s
National Party (PNP), Michael Manley;
Workers’ Party of Jamaica (WPJ), Trevor
Munroe
Voting strength: in the 1983 general
elections 54 seats were uncontested; in six
contested seats the JLP won overwhelm-
ingly against several small fringe parties;
the PNP and WP] boycotted the election;
in 1980 general elections about 58.8% JLP
(51 seats in House), 41.2% PNP (9 seats)
Communists: Workers’ Party of Jamaica
(Marxist-Leninist)
Other political or pressure groups: New
World Group (Caribbean regionalists,
nationalists, and leftist intellectual frater-
nity); Rastafarians (black religious/racial
cultists, pan-Africanists); New Creation
International Peacemakers Tabernacle
(leftist group); Workers Liberation League
(a Marxist coalition of students/labor)
Member of: CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, ICO, 1DB—Inter-American
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTERPOL, ISO, ITU, NAM,
OAS, PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WTO','58ee9d911e5e5b0f53f484269e32128289e55215223f1f46fac1f76df8f63706','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c91671bd608f93f50fefb3bbf610d3f7f8fe9013e0561834f7cbb6d7795082',1987,'JE','Jersey','government',379,'Official name: Bailiwick of Jersey
Type: British crown dependency
Capital; Saint Helier
Administrative divisions: 12 parishes
Legal system: English law and local stat-
ute; justice is administered by the Royal
Court
National holiday: Birthday of the Queen,
16 June
Branches: the Lieutenant Governor and
Commander in Chief is the personal
representative of the Crown and is entitled
to sit and speak in the Assembly of the
States (legislature) but not vote; the Assem-
bly is presided over by the Bailiff who has
a right of dissent and a casting vote; it
consists of 12 senators (elected for six
years), 12 constables (triennial), and 29
deputies (triennial); the Crown is ulti-
mately responsible for the island’s good
Government leaders: Adm. Sir William
PILLAR, Lieutenant Governor and Com-
mander in Chief (since 1985); Peter
CRILL, Bailiff, President of the Assembly
of the States and the Royal Court (since
1975)
Suffrage: universal adult
Communists: probably none
Official name: Kingdom of Swaziland
Type: monarchy; independent member of
Commonwealth since September 1968
Capital: Mbabane (administrative);
Lobamba (legislative capital)
Administrative divisions: 4 administrative
districts
Legal system: based on South African
Roman-Dutch law in statutory courts,
Swazi traditional law and custom in tradi-
tional courts; has not accepted compulsory
IC) jurisdiction
National holiday: Somhlolo (Indepen-
dence) Day, 6 September
Branches: constitution was repealed and
Parliament dissolved by King Sobhuza II
(deceased August 1982) in April 1973; new
bicameral Parliament (Senate, House of
Assembly) formally opened in January
1979; 80-member electoral college chose
40 members of lower house and 10 mem-
bers of upper house; additional 10 mem-
bers for each house chosen by King; execu-
tive authority vested in the King or Queen
(with the advice of the Supreme Council
of State), whose assent is required before
parliamentary acts become law; King’s
authority exercised through Prime Minister
and Cabinet who must be members of
Parliament; judiciary is part of Ministry of
Justice but otherwise independent of
executive and legislative branches; cases
from subordinate courts can be appealed
to the High Court and the Court of Ap-
peal
Government leaders: MSWATI II, King
(since April 1986); Ntombi THWALA,
Queen (and co-Monarch), Sotsha Ernest
DLAMINI, Prime Minister (since October
1986)
Suffrage: universal for adults
Communists: no Communist party
Member of: AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IDA, IFAD, IFC,
ILO, IMF, INTERPOL, ISO, ITU, NAM,
OAU, Southern African Customs Union,
SADCC, UN, UNESCO, UPU, WHO','1a53e8c75f8c275af03d701e32e9cf8431d43aca7770fed0e67056fa0e78c2e2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff2d5c0c8f2093fbdb5b0c0531dde284e3ac6e90ebe79fb953161f57afb5a162',1987,'JO','Jordan','government',384,'Official name: Hashemite Kingdom of
Type: constitutional monarchy
Capital: Amman
Administrative divisions: eight governor-
ates under centrally appointed officials
Legal system: based on Islamic law and
French codes; constitution adopted 1952;
judicial review of legislative acts in a
specially provided High Tribunal; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 25
May
Branches: King holds balance of power;
Prime Minister exercises executive author-
ity in name of King; Cabinet appointed by
Jordan (continued)
King and responsible to parliament; bi-
cameral parliament with House of Repre-
sentatives, dissolved by King in February
1976, and reconvened in January 1984,
following national elections; Senate last
appointed by King in January 1984; secu-
lar court system based on differing legal
systems of the former Transjordan and
Palestine; law Western in concept and
structure; Sharia (religious) courts for
Muslims, and religious community council
courts for non-Muslim communities; desert
police carry out quasi-judicial functions in
desert areas
Government leaders: HUSSEIN I, King
(since August 1952); Zayd al-RIFA‘I, Prime
Minister (since April 1985)
Suffrage: universal adult at age 20
Political parties and leaders: political
party activity illegal since 1957
Communists: party actively repressed,
membership estimated at less than 500
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, IPU,
ITU, NAM, OIC, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO, WTO','74c16e41e9b4f72e086c41e8fddd2b67a2b8f8eeb4fd82d26aaf807f4c378cd3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5832821d56679ae704a1a7aab4f7dd20a9496958c3cb7caef4a9e84deb6e520',1987,'KE','Kenya','government',389,'Official name: Republic of Kenya
Type: republic within Commonwealth
Capital: Nairobi
Administrative divisions: seven provinces
plus Nairobi area
Legal system: based on English common
law, tribal law, and Islamic law; constitu-
tion enacted 1963; judicial review in High
Court; accepts compulsory IC) jurisdiction,
with reservations; constitutional amend-
ment in 1982 made Kenya a de jure one-
party state
National holiday: Jamhuri Day, 12 De-
cember
Branches: President and Cabinet responsi-
ble to unicameral legislature (National
Assembly) of 200 seats, 188 directly
elected by constituencies and 12 appointed
by the President; High Court, with Chief
Justice and at least 11 justices, has unlim-
ited original jurisdiction to hear and deter-
mine any civil or criminal proceeding;
provision for system of courts of appeal
Government leader: Daniel T. arap MOI,
President (since 1978)
Suffrage: universal over age 21
Elections: Assembly at least every five
years; present National Assembly and
President elected September 1983
Political party and leader: Kenya African
National Union (KANU), Kenya’s sole legal
political party, Daniel T. arap Moi, Presi-
dent
Voting strength: KANU holds all seats in
the National Assembly
Communists: may be a few Communists
and sympathizers
Other political or pressure groups: labor
unions
Member of: AfDB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAO, ICO,
IDA, IFAD, IFC, 1LO, IMF, IMO,
INTELSAT, INTERPOL, IRC, !SO, ITU,
1WC—International Wheat Council,
NAM, OAU, UN, UNDP, UNESCO, UPU,
WHO, WIPO, WMO, WTO
Official name: Federation of St. Chris-
topher and Nevis
Type: independent state within Common-
wealth, recognizing Elizabeth 11 as Chief
of State
Capital: Basseterre, St. Christopher;
Charlestown, Nevis
Administrative divisions: 14 parishs
Legal system: based on English common
law; constitution of 1960; highest judicial
organ is Court of Appeal of Leeward and
Windward Islands
Branches: legislative, 11-member popu-
larly elected House of Assembly; execu-
tive, Cabinet headed by Prime Minister;
separate Nevis Island Legislature and
Nevis Island Assembly headed by Premier
Government leaders: Dr. Kennedy
Alphonse SIMMONDS, Prime Minister
(since 1980); Sir Clement ARRINDELL,
Governor General (since 1981)
Suffrage: universal adult suffrage
Elections: at least every five years; last
election held June 1984
Political parties and leaders: St. Chris-
topher and Nevis Labor Party (SKNLP),
Lee Moore; People’s Action Movement
(PAM), Kennedy Simmonds; Nevis Refor-
mation Party (NRP), Simeon Daniel
Voting strength: (June 1984 election)
House of Assembly—PAM, 6 seats;
SKNLP, 2 seats; NRP, 3 seats
Communists: none known
Member of: CARICOM, Commonwealth,
FAO, IBRD, IMF, ISO, OAS, UN
Official name: St. Helena
Type: British dependent territory
Capital: Jamestown
Administrative divisions: Ascension and
Triston da Cunha are dependencies of St.
Helena
Legal system: Constitution in effect since
1967; Supreme Court
Branches: Executive Council, 12-member
elected Legislative Council
Government leader: Francis BAKER,
Governor and Commander in Chief (since
1984)
Elections: general elections held in Octo-
ber 1984
Political parties and leaders: St. Helena
Labor Party, G. A. O. Thornton; St. Hel-
ena Progressive Party, leader unknown
Voting strength: both political parties
inactive since 1976
Communists: probably none
Official name: St. Lucia
Type: independent state within Common-
wealth, recognizing Elizabeth II as Chief
of State
Capital: Castries
Administrative divisions: 11 quarters
Legal system: based on English common
law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and
Windward Islands
Branches: bicameral legislative (Senate,
House of Assembly); executive, Cabinet
headed by Prime Minister
Government leaders: John G. M. COMP-
TON, Prime Minister (since February
1975); Sir Allen LEWIS, Governor General
(since December 1982)
Suffrage: universal adult over age 18
Elections: every five years; last election
held May 1982
Political parties and leaders: United
Workers’ Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Julian Hunte;
Progressive Labor Party (PLP), George
Odlum
Voting strength: (1982 election) House of
Assembly—UWP, 14 seats; SLP, 2 seats;
PLP, 1 seat
Communists: negligible
Member of; CARICOM, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, NAM, OAS,
PAHO, UN, UNESCO, UPU, WFTU,
WHO, WMO
Official name: St. Vincent and the Grena-
dines
Type: independent state within Common-
wealth, recognizing Elizabeth Il as Chief
of State
Capital: Kingstown
Legal system: based on English common
law; constitution of 1960; highest judicial
body is Court of Appeal of Leeward and
Windward Islands
Branches: bicameral legislature
(13-member elected House of Representa-
tives and 6-member appointed Senate),
judiciary (Supreme Court)
Government leaders: James (Son) MITCH-
ELL, Prime Minister (since 1984); Sir
Joseph EUSTACE, Governor General
(since February 1985)
Suffrage: universal adult at age 18
Elections: every five years; last held 18
July 1984
Political parties and leaders: New Demo-
cratic Party (NDP), James (Son) Mitchell;
St. Vincent Labor Party (SVLP), Vincent
Beach and Hudson Tannis; United
People’s Movement (UPM), Oscar Allen;
Movement for National Unity (MNU),
Ralph Gonsalves
Voting strength: (1984 election) House of
Assembly—NDP, 9 seats; SVLP, 4 seats
Member of: CARICOM, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA,
IFAD, IMF, IMO, OAS, UN, UNESCO,
UPU, WFTU, WHO','a8aa208199acb939bccfb23e07dab4b0eb95c5d37c9a7de64a9147639a7dbec9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ba4798dffda25cc498f96a3627a9c37de0dde73775bfa8806b341c439f806e',1987,'KI','Kiribati','government',394,'Official name: Republic of Kiribati
Type: republic
Capital; Tarawa
Administrative divisions: 20 constituen-
cies
Branches: unicameral legislature—Na-
tional Assembly (comprised of 36 elected
members and one nominated representa-
tive of the Banaban community); nation-
ally elected President
Government leader: leremia T. TABAI,
President (since July 1979)
Elections: every four years
Political parties and leaders: Gilbertese
National Party, Christian Democratic
Party
Member of: ADB, Commonwealth,
ESCAP (associate member), GATT (de
facto), ICAO, IMF, SPF, WHO
Official name: Democratic People’s Re-
public of Korea
Type: Communist state; one-man rule
Capital; P’yongyang
Administrative divisions: nine provinces,
four special cities (P’yongyang, Kaesong,
Namp’o, and Ch’ongjin)
Legal system: based on German civil law
system with Japanese influences and Com-
munist legal theory; constitution adopted
1948 and revised 1972; no judicial review
of legislative acts; has not accepted com-
pulsory ICJ jurisdiction
National holiday: 9 September
Branches: Supreme People’s Assembly
theoretically supervises legislative and
judicial] functions; State Administration
Council (cabinet) oversees ministerial
operations
Government leaders: KIM Il-song, Presi-
dent (since December 1972); Yl Kun-mo,
Premier (since December 1986)
Suffrage: universal at age 17
Elections: election to Supreme People’s
Assembly every four years, but this consti-
tutional provision not necessarily fol-
lowed—last election November 1986
Political party and leaders: Korean
Workers’ Party (K WP); Kim ll-song, Gen-
eral Secretary, and his son, Kim Chong-il,
Secretary, Central Committee
133
Communists: KWP claims membership of
about 2 million, or about 11% of popula-
tion
Member of: FAO, G-77, [AEA, ICAO,
IPU, ITU, NAM, UNCTAD, UNESCO,
UPU, WFTU, WHO, WIPO, WMO;
official observer status at UN
Official name: Republic of Korea
Type: republic; power centralized in a
strong executive
Capital: Seoul
Administrative divisions: nine provinces,
four special cities; governors/mayors
centrally appointed
Legal system: combines elements of
continental European civil law systems,
Anglo-American law, and Chinese classical
thought; constitution approved 1980; has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 15
August
Branches: unicameral legislature (National
Assembly), judiciary
Government leaders: CHUN Doo Hwan,
President (since August 1980); LHO Shin
Yong, Prime Minister (since February
1985)
Suffrage: universal over age 20
Elections: under new constitution of
October 1980, President elected every
seven years indirectly by a 5,000-man
electoral college; last election February
1981; four-year National Assembly, elected
in February 1985, consists of 276 represen-
tatives, 184 directly elected and 92 ap-
pointed on proportional basis by major
parties
Political parties and leaders: major party
is government’s Democratic Justice Party
(DJP), Chun Doo Hwan, president, and
Roh Tae Woo, chairman; opposition par-
ties are New Korea Democratic Party
(NKDP), Lee Min-woo; Korean National
Party (KNP), Lee Man-sup; several smaller
parties
Communists: Communist activity banned
by government
Other political or pressure groups: Coun-
cil for the Promotion of Democracy;
Korean National Council] of Churches;
large, potentially volatile student popula-
tion concentrated in Seoul; Federation of
Korean Trade Unions; Korean Veterans’
Association; Federation of Korean Indus-
tries; Korean Traders Association
Member of: ABD, AfDB, Asian-African
Legal Consultative Committee, Asian
Parliamentary Union, APACL—Asian
People’s Anti-Communist League, ASPAC,
Colombo Plan, ESCAP, FAO, G-77,
GATT, Geneva Conventions of 1949 for
the protection of war victims, IAEA,
IBRD, ICAC, ICAO, IDA, IFAD, IFC,
IHO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ITU, IWC—
International Whaling Commission,
1WC—International Wheat Council,
UNCTAD, UNDP, UNESCO, UNICEF,
UNIDO, UN Special Fund, UPU,
WACL—World Anti-Communist League,
WHO, WIPO, WMO, WTO; official
observer status at UN','ccd1f072d4cde447be5999cdb806cd4e428c1bc882586cdffdee1cc3771c0b2f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489b4c3a771cc1a802da04b5d44df34cdde78e90c2e51dd4be07fe66be9eb226',1987,'LB','Lebanon','government',400,'Note: Between early 1975 and late 1976
Lebanon was torn by civil war between its
Christians—then aided by Syrian troops—
and its Muslims and their Palestinian
allies. The cease-fire established in October
1976 between the domestic political groups
generally held for about six years, despite
occasional fighting. Syrian troops consti-
tuted as the Arab Deterrent Force by the
Arab League have remained in Lebanon.
Syria’s move toward supporting the Leba-
nese Muslims and the Palestinians and
Israel’s growing support for Lebanese
Christians brought the two sides into rough
equilibrium, but no progress was made
toward national reconciliation or political
reforms—the original cause of the war.
Continuing Israeli concern about the
Palestinian presence in Lebanon led to the
Israeli invasion of Lebanon in June 1982.
Israeli forces occupied all of the southern
portion of the country and mounted a
summer-long seige of Beirut, which re-
sulted in the evacuation of the PLO from
Beirut in September under the supervision
of a multinational force made up of US,
French, and Italian troops.
Within days of the departure of the multi-
national force (MNF), Lebanon’s newly
elected president, Bashir Gemayel, was
assassinated. In the wake of his death,
Christian militiamen massacred hundreds
of Palestinian refugees in two Beirut
camps. This prompted the return of the
MNF to ease the security burden on
Lebanon’s weak army and security forces.
In late March 1984 the last MNF units
withdrew.
Lebanon continues to be partially occu-
pied by Syrian troops. Israel withdrew the
bulk of its forces from the south in 1985,
retaining a 10-km deep security zone just
north of the 1949 Armistice Line. Israel
continues to arm and train the Army of
South Lebanon (ASL), which opposes the
return of Palestinian fighters to South
Lebanon. The ASL has increasingly been
involved in confronting Shi''a as well as
leftist militias sponsored by Syria.
Sporadic fighting between Shi''a and Pales-
tinian forces based in the refugee camps of
Beirut, Sidon, and Tyre escalated during
October 1986 to January 1987, finally
breaking into major combat in February.
At its height, fighting in West Beirut pitted
the Shi‘a against the Druze (their nominal
allies) and the Sunnis and Palestinians. At
the request of Prime Minister Rashid
Karami and other Muslim members of the
government, Syria dispatched troops to
West Beirut to restore order.
Syria also maintains troops in the Riyaq
area of the Bekaa Valley, while Special
Forces units are stationed in the Matn, and
in the Tripoli areas, north and northeast.
In late 1985 the Syrian regime successfully
negotiated a tripartite agreement among
the three major rival Christian, Druze, and
Shi‘a militias, but implementation remains
a distant possibility. The Christian and
Muslim communities are deeply split from
within over specific points in the agree-
ment.
Israel and Lebanon signed a withdrawal
agreement on 17 May 1983. The agree-
ment was never implemented and was
subsequently voided. A partial Israeli
withdrawal and government attempts to
extend authority have led to renewed
factional fighting. The following descrip-
139
tion is based on the present constitutional
and customary practices of the Lebanese
system.
Official name: Republic of Lebanon
Type: republic
Capital: Beirut
Administrative divisions: 4 provinces
Legal system: mixture of Ottoman law,
canon law, and civil law; constitution
mandated in 1926; no judicial review of
legislative acts; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 22
November
Branches: power lies with the President,
who is elected by unicameral legislature
(National Assembly); Cabinet appointed by
President, approved by legislature; inde-
pendent secular courts on French pattern;
religious courts for matters of marriage,
divorce, inheritance, etc.; by custom, the
President is a Maronite Christian, the
Prime Minister is a Sunni Muslim, and the
president of the legislature is a Shi‘a Mus-
lim; each of nine religious communities
are represented in the legislature in pro-
portion to their national numerical
strength
Government leaders: Amine Pierre
GEMAYEL, President (since September
1982); Rashid KARAMI, Prime Minister
(since May 1984)
Suffrage: compulsory for all males over
21; authorized for women over 21 with
elementary education
Elections: National Assembly held every
four years or within three months of
dissolution of Chamber; security conditions
have prevented parliamentary elections
since April 1972
Political parties and leaders: political
party activity is organized along largely
sectarian lines; numerous political group-
ings exist, consisting of individual political
figures and followers motivated by reli-
gious, clan, and economic considerations,
most parties have well-armed militias,
which are still involved in occasional
clashes
Lebanon (continued)
Communists: the Lebanese Communist
Party was legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, 1PU,
ITU, I[WC—International Wheat Council,
NAM, OIC, UN, UNESCO, UPU, WFTU,
WHO, WMO, WSG, WTO','08b18891430cf194fb3443af168687d697deb87857667a3a8995b68719f4b9ad','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eb99f3080a9b98b6862cde4b16054ac7a279d8688db77fccaf6ae1612c13d11',1987,'ZA','South Africa','government',404,'Official name: Kingdom of Lesotho
Type: constitutional monarchy under King
Moshoeshoe II; independent member of
Commonwealth
Capital: Maseru
Administrative divisions: 10 administra-
tive districts
Legal system: based on English common
law and Roman-Dutch law; constitution
came into effect 1966; judicial review of
legislative acts in High Court and Court of
Appeal; has not accepted compulsory ICJ
jurisdiction
National holiday: 4 October
Branches: executive and legislative author-
ity nominally vested in King; real power
rests with six-man Military Council, estab-
lished after military coup January 1986;
20-member Council of Ministers responsi-
ble for administrative duties; judicial—63
Lesotho courts administer customary law
for Africans, High Court and subordinate
courts have criminal jurisdiction over all
residents, Court of Appeal at Maseru has
appellate jurisdiction
Government leaders: MOSHOESHOE I],
King (since 1966); Maj. Gen. Justinus
Metsing LEKHANYA, chairman of Mili-
tary Council and Minister of Defense and
Internal Security (since January 1986);
other members of council—Col. E. T.
RAMAEMA, Col. A. K. MOSOEUNYANE,
Col. M. K. TSOTETSI, Lt. Thabe LETSIE,
Lt. Col. Joshua Sekhobe LETSIE (since
January 1986)
Suffrage: universal for adults
Elections: elections scheduled for Septem-
ber 1985 were boycotted by all opposition
parties because of procedural irregularities;
ruling BNP won all 60 parliamentary seats
by default
Political parties and leaders: Basotho
National Party (BNP), Leabua Jonathan;
Basutoland Congress Party (BCP), Ntsn
Mokhehle; Basotho Democratic Alliance
(CDA), C. D. Molapo; National Indepen-
dent Party (NIP), A. C. Manyeli; Maremat-
lou Freedom Party (MFP), B. Khaketla
Voting strength: National Assembly inop-
erative as of 20 January 1986
Communists: no information
Member of: AfDB, Commonwealth, FAO,
G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, INTERPOL,
1TU, NAM, OAU, Southern African Cus-
toms Union, SADCC, UN, UNESCO,
UPU, WHO, WMO','77a03240fba574467aa74e25b95bf1d0f2c1b8b278bc4f976ef57a5d93640c83','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b2d9fc83192444472d0e173b615fea97450fa42e16733731e9bae8b6a5abfd3',1987,'LR','Liberia','government',410,'Official name: Republic of Liberia
Type: republic
Capital: Monrovia
Administrative divisions: 13 counties
Legal system: new constitution approved
by nationwide referendum in July 1984
and implemented in January 1986; judicial
powers invested in People’s Supreme
Court and lower courts
National holiday: National Redemption
Day, 12 April; Independence Day, 26 July
Branches: executive powers held by Presi-
dent, assisted by appointed Cabinet; legis-
lative powers held by bicameral legisla-
ture; independent judiciary
Government leader: Gen. Samuel Kanyon
DOE, President and Commander in Chief
of the Armed Forces (since April 1980)
Suffrage: universal at age 18
Elections: presidential and legislative
elections held October 1985; Doe was
proclaimed winner of presidential election
and took office in January 1986
Political parties and leaders: National
Democratic Party of Liberia, Miatta Sher-
man, Chairman; Liberian Action Party,
142
Jackson Doe, Chairman; Liberian Unity
Party, Gabriel Kpolleh, Chairman; Unity
Party, Edward Kesselly, Chairman; United
Peoples Party, Gabriel Baccus Matthews,
Chairman
Communists: no Communist Party and
only a few sympathizers
Member of: AfDB, ECA, ECOWAS, FAO,
G-77, IAEA, IBRD, ICAO, ICO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
IPU, IRC, ITU, Mano River Union, NAM,
OAU, UN, UNESCO, UPU, WHO, WMO','58da50d39371d9d04ad0785da22364112c520bfbb0cb63c0723219a25ce56ff7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9f1be120f58867e4ed5db877fba5330271f9808c4558ef0445ca23bfb4cd731',1987,'LY','Libya','government',415,'Official name: Socialist People’s Libyan
Arab Jamahiriya
Type: republic
Capital: Tripoli
Administrative divisions: 46 municipali-
ties closely controlled by central govern-
ment
Legal system: based on Italian civil law
system and Islamic law; separate religious
courts; no constitutional provision for
judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
National holiday: Revolution Day, 1
September
Branches: officially, paramount political
power and authority rests with the General
People’s Congress, which theoretically
functions as a parliament with a cabinet
called the General People’s Committee
Government leaders: Col. Mu‘ammar Abu
Minyar al-QADHAFI (no official title; runs
country and is treated as chief of state);
Miftah al-Ista ‘UMAR, Secretary of the
General People’s Congress (chief of state in
theory but not treated as such)
Suffrage: mandatory universal adult
Elections: representatives to the General
People’s Congress are drawn from popu-
larly elected municipal committees
Politica] parties: none
Communists: no organized party, negli-
gible membership
Libya (continued)
Other political or pressure groups: vari-
ous Arab nationalist movements and the
Arab Socialist Resurrection (Ba''th) party
with almost negligible memberships may
be functioning clandestinely, as well as
some Islamic elements
Member of: AfDB, Arab League, FAO,
G-77, IAEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IOOC, ITU, NAM, OAPEC, OAU, OIC,
OPEC, UN, UNESCO, UPU, WHO,
W1PO, WMO, WSG','83641d819fd79e2f6d2ad7fb41fd38c1ed201bc26364564824d9c06dc07ebe0a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7fc25733df8a8be805abf96666468cbb9b16a5dc42a9050084b1b250110a785',1987,'LI','Liechtenstein','government',420,'Official name: Principality of Liechten-
stein
Type: hereditary constitutional monarchy
Capital: Vaduz
Administrative divisions: 11 communes
Legal system: principality has its own
civil and penal codes; lowest court is
county court (Landgericht) which decides
minor civil cases and summary criminal
offenses; criminal court (Kriminalgericht) is
for major crimes; the court of assizes is for
misdemeanors; Superior Court
(Obergericht) and Supreme Court (Ober-
ster Gerichtshof) are courts of appeal for
civil and criminal cases; an administrative
court of appeal from government actions
and the State Court determine the consti-
tutionality of laws; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral legislature (Diet)
with 15 deputies elected to four-year
terms, hereditary Prince, independent
judiciary
Government leaders: FRANZ JOSEF II,
Prince (since 1938); Hans BRUNHART,
Head of Government (Prime Minister;
since May 1978); the Prince transferred
most of his executive powers to his son,
Prince HANS ADAM, in August 1984
Suffrage: universal adult
Elections: every four years; last election
1986
Political parties and leaders: Fatherland
Union (VU), Dr. Otto Hasler; Progressive
Citizens’ Party (FBP), Dr. Herbert Bat-
liner; Christian Social Party, Fritz Kaiser
Voting strength: (1986) VU 50.2% (8
seats), FBP about 41.9% (7 seats)
Communists: none
Member of: Council of Europe, EFTA,
IAEA, INTELSAT, INTERPOL, ITU,
UNCTAD, UNIDO, UNICEF, UPU,
WIPO; considering UN membership; has
consultative status in the EC; under several
post-World War I treaties Switzerland
handles Liechtenstein’s customs and repre-
sents the principality abroad on a diplo-
matic and consular level whenever re-
quested to do so by the Liechtenstein','59f485cacd125757a7fa9f8c8c7db4dbf1d63b834c6832616e209f41d7c5e887','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7be4bc5285f0883252b6aa38f36f1872f8c62291db83247e8db244a2510cee7',1987,'LU','Luxembourg','government',425,'Official name: Grand Duchy of Luxem-
bourg
Type: constitutional monarchy
Capital: Luxembourg
Administrative divisions: unitary state,
but for administrative purposes has 3
districts (Luxembourg, Diekirch,
Grevenmacher) and 12 cantons
Legal system: based on civil law system;
constitution adopted 1868; accepts compul-
sory IC) jurisdiction
National holiday: 23 June
Branches; parliamentary democracy;
seven ministers compose Council of Gov-
ernment headed by President, which
constitutes the executive; it is responsible
to the unicameral legislature (Chamber of
Deputies); the Council of State, appointed
for indefinite term, exercises some powers
of an upper house; judicial power exer-
cised by independent courts; coalition
governments are usual
Government leaders: JEAN, Grand Duke
(since 1964); Jacques SANTER, Prime
Minister (since July 1984)
Suffrage: universal and compulsory over
age 18
Elections: every five years for entire
Chamber of Deputies; latest elections June
1984
Politica] parties and leaders: Christian
Social Party (CSV), Jean Spautz; Socialist
Workers Party (POSL), Ben Fayot; Liberal
(DP), Colette Flesch; Communist (PCL),
René Urbany; Independent Socialists, Jean
Gremling; Green Alternative (GAP), Jean
Huss
Voting strength: (1984) Chamber of Depu-
ties—Christian Social Party, 25; Socialist
Workers Party, 21; Liberals, 14; Commu-
nists, 2; Green Alternative, 2
Communists: 500 party members (1982)
146
Other political or pressure groups: group
of steel industries representing iron and
steel industry, Centrale Paysanne repre-
senting agricultural producers; Christian
and Socialist labor unions; Federation of
Industrialists; Artisans and Shopkeepers
Federation
Member of: Benelux, BLEU, Council of
Europe, EC, EIB, EMS, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IEA, IFAD,
IFC, ILO, IMF, INTELSAT, INTERPOL,
IOOC, IPU, ITU, NATO, OECD, UN,
UNESCO, UPU, WEU, WHO, WIPO,
WMO
Official name: Macau
Type: Chinese territory under Portuguese
administration
Capital; Macau
Administrative divisions: municipality of
Macau and two islands— Ilha da Taipa
and Ilha da Coloane
Legal system: Portuguese civil law system
Branches: Governor assisted by five
Secretaries-Adjunct (all appointed by
President of Portugal), 17-member Legisla-
tive Assembly (five appointed by Gover-
nor, six elected by universal suffrage, six
elected by various groups and associations)
Government leader: Dr. Joaquim Pinto
MACHADO, Governor (since May 1986)
Suffrage: Portuguese, Chinese, and foreign
residents over 18
Elections: conducted every four years
Political parties and leaders: Association
to Defend the Interests of Macau; Macau
Democratic Center; Group to Study the
Development of Macau; Macau Indepen-
dent Group
Other political or pressure groups:
wealthy Macanese and Chinese represent-
ing local interests, wealthy pro-Communist
merchants representing China''s interests;
in January 1967 Macau Government
acceded to Chinese demands that gave
China veto power over administration
Member of: Multifiber Agreement','37a0d412bf81b0810a92d6f433ce18261c0a9a9b0fbe2d0b05dafa7b32d9a311','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd494e2d757d2e688ad176aabaac06d1a8372bdf96d4da6a70fd64fea0833d9c',1987,'MG','Madagascar','government',430,'Official name: Democratic Republic of
Type: real authority in hands of the Presi-
dent, although Supreme Revolutionary
Council is theoretically ultimate executive
authority
Capital; Antananarivo
Administrative divisions: 6 provinces
Legal system: based on French civil law
system and traditional Malagasy law;
constitution of 1959 modified in October
1972 by law establishing provisional gov-
ernment institutions; new constitution
accepted by referendum in December
1975; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 26
June
Branches: executive—a ]9-member Su-
preme Revolutionary Council (made up of
military and political leaders); assisted by
cabinet called Council of Ministers; uni-
cameral legislative—Popular National
Assembly; Military Committee for Devel-
opment; regular courts are patterned after
French system, and a High Council of
Institutions reviews all legislation to deter-
mine its constitutional validity
Government leaders: Adm. Didier
RATSIRAKA, President (since June 1975);
Lt. Col. Desire RAKOTOARIJAONA,
Prime Minister (since 1977)
Suffrage: universal over age 18
Elections: referendum held in December
1975 gave overwhelming approval to
government and new constitution; elections
for Popular National Assembly held in
June 1977 and in August 1983; only one
political group allowed to take part in the
election, The National Front for the De-
fense of the Revolution, which presented a
single list of candidates; a presidential
election in November 1982 returned
President Ratsiraka with an 80% majority;
the challenger, Monja Jaona, received 20%
and was later arrested after leading dem-
onstrations to protest election fraud
Political parties and leaders: seven par-
ties are now allowed limited political
activity under the national] front and are
represented on the Supreme Revolutionary
Council: Advance Guard of the Malagasy
Revolution (AREMA), Didier Ratsiraka;
Congress Party for Malagasy Independence
(AKFM), Pastor Richard Andriamanijato;
Movement for Nationa] Unity (VONJY),
Dr. Marojama Razanabahiny; Malagasy
Christian Demcratic Union (UDECMA),
Norbert Andriamorasata; Militants for the
Establishment of a Proletarian Regime
(MFM), Manandafy Rakotonirina; National
Movement for the Independence of
Madagascar (MONIMA), Monija Jaona;
Socialist Organization MONIMA (VS
MONIMA), Remanindry Jaona
Voting strength: 4.8 million registered
voters (1982); in 1977 local elections,
President Ratsiraka’s AREMA captured
about 89.5% of the 73,000 available posi-
tions on 11,400 local executive committees;
AKFM won about 7.3% of the seats,
MONIMA 1.7%, and VONJY 1.4%;
UDECMA won only about 45 seats; in the
1988 legislative election AREMA won 117
out of the 187 seats in the Popular Na-
tional Assembly
Communists: Communist party of virtu-
ally no importance; small and vocal group
of Communists has gained strong position
in leadership of AKFM, the rank and file
of which is non-Communist
Member of: AfDB, EAMA, FAO, G-77,
GATT, IAEA, IBRD, ICAO, ICO, IDA,
IFAD, IFC, 1LO, IMF, IMO, INTELSAT,
INTERPOL, IRC, ISO, ITU, NAM, OAU,
OCAM, UN, UNESCO, UPU, WFTU,
WHO, WMO, WTO','62b9bb681dcbf6e18d2a2ca89dea44d22dab9d030daca2a4c7efae09298616f0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a67586348704aaabd12faf4240f391a0047d48868da3eed56ac5e0fdb9b9a93',1987,'MW','Malawi','government',435,'Official name: Republic of Malawi
Type: one-party state
Capital: Lilongwe
Administrative divisions: 3 administrative
regions and 24 districts
Legal system: based on English common
law and customary law; constitution
adopted 1964; judicial review of legislative
acts in the Supreme Court of Appeals; has
not accepted compulsory ICJ jurisdiction
National holiday: Republic Day, 6 July
Branches: strong presidential system with
Cabinet appointed by President; unicam-
eral National Assembly of 87 elected and
up to 15 nominated members; High Court
with Chief Justice and at least two justices
Government leader: Dr. Hastings Kamuzu
BANDA, President (since 1966)
Suffrage: universal over age 18
Elections: President Banda designated
President for Life in 1970; parliamentary
elections last held June 1983, next sched-
uled for 1988
Political parties and leaders: Malawi
Congress Party (MCP), Robson Chirwa,
administrative secretary
Communists: no Communist party
Member of: AfDB, Commonwealth, EC
(associated member), FAO, G-77, GATT,
IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF,
INTELSAT, INTERPOL, IPU, 1SO, ITU,
NAM, OAU, SADCC, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO
150','6cad2e076d58c062d8c4d9800e7d393489f697772ebe1a5ba9edbe8062176ebb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8287e8d337500d6c9536128adaa496251b3c8c142dbb62fe23dc9419872c7da4',1987,'MY','Malaysia','government',440,'Official name: Malaysia
Type: Federation of Malaysia formed 9
July 1963, constitutional monarchy nomi-
nally headed by Paramount Ruler (King), a
bicameral Parliament consisting of a
58-member Senate and a 154-member
House of Representatives; Peninsular
Malaysian states—hereditary rulers in all
Malaysia (continued)
but Penang and Melaka where Governors
appointed by Malaysian Government,
powers of state governments limited by
federal constitution; Sabah—self-governing
state, holds 16 seats in House of Represen-
tatives with foreign affairs, defense, inter-
nal security, and other powers delegated to
federal government; Sarawak—self-
governing state within Malaysia in which
it holds 24 seats in House of Representa-
tives with foreign affairs, defense, and
interna] security, and other powers dele-
gated to federal] government
Capital; Kuala Lumpur
Administrative divisions: 14 states (in-
cluding Sabah and Sarawak)
Legal system: based on English common
law; constitution came into force 1963;
judicial review of legislative acts in the
Supreme Court at request of Supreme
Head of the Federation; has not accepted
compulsory 1CJ jurisdiction
National holiday: 31 August, Indepen-
dence Day
Branches: nine state rulers alternate as
Paramount Ruler for five-year terms; locus
of executive power vested in Prime Minis-
ter and Cabinet, who are responsible to
bicameral] Parliament (Senate, House of
Representatives); Peninsular Malaysia—
executive branches of 1] states vary in
detail but are similar in design with a
Chief Minister, appointed by hereditary
ruler or Governor, heads an executive
council (cabinet), which is responsible to
an elected, unicameral legislature; Sarawak
and Sabah—executive branch headed by
Governor appointed by central govern-
ment, largely ceremonial role; executive
power exercised by Chief Minister who
heads parliamentary cabinet responsible to
unicameral legislature; judiciary part of
Malaysian judicial system
Government leader: Dr. MAHATHIR bin
Mohamad, Prime Minister (since July
1981)
Suffrage: universal over age 21
Elections: minimum of every five years;
last elections August 1986
Political parties and leaders: Peninsular
Malaysia—National Front, a confederation
of 1] political parties dominated by
United Malays National Organization
(UMNO), Mahathir bin Mohamad; major
opposition party is Democratic Action
Party (DAP), Lim Kit Siang; Sabah—
Berjaya Party, Datuk Haji Mohamad Noor
Haji Mansodr; Bersatu Sabah (PBS), Joseph
Pairin Kitingan; United Sabah National
Organization (USNO), Tun Datuk Mus-
tapha; Sarawak—coalition Sarawak Na-
tional Front composed of the Party Pesaka
Bumipatra Bersatu (PBB), Datuk Abdul
Taib; the United People’s Party (SUPP),
Wong Soon Kai; and the Sarawak National
Party (SNAP), Datuk James Wong; opposi-
tion is Parti Bansa Dayak Sarawak (PBDS),
Leo Moggie
Voting strength: Peninsular Malaysia—
(1986 parliamentary election, lower house
of parliament) National Front, 148 seats;
DAP, 24 seats; PAS, ] seat; independents,
4 seats; Sabah—{April 1985 state election,
State Assembly) Berjaya Party, 6 seats;
USNO, 16 seats; PBS, 26 seats; Sarawak—
(December 1983 state election) State As-
sembly National Front controlled nearly
two-thirds of 46 seats
Communists: Peninsular Malaysia—about
2,000 armed insurgents on Thailand side
of international boundary; about 200
full-time inside Malaysia; Sarawak—less
than 100, North Kalimantan Communist
Party; Sabah—insignificant
Member of: ADB, ANRPC, ASEAN,
Association of Tin Producing Countries,
Colombo Plan, Commonwealth, ESCAP,
FAO, G-77, GATT, IAEA, IBRD, ICAO,
IDA, IDB—Islamic Development Bank,
1FC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ITC, ITU, NAM,
OIC, UN, UNESCO, UPU, WHO, WMO,
WTO','47c2a879ecffb886472237c4a8457511949becd6a1ed6904e5d7c8a1d6be40d9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c1811e564008653172c6211d128fffecdd40b01c5873c9e1c6e778de92b59e',1987,'MV','Maldives','government',444,'Official name: Republic of Maldives
Type: republic
Capital: Male
Administrative divisions: 19 administra-
tive districts corresponding to 19 atolls,
plus capital city
Legal system: based on Islamic law with
admixtures of English common law prima-
rily in commercial] matters; has not ac-
cepted compulsory 1CJ jurisdiction
National holidays: Independence Day, 26
July; Republic Day, 11 November
Branches: popularly elected unicameral
national legislature, People’s Council
(members elected for five-year terms);
elected President, chief executive; ap-
pointed Chief Justice responsible for
administration of Islamic law
Government leader: Maumoon Abdul
GAYOOM, President (since 1978)
Suffrage: universal over age 2]
Political parties and leaders: no orga-
nized political parties; country governed
by the Didi clan for the past eight
centuries
Communists: negligible
Member of: ADB, Colombo Plan, Com-
monwealth (special member), ESCAP,
FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, IMF, IMO, ITU, NAM,
OIC, SAARC, UN, UNESCO, UPU,
WHO, WMO
Maldives (continued)','6f4d4d4470210f379ea33b26e58d1b74897084d4e4b094232a8506a010135dd9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b99f2135ef8337947f0e8b83a67eecb3a65d0695c311c30aa77c69af389252ad',1987,'ML','Mali','government',449,'Official name: Republic of Mali
Type: republic; single-party constitutional
Capital: Bamako
Administrative divisions: 7 regions, capi-
tal district
Legal system: based on French civil law
system and customary law; constitution
adopted 1974, came into full effect in
1979; judicial review of legislative acts in
Constitutional Section of Court of State;
has not accepted compulsory ICJ jurisdic-
tion
National holiday: Independence Day, 22
September
Branches: until 1979 executive authority
exercised by Military Committee of Na-
tional Liberation (MCNL) composed of 11
army officers; now Cabinet composed of
civilians and army officers; unicameral
legislature (National Council); judiciary
Government leader: Gen. Moussa
TRAORE, President (led Mali as President
of MCNL during 1968-79; President since
1979)
Suffrage: universal over age 21
Political parties and leaders: Democratic
Union of Malian People (UDPM) is the
sole political party; under civilian leader-
ship
Elections: constitutional elections took
place June 1979
Communists: a few Communists and some
sympathizers (no legal Communist party)
Member of: AfDB, APC, CEAO, ECA,
ECOWAS, FAO, G-77, GATT (de facto),
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, INTELSAT, INTERPOL, IRC, ITU,
Niger River Commission, NAM, OAU,
OIC, OMVS (Organization for the Devel-
opment of the Senegal River Valley), UN,
UNESCO, UPU, WHO, WMO, WTO','316eb99e23777439acc9f419c6b3dd7063fa547d7ba3d51441cec7f83ff33b5c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f569a0b2f6e0be20d03aa5893e7b7cc56b8bd69f867f64bd3194aded5646605f',1987,'MT','Malta','government',454,'Official name: Republic of Malta
Type: parliamentary democracy, indepen-
dent republic within the Commonwealth
since December 1974
Capital: Valletta
Administrative divisions: 2 main popu-
lated islands, Malta and Gozo, divided into
18 electoral districts (divisions)
Legal system: based on English common
law; constitution adopted 1961, came into
force 1964; has accepted compulsory ICJ
jurisdiction, with reservations
Branches: executive, consisting of Prime
Minister and Cabinet; unicameral legisla-
ture (65-member House of Representa-
tives); independent judiciary
National holiday: Freedom Day, 31
March
Government leaders: Agatha BARBARA,
President (since February 1982); Karmenu
MIFSUD BONNICI, Prime Minister (since
December 1984)
Suffrage: universal over age 18; registra-
tion required
Elections: at the discretion of the Prime
Minister, but must be held before the
expiration of a five-year electoral mandate;
last election December 198)
Political parties and leaders: Nationalist
Party, Edward Fenech Adami; Malta
Labor Party, Karmenu Mifsud Bonnici
Voting strength: (1981 election) House of
Representatives—Labor, 84 seats (49% of
the vote); Nationalist, 31 seats (51% of the
vote)
Communists: less than 100 (est.)
Member of: Commonwealth, Council of
Europe, FAO, G-77, GATT, IBRD, ICAO,
IFAD, ILO, IMF, IMO, INTERPOL, ITU,
IWC—International Wheat Council,
NAM, UN, UNDP, UNESCO, UNICEF,
UPU, WHO, WIPO, WMO
Official name: Isle of Man
Type: self-governing British dependent
territory
Capital: Douglas
Administrative divisions: 6 sheadings and
7 constituencies
Legal system: English law and local
statute
National holiday: Birthday of the Queen,
16 June
Branches: the Tynwald (parliament)
consists of the Lieutenant Governor, ap-
pointed by and representative of the
Crown; the Legislative Council (upper
house), which includes members indirectly
elected by the House of Keys and certain
ex officio members; and the elected 24-
member House of Keys (lower house); an
Executive Council carries out administra-
tive actions; the Crown has ultimate re-
sponsibility for the island’s government
Government leaders: Maj. Gen. Laurence
NEW, Lieutenant Governor (since 1985)
who is appointed by the Lord of Mann,
Queen Elizabeth 11, Head of State; J. C.
NIVISON, President of the Legislative
Council (since 1985)
Suffrage: universal at age 21
Elections: every five years
Political parties and leaders: there is no
party system and members sit as indepen-
dents; affiliations—Manx Labor Party,
Alan Clague, chairman; Manx Nationa]
Party, Audrey Ainsworth, chairman; Mec
Vannin (Sons of Man), Lewis Crellin,
chairman
Communists: probably none
157','b5e5b0f12332c4bcce8d335b5bfea405f512bbb856b1daf15c20f8542e5c005c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c7970cc3bf6344e0626ca34493bc6d7b509f07955d1885d98d07bfd797d99c8',1987,'MQ','Martinique','government',459,'Official name: Department of Martinique
Type: overseas department and region of
France; represented by three deputies in
the French National Assembly and two
senators in the Senate
Capital: Fort-de-France
Administrative divisions: 3 arrondisse-
ments; 34 communes, each with a locally
elected municipal council
Legal system: French legal system; highest
court is a court of appeal based in Martin-
ique with jurisdiction over Guadeloupe,
French Guiana, and Martinique
Branches: executive—Prefect appointed
by Paris; legislative—popularly elected
council of 36 members and a Regional
Council, including all members of the
local general council and the locally
elected deputies and senators to the
French parliament; judicial—under juris-
diction of French judicial system
Government leader: Edward LACROIX,
Commissioner (since 1985)
Suffrage: universal over age 18
Elections: General Council election nor-
mally held every five years; last General
Council election took place in June 1981;
regional assembly elections held February
1983
Political parties and leaders: Rally for
the Republic (RPR), Emile Maurice; Pro-
gressive Party of Martinique (PPM), Aimé
Césaire; Communist Party of Martinique
158
(PCM), Armand Nicolas; Command Party
of Martinique (PCM), Léon-Laurent
Valére
Voting strength: RPR, | seat in French
National Assembly; UDF, 1 seat; Socialist
Party, I seat
Communists: 1,000 estimated
Other political or pressure groups: Prole-
tarian Action Group (GAP); Alhed Marie-
Jeanne Socialist Revolution Group (GRS),
Martinique Independence Movement
(MIM), Caribbean Revolutionary Alliance
(ARC), Central Union for Martinique
Workers (CSTM), Mare Pulvar; Frantz
Fanon Circle; League of Workers and
Peasants
Member of: WFTU','f33ed2fdec38a0ae7749c72cb30e04a1469e1e7c1010b1443889f7cf613ae356','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f146adb213cf74f884c5a5e6a4837482a36406b6b7023f7846b03153df90e89',1987,'MR','Mauritania','government',464,'Official name: Islamic Republic of Mauri-
tania
Type: republic; military first seized power
in bloodless coup 10 July 1978; a palace
coup that took place on 12 December
1984 brought the President to power
Capital: Nouakchott
Administrative divisions: 12 regions and a
capital district
Legal system: based on Islamic law; mili-
tary constitution April 1979
National holiday: Independence Day, 28
November
Branches: executive, Military Committee
for National Salvation rules by decree;
National Assembly and judiciary sus-
pended pending restoration of civilian rule
Government leader: Col. Maaouiya Ould
Sid Ahmed Ould TAYA, President and
Prime Minister (since December 1984)
Suffrage: universal for adults
Elections: municipal elections conducted
December 1986; last presidential election
August 1976
Political parties and leaders: suspended
Communists: no Communist Party, but
there is a scattering of Maoist sympathizers
Mauritania (continued)
Member of: AfDB, AIOEC, Arab League,
CEAO, CIPEC (associate), EAMA, EIB
(associate), FAO, G-77, GATT, IBRD,
ICAO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU,
NAM, OAU, OIC, OMVS (Organization
for the Development of the Senegal River
Valley), UN, UNESCO, UPU, WHO,
WIPO, WMO','cf7f3caaf87d558b68c67f2d189f72e6048a9261d55a3966ff6d63601c940d5a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9e0736c422d5f5a746f14491c6afc85c02e2fbe8954b6b1752d44888b6f2cb9',1987,'MU','Mauritius','government',469,'Official name: Mauritius
Type: independent state, recognizing
Elizabeth II as Chief of State
Capital: Port Louis
Administrative divisions: 5 organized
municipalities and various island depen-
dencies
Legal system: based on French civil law
system with elements of English common
law in certain areas; constitution adopted 6
March 1968
National holiday: Independence Day, 12
March
Branches: executive power exercised by
Prime Minister and 19-member Council of
Ministers; unicameral legislature (Legisla-
tive Assembly) with 62 members elected
by direct suffrage, eight specially elected
under the so called best loser system
Government leader: Aneerood
JUGNAUTH, Prime Minister (since June
1982)
Suffrage: universal over age 18
Elections: legislative August 1983
Political parties and leaders: the govern-
ment is currently controlled by a coalition
composed of the Militant Socialist Move-
ment (MSM) led by A. Jugnauth, the
Mauritian Social Democratic Party (PMSD)
led by G. Duval, the Mauritian Workers’
Assembly (RTM) led by Beergoonath
Ghurburrun, and the Mauritian Labor
Party (MLP) faction, led by party head S.
Boolell; the main opposition party is the
Mauritian Militant Movement (MMM) led
by P. Bérenger.
Voting strength: MSM, 30 of 70 seats in
the Assembly; MMM, 21; MLP, 11; PMSD,
4; OPR, 2; and independents, 2
Communists: may be 2,000 sympathizers;
several Communist organizations; Maurit-
ius Lenin Youth Organization, Mauritius
Women’s Committee, Mauritius Commu-
nist Party, Mauritius People’s Progressive
Party, Mauritius Young Communist
League, Mauritius Liberation Front, Chi-
nese Middle Schoo! Friendly Association,
Mauritius/USSR Friendship Society
Other political or pressure groups: vari-
ous labor unions
Member of: AfDB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
ISO, ITU, IWC—International Wheat
Council, NAM, OAU, OCAM, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO','f47c8a7a4da1b5e01422517fed2c95d5721ffbde7a8452f46c19567848f0f4c2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('833cd61e9047ca3630947fa42e415379c156d3b60b99813acfeefbb924a0ec56',1987,'KM','Comoros','government',473,'Official name: Mayotte
Type: French overseas territority
Capital: Dzaoudzi
Legal system: represented in French
Parliament by one deputy in the National
Assembly and one member in the Senate;
superior court of appeal
Branches: elected 17-member general
council; appointed commissioner
Government leaders: Christian
PELLERIN, Commissioner of the Repub-
lic (since 1983); Younoussa BAMANA,
President of the General Council (since
1976)
Political parties and leaders: Mahoran
Popular Movement (MPM), Zia M’Oere;
Party for the Mahoran Democratic Rally
(PRDM), Darouéche Maoulida; Mahoran
Rally for the Republic (RMPR), Abdoul
Anizizi
Communists: probably none','30c52eb295d53b188f91eae57f3cf6513ab3a3d075552bd03c6aacd32b901a82','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f18284111e45a0c56a44da15e24ce67ecc0dcee35803d920a48bb2478d2f491',1987,'MX','Mexico','government',478,'Official name: United Mexican States
Type: federal republic operating under a
centralized government
Capital: Mexico
Administrative divisions: 31 states and
the Federal District
Legal system: mixture of US constitutional
theory and civil law system; constitution
established in 1917; judicial review of
legislative acts; accepts compulsory [CJ
jurisdiction, with reservations
National holiday: Independence Day, 16
September
Branches: dominant executive, bicameral
legislature (National Congress—Senate,
Federal Chamber of Deputies), Supreme
Court
Government leader: Miguel DE LA
MADRID Hurtado, President (since De-
cember 1982)
Suffrage: universal over age 18; compul-
sory but unenforced
Elections: next presidential election to be
held in 1988
Political parties and leaders: (recognized
parties) Institutional Revolutionary Party
(PRI), Jorge de la Vega; National Action
Party (PAN), Pablo Emilio Madero; Popu-
lar Socialist Party (PPS), Jorge Cruickshank
Garcia; Unified Socialist Party of Mexico
(PSUM), Pablo Gomez Alvarez; Mexican
163
Democratic Party (PDM), Ignacio
Gonzalez Gollaz; Socialist Workers Party
(PST), Pedro Etiene; Revolutionary Work-
ers Party (PRT), Ricardo Pascoe Pierce;
Mexican Workers Party (PMT), Heberto
Castillo Martinez; Authentic Party of the
Revolution (PARM), Carlos Enrique Cantu
Rosas
Voting strength: (1985 congressional
election) 66% PRI, 15% PAN, 3% PSUM,
3% PDM, 2% PST, 2% PPS, 2% PARM, 2%
PMT, 1% PRT, 4% other parties or an-
nulled
Other political or pressure groups: Ro-
man Catholic Church, Confederation of
Mexican Workers (CTM), Confederation of
Industrial Chambers (CONCAMIN), Con-
federation of National Chambers of Com-
merce (CONCANACO), National Peasant
Confederation (CNC), National Confedera-
tion of Popular Organizations (CNOP),
Revolutionary Confederation of Workers
and Peasants (CROC)
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAC, ICAO, ICO, IDA,
[DB—Inter-American Development Bank,
IFAD, IFC, ILO, International Lead and
Zinc Study Group, IMF, IMO,
INTELSAT, INTERPOL, IRC, ISO, ITU,
IWC—International Whaling Commission,
LAIJA, OAS, PAHO, SELA, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO, Group of Six
Fiscal year: calendar year
Official name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Administrative divisions: 20 counties, 407
communes, 47 towns
Dependent areas: Bouvet Island, Jan
Mayen, Peter I Island, Svalbard
Legal system: mixture of customary law,
civil law system, and common law tradi-
tions; constitution adopted in 1814 and
modified in 1884; Supreme Court renders
advisory opinions to legislature when
asked; accepts compulsory 1CJ jurisdiction,
with reservations
National holiday: Constitution Day, 17
May
Branches: legislative authority rests jointly
with Crown and parliament (Storting—
Lagting, upper house; Odelsting, lower
house); executive power vested in Crown
but exercised by Cabinet responsible to
parliament; Supreme Court, 5 superior
courts, 104 lower courts
Government leaders: OLAV V, King
(since 1957); Gro Harlem BRUNDTLAND,
Prime Minister (since May 1986)
Suffrage: universal at age 18 but not
compulsory
Elections: held every four years (next in
1989)
Politica] parties and leaders: Labor, Gro
Harlem Brundtland; Conservative, Rolf
Presthus; Center, Johan J. Jakobsen; Chris-
tian People’s, Kjell Magne Bondevik;
Liberal, Arne Fjortoft; Socialist Left, Theo
Koritzinsky; Norwegian Communist, Hans
I. Kleven; Progressive, Carl 1. Hagen
Voting strength; (1985 election) Labor,
40.8%; Conservative, 30.4%; Christian
People’s, 8.3%; Center, 6.6%; Socialist Left
(Socialist Electoral Alliance), 5.5%; Progres-
sive, 3.7%; Liberal, 3.1%; Red Electoral
Alliance, 0.6%; Liberal People’s Party
(antitax), 0.5%; Norwegian Communist,
0.2%; other 0.4%
Communists: 15,500 est.; 5,500 Norwegian
Communist Party (NKP); 10,000 Workers
Communist Party Marxist-Leninist
(AKP-ML, pro-Chinese)
Member of: ADB, Council of Europe,
DAC, EC (Free Trade Agreement), EFTA,
ESRO (observer), FAO, GATT, IAEA,
IBRD, ICAC, 1CAO, ICES, ICO, IDA,
IEA (associate member), IFAD, [FC, [HO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
International Lead and Zinc Study Group,
IPU, ITU, [WC—International Whaling
Commission, 1!WC—International Wheat
Council, NATO, Nordic Council, OECD,
UN, UNESCO, UPU, WHO, WIPO,
WMO, WSG
Official name: Sultanate of Oman
Type: absolute monarchy; independent,
with residual UK influence
Capital: Muscat
Administrative divisions: 1 province
(Dhofar), 2 governorates (Musandam and
Muscat), and numerous districts (wilayats)
Legal system: based on English common
law and Islamic law; no constitution;
ultimate appeal to the Sultan; has not
accepted compulsory ICJ jurisdiction
Branches: executive—Sultan, who ap-
points 45-member State Consultative
Assembly to advise him; judicial—tradi-
tional Islamic judges and a nascent civil
court system
National holiday: National Day, 18-19
November
Government leader: QABOOS bin Said,
Sultan (since July 1970)
Political parties: none
Other political or pressure groups: out-
lawed Popular Front for the Liberation of
Oman (PFLO), based in South Yemen
Member of: Arab League, FAO, G-77,
GCC, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, IMF,
IMO, INTELSAT, INTERPOL, ITU,
NAM, OIC, UN, UNESCO, UPU, WFTU,
WHO, WMO
Official name: Polish People’s Republic
Type: Communist state
Capital: Warsaw
Administrative divisions: 49 provinces
Legal system: mixture of Continental
(Napoleonic) civil law and Communist
legal theory; constitution adopted 1952;
court system parallels administrative
divisions with Supreme Court, composed
of 104 justices, at apex; no judicial review
of legislative acts; has not accepted com-
pulsory ICJ jurisdiction
National holiday: National Liberation
Day, 22 July
Branches: unicameral legislature (Sejm),
executive, judicial system dominated by
parallel Communist party apparatus
Government leaders: Zbigniew MESS-
NER, Chairman of Council of Ministers
(Premier; since November 1985); Army
Gen. Wojciech JARUZELSKI, Chairman
of Council of State (President; since No-
vember 1985)
Suffrage: universal and compulsory over
age 18
Elections: parliamentary and local govern-
ment every four years; last election held
October 1985
Political party and leader: Polish United
(Communist) Workers’ Party (PZPR),
Poland (continued)
Woiciech Jaruzelski, First Secretary (since
October 1981)
Voting strength: (October 1985 election)
78.86% voted for Communist-approved
candidates
Communists: 2.1 million (1986)
Other political or pressure groups: United
Peasant Party (ZSL), Democratic Party
(SD); powerful Roman Catholic Church,
Patriotic Movement of National Rebirth
(PRON)
Member of: CEMA, FAO, GATT, IAEA,
ICAO, ICES, THO, ILO, Indochina Truce
Commission, IMO, International Lead and
Zinc Study Group, IPU, ISO, ITC, ITU,
Korea Truce Commission, UN, UNESCO,
UPU, WFTU, WHO, Warsaw Pact,
WIPO, WMO, WTO
Official name: Socialist Republic of Viet-
nam
Type: Communist state
Capital: Hanoi
Administrative divisions: 40 provinces,
under central government control
Legal system: based on Communist legal
theory and French civil law system
National holiday: 2 September
Branches: unicameral legislature (National
Assembly); highest authority of the land is
technically the Council] of State, whose
chairman serves as the country’s President;
Council of Ministers oversees implementa-
tion of party policies—chairman is equiva-
lent of premier
Government leader: Nguyen Van LINH,
Secretary General of the Communist Party
(since December 1986)
Suffrage: universal over age 18
Elections: pro forma elections held for
national and local assemblies; last election
for National Assembly held on 25 April
1976
Political party and leader: Vietnam
Communist Party (VCP), Nguyen Van
Linh
Communists: probably more than 1 mil-
lion
Member of: ADB, CEMA, Colombo Plan,
ESCAP, FAO, G-77, IAEA, IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, INTELSAT,
IRC, ITU, Mekong Committee, NAM, UN,
UNDP, UNESCO, UNICEF, UPU,
WFTU, WHO, WIPO, WMO, WTO','c77dd5213d7a7ab20b002f61bfc97adb031d305f1a5db5b1d341269f6ba6c7db','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a0bb2c6eca1c46b07ba60d7bf3903b0792f53114162538ae7f4b82c940848a',1987,'MC','Monaco','government',482,'Official name: Principality of Monaco
Type: constitutional monarchy
Capital; Monaco
Administrative divisions: 1] commune
composed of 4 communal sectors
Legal system: based on French law; new
constitution adopted 1962; has not ac-
cepted compulsory ICJ jurisdiction
National holiday: 19 November
Branches: legislative branch is composed
of the Prince and National Council of 18
members; executive consists of the Prince
as Chief of State, the Minister of State as
Head of Government (senior French civil
servant appointed by Prince), and the
Council of Government as Cabinet; judi-
cial authority is delegated by the Prince to
the Supreme Tribunal
Government leader: Prince RAINIER III,
Chief of State (since November 1949)
Suffrage: universal adult
Elections: National Council every five
years; national election held January 1983;
municipal election held February 1983
Politica] parties and leaders: National
and Democratic Union (UND), Democratic
Union Movement (MUD), Monaco Action,
Monegasque Socialist Party (PSM)
Voting strength: National Council—UND
18 seats
Member of: IAEA, ICAO, IHO,
INTELSAT, INTERPOL, IPU, ITU, UN
(permanent observer), UNESCO, UPU,
WHO, WIPO','0e0b8b5ab56187f13dad5871b3bef3655d1bc2c21cfc17c3bdba8249f27b3813','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0dcffe0352728d8c0beeecde3721cc947b30339536bd17ecea18b48efd21ef',1987,'MN','Mongolia','government',487,'Official name: Mongolian People’s
Republic
Type: Communist state
Capital: Ulaanbaatar
Administrative divisions: 18 provinces
and 3 autonomous municipalities
(Ulaanbaatar, Darhan, and Erdenet)
Legal system: blend of Russian, Chinese,
and Turkish systems of law; new constitu-
tion adopted 1960; no constitutional provi-
sion for judicial review of legislative acts;
has not accepted compulsory ICJ jurisdic-
tion
National holiday: People’s Revolution
Day, 11 July
Branches: executive—Council of Minis-
ters; legislative—unicameral People’s Great
Hural; judicial—court system; Supreme
Court elected by People’s Great Hural
Government leaders: Jambyn
BATMONH, Chairman of the Presidium
of the People’s Great Hural (since Decem-
ber 1984); Dumaagiyn SODNOM, Chair-
man of the Council of Ministers (since
December 1984)
Suffrage: universal at age 18 and over
Elections: legislative election theoretically
held every four years; last election held
June 1986
Political party and leader: Mongolian
People’s Revolutionary Party (MPRP),
Jambyn Batmonh, General Secretary (since
August 1984)
Communists: estimated MPRP member-
ship, 88,150 (1986)
Member of: CEMA, ESCAP, FAO, IAEA,
ILO, IPU, ITU, UN, UNESCO, UPU,
WFTU, WHO, WIPO, WMO','5e0591a047e5572a9ab43c4765ecababb927e43cf45394a9b63e449250ddf6fa','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c636109e64871839cc6dd7e51674c59e20d61140463ddada6c801c8fdbd9563',1987,'MS','Montserrat','government',492,'Official name: Montserrat
Type: British dependent territory
Capital: Plymouth
Administrative divisions: 7 districts
Legal system: English common law and
statute law
Branches: Executive Council presided
over by governor, consisting of two ex-
officio members (attorney general and
financial officer) and four unofficial mem-
bers (chief minister and three other minis-
ters); Legislative Council presided over by
Speaker chosen from outside the Council,
seven elected, two official, and two nomi-
nated members
Government leaders: Arthur C.
WATSON, Governor (since 1985); J. A.
OSBORNE, Chief Minister (since 1978)
Suffrage: universal over age 18
Elections: at least once every five years;
last election held February 1983
Political parties and leaders: People’s
Liberation Movement (PLM), John Os-
borne; Progressive Democratic Party
(PDP), P. Austin Bramble; United National
Front (UNF), Dr. George Irish; National
Development Party (NDP), Bertram
Osborne
Voting strength: July 1984 elections—
PLM, 4 seats; PDP, 3 seats
Communists: probably none','bbdd491d7096a04cd172815e343ee80578ca81f493e69574594ce748000776e0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6439b39de0059f09ae96f17ba7144ebe05a20d88c2b7250af8809ec22fe9d949',1987,'MA','Morocco','government',497,'Official name: Kingdom of Morocco
Type: constitutional monarchy (constitu-
tion adopted 1972)
Capital: Rabat
Administrative divisions: 36 provinces
(does not include Western Sahara) and 2
prefectures (Rabat-Salé and Casablanca)
Legal system: based on Islamic law and
French and Spanish civil law system;
judicial review of legislative acts in Consti-
tutional Chamber of Supreme Court
National holiday: Independence Day, 18
November
Branches: constitution provides for Prime
Minister and ministers named by and
responsible to King; King has paramount
executive powers; unicameral legislature
(Chamber of Representatives), of which
two-thirds of the members are directly
elected and one-third are indirectly
elected; judiciary independent of other
branches
168
Government leaders: HASSAN II, King
(since March 1961); Azzedine LARAKI,
Prime Minister (since September 1986)
Suffrage: universal over age 20
Elections: provincial elections held 10
June 1983; elections for National Assembly
held 14 September 1984
Political parties and leaders: Morocco has
15 political parties; the major ones are
Istiqlal Party, M’Hamed Boucetta; Socialist
Union of Popular Forces (USFP), Abder-
rahim Bouabid; Popular Movement (MP),
Secretariat General; National Assembly of
Independents (RNI) formed in October
1978 is progovernment grouping of previ-
ously unaffiliated deputies in parliament,
Ahmed Osman; National Democratic
Party (PND), a splinter group from the
RNI formed July 1981, Mohamed Arsalane
El-Jadidi; Party for Progress and Socialism
(PPS), legalized in August 1974, is front for
Moroccan Communist Party (PCM), which
was proscribed in 1959, Ali Yata; new
promonarchy party—the Constitutional
Union (UC), Maati Bouabid
Voting strength: progovernment parties
hold absolute majority in Chamber of
Representatives; with palace-oriented
Popular Movement deputies, the King
controls over two-thirds of the seats
Communists: about 2,000
Member of: AfDB, Arab League, EC
(associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IDB—Islamic Devel-
opment Bank, IFAD, IFC, ILO, Interna-
tional Lead and Zinc Study Group, IMF,
IMO, INTELSAT, INTERPOL, IOOC,
IPU, ITU, NAM, OIC, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO','128b0ebbf76d9f6b4375eb796d4bb98b0f36bf8e4b53ee5e7cc8fa250c69d4dc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d89fbdebc2e0d116f5f445e7394762a8b82393f220b56a40621edcf0ca8e60ba',1987,'MZ','Mozambique','government',502,'Official name: People’s Republic of
Type: people’s republic
Capital: Maputo
Administrative divisions: 10 provinces
subdivided into 112 districts; administra-
tors are appointed by central government
Legal system: based on Portuguese civil
law system and customary law
National holiday: Independence Day, 25
June
Branch: unicameral legislature (People’s
Assembly; last convened in December
1985)
Government leaders: Joaquim Alberto
CHISSANO, President (since November
1986); Mario da Graca MACHUNGO,
Prime Minister (since July 1986)
Suffrage: universal adult
Elections: legislative elections held in
many areas of the country in 1986
Political parties and leaders: Front for
the Liberation of Mozambique
(FRELIMO) is the only legal party and is a
Marxist organization with close ties to the
USSR
Communists: about 50,000 FRELIMO
members
Member of: AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IFAD, ILO, IMF,
IMO, ITU, NAM, OAU, SADCC, UN,
UNESCO, UPU, WHO, WMO','2a67674ca9725090669f39cbab81864c784298a243f2b2d5083991f03ac5dd74','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('802f5072741f932aa678c966b47c1fecd51abf28dff446778f89fa9e5a9aca07',1987,'NA','Namibia','government',507,'Official name: Namibia
Type: former German colony of South-
West Africa mandated to South Africa by
League of Nations in 1920; UN formally
ended South Africa’s mandate on 27
October 1966, but South Africa has re-
tained administrative control
Capital: Windhoek
Administrative divisions: 10 tribal home-
lands, mostly in northern sector, and zone
open to white settlement with 26 magiste-
rial districts similar to a province of South
Africa
Legal system: based on Roman-Dutch law
and customary law
Branches: since September 1977 Adminis-
trator General, appointed by South African
Government, has exercised coordinative
functions over zone of white settlement
and tribal homelands, where traditional
chiefs and representative bodies exercise
limited autonomy; veto power over legisla-
tion proposed by National Assembly;
interim government established June 1985
with eight-member Cabinet, 16-member
Constitutional Council and 62-member
National Assembly
Government leader: Louis A. PIENAAR,
Administrator General (since July 1985)
171
Suffrage: universal white adult suffrage at
territorial level; lower level elections open
to blacks
Elections: last election of Namibian Na-
tional Assembly, December 1978
Political parties and leaders: six parties
belong to multiracial South African-
appointed Transitional Government of
National Unity Democratic Turnhalle
Alliance (DTA), Dirk Mudge; South-West
African National Union (SWANU), Moses
Katjiuongua; South-West African People’s
Organization Democrats (SWAPO-D),
Andreas Shipanga; South-West African
National Party (SWANP), Kosie Pretorius;
Colored Labor Party, David Bezuidenhout;
Rehoboth Free Democratic Party (RFDP),
Hans Diergaardt; other parties—United
Democratic Party, formed in September
1985 after merger of two Caprivi parties,
Mishake Muyongo; Federal Party, largely
white, English-speaking, liberal; Christian
Democratic Action Party, a primarily
Ovambo party formed in early 1982 as a
result of a split in the DTA, Peter
Kalangula
Voting strength: (1978 election) Namibian
National Assembly—DTA, 22 seats;
SWANP, 8 seats; SWANU, 8 seats;
SWAPO-D, 8 seats; CP, 8 seats; RFDP, 8
seats; Assembly appointed in June 1985
Communists: no Communist Party;
SWAPO guerrilla force is supported by
USSR, Cuba, and other Communist states
as well as the Organization for African
Unity
Other political or pressure groups: South-
West African People’s Organization
(SWAPO), led by Sam Nujoma, maintains
a foreign-based guerrilla movement; is
predominantly Ovambo but has some
influence among other tribes; is the only
Namibian group recognized by the UN
General Assembly and the Organization of
African Unity
Member of: FAO, ILO, UNESCO,
WFTU, WHO
Namibia (continued)
Official name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legisla-
tive, Cape Town; judicial, Bloemfontein
Administrative divisions: 4 provinces; 10
homelands (4 independent, 6 dependent)
administered in areas set aside for blacks
Legal system: based on Roman-Dutch law
and English common law; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: Republic Day, 3] May
Branches: state president is chief of state,
head of government, and chairman of
cabinet; tricameral legislature—House of
223
Assembly (whites), House of Representa-
tives (coloreds), and House of Delegates
(Indians) elected directly by respective
racial electorates; judiciary maintains
substantial independence of government
influence
Government leader: Pieter Willem
BOTHA, State President (since September
1984)
Suffrage: general suffrage limited to whites
over 18 (17 in Natal Province) and to
coloreds and Indians over 18
Elections: must be held at least every five
years; last white elections April 1981; last
colored and Indian elections August 1984;
the next white elections will be held in
first half of 1987
Political parties and leaders: White
political parties and leaders— National
Party, P. W. Botha; Progressive Federal
Party, Colin Eglin; New Republic Party,
Bill Sutton; Conservative Party, Dr. Andr-
ies P. Treurnicht; Herstigte National Party,
Jaap Marais; Colored political parties and
leaders— Labor Party, Allan Hendrickse
(majority party); People’s Congress Party,
Peter Marais; Indian political parties and
leaders—National People’s Party,
Amichand Rajbansi (majority party); Soli-
darity, J. N. Reddy
Voting strength: white parliamentary
seats—National Party, 127; Progressive
Federal Party, 27; Conservative Party, 18;
New Republic, 5; Herstigte National
Party, 1]
Communists: small Communist Party
illegal since 1950; party in exile maintains
headquarters in London, Daniel Tloome,
(Chairman) and Joe Slovo, (General Secre-
tary)
Other political groups: (insurgent groups
in exile) African National Congress (ANC),
Oliver Tambo; Pan-Africanist Congress
(PAC), Zephania Mothopeng
Member of: GATT, IAEA, IBRD, ICAO,
IDA, IFC, IHO, International Lead and
Zinc Study Group, IMF, INTELSAT, ISO,
ITU, IWC—International Whaling Com-
mission, IWC—International Wheat Coun-
cil, Southern African Customs Union, UN,
UPU, WFTU, WHO, WIPO, WMO, WSG
South Africa (continued)
(membership rights in IAEA, ICAO, ITU,
WHO, WIPO, and WMO suspended or
restricted)
Official name: Union of Soviet Socialist
Republics
Type: Communist state
Capital; Moscow
Administrative divisions: 15 union repub-
lics, consisting of 20 autonomous republics,
6 krays, 123 oblasts, 8 autonomous oblasts,
and 10 autonomous okrugs
Legal system: civil law system as modified
by Communist legal theory; revised consti-
tution adopted 1977; no judicial review of
legislative acts; has not accepted compul-
sory ICJ jurisdiction
National holiday: October Revolution
Day, 7 November
Branches: executive—USSR Council of
Ministers, legislative—USSR Supreme
Soviet, judicial—Supreme Court of USSR
Government leaders: Mikhail Sergeyevich
GORBACHEV, General Secretary of the
Central Committee of the Communist
Party (since 11 March 1985); Nikolay
Ivanovich RYZHKOV, Chairman of the
USSR Council of Ministers (since 28 Sep-
tember 1985); Andrey Andreyevich
GROMYKO, Chairman of the Presidium
of the USSR Supreme Soviet (since 2 July
1985)
Suffrage: universal over age 18; direct,
equal
Elections: to Supreme Soviet every five
years; 1,500 seats in 1984; 71.5% held by
party members
Political party: Communist Party of the
Soviet Union (CPSU) only party permitted
Voting strength: (1984 election) 99.95% of
the 197,292,000 persons over 18 voted for
Communist-sponsored single slate
Communists: over 18 million party mem-
bers
Other political or pressure groups:
Komsomol, trade unions, and other organi-
zations that facilitate Communist control
Member of: CEMA, ESCAP, Geneva
Disarmament Conference, IAEA, IBEC,
ICAC, ICAO, ICCAT, ICCO, ICES, ILO,
IMO, International Lead and Zinc Study
Group, INRO, 1IPU, ISO, iTC, 1TU,
JWC—International Whaling Commission,
1WC—international Wheat Council, UN,
UNESCO, UPU, Warsaw Pact, WFTU,
WHO, WIPO, WMO, WTO','961c07a701c77dd9def9e2f72359ee1221da71880657610e45bafda77934a54b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86facd1c5b3c578b3c71120a4bbbeec8518d44da1e515bbee58d0d12f305b7e4',1987,'NR','Nauru','government',512,'Official name: Republic of Nauru
Type: republic
Capital: no capital city as such; govern-
ment offices in Yaren District
Administrative divisions: 14 districts
National holidays: Independence Day, 31
January; Constitution Day, 17 May;
Angram Day, 26 October
Branches: President elected from and by
Parliament for an unfixed term; popularly
elected 18-member unicameral legislature
(Parliament); four-member Cabinet to
assist the President appointed by him from
Parliament members
Government leader: Hammer
DEROBURT, President (since May 1978)
Suffrage: universal adult
Elections: last held in January 1987
Political parties and leaders: governing
faction, President DeRoburt; opposition
Nauru Party, Lagumot Harris
Member of: Commonwealth (special
member), ESCAP, ICAO, INTERPOL,
ITU, South Pacific Commission, SPF, UPU','07ff9ecfef73533c08910636cd63a1e4acb942dd3f13a9d45a6de955f2d400dc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4847f5c32333481caea5f62ab1413c103bafb656b6e05b51c7d2fc09dee678e7',1987,'NP','Nepal','government',517,'Official name: Kingdom of Nepal
Type: nominally a constitutional mon-
archy; King Birendra exercises autocratic
control over multitiered panchayat system
of government
Capital: Kathmandu
Administrative divisions: 75 districts, 14
zones
Legal system: based on Hindu legal con-
cepts and English common law; has not
accepted compulsory ICJ jurisdiction
National holiday: Birthday of the King
and Nationa] Day, 28 December
Branches: Council of Ministers appointed
by the King; Rastriya Panchayat (National
Assembly; 112 directly elected, 28 ap-
pointed by King)
Government leaders: BIRENDRBA Bir
Bikram Shah Dev, King (since 1973);
Marich Man SINGH (Shrestha), Prime
Minister (since 1986)
Suffrage: universal over age 21
Elections: village, town, and district coun-
cils (panchayats) elected by universal
suffrage; a constitutional amendment in
1980 provided for direct elections to the
National Panchayat, which consists of 140
members (including 28 appointed by the
King), who serve five-year terms; Nepal’s
first general election in 22 years was held
in May 1981; general elections successfully
held in May 1986; local district elections
scheduled for Spring 1987
Nepal (continued)
Political parties and leaders: all political
parties outlawed but operate more or less
openly; Nepali Congress Party (NCP),
Ganesh Man Singh, K. P. Bhattarai, G. P.
Koirala
Communists: Communist Party of Nepal
(CPN); factions include V. B. Manandhar,
Man Mohan Adhikari, Bharat Raj Joshi,
Rai Majhi, Tulsi Lal, Krishna Raj Burma,
Sahana Pradhan
Other political or pressure groups: nu-
merous small, left-leaning student groups
in the capital; Indian merchants in Tarai
and capital; several small, radical Nepalese
antimonarchist groups operating from
north India
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, IMO, INTERPOL, 1PU,
IRC, ITU, NAM, SAARC, UN, UNESCO,
UPU, WHO, WMO, WTO','e83ddeffadafb8d2512c349be04485958d0ff3412fc4d1cdbbd25af9fa90a9e9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ef7b281111e298b93263a8cd2a65eda309a6e5226a9f2c1fb17f6eb0039c176',1987,'NL','Netherlands','government',522,'Official name: Kingdom of the Nether-
lands
Type: constitutional monarchy
Capital: Amsterdam, but government
resides at The Hague
Administrative divisions: 12 provinces
and 4 special municipalities governed by
centrally appointed commissioners of
Queen
Dependent areas: Aruba, Netherlands
Antilles
Legal system: civil law system incorporat-
ing French penal theory; constitution of
1815 frequently amended, reissued 1947;
judicial review in the Supreme Court of
legislation of lower order rather than Acts
of Parliament; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Queen''s Day, 30 April
Branches: executive (Queen and Cabinet
of Ministers), which is responsible to bi-
cameral parliament (States General) con-
sisting of a First Chamber (75 indirectly
elected members) and a Second Chamber
(150 directly elected members); indepen-
dent judiciary; coalition governments are
usual
Government leaders: BEATRIX Wilhel-
mina Armgard, Queen (since Apri! 1980);
Ruud LUBBERS, Prime Minister (since
November 1982)
Suffrage: universal over age 18
Elections: must be held at least every four
years for lower house (last held in May
1986); following an amendment to the
constitution that took effect in 1983, elec-
tions are held for the upper house every
four years (most recent August 1983)
Political parties and leaders: Christian
Democratic Appeal (CDA) Willem van
Velzen; Labor (PvdA), Marianne Sint;
Liberal (VVD), Leendert Ginjaar,; Demo-
crats 66 (D’66), Saskia van der Loo; Com-
munist (CPN), Henk Hoekstra; Pacifist
Socialist (PSP), Marko Mazeland; Political
Reformed (SGP), H. Slagboom; Reformed
Political Union (GPV), J. Blokland; Radical
Party (PPR), Janneke van der Plaat; Dem-
ocratic Socialist 70 (DS’70), Z. Hartog;
Rightist Peoples Party (RVP), Hendrik
Koekoek; Reformed Political Federation
(RPF), P. Lamgeler; Center Party (CP), H.
Janmatt; Evangelical People’s Party (EVP),
J. Renes; Party for Better Housing (PVA),
J. H. Borsboom; Roman Catholic Party of
the Netherlands (RKPN), Klaas Beuker;
Netherlands Christian Democrats (NCD),
J. A. Taex
Voting strength: (May 1986 election) CDA
54 seats, PvdA 52 seats, VVD 27 seats,
D’66 9 seats, SGP 3 seats, PPR 2 seats, PSP
1 seat, GPV 1 seat, RPF ] seat; two mem-
bers of the CDA were expelled from the
party in 1984 and are now serving as
independents
Communists: about 6,000
Other political or pressure groups: large
multinational firms; Federation of Nether-
lands Trade Union Movement (comprising
Socialist and Catholic trade unions) and a
Protestant trade union; Federation of
Catholic and Protestant Employers Associ-
ations; the nondenominational Federation
of Netherlands Enterprises; and IKV—
Interchurch Peace Council
Member of: ADB, Benelux, Council of
Europe, DAC, EC, ECE, EIB, ELDO,
EMS, ESCAP, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, ICO, IDA,
1DB—Inter-American Development Bank,
IEA, IFAD, IFC, IHO, ILO, IMF, IMO,
INRO, INTELSAT, International Lead
and Zinc Study Group, INTERPOL, IPU,
IRC, ITC, ITU, [WC—International
Wheat Council (with respect to interests of
175
the Netherlands Antilles and Suriname),
NATO, OAS (observer), OECD, UN,
UNESCO, UPU, WEU, WHO, WIPO,
WMO, WSG
Official name: Netherlands Antilles
Type: autonomous territory within King-
dom of the Netherlands
Capital; Willemstad on Curacao
Administrative divisions: three island
territories—Bonaire, Curacao, and the
Windward Islands
Legal system: based on Dutch civil law
system, with some English common law
influence; constitution adopted 1954
Branches: federal executive power rests
nominally with Governor (appointed by
the Crown); actual power exercised by
eight-member Council of Ministers or
cabinet presided over by Minister-
President; legislative power rests with
22-member Legislative Council; indepen-
dent court system under control of Chief
Justice of Supreme Court of Justice (ad-
ministrative functions under Minister of
Justice); each island territory has island
council headed by Lieutenant Governor
Government leaders: Domenico Felip
MARTINA, Prime Minister (since January
1986); Dr. Rene ROMER, Governor (since
1983)
Suffrage: universal age 18 and over
Elections: federal elections mandatorily
held every four years, last held 22 Novem-
ber 1985; island council elections every
four years, last held 22 November 1985
Political parties and leaders: political
parties are indigenous to each island:
Curacao—Movement for a New Antilles
(MAN), Domenico Felip Martina; Demo-
cratic Party (DP), Augustin Diaz; National
People’s Party (NVP), Maria Liberia-
Peters; Workers Front for Liberation
(FOL), Wilson (Papa) Godett; Social Dem-
ocratic Party (PSD), Efraim Cintje; Social
Independent Party (SI), George Hueck and
Nelson Monte; Bonaire—Popular Union
Party of Bonaire (UPB), Charles E. R.
Ellis; Democratic Party of Bonaire (PDB),
John Evert (Jopie) Abraham; New Demo-
cratic Action (ADEN); Windward Is-
lands— Windward Islands Democratic
Party (DPW), Claude Wathey; United
Federation of Antillean Workers (UFA);
Windward Islands People’s Movement
(WIPM)
Voting strength: the government of Prime
Minister Don Martina is a coalition of the
MAN and DP parties
Communists: small leftist groups
Member of: EC (associate), INTERPOL;
associated with UN through the Nether-
lands; UPU, WMO','2d54c94940ba3bc35434625678c59152138f649d8a63461d05689a22a1cd88b4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba631c20e8004a2f36716787b813345871840bacb2d694003e535fd2fc6542d4',1987,'NC','New Caledonia','government',527,'Official name: Territory of New Cal-
edonia and Dependencies
Type: French overseas territory; repre-
sented in French parliament by two depu-
ties and one senator
Capital: Nouméa
Administrative divisions: 4 islands or
island group dependencies (fle des Pins,
fles Loyauté, fle Huon, Island of New
Caledonia) and 32 municipalities
Legal system: French law
Branches: administered by High Commis-
sioner, responsible to French Ministry for
Overseas France and Council of Govern-
ment; 46-seat Territorial Assembly
Government leaders: Fernand WIBAUX,
French High Commissioner and President
of the Council of Government (since 1985);
Kanak Provisional Government—Jean-
Marie TJIBAOU, President (since Decem-
ber 1984)
Suffrage: universal
Elections: Assembly elections every five
years, last in November 1984; referendum
on New Caledonian independence sched-
uled for 1987
Political parties: white-dominated Ras-
semblement pour la Calédonie dans la
République (RPCR)}—Conservative; Melan-
esian proindependence Kanak Socialist
National Liberation Front (FLNKS); Me-
lanesian moderate Kanak Socialist Libera-
tion (LKS)
Voting strength: (1984 election) Territorial
Assembly—RPCR, 34 seats; LKS, 6 seats;
splinter groups, 2 seats; FLNKS boycotted
the election
Communists: number unknown; Palita
extreme left party; some politically active
Communists deported during 1950s; small
number of North Vietnamese
Member of: EIB (associate), WFTU,
WMO','3e8f9b50d74cfcf4d0f2849dfe691071d472b9b03e3d0cd6a429dd6e99716b39','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6a6a8c2e0d9f70c75f81070f867e5cfbc8a57a864185d474c3fa1371420845',1987,'NZ','New Zealand','government',532,'Official name: New Zealand
Type: independent state within Common-
wealth, recognizing Elizabeth II as head of
state
Capital; Wellington
Administrative divisions: 241 territorial
units (128 boroughs, 90 counties, 10 town
and district councils); 579 special-purpose
bodies
Dependent areas: Cook Islands, Niue,','5ac17a10c19b366b4ffc575055ebfaa33cc1f4b78f35197adfba9495b23a91a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526bd9b6b546a583d757ef2b781889de2d48bd931feb7267e512ace1c696d562',1987,'TK','Tokelau','government',533,'Legal system: based on English law, with
special land legislation and land courts for
Maoris; constitution consists of various
documents, including certain acts of the
UK and New Zealand Parliaments; accepts
compulsory ICJ jurisdiction, with reserva-
tions
National holiday: Waitangi Day, 6 Febru-
ary
Branches: unicameral legislature (97-
member House of Representatives, com-
monly called Parliament); Cabinet respon-
sible to Parliament; three-level court
system (magistrates and courts, Supreme
Court, and Court of Appeal)
Government leader: David LANGE,
Prime Minister (since July 1984)
Suffrage: universal age 18 and over
Elections: held at three-year intervals or
sooner if Parliament is dissolved by Prime
Minister; last election July 1984
Political parties and leaders: New
Zealand Labor Party (NZLP; government),
David Lange; National Party (NP; opposi-
tion), Jim Bolger; Democratic Party, Neil
Morrison; New Zealand Party, Steven
Greenfield; Socialist Unity Party (SUP;
pro-Soviet), Ken Douglas
Voting strength: (1984 election and one
byelection in 1985) Parliament—National
Party, 38 seats; Labor Party, 55 seats;
Democratic Party, 2 seats
Communists: SUP about 140, other sects,
about 200
Member of: ADB, ANZUS, ASPAC, Co-
lombo Plan, Commonwealth of Nations,
DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAO, ICO, IDA, IEA, IFAD, IFC, THO,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, ISO, ITU, OECD, SPF, UN,
UNESCO, UPU, WHO, WMO, WSG
Official name: Tokelau
Type: New Zealand Associated Territory;
Tokelauans are British subjects and New
Zealand citizens; administered under the
Tokelau Islands Act of 1948 as amended in
1970
Capital: no capital—each atoll has its own
administrative center
Branches: the Minister of Foreign Affairs
of New Zealand is empowered to appoint
an Administrator to the region; the powers
of the Administrator are delegated to the
Official Secretary at the Office of Tokelau
Affairs, Apia, Western Samoa
Administrative divisions: each village has
a Council of Elders (Taupulega) made up
of heads of family groups together with
the commissioner (faipule) and the mayor
(pulenuku); the commissioner administers
the law and presides over the court
Legal system: British and local statutes
National holiday: 6 February (Waitangi
Day)
Government leaders: H. H. FRANCIS,
Administrator (since February 1985); A. H.
MACEY, Official Secretary, Office of
Tokelau Affairs (since February 1985)
Suffrage: universal adult
Elections: elections for a commissioner
and a mayor from each atoll held at
three-year intervals
Communists: probably none','4a2c041c6cddbb41f3bbd91478e23630f2d7f136160db495bf2f7cf3eac4c9ee','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6896bb717d177a15e6a72a0b4da71cfa7e3bd956d67ac0cb627ba13990e3416b',1987,'NI','Nicaragua','government',539,'Official name: Republic of Nicaragua
Type: republic
Capital: Managua
Administrative divisions: 16 departments;
in 1982 the Sandinistas established six
regions and three special zones, which
both the government and the Sandinista
National Liberation Front (FSLN) increas-
ingly use for administrative purposes
Legal system: the Sandinista-appointed
Government of National Reconstruction
revoked the constitution of 1974 and
issued a Fundamental Statute and a Pro-
gram of the Government of National
Reconstruction, which guided its actions
unti! the new constitution was promul-
gated in January 1987
National holiday: Independence Day, 15
September; Anniversary of the Revolution,
19 July
180
Branches: executive and administrative
responsibility formally reside in the Presi-
dent, Vice President, and Cabinet; in
reality, the nine-member National Direc-
torate of the Sandinista National Libera-
tion Front (FSLN) shares power with and
dominates the executive; National Assem-
bly was elected in November 1984 and
inaugurated in January 1985; the country’s
highest judicial authority is the Sandinista-
appointed Supreme Court, composed of
seven members
Government leaders: Cdte. (José) Daniel
ORTEGA Saavedra, President (since 10
January 1985); Sergio RAMIREZ Mercado,
Vice President (since 10 January 1985)
Elections: national elections were held on
4 November 1984 for president and vice
president (elected for a six-year term), and
a 96-member National Assembly
Political parties and leaders: Sandinista
National Liberation Front (FSLN) is the
ruling party and dominates political life;
the FSLN has 61 seats in the National
Assembly; government prohibited most
political activities by opposition parties
under the state of emergency in March
1982, expanded the emergency decree in
October 1985, and reimposed the state of
emergency in January 1987; main opposi-
tion parties boycotted the November 1984
elections on the grounds that the regime
had not provided them with sufficient
political guarantees; democratic opposition
parties are highly fragmented and include
Social Democratic Party (PSD), leadership
undecided; Social Christian Party (PSC),
Erick Ramirez; Democratic Conservative
Party of Nicaragua (PCDN), split into
factions—the most influential leaders are
Mario Rappaccioli and Myriam Arguello;
Constitutionalist Liberal Party (PLC),
Alfredo Reyes Duque Estrada; Indepen-
dent Liberal Party (PLI), Virgilio Godoy;
Popular Social Christian Party (PPSC),
Mauricio Diaz; and Democratic Conserva-
tive Party (PCD), split into factions—most
influential leader Rafael Cordova Rivas;
the PSD, PSC, PCDN and PLC, as well as
opposition business and union organiza-
tions, form the Democratic Coordinating
Board—Eduardo Rivas Gasteazoro, presi-
dent; the PPSC and PLI were allied with
the FSLN in the Patriotic Front of the
Revolution (FPR) until early 1984 but
fielded their own candidates in the elec-
tions; a pro-FSLN faction dominates the
PCD; the PCD has 14 seats in the National
Assembly, the PLI 9, and the PPSC 6; two
additional relatively obscure parties, the
Central American Unionist Party (PUCA)
and the Revolutionary Party of the Work-
ers (PRT), were founded in late 1984; a
third obscure party, the Liberal Party
(PALI, was founded in 1986
Communists: the Nicaraguan Socialist
Party (PSN), Gustavo Tablada, founded in
1944, has served as Nicaragua’s Moscow-
line Communist party; the Communist
Party of Nicaragua (PCdeN), Eli Altamir-
ano Pérez, is an ultraleft breakaway fac-
tion from the PSN; and the Popular Action
Movement—Marxist-Leninist (MAP-ML),
Isidro Téllez; only the PSN was a member
of the FPR alliance with the FSLN, but all
three have supported the revolution; the
PCdeN and MAP-ML have criticized the
Sandinistas for moving too slowly toward
consolidation of a Marxist-Leninist regime;
each of the three Communist parties has
two seats in the National Assembly
Other political or pressure groups: the
Superior Council of Private Enterprise
(COSEP) is an umbrella group comprising
11 different chambers of associations,
including such groups as the Chamber of
Commerce, the Chamber of Industry, and
the Nicaraguan Development Institute
~ (INDE)
Member of: CACM, CEMA (observer),
FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB—Inter-
American Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IPU, IRC, ISO, ITU, NAM, OAS, ODECA,
PAHO, SELA, UN, UNESCO, UPEB,
UPU, WFTU, WHO, WMO, WTO','cef70d267c3ea7fa7a8c9ffa44905b71d6beaddac91ed34b5362da7463cd70be','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb60849a1127a711bcb3cc3dab51e6c21b1773ed6d12d7b2a67eeb377eb072d',1987,'NE','Niger','government',544,'Official name: Republic of Niger
Type: republic; military regime in power
since April 1974
Capital: Niamey
Administrative divisions: 7 departments,
88 arrondissements
Legal system: based on French civil law
system and customary law; constitution
adopted 1960, suspended 1974; committee
appointed January 1984 to reflect on a
new national charter; has not accepted
compulsory ICJ jurisdiction
National holidays: Independence Day, 3
August; Republic Day, 18 December
Branches: executive authority exercised by
President Seyni Kountché in the name of
the Supreme Military Council (SMC),
which is composed of army officers; office
of prime minister created January 1983;
since November 1983, civilians have held
all cabinet portfolios except Defense and
Interior, which are held by President
Kountché
Government leaders: Brig. Gen. Seyni
KOUNTCHE, President of Supreme
Military Council, Chief of State (since
1974); Hamid ALGABID, Prime Minister
(since November 1983)
Suffrage: universal adult
Elections: popular elections currently
allowed only for choosing representatives
for village Development Councils, which
advise on local economic development
Political parties and leaders: political
parties banned
Communists: no Communist party; some
sympathizers in outlawed Sawaba party
Member of: AfDB, APC, CEAO, EAMA,
ECA, ECOWAS, Entente, FAO, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
182
ILO, IMF, INTELSAT, INTERPOL, IPU,
ITU, Lake Chad Basin Commission, Niger
River Commission, NAM, OAU, OCAM,
OIC, UN, UNESCO, UPU, WHO, WIPO,
WMO','41d64f162781362e0568f410256d19b66ea221546f2078cd24ab1c2379db068a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07bad71a01df25ca899711dc3c50261bb5c37d4c9de25cb5a8d742c0fe8c9d0c',1987,'NG','Nigeria','government',547,'Type: military government since 31 De-
cember 1983
Capital: Lagos
Administrative divisions: 19 states with
appointed military governors
Legal system: based on English common
law and Islamic and tribal law
National holiday: Independence Day, 1
October
Branches: Armed Forces Ruling Council;
National Council of Ministers and National
Council of States; judiciary headed by
Supreme Court
Government leader: Ibrahim BABAN-
GIDA, President and Commander in Chief
of Armed Forces (since August 1985)
Suffrage: none
Elections: last national elections under
civilian rule held August-September 1983
Political parties and leaders: all political
parties banned after 31 December 1983
Nigeria (continued)
Communists: the pro-Communist under-
ground comprises a fraction of the small
Nigerian left; leftist leaders are prominent
in the country’s central labor organization
but have little influence on government
Member of: Af{DB, APC, Commonwealth,
ECA, ECOWAS, FAO, G-77, GATT,
IAEA, IBRD, ICAO, ICO, IDA, IFAD,
IFC, ILO, IMO, IMF, INTELSAT,
INTERPOL, IRC, ISO, ITC, ITU, IWC—
International Wheat Council, Lake Chad
Basin Commission, Niger River Commis-
sion, NAM, OAU, OPEC, UN, UNESCO,
UPU, WHO, WMO, WTO','0e6a8a5242e998d14ba936051e19f780c6edf5730dc03c5a574f0a13193ec9e6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c77708cfc29831585a77954907af072a7043e5b9532bf32d07d55f7bb20303fb',1987,'NU','Niue','government',552,'Official name: Niue
Type: (since 1974) self-governing territory
in free association with New Zealand;
Niueans retain New Zealand citizenship
Capital: Alofi
Administrative divisions: 14 village coun-
cils
Legal system: English common law
Branches: Executive consists of a Cabinet
of four members—the Premier (elected by
the Assembly) and three ministers (chosen
by the Premier from among Assembly
members); Legislative Assembly consists of
20 members (14 village representatives and
6 elected on a common roll); if requested
by the Assembly, New Zealand will also
legislate for the island
Government leaders: Sir Robert R. REX,
Premier (since early 1950s); John SPRING-
FORD, New Zealand Representative (since
1974)
Suffrage: universal adult
Elections: every three years; last election
held March 1984
Member of: ESCAP (associate member),
SPF','02d8e4fe3a57b9b1e011cc1523eac81063c5520d80a96d4cbccd8eec8e92e00a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bf27d2fa26a8ed25efc162e2758eb332ac2956bd3d80e4024a90010f2c24f63',1987,'NF','Norfolk Island','government',557,'Official name: Territory of Norfolk Island
Type: Australian territory
Capital: Kingston (administrative center),
Burnt Pine (commercial center)
Legal system: wide legislative and execu-
tive responsibility under the Norfolk Island
Act of 1979; Supreme Court
National holiday: Pitcairners Arrival Day
Anniversary, 8 June
Branches: 9-member elected Legislative
Assembly; chief executive is Australian
administrator named by governor general
Government leader: David E. BUFFETT,
Chief Minister (since 1983)
Suffrage: proportional representation; all
persons born on the island are Australian
citizens
Elections: last held 18 May 1983; every
three years','09bd36c97a22405b1f45413fbdd468a1d28f4b97fdc9382890762cb630f81bd8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef469ee34703e988992982bfcc1ec387e004cafe2a1d98e9847163205962ced7',1987,'PK','Pakistan','government',565,'Type: parliamentary with strong executive,
federal republic
Capital: Islamabad
Administrative divisions: four provinces
(Baluchistan, North-West Frontier, Punjab,
Sind) and 1 territory (Federally Adminis-
tered Tribal Areas)
Legal system: based on English common
law but gradually being transformed to
correspond to Koranic injunction; accepts
compulsory ICJ jurisdiction, with reserva-
tions; President Zia’s government has
established Islamic Sharia courts parallel-
ing the secular courts and has introduced
Koranic punishments for criminal offenses;
martial law courts abolished 30 December
1985, and all cases, including those con-
cerning national security, now require due
process
National holiday: Pakistan Day, 23 March
Government leaders: Gen. Mohammed
ZIA-UL-HAQ, President and Army Chief
of Staff (since July 1977); confirmed as
President through March 1990 in special
referendum in December 1984; Moham-
med Khan JUNEJO, Prime Minister (since
March 1985)
Suffrage: universal from age 18
Elections: opposition agitation against
rigging elections in March 1977 led to
military coup; military promised to hold
new national and provincial assembly
elections in October 1977 but postponed
them indefinitely; elections for municipal
bodies were held in 1979 and 1983;
nonparty national elections were held in
February 1985; many outlawed political
parties boycotted polling
Political parties and leaders: relegalized
in December 1985 under legislation re-
quiring parties to register and open books
for inspection; government still has wide
authority under civil code to restrict
political activity; law requires disqualifica-
tion of any parliamentary delegate who
changes party affiliation; majority party in
parliament is Pakistan Muslim League
(PML), Mohammed Khan Juneio; principal
opposition party is the secular socialist
Pakistan People’s Party (PPP), Benazir
Bhutto (major leader); others include
National Democratic Party (NDP), Sherbaz
Mazari and the Awami National Party
(ANP), Abdul Wali Khan; all the afore-
mentioned are in the Movement for Resto-
ration of Democracy (MRD), formed in
February 1981; Pakistan National Party
(PNP), Ghaus Bakhsh Bizenjo (Baluch
elements of the former NAP); Tehrik-i-
Istiqlal, Asghar Khan; Jamiat-ul-Ulema-i-
Islam (JUD, Fazlur Rahman; National
People’s Party (NPP), Ghulam Mustapha
Jatoi
Communists: party is outlawed, member-
ship very small; sympathizers estimated at
several thousand
Other political or pressure groups: mili-
tary remains dominant political force;
Ulema (clergy), industrialists, and small
merchants also influential
Member of: ADB, Colombo Plan, ESCAP,
FAO, G-77, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITU,
IWC—International Wheat Council,
NAM, OIC, Economic Cooperation Orga-
190
nization, SAARC, UN, UNESCO, UPU,
WHO, WFTU, WIPO, WMO, WSG,
WTO','b891d04ad3a04aeb5f360671829b7c4ba6ccf121278af8b8c92d96685ed07f3e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f54c4de909cf7fbbcf2d3f02818550079e21dea180c235c5fc2a431b8085e1',1987,'PA','Panama','government',570,'Official name: Republic of Panama
Type: centralized republic
Capital: Panama
Administrative divisions: 9 provinces, |
comarca
Legal system: based on civil law system;
constitution adopted in 1972, but major
reforms adopted in April 1983; judicial
review of legislative acts in the Supreme
Court; accepts compulsory 1CJ jurisdiction,
with reservations
National holiday: Independence Day, 3
November
Branches: under April 1983 reforms, a
President, two Vice Presidents, and a
67-member Legislative Assembly are
elected by popular vote for five-year
terms; nine Supreme Court Justices and
nine alternates serve 10-year terms; two
justices and their alternates are replaced
every other December by presidential
nomination and legislative confirmation
Government leaders: Eric Arturo
DELVALLE Henriquez, President (since
September 1985); Roderick ESQUIVEL,
First Vice President (since October 1985);
Second Vice President, unfilled
Panama (continued)
Suffrage 18: universal and compulsory
over age 18
Elections: seven electoral slates made up
of 14 registered political parties were on
the May 1984 ballot with the president
and other winners decided by simple
pluralities; mayoral and municipal elec-
tions were held in June 1984
Political parties and leaders: (registered
for 1984 presidential and legislative elec-
tions) National Democratic Union
(UNADE; government coalition—Demo-
cratic Revolutionary Party (PRD, official
government party), Romulo Escobar Be-
thancourt, Carlos Ozores Typaldos; Repub-
lican Party (PR), Eric Arturo Devalle
Henriquez; Liberal Party (PL), Roderick
Lorenzo Esquivel; Labor Party (PALA),
Ramén Sieiro Murgas and Carlos Eleta
Almardan; Panamenista Party (PP), Luis
Suarez; Popular Broad Front Party (FR-
AMPO), Alvaro Arosemena; Democratic
Opposition Alliance (ADO, opposition)—
Christian Democratic Party (PDC), Ri-
cardo Arias Calderon; Authentic Paname-
nista Party (PPA), Arnulfo Arias Madrid;
Nationalist Republican Liberal Movement
(MOLIRENA), Alfredo Ramirez, Sr.; other
opposition parties—Popular Nationalist
Party (PNP), Olimpo A. Saez Maruci;
Popular Action Party (PAPO), Carlos Ivan
Zuniga; People’s Party (PdP, Soviet-
oriented Communist), Rubén Dario Sousa
Batista; Socialist Workers Party (PST), José
Cambra; Revolutionary Workers Party
(PRT), Graciela Dixon
Voting strength: in the May 1984 elections
the government coalition received 800,748
votes, narrowly defeating the opposition
alliance, which received 299,035 votes;
UNADE won 45 seats in the 67-member
Legislative Assembly, and ADO won the
remaining 22 seats
Communists: People’s Party (PdP), pro-
government mainline Communist party,
did not obtain the necessary three percent
of the total vote in 1984 elections to retain
its legal status; about 3,000 members
Other political or pressure groups: Na-
tional Council of Organized Workers
(CONATO); National Council of Private
Enterprise (CONEP); Panamanian Associa-
tion of Business Executives (APEDE)
Member of: FAO, G-77, IADB, IAEA,
IBRD, ICAO, ICO, IDA, IFAD, IDB—
Inter-American Development Bank, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
IRC, ITU, 1WC—International Whaling
Commission, 1WC—International Wheat
Council, NAM, OAS, PAHO, SELA, UN,
UNESCO, UPEB, UPU, WFTU, WHO,
WMO, WTO','7b58eb46f0271b572f984176a567f0d9b9a50862819d807924ee41ad9f08d906','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfe7c5ebdd4f593eddccbf49f8ca5369c707b69bf623d9b6734ceef604fe6cfb',1987,'PG','Papua New Guinea','government',575,'Official name: Independent State of
Type: independent parliamentary state
within Commonwealth recognizing Eliza-
beth II as head of state
Capital: Port Moresby
Administrative divisions: 20 provinces
Legal system: based on English common
law
National holiday: Independence Day, 16
September
Branches: executive—National Executive
Council; legislature—House of Assembly
(109 members); judiciary—court system
consists of Supreme Court of Papua New
Guinea and various inferior courts (district
courts, local courts, children’s courts,
wardens’ courts)
Government leaders: Sir Kingsford
DIBELA, Governor General (since March
1983); Paias WINGTI, Prime Minister
(since November 1985)
Suffrage: universal adult
Elections: preferential-type elections for
109-member House of Assembly every five
years, last held in June 1982
Political parties: Pangu Party, People’s
Progress Party, United Party, Papua Be-
sena, National Party, Melanesian Alliance
Communists: no significant strength
193
Member of: ADB, ANRPC, CIPEC (asso-
ciate), Commonwealth, ESCAP, FAO,
G-77, GATT (de facto), IBRD, ICAO,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ITU, South
Pacific Commission, SPF, UN, UNESCO,
UPU, WHO, WMO','840483f7c6d205ffcfb0b93b5348666e9dde32011f9d495ff61084ad149422a9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6029329ba24661b2141e9d53fc250dbbe6277f15883dd2fccb007c5559111496',1987,'PY','Paraguay','government',580,'Official name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncién
Administrative divisions: 19 departments
and the national capital
Legal system: based on Argentine codes,
Roman law, and French codes; constitu-
tion promulgated 1967; judicial review of
legislative acts in Supreme Court; does not
accept compulsory ICJ jurisdiction
National holiday: Independence Day, 14
May
Branches: President heads executive;
bicameral legislature (Senate, Chamber of
Deputies); judiciary headed by Supreme
Court
Government leader: Gen. (Ret.) Alfredo
STROESSNER, President (since May 1954)
Suffrage: universal; compulsory between
ages of 18 and 60
Elections: President and Congress elected
at same time every five years (next elec-
tion March 1988)
Political parties and leaders: Colorado
Party, Juan Ramén Chaves; Authentic
Radical Liberal Party (PLRA), Juan
Zaldivar; Christian Democratic Party
(PDC), Geronimo Irala Burgos; Febrerista
Revolutionary Party (PRF), Fernando
Vera; Liberal Party (PL), Joaquin Burgos;
Popular Colorado Movement (MOPOCO),
Waldino Lovera; Radical Liberal Party
(PLR), Emilio Forestieri
Voting strength: (February 1983 general
election) 90% Colorado Party, 5.6% Radi-
cal Liberal Party, 3.2% Liberal Party;
Febrerista Party boycotted elections
Communists: Oscar Creydt faction and
Miguel Angel Soler faction (both illegal);
est. 8,000 to 4,000 party members and
sympathizers in Paraguay, very few are
hard core; party in exile is small and
deeply divided
Other political or pressure groups: Na-
tional Accord includes MoPoCo and
Febrerista, Radical Liberal, and Christian
Democratic Parties; Gaspar Rodriguez de
Francia, Paraguayan Liberation Movement
Member of: FAO, G-77, IADB, IAEA,
IBRD, ICAO, ICO, IDA, 1DB—Inter-
American Development Bank, IFAD, IFC,
1LO, IMF, INTELSAT, INTERPOL, I1PU,
IRC, ITU, LAJA, OAS, SELA, UN,
UNESCO, UPU, WHO, WMO, WSG','80a6767ad9e4e8f6c334a70bbf2f6ed9b8c7fadcbb58442fe35478bd88b323bb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad976b915b88c00ab8fb7f927b8d19bf27be5213b5d717825498399813ee00d',1987,'PE','Peru','government',585,'Official name: Republic of Peru
Type: republic
Capital: Lima
Administrative divisions: 24 departments
with limited autonomy plus constitutional
Province of Callao
Legal system: based on civil law system;
1979 constitution reestablished civilian
government with a popularly elected
president and bicameral legislature; has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 28
July
Branches: executive, judicial, bicameral
legislature (Senate, Chamber of Deputies)
Government leaders: Alan GARCIA
Pérez, President (since July 1985); Luis
ALVA Castro, Prime Minister (since July
1985)
Suffrage: universal over age 18
Elections: elections for president and
congress held every five years; last election
for president and congress held 14 April
1985; current government inaugurated 28
July 1985
Political parties and leaders: American
Popular Revolutionary Alliance
(APRA), Alan Garcia; United Left (IU),
Alfonso Barrantes; Popular Christian Party
(PPC), Luis Bedoya Reyes; Popular Action
Party (AP), Fernando Belatnde Terry
Voting strength: (1985 presidential elec-
tion) 48% APRA, 23% 1U, 14% PPC, 5%
AP
Communists: Peruvian Communist Party-
Unity (PCP-U), pro-Soviet, 2,000; other
minor Communist parties
Member of: Andean Pact, AIOEC,
ASSIMER, CIPEC, FAO, G-77, GATT,
IADB, IAEA, IATP, IBRD, ICAO, ICO,
IDA, IDB—Inter-American Development
Bank, IFAD, IFC, 1LO, INTERPOL, IMF,
IMO, INTELSAT, International Lead and
Zinc Study Group, ISO, ITU, IWC—
International Wheat Council, LAIA, NAM,
OAS, PAHO, SELA, UN, UNESCO, UPU,
WFTU, WHO, WMO, WSG, WTO','8ba4b8bf9861f787c1bcaa32ffa9065b2c22d3cbefbbc1b19185055ec5f70b70','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('002600fec59c900763df3ae1abee95c4eb3c4eb2ad1236cbbc6209e8418c8cca',1987,'PH','Philippines','government',590,'Official name: Republic of the Philippines
Type: republic
Capital; Manila (de facto), Quezon City
(designated)
Administrative divisions: 73 provinces
and 61 chartered cities
Legal system: based on Spanish, Islamic,
and Anglo-American law; new constitution
passed 1987; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day
Branches: constitution provides for a
bicameral legislature and a presidential
form of government with a directly
elected President and Vice President;
judicial branch headed by Supreme Court
with descending authority in a three-tiered
system of local, regional trial, and interme-
diate appellate courts
Government leaders: Corazon AQUINO,
President (since February 1986); Salvador
LAUREL, Vice President and Foreign
Minister (since February 1986)
Suffrage: universal and compulsory
197
Elections: presidential election held on 7
February 1986; Ferdinand Marcos initially
declared winner; following civil unrest and
military rebellion, he left office and
Aquino assumed presidency; legislative
elections scheduled for May 1987, with
local elections to follow in August
Political parties: national parties are
PDP-Laban; United Nationalist Demo-
cratic Organization (UNIDO), Liberals,
Nacionalistas; Partido Ng Bayan (PNB)
Communists: the Communist Party of the
Philippines (CPP) controls about 23,200
full-time insurgents; not recognized as
legal party; a second Communist party,
the pro-Soviet Philippine Communist
Party (PKP), has quasi-legal status
Member of: ADB, ASEAN, ASPAC, Co-
lombo Plan, ESCAP, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFAD, IFC,
1HO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ISO, ITU, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO
Official name: Pitcairn, Henderson, Ducie,
and Oeno Islands
Type: British dependent territory
Capital; Adamstown
Legal system: Island Court; provisions for
a Supreme Court
Branches: administered locally by Island
Council consisting of four elected island
officers, a secretary, and five nominated
members
Government leaders: Terence D.
O’LEARY, Governor and UK High Com-
missioner to New Zealand (since 1982); B.
YOUNG, Island Magistrate and Chairman
of the Island Council (since 1985)
Suffrage: 18 years old and 3 years resi-
dency
Elections: annual; Island Magistrate
elected for a 3-year term
Communists: none','651ea65b223acef7de79d7ea80617e6f0f237b97bbb717cd5e0c5bbd8db24110','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12dc6721e28ad91187b29a44626ec339b886bbcb9d63864efec0754f3d4cb201',1987,'PT','Portugal','government',597,'Official name: Portuguese Republic
Type: republic
Capital: Lisbon
Administrative divisions: 18 districts on
the mainland, 3 in the Azores, 1 in the
Madeira Islands
Dependent area: Macau
Legal system: civil law system; constitu-
tion adopted April 1976 and revised Octo-
ber 1982; next round of discussions on
constitutional revision slated for October
1987; the Constitutional Tribunal reviews
the constitutionality of legislation; accepts
compulsory ICJ jurisdiction, with reserva-
tions
National holiday: 25 April
Branches: executive with President and
Prime Minister; unicameral legislature
(popularly elected 250-seat Assembly of
the Republic); independent judiciary
Government leaders: Mario SOARES,
President since (February 1986), Anibal
Cavaco SILVA, Prime Minister (since
October 1985)
Suffrage: universal over age 18
Elections: national elections for Assembly
of the Republic normally to be held every
four years; Assembly elections held Octo-
ber 1985; national election for President to
be held every five years (last held January-
February 1986); local elections to be held
every three years (last held December
1985)
Political parties and leaders: Social Dem-
ocratic Party (PSD), Anibal Cavaco Silva;
Portuguese Socialist Party (PS), Vitor
Constancio; Party of Democratic Renewal
(PRD), Antonio Ramalho Eanes; Portu-
guese Communist Party (PCP), Alvaro
Cunhal; Social Democratic Center (CDS),
Adriano Moreira
Voting strength: (1985 parliamentary
election) Social Democrats, 29.87%; Social-
ists, 20.77%; Democratic Renewal, 17.92%;
Communists (in a front coalition called the
United Peoples Alliance—APU), 15.49%;
Center Democrats, 9.6%
Communists: Portuguese Communist
Party claims membership of 200,753
(December 1983)
Member of: Council of Europe, EC,
EFTA, FAO, GATT, IAEA, IATP, IBRD,
ICAC, ICAO, ICES, ICO, 1DB—Inter-
American Development Bank, IEA, IFAD,
IFC, IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOOC, IRC, 1SO, ITU,
IWC—International Wheat Council,
NATO, OECD, UN, UNESCO, UPU,
WHO, WIPO, WMO, WSG','e9857c3ed1ad04af11d9a8dfdc8be5d0e14d6c86692acd0b11ee621fb5732b72','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('588033d1f79e4852f14e4243608ec51102349a5f9e2a7c4b4b596cdda81d19ba',1987,'QA','Qatar','government',602,'Official name: State of Qatar
Type: traditional monarchy; independence
declared in 1971
Capital: Doha
Legal system: discretionary system of law
controlled by the ruler, although civil
codes are being implemented; Islamic law
is significant in personal matters; a consti-
tution was promulgated in 1970
National holiday: Independence Day, 3
September
Branches: executive—Amir and Council
of Ministers; legislature—State Advisory
Council
Government leader: Khalifa bin Hamad
Al THANI, Amir and Prime Minister
(since February 1972)
Suffrage: no specific provisions for suffrage
laid down
Elections: constitution calls for elections
for part of State Advisory Council, a
consultative body, but no elections have
been held
Political parties and leaders: none
Other political or pressure groups: a few
small clandestine organizations
Member of: Arab League, FAO, G-77,
GATT (de facto), GCC, IBRD, ICAO,
1DB—Islamic Development Bank, IFAD,
1LO, IMF, IMO, INTELSAT, INTERPOL,
ITU, NAM, OAPEC, OIC, OPEC, UN,
UNESCO, UPU, WHO, WIPO, WMO
Official name: Department of Reunion
Type: overseas department of France;
represented in French Parliament by three
deputies and two senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a
Prefect appointed by the French Minister
of Interior, assisted by a Secretary General
and an elected 36-man General Council;
in 1974 France created an elected 45-
member Regional Assembly to coordinate
economic and social development policies;
in 1981 both the General Council and the
Regional Assembly received greater au-
thority for fiscal policy
Government leader: Jean Anciaux, Com-
missioner of the Republic
Suffrage: universal adult
Elections: last municipal and General
Council elections in 1983; parliamentary
election June 1981; Regional Assembly
election February 1983
Political parties and leaders: Reunion
Communist Party (RCP), Paul Verges;
Popular Movement for the Liberation of
Reunion, Georges Sinamale; other political
candidates affiliated with metropolitan
French parties, which do not maintain
permanent organizations on Reunion
Voting strength: (parliamentary election
1981) Union for French Democracy—
Rally for the Republic coalition elected
two deputies; the Socialists elected one; in
the 1983 Regional Assembly election,
leftist parties received 45.7% of the vote
Communists: Communist Party small but
has support among sugarcane cutters and
the minuscule Popular Movement for the
Liberation of Reunion (MPLR) and in Le
Port District
Member of: WFTU','701de71cb3d2d366024bf215a264d38c78841f902d07762e9767f46ec564d0f1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d53df1e27d8de64471b6f4aa927ed2c1f80fbfaba752e233841d3d709ab3ba0',1987,'RO','Romania','government',607,'Official name: Socialist Republic of Roma-
nia
Type: Communist state
Capital: Bucharest
Administrative divisions: 40 counties; city
of Bucharest has administrative status
equal to a county
Legal system: mixture of civil law system
and Communist legal theory that increas-
ingly reflects Romanian traditions; consti-
tution adopted 1965; has not accepted
compulsory I1CJ jurisdiction
National holiday: Liberation Day, 23
August
Branches: Presidency; Council of Minis-
ters; Grand National Assembly, under
which is Office of Prosecutor General and
Supreme Court; Council of State
Government leaders: Nicolae
CEAUSESCU, President of the Socialist
Republic (head of state; since 1967); Const-
antin DASCALESCU, Prime Minister
(since May 1982)
Suffrage: universal and compulsory over
age 18
Elections: elections held every five years
for Grand National Assembly deputies and
local people’s councils; last election held
March 1985
205
Political parties and leaders: Communist
Party of Romania only functioning party,
Nicolae Ceausescu, Secretary General
(since March 1965)
Voting strength: (1985 election) overall
participation reached 99.99%; of those
registered to vote (15,733,060), 97.73%
voted for party candidates
Communists: 3,400,000 (November 1984)
Member of: CEMA, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IFAD, ILO, IMF,
IMO, INTERPOL, IPU, ITC, ITU, UN,
UNESCO, UPU, Warsaw Pact, WFTU,
WHO, WIPO, WMO, WTO','a009575c5cbe88076ca655fdb69f5ccd9f2bdbf6d9024a661db35d98dfc3f06d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('746ef05ad382f873e684f573ac41b1892b676782ac0104765a6ac0ecce373d27',1987,'RW','Rwanda','government',611,'Official name: Republic of Rwanda
Type: republic; presidential system in
which military leaders hold key offices
Capital: Kigali
Administrative divisions: 10 prefectures,
subdivided into 143 communes
Legal system: based on German and
Belgian civil law systems and customary
law; judicial review of legislative acts in
the Supreme Court; has not accepted
compulsory ICJ jurisdiction
National holiday: National Day, 1 July
Branches: executive (President,
16-member Cabinet); unicameral legisla-
tive (National Development Council);
judiciary (4 senior courts, magistrates)
Government leader: Maj. Gen. Juvénal
HABYARIMANA, President and Head of
State (since 1973)
Suffrage: universal adult
Elections: national elections, including
constitutional referendum and presidential
plebiscite, held December 1978; National
Development Council elected and Presi-
dent reelected in December 1983
Political parties and leaders: National
Revolutionary Movement for Development
(MRND), General Habyarimana (officially
a development movement, not a party)
Communists: no Communist party
Member of: AfDB, EAMA, FAO, G-77,
GATT, IBRD, ICAO, ICO, IDA, IFAD,
IFC, ILO, IMF, INTERPOL, IPU, ITU,
NAM, OAU, OCAM, UN, UNESCO,
UPU, WHO, WMO, WTO','23bf6a8577a9c7b6bb12792dcb3e0fa7bb771109d374b1c961fbad9c265381a8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df3428a03f7baa22671a59926b6cd88303b558f3f2fa81f4df6ef70c186eef3c',1987,'SM','San Marino','government',616,'Official name: Republic of San Marino
Type: republic
Capital: San Marino
Administrative divisions: San Marino is
divided into 9 castles—Acquaviva, Borgo
Maggiore, Chiesanuova, Domagnano,
Faetano, Fiorentino, Monte Giardino, San
Marino, Serravalle
Legal system: based on civil law system
with Italian law influences; electoral law of
1926 serves some of the functions of a
constitution; has not accepted compulsory
IC] jurisdiction
National holiday: Anniversary of the
Liberation of the Republic, 5 February
Branches: the Grand and General Council
is the legislative body elected by popular
vote; its 60 members serve five-year terms;
Council in turn elects two Captains-Regent
who exercise executive power for term of
six months, the Congress of State whose
members head government administrative
departments, and the Council of Twelve,
the supreme judicial body; actual execu-
tive power is wielded by the Secretary of
State for Foreign Affairs and the Secretary
of State for Internal Affairs
Government leaders: Gabriele GATTI
(Christian Democrat), Secretary of State
for Foreign and Political Affairs and for
Information (since July 1986); Alvaro
SELVA (Communist), Secretary of State
for Internal Affairs and Justice (since July
1978); Gabriele GATTI (Christian Demo-
crat), Secretary of State for Budget, Fi-
nance, and Planning (since July 1986)
Suffrage: universal (since 1960)
Elections: elections to the Grand and
General Council required at least every
five years; last election was held 29 May
1983
Political parties and leaders: Christian
Democratic Party (DCS), Clara Boscaglia;
Social Democratic Party (PSDS), Alvaro
Casali; Socialist Party (PSS), Remy Gi-
acomini; Communist Party (PCS), Gilberto
Ghiotti; Unitary Socialist Party (PSU),
Emilio Della Balda; Committee for the
Defense of the Republic (CDR), leader
unknown
Voting strength: (1983 election) 42.1%
DCS, 24.4% PCS, 14.8% PSS, 13.9% PSU,
2.9% PSDS
Communists: about 300 members; the
PCS, in conjunction with the PSS, PSU,
and PSDS, has led the government since
1978
Other political parties or pressure
groups: political parties influenced by
policies of their counterparts in Italy
Member of: ICJ, International Institute for
Unification of Private Law, International
Relief Union, ITU, IRC, UNESCO, UPU,
WFTU, WHO, WTO; observer status in
NAM','f0d3cbd71f66bb4be865c360f8e285e138a5f5ed5f0e9203ce95da83c256ac90','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e5d7625c0c84e300c0ea1fb6263a8ba0d722c8a0dc4de3775c3e328feefaeb',1987,'ST','Sao Tome and Principe','government',619,'Type: republic
Capital: Sio Tomé
Administrative divisions: seven counties
Legal system: based on Portuguese law
system and customary law; constitution
adopted December 1975 and approved by
National People’s Assembly on 15 Decem-
ber 1982; has not accepted compulsory 1CJ
jurisdiction
National holidays: Martyr''s Day, 4 Febru-
ary; Independence Day, 12 July; Armed
Forces Day, first week in September
(varies); Farmer’s Day, 30 September
Branches: President heads the government
assisted by a cabinet of ministers; unicam-
eral legislature (elected National People’s
Assembly)
Government leader: Dr. Manuel Pinto DA
COSTA, President (since 1975)
Suffrage: universal for age 18 and over
Elections: da Costa reelected by Popular
Assembly May 1980 and September 1985;
Assembly elections in August and Septem-
ber 1985
Political parties and leaders: Movement
for the Liberation of Sao Tome and Prin-
cipe (MLSTP), Manuel Pinto da Costa
Communists: no Communist party, proba-
bly a few sympathizers
Member of; AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IDA, IFAD, IFC,
ILO, IMF, 1TU, NAM, OAU, UN,
UNESCO, UPU, WHO, WMO','102648ff7f22fc7ef5b79290755bee120f98feaed1717667270dfbc37e39126d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f786fd8d1c4e0f38d979f2b4a0fab4cf40302c0acdc70af7074f5f8e8a020c67',1987,'SA','Saudi Arabia','government',623,'Official name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh
Administrative divisions: 14 provinces
Legal system: based on Islamic law, sev-
eral secular codes have been introduced;
commercial disputes handled by special
committees; has not accepted compulsory
ICJ jurisdiction
National holiday: 23 September
Branches: King rules in consultation with
royal family and Council of Ministers
Government leader: FAHD bin ‘Abd
al-‘Aziz Al] Sa‘ud, King and Prime Minister
(since 1982)
Communists: negligible
Member of: Arab League, FAO, G-77,
GCC, 1AEA, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, International
Maritime Satellite Organization,
INTERPOL, ITU, [WC—International
Wheat Council, NAM, OAPEC, OIC,
OPEC, UN, UNESCO, UPU, WHO,
WMO
Officia] name: People’s Democratic Re-
public of Yemen
Type: republic
Capital: Aden
Administrative divisions: six governorates
Legal system: based on Islamic law (for
personal matters) and English common law
(for commercial matters); highest judicial
organ, Federal High Court, interprets
constitution and determines disputes
between states
National holiday: 14 October
Branches: unicameral legislature (People’s
Assembly); Supreme Cabinet
Government leaders: Haydar Abu Bakr
al-‘ATTAS, Chairman, Presidium, Su-
preme People’s Council (since February
1986); ‘Ali Salim al-BID, Secretary Gen-
eral, Yemeni Socialist Party (since Febru-
ary 1986); Yasin Sa‘id NU‘MAN, Chair-
man, Council of Ministers (since February
1986)
Suffrage: all citizens age 18 and over
Elections: elections for legislative body
and Supreme People’s Council are called
for in the constitution, but none have been
held
Political parties and leaders: Yemeni
Socialist Party (YSP), the only legal party,
is a coalition of National Front, Ba‘th, and
Communist Parties
Communists: no information
Member of: Arab League, FAO, G-77,
GATT (de facto), IBRD, ICAO, IDA,
IDB—Islamic Development Bank, IFAD,
ILO, IMF, IMO, ITU, NAM, OIC, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WTO','52e09c023d0a266cf7a2a91ac1ff22a468dc611294f5e0909bec3ecddca7cd00','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fa49684798835c9ff090c2de04dd92bd308573ef903189b361a0af029d81e64',1987,'SC','Seychelles','government',627,'Official name: Republic of Seychelles
Type: republic; member of the Common-
wealth
Capital: Victoria, Mahé Island
Legal system: based on English common
law, French civil law, and customary law
National holidays: 5 and 29 June
Branches: President, Council of Ministers,
People’s Assembly
Government leader: France Albert RENE,
President (since June 1979)
Suffrage: universal adult
Elections: general election held June 1979
gave 98% approval to René as only presi-
dential candidate on yes/no ballot; re-
elected in June 1984 with 92% of vote
Political parties and leaders: René, who
heads the Seychelles People’s Progressive
Front, came to power by a military coup
in June 1977; until then he had been
Prime Minister in an uneasy coalition with
then President James Mancham, who
headed the Seychelles Democratic Party;
René banned the Seychelles Democratic
Party in March 1978 and announced a
new constitution in March 1979 that
turned the country into a one-party state
Communists: negligible, although some
Cabinet ministers espouse pro-Soviet line
Other political or pressure groups: trade
unions, Roman Catholic Church
Member of: AfDB, FAO, G-77, GATT (de
facto), IBRD, ICAO, IFAD, IFC, ILO,
IMF, IMO, INTERPOL, NAM, OAU, UN,
UNESCO, UPU, WHO, WMO','a10939497befbe9bcdef0be72f54924a7c9ec7b404c429b6b5bd3f25b8c58e88','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4852611f4848da85ce10cb2e3e4c5e7c1c59d201dd075d57ecc013f676abc84f',1987,'SL','Sierra Leone','government',632,'Official name: Republic of Sierra Leone
Type: republic under presidential regime
since April 197]
Capital: Freetown
Administrative divisions: three provinces
(Eastern, Northern, Southern) and one area
(Western Area)
Legal system: based on English law and
customary laws indigenous to local tribes;
constitution adopted 1978; highest court of
appeal is the Sierra Leone Court of Ap-
peals; has not accepted compulsory 1CJ
jurisdiction
National holiday: Republic Day, 19 April
Branches: executive authority exercised by
President; unicameral parliament consists
of 104 authorized seats, 85 of which are
filled by elected representatives of constit-
uencies and 12 by Paramount Chiefs
elected by fellow Paramount Chiefs in
each district; President authorized to
appoint up to seven members; indepen-
dent judiciary
Government leaders: Gen. Joseph
MOMOH, President (since 28 November
1985); Francis MINAH, First Vice Presi-
dent (since November 1985); Abu Bakar
KAMARA, Second Vice President (since
November 1985)
Suffrage: universal over age 21
218
Political party and leader: All People’s
Congress (APC), Siaka Stevens, National
Chairman (constitution provides only for
one-party rule)
Communists: no party, although there are
a few Communists and a slightly larger
number of sympathizers
Member of: AfDB, AIOEC, Common-
wealth, ECA, ECOWAS, FAO, G-77,
GATT, IAFA, IBA, IBRD, ICAO, ICO,
IDA, IDB—Islamic Development Bank,
IFAD, IFC, ILO, IMF, IMO, INTERPOL,
IPU, IRC, ITU, Mano River Union, NAM,
OAU, OIC, UN, UNESCO, UPU, WHO,
WMO, WTO','f3007778adea9f0d127d34792f7d37778ecfece6edd88445e2bab4d39ee075c0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5579adede11eaa3bda71e3579396486695b7be89eee7fdab869d451fbc4a11ac',1987,'SG','Singapore','government',637,'Official name: Republic of Singapore
Type: republic within Commonwealth
Capital: Singapore
Legal system: based on English common
law; constitution based on preindepend-
ence State of Singapore constitution; has
not accepted compulsory ICJ jurisdiction
National holiday: 9 August
Branches: ceremonial President; executive
power exercised by Prime Minister and
Cabinet responsible to unicameral legisla-
ture (Parliament)
Government leaders: WEE Kim Wee,
President (since September 1985); LEE
Kuan Yew, Prime Minister (since June
1959)
Suffrage: amiversil and compulsory over
age 20
Elections: normally held every five years;
last held 1984
Political parties and leaders: govern-
ment—People’s Action Party (PAP), Lee
Kuan Yew; opposition—Barisan Sosialis
(BS), Dr. Lee Siew Choh; Workers’ Party
(WP), J. B. Jeyaretnam; United People’s
Front (UPF), Harbans Singh; Singapore
Democratic Party (SDP), Chiam See Tong;
Communist Party illegal
Voting strength: (1984 election) PAP won
77 of 79 seats in Parliament and received
63% of the vote; WP and SDP won one
seat each; WP member of Parliament
expelled November 1986
Communists: 200-500; Barisan Sosialis
infiltrated by Communists
Singapore (continued)
Member of: ADB, ANRPC, ASEAN,
Colombo Plan, Commonwealth, ESCAP,
G-77, GATT, IAEA, IBRD, ICAO, IFC,
IHO, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, ISO, ITU, NAM, UN,
UNESCO, UPU, WHO, WMO, WTO','a49ab07e3c35789f6c76fa79504cab6f33c38e2b146b1dad584427de623c2737','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecd5a0c8868a893c3a13bc3921a4f5989fdcf14112dc7425d347815498e68c77',1987,'SB','Solomon Islands','government',642,'Official name: Solomon Islands
Type: independent parliamentary state
within Commonwealth
Capital; Honiara
Administrative divisions: 7 administrative
districts
Legal system: a High Court plus Magis-
trates Courts; also a system of native courts
throughout the islands
National day: 7 July—Independence Day
Branches: executive authority in Governor
General; unicameral legislature
(38-member National Parliament)
Government leaders: Sir Baddeley
DEVESI, Governor General (since July
1978); Ezekiel Alabna, Prime Minister
(since December 1986)
Suffrage: universal adult at age 21
Elections: at least every four years; last
held October 1984
Political parties and leaders: United
Party, Sir Peter Kenilorea; People’s Alli-
ance Party, Solomon Mamaloni, National
Democratic Party, Bartholemew Ulufa’alu
Member of: ADB, Commonwealth,
ESCAP, G-77, GATT (de facto), IBRD,
IDA, IFAD, IFC, ILO, IMF, SPF, UN,
UPU, WHO','7d883bf8cb88918ad73e4e076c9143300020b64f7770ce3d25c73059a14e26f4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4514768f9b7caa4dfa5c6e084a7fe1b8a50a82d545404c399161d261bf6385c',1987,'SO','Somalia','government',647,'Official name: Somali Democratic Repub-
lic
Type: republic
Capital: Mogadishu
Administrative divisions: 18 regions, 60
districts
National holiday: 21 October
Branches: President dominates political
system; Cabinet carries out day-to-day
government functions; unicameral legisla-
ture (National People’s Assembly) exists
but has little power
Government leader: Maj. Gen. Mohamed
SIAD Barre, President and Commander in
Chief of the Army (since October 1969)
Political party and leader: the Somali
Revolutionary Socialist Party (SRSP),
created on 1 July 1976, is the sole legal
party; Maj. Gen. Mohamed Siad Barre is
general secretary of the SRSP
Elections: parliamentary elections held 31
December 1984; Presidential election held
December 1986 and President Siad won
99.92% of the votes in yes/no style elec-
tion for another seven-year term
Communists: probably some Communist
sympathizers in the government hierarchy
Member of: AfDB, Arab League, EAMA,
FAO, G-77, IBRD, ICAO, IDA, IDB—
Islamic Development Bank, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL,
ITU, NAM, OAU, OIC, UN, UNESCO,
UPU, WFTU, WHO, WMO','836e5ff6bfe5061c914ae781d75bc0820b5619a05e0c8c16574d9987cbb13c7b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8955c129a199bdc051d61eddad014a3b0c0ebb5cf6925aad8ee60e80ce8cda34',1987,'LK','Sri Lanka','government',655,'Official name: Democratic Socialist Re-
public of Sri Lanka
Type: republic
Capital: Colombo
Administrative divisions: 9 provinces, 24
administrative districts
Legal system: a highly complex mixture
of English common law, Roman-Dutch,
Muslim, and customary law; new constitu-
tion 7 September 1978 reinstituted a
strong, independent judiciary; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22
May
Branches: the 1978 constitution estab-
lished a strong presidential form of gov-
ernment under J. R. Jayewardene, who
had been Prime Minister since his party’s
election victory in July 1977; Jayewardene
was elected to a second term in October
1982 and will serve until 1989 regardless
of whether Parliament is dissolved; the
current Parliament was extended until
August 1989 by a national referendum
held in December 1982
Government leader: Junius Richard
JAYEWARDENE, President (since 1978)
Suffrage: universal over age 18
Elections: national elections ordinarily
held every six years; must be held more
frequently if government loses confidence
vote; the constitution was amended in
August 1982 to permit the President to call
an early presidential election
Political parties and leaders: Sri Lanka
Freedom Party (SLFP), Sirimavo Ratwatte
Dias Bandaranaike; Sri Lanka Mahajana
Party, Vijaya Kumaratunga; Lanka Sama
Samaja Party (LSSP; Trotskyite), C. R. de
Silva; Nava Sama Samaja Party (NSSP), V.
Nanayakkara; Tamil United Liberation
Front, A. Amirthalingam; United National
Party (UNP), J. R. Jayewardene; Commu-
nist Party/Moscow, K. P. Silva; Commu-
nist Party/Beijing, N. Shanmugathasan;
Mahajana Eksath Peramuna (People’s
United Front), M. B. Ratnayaka; Janatha
Vimukthi Peramuna (JVP; People’s Libera-
tion Front), Rohana Wijeweera; All-Ceylon
Tamil Congress, Kumar Ponnambalam
Voting strength: (October 1982 presiden-
tial election) UNP 52.91%, SLFP 39.07%,
JVP 4.18%, All Ceylon Tamil Congress
2.67%, LSSP .9%, NSSP .27%
Other political or pressure groups: Tamil
separatist groups, Buddhist clergy, Sinha-
lese Buddhist lay groups; far-left violent
revolutionary groups; labor unions
Member of: ADB, ANRPC, Colombo
Plan, Commonwealth, ESCAP, FAO,
G-77, GATT, IAEA, IBRD, ICAO, IDA,
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IPU, IRC, ITU, NAM,
SAARC, UN, UNESCO, UPU, WFTU,
WHO, WIPO, WMO, WTO','9bf9e6ac23cf16a05ed74ddcac4626ea651be6db41e3519478573afe194f0ef0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f3b896eb989a9e242e611bd722d985abd7dc3700b5529b8fa90d3f374a918fc',1987,'SD','Sudan','government',660,'Official name: Republic of the Sudan
Type: republic
Capital: Khartoum
Administrative divisions: 9 regions
Legal system: based on English common
law and Islamic law; in September 1983
President Nimeiri declared the penal code
would conform to Islamic law; some sepa-
rate religious courts; interim constitution
promulgated August 1985; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: I January, Indepen-
dence Day
Branches: Supreme Council and Civilian
Cabinet; regional military governors
Government leaders: Ahmad
al-MIRGHANI, Chairman, Supreme Coun-
cil (since May 1986); Sadiq al- MAHDI,
Prime Minister (since May 1986)
Suffrage: universal adult
Elections: elections held in April 1986;
selected representation to a Constituent
Assembly that was to draft a new constitu-
tion in one year and thereafter turn itself
into a parliament to serve for three years
Political parties and leaders: following
coup in April 1985, more than 30 different
political parties declared; most significant
include the Umma Party (Ansar Muslim
Sect), the Democratic Unionist Party
(Khatmiyyah Muslim Sect), the rightist
230
Islamic fundamentalist National Islamic
Front (Muslim Brotherhood), the Sudanese
Communist Party, and the B‘ath Party;
major southern parties include the Sudan
African Congress and the Southern Sudan-
ese Political Association
Member of: AfDB, APC, Arab League,
FAO, G-77, IAEA, IBRD, ICAC, ICAO,
IDA, IDB—Islamic Development Bank,
(IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ITU, NAM, OAU, OIC, UN,
UNESCO, UPU, WFTU, WHO, WIPO,
WMO, WTO','cf7dc4dc6af281e1cdc7170fd51ce2b711949d856bc5ddeba20a45c9bfe81581','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4b0521e7a2f444ddf080d0db6aca20466e6b65740f859a8e64e46d39664ee0c',1987,'GE','Georgia','government',666,'Official name: Republic of Suriname
Type: military-civilian rule
Capital: Paramaribo
Administrative divisions: 9 districts, each
headed by District Commissioner responsi-
ble to Minister of Internal Affairs and
Local Administration; 100 People’s Com-
mittees installed at local level
Legal system: suspended constitution;
judicial system functions in ordinary civil
and criminal cases
National holiday: Independence Day, 25
November
Branches: civilian government controlled
by the military
Government leaders: Lt. Col. Desire
BOUTERSE, Head of Government, Army
Commander and strongman (since Febru-
ary 1980); Lachmipersad Frederick
RAMDAT-MISIER, Acting President
(figurehead; since February 1982); Jules
Wijdenbosch, Prime Minister (since Febru-
ary 1987)
Suriname (continued)
Suffrage: suspended
Elections: none planned
Political parties and leaders: 25 February
National Unity Movement (November
1983) established by Bouterse; regular
party activity limited; given greater free-
dom of assembly in 1985; leftists (all small
groups)—Revolutionary People’s Party
(RVP), Michael Naarendorp; Progressive
Workers and Farmers (PALU), Iwan
Krolis; traditional parties—Progressive
Reform Party (VHP), Jaggermath
Lachmon; National Party of Suriname
(NPS), Henck Awon; Indonesian Peasants
Party (KTPI), Willy Soemita
Member of: ECLA, FAO, GATT, G-77,
IBA, IBRD, ICAO, 1DB—Inter-American
Development Bank, IFAD, LLO, IMF,
IMO, INTERPOL, ITU, NAM, OAS,
PAHO, SELA, UN, UNESCO, UPU,
WHO, WIPO, WMO','c664f8d0c2afda80a1dc3efcd537e3112795ee5f8c55589e880581aaa3490580','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aa496d16ac58c042d61f613897bd121d1a1738524b446173f99304319a9b2e1',1987,'SE','Sweden','government',672,'Official name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Administrative divisions: 24 counties, 284
municipalities (townships)
Legal system: civil law system influenced
by customary law; a new constitution was
adopted in 1975; accepts compulsory IC]
jurisdiction, with reservations
National holiday: no national holiday;
King’s birthday, 30 April, celebrated as
such by Swedish embassies
Branches: legislative authority rests with
unicameral parliament (Riksdag); executive
power vested in Cabinet, responsible to
parliament; Supreme Court, 6 superior
courts, 108 lower courts
Government leaders: CARL XVI Gustaf,
King (since September 1973); Ingvar
CARLSSON, Prime Minister (since March
1986)
Suffrage: universal but not compulsory
over age 18; after three years of legal
residence immigrants may vote in county
and municipal but not national elections
Elections: every three years; next sched-
uled for September 1988
234
Political parties and leaders: Moderate
(conservative), Carl Bildt; Center, Olaf
Johansson; Liberal People’s Party, Bengt
Westerberg; Social Democratic, Ingvar
Carlsson; Left Party-Communist (VPK),
Lars Werner; Swedish Communist Party
(SKP), Roland Pettersson; Communist
Workers’ Party, Rolf Hagel
Voting strength: (1985 election) 45.0%
Social Democratic, 21.3% Moderate Coali-
tion, 12.5% Center (includes votes for
Christian Democratic Alliance), 14.3%
Liberal, 5.4% Communist, 1.5% other
Communists: VPK and SKP; VPK, the
major Communist party, is reported to
have roughly 17,800 members; in the 1985
election, the VPK attracted 293,543 votes;
in addition, there are 4 other active Com-
munist parties, including the SKP, for
which membership figures are not avail-
able; in the 1985 elections, these parties
obtained an additional 16,000 votes
Member of: ADB, Council of Europe,
DAC, EC (Free Trade Agreement), EFTA,
ESRO, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, ICES, ICO, IDA, IDB—Inter-
American Development Bank, IEA, IFAD,
IFC, JIHO, ILO, IMF, IMO, INTERPOL,
INTELSAT, International Lead and Zinc
Study Group, IPU, ISO, ITU, IWC—
International Whaling Commission,
IWC—International Wheat Council,
Nordic Council, OECD, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG','ccb9c2625f4db1175aacb46be929d74e1d689533d2811b4f0a92f5ae4ccaec24','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47251afc16f3cf144b422b9fadc8a612e7a627e0478be5ad62ac00d373f6765c',1987,'CH','Switzerland','government',677,'Official name: Swiss Confederation
Type: federal republic
Capital: Bern
Administrative divisions: 23 cantons (3
divided into half cantons)
Legal system: civil law system influenced
by customary law; constitution adopted
1874, amended since; judicial review of
legislative acts, except with respect to
federal decrees of general obligatory
character; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: National Day, ] August
Branches: bicameral parliament (National
Council, Council of States) has legislative
authority; federal council (Bundesrat) has
executive authority; justice left chiefly to
cantons
Government leaders: Pierre AUBERT,
President (1987—presidency rotates annu-
ally); Otto STICH, Vice President (term
runs concurrently with that of President)
Suffrage: universal over age 20
Elections: held every four years; next
elections scheduled for 1987
Political parties and leaders: Social Dem-
ocratic Party (SPS), Helmuth Hubacher,
chairman; Radical Democratic Party
(FDP), Bruno Hunziker, president; Chris-
tian Democratic People’s Party (CVP),
Flavio Cotti, president; Swiss People’s
Party (SVP), Adolf Ogi, president;
Workers’ Party (PdA), Armand Magnin,
secretary general; National Action Party
(NA), Hans Zwicky, chairman;
Independents’ Party (LdU), Dr. Franz
Jaeger, president; Republican Movement
(Rep), Dr. James Schworzenboch, Franz
Baumgartner, leaders; Liberal Party (LPS),
Gilbert Coutau, president; Evangelical
People’s Party (EVP), Max Diik, president;
Progressive Organizations of Switzerland
(POCH), Georg Degen, secretary; Federa-
tion of Ecology Parties (GP), Laurent
Rebeaud, president; Autonomous Socialist
Party (PSA), Werner Carobbio, secretary
Voting strength: (1983 election) 23.4%
FDP, 22.8% SPS, 20.5% CVP, 11.1% SVP,
3.5% NA, 2.9% GP
Communists: about 5,000 members
Member of: ADB, Council of Europe,
DAC, EFTA, ELDO (observer), ESRO,
FAO, GATT, IAEA, ICAC, ICAO, ICO,
IDB—Inter-American Development Bank,
IEA, IFAD, ILO, IMO, INTELSAT,
INTERPOL, IPU, ITU, [!WC—Interna-
tional Wheat Council, OECD, UNESCO,
UPU, World Confederation of Labor,
WFTU, WHO, WIPO, WMO, WSG,
WTO; permanent observer status at the
UN
Official name: Syrian Arab Republic
Type: republic; under leftwing military
regime since March 1963
Capital; Damascus
Administrative divisions: 13 provinces
and city of Damascus
Legal system: based on Islamic law and
civil law system; special religious courts;
constitution promulgated in 1973; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 17
April
Branches: executive powers vested in
President and Council of Ministers; power
rests in unicameral legislative (People’s
Council); seat of power is the Ba‘th Party
Regional (Syrian) Command
Government leader: Lt. Gen. Hafiz al-
ASSAD, President (since February 1971)
Suffrage: universal at age 18
Elections: People’s Council election held
November 1983; presidential election held
February 1985
Syria (continued)
Political parties and leaders: ruling party
is the Arab Socialist Resurrectionist (Bath)
Party; the Progressive National Front is
dominated by Ba’‘thists but includes inde-
pendents and members of the Syrian Arab
Socialist Party (ASP), Arab Socialist Union
(ASU), Socialist Unionist Movement, and
Syrian Communist Party (SCP)
Communists: mostly sympathizers, num-
bering about 5,000
Other political or pressure groups: non-
Ba‘th parties have little effective political
influence; Communist Party ineffective;
greatest threat to Assad regime lies in
factionalism in the military; conservative
religious leaders; Muslim Brotherhood
Member of: Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL,
IOOC, IPU, ITU, [''WC—International
Wheat Council, NAM, OAPEC, OIC, UN,
UNESCO, UPU, WFTU, WHO, WMO,
WSG, WTO
Official name: United Republic of Tanza-
nia
Type: republic
Capital: Dar es Salaam
Administrative divisions: 25 regions—20
on mainland, 5 on Zanzibar
Legal system: based on English common
law; permanent constitution adopted 1977
(Zanzibar has its own constitution but
remains subject to provisions of the union
constitution); judicial review of legislative
acts limited to matters of interpretation;
has not accepted compulsory 1CJ jurisdic-
tion
National holiday: Union Day, 26 April;
Independence Day, 9 December
Branches: President Ali Hassan Mwinyi
has full executive authority on the main-
land; National Assembly dominated by the
Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 233
members, 72 from Zanzibar, of whom 10
are directly elected, 65 appointed from the
mainland, and 96 directly elected from the
mainland (these numbers are slated to be
changed when amendments to the Consti-
tution are approved)
Government leaders: Ali Hassan
MWINYI, President (since November
1985); Joseph Sinde WARIOBA, Prime
Minister (since November 1985)
Suffrage: universal adult over age 18
Political party and leader: Chama Cha
Mapinduzi (Revolutionary Party), only
political party, dominated by Nyerere; has
considerable power over domestic policies
and the enforcement of them
Voting strength: (October 1985 national
elections) close to 7 million registered
voters; Mwinyi received 92.2% of over 5
million votes cast
Communists: a few Communist sympa-
thizers, especially on Zanzibar
Member of: AfDB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO,
1CO, IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ITU, NAM,
OAU, SADCC, UN, UNESCO, UPU,
WHO, WMO, WTO','e004fa6add71d8bdd9f5332173c28638f68af1cf58b0b55e109dc11be1c5f9d2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b86e005710ec3664c9762946a5e79abd888504cc26c9ce732fc7b6bae40346c8',1987,'TG','Togo','government',682,'Official name: Republic of Togo
Type: republic; one-party presidential
regime
Capital; Lomé
Administrative divisions: 21 prefectures
Legal system: French-based court system
with a court of appeals
National holiday: Independence Day, 27
April
Branches: strong executive President;
unicameral legislature (National Assembly);
separate judiciary, including State Security
Court, established in 1970; a new constitu-
tion was endorsed by referendum in 1979
that provided for an elective presidential
system and a 67-member National Assem-
bly
Government leader: Gen. Gnassingbé
EYADEMA, President (since 1967)
Suffrage: universal adult
Elections: to be held every seven years;
last held in December 1986; General
Eyadéma, the sole candidate, was elected
by almost 100% of votes cast
Political party: single party formed by
President Eyadéma in September 1969,
Rally of the Togolese People (RPT); struc-
ture and staffing of party closely controlled
by government
Communists: no Communist Party; possi-
bly some sympathizers
Togo (continued)
Member of: AfDB, CEAO (observer),
EAMA, ECA, ECOWAS, ENTENTE,
FAO, G-77, GATT, IBRD, ICAO, 1CO,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTERPOL, ITU, Lomé Convention,
NAM, OAU, OCAM, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO','728b3a10e79ffe06e81af5f9f534d124261362e3d2670a9a11170ffebac321f3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a63521e4f2cbc92719dc90bdecc0455adfb8ecb88e70f44eda8baa79c9a3cd4f',1987,'TO','Tonga','government',689,'Official name: Kingdom of Tonga
Type: constitutional monarchy within the
Commonwealth
Capital: Nuku‘alofa
Administrative divisions: three island
groups (Tongatapu, Ha‘apai, Vava‘u)
Legal system: based on English law
Branches: executive—King, Cabinet, and
Privy Council; unicameral legislature—
Legislative Assembly composed of seven
nobles elected by their peers, seven elected
representatives of the people, eight Minis-
ters of the Crown; the King appoints one
of the seven nobles to be the speaker;
judiciary—Supreme Court, Magistrate''s
Court, Land Court
Government leaders: Taufa’ahau TUPOU
IV, King (since December 1965); Prince
Fatafehi TU IPELEHAKE), Premier (since
December 1965)
Suffrage: all literate, tax-paying males and
all literate females over 21
Elections: supposed to be held every three
years; last held in April 1978
Communists: none known
Member of: ADB, Commonwealth, FAO,
ESCAP, GATT (de facto), IFAD, ITU,
South Pacific Bureau for Economic Coop-
eration, SPF, UNESCO, UPU, WHO','f4d7adb1c8ec78f64220248cdb370256bff1e1219ee561dab9591b802a23d6c5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f95db2157d25d67001b4b29788002114d1455178f54fa16a713adde5df1b068d',1987,'TT','Trinidad and Tobago','government',694,'Official name: Republic of Trinidad and
Tobago
Type: parliamentary democracy
Capital: Port-of-Spain
Administrative divisions: 8 counties (29
wards, Tobago is 30th)
Legal system: based on English common
law; constitution came into effect 1976;
judicial review of legislative acts in the
Supreme Court; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 31
August
Branches: bicameral legislature
(36-member elected House of Representa-
tives and 3l-member appointed Senate);
executive is Cabinet led by the Prime
Minister; judiciary is headed by the Chief
Justice and includes a Court of Appeal,
High Court, and lower courts
Government leaders: Arthur Napoleon
Raymond ROBINSON, Prime Minister
(since December 1986); Noor HASSAN-
ALI, President (since February 1987)
Suffrage: universal over age 18
Elections: elections to be held at intervals
of not more than five years; last election
held 15 December 1986
Political parties and leaders: National
Alliance for Reconstruction (NAR), A.N.R.
Robinson; People’s National Movement
(PNM), Patrick Manning (interim leader);
Organization for National Reconstruction
(ONR), Karl Hudson-Phillips
Voting strength: (1986 election) 62% of
registered voters cast ballots; House of
Representatives—NAR, 33 seats; PNM, 3
Communists: People’s Popular Movement
(PPM), Michael Als; February 18 Move-
ment (F/18), James Millette
Other political pressure groups: National
Joint Action Committee (NJAC), radical
antigovernment black-identity organiza-
tion; Trinidad and Tobago Peace Council,
leftist organization affiliated with the
World Peace Council; Trinidad and To-
bago Chamber of Industry and Commerce;
Trinidad and Tobago Labor Congress,
moderate labor federation; Council of
Progressive Trade Unions, radical labor
federation
Member of: CARICOM, Commonwealth,
FAO, G-77, GATT, IADB, IBRD, Interna-
tional Coffee Agreement, ICAO, ICO,
IDA, !DB—Inter-American Development
Bank, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, ISO, ITU, IWC—Interna-
tional Wheat Council, NAM, OAS, PAHO,
SELA, UN, UNESCO, UPU, WFTU,
WHO, WMO, WTO','e807fa526d799ff0a01ba46dbea9eb324e23e349b0062a5e8779b43be663b739','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5009de9620641db7565e2aa535970ed447c20c5c2cf4f69c50f2732584c5a2f',1987,'TN','Tunisia','government',699,'Official name: Republic of Tunisia
Type: republic
Capital: Tanis
Administrative divisions: 23 governorates
Legal system: based on French civil law
system and Islamic law; constitution (pat-
terned on Turkish and US constitutions)
adopted 1959; some judicial review of
legislative acts in the Supreme Court in
joint session
National holiday: Independence Day,
1 June
Branches: executive dominant; unicameral
legislative (National Assembly) largely
advisory; judicial, patterned on French
and Koranic systems
Government leaders: Habib
BOURGUIBA, President (Prime Minister
since 1956, President since 1957, President
for Life since November 1974); Rachid
SFAR, Prime Minister (since July 1986)
Suffrage: universal over age 21
Elections: national election held every five
years; last election held 2 November 1986
Political parties and leaders: Destourian
Socialist Party is official ruling party; two
small parties—Movement of Social Demo-
crats and Movement of Popular Unity—
legalized in 1983; Communist Party legal-
ized in 1981
246
Voting strength: 1986 election
non-competitive; over 95% Destourian
Socialist Party, 3.2% Social Democrats,
under 1% Movement of Popular Unity,
under 1% Communist Party
Communists: a small number of nominal
Communists, mostly students
Member of: AfDB, Arab League, AIOEC,
FAO, G-77, GATT (de facto), IAEA,
IBRD, ICAO, IDA, IDB—islamic Devel-
opment Bank, IFAD, IFC, 1LO, Interna-
tional Lead and Zinc Study Group, IMF,
IMO, INTELSAT, INTERPOL, 100C,
ITU, 1WC—lInternational Wheat Council,
NAM, OAPEC, OAU, OIC, Regional
Cooperation for Development, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WTO
Official name: Republic of Turkey
Type: republican parliamentary democ-
racy
Capital: Ankara
Administrative divisions: 67 provinces
Legal system: derived from various conti-
nental legal systems; constitution adopted
in November 1982; accepts compulsory
1CJ jurisdiction, with reservations
National holiday: Republic Day, 29
October
Branches: executive—President empow-
ered to call new elections, promulgate laws
(elected for a seven-year term); unicameral
legislature (400-member Grand National
Assembly); independent judiciary
Government leaders: Gen. Kenan
EVREN, President (since 1982); Turgut
OZAL, Prime Minister (since 1983)
Suffrage: universal over age 21
Turkey (continued)
Elections: according to the 1982 Constitu-
tion, elections to the Grand National
Assembly to be held every five years; most
recent election 6 November 1983; by-
election held 28 September 1986
Political parties and leaders: military
leaders banned all traditional parties from
taking part in the parliamentary election
of November 1983 and banned many
prominent party leaders from taking part
in politics for five to 10 years; three new
parties allowed to take part in the elec-
tion—Motherland Party (ANAP), Turgut
Ozal; Populist Party (PP), Necdet Calp;
Nationalist Democracy Party (NDP), Ulk
Sdylemezoglu; additional parties permitted
to take part in local elections in March
1984—Social Democratcy Party (SODEP),
Erdal [nén; Correct Way Party (CWP),
Husamettin Cinderuk; SODEP and PP
merged in 1985 to form the Social Demo-
cratic Populist Party (SHP) now headed by
Erdal inén; Democratic Left Party (DLP)
founded in 1985 under Rahsan Ecevit
Voting strength: (1983 election) Grand
National Assembly—Motherland Party,
211 seats; Populist Party, 117 seats; Na-
tionalist Democracy Party, 71 seats; as of
March 1987, Grand National Assembly—
Motherland Party, 251 seats; Social Demo-
cratic Populist Party, 65 seats; Correct
Way Party, 35 seats; Democratic Left
Party, 24 seats; independents, 24 seats;
vacant, 2 seats
Communists: strength and support negligi-
ble
Member of: ASSIMER, Council of Eu-
rope, EC (associate member), ECOSOC,
FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IDB—Islamic Development Bank,
IEA, IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOOC, IPU,
ITC, ITU, NATO, OECD, OIC, Economic
Cooperation Organization, UN, UNESCO,
UPU, WHO, WIPO, WMO, WSG, WTO','3eb56b7dd9c7270ccca6fe59f5668e4677eb67f6a93ed7f8de2c264cd523803d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0234b7245814eee05abf9f16799339208f21e9f8731e4e31df5343f3037e95e',1987,'JP','Japan','government',703,'Official name: Turks and Caicos Islands
Type: British dependent territory
Capital; Grand Turk (Cockburn Town)
Administrative divisions: 3 districts
Legal system: based on laws of England
and Wales with a small number adopted
from Jamaica and The Bahamas; constitu-
tion introduced in 1976
National holiday: Commonwealth Day,
31 May
Branches: executive, bicameral legislature
(Executive Council, 14-member Legislative
Council), judicial (Supreme Court)
Government leader: Michael BRADLEY,
Governor (since 1987)
Suffrage: universal adult at age 18
Elections: last held in May 1984 for 11
Legislative Council seats
Political parties and leaders: People’s
Democratic Movement (PDM), Clement
Howell; Progressive National Party (PNP),
Nathaniel Francis
Voting strength: PDM, 3 seats, PNP, 8
seats
Communists: none','57f6e8b579d3a38c4961caf12c6e2ac29f6ee9fffe59b541d9611d449f9df762','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('111889e02832a5c27b5c10cf570192e8794a593db449a2b8fb0fa0b832f14313',1987,'TV','Tuvalu','government',707,'Official name: Tuvalu
Type: independent state, special member
of the Commonwealth
Capital: Funafuti
Administrative divisions: 8 island councils
on the permanently inhabited islands
Branches: executive—Prime Minister and
Cabinet; unicameral legislature—12-
member House of Parliament; judicial—
High Court, 8 island courts with limited
jurisdication
Government leaders; Dr. Tomasi
PUAPUA, Prime Minister (since Septem-
ber 1981); Tupua LEUPENA, Governor
General (since 1 March 1986)
Elections: last general election September
1985, next scheduled for September 1989
Political parties: none
Member of: ESCAP (associate member),
GATT (de facto), SPF, SPC, UPU','4f6b28dc70beff51b45d688cb90792b6a921f5062c4b2e2a17c7e604396057af','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38727b72ec0192e54ac847047bcf16acae107e64013809fc1a604543c6a1a6fc',1987,'UG','Uganda','government',712,'Official name: Republic of Uganda
Type: republic
Capital: Kampala
Administrative divisions: 10 provinces
and 34 districts
Legal system: government plans to restore
system based on English common law and
customary law and reinstitute a normal
judicial system; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 9
October
Branches: present government, which
assumed power in January 1986, consists
of a National Resistance Council headed
by the President; the constitution has been
suspended and the unicameral legislature
(National Assembly) has been dissolved
Government leader: Yoweri Kaguta
MUSEVENI, Head of State and Chairman
of the National Resistance Council (since
January 1986)
Suffrage: universal adult
Elections: none scheduled
Political parties: Uganda Patriotic Move-
ment (UPM), Ugandan People’s Congress
(UPC), Democratic Party (DP), Conserva-
tive Party (CP); all are proscribed from
conducting public political activities
Other political] parties or pressure
groups: Uganda National Liberation Army
(UNLA), Uganda Freedom Movement
(UFM), Federal Democratic Movement of
Uganda (FEDEMU), Uganda National
Rescue Front (UNRF), Uganda People’s
Democratic Movement (UPDM)
Communists: possibly a few sympathizers
Member of: Af{DB, Commonwealth, FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO,
ICO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, 1LO, IMF, INTELSAT,
INTERPOL, ISO, ITU, NAM, OAU, OIC,
UN, UNESCO, UPU, WHO, WIPO,
WMO, WTO
251','12297ed0ab542d4abe80d4ecbc8d9fc28b683730060c76908842492ea1d3c8af','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36cef2c5716c112c76220b28529a78d9e67762ae62aea407e7f2856b3228e123',1987,'AE','United Arab Emirates','government',717,'Official name: United Arab Emirates
Member states: Abu Dhabi, ‘Ajman,
Dubayy, Al Fujayrah, Ra’s al Khaymah,
Ash Shariqah, Umm al Qaywayn
Type: federation; constitution signed
December 1971, which delegated specified
powers to the UAE central government
and reserved other powers to member
shaykhdoms
Capital: Abu Dhabi
Legal system: secular codes are being
introduced by the UAE Government and
in several member shaykhdoms; Islamic
law remains influential
National holiday: 2 December
Branches: executive—Supreme Council of
Rulers (seven members), from which a
President and Vice President are elected;
Prime Minister and Council of Ministers;
unicameral legislature—Federal National
Council; judicial—Union Supreme Court
Government leaders: Shaykh Zayid bin
Sultan Al NUHAYYAN of Abu Dhabi,
President (since December 1971); Shaykh
Rashid ibn Sa‘id Al MAKTUM of Dubayy,
Vice President (since 1971) and Prime
Minister (since April 1979)
Suffrage: none
Elections: none
Political or pressure groups: none; a few
small clandestine groups are active
Member of: Arab League, FAO, G-77,
GATT (de facto), GCC, IAEA, IBRD,
ICAO, IDA, IDB—Islamic Development
Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, ITU, NAM,
OAPEC, OIC, OPEC, UN, UNESCO,
UPU, WHO, WIPO, WTO','c7566032a7a71b91586537d7e9dfa544c91774c6a349e6dc2ea089a041a97a58','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a1096b7488fcb39e4d45dee3f4bd2ea80f54b08b56b90959ccc3853947964d9',1987,'GB','United Kingdom','government',722,'Official name: United Kingdom of Great
Britain and Northern Ireland
Type: constitutional monarchy
Capital; London
Administrative divisions: 54 counties in
England and Wales, 12 regions in Scotland
and islands area, 26 districts in Northern','fa7dd35cb34bf172d72a8794e49ae530681154b7307f2cf68ba390aed0f0759b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42f1d4ec3786dd639d68670d1a6b55e33d31bcbf4ee3bbcd183ebd44799fd7de',1987,'US','United States','government',726,'Official name: United States of America
Type: federal republic; strong democratic
tradition
Capital: Washington, D. C.
t
Administrative divisions: 50 states and
the District of Columbia
Dependent areas: American Samoa, Baker
Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef,
Midway Islands, Navassa Island, Palmyra
Atoll, Puerto Rico, Virgin Islands, Wake
Island. Since 18 July 1947, the US has
administered the Trust Territory of the
Pacific Islands, but recently entered into a
new political relationship with three of the
four political units. The Northern Mariana
Islands is a Commonwealth associated with
the US (effective 3 November 1986). Palau
concluded a Compact of Free Association
with the US that was approved by the US
Congress but to date the Compact process
has not been completed in Palau, which
continues to be administered by the US as
the Trust Territory of the Pacific Islands.
The Federated States of Micronesia signed
a Compact of Free Association with the
US (effective 8 November 1986). The
Republic of the Marshall Islands signed a
Compact of Free Association with the US
(effective 21 October 1986). Maps and data
on the Federated States of Micronesia and
the Republic of the Marshall Islands will
be included in the next edition.
Legal system: based on English common
law; dual system of courts, state and fed-
eral; constitution adopted 1789; judicial
review of legislative acts; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: Independence Day, 4
July
Branches: executive (President), bicameral
legislature (House of Representatives and
Senate), and judicial (Supreme Court);
branches, in principle, independent and
maintain balance of power
Government leaders: Ronald REAGAN,
President (since January 1981); George
BUSH, Vice President (since January 1981)
Suffrage: all citizens over age 18; not
compulsory
Elections: presidential, every four years
(next November 1988); all members of the
House of Representatives, every two years;
one-third of members of the Senate, every
two years
256
Political parties and leaders: Republican
Party, Frank J. Fahrenkopf, Jr., national
chairman, Maureen Reagan, cochairman;
Democratic Party, Paul G. Kirk, Jr., na-
tional committee chairman; several other
groups or parties of minor political signifi-
cance
Voting strength: 53.3% voter participation
(1984 presidential election); Republican
Party (Ronald Reagan), 59% of the popular
vote (525 electoral votes); Democratic
Party (Walter Mondale), 41% of the popu-
lar vote (13 electoral votes)
Communists: Communist Party (claimed
15,000-20,000 members), Gus Hall, general
secretary; Socialist Workers Party (claimed
1,800 members), Jack Barnes, national
secretary (1983)
Member of: ADB, ANZUS, Bank of Inter-
national Settlements, CCC, CENTO,
Colombo Plan, DAC, FAO, ESCAP,
GATT, Group of Ten, IADB, IAEA,
IBRD, ICAC, ICAO, ICEM, ICES, ICO,
IDA, IDB—Inter-American Development
Bank, IEA, IFAD, IFC, IHO, ILO, Inter-
national Lead and Zinc Study Group,
IMF, IMO, INTELSAT, INTERPOL, IPU,
IRC, ITC, ITU, IWC—International
Whaling Commission, [WC—International
Wheat Council, NATO, OAS, OECD,
PAHO, SPC, UN, UPU, WHO, WIPO,
WMO, WSG, WTO','7ccf88d011fdb4850a6877e14ecede09820acbe37b06733f48146ab7985fb1f9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c9e60db81d72ed38ef12e0e0c92b55ef98781a4abce2782ad5a6dc74c333cdd',1987,'UY','Uruguay','government',731,'Official name: Oriental Republic of Uru-
guay
Type: republic
Capital: Montevideo
Administrative divisions: 19 departments
with limited autonomy
Legal system: based on Spanish civil law
system; most recent constitution imple-
mented 1967; accepts compulsory ICJ
jurisdiction
National holiday: Independence Day, 25
August
Branches: executive, headed by President;
bicameral National Congress (Senate and
House of Deputies); national judiciary
headed by Court of Justice
Government leaders: Julio M. SANGUI-
NETTI, President (since March 1985);
Enrique E. TARIGO, Vice President (since
March 1985)
Suffrage: universal over age 18
Elections: last November 1984; elections
held every five years
Political parties and leaders: National
(Blanco) Party, Wilson Ferreira; Colorado
Party, Julio Sanguinetti, Enrique Tarigo,
Jorge Pacheco Areco; Broad Front Coali-
tion, Liber Seregni; Communist Party
(legalized in March 1985), Rodney Arisme-
ndi; Civic Union, Humberto Ciganda;
Government of the People (List 99), Hugo
Batalla
Voting strength: (1984 elections) 41%
Colorado, 35% Blanco, 22% Broad Front,
2% Civic Union
Communists: 30,000
Other political or pressure groups: Na-
tional Liberation Movement (MLN)—
Tupamaros, leftist revolutionary terrorist
group, granted amnesty in 1985
Member of: FAO, G-77, GATT, IADB,
IAEA, IBRD, ICAO, IDB—Inter-American
Development Bank, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL, IRC,
ITU, LAIA, OAS, PAHO, SELA, UN,
UNESCO, UPU, WHO, WIPO, WMO,
WSG','c7c69eb2c656311201edb496dd3e2054be4c5943ca035877fae3c83c506b908e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74d1b4214bb80494b87f33833209262c92444586614034b3d7f0676b74f5d0af',1987,'VU','Vanuatu','government',736,'Official name: Republic of Vanuatu
Type: republic, formerly Anglo-French
condominium of New Hebrides, indepen-
dent 30 July 1980
Capital; Port-Vila
Administrative divisions: four administra-
tive districts
Legal system: unified system being cre-
ated from former dual French and British
systems
Branch: unicameral legislature
(39-member Parliament), elected Novem-
ber 1983
Government leader: Father Walter Hadye
LINI, Prime Minister (since 1980)
Political parties and leaders: National
Party (Vanuaaku Pati), Walter Lini, chair-
man
Member of: ADB, Commonwealth,
ESCAP, FAO, G-77, IBRD, ICAO, IDA,
IFC, IMF, ITU, NAM, SPF, UN, WHO,
WMO
Official name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Administrative divisions: outside the
Vatican, 13 buildings in Rome and Castel
Gandolfo (the Pope’s summer residence)
enjoy extraterritorial rights
Legal system: Canon laws of 1929 serve
some functions of a constitution
National holiday: 22 October (installation
day of Pope John Paul II)
Branches: the Pope possesses full execu-
tive, legislative, and judicial powers; he
delegates these powers to the President of
the Pontifical Commission, who is subject
to pontifical appointment and recall; the
administrative structure of the Roman
Catholic Church is known as the Roman
Curia; its most important temporal compo-
nents include the Secretariat of State and
Council for Public Affairs (which handles
Vatican diplomacy) and the Prefecture of
Economic Affairs; the College of Cardinals
act as chief papal advisers
Government leader: JOHN PAUL II,
Supreme Pontiff (Karol WOJTYLLA,
elected Pope 16 October 1978)
Suffrage: limited to cardinals less than 80
years old
Elections: Supreme Pontiff elected for life
by College of Cardinals
Communists: none known
Other political or pressure groups: none
(exclusive of influence exercised by other
church officers in universal Roman Catho-
lic Church)
Member: IAEA, INTELSAT, ITU, IWC—
International Wheat Council, UPU,
WIPO, WTO; permanent observer status
at FAO, OAS, UN, and UNESCO
Official name: Republic of Venezuela
Type: republic
Capital: Caracas
Administrative divisions: 20 states, 1
federal district, 2 federal territories
Legal system: based on Napoleonic code;
constitution promulgated 1961; judicial
review of legislative acts in Cassation
Court only; dual court system, state and
federal; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 5
July
Branches: executive (President), bicameral
legislature (National Congress—Senate,
Chamber of Deputies), judiciary
Government leader: Jaime LUSINCHI,
President (since February 1984)
Suffrage: universal and compulsory over
age 18, though rarely enforced
Elections: every five years by secret ballot;
last held December 1983; next national
election for President and bicameral
legislature scheduled for December 1988
Political parties and leaders: Social Chris-
tian Party (COPEI), Eduardo Fernandez
(secretary general), Democratic Action
(AD), Gonzalo Barrios, Movement Toward
Socialism (MAS), Pompeyo Marquez (presi-
dent), Freddy Mujfioz (secretary general)
261
Voting strength: (1983 election) 56.8%
AD, 34.5% COPEI, 4.17% MAS, 4.53%
others
Communists: 10,000 members (est.)
Other political or pressure groups:
FEDECAMARAS, a conservative business
group
Member of: Andean Pact, AIOEC, FAO,
G-77, IADB, IAEA, IBRD, ICAO, ICO,
{DB—Inter-American Development Bank,
IFAD, IFC, IHO, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, IRC, ITU,
IWC—International Wheat Council,
LAIA, OAS, OPEC, PAHO, SELA,
WFTU, UN, UNESCO, UPU, WHO,
WMO, WTO','cc72f4dcac8b46dc1b2872602988a4e43b45c064bfda6c8d7e352522a7d35eb7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492a6060a634f7688f0e997ab0528a631d19e1165990938fab10cef08b2472dc',1987,'WF','Wallis and Futuna','government',741,'Official name: Territory of the Wallis and
Futuna Islands
Type: overseas territory of France
Capital: Mata-Utu
Administrative divisions: three districts
Branches: territorial assembly of 20 mem-
bers; popular election of one deputy to
National Assembly in Paris and one sena-
tor
Government leaders: Jacques LE
HENAFF, Administrator; and Jean
MONTPEZAT, High Commissioner
Suffrage: universal adult
Elections: every five years','07154e2d17a885c14b2a3b7789f6500698ccf6ab7824352d1c8ec998438d5421','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae9556bb6d924848fc75c3d18d48bb24edf8a08ab143984e08335c6e293a4d69',1987,'EH','Western Sahara','government',746,'Official name: Western Sahara
Type: legal status of territory and question
of sovereignty unresolved; territory con-
tested by Morocco, an insurgent group
(Popular Front for the Liberation of the
Saguia el Hamra), and Polisario (Rio de
Oro); territory partitioned between Mo-
rocco and Mauritania in April 1976, with
Morocco acquiring northern two-thirds;
Mauritania, under pressure from Polisario
guerrillas, abandoned all claims to its
portion in August 1979; Morocco moved to
occupy that sector shortly thereafter and
has since asserted administrative control;
the Polisario''s government in exile was
seated as an OAU member in 1984; guer-
rilla activities continue to the present
Government leader: Mohamed
ABDELAZIZ, President, Sahara Demo-
cratic Arab Republic (since October 1982),
and secretary general, Polisario (since
August 1976)
Official name: Independent State of
Western Samoa
Type: constitutional monarchy under
native chief
Capital: Apia
Administrative divisions: 11] districts
Legal system: based on English common
Jaw and local customs; constitution came
into effect upon independence in 1962;
judicial review of legislative acts with
respect to fundamental rights of the citi-
zen; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1
January
Branches: Head of State and Executive
Council; unicameral legislature
(47-member Legislative Assembly), Su-
preme Court, Court of Appeal, Land and
Titles Court, village courts
Government leaders: MALIETOA
Tanumafili [1, Head of State (since 1962);
Va’ai KOLONE, Prime Minister (since
December 1985)
Suffrage: 45 members of Legislative As-
sembly are elected by holders of matai
(heads of family) titles (about 12,000 per-
sons); two members are elected by univer-
sal adult suffrage of persons lacking tradi-
tional family ties
Elections: held triennially; last held in
February 1982
Political parties and Jeaders: no clearly
defined structure
Communists: unknown
Member of: ADB, Commonwealth,
ESCAP, FAO, G-77, IBRD, IDA, IFAD,
IFC, IMF, South Pacific Commission, SPF,
UN, UNESCO, WHO
. Western Samoa (continued)
Official name: Yemen Arab Republic
Type: republic; military regime assumed
power in June 1974
Capital: Sanaa
Administrative divisions: 1] provinces
Legal system: based on Turkish law,
Islamic law, and local customary law; first
constitution promulgated December 1970,
suspended June 1974; has not accepted
compulsory ICJ jurisdiction
National holiday: Proclamation of the
Republic, 26 September
Branches: President, Prime Minister,
Cabinet; People’s Constituent Assembly
Government leaders: Col. ‘Ali ‘Abdallah
SALIH, President (since 1978); ‘Abd al-
‘Aziz ‘ABD AL-GHANI, Prime Minister
(since 1983)
Communists: small number
Political parties or pressure groups: no
legal politica) parties; in 1983 President
Salih started the General People’s Con-
gress, which is designed to function as the
country’s sole political party; conservative
tribal groups, Muslim Brotherhood, and
leftist factions—pro-Iraqi Ba‘thists, Nasir-
ists, National Democratic Front (NDF)
supported by South Yemen—exert political
influence
Member of: Arab League, FAO, G-77,
IBRD, ICAO, IDA, IDB—lIslamic Devel-
opment Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, ITU,
NAM, OIC, UN, UNESCO, UPU, WFTU,
WHO, WIPO, WMO','40e2b42efc12e02c8e9c2a024a1535ca55ea8101a4dfc9ccf12b8891aca21741','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce82a2e3c5ede9c1760485791aa2bbc1ca096ea633306172bd7b139f11df7715',1987,'ZM','Zambia','government',753,'Official name: Republic of Zambia
Type: one-party state
Capital: Lusaka
Administrative divisions: nine provinces
Legal system: based on English common
law and customary law; new constitution
adopted September 1973; judicial review
of legislative acts in an ad hoc constitu-
tional council; has not accepted compul-
sory ICJ jurisdiction
National holiday: Independence Day, 24
October
Branches: modified presidential system;
unicameral legislature (National Assembly),
judiciary
Government leaders; Dr. Kenneth David
KAUNDA, President (since October 1964);
Kebby MUSOKOTWANE, Prime Minister
(April 1985)
Suffrage: universal adult at age 18
Elections: general election held 27 Octo-
ber 1983; next general election scheduled
for 1988
Political parties and leaders: United
National Independence Party (UNIP),
Kenneth Kaunda; former opposition party
banned in December 1972 when one-party
state proclaimed
Voting strength: (1983 election) 63.5% of
eligible voters participated; Kaunda, the
only candidate for president, received a
93% yes vote; National Assembly seats
were contested by members of UNIP
Communists: no Communist party
Member of: AfDB, Commonwealth, FAO,
G-77, GATT (de facto), IAEA, IBRD,
1CAO, IDA, IEA, IFAD, IFC, ILO, IMF,
INTELSAT, International Lead and Zinc
Study Group, INTERPOL, IPU, ITU,
NAM, OAU, SADCC, UN, UNESCO,
UPU, WHO, WIPO, WMO, WTO
272','3a9efa03355c6eb54cd1df03ecd7d33f56a0dd0e21b2a2c2e33e8e79a4411d5e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32183b810666a1fdf3804b5e739e8a6ca5ccc2939f90849814d368d219a381b6',1987,'ZW','Zimbabwe','government',758,'Official name: Republic of Zimbabwe
Type: independent, British-style parlia-
mentary democracy
Capital; Harare
Administrative divisions: 8 provinces
Legal system: Roman-Dutch
Branches: legislative authority resides in a
Parliament consisting of a 100-member
House of Assembly (with 20 seats reserved
for whites) and a 40-member Senate (10
elected by white members of the House,
14 elected by the other members of the
House; 10 chiefs, 5 from Mashonaland and
5 from Matabeleland, elected by members
of the Council of Chiefs; 6 appointed by
the President, on the advice of the Prime
Minister); executive authority lies with a
Cabinet led by the Prime Minister; the
High Court is the superior judicial
authority
Government leaders: Rev. Canaan
Sodindo BANANA, President (since April
1980), Robert Gabriel MUGABE, Prime
Minister (since April 1980)
Suffrage: universal over age 18; for at least
seven years after independence (1980),
white, mixed, and Asians vote on a sepa-
rate roll for 20 seats in the House of As-
sembly
Elections: last held July 1985
Political parties and leaders: Zimbabwe
African National Union (ZANU), Robert
Mugabe; Zimbabwe African People''s
Union (ZAPU), Joshua Nkomo; Conserva-
tive Alliance of Zimbabwe (CAZ), Ian
Smith; Independent Zimbabwe Group
(1ZG), Bill Irving; Zimbabwe African
National Union - Sithole (ZANU-S),
Ndabaningi Sithole; others failed to win
any seats in Parliament
Zimbabwe (continued)
Voting strength: (July 1985 elections)
ZANU (also known as ZANU-PF), 64 seats;
ZAPU, 15 seats; CAZ, 15 seats; 1ZG, 4
seats, ZANU-S, 1 seat; independents, 1
Communists: no Communist party
Member of: AfDB, Commonwealth, FAO,
G-77, GATT, IBRD, ICAO, IDA, IFAD,
IFC, ILO, IMF, INTERPOL, ITO, NAM,
OAU, SADCC, UN, UNESCO, UPU,
WFTU, WHO, WMO
The West Bank and the Gaza Strip are
currently governed by Israeli military
authorities and their civil administrations.
It is US policy that the final status of these
areas will be determined by negotiations
among the concerned parties. These nego-
tiations will determine how this area is to
be governed.','5bfd25182d71f5bcb923d874c5ef804c47dd54d2f812df5ee47e7bbc2c0d9409','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d882b3d52dc3c87408f44ed40e67a92068140f0ec1c88a03be08b6208bde1fe',1987,'AF','Afghanistan','geography',4,'Total area: 647,500 km?; land area:
647,500 km?
Comparative area: about the size of Texas
Land boundaries: 5,510 km total
Boundary disputes: none; Pushtunistan
and Baluchistan questions with Pakistan;
periodic disputes with lran over Helmand
water rights
Climate: arid to semiarid; cold winters
and hot summers
Terrain: mostly rugged mountains; plains
in north and southwest
Land use: 12% arable land; NEGL%
permanent crops; 46% meadows and
pastures; 3% forest and woodland; 39%
other; includes NEGL% irrigated
Environment: damaging earthquakes
occur in Hindu Kush mountains; soil
degradation, desertification, overgrazing,
deforestation, pollution
Special notes: landlocked; narrow and
strategic Vakhan (Wakhan Corridor) pro-
vides direct access to China and separates
Pakistan from USSR','9d57d0931ab85f33a15ac738a8b44ec99bfe1d546007aa029d89d56af1d62ccd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8daef5a461eb2eedc9f47c16006e1ea46e99308cb7b3d205ebb9dfbb5408b0bd',1987,'AL','Albania','geography',10,'Total area: 28,750 km?; land area: 27,400
km?
Comparative area: slightly larger than
Maryland
Land boundaries: 716 km total
Coastline: 362 km
Maritime claim:
Territorial sea: 15 nm
Boundary disputes: none; Kosovo question
with Yugoslavia; Northern Epirus question
with Greece
Climate: mild temperate; cool, cloudy,
wet winters ; hot, clear, dry summers;
interior is cooler and wetter
Terrain: mostly mountains and hills; small
plains along coast
Land use: 21% arable land; 4% permanent
crops; 15% meadows and pastures; 38%
forest and woodland; 22% other; includes
1% irrigated
Environment: subject to destructive earth-
quakes; tsunami occur along southwestern
coast; deforestation
Special notes: strategic location on Strait
of Otranto linking Adriatic Sea to Mediter-
ranean Sea','16a73c1f3085da376416a73e529f2c124e5389fd21d547669176971f10d6a515','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc877651c3802553c640549bdc5671f785544b5be59575833552403cab120bd8',1987,'DZ','Algeria','geography',15,'Total area: 2,381,740 km?; land area:
2,381,740 km?
Comparative area: more than three times
the size of Texas
Land boundaries: 6,260 km total
Coastline: 998 km
Maritime claim:
Territorial sea: 12 nm
Climate: arid to semiarid; mild, wet
winters with hot, dry summers along coast;
drier with cold winters and hot summers
on high plateau; sirocco is a hot,
dust/sand-laden wind especially common
in summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Land use: 3% arable land; NEGL% per-
manent crops; 13% meadows and pastures;
2% forest and woodland; 82% other; in-
cludes NEGL% irrigated
Environment: mountainous areas subject
to severe earthquakes; desertification
Special notes: second largest country in
Africa (after Sudan)','8312bfce4392940573cb789a4058d13d02c68bb34c359a25f5a9550d35f3117c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3652d5bb1b07f1490cc49b12bb0ef90ef2b3ab2dbae2787e5b0f5f1e1652c26',1987,'AD','Andorra','geography',19,'Total area: 450 km?; land area: 450 km?
Comparative area: about two and one-
half times the size of Washington, D.C.
Land boundaries: 105 km total
Climate: temperate; snowy, cold winters
with cool, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Land use: 2% arable land; 0% permanent
crops; 56% meadows and pastures; 22%
forest and woodland; 20% other
Environment: deforestation, overgrazing
Special notes: landlocked','28e8ceddeb5ff94302e497957f720f57df89e1bdf45d03e1ff0254d0d552fb2d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb8bd2557c3fd65ede8c9c5ed2f914f0061d2224e3ada82400be5fffd463548f',1987,'AO','Angola','geography',26,'Total area: 1,246,700 km?; land area:
1,246,700 km?
Comparative area: almost twice the size
of Texas
Land boundaries: 5,070 km total
Coastline: 1,600 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 20 nm
Climate: semiarid in south and along coast
to Luanda; north has cool, dry season (May
to October) and hot, rainy season (Novem-
ber to April)
Terrain: narrow coastal plain rises
abruptly to vast interior plateau
Land use: 2% arable land; NEGL% per-
manent crops; 23% meadows and pastures;
43% forest and woodland; 31% other
Environment: locally heavy rainfall causes
periodic flooding on plateau; desertification
Special notes: Cabinda is separated from
rest of country by Zaire','7c09734f08aaf862466a59c52b4e9359098162436466a89b502ba9cc8100b29a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1d61e256604f21dd3f776b8246b2e7539206dc160784a77b69121b7ff29fd22',1987,'AI','Anguilla','geography',31,'Total area: 9] km?; land area: 91 km?
Comparative area: about one-half the size
of Washington, D.C.
Coastline: about 6] km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
mostly rock with sparse scrub oak, few
trees, some commercial salt ponds
Environment: frequent hurricanes, other
tropical storms (July to October)
Special notes: northernmost of Leeward
Islands','830810aa8c57de9fe1efbb834cbfa5ef3d4ba9e3889376f27aa42ba360ee3fc2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc31c7bed97a0f8c867f5c45c81a6e43858ee7666783cc16a12ef42bd6a5dbe',1987,'AG','Antigua and Barbuda','geography',36,'Total area: 440 km?; land area: 440 km?
Comparative area: about two and one-
half times the size of Washington, D.C.
Coastline: 153 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: mostly low-lying with some
higher volcanic areas
Land use: 18% arable land; 0% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 59% other
Environment: subject to hurricanes and
tropical storms (June to October); insuffi-
cient freshwater resources; deeply in-
dented coastline provides many natural
harbors
Special notes: about 650 km from Puerto
Rico','c0eee42c98a8ca4a965f8c02d9ae9b057c66473be0be3bdb5517fe8bbdb9d0c4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cbb5340f6ce66d6e434bfc3f847c0b8e907d457d65045f07e939d70882d7dff',1987,'AR','Argentina','geography',41,'Total area: 2,766,890 km?; land area:
2,736,690 km?
Comparative area: about four times the
size of Texas
Land boundaries: 9,414 km total
Coastline: 4,989 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Uruguay; short section
with Chile is indefinite; claims Falkland
Islands (Islas Malvinas) which are adminis-
tered by UK; territorial claim in Antarc-
tica
Climate: mostly temperate; arid in south-
east; subantarctic in southwest
Terrain: rich plains of the Pampas in
northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
Land use: 9% arable land; 4% permanent
crops; 52% meadows and pastures; 22%
forest and woodland; 13% other; includes
1% irrigated
Environment: Tucuman and Mendoza
areas in Andes subject to earthquakes;
pamperos are violent windstorms that can
strike Pampas and northeast; irrigated soil
degradation; desertification
Special notes: second Jargest country in
South America (after Brazil); strategic
9
location relative to sea lanes between
Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage)','ec324ed3fa9ae8d562b7eee2fee70fdd56abb314131c9c8e6d7c6004722837c8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024bc7715b8a740421feca919d1b6de19a19c5287c517a3194936622fb8867f8',1987,'AW','Aruba','geography',46,'Total area: 193 km?; land area: 193 km?
Comparative area: slightly larger than
Washington, D.C.
Coastline: about 72 km
Maritime claims:
Territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills; scant vegeta-
tion
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: lies outside the Caribbean
hurricane belt
Special notes: 28 km from Venezuela','08f433deec968d2e4c6b3d8cfea84cb00926c63033b359a66cb7a3b6b9b86312','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4221804582c8c5d657ab57c9796ec9f06e28965464f3665fca1ecacf10e5891',1987,'AU','Australia','geography',51,'Total area: 7,686,850 km?; land area:
7,617,930 km?
Comparative area: almost as large as
conterminous US
Coastline: 25,760 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with Indonesia; territorial claim in
Antarctica (Australian Antarctic Territory)
Climate: generally arid to semiarid; tem-
perate in south and east; tropical in north
Terrain: mostly low plateau with deserts;
fertile plain in southeast
Land use: 6% arable land; NEGL% per-
manent crops; 58% meadows and pastures;
14% forest and woodland; 22% other;
includes NEGL% irrigated
Environment: subject to severe droughts
and floods; cyclones along coast; limited
freshwater availability; irrigated soil degra-
dation; regular, tropical, invigorating, sea
breeze known as the doctor occurs along
west coast in summer; desertification
Special notes: world’s smallest continent
but sixth largest country','7cc61371ffaf9826d17e2abb57a81a0f5a317881a76fd12626d014303ae25565','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea778ca7ac5237f1f8d3281b3e09703bbd02644d935153eac7a1038285cae459',1987,'AT','Austria','geography',56,'Total area: 83,850 km?; land area: 82,730
km?
Comparative area: slightly smaller than
Maine
Land boundaries: 2,582 km total
Boundary disputes: none; South Tyrol
question with Italy
Climate: temperate; continental, cloudy;
cold winters with frequent rain in low-
lands and snow in mountains; cool sum-
mers with occasional showers
Terrain: mostly mountains with Alps in
west and south; low local relief and gentle
slopes along eastern and northern margins
Land use: 17% arable land; 1% permanent
crops; 24% meadows and pastures; 39%
forest and woodland; 19% other; includes
NEGL® irrigated
Environment: due to steep slopes, poor
soils, and cold temperatures, population is
concentrated on eastern lowlands
Special notes: landlocked; strategic loca-
tion at the crossroads of central Europe
with many easily traversable Alpine passes
and valleys
Total area: 13,940 km?; land area: 10,070
km?
Comparative area: about the size of
Connecticut
Coastline: 3,542 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine; moderated by
warm waters of Gulf Stream
Terrain: long, flat, coral formations with
some low, rounded hills
Land use: 1% arable land; NEGL% per-
manent crops; NEGL% meadows and
pastures; 32% forest and woodland; 67%
other
Environment: subject to hurricanes and
other tropical storms; archipelago of about
700 islands and keys
Special notes: strategic location adjacent
to US and Cuba','26d58fded279770552fdbbd96621307a566ed135c6d02e804160fd8afd310005','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('706a4143cd3256bb8a761e8c616b8f96fd525b77769cb6f1cc8c0446fbb05fd0',1987,'BH','Bahrain','geography',61,'Total area: 620 km?; land area: 620 km?
Comparative area: about three times the
size of Washington, D. C.
Coastline: 161 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 8 nm
Boundary disputes: none; territorial dis-
pute with Qatar over the island of Hawar
and its ring of islets
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain: mostly low desert plain rising
gently to low central escarpment
Land use: 2% arable land; 2% permanent
crops; 6% meadows and pastures; 0% forest
and woodland; 90% other; includes
NEGL% irrigated
Environment: subsurface water sources
being rapidly depleted (requires develop-
ment of desalination facilities); dust storms;
desertification
Special notes: close proximity to primary
Middle East crude oil sources and strategic
location in Persian Gulf through which
much of western world’s crude oil must
transit to reach open ocean','990f34b8ce4e490009f5f0178c36c9c0ae2d9ac3eb23983466f2615c08194978','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a813c3ce3b6758d1798ff26994b6ab3c91198814722d899cf8ddaef9ad04450',1987,'BD','Bangladesh','geography',68,'Total area: 144,000 km?; land area:
133,910 km?
Comparative area: slightly smaller than
Wisconsin
Land boundaries: 2,535 km total
Coastline: 580 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: up to outer limits of
continental margin
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: India
Climate: tropical; cool, dry winter (Octo-
ber to March); hot, humid summer (March
to June); cool, rainy monsoon (June to
October)
Terrain: mostly flat alluvial plain; hilly in
southeast
Land use: 67% arable land; 2% permanent
crops; 4% meadows and pastures; 16%
forest and woodland; 11% other; includes
14% irrigated
Environment: vulnerable to droughts;
much of country routinely flooded during
summer monsoon season; overpopulation;
deforestation
Special notes: almost completely sur-
rounded by India; Joint River Commission
on water sharing with upstream riparian','7ad3e2c3278982e717be8c0251393b05ed4a3a8270723afbbf1879f595a67997','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23f880f7b01ff8db1acc1fceacc8517278776ed98fffe3eb61fb3c4016482c85',1987,'IN','India','geography',69,'Bangladesh (continued)
Total area: 3,287,590 km?; land area:
2,973,190 km?
Comparative area: about one-third the
size of US
Land boundaries: 12,700 km total
Coastline: 7,000 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12
Boundary disputes: Bangladesh, China,
Cease-Fire Line with Pakistan
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the Ganges
River, deserts in west, Himalayas in north
Land use: 55% arable land; 1% permanent
crops; 4% meadows and pastures; 23%
forest and woodland; 17% other; includes
18% irrigated
Environment: droughts, flash floods, severe
thunderstorms common; deforestation; soil
erosion; overgrazing; air and water pollu-
tion; desertification
Special notes: dominates South Asian
subcontinent; near important Indian
Ocean trade routes; Joint River Commis-
sion on water sharing with downstream
riparian Bangladesh','4693192e028d736809ebdf384525980f1e8107d9a6b2fd3eb1ec1ab2afc6a51a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('336e129dd2b0f2370fa0584e203f0311844b5d5730716786676c6790f3316052',1987,'BB','Barbados','geography',75,'Total area: 430 km?; land area: 430 km?
Comparative area: about twice the size of
Washington, D. C.
Coastline: 97 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea; 12 nm
Climate: tropical; rainy season (June to
November)
Terrain: relatively flat; rises gently to
central highland region
Land use: 77% arable land; 0% permanent
crops; 9% meadows and pastures; 0% forest
and woodland; 14% other
Environment: subject to hurricanes (espe-
cially June to November)
Special notes: easternmost Caribbean
island','a7512e72e8348721acf15c5585a258b911365202f6dfc6491e758937191d0eae','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14e07dc89561dafdf276b722575355057333382302f95c2b79e907752331236',1987,'BE','Belgium','geography',80,'Total area: 30,510 km?; land area: 30,230
km?
Comparative area: slightly larger than
Maryland
Land boundaries: 1,377 km total
Coastline: 64 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate; mild winters, cool
summers; rainy, humid, cloudy
Terrain: flat coastal plains in northwest,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other; includes
NEGL®% irrigated
Environment: air and water pollution
Special notes: majority of West European
capitals within 1,000 km of Brussels;
crossroads of Western Europe','83c6af26c64779c606b4bb49b21bdd2dce628bce1ba68594f1e4f50d78e01448','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0791837075cd1ef3e8c3112b9c094199e87a5d0822e532512d59cb78506097a5',1987,'BZ','Belize','geography',84,'Total area: 22,960 km?; land area: 22,800
km?
Comparative area: slightly larger than
Massachusetts
Land boundaries: 515 km total
Coastline: 386 km
Maritime claim:
Territorial sea: 3 nm
Boundary disputes: none; claimed by','ea33cb4c15501a5f8a413a7cfec8e76d625ef830a1ea8793ae7914aee7ab44a4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aca8f3bf2f3e16d215ee7152b9fd64fe7daf4fe6099bd99a4884bd0845283ff',1987,'GT','Guatemala','geography',85,'Climate: tropical; very hot and humid;
rainy season (May to February)
Terrain: flat, swampy coastal plain; low
mountains in south
Land use: 2% arable land; NEGL% per-
manent crops; 2% meadows and pastures;
44% forest and woodland; 52% other;
includes NEGL% irrigated
Environment: frequent devastating hurri-
canes (September to December) and
coastal flooding (especially in south); defor-
estation
Special notes: national capital moved 80
km inland from Belize City to Belmopan
because of hurricanes; only country in
Central America without a coastline on the
Pacific Ocean
Total area: 108,890 km?; land area:
108,430 km?
Comparative area: about the size of
Tennessee
Land boundaries: 1,625 km total
Coastline: 400 km
Maritime claims:
Continental shelf: not specific
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims Belize
Climate: tropical; hot, humid in lowlands;
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone plateau
(Petén)
Land use: 12% arable land; 4% permanent
crops; 12% meadows and pastures; 40%
forest and woodland; 32% other; includes
1% irrigated
Environment: numerous volcanoes in
mountains with frequent violent earth-
quakes; Caribbean coast subject to hurri-
canes and other tropical storms; deforesta-
tion; soil erosion; water pollution
Special notes: no natural harbors on west
coast','7dabdcf8a22e16fbce4ca58db75b9e5bf7fd3834c138512acda10e0bc805cc98','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cfd51ab4feeda6c09cf809c35eaf5bff3608c1dffac3eb9aaa3b55013279ddd',1987,'BJ','Benin','geography',91,'Total area: 112,620 km?; land area:
110,620 km?
Comparative area: slightly smaller than
Pennsylvania
Land boundaries: 1,963 km total
Coastline: 121 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid in south;
arid in north
Terrain: mostly flat to undulating plain;
some hills and low mountains
Land use: 12% arable land; 4% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 45% other; includes
NEGL% irrigated
Environment: hot, dry, dusty harmattan
wind may affect north in winter; defores-
tation; desertification
Special notes: recent droughts have se-
verely affected marginal agriculture in
north; no natural harbors
Total area: 923,770 km/?; land area:
910,770 km?
Comparative area: more than twice the
size of California
Land boundaries: 4,034 km total
Coastline: 853 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 30 nm
Boundary disputes: none; sporadic border
dispute with Cameroon
Climate: varies—equatorial in south,
tropical in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Land use: 31% arable land; 3% permanent
crops; 23% meadows and pastures; 15%
forest and woodland; 28% other; includes
NEGL% irrigated
Environment: recent droughts in north
severely affecting marginal agricultural
activities; desertification; soil degradation
Special notes: none','b6c9d8e0f1d5088c48a0edea07e8e9ab445b5ffde58b20445635dfe50444c968','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dbd177acc9a16cb24d385718e2838f98c67bcc4e39aed8a935443f4fe491e1d',1987,'BM','Bermuda','geography',96,'Total area: 50 km?; land area: 50 km?
Comparative area: about one-third the
size of Washington, D.C.
Coastline; 103 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: subtropical; mild, humid; gales,
strong winds common in winter
Terrain: low hills separated by fertile
depressions
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 20%
forest and woodland; 80% other; includes
11% leased for military bases
Environment: ample rainfall, but no rivers
or freshwater lakes; consists of about 360
small coral islands
Special notes: 1,050 km east of North
Carolina; some reclaimed land leased by
US Government','403dbca9fd574738ec62b509911cc7efe90574d54f4cbf79fda5d4a179ced529','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba838eccd8b32ade3636bb2c08b69e141afd2b29957a2b347fe25437e469f39e',1987,'BT','Bhutan','geography',101,'Total area: 47,000 km?; land area: 47,000
km?
Comparative area: the size of Vermont
and New Hampshire combined
Land boundaries: 870 km total
Climate: varies; tropical in southern
plains; cool winters and hot summers in
central valleys; severe winters and cool
summers in Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Land use: 2% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
70% forest and woodland; 23% other
Environment: violent storms coming down
from the Himalayas were the source of the
country name which translates as Land of
the Thunder Dragon
Special notes: landlocked; strategic loca-
tion between China and India; controls
several key Himalayan mountain passes
Total area: 1,098,580 km: land area:
1,084,390 km?
Comparative area: about the size of
California and Texas combined
Land boundaries: 6,083 km total
Boundary disputes: none; has wanted a
sovereign corridor to the Pacific Ocean
since Atacama area was lost to Chile in
1884; dispute with Chile over Rio Lauca
water rights
Climate: varies with altitude; humid and
tropical to cold and semiarid
Terrain: high plateau, hills, lowland plains
Land use: 3% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
52% forest and woodland; 20% other;
includes NEGL% irrigated
Environment: cold, thin air of high pla-
teau makes physical activity very difficult;
overgrazing; soi] erosion; desertification
Special notes: landlocked; shares control
of Lago Titicaca, world’s highest navigable
lake, with Peru','0287f0f5c8e0b78a43dd0c5e14c8feb314cf770c38dc8b7270cb1dfd966b132a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e2b593c7883d05a89d2f438e36590f3870ac4d9a28913736c4b6d01b98656b',1987,'BW','Botswana','geography',106,'Total area: 600,370 km?; land area:
585,370 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 3,774 km total
Boundary disputes: short section with
Namibia is indefinite
Climate: tropical; warm winters and hot
summers
Terrain: predominately flat to gently
rolling tableland
Land use: 2% arable land; 0% permanent
crops; 75% meadows and pastures; 2%
forest and woodland; 21% other; includes
NEGL% irrigated
Environment: continuing drought severely
affecting important cattle industry; over-
grazing; desertification
Special notes: landlocked; very long
boundary with South Africa','4858a3de834e8870ee69eb5340a739ad40a4ddca597534f05530b6fba8f65470','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a2e1ae56ed54aa9c6c96e6ff6ff46b99132537642845d0bd48fac99bc7317f9',1987,'BR','Brazil','geography',111,'Total area: 8,511,970 km?; land area:
8,456,510 km?
Comparative area: larger than contermi-
nous US
Land boundaries: 13,076 km total
Coastline: 7,491 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm
Boundary disputes: Paraguay (Rio Parana
area), Uruguay; claims a Zone of Interest
in Antarctica
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Land use: 7% arable Jand; 1% permanent
crops; 19% meadows and pastures; 67%
forest and woodland; 6% other; includes
NEGL% irrigated
Environment: recurrent droughts in north-
east; floods and frost in south; deforestation
in Amazon basin
Special notes: largest country in South
America; shares common boundaries with
every South American country except
Chile and Ecuador
Total area: 80 km?; land area: 80 km?
Comparative area: less than one-half the
size of Washington, D.C.
Coastline: about 120 km
Maritime claim:
Territorial sea: 8 nm
Boundary disputes: none; Diego Garcia
claimed by Mauritius
Climate: tropical marine; hot, humid,
moderated by trade winds
Terrain: flat and low (up to 4 meters in
elevation)
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: consists of 2,300 islands
Special notes: Diego Garcia, largest and
southernmost island, occupies strategic
location in central Indian Ocean
Total area: 150 km?; land area: 150 km?
Comparative area: about the size of
Washington, D. C.
Coastline; 80 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 8 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volca-
nic islands steep, hilly
Land use: 20% arable land; 7% permanent
crops; 838% meadows and pastures; 7%
forest and woodland; 33% other
Environment: subject to hurricanes and
tropical storms
Special notes: strong ties to nearby US
Virgin Islands and Puerto Rico
Total area: 5,770 km?; land area: 5,270
km?
Comparative area: slightly larger than
Delaware
Land boundary: 381 km with Malaysia
Coastline: 161 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; possible territo-
rial claim in complex dispute over Spratly
Islands involving China, Malaysia, Philip-
pines, Taiwan, and Vietnam
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to moun-
tains in east; hilly lowland in west
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 79%
forest and woodland; 18% other; includes
NEGL®% irrigated
Environment: typhoons, earthquakes, and
severe flooding are rare
Special notes: close to vital sea lanes
through South China Sea linking Indian
and Pacific Oceans; two parts physically
separated by Malaysia; almost an enclave
of Malaysia','13e4d5937e7e38e1631e171e4792688ad3622bb490e8f40ef0ed0775ecf582c8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fcc21e8197ddedb81679768fcaf45745d51b1d29977eb8db685bdcb47c95f25',1987,'BG','Bulgaria','geography',116,'Total area: 110,910 km?; land area:
110,550 km?
Comparative area: slightly larger than
Ohio
Land boundaries: 1,883 km total
Coastline: 354 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Macedonia
question with Greece and Yugoslavia
Climate: temperate; cold, damp winters,
hot, dry summers
Terrain: mostly mountains with lowlands
in north and south
Land use: 34% arable land; 3% permanent
crops; 18% meadows and pastures; 35%
forest and woodland; 10% other; includes
11% irrigated
Environment: subject to earthquakes,
landslides; deforestation
Special notes: strategic location near
Turkish Straits; controls key land routes
from Europe to Middle Fast and Asia
Total area: 274,200 km?; land area:
273,800 km?
Comparative area: about the size of
Colorado
Land boundaries: 3,307 km total
Climate: tropical; warm, dry winters; hot,
wet summers
Terrain: mostly flat to dissected, undulat-
ing plains; hills in south
Land use: 10% arable land; NEGL%
permanent crops; 87% meadows and
pastures; 26% forest and woodland; 27%
other; includes NEGL% irrigated
Environment: recent droughts and deserti-
fication severely affecting marginal agri-
cultural activities, population distribution,
economy; overgrazing; deforestation
Special notes: landlocked
Total area: 676,550 km?; land area:
657,740 km?
Comparative area: nearly as large as
Texas
Land boundaries: 5,850 km total
Coastline: 3,060 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical monsoon; cloudy, rainy,
hot, humid summers (southwest monsoon,
June to September); less cloudy, scant
rainfall, mild temperatures, lower humid-
ity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep,
tugged highlands
Land use: 15% arable land; 1% permanent
crops; 1% meadows and pastures; 49%
forest and woodland; 34% other; includes
2% irrigated
Environment: subject to destructive earth-
quakes and cyclones; flooding and land-
slides common during rainy season (June
to September); deforestation
Special notes: strategic location near
major Indian Ocean shipping lanes
37','9ed80af2f2c615b4bfbbdc0104d5e4dd064a806b59a54acace03dc51148d8ee4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd408fd52c814673c5884be1340f9d2b4db1e32e25cd9b3b555fe59a6b21761',1987,'BI','Burundi','geography',121,'Total area: 27,830 km; land area: 25,650
km?
Comparative area: about the size of
Maryland
Land boundaries: 974 km total
Climate: temperate; warm; occasional frost
in uplands
Terrain: mostly rolling to hilly highland;
some plains
Land use: 43% arable land; 8% permanent
crops; 35% meadows and pastures; 2%
forest and woodland; 12% other; includes
NEGL% irrigated
Environment: soil exhaustion; soil erosion;
deforestation
Special notes: landlocked; straddles crest
of the Nile-Congo watershed','57ead14255ca6ddfab00793293c11461146388a7a01fc318bbba10b500e72678','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8bdc6bfffd4216d428917363874a6d1aec2820de3826309abac639b1b215725',1987,'TH','Thailand','geography',126,'Total area: 181,040 km?; land area:
176,520 km?
Comparative area: the size of Missouri
Land boundaries: 2,438 km total
Coastline: 443 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Extended economic zone: 200 nm
Terrttortal sea: 12 nm
Boundary disputes: Vietnam (three areas);
occupied by Vietnam
Climate: tropical; rainy, monsoon season
(May to October); dry season (December to
March); little seasonal temperature varia-
tion
Terrain: mostly low, flat plains; mountains
in southwest and north
Land use: 16% arable land; 1% permanent
crops; 3% meadows and pastures; 76%
forest and woodland; 4% other; includes
1% irrigated
Environment: a land of paddies and
forests dominated by Mekong River and
Tonle Sap
Special notes: buffer between Thailand
and Vietnam
Total area: 514,000 km?: land area:
511,770 km?
Comparative area: about the size of Texas
Land boundaries: 4,868 km total
Coastline: 3,219 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy, warm, cloudy
southwest monsoon (mid-May to October);
dry, cool northeast monsoon (November to
mid-March); southern isthmus always hot
and humid
Terrain: central plain; eastern plateau
(Khorat); mountains elsewhere
Land use: 34% arable land; 4% permanent
crops; 1% meadows and pastures; 30%
forest and woodland; 31% other; includes
7% irrigated
Environment: air and water pollution;
land subsidence in Bangkok area
Special notes: controls only land route
from Asia to Malaysia and Singapore
Total area: 329,560 km?; land area:
$25,360
Comparative area: about the size of New','c545af49bcdf3df7a31819bd8fb9ea455aafa86afa3c0b57edfea9c6d5287aae','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9092ef8dac3bbd9b3af3f06f5b198126d579712bc721c6fb9758df726a6c651',1987,'CM','Cameroon','geography',131,'Total area: 475,440 km?; land area:
469,440 km?
Comparative area: slightly larger than
California
Land boundaries: 4,554 km total
Coastline: 402 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 50 nm
Boundary disputes: none; sporadic border
dispute with Nigeria
Climate: varies with terrain from tropical
along coast to semiarid and hot in north
Terrain: diverse with coasta] plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Land use: 13% arable land; 2% permanent
crops; 18% meadows and pastures; 54%
forest and woodland; 13% other; includes
NEGL% irrigated
Environment: recent volcanic activity
with release of poisonous gases; deforesta-
tion; overgrazing; desertification
Special notes: sometimes referred to as
the hinge of Africa','6afb17407f33aa39419024f4bf59bfde5213d6854e9540cf9742703dc0c80277','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb749b4a553dbecb6a6d772fb5a8fe911dabb18f4c6f06be2eb150bb44d3052',1987,'CA','Canada','geography',136,'Total area: 9,976,140 km?; land area:
9,220,970 km?
Comparative area: slightly larger than US
Land boundaries: 9,010 km total
Coastline: 243,791 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
putes with France, US
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Land use: 5% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
35% forest and woodland; 57% other;
includes NEGL% irrigated
Environment: 80% of population concen-
trated within 160 km of US border; con-
tinuous permafrost in north a serious
obstacle to development
Special notes: second largest country in
world; strategic location between USSR
and US via polar route
Total area: 4,030 km?; land area: 4,030
km?
Comparative area: slightly larger than
Rhode Island
Coastline; 965 km
Maritime claim: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: temperate; warm, dry, summer
precipitation very erratic
Terrain: steep, rugged, rocky, volcanic
Land use: 9% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
NEGL% forest and woodland; 85% other;
includes 1% irrigated
Environment: subject to prolonged
droughts; harmattan wind can obscure
visibility; volcanically and seismically
active; deforestation; overgrazing
Special notes: strategic location 500 km
from African coast near major north-south
sea routes; important communications
station; important sea and air refueling site','7a11ab7840f2647cc3705f40f9a230625e03ce32544c900803847409ef1847f6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6cba7af64eaa3b25b59c8ebfb1f49265f83d139fb97f6de7500f5a0306002b8',1987,'KY','Cayman Islands','geography',141,'Total area: 260 km2; land area: 260 km?
Comparative area: less than twice the size
of Washington, D. C.
Coastline: 160 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical marine with warm
summers and cool winters
Terrain: low lying limestone base sur-
rounded by coral reefs
Land use: 0% arable land; 0% permanent
crops; 8% meadows and pastures; 23%
forest and woodland; 69% other
Environment: within the Caribbean hurri-
cane belt, but rarely affected
Special notes: important location between
Cuba and Central America','28ed5efc17768dd5781f93cd050ddb340d584232a9a6690adf732d66ff384507','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('976ccd88671b378c0450c3866de502fbc585df4bf2b7f484c1b0268dba47116d',1987,'CF','Central African Republic','geography',146,'Total area: 622,980 km?; land area:
622,980 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 4,981 km total
Climate: tropical; hot, dry winters; mild to
hot, humid, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
southwest
Land use: 3% arable land; NEGL% per-
manent crops; 5% meadows and pastures;
64% forest and woodland; 28% other
Environment: hot, dry, dusty harmattan
winds affect northern areas; poaching has
diminished reputation as one of last great
wildlife refuges; desertification
Special notes: landlocked; almost the
precise center of Africa','11016365b92e012bc3c1761888600b98a3d772d00610c94a40421d0ad164f11f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1f2c181b6990f5eba8a870fe4d4d73ba24ed71f928d4f2bb91e86b0d773e65c',1987,'TD','Chad','geography',151,'Total area: 1,284,000 km?; land area:
1,259,200 km?
Comparative area: slightly larger than
Texas and California combined
Land boundaries: 5,987 km total
Boundary disputes: none; Libya claims
Aozou Strip in far north; Libyan troops
occupy northern Chad
Climate: tropical in south gradually be-
coming dry desert in north
Terrain: broad, arid plains in center,
desert in north, mountains in northwest,
lowlands in south
Land use: 2% arable land; NEGL% per-
manent crops; 36% meadows and pastures;
11% forest and woodland; 51% other;
includes NEGL% irrigated
Environment: hot, dry, dusty harmattan
winds occur in north; recent drought and
desertification adversely affecting south
Special notes: landlocked; Lake Chad
most significant water body in Sahel','8ad4f8228bdffefbaa139f465ddc47b36cd375213251e8ab2ecba36d6a6746eb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6328b50f0809fcb385fd5109adbb065331a2410ab523fd39638f8e029346627d',1987,'CL','Chile','geography',156,'Total area: 756,950 km?; land area:
748,800 km?
Comparative area: larger than Texas
Land boundaries: 6,325 km total
Coastline: 6,485 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: short section with
Argentina is indefinite; Bolivia has wanted
a sovereign corridor to Pacific Ocean since
_ Atacama area was lost to Chile in 1884;
dispute with Bolivia over Rio Lauca water
rights; territorial claim in Antarctica
(Chilean Antarctic Territory)
Climate: temperate; desert in north; cool
and damp in south
Terrain: low coastal mountains; fertile
central valley; rugged Andes in west
Land use: 7% arable land; NEGL% per-
manent crops; 16% meadows and pastures;
21% forest and woodland; 56% other;
includes 2% irrigated
Environment: subject to severe earth-
quakes, active volcanism, tsunami; At-
acama Desert one of world’s driest regions;
desertification
Special notes: strategic location relative to
sea lanes between Atlantic and Pacific
Oceans (Strait of Magellan, Beagle Chan-
nel, Drake Passage)','5c5edd6f78f8cb79c6faf96b97b982dd2efcaaf5287cfa48eae61e1aba7bec2c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf05d2958ce7c29587750b879c90754082362ab8478771b9b19f7881ecf93af',1987,'CN','China','geography',161,'Total area: 9,596,960 km?; land area:
9,326,410 km?
Comparative area: slightly larger than
conterminous US
Land boundaries: 24,000 km total
Coastline: 14,500 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: India, USSR (Pamir,
Argun, Amur, and Khabarovsk areas); short
section with North Korea is indefinite;
British colony of Hong Kong will become
a Special Administrative Region in 1997;
Portuguese territory of Macau will become
a Special Administrative Region in 1999;
sporadic border clashes with Vietnam;
involved in complex dispute over Spratly
Islands with Malaysia, Philippines, Taiwan,
Vietnam, and possibly Brunei; maritime
dispute with Vietnam; dispute with Viet-
nam over Paracel Islands
Climate: extremely diverse; tropical in
south to subarctic in north
Terrain: mostly mountains, high plateaus,
deserts in west; plains, deltas, and hills in
east
Land use: 10% arable land; NEGL%
permanent crops; 31% meadows and
pastures; 14% forest and woodland; 45%
other; includes 5% irrigated
Environment: frequent typhoons (about
five times per year along southern and
eastern coasts), damaging floods, earth-
quakes; deforestation; soil erosion; indus-
trial pollution; water pollution; desertifica-
tion
Special notes: world’s third largest coun-
try (after USSR and Canada)
Total area: 372,310 km?; land area:
371,030 km?
Comparative area: slightly smaller than
California
Coastline: 13,685 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm (8 nm in interna-
tional straits—La Perouse or Soya,
Tsugaru, Osumi, and Eastern and West-
ern channels of Tsushima or Korea
Strait)
Boundary disputes: none; Habomai Is-
lands, Etorofu, Kunashiri, and Shikotan
islands occupied by Soviet Union since
1945, claimed by Japan; Kuril Islands
administered by Soviet Union; Liancourt
Rocks disputed with South Korea
Climate: varies from tropical in south to
coo] temperate in north
Terrain: mostly rugged and mountainous
Land use: 11% arable land; 2% permanent
crops; 2% meadows and pastures; 68%
forest and woodland; 17% other; includes
9% irrigated
Environment: many dormant and some
active volcanoes; about 1,500 seismic
occurrences (mostly tremors) every year
Special notes: strategic location in north-
east Asia','d7fb6af225c7bfd33cc51f20923c8e18f4bb8a52b81ce137ca783a2f1a1b12d3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d943ce563a9f77fd328c549085533aab4f5ae28d26bbc9a16e6805c6c49fe11c',1987,'CX','Christmas Island','geography',166,'Total area: 130 km?; land area: 130 km?
Comparative area: slightly smaller than
Washington, D.C.
Coastline: about 54 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; heat and humidity
moderated by trade winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: almost completely sur-
rounded by a reef
Special notes: located along maior sea
lanes of Indian Ocean','e82ee4bec2a5da22bd7ffe9c1c40e513555e4cdc0f6ec1f73b6fc064b36176e6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('633cc046f1587a5311fb038b6543e359f1de1d67afdca6b37823256e5e48c7ee',1987,'CO','Colombia','geography',171,'Total area: 1,138,910 km: land area:
1,038,700 km?
Comparative area: about the size of New
Mexico and Texas combined
Land boundaries: 6,342 km total
Coastline: 3,208 km total (1,448 km Pa-
cific Ocean; 1,760 Caribbean Sea)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Venezuela; territorial dispute
with Nicaragua over San Andres and
Providencia Archipelago
Climate: tropical along coast and eastern
plains; cooler in highlands
Terrain: mixture of flat coastal lowlands,
plains in east, central highlands, some high
mountains
Land use: 4% arable land; 2% permanent
crops; 29% meadows and pastures; 49%
forest and woodland; 16% other; includes
NEGL% irrigated
Environment: highlands subject to volea-
nic eruptions; deforestation
Special notes: only South American coun-
try with coastlines on both Pacific Ocean
and Caribbean Sea','ac3420afdaad57b480d943608f4cd0036e7071ebb6bc8fc8345fa8051d757379','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb33b4a20d6a7c3f70596d25610870361667d4c4e8e00ef4ae451720f060ec9d',1987,'YT','Mayotte','geography',177,'Total area: 2,170 km?; land area: 2,170
km?
Comparative area: about half the size of
Delaware
Coastline: 340 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims French-
administered Mayotte
Climate: tropical marine; rainy season
(November to May)
Terrain: interiors vary from steep moun-
tains to low hills
Land use: 35% arable land; 8% permanent
crops; 7% meadows and pastures; 16%
forest and woodland; 34% other
Environment: soil degradation and ero-
sion; deforestation; cyclones possible dur-
ing rainy season
Special notes: important location at north-
ern end of Mozambique Channel
Total area: 375 km?; land area: 375 km?
Comparative area: about twice the size of
Washington, D.C.
Coastline: 165 km (excluding islets)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claimed by','0b5edd80f4c3c2c7c16ab75f7519bf00b64155778224371c63b34d90b55c3bc8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8728d13b31ccef0c7ebc699440074e5825fefba35c838db2922d909df599b4e3',1987,'CG','Congo','geography',182,'Total area: 342,000 km?; land area:
341,500 km?
Comparative area: slightly smaller than
Montana
Land boundaries: 4,514 km total
Coastline: 169 km
Maritime claim:
Territorial sea: 200 nm
Boundary disputes: section with Zaire is
indefinite
Climate: tropical; rainy season (March to
June); dry season (June to October); con-
stantly high temperatures and humidity;
particularly enervating climate astride the
Equator
Terrain: coastal plain, southern basin,
central plateau, northern basin
Land use: 2% arable land; NEGL% per-
manent crops; 29% meadows and pastures;
62% forest and woodland; 7% other
Environment: deforestation
Special notes: none','d0efd80fcb326844725d863d36cb5a9e7ac5bb91b96e680808fd16cf719bda10','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7ac02cea4143bc908f3df147d2c8609f7e95a72074e72514fd2a954ad70d86f',1987,'CK','Cook Islands','geography',187,'Total area: 230 km?; land area: 230 km?
Comparative area: slightly larger than
Washington, D. C.
Coastline: 120 km
Maritime claims:
Continental shelf: 200 meters or edge
of continental margin
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds
Terrain: low coral atolls in north; volcanic,
hilly islands in south
Land use: 4% arable land; 22% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 74% other
Environment: subject to typhoons from
November to March
Special notes: none','3d2e63285feae31e7d88eedbf8e4e4dbdb1d40b4ffb1db0edf270e3a0d58b812','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f3b90deca42f10f5b94e2167078b0ba1f596df7bf135c7ca06518fb93a989b5',1987,'CR','Costa Rica','geography',192,'Total area: 50,700 km?; land area: 50,660
km?
Comparative area: slightly smaller than
West Virginia
Land boundaries: 670 km total
Coastline: 1,290 km
Maritime claims:
Continental shelf: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Nicaraguan
interruption of transit in the Rio San Juan
(the international boundary) is an occa-
sional source of friction
Climate: tropical; dry season (December to
April); rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
Land use: 6% arable land; 7% permanent
crops; 43% meadows and pastures; 32%
forest and woodland; 12% other; includes
1% irrigated
Environment: subject to occasional earth-
quakes, hurricanes along Atlantic coast;
frequent flooding of Jowlands at onset of
rainy season; active volcanoes; deforesta-
tion; soil erosion
Special notes: none','975d4d61502987cfd89aa9c24978d03c32d8e87d8f615e831aaad0ca3f5f9789','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('474a17ec8351058c1e79efad31459655d5c5974fb0a4ad196493b863dbf9f2d2',1987,'CU','Cuba','geography',197,'Total area: 110,860 km?; land area:
110,860 km?
Comparative area: slightly smaller than
Pennsylvania
Land boundary: 29.1 km with Guantan-
amo (US Naval Base)
Coastline: 3,735 km
Maritime claims:
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Guantanamo
(US Naval Base) leased to US
Climate: tropical; moderated by trade
winds; dry season (November to April);
rainy season (May to November)
Terrain: mostly flat to rolling plains with
some hills and mountains
Land use: 23% arable land; 6% permanent
crops; 23% meadows and pastures; 17%
forest and woodland; 31% other; includes
10% irrigated
Environment: averages one hurricane
every other year
Special notes: largest country in Carib-
bean; 145 km south of Florida','a02bce1ffa769d13edf5b574dd8d9a44c8c68bae630734c4a3421725e3def541','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('083d34dfb3e3c09065ee28480611b558b39bb74cfc0b4257b697607f92e69120',1987,'CY','Cyprus','geography',202,'Total area: 9,250 km?; land area: 9,240
km?
Comparative area: slightly smaller than
Connecticut
Coastline: 648 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; has been di-
vided de facto into two autonomous areas
since 1974 hostilities—one controlled by
the Cyprus Government or Greek area
(60%) and the other administered by
Turkish Cypriots (85%); those areas are
separated by a UN buffer zone and two
UK sovereign base areas (5%)
Climate: temperate; hot, dry summers;
cool, rainy winters
Terrain: central plain with mountains to
north and south
Land use: 40% arable land; 7% permanent
crops; 10% meadows and pastures; 18%
forest and woodland; 25% other; includes
10% irrigated
Environment: moderate earthquake activ-
ity; water resource problems (no natural
reservoir catchments and seasonal disparity
in rainfall)
Special notes: occupies important location
in eastern Mediterranean, gateway to the
Middle East
Total area: 127,870 km?; land area:
125,460 km?
Comparative area: about the size of New
York State
Land boundaries: 3,540 km total
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: mixture of hills and mountains
separated by plains and basins
Land use: 40% arable land; 1% permanent
crops; 13% meadows and pastures; 37%
forest and woodland; 9% other; includes
1% irrigated
Environment: infrequent earthquakes;
acid rain; water pollution
Special notes: landlocked; strategically
located astride some of oldest and most
significant land routes in Europe; Morav-
ian Gate is a traditional military corridor
between northern Europe and Danube','6b1487e025f9bb391f6f7d29399cd6a22217998f70086fe7bdfd7be58da078e1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f318e12068d60fac5610964305d5005a72f9ade671197afa8ab1245fb9cfca50',1987,'DK','Denmark','geography',207,'Total area: 43,070 km?; land area: 42,370
km? (excluding Greenland and Faroe
Islands)
Comparative area: about twice the size of
Massachusetts
Land boundaries: 68 km total
Coastline: 3,379 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; Rockall conti-
nental shelf dispute involving Iceland,
Ireland, and UK
Climate: temperate; humid and overcast;
mild winters and cool summers
Terrain: low and flat to gently rolling
plains
Land use: 61% arable land; NEGL%
permanent crops; 6% meadows and pas-
tures; 12% forest and woodland; 21%
other; includes 9% irrigated
Environment: air and water pollution
Special notes: controls Danish Straits
linking Baltic and North Seas','2126b01d0481cad3bf6e5f001ae3c0b7f3f9ee80d8f2b25facc5123dbce89f31','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e679291645f2bbb7417c7ad6b9c232382661ce03cd4cab6c2164dacabdb1bb07',1987,'DJ','Djibouti','geography',212,'Total area: 22,000 km?; land area: 21,980
km?
Comparative area: about the size of New
Hampshire
Land boundaries: 517 km total
Coastline: 314 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; possible claim
by Somalia based on unification of ethnic
Somalis
Climate: desert; torrid, dry
Terrain: coastal plain and plateau sepa-
rated by central mountains
Land use: 0% arable land; 0% permanent
crops; 9% meadows and pastures; NEGL%
forest and woodland; 91% other
Environment: vast wasteland with impor-
tant geothermal resources
Special notes: strategic location near
world’s busiest shipping lanes and close to
Arabian oilfields','f56d9a4f2e5749952661646d0f4f6fcf2adafccf09b8788a6cfca53d617a1c15','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d79f0a3092fdd27d9a5c063dc2f90080a47c05e9001c2a6d767d0f2dff3de379',1987,'DM','Dominica','geography',217,'Total area: 750 km?; land area: 750 km?
Comparative area: about one-fourth the
size of Rhode Island
Coastline: 148 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by northeast
trade winds; heavy rainfall
Terrain: rugged mountains of volcanic
origin
Land use: 9% arable land; 13% permanent
crops; 8% meadows and pastures; 41%
forest and woodland; 34% other
Environment: flash floods a constant
hazard; occasional hurricanes
Special notes: northernmost and largest of
Windward Islands','4f27cd3ec71ddba089371965413b9b102dd529ccb1d908cbc11691af3207efa5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b78bd6cdb1cf5dd85022fd25f27f7e2c1cb69804ea9fe18f4d049fc186f91735',1987,'DO','Dominican Republic','geography',222,'Total area: 48,730 km?; land area: 48,380
km?
Comparative area: about the size of New
Hampshire and Vermont combined
Land boundary 361 km with Haiti
Coastline: 1,288 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: outer edge of conti-
nental margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation
Terrain: rugged highlands and mountains
Land use: 23% arable land; 7% permanent
crops; 43% meadows and pastures; 138%
forest and woodland; 14% other; includes
4% irrigated
Environment: subject to occasional hurri-
canes; deforestation
Special notes: shares island of Hispaniola
with Haiti','ee945eb31c2b5c667a46277c83f34ac16709758c42194463bf588d00f31a8a05','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6949f96208cb0a9451edc894ce517181dede508ae9f22a9e8573677f1788eec2',1987,'EC','Ecuador','geography',227,'Total area: 283,560 km?: land area:
276,840 km?
Comparative area: about the size of
Colorado
Land boundaries: 1,931 km total
Coastline: 2,237 km
Maritime claims:
Continental shelf: 200 m
Territorial sea: 200 nm
Boundary disputes: Peru (two areas)
Climate: tropical along coast becoming
cooler inland
Terrain: coastal plain (Costa), Andes
Mountains and central highlands (Sierra),
flat to rolling eastern jungle (Oriente)
Land use: 6% arable land; 8% permanent
crops; 17% meadows and pastures; 51%
forest and woodland; 23% other; includes
2% irrigated
Environment: subject to frequent earth-
quakes, landslides, volcanic activity, tsuna-
mis; deforestation; desertification; soil
erosion
Special notes: Cotopaxi in Andes is high-
est active volcano in world','1904dbc51072cfd146bb64939577336aca5df802a6aab164487d6306b8a44da9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18095ecbcc73112ef63d249dadc9505ea9df58c29efee74856fc420cc5f23a8d',1987,'EG','Egypt','geography',232,'Total area: 1,001,450 km?; land area:
995,450 km?
Comparative area: about the size of
Oregon and Texas combined
Land boundaries: 2,580 km total
Coastline: 2,450 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; disputes with
Israel over Taba area and precise location
of some individual boundary markers;
Administrative Boundary and international
boundary with Sudan; West Bank and
Gaza Strip are Israeli occupied with status
to be determined
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Land use: 2% arable land; NEGL% per-
manent crops; 0% meadows and pastures;
NEGL% forest and woodland; 98% other;
includes 2% irrigated
Environment: Nile is only perennial water
source; increasing soil salinization below
Aswan High Dam; hot, driving windstorm
called khamsins occurs in spring; water
pollution; desertification
Special notes: controls Sinai Peninsula,
only land bridge between Africa and
remainder of Eastern Hemisphere; controls
Suez Canal, shortest sea link between
Indian Ocean and Mediterranean; size and
juxtaposition to Israel establishes its major
role in Middle East geopolitics
Total area: 21,040 km?; land area: 20,720
km?
Comparative area: about the size of
Massachusetts
Land boundaries: 515 km total
Coastline: 307 km
Maritime claim:
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Honduras
Climate: tropical; rainy season (May to
October); dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
Land use: 27% arable land; 8% permanent
crops; 29% meadows and pastures; 6%
forest and woodland; 30% other; includes
5% irrigated
Environment: The Land of Volcanoes;
subject to frequent and sometimes very
destructive earthquakes; deforestation; soil
erosion; water pollution
Special notes: smallest Central American
country and only one without a coastline
on Caribbean Sea','566b0778a0c33fbcec0f39f08edcf5316f6725d37be946ae30de9d818448c083','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e43a506ec0aa3db86b14610a0ad716272644a3be663f51243909d16d2c88de',1987,'GQ','Equatorial Guinea','geography',237,'Total area: 28,050 km?; land area: 28,050
km?
Comparative area; about the size of
Maryland
Land boundaries: 539 km total
Coastline: 296 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Gabon
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills
Land use: 5% arable land; 4% permanent
crops; 4% meadows and pastures; 61%
forest and woodland; 26% other
Environment: subject to violent wind-
storms
Special notes: none','880715b9545ea1b91058eb9388da520e8f26c13ca01d8652a031d7f41fc3783b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e00788261c03791902d8b6f356165e0eb7fb1bc69dd1754a30ec2a79d8dfb51',1987,'ET','Ethiopia','geography',243,'Total area: ],221,900 km?; land area:
1,101,000 km?
Comparative area: four-fifths the size of
Alaska
Land boundaries: 5,198 km total
Coastline: 1,094 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: southern half of
boundary with Somalia is a Provisional
Administrative Line; possible claim by
Somalia based on unification of ethnic
Somalis; territorial dispute with Somalia
over the Ogaden
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central moun-
tain range divided by Great Rift Valley
Land use: 12% arable land; 1% permanent
crops; 41% meadows and pastures; 24%
forest and woodland; 22% other; includes
NEGL% irrigated
Environment: geologically active Great
Rift Valley susceptible to earthquakes,
volcanic eruptions; deforestation; overgraz-
ing; soil erosion; desertification
Special notes: strategic geopolitical posi-
tion along world’s busiest shipping lanes
and close to Arabian oilfields
Total area: 12,170 km?; land area: 12,170
km?
Comparative area: about the size of
Connecticut
Coastline: 1,288 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm (enfore-
ing only to 150 nm, 1 February 1987)
Territorial sea: 8 nm
Boundary disputes: none; territorial dis-
pute—islands administered by UK,
claimed by Argentina
Climate: cold marine; strong westerly
winds, cloudy, humid; rain occurs on more
than half of days in year; occasional snow
all year, does not accumulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Land use: 0% arable land; 0% permanent
crops; 99% meadows and pastures; 0%
forest and woodland; 1% other
Environment: some smaller islands in
dependencies are voleanically active
Special notes: deeply indented coastline
provides good natural harbors','6967760d8875686d2f7cff1827cab0850267d19ed7ed31ac71e69556dc4be482','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdb23ed813dedb3d3d9d80278aaba4c03de52ba85b077ff33ab5c334a8e1f89d',1987,'FO','Faroe Islands','geography',248,'Total area: 1,400 km?; land area: 1,400
km?
Comparative area: slightly larger than
Rhode Island
Coastline: 764 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: mild winters, cool summers;
usually overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Land use: 2% arable land; 0% permanent
crops; 0% meadews and pastures; 0% forest
and woodland; 98% other
Environment: precipitous terrain limits
habitation to small coastal lowlands; archi-
pelago consists of 18 inhabited islands and
a few uninhabited islets
Special notes: strategically located along
important sea lanes in northeastern Atlan-
tic about midway between Iceland and
Shetland Islands
Total area: 18,270 km?; land area: 18,270
km?
Comparative area: about the size of
Massachusetts
Coastline: 1,129 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; only slight
seasonal temperature variation
Terrain: mostly mountains of volcanic
origin
Land use: 8% arable land; 5% permanent
crops; 3% meadows and pastures; 65%
forest and woodland; 19% other; includes
NEGL4% irrigated
Environment: subject to hurricanes from
November to January
Special notes: none','f58754283ea4a3b4b231c27e5504537e3e8390b4350bf0cad417a06f95807431','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd86923c3586e2b78d5a3a4395ef23d05761a1a4ff2581eeff99d24b773b87ab',1987,'FI','Finland','geography',253,'Total area: 337,030 km?; land area:
305,470 km?
Comparative area: slightly smaller than
Montana
Land boundaries: 2,534 km total
Coastline: 1,126 km excluding islands and
coastal indentations
Maritime claims:
Contiguous zone: 6 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 12 nm
Territorial sea: 4 nm
Climate: cold temperate, potentially
subarctic, but comparatively mild because
of moderating influence of Gulf Stream,
Baltic Sea, more than 60,000 lakes
Terrain: mostly low, flat to rolling plains
interspersed with low hills
Land use: 8% arable land; 0% permanent
crops; NEGL% meadows and pastures;
76% forest and woodland; 16% other;
includes NEGL% irrigated
Environment: permanently wet ground
covers about 30% of land; population
concentrated on small southwestern coastal
plain
Special notes: long boundary with USSR;
Helsinki is northernmost national capital
on European continent
Finland (continued)','7b58d72c99a6f2202092bb689d4b5e1a963b277cf491677f0b0c7a48f461c7e0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b114e1cb61e78c5d06cd2312960ada5b43030b72ab43ce404d88f405559816b8',1987,'FR','France','geography',258,'Total area: 547,030 km?; land area:
545,630 km?
Comparative area: four-fifths the size of
Texas
Land boundaries: 2,888 km total
Coastline: 3,427 km (includes Corsica, 644
km)
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Canada; Madagascar claims
Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, and Trome-
lin Island; Comoros claims Mayotte;
Mauritius claims Tromelin Island; Seychel-
les claims Tromelin Island; Suriname
claims part of French Guiana; territorial
claim in Antarctica (Adélie Land)
Climate: generally cool winters and mild
summers, but mild winters and hot sum-
mers along the Mediterranean
Terrain: mostly flat plains or gently rolling
hills; rest is mountainous
Land use: 32% arable land; 2% permanent
crops; 23% meadows and pastures; 27%
forest and woodland; 16% other; includes
2% irrigated
81
Environment: most of large urban areas
and industrial centers in Rhéne, Garonne,
Seine, or Loire river basins; occasional
warm tropical wind known as mistral
Special] notes: largest West European
nation','03924d39e6a39c025d783fbe7a35c0d3566d4c09926bc665d54b6fed518ac344','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d39dd7529c3d4680d4a90d068a42dad5446cfd215ad80dfaf587d644dacc06f8',1987,'GF','French Guiana','geography',263,'Total area: 91,000 km2: land area: 89,150
km?
Comparative area: slightly smaller than
Maine
Land boundaries: 1,183 km total
Coastline: 378 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Suriname claims area
between Litani Rivier and Riviére
Marounini (both headwaters of the Lawa)
Climate: tropical; hot, humid; little sea-
sonal temperature variation
Terxain: low lying coastal plains rising to
hills and small mountains
Land use: NEGL% arable land; NEGL%
permanent crops; NEGL% meadows and
pastures; 82% forest and woodland; 18%
other
Environment: mostly an unsettled wilder-
ness
Special notes: none','84bcd0781c0806e70f18b40b8178dc046eb79e230e9789f160b3cf8000a859e6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7451bb7f312c670176b97f61e04d72df02eb69bec0f89d15bd1395b45944360f',1987,'PF','French Polynesia','geography',268,'Total area: 4,000 km?; land area: 3,660
km?
Comparative area: larger than Rhode
Island
Coastline: 2,525 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands
and low islands with reefs
Land use: 1% arable land; 19% permanent
crops; 5% meadows and pastures; 31%
forest and woodland; 44% other
Environment: occasional cyclonic storm in
January
Special notes: Makatea is one of three
great phosphate rock islands in the Pacific
(others are Banaba or Ocean Island in
Kiribati and Nauru)','a1a54631a90107be8f5deeaf9f549690528d9a95cebf2af0ec8dd544c70a1856','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ac20b9838eed6be553637480bc2d50b9c230121cd1a08d269629f5d5e104093',1987,'GA','Gabon','geography',276,'Total area: 11,300 km?; land area: 10,000
km?
Comparative area: about twice the size of
Delaware
Land boundary: 740 km with Senegal
Coastline: 80 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 200 nm
Boundary disputes: short section with
Senegal is indefinite
Climate: tropical; hot, rainy season (June
to November); cooler, dry season (Novem-
ber to May)
Terrain: flood plain of Gambia River
flanked by some low hills
Land use: 16% arable land; 0% permanent
crops; 9% meadows and pastures; 20%
forest and woodland; 55% other; includes
8% irrigated
Environment: deforestation
Special notes: almost an enclave of','ecf0e1816b2822776962206eb5bc87e139a96c332cfc145e0f41dc93c6ab3b49','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8cc940c957e452605d7c3331f49aabddc8402fbead3990675e47fc6f17010c',1987,'SN','Senegal','geography',281,'Total area: 108,330 km?; land area:
105,980 km?
Comparative area: about the size of
Virginia
Land boundaries: 2,309 km total
Coastline: 901 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: it is US policy that
the final borders of Germany have not
been established
Climate: temperate; cloudy, cold winters
with frequent rain and snow; cool, wet
summers
Terrain: mostly flat plain with hills and
mountains in south
Land use: 45% arable land; 3% permanent
crops; 12% meadows and pastures; 28%
forest and woodland; 12% other; includes
2% irrigated
Environment: significant deforestation due
to air pollution, acid rain
Special notes: strategic location on North-
ern European Plain and near entrance to
Baltic Sea; West Berlin is an enclave
(about 100 km from FRG)
88
Total area: 248,580 km?; land area:
244,280 km? (including West Berlin)
Comparative area: about the size of
Wyoming
Land boundaries: 4,232 km total
Coastline: 1,488 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm (extends, at one
point, to 16 nm in the Helgolander
Bucht)
Boundary disputes: it is US policy that
the final borders of Germany have not
been established
Climate: temperate and marine; cool,
cloudy, wet winters and summers; occa-
sional warm, tropical foehn wind
Terrain: lowlands in north, uplands in
center, Bavarian Alps in south
Land use: 30% arable Jand; 1% permanent
crops; 19% meadows and pastures; 30%
forest and woodland; 20% other; includes
1% irrigated
Environment: air and water pollution
Special notes: separated from GDR by a
highly secured strip that extends entire
length of frontier; West Berlin is an ex-
clave (about 100 km from FRG)
Total area: 196,190 km?; land area:
192,000 km?
Comparative area: about the size of South
Dakota
Land boundaries: 2,680 km total
Coastline; 531 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: short section with The
Gambia is indefinite
Climate: tropical; hot, humid; rainy season
(December to April) has strong southeast
winds; dry season (May to November)
dominated by hot, dry harmattan wind
Terrain: generally low, rolling, plains
rising to foothills in southeast
Land use: 27% arable land; 0% permanent
crops; 30% meadows and pastures; 31%
forest and woodland; 12% other; includes
1% irrigated
Environment: lowlands seasonally flooded;
deforestation; overgrazing; soil erosion;
desertification
Special notes: The Gambia is almost an
enclave
215','2a2e11d24d0e69349989871b3a6d60a023f88e7512404277a09c4587c4e85c2a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07ddbbeef9072efbee72949a0c4ca12f17994a11e14e5b0c28a24a1e38a74fcf',1987,'GH','Ghana','geography',283,'Total area: 238,540 km?; land area:
230,020 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,285 km total
Coastline: 539 km
Maritime claims:
Continental shelf: 100 fathoms or to
depth of exploitation
Territorial sea: 200 nm
Climate: tropical; warm and compar-
atively dry along southeast coast; hot and
humid in southwest, hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Land use: 5% arable land; 7% permanent
crops; 15% meadows and pastures; 837%
forest and woodland; 36% other; includes
NEGL% irrigated
Environment: recent drought in north
severely affecting marginal agricultural
activities; deforestation; overgrazing; soil
erosion; dry, northeasterly harmattan wind
(January to March)
Special notes: Lake Volta is world’s largest
artificial lake','a985e920ad2f1aab033ee2fa95592e9cb085b091e732d8a616241cde55b646e2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca3c58e389c573a34527f1a35e95751479ee5be4e9d8a848755c2e5d319f4cc6',1987,'GI','Gibraltar','geography',288,'Total area: 6.5 km?; land area: 6.5 km?
Comparative area: about one-twenty-
seventh the size of Washington, D.C.
Land boundaries: 1.6 km total
Coastline: 12 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 3 nm
Boundary disputes: none; occasional
source of friction between Spain and UK
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narrow coastal lowland borders
The Rock
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: natural fresh water sources
are very meager so large water catchments
(concrete or natural rock) collect rain
water
Special notes: strategic location on Strait
of Gibraltar that links Atlantic Ocean and
Mediterranean Sea','288dacf2cb924e299bf8aa89bce278dc4ce5bd1a1d599e04289ea0fba90632fb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb33ed7089d8a448f50417d5b38468e477b40e3f646cb5fd3c47bebcc617816e',1987,'GR','Greece','geography',293,'Total area: 131,940 km?; land area:
130,800 km?
Comparative area: about the size of New
York State
Land boundaries: 1,191 km total
Coastline: 13,676 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 6 nm
Boundary disputes: none; complex mari-
time and air (but not territorial) disputes
with Turkey in Aegean Sea; Cyprus ques-
tion with Turkey; Macedonia question
with Bulgaria and Yugoslavia; Northern
Epirus question with Albania
Climate: temperate; mild, wet winters;
hot, dry summers
Terrain: mostly mountains with ranges
extending into sea as peninsulas or chains
of islands
Land use: 23% arable land; 8% permanent
crops; 40% meadows and pastures; 20%
forest and woodland; 9% other; includes
7% irrigated
Environment: subject to severe earth-
quakes; archipelago of 2,000 islands; air
pollution
Special notes: strategic location dominat-
ing the Aegean Sea and southern approach
to Turkish Straits
94','afd2aa011d24e64ae22acae2b0193ba29edb59a8af264735fce2bea156377720','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1effda6766c87dba8f8beb1fe86a009e92d05eca8616a14d645c3e9db9c798',1987,'GL','Greenland','geography',298,'Total area: 2,175,600 km?; land area:
341,700 km? (ice free)
Comparative area: about three times the
size of Texas
Coastline; 44,087 km
Maritime claims:
Contiguous zone: 4 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 8 nm
Climate: arctic to subarctic; cool summers,
cold winters
Terrain: flat to gradually sloping icecap
covers all but narrow, barren, steep, rocky
coast
Land use: 0% arable land; 0% permanent
crops; 1% meadows and pastures, NEGL%
forest and woodland; 99% other
Environment: sparse population confined
to small settlements along coast
Special notes: dominates North Atlantic
Ocean between North America and
Europe','94a83d518f14fb0dc0b8f8c3425200de786be7827e4690ab33169921e5ad5b4c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb66624a886be99fa98ed1e31086f8724c51f1a9c10c71c43cc106257b31bc9c',1987,'GD','Grenada','geography',303,'Total area: 340 km?; land area: 340 km?
Comparative area: about twice the size of
Washington, D.C.
Coastline: 121 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
Land use: 15% arable land; 26% perma-
nent crops; 3% meadows and pastures; 9%
forest and woodland; 47% other
Environment: lies on edge of hurricane
belt; hurricane season lasts from June to
November
Special notes: islands of the Grenadines
group are divided politically with St.
Vincent and the Grenadines','1ec326b1aa263db3b6e2c872f67df6b3808f4ae0c96027c6f23134f3f2bd75ed','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ccb772a5df00475f762681ac6744ba6ca7a79176bf50303e77e982e02c0465c',1987,'GP','Guadeloupe','geography',308,'Total area: 1,780 km?; land area: 1,760
km?
Comparative area: about half the size of
Rhode Island
Coastline: 306 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: subtropical tempered by trade
winds; relatively high humidity
Terrain: Basse-Terre is volcanic in origin
with interior mountains; Grand-Terre is
low limestone formation
Land use: 18% arable land; 5% permanent
crops; 13% meadows and pastures; 40%
forest and woodland; 24% other; includes
\\% irrigated
Environment: subject to hurricanes (June
:0 December)
Special notes: none','a4c83876efb19b250ec5789a657e17cc84a72806d4139a63856638caea4cc7c3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd41975a0244ea893a3ca4a0d567f29e41649b4cb9af010baf72fe4f5c5fc53',1987,'GG','Guernsey','geography',313,'Total area: 194 km?; land area: 194 km?
Comparative area: slightly larger than
Washington, D.C.
Coastline: 50 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate with mild winters and
cool summers; about 50% of days are
overcast
Terrain: mostly level with low hills in
southwest
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 50% cultivated
Environment: large, deepwater harbor at
St. Peter Port
Special notes: 52km west of France','5b091c14b969fb44c075bad4a4dc202d8a9ecafaffb0dc106d3d4fe51b968d6b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a828f93ebef1636de2d233983a73baf9716e8a98a82f37b288e9a738b21f321',1987,'GN','Guinea','geography',317,'Total area: 245,860 km?; land area:
245,860 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 3,476 km total
Coastline: 320 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: generally hot and humid;
monsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: generally flat coastal plain, hilly
to mountainous interior
Land use: 6% arable land; NEGL% per-
manent crops; 12% meadows and pastures;
42% forest and woodland; 40% other;
includes NEGL% irrigated
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry
season; deforestation
Special notes: none
Total area: 1,904,570 km?; land area:
1,811,570 km?
Comparative area: about the size of
Alaska and California combined
Land boundaries: 2,736 km total
Coastline: 54,716 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Australia; East Timor question
with Portugal
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: mostly coastal lowlands; larger
islands have interior mountains
Land use: 8% arable land; 3% permanent
crops; 7% meadows and pastures; 67%
forest and woodland; 15% other; includes
3% irrigated
Environment: more than 13,500 islands;
occasional floods; deforestation
Special notes: straddles Equator; strategic
location astride or along major sea lanes
from Indian Ocean to Pacific Ocean
Total area: 1,648,000 km/?; land area:
1,636,000 km?
Comparative area: about the size of
Alaska and Pennsylvania combined
Land boundaries: 5,318 km total
Coastline: 3,180 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: 50 nm in the
Sea of Oman; median-line boundaries in
the Persian Gulf
Territorial sea: 12 nm
Boundary disputes: none; on 17 Septem-
ber 1980 Iraq abrogated 1975 treaty with
Iraq which shifted the boundary in Shatt
al Arab waterway from the low water
mark on Iranian side of river to midpoint
of deepest navigable channel (thalweg}—
heavy fighting with Iraq began on 22
September 1980; Kurdistan question with
Iraq; occupies three islands claimed by
UAE in Strait of Hormuz; periodic dis-
putes with Afghanistan over Helmand
water rights
Climate: mostly arid or semiarid, sub-
tropical along Caspian coast
Terrain: rugged, mountainous rim; high,
central basin with deserts, mountains;
small, discontinuous plains along both
coasts
Land use: 8% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
11% forest and woodland; 54% other;
includes 2% irrigated
Environment: deforestation; overgrazing;
desertification
Special notes: none
Total area: 960 km?; land area: 960 km?
Comparative area: about one-third the
size of Rhode Island
Coastline: 209 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Land use: 1% arable land; 36% permanent
crops; 1% meadows and pastures; 0% forest
and woodland; 62% other
Environment: deforestation; soil erosion
Special notes: smallest country in Africa','8f4c978aab34249ee216b6dfa63a1c1a4634e2633f4ae80f1e998fad173464f8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f41910f9de57a1381d8cd5c3ba73588ef61fb36e96d0031e79deedd113165b7d',1987,'GW','Guinea-Bissau','geography',320,'Total area: 36,120 km?; land area: 28,000
km?
Comparative area: about the size of
Connecticut and New Hampshire com-
bined
Land boundaries: 740 km total
Coastline: 350 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; generally hot and hu-
mid; monsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast-
erly harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Land use: 9% arable land; 1% permanent
crops; 46% meadows and pastures; 38%
forest and woodland; 6% other
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry
season
Special notes: none','1b2c940b2673b4d0249a459f488081a3854a4b91e18134e770d8b713ff98dfc9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb08c33be59c6892b1ab3ad3b93c98b28376fed404abca3a5ef386ca0afedb3a',1987,'GY','Guyana','geography',325,'Land area: 214,970 km”; land area:
196,850 km?
Comparative area about the size of Idaho
Land boundaries: 2,575 km total
Coastline: 459 km
Maritime claims:
Continental shelf: outer edge of conti-
nental margin or 200 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Essequibo area
claimed by Venezuela; Suriname claims
area between New (Upper Courantyne)
and Courantyne/Kutari rivers (all head-
waters of the Courantyne)
Climate: tropical; hot, humid, moderated
by northeast trade winds; two rainy sea-
sons (May to mid-August, mid-November
to mid-January)
Terrain: mostly rolling highlands; low
coastal plain; savanna in south
Land use: 3% arable land; NEGL% per-
manent crops; 6% meadows and pastures;
83% forest and woodland; 8% other; in-
cludes 1% irrigated
Environment: flash floods a constant threat
during rainy seasons; water pollution
Special notes: none','f2f34efa2aa93f0d019e9352af05046b67457f547ce9feb4b4219b3f45ec9001','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91e2babed0b8f25fdba109355f1f3d8b5cd01b61ec58cab1a8b112300e407bf3',1987,'HT','Haiti','geography',330,'Total area: 27,750 km?; land area: 27,560
km?
Comparative area: about the size of
Maryland
Land boundary: 361 km with Dominican
Republic
Coastline: 1,77] km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims Navassa
Island (US possession)
Climate: tropical; semiarid where moun-
tains in east cut off trade winds
Terrain: mostly rough and mountainous
Land use: 20% arable land; 13% perma-
nent crops; 18% meadows and pastures;
4% forest and woodland; 45% other; in-
cludes 3% irrigated
Environment: lies in middle of hurricane
belt; hurricanes have caused extensive
damage; occasional flooding and earth-
quakes; deforestation
Special notes: shares island of Hispaniola
with Dominican Republic
Total area: 112,090 km?; land area:
111,890 km?
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,530 km total
Coastline: 820 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: El Salvador
Climate: subtropical in lowlands, temper-
ate in mountains
Terrain: mostly mountains in interior,
narrow coastal plains
Land use: 14% arable land; 2% permanent
crops; 30% meadows and pastures; 34%
forest and woodland; 20% other; includes
1% irrigated
Environment: subject to frequent, but
generally mild, earthquakes; damaging
hurricanes along Caribbean coast; defores-
tation; soil erosion
Special notes: none','a976948154675bb79ab5700636d2dad8187e3ad2c3f7a1034945364bf82a5a7f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1016c0bbaaae2280b6d962a75d764f3246a00fedbe81031b72c2282a9f4fb3b',1987,'HK','Hong Kong','geography',335,'Total area: 1,040 km?; land area: 990 km?
Comparative area: about one-third the
size of Rhode Island
Land boundary: 24 km with China
Coastline: 733 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 8 nm
Boundary disputes: none; will become a
Special Administrative Region of China in
1997
Climate: tropical monsoon; cool and
humid in winter, hot and rainy from
spring through summer, warm and sunny
in fall
Terrain: hilly to mountainous with steep
slopes; lowlands in north
Land use: 7% arable land; 1% permanent
crops; 1% meadows and pastures; 12%
forest and woodland; 79% other; includes
3% irrigated
Environment: more than 200 islands;
occasional typhoons
Special notes: outstanding natural harbor','0d7ff3afa73a9c89cf1bdc06448c3292c277c7efc9e04e96ffe22c26f831a254','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d496cd3d1e8c401d558f9b9d0fb975813c70fdaa8e96fa2dfc6a4eadfdeadf7',1987,'HU','Hungary','geography',340,'Total area: 93,030 km?; land area: 92,340
km?
Comparative area: slightly smaller than
Indiana
Land boundaries: 2,242 km total
Boundary disputes: none; Transylvania
question with Romania
Climate: temperate; cold, cloudy, humid
winters; warm summers
Terrain: mostly flat to rolling plains
Land use: 54% arable land; 3% permanent
crops; 14% meadows and pastures; 18%
forest and woodland; 11% other; includes
2% irrigated
Environment: levies are common along
many streams, but flooding occurs almost
every year
Special notes: landlocked; strategic loca-
tion. astride main land routes between
Western Europe and Balkan Peninsula as
well as between USSR and Mediterranean
basin','269970dd525a08e2edcb2451a56fb03f6ed98b5abb7de55287894a8b084f0748','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b42036adfb70d0460ecd05ecd815d9553c9bc9041eed50d8e5aa8de26cbb32e',1987,'IS','Iceland','geography',345,'Total area: 103,000 km?; land area:
100,250 km?
Comparative area: about the size of
Virginia
Coastline: 4,988 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Rockall conti-
nental shelf dispute involving Denmark,
Ireland, and UK
Climate: temperate; Gulf Stream influ-
ence; mild, windy winters; damp, cool
summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields
Land use: NEGL% arable land; 0% per-
manent crops; 23% meadows and pastures;
1% forest and woodland; 76% other
Environment: subject to earthquakes and
volcanic activity
Special notes: strategic location between
Greenland and Europe; westernmost
European country','141f750317342605df62c5922a91d0f4201e8171f5d7847a2a385e32ba5c74cb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1988c7f780dbd61db2be10ae6dc2b83409fa71c83272cf7ba517fe60fdfb4e8f',1987,'IQ','Iraq','geography',352,'Total area: 434,920 km?; land area:
438,970 km?
Comparative area: larger than California
Land boundaries: 3,668 km total
Coastline: 58 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; on 17 Septem-
ber 1980 Iraq abrogated 1975 treaty with
Iraq which shifted the boundary in Shatt
al Arab waterway from the low water
mark on Iranian side of river to midpoint
of deepest navigable channel (thalweg)—
heavy fighting with Iran began on 22
September 1980; Kurdistan question with
lran; ownership of Warbah and Bubiyan
islands disputed with Kuwait; shares Neu-
tral Zone with Saudi Arabia; periodic
disputes with Syria over Euphrates water
rights; potential dispute over water devel-
opment plans by Turkey for the Tigris and
Euphrates rivers
Climate: desert; mild to cool winters with
dry, hot, cloudless summers
Terrain: mostly broad plains; reedy
marshes in southeast; mountains along
borders with Iran and Turkey
Land use: 12% arable land; 1% permanent
crops; 9% meadows and pastures; 3% forest
and woodland; 75% other; includes 4%
irrigated
Iraq (continued)
Environment: development of Tigris-
Euphrates river systems contingent upon
agreements with upstream riparians (Syria,
Turkey); air and water pollution; soil
degradation and erosion; desertification
Special notes: none
Climate: dry desert; intensely hot sum-
mers; short, cool winters
Terrain: flat to slightly undulating desert
plain
Land use: NEGL% arable land; 0% per-
manent crops; 8% meadows and pastures;
NEGL% forest and woodland; 92% other;
includes NEGL% irrigated
Environment: some of world’s largest and
most sophisticated desalination facilities
provide most of water; air and water
pollution; desertification
Special notes: strategic location at head of
Persian Gulf and close to Iran-Iraq war
zone
Total area: 236,800 km?: land area:
230,800 km?
Comparative area: slightly larger than
Utah
Land boundaries: 5,053 km total
Climate: tropical monsoon; rainy season
(May to October); dry season (February to
May)
Terrain: mostly rugged mountains; some
plains and plateaus
Land use: 4% arable land; NEGL% per-
manent crops; 3% meadows and pastures;
58% forest and woodland; 35% other;
includes 1% irrigated
Environment: deforestation; soil erosion;
subject to floods
Special notes: landlocked','f8d459929407c8d0d6d704f6a27b54cab557a1100df18e9a5abb7783fcf14e27','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74f21c275a08193db48f97378ce0083524a858ff49cbce35c6184f30cb33c8b2',1987,'IE','Ireland','geography',357,'Total area: 70,280 km?; land area: 68,890
km?
Comparative area: slightly larger than
West Virginia
Land boundary: 360 km with United
Kingdom
Coastline: 1,448 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with UK; Northern Ireland question
with UK; Rockall continental shelf dispute
involving Denmark, Iceland, and UK
Climate: temperate marine; modified by
Gulf Stream; mild winters, cool summers;
consistently humid; overcast about half the
time
Terrain: mostly level to rolling interior
plain surrounded by rugged hills and low
mountains
Land use: 14% arable land; NEGL%
permanent crops; 71% meadows and
pastures; 5% forest and woodland; 10%
other
Environment: deforestation
Special notes: none','78903d1661269ee89bda6f1e7b3b707e0d1e5bca7e3e11f7c465441bbf97348f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78158b0aab22873a408eba0ce676b39d405e61e669d171fead8405a71001ff87',1987,'IL','Israel','geography',362,'Total area: 20,770 km?; land area: 20,330
km?
Comparative area: about the size of
Massachusetts
Land boundaries: 1,036 km total (before
1967 war)
Coastline: 273 km (before 1967 war)
Maritime claims:
Continental shelf: to depth of exploita-
tion
Territorial sea: 6 nm
120
Boundary disputes: separated from Jor-
dan, Lebanon, and Syria by 1949 Armi-
stice Line; disputes with Egypt over Taba
area and precise location of some individ-
ual boundary markers; West Bank and
Gaza Strip are Israeli occupied with status
to be determined; Golan Heights is Israeli
occupied; Israeli troops in southern Leba-
non since June 1982
Climate: temperate; hot and dry in desert
areas
Terrain: mostly desert (Negev) in south;
low coastal plain; central mountains;
Jordan Rift Valley
Land use: 17% arable land; 5% permanent
crops; 40% meadows and pastures; 6%
forest and woodland; 32% other; includes
11% irrigated
Environment: sandstorms may occur
during spring and summer; limited arable
land and natural water resources pose
serious constraints; deforestation
Special notes: none','086777b306d84bfb5fd2b2f3a1a8deb2ac3916b669c157610f810e2cd968c455','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4c8fe1928b3300c65503a7fdb2cf39e65e9368e7a1418e6297c700cb7f82ab3',1987,'IT','Italy','geography',367,'Total area: 301,230 km?; land area:
294,020 km?
Comparative area: slightly larger than
Arizona
Land boundaries: 1,702 km total
Coastline: 4,996 km
Maritime claims:
Continental shelf: 200 m or to depth of
exploitation
Territorial sea: 12 nm
Boundary disputes: none; South Tyrol
question with Austria; Trieste question
with Yugoslavia
Climate: temperate; Alpine in far north
Terrain: mostly rugged and mountainous;
some plains, coastal lowlands
Land use: 32% arable land; 10% perma-
nent crops; 17% meadows and pastures;
22% forest and woodland; 19% other;
includes 10% irrigated
Environment: regional risks include land-
slides, mudflows, snowslides, earthquakes,
volcanic eruptions, flooding, pollution; land
sinkage in Venice
Special notes: strategic location dominat-
ing central Mediterranean as well as south-
ern sea and air approaches to Western
Europe
Total area: 322,460 km?; land area:
318,000 km?
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,227 km total
Coastline: 515 km
Maritime claims:
Continental shelf: 200 m
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical along coast, semiarid in
far north; three seasons—warm and dry
(November to March), hot and dry (March
to May), hot and wet (June to October)
Terrain: mostly flat to undulating plains;
mountains in northwest
Land use: 9% arable land; 4% permanent
crops; 9% meadows and pastures; 26%
forest and woodland; 52% other; includes
NEGL% irrigated
Environment: coast has heavy surf and no
natural harbors; deforestation
Special notes: none
Climate: temperate; hot, relatively dry
summers with mild, rainy winters along
coast; warm summer with cold winters
inland
Terrain: mostly mountains with large areas
of karst topography; plain in north
Land use: 28% arable land; 3% permanent
crops; 25% meadows and pastures; 36%
forest and woodland; 8% other; includes
1% irrigated
Environment: subject to frequent and
very destructive earthquakes
Special notes: controls the most important
land routes from central and western
Europe to Aegean Sea and Turkish Straits
Total area: 2,345,410 km?; land area:
2,267,600 km?
Comparative area: about one-fourth the
size of US
Land boundaries: 9,902 km total
Coastline: 37 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: sections with Congo
and Zambia are indefinite
Climate: tropical; hot, humid in river
basin; cooler, drier in southern highlands
Terrain: vast central basin is a low-lying
plateau; mountains in east
Land use: 3% arable land; NEGL% per-
manent crops; 4% meadows and pastures;
78% forest and woodland; 15% other;
includes NEGL% irrigated
Environment: straddles Equator; periodic
droughts in south
Special notes: very narrow strip of land is
only outlet to Atlantic Ocean','ed624ddfa53e3b14ed1dc557e90cdbc301a027270a63979825e7c9cd72d1e9e8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5967fb57e3ff69426196c07bcd5498687d565b2a8361a6db14521d80d92c7fae',1987,'JM','Jamaica','geography',372,'Total area: 10,990 km?; land area: 10,830
km?
Comparative area: slightly smaller than
Connecticut
Coastline: 1,022 km
Maritime claim:
Territorial sea: 12 nm
Climate: tropical; hot, humid; temperate
interior
Terrain: mostly mountains with narrow,
discontinuous coastal plain
Land use: 19% arable land; 6% permanent
crops; 18% meadows and pastures; 28%
forest and woodland; 29% other; includes
8% irrigated
Environment: subject to hurricanes, espe-
cially (May to December); deforestation;
water pollution
Special notes: strategic location between
Cayman Trench and Jamaica Channel, the
main sea lanes for Panama Canal','b7b07cbefdc9bf317a0a1613e0d0954f131ee34c853281c258444ea766962c8f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cecafb155df3fff73da7f94b88e8636f88592057c2929ee181d662a480d47d0',1987,'JE','Jersey','geography',377,'Total area: 117 km?; land area: 117 km?
Comparative area: slightly more than half
the size of Washington, D.C.
Coastline: 70 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: temperate; mild winters and cool
summers
Terrain: gently rolling plain with low
rugged hills along north coast
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
about 58% of land under cultivation
Environment: about 30% of population
concentrated in Saint Helier
Special notes: largest and southernmost of
Channel Islands; 27 km from France
Land boundaries: 435 km total
Climate: varies from tropical to near
temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Land use: 8% arable land; NEGL% per-
manent crops; 67% meadows and pastures;
6% forest and woodland; 19% other; in-
cludes 2% irrigated
Environment: overgrazing; soil degrada-
tion; soil erosion
Special notes: landlocked; almost an
enclave of South Africa','1dad8f6bfd5d4fc4c96f6dde713f1ed60a9ad07c51dc2d15ac7b8f71d59a5664','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6127a7079a515919eed5697bd94dad6156c59bf43fcf56188693b5daf81de1e0',1987,'JO','Jordan','geography',382,'Total area: 97,740 km?; land area: 97,180
km?
Comparative area: about the size of
Minnesota
Land boundaries: 1,770 km total (before
1967 war)
Coastline: 26 km
Maritime claim:
Territorial sea: 3 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; West Bank and
Gaza Strip are Israeli occupied with status
to be determined
Climate: mostly arid desert; rainy season
in west (November to March)
129
Terrain: mostly high desert plateau in east;
Great Rift Valley separates East and West
Banks of Jordan River
Land use: 4% arable land; .5% permanent
crops; 1% meadows and pastures; .5%
forest and woodland; 94% other; includes
.5% irrigated
Environment: lack of natural water re-
sources; deforestation; overgrazing; soil
erosion; desertification
Special notes: none','e630631bf0941197c2327c371c077d629bdf6c4f18ece5979ab85bd8053fad23','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd24f2edd37dcdd2677b7a1947bbe9e617ac2d1f5b4cce61d38299b71ec18da7',1987,'KE','Kenya','geography',387,'Total area: 582,650 km?; land area:
569,250 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 3,368 km total
Coastline: 536 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; international
boundary and Administrative Boundary
with Sudan; possible claim by Somalia
based on unification of ethnic Somalis
Climate: varies from tropical along coast
to arid in interior
Terrain: low plains rise to central high-
lands bisected by Great Rift Valley; fertile
plateau in west
Land use: 3% arable land; 1% permanent
crops; 7% meadows and pastures; 4% forest
and woodland; 85% other; includes
NEGL& irrigated
Environment: unique physiography sup-
ports abundant and varied wildlife of
immense scientific and economic value;
deforestation; soil erosion; desertification
Special notes: none
Total area: 360 km?; land area: 360 km?
Comparative area: about twice the size of
Washington, D. C.
Coastline: 135 km
Maritime claims:
Contiguous zone: 24 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: subtropical tempered by constant
sea breezes; little seasonal temperature
variation; one rainy season (May to No-
vember)
Terrain: volcanic with mountainous
interiors
Land use: 22% arable land; 17% perma-
nent crops; 3% meadows and pastures;
17% forest and woodland; 41% other
Environment: lies within Caribbean hurri-
cane belt
Special notes: none
Total area: 310 km?; land area: 310 km?
Comparative area: almost twice the size
of Washington, D. C.
Coastline: 60 km
Maritime claims:
Territorial sea: 3 nm
Climate: tropical; marine; mild, tempered
by trade winds
Terrain: rugged, volcanic; small scattered
plateaus and plains
Land use: 7% arable land; 0% permanent
crops; 7% meadows and pastures; 3% forest
and woodland; 83% other
Environment: very few perennial streams
Special notes: Ascension is major relay
station for cables running between Europe
and South Africa
Total area: 620 km?; land area: 610 km?
Comparative area: about one-fifth the size
of Rhode Island
Coastline: 158 km
Maritime claiins:
Exclusive fishing zone: 12 nm
Territorial sea: 8 nm
Climate: tropical marine, moderated by
northeast trade winds; dry season from
January to April, rainy season from May to
August
Terrain: mostly mountainous with some
broad, fertile valleys
Land use: 8% arable land; 20% permanent
crops; 5% meadows and pastures; 13%
forest and woodland; 54% other; includes
2% irrigated
Environment: subject to hurricanes and
mild volcanic activity; deforestation; soil
erosion
Special notes: none
Total area: 340 km?; land area: 340 km?
Comparative area: about twice the size of
Washington, D. C.
Coastline: 84 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 3 nm
Climate: tropical; little seasonal tempera-
ture variation; one rainy season (May to
November)
Terrain: volcanic, mountainous
Land use: 38% arable land; 12% perma-
nent crops; 6% meadows and pastures;
41% forest and woodland; 3% other; in-
cludes 3% irrigated
Environment: subject to hurricanes;
Soufriére volcano a constant threat
Special notes: islands of the Grenadines
group are divided politically with Grenada','b0806384d7199331c9ec7ac0db0374e505aee30b2be183407b3f1578185e95d2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bffba3038af3a1fd1a2ccdb4a6110416ea1be8841e2cf4fb31ad01219719a8c',1987,'KI','Kiribati','geography',392,'Total area: 710 km; land area: 710 km?
Comparative area: about four times the
size of Washington, D. C.
Coastline: 1,143 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; marine, hot and humid,
moderated by trade winds
Terrain: mostly low lying coral atolls
surrounded by extensive reefs
Land use: 0% arable land; 51% permanent
crops; 0% meadows and pastures; 3% forest
and woodland; 46% other
Environment: typhoons can occur any
time, but usually November to March
Special notes: Banaba or Ocean Island is
one of three great phosphate rock islands
in the Pacific (others are Makatea in
French Polynesia and Nauru)
Total area: 120,540 km?; land area:
120,410 km?
Comparative area: slightly smaller than
Mississippi
Land boundaries: 1,675 km total
Coastline: 2,495 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Military boundary line: 50 nm (all
foreign vessels and aircraft are banned
without permission)
Boundary disputes: short section with
China is indefinite; Demarcation Line with
South Korea
Climate: temperate with rainfall concen-
trated in summer
Terrain: mostly hills and mountains sepa-
rated by deep, narrow valleys; coastal
plains wide in west, discontinuous in east
Land use: 18% arable land; 1% permanent
crops; NEGL% meadows and pastures;
74% forest and woodland; 7% other; in-
cludes 9% irrigated
Environment: mountainous interior is
isolated, nearly inaccessible, and sparsely
populated; late spring droughts often
followed by severe flooding
Special notes: occupies northern half of
Korean peninsula; strategic location bor-
dering China, South Korea, and USSR
Total area: 98,480 km?; land area: 98,190
km?
Comparative area: slightly larger than
Indiana
Land boundary: 241 km with North
Korea
Coastline: 2,413 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 12 nm (3 nm in the
Korea Strait)
Boundary disputes: Demarcation Line
with North Korea; Liancourt Rocks dis-
puted with Japan
Climate: temperate; cold, dry, clear win-
ters with hot and humid summers
Terrain: mostly rugged and mountainous
Land use: 21% arable land; 1% permanent
crops; 1% meadows and pastures; 67%
forest and woodland; 10% other; includes
12% irrigated
Environment: occasional typhoons bring
high winds, floods, landslides; water pollu-
tion; air pollution
Special notes: strategic location along
Korea Strait and between Chinese, Japa-
nese, and Soviet spheres of influence','cc6ebf7d8d547377d30b31e46985490ab746a11156f957deb2989f85ad4b3ef8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe269d5f0902b4724d528a055e5f84fef43ca5e31ae9540f265a440afbe3e548',1987,'KW','Kuwait','geography',396,'Total area: 17,820 km?; land area: 17,820
km?
Comparative area: slightly smaller than
New Jersey
Land boundaries: 490 km total
Coastline: 499 km
Maritime claims:
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; ownership of
Warbah and Babiyan islands disputed by','ec1ffc5170110369cdf01a26642f7806e4a2674661d67f4afc3f744e644fe75c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f24d58f69862429a0d2697efc1455bcad53be19538039381f8616dc0c1128a',1987,'LB','Lebanon','geography',398,'Total area: 10,400 km?; land area: 10,230
km?
Comparative area: smaller than Connecti-
cut
Land boundaries: 531 km total
Coastline; 225 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; Israeli troops in
southern Lebanon since June 1982
Climate: Mediterranean; mild to cool, wet
winters with hot, dry summers
Terrain: narrow coastal plain; A! Biaa‘
(Bekaa Valley) separates Lebanon and
Anti-Lebanon Mountains
Land use: 21% arable land; 9% permanent
crops; 1% meadows and pastures; 8% forest
and woodland; 61% other; includes 8%
irrigated
Environment: rugged terrain has histori-
cally helped isolate, protect, and develop
numerous factional groups based on reli-
gion, clan, ethnicity; deforestation; soil
erosion; air and water pollution; desertifi-
cation
Special notes: Nahr al Litani only river in
Near East not crossing an international
boundary','275f52d7081830bfcdef624a4c0947d6342792f26027315e18fc3d705ee8073b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3c2af5af28d5f1c6c3bda01a4373dc0ef6d92b6c0079ee5d2346152df47f578',1987,'LS','Lesotho','geography',402,'Total area: 30,350 km?; land area: 30,350
km?
Comparative area: slightly larger than
Maryland
Land boundary; 805 km with South
Africa
Climate: temperate; cool to cold, dry
winters; hot, wet summers
Terrain: mostly highland with some pla-
teaus, hills, and mountains
Land use: 10% arable land; 0% permanent
crops; 66% meadows and pastures; 0%
forest and woodland; 24% other
Environment: population pressure forcing
settlement in marginal areas resulting in
overgrazing, severe soil erosion, soil ex-
haustion; desertification
Special notes: landlocked; enclave of','e79efad5a7ef361614d1f2b791ba43faf7bd0a5e455c575c699615752860e140','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6edba075393a5d598e26c9c435d798679fa0e2ec75fe2c9d7da5d16293b2b1bc',1987,'LR','Liberia','geography',408,'Total area: 111,370 km?; land area: 96,320
km?
Comparative area: slightly smaller than
Pennsylvania
Land boundaries: 1,336 km total
Coastline: 579 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters
with hot days and cool to cold nights; wet,
cloudy summers with frequent heavy
showers
Terrain: mostly flat to rolling coastal plains
rising to rolling plateau and low mountains
in northeast
Land use: 1% arable land; 3% permanent
crops; 2% meadows and pastures; 39%
forest and woodland; 55% other; includes
NEGL% irrigated
Environment: West Africa’s largest tropi-
cal rainforest subject to deforestation
Special notes: none','d6026314ac086e8662411c097a16705e6ed786d5a016a5787d09d564a5bc4ee8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90988e611a52850850e763625975a8d7aff588b0f41414fc3a03481806e55a12',1987,'LY','Libya','geography',413,'Total area: 1,759,540 km?; land area:
1,759,540 km?
Comparative area: larger than Alaska
Land boundaries: 4,345 km total
Coastline: 1,770 km
Maritime claims:
Territorial sea: 12 nm
Gulf of Sidra closing line: 32° 30''N
Boundary disputes: none; claims Aozou
Strip in northern Chad; occupies northern
Chad; maritime dispute with Tunisia
Climate: Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Land use: 1% arable land; 0% permanent
crops; 8% meadows and pastures; 0% forest
and woodland; 91% other; includes
NEGL% irrigated
Environment: hot, dry, dust-laden ghibli is
a southern wind lasting 1-4 days in spring
and fall; desertification; sparse natural
water resources
Special notes: largest water development
scheme in world being built to bring water
from deep wells under Sahara Desert to
coast','a5153be5fce4adae92550c79a57677c74edc4b1607233c86db6c5b64a3984022','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30c4216d4ac3dc07f2e20d6e1768daf3a4e490e12eca7fc5b95dfe39299863aa',1987,'LI','Liechtenstein','geography',418,'Total area: 160 km?; land area: 160 km?
Comparative area: slightly smaller than
Washington, D.C.
Land boundaries: 76 km total
Climate: continental; cold, cloudy winters
with frequent snow or rain; cool to moder-
ately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with
Rhine Valley in western third
Land use: 25% arable land; 0% permanent
crops; 38% meadows and pastures; 19%
forest and woodland; 18% other
Environment: variety of microclimatic
variations based on elevation
Special notes: landlocked','b5135ab497fe02ebfe9add03fb542e046a25400ae8f8e0e93bdfd04d50d43b45','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('890a18aa01714af3ad27d334b1de8dceca718e4c6bffe9dd2adb77a2cd1b7c46',1987,'LU','Luxembourg','geography',423,'Total area: 2,586 km?; land area: 2,586
km?
Comparative area: smaller than Rhode
Island
Land boundaries: 356 km total
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad shallow valleys; uplands to
slightly mountainous in north
Land use: 24% arable land; 1% permanent
crops; 20% meadows and pastures; 21%
forest and woodland; 34% other
Environment: deforestation
Special notes: landlocked
Total area: 20 km?; land area: 20 km?
Comparative area: about one-ninth the
size of Washington, D.C.
Land boundary: 201 meters with China
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 6 nm
Boundary disputes: none; will become a
Special Administrative Region of China in
1999
Climate: tropical; marine with cool win-
ters, warm summers
Terrain: generally flat
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: essentially urban; one
causeway and one bridge connect the two
islands to the peninsula on mainland
Special notes: none','c625061f7b4b792979d8b797551f3a7053a6c2cbd8a7afe3f93626a0a698eac3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6fffede4a7a065039e38d003afdcf58acdff8b4dec24fa7005eccce0f357a4c',1987,'MG','Madagascar','geography',428,'Total area: 587,040 km?; land area:
581,540 km?
Comparative area: slightly smaller than
Texas
Coastline: 4,828 km
Maritime claims:
Continental shelf: 150 nm
Exclusive fishing zone: 150 nm
Extended economic zone: 150 nm
Territorial sea: 50 nm
Boundary disputes: none; claims French-
administered Bassas da India, Europa
island, Juan de Nova Island, Glorioso
Islands, Tromelin Island
Climate: tropical along coast, temperate
inland, arid in south
Terrain: narrow coastal plain, high plateau
and mountains in center
Land use: 4% arable land; 1% permanent
crops; 58% meadows and pastures; 26%
forest and woodland; 11% other; includes
1% irrigated
Environment: subject to periodic cyclones;
deforestation; overgrazing; soil erosion;
desertification
Special notes: world’s fourth largest
island; important location along Mozam-
bique Channel','568a34885590a9e577b6a8ba683b3dd49d983c28ea7a7599b4670fee3fa2c376','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0c009ea5d0cac556d4a45251c889f243732acba7961cd2031c3228c66b9123',1987,'MW','Malawi','geography',433,'Total area: 118,480 km?; land area: 94,080
km?
Comparative area: about the size of
Pennsylvania
Land boundaries: 2,881 km total
Boundary disputes: none; maritime dis-
pute with Tanzania
Climate: tropical; rainy season (November
to May); dry season (May to November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun-
tains
Land use: 25% arable land; NEGL%
permanent crops; 20% meadows and
pastures; 50% forest and woodland; 5%
other; includes NEGL% irrigated
Environment: deforestation
Special notes: landlocked','9553a097a8eaff473bf3b41749cee77c5ce56f6c405c7d3e21e60d091f9d060d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d274165cb9eae7be4842c184f3cb303aa3e20c5437c81e4a2bd57c0d018ed04',1987,'MY','Malaysia','geography',438,'Total area: 329,750 km?; land area:
328,550 km?
Comparative area: slightly larger than
New Mexico
Land boundaries: 2,295 km total
Coastline: 4,675 km total (2,068 km Pen-
insular Malaysia, 2,607 km East Malaysia)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; involved in
complex dispute over Spratly Islands with
China, Philippines, Taiwan, Vietnam, and
possibly Brunei
Climate: tropical; annual southwest (April
to October) and northest (October to
February) monsoons
Terrain: coastal plains rising to hills and
mountains
Land use: 3% arable land; 10% permanent
crops; NEGL% meadows and pastures;
63% forest and woodland; 24% other;
includes 1% irrigated
Environment: subject to flooding; air and
water pollution
Special notes: strategic location along
Strait of Malacca; occupies southern half
of Malay Peninsula and northern quarter
of island of Borneo
151','91db8770232f7996009c8a0c21faf408bb968609e63f679c0a7d7fa83244a32d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd8328388a1dd159e4d7d8a8e8b858b3169a2bfe90d034793a1c072a78a16967',1987,'MV','Maldives','geography',442,'Total area: 300 km?; land area: 300 km?
Comparative area: about twice the size of
Washington D.C.
Coastline: 644 km
Maritime claims:
Exclusive fishing zone: about 100 nm
(defined by geographic coordinates)
Extended economic zone: irregular
polygon varying in breadth from about
85 nm to more than 300 nm
Territorial sea: irregular polygon vary-
ing in breadth from less than 3 nm to
about 55 nm
Climate: tropical; hot, humid; dry, north-
west monsoon (November to March); rainy,
southwest monsoon (June to August)
Terrain: flat with elevations only as high
as 2.5 meters
Land use: 10% arable land; 0% permanent
crops; 8% meadows and pastures; 3% forest
and woodland; 84% other
Environment: 1,200 coral islands grouped
into 19 atolls
Special notes: strategic location astride
and along major sea lanes in Indian Ocean','d69a0d67570afec6ceb5f1e7b2acceb887cb6cba526e8d3b0be31aa19a83104e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70e2ec25b617f43cc9309814a9dcc2f85c7ec360358035c09a8cedff77786a33',1987,'ML','Mali','geography',447,'Total area: 1,240,000 km?; land area:
1,220,000 km?
Comparative area: larger than California
and Texas combined
Land boundaries: 7,459 km total
Climate: subtropical to arid; hot and dry
February to June; rainy, humid, and mild
June to November; cool and dry Novem-
ber to February
Terrain: mostly flat to rolling northern
plains covered by sand; savanna in south,
rugged hills in northeast
Land use: 2% arable land; NEGL% per-
manent crops; 25% meadows and pastures;
7% forest and woodland; 66% other; in-
cludes NEGL% irrigated
Environment: hot, dust-laden harmattan
haze common during dry seasons; deserti-
fication; recent droughts affecting marginal
agriculture
Special notes: landlocked','8f4990cfbf499f44fc79197a8f383e72c5d6fe2b0bc451f9328555318bb113b3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30cd34eb29ccbe5846cef4f7c0ecbdc99472120a8cab691dd6a47071098782e5',1987,'MT','Malta','geography',452,'Total area: 320 km?; land area: 320 km?
Comparative area: about twice the size of
Washington, D.C.
Coastline: 140 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 25 nm
Territorial sea: 12 nm
Climate: Mediterranean with mild, rainy
winters and hot, dry summers
Terrain: mostly low, rocky, flat to dis-
sected plains; many coastal cliffs
Land use: 38% arable land; 3% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 59% other; includes 3%
irrigated
Environment: numerous bays provide
good harbors
Special notes: strategic location in central
Mediterranean, 93 km south of Sicily, 290
km north of Libya
Total area: 588 km?; land area: 588 km?
Comparative area: about three times the
size of Washington, D. C.
Coastline: 113 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: cool summers and mild winters;
humid; overcast about half the time
Terrain: coastal plains in north and south
connected by valley bisecting hilly interior
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other;
extensive arable land and forests
Environment: strong westerly winds
prevail
Special notes: located in Irish Sea equidis-
tant from England, Scotland, and Ireland','d9f56d0ae35564ae447f956bf885d0be1f0b74f9c2350241edd8742badb947e2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ded6d216b4341afbe8a40ce5d43c100d7cbcf6a3850df68eccfef6e8c6b202',1987,'MQ','Martinique','geography',457,'Total area: 1,100 km?; land area: 1,060
km?
Comparative area: slightly smaller than
Rhode Island
Coastline: 290 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds; rainy season (June to October)
Terrain; mountainous with indented
coastline
Land use: 10% arable land; 8% permanent
crops; 30% meadows and pastures; 26%
forest and woodland; 26% other; includes
5% irrigated
Environment: subject to hurricanes,
flooding, and volcanic activity that results
in an average of one major natural disaster
every five years
Special notes: northernmost of Windward
Islands','30cc290cff4f0a6c80d76882dd529ba00e2fde8cfa736e9ab978b425a99e142c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21dede474f534608f958b41e0703af2a122ef8cf0f65493a527a9319d1e5954f',1987,'MR','Mauritania','geography',462,'Total area: 1,080,700 km?; land area:
1,030,400 km?
Comparative area: about the size of
California and Texas combined
Land boundaries: 5,118 km total
Coastline: 754 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 70 nm
Boundary disputes: none; Western Sahara
question with Morocco
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of
Sahara Desert; some central hills
Land use: NEGL% arable land; NEGL%
permanent crops; 38% meadows and
pastures; 15% forest and woodland; 47%
other; includes NEGL% irrigated
Environment: hot, dry, dust/sand-laden
sirocco wind blows primarily in March
and April; desertification; only perennial
river is the Senegal
Special notes: none','d77f86f8fbafc8df3f33901d89c7329a8d4f4a11b0da32c1a009f0f57db39a22','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7fe1a04ce7c66cbe34066f67c3d20e32bcd8503daea76c50e2041fc5e0e7340',1987,'MU','Mauritius','geography',467,'Total area: 1,860 km?; land area: 1,850
km?
Comparative area: smaller than Rhode
Island
Coastline: 177 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims island of
Diego Garcia in UK-administered British
Indian Ocean Territory; claims French-
administered Tromelin Island
Climate: tropical modified by southeast
trade winds; warm, dry winter (May to
November); hot, wet, humid summer
(November to May)
Terrain: small coastal plain rising to dis-
continuous mountains encircling central
plateau
Land use: 54% arable land; 4% permanent
crops; 4% meadows and pastures; 31%
forest and woodland; 7% other; includes
9% irrigated
Environment: subject to cyclones (Novem-
ber to April); almost completely sur-
rounded by reefs
Special] notes: none','b376eeb53caf57d0eabe070bfcee5dc813b883446446b28c163c2f79af137a07','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9954d146bc9b0d474b40422fe08394e134b5e5d4e6f85dc98a9e6e66d9372950',1987,'KM','Comoros','geography',471,'Climate: tropical; marine; hot, humid,
rainy season during northeastern monsoon
(November to May); dry season is cooler
(May to November)
Terrain: generally undulating with ancient
volcanic peaks, deep ravines
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to cyclones during
rainy season
Special notes: none','b9d807073069b899e02c63066d9bc2986d4e3969d78d3f250766203367dbaeb1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa82dae701c004244b29e496521ce1576dab855b8359b41bbdee374aede8f688',1987,'MX','Mexico','geography',476,'Total area: 1,972,550 km; land area:
1,923,040 km?
Comparative area: about three times the
size of Texas
Land boundaries: 4,220 km total
Coastline: 9,330 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 2 nm
Climate: varies from tropical to desert
Terrain: mostly high, ragged mountains
with low coastal plains and high plateaus
Land use: 12% arable land; 1% permanent
crops; 89% meadows and pastures; 24%
forest and woodland; 24% other; includes
8% irrigated
Environment: subject to destructive earth-
quakes in center and south; natural water
resources scarce in north, inaccessible and
poor quality in center and extreme south-
east; deforestation; soil erosion widespread;
desertification
Special notes: strategic location on south-
ern border of US
Land boundaries: 2,579 km total
Coastline: 21,925 km (3,419 km mainland;
2,413 kim large islands; 16,093 km long
fjords, numerous small islands, and minor
indentations)
Maritime claims:
Contiguous zone: 10 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 4 nm
Boundary disputes: none; maritime dis-
pute with USSR; territorial claim in Ant-
arctica (Queen Maud Land)
Climate: temperate along coast, modified
by Gulf Stream; colder interior
Terrain: glaciated; mostly high plateaus
and rugged mountains broken by fertile
valleys; small, scattered plains; coastline
deeply indented by fjords; arctic tundra in
north
Land use: 3% arable land; 0% permanent
crops; NEGL% meadows and pastures;
27% forest and woodland; 70% other;
includes NEGL% irrigated
Environment: air and water pollution;
acid rain
Special notes: strategic location adjacent
to sea lanes and air routes in North Atlan-
tic; one of most rugged and longest coast-
lines in world; Norway and Turkey only
NATO members having a boundary with
the USSR
Land boundaries: 1,384 km total
Coastline: 2,092 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Administrative Line
with PDRY; no defined boundary with
most of UAE, Administrative Line in far
north; no defined boundary with Saudi
Arabia
Climate: dry desert; hot, humid along
coast; hot, dry interior; strong southwest
summer monsoon (May to September) in
far south
Terrain: vast central desert plain, rugged
mountains in north and south
Land use: NEGL% arable land; NEGL%
permanent crops; 5% meadows and pas-
tures; 0% forest and woodland; 95% other;
includes NEGL% irrigated
Environment: summer winds often raise
large sandstorms and duststorms in inte-
rior; sparse natural fresh water resources
Special notes: strategic location with small
foothold on Musandam Peninsula control-
ling Strait of Hormuz (17% of world’s
daily oil production transits this point
going from Persian Gulf to Arabian Sea)
188
Land boundaries: 3,090 km total
Coastline: 491 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain, mountains along
southern border
Land use: 48% arable land; 1% permanent
crops; 18% meadows and pastures; 29%
forest and woodland; 9% other; includes
NEGL& irrigated
Environment: plain crossed by a few
north-flowing, meandering streams
Special notes: historic area on North
European Plain for conflict because of flat
terrain and lack of natural barriers
Land boundaries: 4,562 km total
Coastline: 3,444 km (excluding islands)
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Cambodia (three
areas); occupies Cambodia; sporadic border
clashes with China; involved in complex
dispute over Spratly Islands with China,
Malaysia, Philippines, Taiwan, and possi-
bly Brunei; maritime dispute with China;
dispute with China over Paracel Islands
Climate: tropical in south; monsoonal in
north with hot, rainy season (mid-May to
mid-September) and warm, dry season
(mid-October to mid-March)
Terrain: low, flat delta in south and north;
central highlands; hilly, mountainous in far
north and northwest
Land use: 22% arable land; 2% permanent
crops; 1% meadows and pastures; 40%
forest and woodland; 35% other; includes
5% irrigated
Environment: occasional typhoons (May to
January) with extensive flooding
Special notes: none
262','82c95b8407560e530df45dff3dcccd95b49243e5c463be2f268f03071323a127','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262c754fa706928dec8c4aeafcbcc4b3cd772420189c044ca2ec8df245bd3d64',1987,'MC','Monaco','geography',480,'Total area: 1.9 km?; land area: 1.9 km?
Comparative area: about one-hundredth
the size of Washington, D.C.
Land boundary: 3.7 km with France
Coastline: 4.1 km
Maritime claim:
Territorial sea: 12 nm
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: almost entirely urban
Special notes: second smallest indepen-
dent state in world (after Vatican City)','64d3e666a60c9942bfb50cacd41242f8aaaab057a65397aeba777d3c92e18d94','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('108d3beba6fd3f5eb55a800a89f5d2a4e144f6035a490f7df4ae768234dfe2c0',1987,'MN','Mongolia','geography',485,'Total area: 1,565,000 km?; land area:
1,565,000 km?
Comparative area: more than twice the
size of Texas
Land boundaries: 8,000 km total
Climate: desert; cold, dry, continental;
sharp seasonal variation
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi
Desert in southeast
Land use: 1% arable land; 0% permanent
crops; 79% meadows and pastures; 10%
forest and woodland; 10% other; includes
NEGL% irrigated
Environment: harsh and rugged
Special notes: landlocked; strategic loca-
tion between China and Soviet Union','19352b9afe4dbbac21f4d994c720bf000f45305956954ac739e9c88e45c57267','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34974ce121ab699eaf5aeb5248579aa481d3ccabaf81ea8739bd89fb98bb32b9',1987,'MS','Montserrat','geography',490,'Total area: 100 km?; land area: 100 km?
Comparative area: about one-half the size
of Washington, D.C.
Coastline: 40 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Climate: tropical; little daily or seasonal
temperature variation
Terrain: volcanic islands, mostly moun-
tainous, with small coastal lowland
Land use: 20% arable land; 0% permanent
crops; 10% meadows and pastures; 40%
forest and woodland; 30% other
Environment: subject to severe hurricanes
(especially June to December)
Special notes: none','f924e593dc234cb3b20b734e8f69280cfa087aa1986b2c9852aa19ea0d7c023c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e142a29fc9c179f255020b9b4789642936ca6e06d6e971eee99d74abb2be27c0',1987,'MA','Morocco','geography',495,'Total area: 446,550 km?; land area:
446,300 km?
Comparative area: about the same size as
California
Land boundaries: 1,996 km total
Coastline: 1,835 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; claims and
administers Western Sahara, but sover-
eignty is unresolved; Western Sahara
question with Mauritania; Spain controls
two coastal presidios or places of sover-
eignty (Ceuta, Melilla)
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: mostly mountains with rich
coastal plains
Land use: 18% arable land; 1% permanent
crops; 28% meadows and pastures; 12%
forest and woodland; 41% other; includes
1% irrigated
Environment: northern mountains geologi-
cally unstable and subject to earthquakes;
desertification
Special notes: strategic location along
Strait of Gibraltar','ba6d8d86c0dec388f8e85af1c89c0133157a0711ddcc874725ae521ab2d67437','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5483cc776b1e4c72508dcd7a8cf5ae50601a34cd3f023c5e95f5f6fa1bab5273',1987,'MZ','Mozambique','geography',500,'Total area: 801,590 km?; land area:
784,090 km?
Comparative area: about the size of Texas
Land boundaries: 4,627 km total
Coastline: 2,470 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus in northwest,
mountains in west
Land use: 4% arable land; NEGL% per-
manent crops; 56% meadows and pastures;
20% forest and woodland; 20% other;
includes NEGL% irrigated
Environment: severe drought and floods
occur in south; desertification
Special notes: none','cbb0d059902d99335de5e96e876288a85c4dc2bdf18b17f049e3c45db89829f2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ea1495f85c38702e4eb63a2703ee114bcb1dee2d1ec4153e3d323e3624b1e7',1987,'NA','Namibia','geography',505,'Total area: 824,290 km?; land area:
823,290 km?
Comparative area: about twice the size of
California
Land boundaries: 3,798 km total
Coastline: 1,489 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 6 nm
Boundary disputes: short section with
Botswana is indefinite; occupied by South
Africa
Climate: desert; hot, dry; rainfall sparse
and erratic
Terrain: mostly high plateau; Namib
Desert along coast; Kalahari Desert in east
Land use: 1% arable land; NEGL% per-
manent crops; 64% meadows and pastures;
22% forest and woodland; 13% other;
includes NEGL% irrigated
Environment: inhospitable with very
limited natural water resources; desertifi-
cation
Special notes: Walvis Bay area of South
Africa is almost an enclave
Climate: mostly dry desert, subtropical
along coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Land use: 10% arable land; 1% permanent
crops; 65% meadows and pastures; 3%
forest and woodland; 21% other; includes
1% irrigated
Environment: lack of important arterial
rivers or Jakes requires extensive water
conservation and control measures
Special notes: Walvis Bay is almost an
enclave of Namibia; Lesotho is an enclave
Total area: 22,402,200 km?; land area:
22,272,000 km?
Comparative area: almost two and one-
half times the size of US
Land boundaries: 20,217 km total
Coastline: 108,346 km (60,085 km main-
land; 48,261 islands)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: China (Pamir, Argun,
Amur, and Khabarovsk areas); US Govern-
ment has not recognized incorporation of
Estonia, Latvia, and Lithuania into Soviet
Union; Habomai Islands, Etorofu, Kunash-
iri, and Shikotan islands occupied by
Soviet Union since 1945, claimed by
Japan; Kuril Islands administered by
Soviet Union; maritime disputes with
Sweden, Norway; has made no territorial
claim in Antarctica (but has reserved the
right to do so) and does not recognize the
claims of any other nation; Bessarabia
question with Romania
Climate: mostly temperate to arctic conti-
nental; winters vary from cool along Black
Sea to frigid in Siberia; summers vary
from hot in southern deserts to cool along
Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra in
Siberia, deserts in Central Asia, mountains
in south
Land use: 10% arable land; NEGL%
permanent crops; 17% meadows and
pastures; 41% forest and woodland; 32%
other; includes 1% irrigated
Environment: despite size and diversity,
small percentage of land is arable and
much is too far north; some of most fertile
land is water deficient or has insufficient
growing season; many better climates have
poor soils; hot, dry, desiccating sukhovey
wind affects south; desertification
Special notes: largest country in world,
but unfavorably located in relation to
major sea lanes of world','c4a10309429ae4658aa2eae2f37f213b7b5a4e584e60cd36d2fe513676501924','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6fe531909743dc6d81ccd82f19190fea20c403ad953d1454ea3418487e1866',1987,'NR','Nauru','geography',510,'Total area: 20 km?; land area: 20 km?
Comparative area: about one-ninth the
size of Washington, D.C.
Coastline: 24 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: only 53 km south of
Equator
Special notes: one of three great phos-
phate rock islands in the Pacific (others are
Banaba or Ocean Island in Kiribati and
Makatea in French Polynesia)','9de3afe857f7e1d3dc674bb8700e575864fc4f68e3b9cce5670c7ed44eb03437','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4efaf0d9116ca22a91589f223cf9530d52cdac6d2e814a29266342c8b6e831f5',1987,'NP','Nepal','geography',515,'Total area: 140,800 km?; land area:
136,800 km?
Comparative area: about the size of North
Carolina
Land boundaries: 2,800 km total
Climate: varies from cool summers and
severe winters in north to subtropical
summers and mild winter in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region, rugged
Himalayas in north
Land use: 17% arable land; NEGL%
permanent crops; 13% meadows and
pastures; 33% forest and woodland; 37%
other; includes 2% irrigated
Environment: contains eight of world’s ten
highest peaks; deforestation; soil erosion;
water pollution
Special notes: landlocked; strategic loca-
tion between China and India','fca96a9fd37700d57d899333aabb1f473e8ab7ee54f29122c121905fa612bda1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7c305219830dce799283673c5ffd69a294660979bfd8c39eb64e10ebf3d0142',1987,'NL','Netherlands','geography',520,'Total area: 37,310 km?; land area: 33,940
km?
Comparative area: about the size of
Massachusetts, Connecticut, and Rhode
Island combined
Land boundaries: 1,022 km total
Coastline: 451 km
Maritime claims:
Contiguous zone: 12 nm
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Climate: temperate; marine; cool summers
and mild winters
Terrain: mostly coastal lowland and re-
claimed land (polders); some hills in south-
east
Land use: 25% arable land; 1% permanent
crops; 34% meadows and pastures; 9%
forest and woodland; 31% other; includes
15% irrigated
Environment: dikes protect 30% of land
area that is below sea level from North Sea
Special notes: located at mouths of three
major European rivers (Rhine, Maas or
Meuse, Schelde)
Total area: 960 km?; land area: 960 km?
Comparative area: about one third the
size of Rhode Island
Coastline: 364 km
Maritime claims:
Territorial sea: 12 nm
Climate: tropical; modified by northeast
trade winds
Terrain: generally hilly, volcanic interiors
Land use: 8% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 92% other
Environment: south of Carribean hurri-
cane belt, so rarely threatened
Special notes: none','2c771684b93fa3312fc00029027084741728ae0e64a0ff95b678f872f11253c9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc96a0e0f4b464f3ef5030d19aee2a5793a9b41941bb0b920375501b3d24601d',1987,'NC','New Caledonia','geography',525,'Total area: 19,060 km?; land area: 18,760
km?
Comparative area: about the size of
Massachusetts
Coastline: 2,254 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended econamic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by southeast
trade winds; hot, humid
Terrain: coastal plains with interior moun-
tains
Land use: NEGL% arable land; NEGL%
permanent crops; 14% meadows and
pastures; 51% forest and woodland; 35%
other
Environment: typhoons most frequent
from November to March
Special notes: none','6092d24273f0b92b6c06fb8527a6994829c8064d6fda29fef021cb7da9fe0f6a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('014f9bed3fc34539c9b553787c027d0ff8227fd222fc7ce3262f8da73bc20fa6',1987,'NZ','New Zealand','geography',530,'Total area: 268,680 km; land area:
268,670 km?
Comparative area: about the size of
Colorado
Coastline: 15,184 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; territorial claim
in Antarctica (Ross Dependency)
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous with
some large coastal plains.
Land use: 2% arable land; 0% permanent
crops; 53% meadows and pastures; 38%
forest and woodland; 7% other; includes
1% irrigated
Environment: earthquakes are common,
though usually not severe
Special notes: none','af512d24e9d050622cf4883e765e887f6d9687aa4af2b041214c630c2f0c393f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('889f8383940c39ea12a32b230d18d9a4122470aa3df791b1ffe36e4c58fbb546',1987,'NI','Nicaragua','geography',537,'Total area: 130,000 km?; land area:
118,750 km?
Comparative area: about the size of lowa
Land boundaries: 1,220 km total
Coastline: 910 km
Maritime claims:
Continental shelf: 200 meters depth
Territorial sea: 200 nm
Boundary disputes: none; Nicaraguan
interruption of transit in the Rio San Juan
(the internationa] boundary) is an occa-
sional source of friction with Costa Rica;
territorial dispute with Columbia over San
Andres and Providencia Archipelago
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive coastal plains rising to
interior mountains
Land use: 9% arable land; 1% permanent
crops; 43% meadows and pastures; 35%
forest and woodland; 12% other; including
1% irrigated
Environment: subject to destructive earth-
quakes, volcanoes, and landslides; defores-
tation; soil erosion; water pollution
Special notes: none','803709d607263344e3788c885fa65c7807d58ceba1824d65c6497d97d970fb1a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f7755c9e580cf13e4a3e666bbdfa7babf0444089984cabcc6672008de22e1f',1987,'NE','Niger','geography',542,'Total area: 1,267,000 km?; land area:
1,266,700 km?
Comparative area: almost three times the
size of California
Land boundaries: 5,745 km total
Climate: desert; mostly hot, dry, dusty;
tropical in south
Terrain: predominately desert plains and
sand dunes; flat to rolling plains in south
Land use: 3% arable land; 0% permanent
crops; 7% meadows and pastures; 2% forest
and woodland; 88% other; includes
NEGL% irrigated
Environment: recent drought and deserti-
fication severely affecting marginal agri-
cultural activities; overgrazing; soil erosion
Special notes: landlocked','1b0292803843c80c3be1b663c00441c101d1ba403afeea0273047f490f604198','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68734ade41356c434fd6baff505eb85d756444c40cea0a4c4b27b1b496a506d3',1987,'NU','Niue','geography',550,'Total area: 260 km?; land area: 260 km?
Comparative area: one and one-half times
the size of Washington, D.C.
Coastline: 64 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by southeast
trade winds
Terrain: steep limestone cliffs along coast,
central plateau
Land use: 61% arable land; 4% permanent
crops; 4% meadows and pastures; 19%
forest and woodland; 12% other
Environment: subject to typhoons
Special notes: one of world’s largest coral
islands','d5e50a6d62f9e96f97b35bb7b55a01471c9da7e2dccf82d228be8d8c98e5c82a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aa10be5f05d00df621070adce9748ed9bae0335e0348ab78d1c17b954bcafed',1987,'NF','Norfolk Island','geography',555,'Total area: 40 km?; land area: 40 km?
Comparative area: less than one-fourth
the size of Washington, D.C.
Coastline: 32 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 8 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly
rolling plains
Land use: 0% arable land; 0% permanent
crops; 25% meadows and pastures; 0%
forest and woodland; 75% other
Environment: subject to typhoons (espe-
cially May to July)
Special notes: none','e663e13bd38e7b4f1356ef14c60bfe239a1e5a2edbab924d42ff0d89d4647c9e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2abbc26f24e5f044cb50a542766601f9e424f94d8fbeca79223b92477c4cd4d',1987,'NO','Norway','geography',560,'Total area: 324,220 km?; land area:
307,860 km?
Comparative area: about the size of New','b7e5fa13b09c27ecf02b2e08e8fabdd73dc422cd8567f6e4218affeb9a29c2e1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2948c6eb169aa004224dac2db1fca82f0ad68c177becfc9f62c6f81eca0f0738',1987,'OM','Oman','geography',562,'Total area: 212,460 km?; land area:
212,460 km?
Comparative area: about the size of New
Total area: 803,940 km?; land area:
778,720 km?
Comparative area: about the size of Texas
Land boundaries: 5,900 km total
Coastline: 1,046 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: Cease-Fire Line with
India; Pushtunistan and Baluchistan ques-
tions with Afghanistan
Climate: mostly hot, dry desert; temperate
in northwest; arctic in north
Terrain: flat Indus plain in east; mountains
in north and northwest; Baluchistan Pla-
teau in west
Land use: 26% arable land; NEGL%
permanent crops; 6% meadows and pas-
tures; 4% forest and woodland; 64% other;
includes 19% irrigated
Environment: frequent earthquakes,
occasionally severe especially in north and
west; flooding along the Indus after heavy
rains (July and August); deforestation; soil
erosion; desertification
Special notes: controls Khyber Pass, tradi-
tional invasion route between Afghanistan
and Pakistan
Pakistan (continued)','f7d85371832fe420edbd24dde812a0ca27074e4c792f28fa6b89831004e45384','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8430dd6bd56ef1d83be81698076de37101de33b67a7899ce04c1d7ab2d76d10f',1987,'PA','Panama','geography',568,'Total area: 77,080 km?; land area: 75,990
km?
Comparative area: slightly larger than
West Virginia
Land boundaries: 630 km total
Coastline: 2,490 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy;
prolonged rainy season (May to January),
short dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains;
coastal areas largely plains and rolling hills
Land use: 6% arable land; 2% permanent
crops; 15% meadows and pastures; 54%
forest and woodland; 23% other; includes
NEGL®% irrigated
Environment: dense tropical forest in east
and northwest
Special notes: strategic location on eastern
end of isthmus forming land bridge con-
necting North and South America; controls
Panama Canal that links Atlantic Ocean
via Caribbean Sea with Pacific Ocean','918238a48c52ec07512a40632ff04eee91c5db4cc89af645c41c806915d609cb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ab0b1b0598635e15d594822337cdd05f8bb333bb20a649765092dc3496ba079',1987,'PG','Papua New Guinea','geography',573,'Total area: 461,690 km?; land area:
451,710 km?
Comparative area: slightly larger than
California
Land boundary: 966 km with Indonesia
Coastline: 5,152 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; northwest monsoon
(December to March), southeast monsoon
(May to October); slight seasonal tempera-
ture variation
Terrain: mostly mountains with coastal
lowlands and rolling foothills
Land use: NEGL% arable land; 1% per-
manent crops; NEGL% meadows and
pastures; 71% forest and woodland; 28%
other
Environment: one of world’s largest
swamps along southwest coast; some active
volcanos; frequent earthquakes
Special notes: none','e5bedc062444005ffaa4e76a732054555570098dd9baf500b1646ca59c83a004','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ec907f1486a22e275ef0bab244d14d8326cc3cd7102f9c5e3f0f51b8086c440',1987,'PY','Paraguay','geography',578,'Total area: 406,750 km?; land area:
397,300 km?
Comparative area: about the size of
California
Land boundaries: 3,444 km total
Boundary disputes: Brazil (Rio Parana
area)
Climate: varies from temperate in east to
semiarid in far west
Terrain: grassy plains and wooded hills
east of Paraguay River; Gran Chaco region
west of Paraguay River mostly low,
marshy plain
Land use: 4% arable land; 1% permanent
crops; 39% meadows and pastures; 51%
forest and woodland; 5% other; includes
NEGL% irrigated
Environment: local flooding in southeast
(early September to June); poorly drained
plains may become boggish (early October
to June)
Special notes: landlocked; buffer between
Argentina and Brazil','ada107d1bdb1a0219286434670f508c7c7293c755ce74f2d0b771c1d02aea0e7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cc5224b30847ef5b196f162fcf3b720cd02b1369e344cdb87a977ff73277f35',1987,'PE','Peru','geography',583,'Total area: 1,285,220 km?; land area:
1,280,000 km?
Comparative area: about five-sixths the
size of Alaska
Land boundaries: 6,131 km total
Coastline: 2,414 km
Maritime claims:
Continental shelf: 200 nm
Territorial sea: 200 nm
Boundary disputes: Ecuador (two areas)
Climate: varies from tropical in east to
dry desert in west
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), east-
ern lowland jungle of Amazon Basin (selva)
Land use: 3% arable land; NEGL% per-
manent crops; 21% meadows and pastures;
55% forest and woodland; 21% other;
includes 1% irrigated
Environment: subject to earthquakes,
tsunamis, landslides, mild volcanic activity;
deforestation; overgrazing; soil erosion;
desertification
Special notes: shares control of Lago
Titicaca, world’s highest navigable lake,
with Bolivia','31ffffac2e38a5c7af606becd5db15b6b9be9248a2dfb177dd9d2c04b8d2d3c4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e1fd9ef409d071d2983f46de1c03212196b5c476fdbd075e4d9ca677030e0f4',1987,'PH','Philippines','geography',588,'Total area: 300,000 km?; land area:
298,170 km?
Comparative area: slightly larger than
Nevada
Coastline: 36,289 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf: to depth of exploita-
tion
Extended economic zone: 200 nm
Territorial sea: irregular polygon up to
285 nm in breadth
Boundary disputes: none; involved in
complex dispute over Spratley Islands with
China, Malaysia, Taiwan, Vietnam, and
possibly Brunei
Climate: tropical marine; northeast mon-
soon (December to May); southwest mon-
soon (July to October)
Terrain: mostly mountains with narrow to
extensive coastal lowlands
Land use: 26% arable land; 11% perma-
nent crops; 4% meadows and pastures;
40% forest and woodland; 19% other;
includes 5% irrigated
Environment: astride typhoon belt, af-
fected by 15 and struck by five to six
cyclonic storms per year; subject to land-
slides, active volcanoes, destructive earth-
quakes; deforestation; soil erosion; water
pollution
Special notes: none
Total area: 47 km?; land area: 47 km?
Comparative area: about one-fourth the
size of Washington, D.C.
Coastline: 51 km
Maritime claims:
Exclusive fishing zone: 200 nm
Climate: tropical, hot, humid, modified by
southeast trade winds; rainy season (No-
vember to March)
Terrain: rugged volcanic formation; rocky
coastline with cliffs
Land use: NA% arable land; NA% perma-
nent crops; NA% meadows and pastures;
NA% forest and woodland; NA% other
Environment: subject to typhoons (espe-
cially November to March)
Special notes: none','a987d35612e4c4ae8943e876eb4a1640fafe26dbd6391c739459c56612cbbcdb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eedd7529a2765933e5fe14fea282963d5411d5506e5636011322992a44086f39',1987,'PL','Poland','geography',593,'Total area: 312,680 km?; land area:
304,510 km?
Comparative area: smaller than New','3c6e1987fb47d24182c74034857ec76cfa863f33b03fc89392120b07cf7c6f52','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0da4c510cb1c130f6ff2491bc5b080bb55d0769e6d2f3d09c4728918cf2e7fad',1987,'PT','Portugal','geography',595,'Total area: 92,080 km?; land area: 91,640
km?
Comparative area: slightly smaller than
Indiana
Land boundary: 1,207 km with Spain
Coastline: 1,793 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; territory of
Macau will become a Special Administra-
tive Region of China in 1999; East Timor
question with Indonesia
Climate: maritime temperate; cool and
rainy in north, warmer and drier in south
Terrain: mountainous north of Tagus
River, rolling plains in south
Land use: 32% arable land; 6% permanent
crops; 6% meadows and pastures; 40%
forest and woodland; 16% other; includes
7% irrigated
Environment: Azores subject to severe
earthquakes
Special notes: Azores and Madeira Islands
occupy strategic locations along western
sea approaches to Strait of Gibraltar','4c1b03d2917d5dc3e5228ba45d1b44b1252a37fda9aa2e57f3c06b4098b8cb61','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41a8fcdddeb34a4993bd7df7dd514214114c5569d4ad8942637aff7062617ddf',1987,'QA','Qatar','geography',600,'Total area: 11,000 km?; land area: 11,000
km?
Comparative area: about the size of
Connecticut
Land boundaries: 56 km total
Coastline: 563 km
Maritime claims:
Continental shelf: not specific
Exclusive fishing zone: as delimited
with neighboring states, or to limit of
shelf, or to median line
Extended economic zone: to median
line
Territorial sea: 8 nm
Boundary disputes: UAE; territorial
dispute with Bahrain over Hawar island
and its ring of islets
Climate: desert; hot, dry; humid and
sultry in summer
Terrain: mostly flat and barren desert
covered with loose sand and gravel
Land use: NEGL% arable land; 0% per-
manent crops; 5% meadows and pastures;
0% forest and woodland; 95% other
Environment: haze, duststorms, sand-
storms common; limited fresh water re-
sources mean increasing dependence on
large-scale desalination facilities
Special notes: strategic location in central
Persian Gulf and close proximity to
region’s important crude ail sources
202
Total area: 2,510 km?; land area: 2,500
km?
Comparative area: about the size of
Rhode Island
Coastline: 201 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical, but moderates with
elevation; cool and dry from May to
November, hot and rainy from November
to April
Terrain: mostly rngged and mountainous;
fertile lowlands along coast
Land use: 20% arable land; 2% permanent
crops; 4% meadows and pastures; 35%
forest and woodland; 39% other; includes
2% irrigated
Environment: periodic devastating
cyclones
Special notes: none','fb35681e247b6471341686a1923bbebdac44f16e202e08e34298281a3de1403d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6954d598104596b61cd3262cd74cb62baddd1895975054a5e5ecbcf24255fde',1987,'RO','Romania','geography',605,'Total area: 237,500 km?; land area:
230,340 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,969 km total
Coastline: 225 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Transylvania
question with Hungary; Bessarabia ques-
tion with USSR
Climate: temperate; cold, cloudy winters
with frequent snow and fog; sunny sum-
mers with frequent showers and thunder-
storms
Terrain: mostly flat to undulating plains;
some hills and mountains
Land use: 43% arable land; 3% permanent
crops; 19% meadows and pastures; 28%
forest and woodland; 7% other; includes
11% irrigated
Environment: frequent earthquakes most
severe in south and southwest; geologic
structure and climate promote landslides
Special notes: controls most easily travers-
able land route between Balkans and
western USSR','6cc553f6206e3fad6421c57e4bb8a840f9ec077436aca7d4dbcb4cef6e0b5784','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('621627e8198e2ea618ad30a6b73d49aff9d538c73708a65962d071644f64d394',1987,'RW','Rwanda','geography',609,'Total area: 26,340 km?; land area: 24,950
km?
Comparative area: about the size of
Maryland
Land boundaries: 877 km total
Climate: temperate; two rainy seasons
(February to April, November to January);
mild in mountains with frost and snow
possible
Terrain: mostly grassy uplands and hills;
mountains in west
Land use: 29% arable land; 11% perma-
nent crops; 18% meadows and pastures;
10% forest and woodland; 32% other;
includes NEGL% irrigated
Environment: deforestation; overgrazing;
soil exhaustion; soil erosion; periodic
droughts
Special notes: landlocked','dca96bca5e733162ca408e9e9b3e7fc80371f48842374ed9bc936b3b33c0c7c6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0f0b98ec5522c8520446e375e78a7c2ec94dc4da1dbff63a21bc47610eae354',1987,'SM','San Marino','geography',614,'Total area: 60 km?; land area: 60 km?
Comparative area: about one-third the
size of Washington, D. C.
Land boundary: 34 km with Italy
Climate: Mediterranean; mild to cool
winters; warm, sunny summers
Terrain: rugged mountains
Land use: 17% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 83% other
Environment: dominated by the Appeni-
nes
Special notes: landlocked; world’s smallest
republic; enclave of Italy','62b5fb2a2a83645b096d5c0bcd37e281ec036f759a996f9054b9433918a69c30','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b131a0d2c0676f610bbd61886cb2855cc4f0b3d84a047f7ead0891e43ca182e1',1987,'SA','Saudi Arabia','geography',621,'Total area: 2,149,690 km?; land area:
2,149,690 km?
Comparative area: about one-third the
size of US
Land boundaries: 4,537 km total
Coastline: 2,510 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: not specific
Territorial sea: 12 nm
Boundary disputes: none; no defined
boundaries with Oman, PDRY, UAE,
YAR; shares Neutral Zone with Iraq
Climate: harsh, dry desert with great
extremes of temperature
Terrain: mostly uninhabited, sandy desert
Land use: 1% arable land; NEGL% per-
manent crops; 39% meadows and pastures;
1% forest and woodland; 59% other; in-
cludes NEGL®% irrigated
Environment: no perennial rivers or
permanent water bodies; developing exten-
sive coastal seawater desalination facilities;
desertification
Special notes: extensive coastlines on
Persian Gulf and Red Sea provide great
leverage on shipping (especially crude oil)
through Persian Gulf and Suez Canal
Climate: desert; extraordinarily hot and
dry
Terrain: mostly upland desert plains;
narrow, flat, sandy coastal plain backed by
flat-topped hills and rugged mountains
Land use: 1% arable land; NEGL% per-
manent crops; 27% meadows and pastures;
7% forest and woodland; 65% other; in-
cludes NEGL% irrigated
Environment: scarcity of natural fresh
water resources; overgrazing; soil erosion;
desertification
Special notes: controls southern
approaches to Bab el Mandeb linking Red
Sea to Gulf of Aden, one of world’s most
active shipping lanes
Yemen, People’s Democratic
Republic of
(South Yemen) (continued)','e8e64f2f96b0efa2a45f2f1efa04283c736de4ef42d6d473f36c6726b5b0db7c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4341237417afb76cb6a43298d0ba8af42ddcf457a8b3149f8581cc0dc93667b6',1987,'SC','Seychelles','geography',625,'Total area: 280 km?; land area: 270 km?
Comparative area: about one and one-half
times the size of Washington, D. C.
Coastline: 491 km
Maritime claims:
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical marine; humid; cooler
season during southeast monsoon (late May
to September); warmer season during
northwest monsoon (March to May)
Terrain: Mahé Group is granitic, narrow
coastal strip, rocky, hilly; others are coral,
flat, elevated reefs, no fresh water, mostly
uninhabited
Land use: 4% arable land; 18% permanent
crops; 0% meadows and pastures; 18%
forest and woodland; 60% other
Environment: lies outside the cyclone belt,
so severe storms are rare; short droughts
possible; 40 granitic and about 50 coralline
islands
Special notes: none','1f35ba537aa59eaa2876f149a5dcc12b7c74c94cd22bde5b1e1784b13eaeebcc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919a7d654792152da3b416dbeaa9664b91086a3c89cbe0231cf3a499c67d0659',1987,'SL','Sierra Leone','geography',630,'Total area: 71,740 km?; land area: 71,620
km?
Comparative area: slightly smaller than
South Carolina
Land boundaries: 933 km total
Coastline: 402 km
Maritime claim:
Territorial sea: 200 nm
Climate: tropical; hot, humid; summer
rainy season (May to December); winter
dry season (December to April)
Terrain: coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Land use: 23% arable land; 2% permanent
crops; 31% meadows and pastures; 29%
forest and woodland; 15% other; includes
NEGL% irrigated
Environment: extensive mangrove swamps
hinder access to sea; deforestation; soil
degradation
Special notes: none','147396c94c13610bd22870a5755cb639c22f99dee5a596c5753c52f5a18bff3e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cdaf4d2455f16d0b377a192cc0f59cbdad0d40d70dfa604d5f49fdbbfb23f1e',1987,'SG','Singapore','geography',635,'Total area: 580 km?; land area: 570 km?
Comparative area: about three times the
size of Washington, D. C.
Coastline; 193 km
Maritime claims:
Exclusive fishing zone: 12 nm
Territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no
pronounced rainy or dry seasons; thunder-
storms occur on 40% of all days (67% of
days in April)
Terrain: lowland; gently undulating cen-
tral plateau contains water catchment area
and nature preserve
Land use: 4% arable land; 7% permanent
crops; 0% meadows and pastures; 5% forest
and woodland; 84% other
Environment: mostly urban and industri-
alized
Special notes: focal point for Southeast
Asian sea routes','c30b5ceda1a959068082c5703318d503d28cf68fb9461842a79081f8e0e49fec','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('780092bffd44600777fedf12c5ea43202ce7e8a86090db556b3c20e11f378b39',1987,'SB','Solomon Islands','geography',640,'Total area: 28,450 km?; land area: 27,540
km?
Comparative area: slightly larger than
Maryland
Coastline: 5,313 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical monsoon; few extremes
of temperature and weather
Terrain: mostly ruggedly mountainous
with some low coral atolls
Land use: 1% arable land; 1% permanent
crops; 1% meadows and pastures; 93%
forest and woodland; 4% other
Environment: subject to typhoons, but
rarely destructive; geologically active
region with frequent earth tremors
Special notes: none','60fe568cde1562565a690f191afbe7413223fc17601baa80ea2e13d82a47b17d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffb60c505bc23021118dc5586675e927b236550addce3529f952a488238e5383',1987,'SO','Somalia','geography',645,'Total area: 637,660 km?; land area:
627,340 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 2,263 km total
Coastline: 3,025 km
Maritime claim:
Territorial sea: 200 nm
Boundary disputes: southern half of
boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute
with Ethiopia over the Ogaden; possible
claims to Djibouti, Ethiopia, and Kenya
based on unification of ethnic Somalis
Climate: hot, dry desert; northeast mon-
soon (December to February), cooler
southwest monsoon (May to October);
irregular rainfall; hot, humid periods
(Tangambili) between monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Land use: 2% arable land, NEGL% per-
manent crops; 46% meadows and pastures;
14% forest and woodland; 38% other;
includes 3% irrigated
Environment: recurring droughts; fre-
quent dust storms over eastern plains in
summer; deforestation; overgrazing; soil
erosion; desertification
Special notes: strategic location on Horn
of Africa along southern approaches to
Bab el Mandeb and route through Red Sea
and Suez Canal
Somalia (continued)','a9e1029d8cb006806250ef2e515735a5fe3c48e6ee5e333053a07bc26f590c77','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eeefc6bf446f230175b16870f206937c6af5b702d9436470c1fc5681a931fb12',1987,'ZA','South Africa','geography',649,'Total area: 1,221,040 km; land area:
1,221,040 km?
Comparative area: about four-fifths the
size of Alaska
Land boundaries: 2,044 km total
Coastline: 2,88] km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; occupies','0078c3fca4a439c1da0f94e4674649c8c0f7eab020f33a41d431dd7b59f2df77','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74291df7d88d099a8285ee244a47c66a0f1b026d69cb04b69b708362693989e0',1987,'ES','Spain','geography',650,'Total area: 504,750 km/?; land area:
499,400 km?
Comparative area: about the size of
Arizona and Utah combined
Land boundaries: 1,899 km total
Coastline: 4,964 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; Gibraltar ques-
tion with UK; controls two presidios or
places of sovereignty (Ceuta, Melilla) on
the coast of Morocco
Climate: temperate; clear, hot summers in
interior, more moderate and cloudy along
coast; cloudy, cold winters in interior,
partly cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills
Land use: 31% arable land; 10% perma-
nent crops; 21% meadows and pastures;
81% forest and woodland; 7% other; in-
cludes 6% irrigated
Environment: deforestation; desertification
Special notes: strategic location along
approaches to Strait of Gibraltar','c64e4f8312e88c8b86cb4fd555ccf0a28a81e90560ff376f1b8dcfb69017c579','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b6d2b01fb5aee90a28c2d396023df1d638c43dd3c10f33513058f5a3b03cfd',1987,'LK','Sri Lanka','geography',653,'Total area: 65,610 km?; land area: 64,740
km?
Comparative area: about one-half the size
of North Carolina
Coastline: 1,340 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; monsoonal; northeast
monsoon (December to March); southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain;
mountains in south-central interior
Land use: 16% arable land; 17% perma-
nent crops; 7% meadows and pastures;
87% forest and woodland; 23% other;
includes 8% irrigated
Environment: occasional cyclones, torna-
dos; deforestation; soil erosion
Special notes: only 29 km from India;
near major Indian Ocean sea lanes','bce8b1529c81a011e35cdc2e1993221f6a0014b8a19c206df4b95bf4bb6b9740','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb00c95ce50a61f2f920744686ae15ebcab2e88206dfd600aa1119227f0a9f4',1987,'SD','Sudan','geography',658,'Total area: 2,505,810 km?; land area:
2,376,000 km?
Comparative area: about one-fourth the
size of US
Land boundaries: 7,805 km total
Coastline: 853 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; international
boundary and Administrative Boundary
with Kenya; international boundary and
Administrative Boundary with Egypt
Climate: tropical in south; arid desert in
north; rainy season (April to October)
Terrain: generally flat, featureless plain;
mountains in east and west
Land use: 5% arable land; NEGL% per-
manent crops; 24% meadows and pastures;
20% forest and woodland; 51% other;
includes 1% irrigated
Environment: dominated by Nile River
and tributaries; dust storms; desertification
Special notes: largest country in Africa','ecf9bf5aa1eff2e187990ad7bff8dfb6d1a5fc689cfab0c4f2992ea27af43045','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801a76cf540f7e4d83e9d86e7dbd3b93aab9f2c0ed9bfe39b2209d9364077780',1987,'SR','Suriname','geography',663,'Total area: 163,270 km?; land area:
161,470 km?
Comparative area: about the size of','b5924b0cba3a23a452c060ee74c622e765b15b19b59ac2ad48fc88f8711f495b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8738ae6ee59ab771b27500bb87e2a2782e6f74b7fdcd7560d8fe6cb0d4b5d58',1987,'GE','Georgia','geography',664,'Land boundaries: 1,561] km total
Coastline: 386 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: claims area in French
Guiana between Litani Rivier and Riviére
Marouini (both headwaters of the Lawa),
claims area in Guyana between New
(Upper Courantyne) and Courantyne/Ku-
tari rivers (all headwaters of the Conran-
tyne)
Climate: tropical; moderated by trade
winds
Terrain: mostly rolling hills; narrow
coastal plain with swamps
Land use: NEGL% arable land; NEGL%
permanent crops, NEGL% meadows and
pastures; 97% forest and woodland; 3%
other; includes NEGL% irrigated
Environment: mostly tropical rain forest
Special notes: none
Total area: 17,360 km?; land area: 17,200
km?
Comparative area: about the size of New','0c28220b8c169777a58ddc9c47cbfe737aaa81679491797ed1d445c6d46881e7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b9914ef734740bdd5af0ef44c759fd6128ee423c68b0ef7ac4a581376a663c5',1987,'SE','Sweden','geography',670,'Total area: 449,960 km?; land area:
411,620 km?
Comparative area: about the size of
California
Land boundaries: 2,196 km total
Coastline: 3,218 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with USSR
Climate: temperate in south with cold,
cloudy winters and cool partly cloudy
summers; subarctic in north
Terrain: mostly flat or gently rolling low-
lands; mountains in west
Land use: 7% arable land; 0% permanent
crops; 2% meadows and pastures; 64%
forest and woodland; 27% other; includes
NEGL% irrigated
Environment: water pollution; acid rain
Special notes: strategic location along
Danish Straits linking Baltic and North
Seas','dfb0b43517b35b0079345ea3a9b1d36c4223947de082fa21f2a5f013085fa183','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82286713ad99aafd80ed60388bb3d7561adc389fe0508b68787353ce0102d607',1987,'CH','Switzerland','geography',675,'Total area: 41,290 km?; land area: 39,770
km?
Comparative area: about twice the size of
New Jersey
Land boundaries: 1,884 km total
Climate: temperate, but varies with alti-
tude; cold, cloudy, rainy/snowy winters;
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mostly mountains (Alps in south,
Jura in northwest) with central plateau of
rolling hills and plains
Land use: 10% arable land; 1% permanent
crops; 40% meadows and pastures; 26%
forest and woodland; 23% other; includes
1% irrigated
Environment: dominated by Alps
Special notes: landlocked; crossroads of
northern and southern Europe
Total area: 185,180 km?; land area:
184,050 km? (including 1,295 km? of
Israeli-occupied territory)
Comparative area: about the size of North
Dakota
Land boundaries: 2,196 km total (excludes
2,156 km occupied area)
Coastline: 193 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 35 nm
Boundary disputes: separated from Israel
by 1949 Armistice Line; Golan Heights is
Israeli occupied; Hatay question with
Turkey; periodic disputes with Iraq over
Euphrates water rights; potential dispute
over water development plans by Turkey
for the Tigris and Euphrates rivers
Climate: mostly dry desert with hot, dry,
sunny summers (June to August) and mild,
rainy winters (December to February)
along coast
Terrain: primarily semiarid and desert
plain; narrow coastal plain; mountains in
west
Land use: 28% arable land; 3% permanent
crops; 46 meadows and pastures; 3% forest
and woodland; 20% other; includes 3%
irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
237
Special notes: none
Total area: 945,090 km?; land area:
886,040 km?
Comparative area: about twice the size of
California
Land boundaries: 3,883 km total
Coastline: 1,424 km
Maritime claim:
Territorial sea: 50 nm
Boundary disputes: none; maritime dis-
pute with Malawi
Climate: varies from tropical along coast
to temperate in highlands
Terrain: plains along coast; central pla-
teau; highlands in north, south
Land use: 5% arable land; 1% permanent
crops; 40% meadows and pastures; 47%
forest and woodland; 7% other; includes
NEGL% irrigated
Environment: lack of water and tsetse fly
limit agriculture; recent droughts affecting
marginal agriculture; Kilimanjaro is high-
est point in Africa
Special notes: none','2f5f0db4e9a2369b4347db5524e0dff1cdf70c892ac7a79a753b6f934bbf6112','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9380c4e529a1ca83a5bfd5b86d7a98f53f739df667a17527e63fc656e5c4ca70',1987,'TG','Togo','geography',680,'Total area: 56,790 km?: land area: 54,390
km?
Comparative area: about the size of West
Virginia
Land boundaries: 1,646 km total
Coastline: 56 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 30 nm
Climate: tropical; hot, humid in south;
semiarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low coastal
plain with extensive lagoons and marshes
Land use: 25% arable land; 1% permanent
crops; 4% meadows and pastures; 28%
forest and woodland; 42% other; includes
NEGL.% irrigated
Environment: hot, dry harmattan wind
can reduce visibility in north during win-
ter; recent droughts affecting agriculture;
deforestation
Special notes: none','25df036c1c5dee46e527505a07a05e2b0cede3f6bd5b0a614ea0a867c58e9cf2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c79055a700a48770790b522ee2d7f86c9ad9aa7eeb397022d55e2ae8411a117',1987,'TK','Tokelau','geography',684,'Total area: 10 km2; Jand area: 10 km?
Comparative area: about one-eighteenth
the size of Washington, D. C.
Coastline: 101 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by trade
winds (April to November)
Terrain: coral atolls enclosing large lagoons
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: lies in Pacific typhoon belt
Special notes: none','e046b177701584e289e9fd008c14335992e48f0e1fca4bfe15a30db35558ead6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b45b13f2c016f678fb1c036f3d58fb46e085cf1e61102e17a2acfcb2a328e95b',1987,'TO','Tonga','geography',687,'Total area: 700 km?; land area: 670 km?
Comparative area: about four times the
size of Washington, D. C.
Coastline: 419 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; modified by trade
winds; warm season (December to May),
cool season (May to December)
Terrain: most have limestone base formed
from uplifted coral formation; others have
limestone overlaying volcanic base
Land use: 25% arable land; 55% perma-
nent crops; 6% meadows and pastures;
12% forest and woodland; 2% other
Environment: archipelago of 170 islands
(86 inhabited); subject to cyclones (October
to April); deforestation
Special notes: none','7026bc61a439ebce952937025f32d0b759426d8c2b01fc8ff859d71d93f1ee3d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e88a118fd397c6951ec6dd1b55ba2ad1d09834796d77f423d1105ed6f1cc48f',1987,'TT','Trinidad and Tobago','geography',692,'Total area: 5,130 km?; land area: 5,130
km?
Comparative area: about the size of
Delaware
Coastline: 362 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Land use: 14% arable land; 17% perma-
nent crops; 2% meadows and pastures;
44% forest and woodland; 23% other;
includes 4% irrigated
Environment: outside usual path of hurri-
canes and other tropical storms
Special notes: southernmost of Southern
Antilles; only 11 km from Venezuela','b0d09b7af87700e02518e4aaf9373ad5906948f414d31bcd1ac1226d1c55c189','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df59c1898638b8db78fc12362ca209a621682327444f6cea31ec6d0c1b769fb',1987,'TN','Tunisia','geography',697,'Total area: 163,610 km?; land area:
155,360 km?
Comparative area: about the size of
Missouri
Land boundaries: 1,408 km total
Coastline: 1,148 km
Maritime claim:
Territorial sea: 12 nm
Boundary disputes: none; maritime dis-
pute with Libya
Climate: temperate in north with mild,
rainy winters and hot, dry summers; hot,
dry desert in south year round
Terrain: mountains in north; hot, dry
central plain; semiarid south merges into
Sahara Desert
Land use: 20% arable land; 10% perma-
nent crops; 19% meadows and pastures;
4% forest and woodland; 47% other; in-
cludes 1% irrigated
Environment: deforestation; overgrazing;
soil erosion; desertification
Special notes: strategic location in central
Mediterranean; only 144 km from Italy
across the Strait of Sicily; borders Libya on
east
Total area: 780,580 km?; land area:
770,760 km?
Comparative area: about twice the size of
California
Land boundaries: 2,574 km total
Coastline: 7,200 km
Maritime claims:
Extended economic zone: 200 nm in
Black Sea only
Territorial sea: 6 nm (12 nm in Black
Sea and Mediterranean Sea)
Boundary disputes: none; complex mari-
time and air (but not territorial) disputes
with Greece in Aegean Sea; Cyprus ques-
tion with Greece; Hatay question with
Syria; potential dispute with downstream
riparians (Syria and Iraq) over water
development plans for the Tigris and
Euphrates rivers
Climate: temperate; hot, dry summers
with mild, wet winters; harsher in interior
Terrain: mostly mountains; narrow coastal
plain; central plateau (Anatolia)
Land use: 30% arable land; 4% permanent
crops; 12% meadows and pastures; 26%
forest and woodland; 28% other; includes
3% irrigated
Environment: subject to severe earth-
quakes, especially along major river valleys
in west; air pollution; desertification
Special notes: strategic location controlling
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean
247
Seas; Turkey and Norway only NATO
members having a boundary with USSR','892ff507077b0a5b33665323f3f9a41010e0e5289b5eb56d34942ab96c99dc1d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e6cbab5cc50eff5632d6050a09feb66fd7889a51f505b71bf5c93b253ce942a',1987,'JP','Japan','geography',701,'Total area: 430 km?; land area: 430 km?
Comparative area: about two and one-
half times the size of Washington, D. C.
Coastline: about 300 km
Maritime claims:
Exclusive fishing zone: 200 nm
Territorial sea: 8 nm
Climate: tropical; marine; moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
Land use: 2% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 98% other
Environment: 30 islands (8 inhabited);
subject to frequent hurricanes
Special notes: none','2b23dc6a1f7fc04b8914b31dfef7dde24d6b5e932e68b393347d513391bc3d6b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12bf65eb0bba9da9128ca44f6a52799571f8baa082c562d3acadac3d77e070de',1987,'TV','Tuvalu','geography',705,'Total area: 26 km?; land area: 26 km?
Comparative area: about one-seventh the
size of Washington, D. C.
Coastline: 24 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by easterly
trade winds (March to November); west-
erly gales and heavy rain (November to
March)
Terrain: very low lying and narrow coral
atolls
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: severe tropical storms are
rare
Special notes: none','93df40de7063b42422fd5aa76eaa3374018dbaef27aa685fb4b01873592707d7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c194e968da00c0a5e46650625f964e60a5e0fd9a422441426bbd5b40591a0f72',1987,'UG','Uganda','geography',710,'Total area: 236,040 km?; land area:
199,710 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,680 km total
Climate: tropical; generally rainy with two
dry seasons (December to February, June
to August); semiarid in northeast
Terrain: mostly plateau with rim of moun-
tains
Land use: 23% arable land; 9% permanent
crops; 25% meadows and pastures; 30%
forest and woodland; 13% other; includes
NEGL% irrigated
Environment: straddles Equator; defores-
tation; overgrazing; soil erosion
Special notes: landlocked','666709b99ffe84c964ad3d568dd9b7cb539229ee63e1c65a9bd1d9b88402392b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ab0bf2dd7b2d965d20ac8fac0dbe8252e188cc4cb5f905d3677cd5b13ace209',1987,'AE','United Arab Emirates','geography',715,'Total area: 83,600 km?; land area: 83,600
km?
Comparative area: about the size of
Maine
Land boundaries: 1,094 km total
Coastline: 1,448 km
Maritime claims:
Continental shelf: defined by bilateral
boundaries or equidistant line
Extended economic zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: Qatar; no defined
boundary with Saudi Arabia; no defined
boundary with most of Oman, Administra-
tive Line in far north; claims three islands
occupied by Iran in Strait of Hormuz
Climate: hot, dry desert; cooler in eastern
mountains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert
wasteland; mountains in east
Land use: NEGL% arable land; NEGL%
permanent crops; 2% meadows and pas-
tures; NEGL% forest and woodland; 98%
other; includes NEGL% irrigated
Environment: frequent dust and sand
storms; lack of natural fresh water re-
sources being overcome by desalination
plants; desertification
Special notes: strategic location along
southern approaches to Strait of Hormuz, a
vital transit point for world crude oil
252','09b84f03d0b20f88f6748f683a7bad2ef97d198f16680d83f82ea80a2fb1a15d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e83553e614f13e8b3496c61f2d5a807d2b30542850b8c3db151dd3317736c64',1987,'GB','United Kingdom','geography',720,'Total area: 244,820 km?; land area:
241,590 km?
Comparative area: about the size of
Oregon
Land boundary: 360 km with Ireland
Coastline: 12,429 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Exclusive fishing zone: 200 nm
Territorial sea: 3 nm
Boundary disputes: none; maritime dis-
pute with lreland; Northern Ireland ques-
tion with Ireland; Gibraltar question with
Spain; Argentina claims Falkland Islands
(Islas Malvinas); Mauritius claims island of
Diego Garcia in British Indian Ocean
Territory; colony of Hong Kong will be-
come a Special Administrative Region of
China in 1997; Rockall continental shelf
dispute involving Denmark, Iceland,
Ireland; territorial claim in Antarctica
(British Antarctic Territory)
Climate: temperate; moderated by pre-
vailing southwest winds over Gulf Stream;
more than one-half of days are overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east
and southeast
Land use: 29% arable land; NEGL%
permanent crops; 48% meadows and
pastures; 9% forest and woodland; 14%
other; includes 1% irrigated
United Kingdom (continued)
Environment: pollution control measures
improving air, water quality; because of
heavily indented coastline, no location is
more than 125 km from tidal waters
Special notes: lies near vital North Atlan-
tic sea lanes; only 35 km from France','4e8ce91532e509ce325bb4753ff1bbe3681ac531feeb72e71829847d260893fe','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e729775507a5fe09782f35a169bd2267051299ec5ccb22c916d2b13c061fb4',1987,'US','United States','geography',724,'Total area: 9,372,610 km?; land area:
9,166,600 km?
Comparative area: about four-tenths the
size of USSR; about one-third the size of
Africa; about one-half the size of South
America (or slightly larger than Brazil);
slightly smaller than China; about two and
one-half times the size of Western Europe
Land boundaries: 12,000 km total
Coastline: 19,924 km
Maritime claims:
Contiguous zone: 12 nm
Continental shelf: 200 meters
Extended economic zone: 200 nm
Territorial sea: 8 nm
Boundary disputes: none; maritime dis-
pute with Canada; Guantanamo (US Naval
Base) leased from Cuba; Haiti claims
Navassa Island (US possession), has made
no territorial claim in Antarctica (but has
reserved the right to do so) and does not
recognize the claims of any other nation
Climate: mostly temperate, but varies
from tropical (Hawaii) to arctic (Alaska);
arid to semiarid with occasional warm, dry
chinook wind in west
Terrain: vast central plain, mountains in
west, hills and low mountains in east;
rugged mountains and broad river valleys
255
United States (continued)
in Alaska; rugged, volcanic topography in
Hawaii
Land use: 20% arable land; NEGL%
permanent crops; 26% meadows and
pastures; 29% forest and woodland; 25%
other; includes 2% irrigated
Environment: pollution control measures
improving air and water quality; acid rain;
agricultural fertilizer and pesticide polfu-
tion; management of sparse natural water
resources in west; desertification; tsunamis,
volcanoes, and earthquake activity around
Pacific Basin
Special notes: world’s fourth largest coun-
try (after USSR, Canada, and China)','4d0a3db73ece35faae2ff270e9184fad7f7c2eb47001efe5b0a9578056eeedad','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f3490383bed5a0085d82fd263eb3a89d1d53d1334ccd45414bae3bfa04a7814',1987,'UY','Uruguay','geography',729,'Total area: 176,220 km?; land area:
178,620 km?
Comparative area: about the size of the
State of Washington
Land boundaries: 1,352 km total
Coastline: 660 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 200 nm (overflight and
navigation permitted beyond 12 nm)
Boundary disputes: Argentina, Brazil
Climate: warm temperate; freezing tem-
peratures almost unknown
Terrain: mostly rolling plains and low
hills; fertile coastal lowland
Land use: 8% arable land; NEGL% per-
manent crops; 78% meadows and pastures;
4% forest and woodland; 10% other; in-
cludes 1% irrigated
Environment: subject to seasonally high
winds, droughts, floods
Special notes: none','c887efdd406aa68c11df78e330301bdf56bd71833f1079727de64ccdeee8aff2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf5d68325aea89152e9dc9f4f250711e1d4af8eaf6a189cd9056a8da56d7fd13',1987,'VU','Vanuatu','geography',734,'Total area: 14,760 km?; land area: 14,760
km?
Comparative area: about the size of
Connecticut
Coastline: 2,528 km
Maritime claims: (measured from claimed
archipelagic baselines)
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; moderated by southeast
trade winds
Terrain: mostly mountains of volcanic
origin; narrow coastal plains
Land use: 1% arable land; 5% permanent
crops; 2% meadows and pastures; 1% forest
and woodland; 91% other
Environment: subject to cyclones (January
to April); volcanism causes minor earth-
quakes; over 80 islands
Special notes: none
Total area: 0.438 km?; land area: 0.438
km?
Comparative area: about one-four hun-
dredth the size of Washington, D. C.
Land boundary: 3 km with Italy
Climate: temperate; mild, rainy winters
(September to mid-May) with hot, dry
summers (May to September)
Terrain: low hill
Land use: 0% arable land; 0% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 100% other
Environment: urban
Special notes: landlocked; enclave of
Rome, Italy; world’s smallest state
Total area: 912,050 km?; land area:
882,050 km?
Comparative area: about twice the size of
California
Land boundaries: 4,18] km total
Coastline: 2,800 km
Maritime claims:
Contiguous zone: 15 nm
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: claims Essequibo area
of Guyana; maritime dispute with Colom-
bia
Climate: tropical; hot, humid; more mod-
erate in highlands
Terrain: Andes mountains and Maracaibo
lowlands in northwest; central plains
(Ilanos); Guyana highlands in southeast
Land use: 3% arable land; 1% permanent
crops; 20% meadows and pastures; 39%
forest and woodland; 37% other; includes
NEGL% irrigated
Environment: Angel Falls is world’s high-
est waterfall
Special notes: on major sea and air routes
linking North and South America','190a2d0a73d443100b9777a1e88637b541d2e81bc7452c5904788a54951816a3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26df5d7623c71f0e57b5040f3dbcdeb70960ce7a3f17f03c94d0e03a6044975a',1987,'WF','Wallis and Futuna','geography',739,'Total area: 200 km?; land area: 200 km?
Comparative area: slightly larger than
Washington, D.C.
Coastline: 129 km
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; hot, rainy season (No-
vember to April); cool, dry season (May to
October)
Terrain: volcanic origin; low hills
Land use: 5% arable land; 20% permanent
crops; 0% meadows and pastures; 0% forest
and woodland; 75% other
Environment: both island groups have
fringing reefs
Special notes: none','63a8c20c97ae97688caa16cf183950922b287d1d76d426df3a4497cd70b70d14','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2937b8ac62c3983b20ccf79c4f8281aac11951184bb47bcca8937e3fdaad4252',1987,'EH','Western Sahara','geography',744,'Total area: 266,000 km?: land area:
266,000 km?
Comparative area: about the size of Utah
Land boundaries: 2,086 km total
Coastline: 1,110 km
Maritime claims: contingent upon resolu-
tion of sovereignty issue
Boundary disputes: none; claimed and
administered by Morocco, but sovereignty
is unresolved
Climate: hot, dry desert; rain is rare; cold
offshore currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Land use: NEGL% arable land; 0% per-
manent crops; 19% meadows and pastures;
0% forest and woodland; 81% other
Environment: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring; widespread harmattan haze exists
60% of time, often severely restricting
visibility; sparse water and arable land
Special notes: none
Total area: 2,860 km?; land area: 2,850
km?
Comparative area: about the size of
Rhode Island
Coastline: 403 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Climate: tropical; rainy season (October to
March), dry season May to October)
Terrain: narrow coastal plain with volca-
nic, rocky, rugged mountains in interior
Land use: 19% arable land; 24% perma-
nent crops; NEGL% meadows and pas-
tures; 47% forest and woodland; 10% other
Environment: subject to occasional ty-
phoons; active volcanism
Special] notes: none
Total area: 195,000 km?; land area:
195,000 km?
Comparative area: slightly smaller than
South Dakota
Land boundaries: 1,528 km total
Coastline: 523 km
Maritime claims:
Contiguous zone: 18 nm
Continental shelf: 200 meters
Territorial sea: 12 nm
Boundary disputes: international boun-
dary/indefinite boundary/no defined
boundary with PDRY; international boun-
dary/no defined boundary with Saudi
Arabia
Climate: desert; hot and humid along
coast; temperate in central mountains;
harsh desert in east
Terrain: narrow coastal plain (Tihama),
western mountains; flat dissected plain in
center sloping into desert interior of Ara-
bian Peninsula
Land use: 14% arable land; NEGL%
permanent crops; 36% meadows and
pastures; 8% forest and woodland; 42%
other; includes 1% irrigated
Environment: subject to sand and dust
storms in summer; overgrazing; soil ero-
sion; desertification
Special notes: controls northern
approaches to Bab el Mandeb linking Red
Sea and Gulf of Aden, one of world’s most
active shipping lanes
266
Total area: 332,970 km; land area:
332,970 km?
Comparative area: about the size of
Nevada
Land boundaries: 1,802 km total
Coastline: 1,383 km
Maritime claims:
Contiguous zone: 24 nm
Continental shelf: edge of continental
margin or 200 nm
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: international boun-
dary/indefinite boundary/no defined
boundary with YAR; Administrative Line
with Oman; no defined boundary with','de0d6fdf175e6e57bae412c7c39004716638571fe20d198c7e4581dd0b8b82ec','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a16e2d969f4e49dabb3cb74cfac8de94a97754a752f4e56b37e30d0ff971818f',1987,'YE','Yemen','geography',749,'Total area: 255,800 km?; land area:
255,400 km?
Comparative area: about the size of
Wyoming
Land boundaries: 3,001 km total
Coastline: 3,935 km (including 2,414 km
offshore islands)
Maritime claims:
Continental shelf: 200 meters or to
depth of exploitation
Territorial sea: 12 nm
Boundary disputes: none; Kosovo question
with Albania; Macedonia question with
Bulgaria and Greece; Trieste question with','b2d5253fb0b4eb8967c007902a232d2fe000e901a645586f2816be6b60d5c1b2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36bad9ab99ef1e51473cda7b1c9cf4833f7c8eeae673d39f19c8d900e30f22a',1987,'ZM','Zambia','geography',751,'Total area: 752,610 km?; land area:
740,720 km?
Comparative area: about the size of Texas
Land boundaries: 6,003 km total
Boundary disputes: short section with
Zaire is indefinite
Climate: tropical; modified by altitude;
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Land use: 7% arable land; NEGL% per-
manent crops; 47% meadows and pastures;
27% forest and woodland; 19% other;
includes NEGL% irrigated
Environment: deforestation; soi] erosion;
desertification
Special notes: landlocked','ea700951c3280d0a8fd3615e8c27db9a5b4e981ba3f6d16b5677429f131a017d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae01612b65c1100d7b16a5ca285845c7795638ba4a4cce0a102ba36add5676fa',1987,'ZW','Zimbabwe','geography',756,'Total area: 390,580 km?; land area:
386,670 km?
Comparative area: slightly smaller than
California
Land boundaries: 3,017 km total
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains in
east
Land use: 7% arable land; NEGL% per-
manent crops; 12% meadows and pastures;
62% forest and woodland; 19% other;
includes NEGL% irrigated
Environment: recurring droughts; floods
and severe storms are rare; deforestation;
soil erosion; air and water pollution; deser-
tification
Special notes: landlocked
Total area: 35,980 km?; land area: 35,980
km?
Comparative area: about the size of
Connecticut and New Hampshire com-
bined
Coastline: 1,448 km
Maritime claims:
Extended economic zone: 200 nm
Territorial sea: 12 nm
Boundary disputes: none; involved in
complex dispute over Spratly Islands with
China, Malaysia, Philippines, Vietnam,
and possibly Brunei
Climate: tropical; marine; rainy season
during southwest monsoon (June to Sep-
tember); cloudiness is persistent and exten-
sive all year
Terrain: mostly mountains; flat to gently
rolling plains in west
Land use: 24% arable land; 1% permanent
crops; 5% meadows and pastures; 55%
forest and woodland; 15% other; 14%
irrigated
Environment: subject to earthquakes and
typhoons
Special notes: none
Total area: West Bank—5,860 km? (in-
cludes West Bank, East Jerusalem, Latrun
Salient, Jerusalem No Man’s Land, and
northwest quarter of the Dead Sea, but
excludes Mt. Scopus) and Gaza Strip—
380km?; land area: West Bank—5,640 km?
and Gaza Strip—380 km?
Comparative area: West Bank—slightly
larger than Delaware; Gaza Strip— about
twice the size of Washington, D. C.
Land boundaries: West Bank—480 km
total; Gaza Strip—72 km total
Coastline: West Bank—none (landlocked),
Gaza Strip—40 km
Maritime claims: West Bank—none
(landlocked); Gaza Strip—to be deter-
mined
Boundary disputes: West Bank—Israeli
occupied with status to be determined;
Gaza Strip—lIsraeli occupied with status to
be determined
Climate: West Bank—temperate, tempera-
ture and precipitation vary with altitude,
warm to hot summers, cool to mild win-
ters; Gaza Strip— temperate, mild winters,
dry and warm to hot summers
Terrain: West Bank—mostly rugged
dissected upland, some vegetation in west,
but barren in east; Gaza Strip—flat to
rolling, sand and dune covered coastal
plain
Land use: West Bank—27% arable land,
0% permanent crops, 32% meadows and
pastures, 1% forest and woodland, 40%
other; Gaza Strip—13% arable land, 32%
permanent crops, 0% meadows and pas-
tures, 0% forest and woodland, 55% other
Environment: West Bank—highlands are
main recharge area for Israel’s coastal
aquifers; Gaza Strip—desertification
Special notes: West Bank—landlocked,
Israeli settlements; Gaza Strip— Israeli
settlements','30b8cca7402e820427ba8d4ccf81d50b9dd2004de144cf6bbfa77bca57106339','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

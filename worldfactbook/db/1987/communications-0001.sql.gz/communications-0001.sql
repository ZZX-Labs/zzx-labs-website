SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d4a3256affb81ca406d00347643f57a464b51f77718ce022735051869be1bc7',1987,'AF','Afghanistan','communications',8,'Railroads: 9.6 km (single track) 1.524-
meter gauge, spur of Soviet line from
Kushka (USSR) to Towraghondf and from
Termez (USSR) to Kheyrabad tranship-
ment point (15 km) on south bank of Amu
Darya; government owned
Highways: 21,000 km total (1984); 2,800
km hard surface, 1,650 km bituminous
treated gravel and improved earth, 16,550
unimproved earth and tracks
Inland waterways: total navigability 1,200
km; chiefly Amu Darya, which handles
steamers up to about 500 metric tons
Pipelines: natura] gas, 180 km
Ports: 3 minor river ports (Shir Khan is
largest)
Civil air: 5 major transport aircraft
Airfields: 42 total, 34 usable; 12 with
permanent-surface runways; 9 with run-
ways 2,440-3,659 m, 15 with runways
1,220-2,489 m
Telecommunications: limited telephone,
telegraph, and radiobroadcast services;
television introduced in 1980; 31,200
telephones (0.2 per 100 popl.); 5 AM and
no FM stations, 1 TV station, 1 earth
satellite station
Defense Forces
Branches: Armed Forces, Air and Defense
Forces, border guard forces, Defense of
the Revolution Force, National Police
Force—operational battalions, Ministry for
State Security (WAD), People’s Militia
Military manpower: males 15-49, about
8,483,000; 1,868,000 fit for military ser-
vice; about 144,000 reach military age (22)
annually
Military budget: for fiscal year ending 20
March 1984, $210 million, about 63% of
central government budget','cdc2fb51c13843c3d5863633e217065020abbe2383cac232d1645d8a1919f18d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da729a58770af05d43116735167fc2228a2ecbd42442726e8db98b6576ecfea7',1987,'AL','Albania','communications',9,'75 km
lonian See
See regional map V
Railroads: 437 km—425 1.435-meter
standard gauge, single track, government
owned; 12 km narrow gauge, single track
(1986); line connecting Titograd (Yugosla-
via) and Shkodér (Albania) completed
August 1986
Highways: 4,989 km total; 1,287 km
paved, 1,609 km crushed stone and/or
gravel, 2,093 km improved or unimproved
earth (1975)
Inland waterways: 43 km plus Albanian
sections of Lake Scutari, Lake Ohrid, and
Lake Prespa (1979)
Pipelines: crude oil, 117 km; refined
products, 65 km; natural gas, 64 km
Freight carried: total freight—85.75
million metric tons; 1.946 billion metric
tons/km; highways 1.298 billion metric
tons/km; railways 618.8 million metric
tons/km; internal waterways 29.2 million
metric tons/km (1983)
Ports: | major (Durrés), 3 minor
Civil air: none
Airfields: 10 total; 6 with runways 2,500
m or longer
Telecommunications: 14 AM, 4 FM, 9 TV
stations; 50,000 TV sets; 210,000 receiver
sets
Defense Forces
Branches: Albanian People’s Army, Fron-
tier Troops, Interior Troops, Albanian
Coastal Defense Command, Air and Air
Defense Force
Military manpower: males 15-49, 830,000;
687,000 fit for military service; 34,000
reach military age (19) annually
Military budget: announced for fiscal year
ending 81 December 1986, 1 billion leks;
10.6% of total budget','d8ca0388dc24dd5e151f2988afc2750e97021d9ccf237de2f9d801c072acd554','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('672e22d29229c70f688e22ef2f6cb02c51294cfa1ae541c472af04dd3f08e9fd',1987,'DZ','Algeria','communications',14,'500 km Mediterranean See
ALGIERS ‘Conatentine
arn
See regional map Vil
Railroads: 4,146 km total; 2,632 km stan-
dard gauge (1.435 m), 1,258 km 1.055-
meter gauge, 256 km 1.000-meter gauge;
300 km electrified; 345 km double track
Highways: 80,000 km total; 60,000 km
concrete or bituminous, 20,000 km gravel,
crushed stone, unimproved earth
Pipelines: crude oil, 6,612 km; refined
products, 298 km; natural gas, 2,948 km
Ports: 6 major, 6 secondary, 11 minor
Civil air: 40 major transport aircraft
Airfields: 154 total, 146 usable; 55 with
permanent-surface runways; 28 with
runways 2,440-3,659 m; 74 with runways
1,220-2,439 m
Telecommunications: 17 AM, 0 FM, and
1 TV stations; 1,445,000 TV sets; 3,500,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: Armed Forces, Army, Navy,
Air Force, National Gendarmerie
Military manpower: males 15-49,
5,257,000; 3,249,000 fit for military ser-
vice; 269,000 reach military age (19)
annually
Andorras','9ecbb15d572947c25b7c812944c09b99f30c265bb7a9b42411df773aaa812d94','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaaa58a5be5d42451ff632483071180183924ab264948344ea50fa7353a51e17',1987,'ES','Spain','communications',24,'Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international land-
line circuits to Spain and France; 1 AM
station; about 12,800 telephones (43.5 per
100 popl.) (1982)
Defense Forces
Defense is the responsibility of Spain and
300 km
Bay of Biscay
Balearic
Sea cy
Q
© Balearic
* Islands
Mediterranean
North Sea
Atlantic
Ocean = Strait of
Gibrattar Canary Islands. Ceuta,
and Malilla ara not shown
See regional map V and VII
Railroads: 15,430 km total; Spanish Na-
tional Railways (RENFE) operates 12,691
km 1.668-meter gange, 6,050 km electri-
fied, and 2,295 km double track; FEVE
(government-owned narrow-gauge rail-
ways) operates 1,821 km of predominantly
1.000-meter gauge and 44] km electrified;
privately owned railways operate 918 km
of predominantly 1.000-meter gauge, 512
km electrified, and 56 km double track
Highways: 150,896 km total; 82,070 km
national 2,433 km limited-access divided
highway, 63,042 km bituminous treated,
17,038 km intermediate bituminous, con-
crete, or stone block; the remaining 68,326
km are provincial or local roads (bitumi-
nous treated, intermediate bituminous, or
stone block)
Inland waterways: 1,045 km; of minor
importance as transport arteries and con-
tribute little to economy
Pipelines: 265 km crude oil; 1,862 km
refined products; 1,475 km natural gas
Ports: 23 major, 175 minor
Civil air: 142 major transport aircraft
Airfields: 121 total, 117 usable; 61 with
permanent-surface runways; 4 with run-
ways over 3,659 m, 21 with runways
2,440-3,659 m, 32 with runways
1,220-2,439 m
Spain (continued)
Telecommunications: generally adequate,
modern facilities; 14.4 million telephones
(34.5 per 100 popl.); 193 AM, 406 FM,
1,500 TV stations; 22 coaxial submarine
cables; 2 satellite stations with total of 6
antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
9,597,000; 7,810,000 fit for military ser-
vice; 337,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1986, $5.9 billion; 12.3% of the
central government budget','c38e1d440cdeff8c37bd240b336d2891ab8265ecd35a27e550172705fd046b11','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90e6839dad1013ee4c1b3d8abfd45c5c93ae09519f6011a032478b974b291b2a',1987,'AO','Angola','communications',25,'<¢ 300 km
Cabinda
South
Atlantic
Ocean
See regional map VII
Railroads: 3,189 km total; 2,879 km 1.067
meter gauge, 310 km 0.600-meter gauge
Highways: 73,828 km total; 8,577 km
bituminous-surface treatment, 29,350 km
crushed stone, gravel, or improved earth,
remainder unimproved earth
Inland waterways: 1,295 km navigable
Ports: 8 major (Luanda, Lobito, Namibe),
5 minor
Pipelines: crude oil, 179 km
Civil air: 30 major transport aircraft
Airfields: 349 total, 252 usable; 25 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 12 with runways
2,440-3,659 m, 7] with runways
1,220-2,489 m
Telecommunications: fair system of wire,
radio-relay, and troposcatter routes; high
frequency used extensively for military /
Cuban links; 2 Atlantic Ocean satellite
stations; 40,300 telephones (0.5 per 100
popl.); 16 AM, 13 FM, 2 TV stations
Defense Forces
Branches: Army, Navy, Air Force/Air
Defense; paramilitary forces—People’s
Defense Organization and Territorial
Troops, Frontier Guard, Popular Vigilance
Brigades
Military manpower: males 15-49,
1,933,000; 972,000 fit for military service;
85,000 reach military age (18) annually
Military budget: for fiscal year ending 31
December 1983, $587 million; 25% of
central government budget','382596314ebae0a08226164203ff1ad9554dc8ed1072eadc44d582903caeba7b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dccb772b49c2f3b2fc2aacba3f1411fa022dbe3383cfd24fb9885d70770a67a',1987,'AI','Anguilla','communications',30,'° ‘ombrero
Caribbean
Sea
Scrub island
?
THE VALLEY;
Blowing Point
Prickly Pear Ca YSy
See regional map II
Railroads: none
Highways: about 60 km surfaced
Inland waterways: none
Ports: 1 major (Road Bay), 1 minor (Blow-
ing Point)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with
permanent-surface runways of 1,100 m
(Wallblake Airport)
Telecommunications: modern internal
telephone system; 890 telephones (13.6 per
100 popl.); 1 FM and 8 AM stations; radio-
relay link to St. Martin’s Island
Defense Forces
Defense is the responsibility of United
Kingdom
Branches: Police','a6c85ce6768750c8d6d8048d62682f1865da3f5b754549b86fd459de6ec20ad2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa8d0657d741b6f6a4c7c8cf22ef46fc6f103e2611a04fd75ea0a30b476a4cd0',1987,'AG','Antigua and Barbuda','communications',35,'20 km
i
Barbuda
Caribbean Saa
ST. JOHN’ se ;
i
9 Redonds
See regional map {11
Railroads: 64 km 0.760-meter narrow
gauge, 13 km 0.610-meter gauge, em-
ployed almost exclusively for handling
cane
Highways: 240 km main
Ports: | major (St. John’s), 1 minor
Civil air: 10 major transport aircraft
Airfields: 2 total, 1 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: good automatic
telephone system; 6,700 telephones (9.2 per
100 popl.); tropospheric scatter links with
Saba and Guadeloupe; 6 AM, 2 FM, 2 TV
stations; I coaxial submarine cable; 1
satellite ground station
Defense Forces
Branches: Antigua and Barbuda Defense
Force, Royal Antigua and Barbuda Police
Force','8ed6c2b5cb23db8a23d7107ec319d078a96896f8a66512d3e7d98f94f9b62653','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d6e147b3f1e3025a1a79c79b38e9edbd63acebb8b1916b97c14058a733bb88b',1987,'AR','Argentina','communications',40,'1000 km
San Miguef
de Tucuman
BUENOS AIRES
Mar del Plata
San Carlos
da Barilocha South Atlantic
Ocean
Comodoro Rivadavia
Boundary representation 1s
not necessarily authoritative
Ushuaia
See regional map 1V
Railroads: 39,738 km total; 3,086 km
1.435-meter standard gauge, 22,788 km
1.676-meter broad gauge, 13,461 km
1.000-meter gauge, 403 km 0.750-meter
gauge; of total in country, 142 km are
electrified
Highways: 208,350 km total, of which
47,550 km paved, 39,500 km gravel,
101,000 km improved earth, 20,300 km
unimproved earth
Inland waterways: 11,000 km navigable
Pipelines: 4,090 km crude oil; 2,200 km
refined products; 9,918 km natural gas
Ports: 7 major, 30 minor
Civil air; 54 major transport aircraft
Airfields: 1,849 total, 1,689 usable; 126
with permanent-surface runways; 1 with
runways over 3,695 m, 29 with runways
2,440-3,659 m, 334 with runways
1,220-2,439 m
10
Telecommunications: extensive modern
system; 2.45 million telephones (7.9 per
100 popl.), radio relay widely used; 2
satellite stations with 3 Atlantic Ocean
antennas; 163 AM, 10 shortwave, 196 TV
stations; 30-station domestic satellite net-
work
Defense Forces
Branches: Argentine Army, Navy of the
Argentine Republic, Argentine Air Force,
National Gendarmerie, Argentine Naval
Prefecture, National Aeronautical Police
Military manpower: males 15-49,
7,500,000; 6,084,000 fit for military ser-
vice; 256,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1986, $1.1 billion; 7.3% of
central government budget','819e95dce191456cdc59ccd7c4d79f4a5541542a40a158c3d30fd9870054a7cc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c5be350d30c79de4e00b13e75072ca50aaa704180289914d301ba14a0680c6',1987,'AW','Aruba','communications',45,'Caribbean
Sea
ORANJESTAO
Sint
Nicotaaa
10 km
See regional map 111
Ports: 2 (Oranjestad, Sint Nicolaas)
1}
Airfield: government-owned airport east of
Oranjestad
Telecommunications: facilities, which
include extensive interisland radio-relay
links, are generally adequate; 49,600
telephones; 3 AM and 3 FM stations; 1 TV
station
Defense
Defense is the responsibility of the Nether-
Jands until 1996','04f3e7d532a6a7681e12c38dcf7f02c6240850d880dfa31a7800415a87f9fe94','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72202e5ee14339288b73d3fb746536bb0ba3b54a105ccdf51031792a0d332345',1987,'AU','Australia','communications',50,'Timor Sea
Darwin?
Ocaan
*
Austrelien * CANBERRA
Bight "Melbourne
e
4 Tesmen
Tasmania\\ See
1000 km_
indian Ocean
See regional map X
Railroads: 40,661 km total (1985); 7,970
km 1.600-meter gauge, 16,201 km 1.435-
meter standard gauge, 16,307 km 1.067-
meter gauge; 183 km dual gauge; 1,130
km electrified; government owned (except
for a few hundred kilometers of privately
owned track)
Highways: 837,872 km total; 243,750 km
paved, 228,396 km gravel, crushed stone,
or stabilized soil surface, 365,726 km
unimproved earth
Inland waterways: 8,368 km; mainly by
small, shallow-draft craft
Pipelines: crude oil, 2,475 km; refined
products, 500 km; natural gas, 5,600 km
Ports: 12 major, numerous minor
Civil air; around 150 major transport
aircraft
Airfields: 1,014 total, 973 usable; 228 with
permanent-surface runways, 2 with run-
ways over 3,659 m; 20 with runways
2,440-3,659 m, 486 with runways
1,220-2,439 m
Telecommunications: very good interna-
tional and domestic service; 8.7 million
telephones (55 per 100 popl.); 258 AM, 67
FM, 134 TV stations; 3 international earth
satellite stations; submarine cables to New
Zealand and Papua New Guinea; domestic
satellite service
Defense Forces
Branches: Royal Australian Navy, Austra-
lian Army, Royal Australian Air Force
Military manpower: males 15-49,
4,317,000; 3,792,000 fit for military ser-
vice; 137,000 reach military age (17)
annually
Military budget: for fiscal year ending 30
June 1986, $4.6 billion; about 9.9% of total
central government budget
13','348509d834e52a4e35aedf9deb7f72d8c4113b9d5ffe8482e6e440a27679d1cc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39a8a336ee226cdb7f0a6d20e014bde97e3596777b25cad23660ed31a8795bc7',1987,'AT','Austria','communications',55,'150 km
2fansbruck
See regional map V
Railroads: 6,497 km total; 5.857 km gov-
ernment owned; 5,403 km 1.435-meter
standard gauge of which 3,017 km electri-
fied and 1,520 km double tracked; 454 km
0.760-meter narrow gauge of which 91 km
electrified; 640 km privately owned J.435-
and ].000-meter gauge
Highways: 95,412 km total; 34,612 are the
classified network (including 1,012 km of
autobahn, 10,400 km of federal, and
23,200 km of provincial roads); of this
number, 21,812 km are paved and 12,800
km are unpaved; additionally, there are
60,800 km of communal roads (mostly
gravel, crushed stone, earth)
Inland waterways: 446 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km
natural gas; 17] km refined products
Civil air: 25 major transport aircraft
Airfields: 56 total, 54 usable; 19 with
permanent-surface runways; 5 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: highly developed
and efficient; extensive TV and
radiobroadcast systems with 6 AM, 693
FM, 910 TV stations; 1 INTELSAT (for
Atlantic and Indian regions); 3.72 million
telephones (45.9 per 100 popl.)
Defense Forces
Branches: Army, Flying Division
Military manpower: males 15-49,
1,964,000; 1,655,000 fit for military ser-
vice; 57,000 reach military age (19) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $1.18 billion; about 4.2%
of the proposed federal budget
The Bahamas
200 ken
Meaton, By North
- @Great Abaco Atlantic
i ‘ Ocean
NASSAU& “x Eleuthers
ay
" : _.qCat Island
Cay Sal andros 2 me \\
aa island ¢ " ‘ >
a eo
fre Long Island
North a ” oxy
Atlantic Lee ne
Ocean ‘ .
°
Great inagua
See regional map fl!
Railroads: none
Highways: 2,400 km total; 1,350 km
paved, 1,050 km gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 9 major transport aircraft
Airfields: 59 total, 56 usable; 29 with
permanent-surface runways; 8 with run-
ways 2,440-3,659 m, 23 with runways
1,220-2,489 m
Telecommunications: highly developed,
including 84,000 telephones (37.9 per 100
popl.) in totally automatic system; tropo-
spheric scatter and cable links with Flor-
ida; 8 AM, 2 FM, and 1 TV stations; 3
coaxial submarine cables; satellite ground
station under construction
Defense Forces
Branches: Roya! Bahamas Defense Force
(a coast guard element only), Royal Baha-
mas Police Force
Military budget: for fiscal year ending 31
December 1985 $12.7 million, about 3% of
the total budget
16
Bahamas.','0e791c33df11be0b5476033a2d4da890a4192edf2a545f48a0382188232230f4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba07f0c2b65cac22528a7b41c3d0f8ba8667973d39b0843b7a57c62c1af004ce',1987,'BH','Bahrain','communications',60,'Perel
ersian Gulf Al Muharra
. MANAMA
Hawar Islands are
disputed between
Bahrain and Qatar
Gulf of
10 km
See regional map V1','8258ecd32e975e881468fd9864223a28f6508db8fe7cb58c89053e2d68a55687','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b5cfcf8b8c2bb52a674f9e0bcb9e295ba24d62bb15f929aed7f8a5963930c0e',1987,'SA','Saudi Arabia','communications',66,'Railroads: none
Highways: 225 km bituminous surfaced;
undetermined kilometers of natural sur-
face tracks; 25 km bridge-causeway to
Saudi Arabia opened in November 1986
Ports: ] major (Mina’ Sulman), 1 minor
(Mina’ al Mandmah), | petroleum, oil, and
lubricant terminal (Sitrah)
Pipelines: crude oil, 56 km; refined prod-
ucts, 16 km; natural gas, 32 km
Civil air: 8 major transport aircraft
Airfields: 3 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways over 3,659 m; 1 with runways
1,220-2,489 m
Telecommunications: excellent interna-
tional telecommunications; adequate
domestic services; 98,000 telephones (23.2
per 100 popl.); 2 AM, 1 FM, and 2 TV
stations; 1 Atlantic Ocean, | Indian Ocean,
and 1 ARABSAT satellite stations; tropo-
spheric scatter and microwave to Qatar,
United Arab Emirates, Saudi Arabia;
submarine cable to Qatar and United Arab
Emirates
Defense Forces
Branches: Army, Naval Wing, Air Wing
Military manpower: males 15-49, 168,000;
95,000 fit for military service
17
500 km
eTabuk
Persian
Gulf
Ad Dammam
Boundary representation is
not necessarily authoritative
See regional map V1
Railroads: 886 km 1.435-meter standard
gauge
Highways: 67,000 km total; 28,000 km
bituminous, 39,000 km gravel and im-
proved earth
Pipelines: 6,400 km crude oil; 150 km
refined products; 2,200 km natural gas,
includes 1,600 km of natural gas liquids
Ports: 7 major (Jiddah or Jeddah, Ad
Dammam, Ras Tanura, Jizin, Al Jubayl,
Yanbu‘ al Bahr, Yanbu‘ as Sind‘iyah), 17
minor
Civil air; 191 major transport aircraft
Airfields: 202 total, 174 usable; 60 with
permanent-surface runways; 11 with
runways over 3,659 m, 26 with runways
2,440-3,659 m, 98 with runways
1,220-2,439 m
Telecommunications: good system exists,
major expansion program completed with
extensive microwave and coaxial cable
systems; 1,624,000 telephones (14.1 per 100
popl.); 21 AM, 2 FM, 63 TV stations; 2
Atlantic and 2 Indian Ocean INTELSAT
stations, 1 ARABSAT satellite control
station; radio-relay to Bahrain, Jordan,
Kuwait, Qatar, UAE, and Sudan; coaxial
cable to Kuwait; submarine cable to
Railroads: 38 km of 1.000-meter gauge
Highways: 2,597 km total (1984)
Inland waterways: none
Ports: 3 major, 2 minor
Civil air: about 30 major transport aircraft
Airfields: 6 total, 6 usable; 6 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 2 with runways
2,440-3,659 m, 1 with runways 1,220-2,439
m
Telecommunications: good domestic
facilities; good international service; good
radio and television broadcast coverage;
1.02 million telephones (39.0 per 100
popl.); 18 AM, 4 FM, 2 TV stations; sub-
marine cables extend to Sabah (Malaysia),
Peninsular Malaysia, Indonesia, and the
Philippines; ) satellite ground station
Defense Forces
Branches: Army, Navy, Air Force, Army
Reserve, Singapore Armed Forces
Military manpower: males 15-49, 808,000;
606,000 fit for military service
Military budget: estimated for fiscal year
ending 31 March 1987, $950 million;
about 11.2% of central government budget
220
Railroads: none
Highways: 5,600 km total; 1,700 km
bituminous treated, 630 km crushed stone
and gravel, 3,270 km motorable track
Pipelines: refined products, 32 km
Ports: 1 major (Aden), 5 minor
Civil air: 9 major transport aircraft
Airfields: 41 total, 30 usable; 5 with
permanent-surface runways; 1) with
runways 2,440-3,659 m, 11 with runways
1,220-2,4389 m
268
Telecommunications: small system of
open-wire, radio-relay, multiconductor
cable, and radio communications stations;
only center Aden; estimated 15,000 tele-
phones (0.7 per 100 popl.); 1 AM, no FM,
5 TV stations; 1 Indian Ocean INTELSAT,
1 Intersputnik, and 1 ARABSAT satellite
station; tropospheric scatter to North','42841c30d2b5eb01326dbb9393e0eea5912cb68c0f664c2599936ee3190df5a8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5a056a78afbd7f48aadd5107ea5639dcf01e565adc6192b49a72dded0bf6754',1987,'BD','Bangladesh','communications',67,'150 km
Boundary representation ts
not necessarily authoritative.
“ae 8 Chittagong
Bay of Bengal
See regional map VIII
Barbados _','2d676346133b4bb14bfa6de5819057987eaafca78c9ad1b2aaf15db12008e1bd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e07bcbd71b222337334b7e8bf5eee9d471ca18bab9f935eccd3eae968ef91aaa',1987,'IN','India','communications',73,'Railroads: 2,892 km total (1986); 1,914 km
meter gauge, 978 km meter gauge; govern-
ment owned
Highways: 7,240 km total (1985); 3,840
km paved, 3,400 km unpaved
Inland waterways: 5,150-8,046 km navi-
gable waterways (includes 2,575-3,058 km
main cargo routes)
Ports: 2 sea (Chittagong, Chalna), 7 inland
Pipelines: 650 km natural gas
Civil air: 15 major transport aircraft
Airfields: 18 total, 13 usable; 14 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: adequate interna-
tional radio communications and landline
service; fair domestic wire and microwave
service; fair broadcast service; 182,000
telephones (0.18 per 100 popl.); 9 AM, 6
FM, 11 TV stations; 2 satellite ground
stations
Jammu and pscoieee line
Kashit®?") of control 500 km
- .J
Srinagar Boundary representation 1s.
claim hot necessarily authoritative
Arabian Bombsy
ae Hyderabsa
Panaji Bangal
Madras Andaman }
a Islands ¥
+ Caligut .
Laccadive epeturel ''
Sea Nicobar +:
Islands ‘©
See segional map Viil','e32b5af72cee9a14b5d5a07cc4faf5a6dc324b97a708616e3274ae7290a76697','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c6c48b36a04795e5a80408b4abc1b710027e0e482e51a270a799ebd2f70371',1987,'BB','Barbados','communications',74,'Defense Forces
Branches: Army, Navy, Air Force; para-
military forces—Bangladesh Rifles, Ban-
gladesh Ansars, Armed Police Reserve,
Coastal Police
North
Atlantic
Military manpower: males 15-49,
25,768,000; 15,327,000 fit for military
service
Military budget: for fiscal year ending 30
June 1987, $218 million; about 18% of
central government budget The Crane
Caribbean
Sea
See regional map 111
Railroads: none
Highways: 1,570 km total; 1,475 km
paved, 95 km gravel and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 2 major transport aircraft
Airfields: 1 total, 1 usable; 1 with
permanent-surface runways 2,440-3,659 m
Telecommunications: islandwide auto-
matic telephone system with 75,000 tele-
phones (30.0 per 100 popl.); tropospheric
scatter link to Trinidad and St. Lucia; 2
AM, 1 FM, and 1 TV stations; 1 Atlantic
Ocean satellite station
Defense Forces
Branches: Barbados Defense Force, Royal
Barbados Police Force
Military manpower: males 15-49, 89,000;
63,000 fit for military service, no conscrip-
tion
Military budget: for fiscal year 1986,
$10.1 million; 3% of central government
budget
20','118de5a7914005b0d68af49a1f20d38794bbf539c262e9cade23c94e6399da42','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559951add6a1633e7c4fce339a1d750b42d50e0a8316e8c87243ad94bcf4fd9a',1987,'BE','Belgium','communications',79,'_ 50 km
North
Sea
Antwerp
*® RUSSELS
=
Liege
Mons
* Charteroi
Bastogne,
See regional map V
Railroads: Belgian National Railways
(SNCB) operates 8,741 km 1.435-meter
standard gauge, government owned; 2,563
km double track; 1,969 km electrified; 191
km 1.000-meter gauge, government owned
and operated
Belgium (continued)
Highways: 103,396 km total; 1,317 km
limited access, divided autoroute; 11,717
km national highway; 1,862 km provincial
road; about 38,000 km other paved; about
51,000 km unpaved rural
Inland waterways: 2,048 km (1,528 km in
regular commercial use)
Ports: 6 major, ] minor
Pipelines: refined products, 1,115 km;
crude, 161 km; natural gas, 3,300 km
Civil air: 47 major transport aircraft
Airfields: 44 total, 43 usable; 25 with
permanent-surface runways; 14 with
runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: excellent domestic
and international telephone and telegraph
facilities; 4.22 million telephones (42.8 per
100 popl.); 6 AM, 39 FM, 32 TV stations,
6 submarine cables; 2 Atlantic Ocean
INTELSAT stations; 2 EUTELSAT anten-
nas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
2,500,000; 2,114,000 fit for military ser-
vice; 80,000 reach military age (19) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $3.4 billion; 8.8% of the
central government budget','dd8fadb2f763964c259ca9d4f37676a11e8d2d0dd1a7fa03fa2bf3bcfe5947c6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c9e540ed4d9616c08d3cb06632140444bfaf96d901d03cb3eb5cc1cac2dc890',1987,'GT','Guatemala','communications',89,'Railroads: none
Highways: 2,575 km total; 340 km paved,
1,190 km gravel, 735 km improved earth,
and 310 km unimproved earth
Inland waterways: 825 km river network
used by shallow-draft craft; seasonally
navigable
Ports: 2 major (Belize City, Belize City
Southwest), 6 minor
Civil air: no major transport aircraft
Airfields: 40 total, 35 usable; 5 with
permanent-surface runways; 3 with run-
ways 1,220-2,489 m
Telecommunications: 8,650 telephones
(4.5 per 100 popl.), above average system
based on radio-relay; 6 AM, 5 FM stations;
1 Atlantic Ocean INTELSAT station
Defense Forces
Branches: British Forces Belize, Belize
Defense Force, Police Department
Military manpower: males 15-49, 37,000;
22,000 fit for military service; 1,800 reach
military age (18) annually; the nucleus of
the Belize Defense Force (BDF) is the
former Special Force of the Belize Police,
which was transferred intact to the new
organization; the bulk of the early recruits
were drawn from the Belize Volunteer
Guard, a home guard force that had
previously acted as a police reserve; the
BDF currently consists of full-time soldiers
known as the Regulars and an essentially
reserve group, which has maintained the
Volunteer Guard name; recruitment is
voluntary and the terms of service vary
Military budget: for fiscal year ending 31
March 1986, $3.5 million; 3.3% of central
government budget
23
100 km
Behia de
Amatique
hago de .
frabal, Santo Tomas
de Castille
(GUATEMALA
Cobén
*
“Hushuatenango
Quezattenango
See regional map Ill
Railroads: 870 km 0.914-meter gauge,
single track; 780 km government owned,
90 km privately owned
100
Highways: 26,429 km total; 2,868 km
paved, 11,421 km gravel, and 12,140
unimproved
Inland waterways: 260 km navigable year
round; additional 730 km navigable during
high-water season
Pipelines: crude oil, 275 km
Ports: 2 major (El Quetzal, Santo Tomas
de Castilla), 3 minor
Civil] air: 10 major transport aircraft
Airfields: 501 total, 455 usable; 11 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 23 with runways
1,220-2,439 m
Telecommunications: fairly modern
network centered on Guatemala; 97,670
telephones (1.6 per 100 popl.); 91 AM, 13
shortwave, 24 TV stations; connection into
Central American microwave net; 1 Atlan-
tic Ocean satellite station
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
1,989,000; 1,295,000 fit for military ser-
vice; 94,000 reach military age (18) annu-
ally
Military budget: proposed for fiscal year
ending 31 December 1987, $269.3 million;
10.5% of central government budget','22c7a8b2c0036053fed7ac829a3c8a99ebfe13ac69d5e74275b7f1372c2b4a5d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20809b818538e5355e23b29792f667f52741bdab8990ed5b592e704d8b3e76d1',1987,'BJ','Benin','communications',90,'150 km
Natitingou
PORTO-NOVO
Bight of Benin
See regional map Vil
Railroads: 580 km, all 1.000-meter gauge,
single track
Highways: 8,550 km total; 828 km paved,
5,722 km improved earth
Inland waterways: small sections, only
important locally
Ports: I major (Cotonou)
Civil air: 4 major transport aircraft
24
Airfields: 9 total, 8 usable; I with
permanent-surface runways; 4 with run-
ways I,220-2,439 m
Telecommunications: fair system of open
wire and radio relay; 16,200 telephones
(0.4 per 100 popl.); 2 AM, 2 FM, and 1 TV
stations; I Atlantic Ocean satellite ground
station
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: eligible 15-49,
1,738,000; of the 805,000 males 15-49,
412,000 are fit for military service; of the
933,000 females 15-49, 471,000 are fit for
military service; about 54,000 males and
52,000 females reach military age (18)
annually; both sexes are liable for military
service
Gulf of Guinea
See regional map VII','5d32200a81dbf3dd88b9f87753e96f799372623f3e10508fba6762590f42f2b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70e23847eae6e3708627219e63e4dd555371414e6164376767f6c27087cec325',1987,'BM','Bermuda','communications',95,'Skm
North Atlantic Ocaan
See regional map It
Railroads: none
Highways: 210 km public roads, all paved
(about 400 km of private roads)
Ports: 3 major
Civil air: 16 major transport aircraft
Airfields: 1 total, 1 usable, 1 with
permanent-surface runways 2,440-3,659 m
Telecommunications: modern telecom
system, includes fully automatic telephone
system with 46,290 sets (84.6 per 100
popl.); 4 AM, 3 FM, 2 TV stations; 3
submarine cables; 2 Atlantic Ocean satel-
lite antennas
Defense Forces
Defense is the responsibility of United
Kingdom
Branches: The Bermuda Regiment','9c45d2959e3e91c18a25634b4ea1f5278cb4167f7b1bb6ff08341ddaabb716df','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13529b6061c0c47e167c7c555183345a6a83ed6fd9320adc00a726c556211a5f',1987,'BT','Bhutan','communications',100,'75 km
Tongse
ZHIMPHU {Dzong Tashi ©
* Paro Drang pay
Samprup
Phunchholing Jongkher +
See regional map VIII
Highways: 1,304 km total; 418 km sur-
faced, 515 km improved, 371 km unim-
proved earth
Civil air: no major transport aircraft
Airfields: 2 total; 2 usable; 2 with
permanent-surface runways; | with run-
ways 1,220-2,439 m
Telecommunications: facilities inade-
quate; 1,300 telephones (0.1 per 100 popl.);
11,000 est. radio sets; no TV sets; 20 AM
stations; no TV stations
Defense Forces
Branches: Royal Bhutan Army
Military manpower: males 15-49, 362,000;
194,000 fit for military service; 16,000
reach military age (18) annually
Bolivia
400 km
«
Trinidad
Lago Titicaca
Soe
LA PAZ cochabamba
“Santa Cruz
e
Orura
Sucra
a
?
Potost
“Tarija
See regional map 1V
Railroads: 3,675 km total; 3,538 km 1.000-
meter gauge and 32 km 0.760-meter
gauge, all government owned, single track;
105 km 1,000-meter gauge, privately
owned
Highways: 38,836 km total; 1,300 km
paved, 6,700 km gravel, 30,836 km im-
proved and unimproved earth
Inland waterways: officially estimated to
be 10,000 km of commercially navigable
waterways
Pipelines: crude oil, 1,670 km; refined
products, 1,495 km; natural gas, 580 km
Ports: none (Bolivian cargo moved through
Arica and Antofagasta, Chile, and Matar-
ani, Peru)
Civil air: 56 major transport aircraft
Airfields: 711 total, 643 usable; 9 with
permanent-surface runways; | with run-
ways over 3,659 m, 7 with runways
2,440-3,659 m, 130 with runways
1,220-2,489 m
Telecommunications: radio-relay system
being expanded; improved international
services; 144,300 telephones (2.6 per 100
popl.); 129 AM, 62 shortwave, 38 TV
stations; 1] Atlantic Ocean INTELSAT
station
Defense Forces
Bolivia','963ec8efecfa966de526d65a0fb0e69aeaf0d1b79dbd52795b275ec808a1a8c1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91e6aef7e24cc693fcdf7eb2caa31083144ebbe534f7beefedd34ffb8c9a9976',1987,'BW','Botswana','communications',105,'200 km
Branches: Bolivian Army, Bolivian Navy,
Bolivian Air Force (literally, the Army of
the Nation, the Navy of the Nation, the
Air Force of the Nation)
Military manpower: males 15-49,
1,510,000; 984,000 fit for military service;
65,000 reach military age (19) annually
Tshabong Boundary representation is
not necessarily authoritative
See regional map Vil
Railroads: 726 km 1.0 67-meter gauge
Highways: 11,514 km total; 1,600 km
paved; 1,700 km crushed stone or gravel,
5,177 km improved earth, 3,037 km unim-
proved earth
Civil air: 6 major transport aircraft
Airfields: 105 total, 97 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 24 with runways
1,220-2,439 m
Telecommunications: the small system is
a combination of open-wire lines, radio-
relay links, and a few radiocommunication
stations; 17,900 telephones (1.7 per 100
popl.); 3 AM, 2 FM, 2 TV stations; 1
Indian Ocean satellite ground station
Defense Forces
Branches: Army, Air Wing, Botswana
Police
Military manpower: males 15-49, 215,000;
113,000 fit for military service; 13,000
reach military age (18) annually','6eee8a3d679db83090a4ca4087fe448b6c12e4d64caed0e42a0d21bc28d3087a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3bbe2f815f6a0525fc4afbdfcb7b5cdd7dd7099fdf3ce2fbbb13f417f51dc76',1987,'BR','Brazil','communications',110,'North Atlentic
Meneus
id
rio Branco
Cuiehs
ane BRASILIA
Belo Hori: ‘onte
Corumbés ,
Rig de Janeiro
Séo Paulo
Boundary representation is
nol necessarily authonlatwe z
South Atlentic
Ocean
—o00km= Pérto Alegre
See cegiona! map IV
Railroads: 29,781 km total; 25,155 km
1.000-meter gauge, 4,339 km 1.600-meter
gauge, 200 km 1.435-meter standard
gauge, 87 km 0.760-meter gauge; 1,915 km
electrified
Highways: 1,498,000 km total; 48,000 km
paved, 1,400,000 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 2,000 km; refined
products, 465 km; natural gas, 257 km
Civil air: 176 major transport aircraft
Airfields: 4,470 total, 3,615 usable; 332
with permanent-surface runways; 1 with
runways over 3,659 m; 23 with runways
2,440-3,659 m; 489 with runways
1,220-2,489 m
Telecommunications: good telecom sys-
tem; extensive radio-relay facilities, 2
Atlantic Ocean INTELSAT stations with
total of 3 antennas; 64 domestic satellite
stations; 9.86 million telephones (7.3 per
100 popl.); 1,141 AM, 171 shortwave, 200
TV stations; 3 coaxial submarine cables
Defense Forces
Branches: Brazilian Army, Navy of Brazil,
Brazilian Air Force
Military manpower: males 15-49,
87,002,000; 25,022,000 fit for military
service; 1,579,000 reach military age (18)
annually
Military budget: estimated for fiscal year
ending 31 December 1986, $4.3 billion;
7.2% of central government budget
31
British Indian Ocean
Territory
kn (oan F
ee “Salomon Islands
Peros Banhos”
Chagos
Archipelago
‘Eagle Islands
‘
“= Egmont Islands
Indian Ocean
ea Garcia
See regional map 1
Railroads: none
Highways: short stretch of paved road
between port and airfield on Diego Garcia
Inland waterways: none
Ports: 1 major (Diego Garcia)
Airfields: 1 total, 1 usable with
permanent-surface runways over 3,659 m
on Diego Garcia
Telecommunications: minimal telecom-
munications facilities; US Navy operates 1
AM, 1 FM, and 1 TV stations
Defense Forces
United Kingdom and United States de-
fense facilities
British Virgin Islands
—lokm
North Anegada y
Atlantic
Ocean
Jost YY
Van w~® % oe 18 Lon
Oy ke Gorda
Oo <A. ic 3
@ ROAD TOW! B®
CFs .
Tortola .
ra
Caribbean Sea
See regional map Ill
Railroads: none
Highways: 106 km motorable roads (1983)
Inland waterways: none
Ports: 1 major (Road Town)
Airfields: 3 total; 3 usable; 2 with
permanent-surface runways
Telecommunications: 3,000 telephones—
worldwide external telephone service and
cable communication links; 1 AM and |
TV stations
Defense Forces
Defense is the responsibility of the United
Kingdom
Brunei
25. km_
South China
Sea
Kuala
Belait
See regional map 1X
Railroads: 13 km 0.610-meter narrow-
gauge private line
Highways: 1,090 km total; 370 km paved
(bituminous treated) and another 52 km
under construction, 720 km gravel or
unimproved
Inland waterways: 209 km; navigable by
craft drawing less than 1.2 meters
Ports: 1 major (Muara), 4 minor
Pipelines: crude oil, 135 km; refined
products, 418 km; natural gas, 920 km
Civil air: 8 major transport aircraft
Airfields: 3 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways over 3,659 m; 1 with runways
1,220-2,439 m
Telecommunications: service throughout
country is adequate for present needs;
international service good to adjacent
Sabah and Sarawak; radiobroadcast cover-
age good; 27,000 telephones (11.0 per 100
popl.); Radio Brunei broadcasts from 4
AM/FM stations and 1 TV station; 52,000
radio receivers; 1 satellite station
Defense Forces
Branches: Royal Brunei Armed Forces,
including air wing, navy, and ground
forces; British Gurkha Battalion; Royal
Brunei Police; Gurkha Reserve Unit
Military manpower: males 15-49, 61,000;
37,000 fit for military service; about 3,300
reach military age (18) annually
Military budget: for fiscal year ending 31
December 1986, $197.6 million; about 17%
of central government budget
34
Brunei','882842ef3a6cb0e0daaf5ce27f985358c3f8270ef501d313a5e2c2d8c8264fee','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c09556b2045b9c7559e49eb2642760509714ef47016a046ce64c4f610d6784ee',1987,'BG','Bulgaria','communications',115,'125 km
Stara
pSOFIA Zagora,
Piovdiv
- Blagoevgrad
See regional map V
Railroads: 4,278 km total; all government
owned (1984); about 4,083 km 1.435-meter
standard gauge, 245 km narrow gauge; 823
km double track; 2,053 km electrified
Highways: 36,336 km total; 33,042 km
hard surface (including 211 km superhigh-
ways); 3,294 km earth roads (1984)
Inland waterways: 471 km (1981)
Pipelines: crude, 193 km; refined product,
418 km; natural gas, 1,400 km
Freight carried: rail—82.9 million metric
tons, 18.1 billion metric tons/km; high-
way—914 million metric tons, 17.1 billion
metric tons/km; waterway—4.0 million
metric tons, 2.0 billion metric tons/km
(1985)
Ports: 3 major (Varna, Varna West,
Burgas), 6 minor; principal river ports are
Ruse and Lom
Civil air: 65 major transport aircraft
Airfields: 380 total; 15 with runways 2,500
m or longer
Telecommunications: 15 AM, 14 FM, 13
TV stations; 1 Soviet TV relay; 2,002,000
TV sets; 2,100,000 receiver sets; at least 1
satellite ground station
Defense Forces
Branches: Bulgarian People’s Army, Fron-
tier Troops, Air and Air Defense Forces,
Bulgarian Navy
Military manpower: males 15-49,
2,156,000; 1,808,000 fit for military ser-
vice; 65,000 reach military age (19) annu-
ally
Military budget: est. for fiscal year ending
831 December 1986, 1.2 billion leva; 6.0%
of total budget
Burkina
200km
See regional map VII
Railroads: 1,173 km Ouagadougou to
Abidjan (Ivory Coast line); 516 km 1.000-
meter gauge, single track in Burkina
Highways: 16,500 km total; 1,300 km
paved, 7,400 km improved, 7,800 km
unimproved
Civil] air: 1 major transport aircraft
Airfields: 56 total, 51 usable; 2 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 6 with runways
1,220-2,439 m
Telecommunications: all services only
fair; radio-relay, wire, radio communica-
tion stations in use; 13,900 telephones
(under 0.2 per 100 popl.); 2 AM, 2 FM, 2
TV stations; 1 Atlantic Ocean INTELSAT
station
Defense Forces
Branches: Army, Air Force
Military manpower: males 15-49,
1,772,000; 905,000 fit for military service;
no conscription
Military budget: for fiscal year ending 31
December 1984, $26.9 million; about
18.1% of central government budget
Burma
500 km
Andaman
Sea
See regional map VIIl and 1X
Railroads: 4,353 km total; all government
owned; 3,878 km 1.000-meter gauge, 113
km narrow-gauge industrial lines; 362 km
double track
Highways: 27,000 km total; 3,200 km
bituminous, 17,700 km improved earth or
gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km
navigable by large commercial vessels
Pipelines: crude, 1,117 km; natural gas,
830 km
Ports: 4 major, 6 minor
Civil air: 17 major transport aircraft
(including 3 helicopters)
Airfields: 89 total, 83 usable; 29 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 37 with runways
1,220-2,439 m
Telecommunications: meets minimum
requirements for local and intercity ser-
vice; international service is good;
radiobroadcast coverage is limited to the
most populous areas; 49,597 telephones
(1982/83; 1 per 1,000 popl.); 2 AM, 1 FM,
and 1 TV stations (1985); 1 satellite ground
station
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: eligible 15-49,
18,940,000; of the 9,439,000 males 15-49,
5,069,000 are fit for military service; of
the 9,501,000 females 15-49, 5,091,000 are
fit for military service; 413,000 males and
403,000 females reach military age (18)
annually; both sexes are liable for military
service
Military budget: for fiscal year ending 31
March 1987, $249.48 million; about 21.7%
of central government budget
38
Burkina
Burma
Burundi _','5b706904835f788ac192ba0c14843409be4fb4c4c7c7c9354f360b53cbb172e4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f62b1131718f700557529c072a649cf74a7e689460bdd15ff252e083a5881078',1987,'BI','Burundi','communications',120,'50 km
Muyinga,
cS itega
Laka 4
Tanganyika _Bururi
See regional map VUl
Railroads: none
Highways: 5,900 km total; 400 km paved,
2,500 km gravel or laterite, 3,000 km
improved or unimproved earth
Inland waterways: Lake Tanganyika; 1
lake port, at Bujumbura, connects to
transportation systems of Zaire and Tanza-
nia
Civil air: 1 major transport aircraft
Airfields: 8 total, 7 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
39
Telecommunications: sparse system of
wire and low-capacity radio-relay links;
about 6,000 telephones (0.1 per 100 popl.);
2 AM, 2 FM, and 1 TV stations; 1 Indian
Ocean satellite ground station
Defense Forces
Branches: Army (including naval and air
units); paramilitary Gendarmerie
Military manpower: males 15-49,
1,108,000; 580,000 fit for military service;
56,000 reach military age (16) annually
Military budget: for fiscal year ending 31
December 1986, $39.3 million; about 18%
of central government budget','97abaa928d569784be7dbe0a00cc28f6a93e089a9a4b5df844a0b1b75c2619ba','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a46ee757f4b48921db75a0fdbddaf84e6651a8c2f8039e9c6b01834924cbf69',1987,'TH','Thailand','communications',125,'See regional map 1X
Boundary representation is
not necessarily authontatiwe
Railroads: 612 km 1.000-meter gauge;
government owned
Highways: 13,35) km total; 2,622 km
bituminous, 7,105 km crushed stone,
gravel, or improved earth; and 3,624 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all
year to craft drawing 0.6 meters; 282 km
navigable to craft drawing 1.8 meters
Ports: 2 major, 5 minor
Airfields: 26 total, 18 usable; 8 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: service barely
adequate for government requirements
and virtually nonexistent for general
public; international service limited to
Vietnam and other adjacent countries;
earth satellite station scheduled for early
1987; radiobroadcasts limited to 1 station;
1 TV station
Defense Forces
Branches: PRK—People’s Republic of
Kampuchea Armed Forces; resistance
forces are the National Army of Demo-
cratic Kampuchea (Khmer Rouge), Khmer
People’s National Liberation Armed
Forces, and Sihanoukist National Army
Military manpower: males 15-49,
1,782,000; 988,000 fit for military service;
about 73,000 reach military age (18) annu-
ally
Railroads: none
Highways: Male has 9.6 km of coral
highways within the city
Ports: 2 minor (Male, Gan)
Civil air; 1 major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m
Telecommunications: minimal domestic
and international facilities; 1,064 tele-
phones (0.5 per 100 popl.); 1 TV, 1 FM, 2
AM stations; 1 Indian Ocean INTELSAT
station
Defense Forces
Military budget: for fiscal year ending 3]
December 1984, about $1.8 million
See regional map 1X
Railroads: 3,940 km 1.000-meter gauge,
99 km double track
Highways: 44,534 km total; 28,016 km
paved, 5,132 km earth surface, 11,386 km
under development
Inland waterways: 3,999 km principal
waterways; 3,70] km with navigable
depths of 0.9 m or more throughout the
year; numerous minor waterways naviga-
ble by shallow-draft native craft
Pipelines: natural gas, 350 km; refined
products, 67 km
Ports: 2 major, 16 minor
Civil air: 30 (plus 2 leased) major transport
aircraft
Airfields: 131 total, 104 usable; 57 with
permanent-surface runways; 1 with run-
ways over 8,659 m, 13 with runways
2,440-3,659 m, 26 with runways
1,220-2,489 m
Telecommunications: service to general
public adequate; bulk of service to govern-
ment activities provided by multichannel
cable and radio-relay network; satellite
ground station; domestic satellite system
being developed; 623,368 telephones; over
200 AM, about 100 FM, 11 TV transmit-
ters in government-controlled networks
Defense Forces
Branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps),
Royal Thai Air Force; paramilitary forces
include Border Patrol Police, Thahan
Phran (irregular soldiers), Village Defense
Forces
Military manpower: males 15-49,
14,557,000; 8,912,000 fit for military
service; 630,000 reach military age (18)
annually
Military budget: for fiscal year ending 30
September 1987, $1.6 billion (est.); 18.1%
of central government budget
Con Ooo
See regional map 1X','9ab42b2b1fd738351f0eebb4d32731a87fc5414b81f558d135134c797bcd8bac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3a256406a6ec1e3dac1f8590f1c98ce4be79f489b54741493f9b1619c26da0d',1987,'CM','Cameroon','communications',130,'300 km
Ngaounderé
>
-bafoussam rf
Bertoua
» e
Dovele Yaounde
Gulf of Guinea
See regional map V1l
Railroads: 1,173 km total; 858 km 1.000-
meter gauge, 145 km 0.600-meter gauge
Highways: about 65,000 km total; includes
2,682 km bituminous, 30,000 km unim-
proved earth, 32,318 km gravel, earth, and
improved earth
Inland waterways: 2,090 km; of decreas-
ing importance
Ports: 1 major (Douala), 8 minor
Civil air: 7 major transport aircraft
Airfields: 63 total, 58 usable; 9 with
permanent-surface runways; 5 with run-
ways 2,440-3,659 m, 25 with runways
1,220-2,489 m
Telecommunications: good system of
open wire and radio-relay; 26,000 tele-
phones (0.2 per 100 popl.); 10 AM, 1 FM,
and | TV stations; 1 Atlantic Ocean satel-
lite station
Defense Forces
Branches: Army, Navy, Air Force; para-
military Gendarmerie
Military manpower: males 15-49,
2,345,000; 1,181,000 fit for military ser-
vice; 111,000 reach military age (18)
annually
Military budget: for fiscal year ending 30
June 1987, $153.6 million; 6.5% of central
government budget
42
Canada _
Cape Verde
Central African Republic ‘
China, People’s
Republic of
Colombia_','e99ab5d97c929be95383e596d171f1261bae0599f9c96b88bf6c41219004f761','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8558c9d54fa201d6318413b2bbb9b67e3d5e288baf047a2a49aecc91793e4618',1987,'CA','Canada','communications',135,'1200 km
Arctic Ocean
eines
Qs Battin
Sgr > Bay
cs PNR fe
=
Labrador
*whitshorse
Churchill
Vancouver Catgary
Winnipeg
Leake Superior
Lake Huron
See regional map 11
Railroads: 81,088 km total; 79,917 km
1.435-meter standard gauge, 129 km
electrified; 1,171 km 1.067-meter gauge (in
Newfoundland); 178 km 0.915-meter
gange (unused)
Highways: 884,272 km total; 712,936 km
surfaced (250,023 km paved), 171,336 km
earth
Inland waterways: 3,000 km, including St.
Lawrence Seaway
Pipelines: oil, 23,564 km total crude and
refined; natural gas, 74,980 km
Ports: over 250 ports of which 25 are
sizeable deep water ports
Civil air: 636 major transport aircraft
Airfields: 1,407 total, 1,076 usable; 412
with permanent-surface runways; 4 with
runways over 3,659 m, 30 with runways
2,440-3,659 m, 306 with runways
1,220-2,439 m
Canada (continued)
Telecommunications: excellent service
provided by modern telecom media; 18.0
million telephones (66.4 per 100 popl.);
countrywide AM, FM, and TV coverage,
including 900 AM, 80 FM, 1,100 TV
stations; 6 coaxial submarine cables; 3
satellite stations with a total of 5 antennas
and 300 domestic satellite stations
Defense Forces
Branches: Mobile Command, Maritime
Command, Air Command, Communica-
tions Command, Canadian Forces Europe,
Training Command
Military manpower: males 15-49,
7,036,000; 6,183,000 fit for military ser-
vice; 189,000 reach military age (17)
annually
Military budget: for fiscal year ending 31
March 1986, $8.0 billion; about 10.3% of
central government budget
Cape Verde
&... Antéo — 75 km
“bs
Mindelo 5.
Senta % Sal
Sto © Luzis %,
Vicente *. ip
555 ,
Sto ’o
TIED Boe Vista
North Atlantic Ocean
tavento
thas do S0 a”
Fi
ae PRAIA
BraveQ S@o Tiago
See regional map VIl
Ports: 2 major (Mindelo and Praia), 2
minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 4 with runways
],220-2,489 m
Telecommunications: interisland radio-
relay system, high frequency radio to
mainland Portugal and Guinea-Bissau;
about 1,740 telephones (0.6 per 100 popl.);
2 FM, 5 AM stations; 1 small TV station; 2
coaxial submarine cables; 1 Atlantic Ocean
satellite ground station
Defense Forces
Branches: People’s Revolutionary Armed
Forces (FARP); Army, Navy, and Air
Force are separate components of FARP
Military manpower: males 15-49, 64,000,
$8,000 fit for military service
Military budget: for fiscal year ending 31
December 1980, $15 million; about 5% of
central government budget','68b2867a1c27cf7d65b3f9fdb49e40d9410ac0aa9a4437319b22db746f1ec8d7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b443d7019ecd262d6810fb1f205bcc4fee33b935b7ce867686aa538be0545e52',1987,'KY','Cayman Islands','communications',140,'—5okm_
Caribbean Sea
Little?
Cayman
Grand Cayman
GEORGE TOWN
Caribbean Sea
See regional map 111
Railroads: none
Highways: 160 km of main roads
Ports: 1 major (George Town), 1 minor
Airfields: 3 total; 3 usable; 2 with
permanent-surface runways, 2 with run-
ways 1,220-2,439 m
Telecommunications: telephone system
links islands and to worldwide services via
submarine coaxial cable and satellite
ground station; 2 AM and 2 FM radio
stations
Defense Forces
Defense is the responsibility of the United
Kingdom
Branches: police force','a66c3afd26619886c24adff6264b959322b41eae3afc309442db9b40df0842b2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('527b094ec62ccdc2bb0875113718b18e00e09a6fd550ffc8126f58712dfb70d2',1987,'CF','Central African Republic','communications',145,'400 km
See regional map Vil
Railroads: none
Highways: 20,800 km total; 454 km bitu-
minous, 7,656 km improved earth, 12,690
'' unimproved earth
Inland waterways: 800 km; traditional
trade carried on by means of shallow-draft
dugonts
Civil air: 8 major transport aircraft
Airfields: 68 total, 61 usable; 4 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Telecommunications: facilities are mea-
ger; network is composed of low-capacity,
low-powered radiocommunication stations
and radio-relay links; 6,000 telephones (0.2
per 100 popl.); 1 AM, 1 FM, and 1 TV
stations; 1 Atlantic Ocean satellite ground
station
Defense Forces
Branches: Army, Air Force
Military manpower: males 15-49, 592,000,
309,000 fit for military service
Military budget: for fiscal year ending 31
December 1983; $12.2 million; about
14.5% of central government budget
47','37f55fd8e95b4699896ee8bfc473df115df2f0bc74ff03d240da831e510c59ac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acfa039a210b27eea537bf11de29b176c7b7675176317a8ab34efd982137ef30',1987,'TD','Chad','communications',150,'400 km
See regional map VII
Railroads: none
Highways: 31,322 km total; 32 km
bituminous, 7,300 km gravel and laterite,
remainder unimproved
Inland waterways: about 2,000 km navi-
gable
Civi) air: 2 major transport aircraft
Airfields: 82 total, 7] usable; 5 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 26 with runways
1,220-2,489 m
Telecommunications: fair system of
radiocommunication stations for intercity
links; 5,000 telephones (0.1 per 100 popl.);
1 FM, 3 AM stations; many facilities,
including satellite ground station, inopera-
tive
Defense Forces
Branches: Army, Air Force, paramilitary
Gendarmerie, Presidential Guard
Military manpower: males 15-49,
1,087,000; 565,000 fit for military service;
47,000 reach military age (20) annually
Military budget: for fiscal year ending 3]
December 1986, $27.1 million; about 35%
of total budget','7f9d71ccbbdfd6155d88809a2102c2bd395aa6b8205e79382975aa94bf1f25fe','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b73c80b246592e0afc098bf6683a7ee6e4f8b7d8df27171e17319ce1a964c0c6',1987,'CL','Chile','communications',155,'1000 km
South
Pacific
Ocean
Easter and Sala y
Gomez islands are
not shown,
a
Punta Arenasg¢
Boundary representation is
See regional map 1v not necessarily authoritative
Railroads: 8,613 km total; 4,257 km 1.676-
meter gauge, 185 km 1.435-meter standard
gauge, 4,221 km 1.000-meter gauge; elec-
trification, 1,578 km 1.676-meter gauge, 76
km 1.000-meter gauge
Highways: 79,065 km total; 9,865 km
paved, 37,700 km gravel, 32,000 km
improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined
products, 785 km; natural gas, 320 km
Ports: 10 major, 13 minor
Civil air: 22 major transport aircraft
Airfields: 893 total, 856 usable; 47 with
permanent-surface runways; 13 with
runways 2,440-3,659 m, 52 with runways
1,220-2,439 m
Telecommunications: modern telephone
system based on extensive radio-relay
facilities; 629,000 telephones (5.4 per 100
popl.); 2 Atlantic Ocean satellite antennas;
8 domestic satellite stations; 154 AM, 119
TV, 14 shortwave stations
Defense Forces
Branches: Army of the Nation, National
Navy, Air Force of the Nation, Carabin-
eros of Chile
Military manpower: males 15-49,
8,321,000; 2,490,000 fit for military ser-
vice; 117,000 reach military age (19)
annually
50','43aa113ce146be4373d2c0e60c07b86a06e166ba7967d139f3aa2287496c64b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2dd6df9690ae2b01ee1453eef5505cd5368ab828a64ccaf67566d1484c40034',1987,'CN','China','communications',160,'(Taiwan entry on page 274)
1200 km
Boundary representation 1a
not necesaarily euthoritetive
Ururhai
een
a” clae
Chineall ry Lanzhou, Xen
tine of °
control
Lhasa e
“ Chengdu Wuhan Sea
Hainan
O20 ~ South China
See regional map VII! Sea
Railroads: total about 52,500 km common
carrier lines; 600 km 1.000-meter gange;
rest 1.435-meter standard gauge; all single
track except 9,500 km double track on
standard gauge lines; 4,200 km electrified;
10,000 km industrial lines (gauges range
from 0.762 to 1.067 meters)
Highways: about 930,000 km all types
roads; about 240,000 km unimproved
natural earth roads and tracks, 540,000 km
improved earth roads, 150,000 km paved
roads
Inland waterways: 138,600 km; about
109,300 km navigable
Pipelines: crude, 6,500 km; refined prod-
ucts, 1,100 km; natural gas, 4,200 km
Ports: 15 major, about 180 minor
Airfields: 325 total; 266 with permanent-
surface runways; 11 with runways 3,500 m
and over; 80 with runways 2,500 to 3,499
m; 208 with runways 1,200 to 2,499 m; 28
with runways less than 1,200 m; 2 sea-
China (continued)
plane stations; 4 heliports, 5 airfields under
construction
Telecommunications: domestic and inter-
national services exist primarily for official
purposes; unevenly distributed internal
system serves principal cities, industrial
centers, and most townships; services in
interior and border regions limited; nearly
4 million telephone exchange lines, includ-
ing 40,000 long-distance telephone ex-
change lines with direct, automatic service
to over 24 cities; 6.0 million telephones
(3-5 telephones per 100 popl. in large
cities, 1 telephone per 170 popl. national
average); 53,000 post and telegraph offices
with about 700 main telegraph centers
capable of general message service at the
county level and above; subscriber tele-
printer exchange (telex) services available
in 25 main metropolitan areas; unknown
number of facsimile and data transmission
points; domestic audio radiobroadcast
coverage provided by 122 main AM cen-
ters and about 525 transmitter relay sta-
tions; unknown number of FM radio and
wired rebroadcast stations with 215 million
receivers; 2 domestic telecommunications
satellites, 5 ground stations, over 2,000 TV
receiving stations; at least 202 TV centers;
over 400 local and network TV relay
transmitter stations; 7,000 supplementary
video recorder and redistribution facilities;
50 million monochrome and 10 million
color TV receiver sets (domestically pro-
duced); 2 major international switching
centers; satellite communications, long-
haul point-to-point radio circuits, regional
cable and wire landlines, directional radio-
relay, and seabed coaxial telephone cable
(damaged) permit linkage with most coun-
tries; direct voice and message communi-
cations with 46 countries and regions; TV
exchange to major cities on 5 continents
through INTELSAT Pacific and Indian
Ocean earth satellite; AM radio broadcasts
in 38 languages to 140 countries and
regions
Defense Forces
Branches: Chinese People’s Liberation
Army (CPLA), CPLA Navy (including
marines), CPLA Air Force
Military manpower: males 15-49,
810,258,000; 173,945,000 fit for military
service; 13,317,000 reach military age (18)
annually
Sea Sstons
Philippine
[4
’ Sea
? Okinawa
See regional map VIIl
Railroads: 21,387 km total (1982); 1,835
km 1.435-meter standard gauge, 19,552
km predominantly 1.067-meter narrow
gauge, 5,690 km double- and multitrack
sections, 8,830 km 1.067-meter narrow-
gauge electrified, 1,804 km 1.435-meter
standard gauge electrified
Highways: 1,113,388 km total (1980);
510,904 km paved, 602,484 km gravel,
crushed stone, or unpaved; 2,579 km
national expressways, 40,212 km national
highways, 43,907 km principal local roads,
86,930 km prefectural roads, 939,760 km
municipal roads
Inland waterways: about 1,770 km; sea
going craft ply all coastal inland seas
Japan (continued)
Pipelines: crude oil, 84 km; refined prod-
ucts, 322 km; natural gas, 1,800 km
Ports: 17 Japanese Port Association specifi-
cally designated major ports, 110 other
major ports, over 2,000 minor ports
Civil air: 265 major transport aircraft
Airfields: 180 total, 160 usable; 127 with
permanent-surface runways; 2 with run-
ways over 3,659 m; 25 with runways
2,440-3,659 m, 50 with runways
1,220-2,4389 m
Telecommunications: excellent domestic
and international service; 64.0 million
telephones (53.0 per 100 popl.); 318 AM
stations, 58 FM stations plus 486 relay
stations; about 12,350 TV stations (196
major—1 kw or greater), and 2 satellite
ground stations; submarine cables to US
(via Guam), Philippines, China, and USSR
Defense Forces
Branches: Japan Ground Self-Defense
Force (army), Japan Maritime Self-Defense
Force (navy), Japan Air Self-Defense Force
(air force), Maritime Safety Agency (coast
guard)
Military manpower: males 15-49,
31,610,000; 27,225,000 fit for military
service; 1,010,000 reach military age (18)
annually
Military budget: actual for fiscal year
ending 31 March 1988, $21.7 billion; 6.4%
of total budget
Railroads: 642 km 1.000-meter gauge
Highways: about 15,700 km total; 1,670
km bituminous, 3,670 km gravel and
improved earth, 10,360 km unimproved
earth
Inland waterways: 1,815 km navigable
Civil air: 5 major transport aircraft
Airfields: 38 total, 30 usable; 8 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m, 8 with runways
1,220-2,489 m
Telecommunications: domestic system
poor and provides only minimal service;
radio-relay, wire, and radio communica-
tions stations in use; expansion of radio-
relay in progress; 9,500 telephones (0.1 per
100 popl.); 2 AM, 2 FM, 2 TV stations; 1
Atlantic and 1 Indian Ocean satellite
ground stations
Defense Forces
Branches: Army, Air Force; paramilitary,
Gendarmerie, Republican Guard, National
Guard
Military manpower: males 15-49,
1,416,000; 798,000 fit for military service;
no conscription
Military budget: for fiscal year ending 31
December 1985, $26.7 million; about
21.9% of central government budget
155','e84292ceba7122a0ac4576992a13d9e85ad5318cedcfe7c18def5c8d93834586','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d773579ee5d9ec8f403dc0a32eb633399b65e2e8d540fa4270c17e76c125fce',1987,'CX','Christmas Island','communications',165,'5km Indian Ocean
THE SETTLEMENT
Indian Ocean
See regional map 1X
Railroads: none
Ports: Flying Fish Cove
Airfields: 1 usable with permanent-surface
runway ],220-2,4389
Telecommunications: 4,000 radio receiv-
ers (1982)
Defense Forces
Defense is the responsibility of Australia','228e933170b92b2e3dc265b26295676638aa5f6512962eacb15a1874f146d98b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d32540d047589bdeeb5818cdb899c719974662acb7005ba0383041991ac8fbd4',1987,'CO','Colombia','communications',170,'Caribbean
,Medeltin
Puerto
North 4 Carreno
Pacific Minizalés * oo
Ocean
°
ati
San Felipe
Providencia, Malpelo, and
San Andrés islands are
not shown.
See regional map 11] and 1V Leticia
Railroads: 3,568 km, all 0.914-meter
gauge, single track
Highways: 75,450 km total; 9,350 km
paved, 66,100 km earth and gravel sur-
faces
Inland waterways: 14,300 km, navigable
by river boats
Pipelines: crude oil, 3,585 km; refined
products, 1,350 km; natural gas, 830 km;
natural gas liquids, 125 km
Ports: 6 major (Barranquilla, Buenaven-
tura, Cartagena, San Andrés, Santa Marta,
Tumaco)
Civil air: 106 major transport aircraft
Airfields: 636 total, 620 usable; 65 with
permanent-surface runways; 1 with run-
ways over 3,659 m; 10 with runways
2,440-3,659 m, 96 with runways
1,220-2,439 m
Telecommunications: nationwide radio-
relay system; 1 Atlantic Ocean satellite
station with 2 antennas and 1] domestic
satellite stations; 1.89 million telephones
(6.5 per 100 popl.); 404 AM, 85 TV
stations
Defense Forces
Branches: Army (Ejercito Nacional), Air
Force (Fuerza Aerea de Colombia), Navy
(Armada Nacional)
Military manpower: males 15-49,
8,049,000; 5,483,000 fit for military ser-
vice; 364,000 reach military age (18)
annually
Military budget: for fiscal year ending
1987, $340.3 million; 7% of the central
government budget
54','4be9a584b267f42b020b12c25b74f6e6bc1991f031b9ba1a6699990425e38659','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ae9ece691a858328f87f1035f8ae8fffe6f0d00f8111dcfb8f9b4c1ed60643e',1987,'KM','Comoros','communications',175,'§0 km
Indian Ocean
MORONI
Niazidja
Mutsamud: Nzwani
Fomboni Domoni
Mwali -.-
°
Railroads: none
Highways: 85 km tarred
Inland waterways: none
Ports: none
Airfields: 1 total, 1 permanent-surface
runway; 1,220-2,439 m
Telecommunications: small system ad-
ministered by French Department of Posts
and Telecommunications; includes radio-
relay and high-frequency radio communi-
cations for links with Comoros and for
international communications; 450 tele-
phones (1 per 100 popl.); 1 AM station
Defense Forces
Defense is the responsibility of France','e424d8fc57455a58158357bc764c201dd8f61fc9a460095b0da37949bf10eda6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf006389104631ba3a999db377c08f80adf5a646e4de5ae2ea7a2c8e9f7b7ac',1987,'YT','Mayotte','communications',176,'. Ay
Mozambique Administered by France.
claimed by Comoros
Channel
See regional map V11
Railroads: none
Highways: 1,110 km total; about 400 km
bituminous, remainder crushed stone or
gravel
Ports: ) major (Mutsamudu); 2 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, 4 usable; 4 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: sparse system of
radio-relay and high frequency radio
communication stations for interisland and
external communications to Madagascar
and Reunion; 1,800 telephones (0.4 per
100 popl.); 2 AM stations, 1 FM station, no
TV stations
Defense Forces
Branches: Army, Presidential Guard,
Gendarmerie
Military manpower: males 15-49, 86,000;
51,000 fit for military service
Military budget: for fiscal year ending 31
December 1981, $2.9 million; about 16%
of the central government budget
55
Hire M‘Zembourou 10km
Administered by France,
claimed by Comoros
lte
Pamanzi
See regional map VII! Mozembique Chennel','14f1fab7eac3d14b7f4e9b676d5d8abe3863bab6b87a83f16b3aae312f847471','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c2f3978a2203f26a4eaa9505448e93b5272867468cdfcc08932d41e78aae42',1987,'CG','Congo','communications',181,'200 km
Loubomo BRAZZAVILLE
Gulf of :
Guinea Pointe- Boundary representaton is
Noirs not necessarily authoritative
See regional map V11
Railroads: 727 km, 1.067-meter gauge,
single track
Highways: 11,970 km total; 555 km bitu-
minous surface treated; 848 km gravel,
laterite, 5,347 km improved earth, and
5,220 km unimproved roads
Inland waterways: the Congo and Ubangi
Rivers provide 1,120 km of commercially
navigable water transport; the remainder
of the inland waterways are used for loca!
traffic only
Pipelines: crude oil 25 km
Ports: 1 major (Pointe-Noire)
Civil air: 5 major transport aircraft
Airfields: 55 total, 51 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 21 with runways
1,220-2,439 m
Telecommunications: services adequate
for government use; primary network is
composed of radio-relay routes and coaxial
cables; key centers are Brazzaville, Pointe-
Noire, and Loubomo; 18,100 telephones
(1.1 per 100 popl.); 3 AM, 1 FM, 4 TV
stations; 1 Atlantic Ocean satellite station
Defense Forces
Branches: Army, Navy, Air Force, para-
military National People’s Militia
Military manpower: males 15-49, 426,000;
215,000 fit for military service; about
20,000 reach military age (20) annually
Cook Islands¢','f06e11ad12aae00650262fbaddf0db998af64f69cf644b2fd485890e0fd9986b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a9befcd3db6ad799ee42a58899c8a52c90c425f917792c5f844b1678ea90850',1987,'CK','Cook Islands','communications',186,'Rakshenge, Panrhyn
Lee, “Menihiki
“Nassau
Island
.
Suwerraw
South Pacific Ocean
Palmerston,
Aitutaki Mantes
. -Mitiara
“‘Meuks
+-xAVARUA
Tekutae
400 km .
Rerotonga
See regional map X Mangeia
Railroads: none
Highways: 187 km total (1980); 35 km
paved, 35 km gravel, 84 km improved
earth, 33 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 7 total, 5 usable; 1 with
permanent-surface runways; 2 with run-
ways 1,220-2,439 m
Telecommunications: 2 AM, no FM, no
TV stations; 10,000 radio receivers; 2,052
telephones; 1 satellite station','2e1c7feb804fbe05b6174371e28b1aed53f1b9de7c74ffa7f0c52e2e5d8051c3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e76d970245b606d28dcc3bcbfcd42e5cef87decff9dc9c537ff4f3700204e959',1987,'CR','Costa Rica','communications',191,'—100 km
Cabo Gracias
2 Dios,
Caribbean
Sea
North Pacific Ocaan
tsla dat Coco
ta not shown,
See regional map Ill
Railroads: 800 km total, all 1.067-meter
gauge; 243 km electrified
Highways: 15,400 km total; 7,030 km
paved, 7,010 km gravel, 1,360 km unim-
proved earth
Inland waterways: about 730 km, season-
ally navigable
Pipelines: refined products, 95 km
Ports: 1 major (Puerto Limon), 4 second-
ary (Caldera, Golfito, Moin, Puntarenas)
Civil air: 9 major transport aircraft
Airfields: 199 total, 188 usable; 27 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m; 9 with runways
1,220-2,489 m
Telecommunications: very good domestic
telephone service; 292,000 telephones (11.8
per 100 popl.); connection into Central
American microwave net; 62 AM, 17 TV
stations; 1] Atlantic Ocean satellite station
Defense Forces
Branches: Civil Guard, Rural Assistance
Guard
Military manpower: males 15-49, 741,000;
502,000 fit for military service; 29,000
reach military age (18) annually
Military budget: for fiscal year ending 31
December 1986, $19.6 million for Ministry
of Public Security, including the Civil
Guard; about 2.8% of total central govern-
ment budget; $8.0 million for Rural
Guard; 1.1% of total central government
budget
59','a0fee38565bb522497f201163036f07ab0fb38f95c2607f27045f60bb99bc335','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4369a04fcc15c407c9ebd96c8e703662f41d3b763be1e00f9e11847e313153e8',1987,'CU','Cuba','communications',196,'Straits
of Florida
North Atlantic
Isla de la
Juventud
5 Santiago U.S.
Caribbaan Sea de Cuba ted
Se
See regional map Ill
Railroads: 14,925 km total; Cuban Na-
tional Railways operates 5,295 km of
].485-meter gauge track; 199 km electri-
fied; 9,630 km of sugar plantation lines of
0.914-1.485-meter gauge
Highways: about 21,000 km total; 9,000
km paved, 12,000 km gravel and earth
surfaced
60
Inland waterways: 240 km
Ports: 10 major, 26 secondary, 34 minor
Civil air: 59 major transport aircraft
Airfields: 202 total, 186 usable; 66 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 13 with runways
2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: 143 AM, 5 FM, 52
TV stations; 1,525,000 TV sets; 2,140,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: Revolutionary Armed Forces,
Ground Forces, Revolutionary Navy, Air
and Air Defense Force, Ministry of Inte-
rior Special Troops, Border Guard Troops,
Territorial Militia Troops, Youth Labor
Army
Military manpower: eligible 15-49,
5,765,000; of the 2,893,000 males 15-49,
1,819,000 are fit for military service; of
the 2,871,000 females 15-49, 1,802,000 are
fit for military service; 112,000 males and
108,000 females reach military age (17)
annually','16acaf45738b4020ff709ddedce94d976c4c9bfe271cd57aae9eb0a6981bb6a3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0867e219f3ca5f8e2f0ef896d7169957c0c3a15c8938af81fc053e71b465181',1987,'CY','Cyprus','communications',201,'50 km
Mediterranean Sea
Rizokarpas:
Famagusta
Area controled by Cyprus
Government {Greek area}
Larnaca
Vasilikos
Limassol
Mediterranean Sea
See regional map V1
Railroads: none
Highways: 10,780 km total; 5,170 km
bituminous surface treated; 5,610 km
gravel, crushed stone, and earth
Ports: 8 major (Famagusta, Larnaca,
Limassol), 2 secondary (Vasilikos, Kyrenia),
11 minor; Famagusta and Kyrenia under
Turkish-Cypriot control
Civil air: 8 major transport aircraft
Airfields: 15 total, 14 usable; 12 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m; 2 with runways
1,220-2,4389 m
Telecommunications: moderately good
telecommunication systems in both Greek
and Turkish sectors; 185,000 telephones
(25 per 100 popl.); 10 AM, 14 FM, 29 TV
stations; tropospheric scatter circuits to
Greece and Turkey; 3 submarine coaxial
cables; 1 Atlantic Ocean satellite antenna
and 1 Indian Ocean antenna
Defense Forces
Branches: Cyprus National Guard; Turk-
ish sector—Turkish Cypriot Security Force
Military manpower: males 15-49, 176,000;
122,000 fit for military service; about
5,000 reach military age (18) annually
Military budget: for fiscal year ending 31
December 1984, $60 million; 11.6% of
central government budget
62
Czechoslovakia
See regional map V
Railroads: 13,114 km total; 12,866 km
1.435-meter standard gauge, 102 km
1.524-meter broad gauge, 146 km 0.750-
and 0.760-meter narrow gauge; 2,868 km
double track; 3,307 km electrified; govern-
ment owned (1984)
Highways: 74,891 km total; including 450
km superhighway (1984)
Inland waterways: 475 km (1984)
Pipelines: crude oil, 1,448 km; refined
products, 1,500 km; natural gas, 8,000 km
Freight carried: rail—298.8 million metric
tons, 74 billion metric tons/km; highway—
1,258 million metric tons, 20.90 billion
metric tons/km; waterway—13.40 million
metric tons, 4.4 billion metric tons/km
(excluding international transit traffic)
(1984)
Ports: no maritime ports; outlets are
Gdynia, Gdarisk, and Szczecin in Poland;
Rijeka and Koper in Yugoslavia; Hamburg,
FRG; Rostock, GDR; principal river ports
are Prague, Dééin, Komarno, Bratislava
Civil air: 40 major transport aircraft
Airfields: 135 total; 18 with runways 2,500
m or longer
Telecommunications: 54 AM, 14 FM, 45
TV stations; 11 Soviet TV relays; 4,360,000
TV sets; 4,208,538 receiver sets; at least 1
satellite ground station
Defense Forces
Branches: Czechoslovak People’s Army,
Frontier Guard, Air and Air Defense
Forces
Military manpower: males 15-49,
8,867,000; 2,969,000 ft for military ser-
vice; 121,000 reach military age (18)
annually
Military budget: announced for fiscal year
ending 31 December 1986, 28.3 billion
koronas, 7.5% of total budget
Czechoslovakia','570a5882c5ba3b207365f67647cdde8adc9a19c57e6db3e7ea419063afc42a8b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('778b42bd73bcbd77a2222d57255fa01d9092a78b887176d043b70dd3826e110b',1987,'DK','Denmark','communications',206,'Skagerrak 120 km
F
Skagen Seale wa ceearee
e entries.
Kattegat
3 .
COPENHAGEN
Sjacitand
e
Gente Gomrhislri
Meén
1a Baltic
Lollan Falster Sea
See regional map V
Railroads: 2,770 km 1.435-meter standard
gauge; Danish State Railways (DSB) oper-
ate 2,120 km (1,999 km rail line and 121
km rail ferry services); 97 km electrified,
730 km double tracked; 650 km of
standard-gauge lines are privately owned
and operated
Highways: 66,482 km total; 64,551 km
concrete, bitumen, or stone block; 1,931
km gravel, crushed stone, improved earth
Inland waterways: 417 km
Pipelines: crude oil, 110 km; refined
products, 508 km; natural gas, 640 km
Ports: 4 major, 15 secondary, 41 minor
Civil air: 58 major transport aircraft
Airfields: 182 total, 117 usable; 25 with
permanent-surface runways; 9 with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: excellent telephone,
telegraph, and broadcast services; 4.0
million telephones (78.3 per 100 popl.); 2
AM, 46 FM, 85 TV stations; 13 submarine
coaxial cables; 7 satellite earth stations for
domestic service
Defense Forces
Branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force
Military manpower; males 15-49,
1,351,000; 1,173,000 fit for military ser-
vice; 38,000 reach military age (20) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $1.7 billion; 7.3% of
central government budget
65','557296d41f6bcfce504ddfd595caaf8068128b45530a0d6787cb7a1ab61e9d91','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('577e7ea8c931949c921dface5fd5a6851edae8ea616fd6b58be97fc1e19f4fa1',1987,'DJ','Djibouti','communications',211,'tae Asai(y
See regional map VII
Railroads: the Ethiopian-Djibouti railroad
extends for 97 km through Djibouti
Highways: 2,800 km total; 279 km bitumi-
nous surface, 229 km improved earth,
2,292 km unimproved earth
Ports: 1 major (Djibouti)
Civil air: 1 major transport aircraft
Airfields: 12 total, 10 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-8,659 m, 4 with runways
1,220-2,439 m
Telecommunications: fair system of urban
facilities in Djibouti and radio-relay sta-
tions at outlying places; 7,800 telephones
(2.4 per 100 popl.); 2 AM, 1 FM, 2 TV
stations; 1 Indian Ocean satellite ground
station, 1 ARABSAT station, 1 submarine
cable to Saudi Arabia
Defense Forces
Branches: Army, Navy, Air Force; para-
military National Security Force
Military manpower: males 15-49, about
84,000; about 49,000 fit for military ser-
vice
Military budget: for fiscal year ending 31
December 1986, $29.9 million; 23% of
central government budget
66
Defense Forces
Branches: Saudi Arabian Land Forces,
Royal Saudi Naval Forces, Royal Saudi Air
Force, Royal Saudi Air Defense Force,
Saudi Arabian National Guard, Coast
Guard and Frontier Forces, Special Secu-
rity Force, Public Security Force, Special
Emergency Force
Military manpower: males 15-49,
5,688,000; 3,209,000 fit for military ser-
vice; 154,000 reach military age (18)
annually','f705bde09f200264630caee53e6f6b076c10d3e39a5d252e3ca8ee6caaecd9f9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c196d684f36b5154adfbfb66773b1a9312dff254afa8734e7b2af495c0696e05',1987,'DM','Dominica','communications',216,'10 km
Caribbean Caribbean
See See
See regional map Ul
Railroads: none
Highways: 750 km total; 370 km paved,
880 km gravel and earth
Ports: 1 major (Roseau), 1 minor (Port-
smouth)
Civil air: unknown number of major
transport aircraft
Airfields; 2 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 1,220-2,439 m
Telecommunications: 4,600 telephones in
fully automatic network (5.6 per 100
popl.); VHF and UHF link to St. Lucia;
new SHF links to Martinique and Guad-
eloupe; 3 AM, 1 FM, 1 cable TV stations
Defense Forces
Branches: Commonwealth of Dominica
Police Force
Military budget: for fiscal year 1986, $2.9
million; 4.6% of the central government
budget
67','52e496e9b14f61d5efcc1c346bcaf7706f2b3371e723a6283b3fb8e9bf6b2ce5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4d792d10b57b20ab6d146f005a910094a29355acac8be8ee5a12921eaf12a31',1987,'DO','Dominican Republic','communications',221,'100 km
North Atlantic Ocean
Bahia da Samana
Higuey,
San Padro*
da Macoria
Caribbean Sea
See regional map lll
Railroads: 1,655 km total in numerous
segments; 4 different gauges from .558 m
to 1.435 m
Highways: 12,000 km total; 5,800 km
paved, 5,600 km gravel and improved
earth, 600 km unimproved
Pipelines: crude oil, 96 km; refined prod-
ucts, 8 km
Ports: 4 major (Santo Domingo, Haina, San
Pedro de Macoris, Puerto Plata), 17 minor
Civil air: 14 major transport aircraft
Airfields: 46 total, 34 usable; 14 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 9 with runways
1,220-2,4389 m
Telecommunications: relatively efficient
domestic system based on islandwide
radio-relay network; 190,000 telephones (3
per 100 popl.); 123 AM, 18 TV stations; I
coaxial submarine cable; 1 Atlantic Ocean
satellite station
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
1,782,000; 1,129,000 fit for military
service; 84,000 reach military age (18)
annually','593c41a9b5dd484af4be3f43953d317d447dbfcd8c14e703cb95794b77404def','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53e47c30242bebcecf35335b85fda5e95e6a744f1495fdd40626bcd29d9edbb3',1987,'EC','Ecuador','communications',226,'Boundary representation is
not neceasarily authortlative
Pecific
Ocean
istends not shown in tree
geogrephicel position.
Golfo f£
le
Guayaquil
See regional map1V Galapagos Islands
Railroads: 965 km total; all 1.067-meter
gauge single track
Highways: 28,000 km total; 3,600 km
paved, 17,400 km gravel and improved
earth, 7,000 km unimproved earth
Inland waterways: 1,500 km
Pipelines: crude oil, 800 km; refined
products, 1,358 km
Ports: 4 major (Guayaquil, Manta, Puerto
Bolivar, Esmeraldas), 6 minor
Civil air: 44 major transport aircraft
Airfields: 176 total, 174 usable; 32 with
permanent-surface runways; | with run-
ways over 3,659 m, 6 with runways
2,440-3,659 m, 2] with runways
1,220-2,439 m
Telecommunications: domestic facilities
generally adequate; 1 Atlantic Ocean
satellite station; 318,000 telephones (3.9
per 100 popl.); 285 AM, 24 TV stations
Defense Forces
Branches: Ecuadorean Army (Ejercito
Ecuatoriano), Ecuadorean Air Force
(Fuerza Aerea Ecuatoriana), Ecuadorean
Navy (Armada Ecuatoriana)
Military manpower: males 15-49,
2,399,000; 1,628,000 fit for military ser-
vice; 108,000 reach military age (20)
annually
Military budget: estimated for fiscal year
ending 31 December 1986, $242 million;
about 10.9% of the central government
budget
70','b639c4454fdcd2e4ef4438efaa4aa899ab09f60ca5eddf261935f48c7f91a50a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e4e4de3e082838d8753760985f3c276d0bab7c13c044ae3295dc52649fafd6',1987,'EG','Egypt','communications',231,'Mediterranean 200 km
Boundary representation is
not necessarily authoritative
See regional map V1 and Vil
Railroads: 602 km 0.914-meter gauge,
single track
Highways: 10,000 km total; 1,500 km
paved, 4,100 km gravel, 4,400 km im-
proved and unimproved earth
Inland waterways: Rio Lempa partially
navigable
Ports: 2 major (Acajutla, La Unién), 1
minor
Civil air: 7 major transport aircraft
Airfields: 161] total, 135 usable; 6 with
permanent-surface runways; ] with run-
ways 2,440-3,659 m; 6 with runways
1,220-2,439 m
Telecommunications: nationwide trunk
radio-relay system; connection into Central
American microwave net; 116,000 tele-
phones (2.3 per 100 popl.); 77 AM, 2
shortwave, 5 TV stations; 1 Atlantic Ocean
satellite station
Defense Forces
Branches: Army, Navy, Air Force, Na-
tional Guard, National Police, Treasury
Police
Military manpower: males 15-49,
1,223,000; 780,000 fit for military service;
63,000 reach military age (18) annually
Military budget: estimated for fiscal year
ending 31 December 1986, $166.8 million;
about 24.6% of the central government
budget
E] Salvador','58a4a7edb52a9115f0ad1552cbbd92ab59d6bae6f1e474522d5844ce00fed86d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cead8e63f4ef583aa478ff8002bd87e646a67eff7fd51ba19f4a453cdf334fa',1987,'GQ','Equatorial Guinea','communications',236,'ALABO —ikn
Bioko
Gulf of Guinea
Bate
RIO MUNI
‘sland not
shown in true
geographical
position,
—
¢
Annobon Acalayong
See regional map VII','12f9a9312300fdc135914e242677b3e043b814e6aaf6b020fe0321bbcbecf4f7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('443f2b3735daa6ccc432e500f68d48294d640c19a2a0a73c235cc05c951aa88a',1987,'GN','Guinea','communications',241,'Railroads: none
Highways: Rio Muni—2,460 km, includ-
ing 185 km bituminous, remainder gravel
and earth; Bioko—300 km, including 146
km bituminous, remainder gravel and
earth
Inland waterways: no significant water-
ways
Ports: 1 major (Malabo), 3 minor
Civil air: 1 major transport aircraft
Airfields: 3 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,489 m
Telecommunications: poor system with
adequate government services; interna-
tional communications from Bata and
Malabo to African and European coun-
tries; 2,000 telephones (0.6 per 100 popl.);
2 AM, no FM, and 1 TV stations
Defense Forces ,
Branches: Army, Navy, and possibly Air
Force
Military manpower: males 15-49, 72,000;
36,000 fit for military service
Military budget: for fiscal year ending 31
March 1981, $6.2 million; 21% of central
government budget
200 km
Siguiri,
Kankan
e
CONAKRY®*
North
Atlantic
Ocean
Macents
Nzérékore |
See regional map VII
Railroads: 1,045 km; 806 km 1.000-meter
gauge, 239 km 1.435-meter standard gauge
Highways: 30,100 km total; 1,087 km
paved, 13,013 km gravel or laterite, 16,000
km unimproved earth
}
Inland waterways: 1,295 km navigable by
shallow-draft native craft
Ports: I major (Conakry), 2 minor
Civil air; 12 major transport aircraft
Airfields: 17 total, 17 usable; 5 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 9 with runways
1,220-2,489 m
Telecommunications: fair system of
open-wire lines, small radiocommunication
stations, and new radio-relay system;
10,000 telephones (0.2 per 100 popl.); 3
AM, I FM, and I TV stations; 7,700 TV
sets; 100,000 receiver sets; 1 Atlantic
Ocean satellite ground station
Defense Forces
Branches: Army (ground forces), Navy
(acts primarily as a coast guard), Air Force,
paramilitary National Gendaramerie
Military manpower: males 15-49,
1,549,000; 781,000 fit for military service
Indian Ocean
See regional map 1X
Railroads: 6,964 km total; 6,389 km 1.067-
meter gauge, 497 km 0.750-meter gauge,
78 km 0.600-meter gauge; 211 km double
track; 101 km electrified; government
owned
Highways: 119,500 km total
Inland waterways: 21,579 km; Sumatra
5,471 km, Java and Madura 820 km,
Kalimantan portion of Borneo 10,460 km,
Celebes 241 km, and Irian Jaya 4,587 km
Pipelines: crude oil, 2,450 km; refined
products, 456 km; natural gas, 450 km
Ports: 15 ocean ports
Civil air: about 150 major transport air-
craft
Airfields: 436 total, 414 usable; 100 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 12 with runways
2,440-3,659 m, 66 with runways
1,220-2,439 m
115
Telecommunications: interisland micro-
wave system and HF police net; domestic
service fair, international service good;
radiobroadcast coverage good; 741,330
(est.) telephones (0.4 per 100 popl.); 618
AM, 38 FM, 9 TV stations; 210 TV relays;
] international satellite ground station (1
Indian Ocean antenna and 1 Pacific Ocean
antenna), and a domestic satellite commu-
nications system
Defense Forces
Branches: Army, Navy, Air Force, Na-
tional Police
Military manpower: males 15-49,
45,740,000; 26,518,000 fit for military
service; 2,706,000 reach military age (18)
annually
Iran
Strait of
Hormuz
Bandar
Guilt Behashti
of
See regional map VI Oman
Railroads: 4,601 km total; 4,509 km 1.432-
meter gauge, 92 km 1.676-meter gauge
Highways: 85,000 km total; 36,000 km
gravel and crushed stone, 15,000 km
improved earth, 19,000 km bituminous
and bituminous-treated surfaces, 15,000
km unimproved earth
Inland waterways: 904 km, excluding the
Caspian Sea, 104 km on the Shatt al Arab
(closed since September 1980 because of
Iran-Iraq conflict); 3 inland coastal ports
on Caspian Sea
Pipelines: crude oil, 5,900 km; refined
products, 3,900 km; natural gas, 3,300 km;
some pumping stations have been dam-
aged by Iraqi air attacks
Ports: 6 major (Abadan and Khorramshahr
are closed, Bandar-e ‘Abbas, Bandar-e
Khomeyni, Chah Bahar, Bishehr), 12
minor
Civil air; 43 major transport aircraft
Airfields: 17) total, 144 usable; 78 with
permanent-surface runways; 16 with
runways over 3,659 m, 15 with runways
2,440-3,659 m, 66 with runways
1,220-2,439 m
Telecommunications: 62 AM, 27 FM, 28
TV stations; 2,048,000 TV sets; 5,500,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: Islamic Ground Forces, Navy,
Air Force, and Revolutionary Guard
(includes Basij militia), Gendarmerie
Military manpower: males 15-49,
11,490,000; 6,848,000 fit for military
service; about 540,000 reach military age
(21) annually
117
Uhéu das Cabraa
o pe -
Neves SAO TOME
thew Santa Cruz
Gago Coutinho ¥
See regional map V11','6a22f2d4d22c88667ad2d62d9cdc15611f7e3d665f18a2af433004d2caa0fc6e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3704af09ced87889a030a8198b3cfb6385d644b6b61d73c56ca83d6151ce9005',1987,'ET','Ethiopia','communications',242,'400 km
+ Red Sea
Mits''iway
i A Boundary representation is
Asmara
not necessarily authoritalive
Aseb
Gonder
Ci tane Hayk
Djré Dawa,
ADDIS ,
AGABA
Jima + . Awase
See regional map VII
Railroads: 1,089 km total; 782 km 1.000-
meter gauge, of which 97 km are in
Djibouti; 307 km 0.950-meter gauge
Highways: 44,300 km total; 3,888 km
bituminous, 8,344 km gravel, 2,456 km
improved earth, 29,612 km unimproved
earth
Ports: 2 major (Aseb, Mits’iwa)
Civil air: 22 major transport aircraft
Airfields: 171 total, 186 usable; 8 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 10 with runways
2,440-3,659 m, 50 with runways
1,220-2,489 m
Telecommunications: 4 AM, 0 FM, and 1]
TV stations; 40,000 TV sets; 2,000,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: Army, Navy, Air Force, Air
Defense; paramilitary Emergency Strike
Force Police
Military manpower: males 15-49,
10,351,000; 5,846,000 fit for military
service; 500,000 reach military age (18)
annually
Military budget: for fiscal year ending 7
July 1986, $433.2 million; 20.4% of central
government budget
Falkland Islands
(Islas Malvinas)
South Sandwich Islands,
South Georgia. Shag. and $9 km
Clerke Rocks are not shown
wa South Atlantic Ocean
Falkland @ East Falkland
-
Administered by U.K.
claimad by Argentine
Scotie Sea
See regional map 1V
Railroads: none
Highways: 510 km total; 30 km paved, 80
km gravel, and 400 km unimproved earth
Ports: | major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable, 1 with
permanent-surface runways; | with run-
ways 2,440-8,659 m
Telecommunications: government-
operated radiotelephone networks provid-
ing effective service to almost all points on
both islands; about 590 telephones (24.2
per 100 popl.); | AM, 1 FM, and 1 Atlan-
tic satellite stations
Defense Forces
Defense is the responsibility of the United
Kingdom
4 Inter-American Development Bank » Islamic Development Bank © Not a member of UN
282
United Nations Organizations
OAU OECD OIC OPEC SELA WFTU FAO GATT IAEA IBRD ICAO IC] IDA IFAD IFC ILO IMF IMO ITU. UNESCO UPU WIIO WMO
4 Ceased to participate in 1961 ¢ Suspended € Excluded since 1962
283
Country International Organizations
ADB ARAB ASEAN CACM CARICOM CEMA EC G-77 GCC 1DB4 iDBe INTELSAT LAIA
LEAGUE
Zz
AM NATO','1e2965f0b57ce1f07e463529ed9980ec38262ab6bd4a75896619295c1c4a7616','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e258b44a9095406592709fb57ff6bda88c79d043a5d38ba490b3c6b1c5bf4839',1987,'FO','Faroe Islands','communications',247,'25 km ©
Sseinoy
Straymoy|
Bordhoy
Mykines ee
vége? TORSHAVN
x 4
Norwegien
WW See
Sandoy
North Skdvoy®
Atlantic ry
Ocean -
Sudhuroy
See regional map V
Railroads: none
Highways: 200 km
Ports: 2 major, 8 minor
Airfields: I total, I usable with
permanent-surface runways I,220-2,439 m
Telecommunications: good international
communications; fair domestic facilities;
27,900 telephones (61.0 per 100 popl.); I
AM, 3 FM stations; 3 coaxial submarine
cables
Defense Forces
Defense is the responsibility of Denmark
Military manpower: included with Den-
mark
«* Rotums
South Pacific Ocean
Vanua Levu
a a
ne 2 Ee
oe Ge NM we
Viti Levu“ SUVA os
na
Kandevu
2 100 km
Cave-i-Ra
See regional map X
Railroads: 644 km 0.610-meter narrow
gauge, belonging to the government-owned
Fiji Sugar Corporation
Highways: 3,300 km total (1984)—390 km
paved; 1200 km bituminous surface treat-
ment; 1,290 km gravel, crushed stone, or
stabilized soil surface; 420 unimproved
earth
Inland waterways: 203 km; 122 km
navigable by motorized craft and 200-
metric-ton barges
Ports: 1 major, 6 minor
Civil air: 1 DC-8 and 1 light aircraft
Airfields; 27 total, 27 usable; 2 with
permanent-surface runways, 1 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,4389 m
Telecommunications: modern local,
interisland, and international (wire/radio
integrated) public and special-purpose
telephone, telegraph, and teleprinter
facilities; regional radio center; important
COMPAC cable link between US/Canada
and New Zealand/Australia; 49,540 tele-
phones (6.9 per 100 popl.); 7 AM, 1 FM ,
no TV stations; | satellite ground station
Defense Forces
Branches: integrated ground and naval
forces
Military manpower: males 15-49, 187,000;
104,000 fit for military service; 7,000
reach military age (18) annually
79','47861fbd37e3157ae081833ee8a8b5f7c206574fa6e8f83f0c534ae92173bffc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('558c42c99596f1ec0e53f746757b499c1692cb92c38e6c0a77c3f51d1988afd1',1987,'FI','Finland','communications',252,'Gulf of
Bothnia
Aland
Islands
ay
See regionatmap v HELSINKI
Railroads: 6,071 km total; Finnish State
Railways (VR) operate a total of 6,010 km
1.524-meter gauge, of which 480 km are
multiple track and 1,257 km are electrified
Highways: about 103,000 km total, includ-
ing 35,000 km paved (bituminous, con-
crete, bituminous-treated surface) and
$8,000 km unpaved (stabilized gravel,
gravel, earth); additional 30,000 km of
private (state subsidized) roads
Inland waterways: 6,675 km total (includ-
ing Saimaa Canal), 3,700 km suitable for
steamers
Pipelines: natural gas, 16) km
Ports: 1] major, 34 minor
Civil air; 39 major transport
Airfields: 163 total, 160 usable; 47 with
permanent-surface runways; 22 with
runways 2,440-3,659 m, 20 with runways
1,220-2,439 m
Telecommunications: good service from
cable and radio-relay network; 2.95 mil-
lion telephones (57 per 100 popl.); 6 AM,
105 FM, 235 TV stations; 3 submarine
cables
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
1,315,000; 1,102,000 fit for military ser-
vice; 31,000 reach military age (17)
annually
Military budget: fiscal year ending 31
December 1986, $1.08 billion; 5.7% of
central government budget','44106de7ca15e4d96a238e641670fd99839e2d5b1625e608b561124281692a1f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('431c4d6687505d8572a5d8425f8e6dcc28097d6ba409084dccf471fe3a54ca87',1987,'FR','France','communications',257,'English Channel
Biscay
Nice
Merseille
Corsica
Mediterranean
Sea
See regional map V
Railroads: French National Railways
(SNCF) operates 34,577 km 1.435-meter
standard gauge; 11,358 km electrified,
15,132 km double or multiple track; 2,138
km of various gauges (1.000-meter to
1.440-meter), privately owned and oper-
ated
Highways: 1,551,400 km total; 33,400 km
national highway; 347,000 km departmen-
tal highway; 421,000 km community
roads; 750,000 km rural roads; 5,401 km of
controlled-access divided autoroutes; about
803,000 km paved
Inland waterways: 14,932 km; 6,969 km
heavily traveled
Pipelines: crude oil, 3,059 km; refined
products, 4,487 km; natural gas, 24,746 km
Ports: 14 major, 12 secondary, 6 minor
Civil air: 355 major transport aircraft
(1982)
Airfields: 474 total, 461 usable; 258 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 34 with runways
2,440-3,659 m, 1382 with runways
1,220-2,439 m
Telecommunications: highly developed
system provides satisfactory telephone,
telegraph, radio and TV broadcast services;
85.0 million telephones (60 per 100 popl.);
41 AM, 797 FM, 8,500 TV stations (includ-
ing repeaters); 24 submarine coaxial cables;
8 communication satellite ground stations
with total of 11 antennas for international
service
Defense Forces
Branches: Army of the Ground, Navy,
Army of the Air, National Gendarmerie
Military manpower: males 15-49,
18,995,000; fit for military service
11,864,000; 441,000 reach military age (18)
annually
Military budget: proposed for fiscal year
ending 31 December 1986, $28.4 billion;
about 19.3% of proposed central govern-
ment budget
Railroads: 1.6 km 1.435-meter gauge
Highways: none; city streets
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield with
permanent-surface runways
Telecommunications: served by the
French communications system; automatic
telephone system with about 34,600 tele-
phones (123.6 per 100 popl.); 3 AM, 4 FM,
4 TV stations
Defense Forces
Defense is the responsibility of France
165
French Guiana‘','d5e21cc2e23552f130184b480a74b957aa51395907bf2f04547b4df54945f36d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a12894c5ec9d65ae4b619a884565051a7154fae6f60f08cfc73cca2e89f5c3d1',1987,'GF','French Guiana','communications',262,'Boundary representation is
See regional map Vv not necessarily authontatwe
Railroads: none
Highways: 680 km total; 510 km paved,
170 km improved and unimproved earth
Inland waterways: 460 km, navigable by
small oceangoing vessels and river and
coastal steamers; 3,300 km possibly naviga-
ble by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 11 total, 11 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: fair open-wire and
radio-relay system with about 18,100
telephones (27.2 per 100 popl.); 6 AM, 7
FM, 9 TV stations; 1 Atlantic Ocean
satellite station
Defense Forces
Defense is the responsibility of France
Military manpower: males 15-49, 21,000;
15,000 fit for military service (1986 est.)
84','b882ecaf366d32e14cf7482e0fc1385c236b53aaede43f30fa1d8ad05bea816d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb62e6c93cf319b186eec3e1ab5166f945433fb6cdc54aa5f7310cc220386349',1987,'PF','French Polynesia','communications',267,'me
les -o.
Marquises * »
South Pacific Ocean
a
free
ft; - thn oe -. Hes
ee ht, PAPEETE «2 °*- ~Tuamotu
Hles de - *¢, ke ne ¥
ahiti
la Société ae
ae iki
x > Bas
les», pe
Tubuai
500 km
Rapa
See regional map X','ec2bc3d3c95ba9708c8b50f79107b278ec78ecf4ccfa00f6193d579d03413794','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c59446c3325cc585bb8814d7aa8ec3dc3672644f08921cd464f64d8b0b6594b',1987,'GA','Gabon','communications',275,'Railroads: 970 km 1.437-meter standard
gauge under construction; 338 km are
completed
Highways: 7,393 km total; 300 km paved,
8,493 km gravel and improved, 3,600 km
unimproved
Inland waterways: about 1,600 km peren-
nially navigable
Pipelines: crude oil, 270 km; refined
products, 14 km
Ports: 2 major (Owendo and Port-Gentil),
3 minor
Civil air: 7 major transport aircraft
Airfields: 80 total, 74 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Telecommunications: adequate system of
open-wire, radio-relay, tropospheric scatter
links and radiocommunication stations;
13,800 telephones (1.4 per 100 popl.); 6
AM, 6 FM, 8 TV stations; 2 Atlantic
Ocean satellite stations
Defense Forces
Branches: Army, Navy, Air Force, para-
military Gendarmerie
Military manpower: males 15-49, 269,000;
134,000 fit for military service; 8,000
reach military age (20) annually
Military budget: for fiscal year ending 31
December 1984, $67.2 million; 4.9% of
central government budget
The Gambia
North
Atlantic
-Georgetown
° 5
Mansa Konka
Brikama
Boundary representation is
Not necessarily aulhoritative
See regional map VII
Gambia, The
German Democratic
Republic
Germany, Federal
Republic of','169ee04dde59e050d4fc73e8cab2b5b4902a6f89c736c591f11251f6b58e0eb5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd769f8576eae629b0525a5a418c993a4615de60db3368d253c8069cba7a46b9',1987,'SN','Senegal','communications',280,'Railroads: none
The Gambia (continued)
Highways: 3,083 km total; 431 km paved,
501 km gravel/laterite, and 2,151 km
unimproved earth
Inland waterways: 400 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 total, 1 usable with
permanent-surface runways 2,440-3,659 m
Telecommunications: adequate network
of radio-relay and wire; 3,500 telephones
(0.5 per 100 popl.); 2 FM, 3AM, 1 TV
stations; 1 Atlantic Ocean satellite station
Defense Forces
Branches: Army, paramilitary Gendar-
merie
Military manpower: males 15-49, 166,000;
83,000 fit for military service
Military budget: for fiscal year ending 30
June 1981, $2.4 million; 6.2% of central
government budget; includes fire and
police expenditures
German Democratic Republic
(East Germany)
Baltic See
> elsund
"Rostock
“Wismar
Schwerin
Tha final borders of
Germany heve not
bean established.
Wittenberge
Schwedt
Berlin, s
cd
Magdeburg Elsephuttenstadt
Cottbus,
Halle
‘4 deipzig
Erte presden?
See regional map V
Railroads: 14,226 km total; 18,941 km
1.485-meter standard gauge, 285 km
1.000-meter or other narrow gauge, 3,830
(est.) km 1.435-meter double track stan-
dard gauge; 2,321 km overhead electrified
(1984)
Highways: 120,314 km total; 47,261 km
concrete, asphalt, stone block, of which
1,913 km are autobahn and limited access
roads, 11,251 are trunk roads, and 34,097
are regional roads; 75,053 municipal roads
(1984)
Inland waterways: 2,319 km (1984)
Freight carried: rail—349 million metric
tons, 58.8 billion metric tons/km; high-
way—558 million metric tons, 14.0 billion
metric tons/km; waterway—16.2 million
metric tons, 2.84 billion metric tons/km
(excluding international transit traffic)
(1985)
Pipelines: oil, 1,301 km; refined products,
500 km; natural gas 2,000 km
Ports: 4 major (Rostock, Wismar, Stral-
sund, Sassnitz), 13 minor; principal inland
waterway ports are East Berlin, Riesa,
Magdeburg, and Eisenhiittenstadt
Civil air: 45 major transport aircraft
89
Airfields: 185 total; 48 with runways 2,500
m or longer
Telecommunications: 23 AM, 17 FM, 18
TV stations; 15 Soviet TV relays; 6,015,400
TV sets; 6,509,932 receiver sets; at least 1
satellite ground station
Defense Forces
Branches: National People’s Army, Border
Troops, Ministry of State Security Guard
Regiment, Air and Air Defense Command,
People’s Navy
Military manpower: males 15-49,
4,263,000; 3,419,000 fit for military ser-
vice; 108,000 reach military age (18)
annually
Military budget: announced for fiscal year
ending 31 December 1986, 14.0 billion
marks; 5.8% of total budget
Germany, Federal Republic of
(West Germany)
200 km € Kial
North Sea
Berlin
The finel borders of
Germeny hava not
been established
Stettgart
Munich
a freiburg
See regional map V
Railroads: 31,800 km total; 27,778 km
1.435-meter government owned, standard
gauge, 12,491 km double track; 11,896 km
electrified; 4,022 km nongovernment
owned; 3,598 km 1.435-meter standard
gauge; 214 km electrified, 424 km 1.000-
meter gauge; 186 km electrified
Highways: 466,305 km total; 169,568 km
classified, includes 6,485 km autobahn,
82,460 km national highways (Bundes-
strassen), 65,425 km state highways (Lan-
desstrassen), 65,248 km county roads
(Kreisstrassen); 296,737 km of unclassified
communal roads (Gemeindestrassen)
Inland waterways: 5,222 km, of which
almost 70% usable by craft of 990-metric
ton capacity or larger
Pipelines: crude oil, 2,343 km; refined
products, 3,389 km; natural gas, 95,414 km
Ports: 9 major, 8 secondary, 15 minor
Civil air: 194 major transport aircraft
Airfields: 479 total, 440 usable; 237 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 34 with runways
2,440-3,659 m, 42 with runways
1,220-2,489 m
Telecommunications: highly developed,
modern telecommunication service to all
parts of the country; fully adequate in all]
respects; 37.9 million telephones (62.1 per
100 popl.); 80 AM, 472 FM, and 6,200 TV
stations (including repeaters); 6 submarine
coaxial cables; 3 satellite stations with total
of 10 antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
16,251,000; 14,090,000 fit for military
service; 391,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1986, $27.1 billion; 22.98% of
the proposed central government budget
91
150km
North
Atlantic
Ocaan
Ziguinchor
Boundary representation 1s
not necessarily authoritative
“See regional map VII
Railroads: 1,084 km 1.000-meter gauge;
70 km double track
Highways: 13,898 km total; 3,461 km
paved, 6,741 km gravel or graded earth,
8,696 km of unimproved roads
Inland waterways: 1,505 km
Ports: ] major (Dakar), 2 minor
Civil air; 8 major transport aircraft
Airfields: 25 total, 21 usable; 10 with
permanent-surface runways; | with run-
ways 2,440-3,659 m, 16 with runways
1,220-2,439 m
Telecommunications: above-average
urban system, using radio-relay and cable;
40,200 telephones (0.6 per 100 popl.); 8
AM , no FM stations; 1 TV station; 3
submarine cables; 1 Atlantic Ocean satel-
lite station
Defense Forces
Branches: Army, Navy, Air Force, para-
military Gendarmerie
Military manpower; males 15-49,
1,498,000; 782,000 fit for military service;
80,000 reach military age (18) annually
216','775b4d6ee3b45587af4131aa0e916f480142a15982083eff73044a5ce8f220b0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c706fbb310e3cb4d6a002b28f8d1c7dd0626d355ff3e01f395a26a4915e93a83',1987,'GH','Ghana','communications',282,'150 km
Boilgatengs”
Gulf of Guinaa
See regional map VIl snoreg
Railroads: 953 km, all 1.067-meter gauge;
82 km double track; diesel locomotives
gradually replacing steam engines
Highways: 32,250 km total; 6,084 km
concrete or bituminous surface, 26,166 km
gravel, laterite, and improved earth
surfaces
92
Inland waterways: Volta, Ankobra, and
Tano rivers provide 168 km of perennial
navigation for launches and lighters; Lake
Volta reservoir provides 1,125 km of
arterial and feeder waterways
Pipelines: 8 km (refined products)
Ports: 2 major (Tema, Takoradi)
Civil air: 4 major transport aircraft
Airfields: 10 total, 9 usable; 5 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 6 with runways
1,220-2,489 m
Telecommunications: fair system of
open-wire and cable, radio-relay links;
68,900 telephones (0.6 per 100 popl.); 6
AM, 9 TV stations; 1 Atlantic Ocean
satellite ground station
Defense Forces
Branches: Army, Navy, Air Force, para-
military Palace Guard, paramilitary
People’s Militia
Military manpower: males 15-49,
8,203,000; 1,797,000 fit for military ser-
vice; 162,000 reach military age (18)
annually
Military budget: for fiscal year ending 30
June 1984, $64.4 million; 8% of central
government budget
|','923da84b728529c345d2d93f620824e5587d67fb35beb09906b2a234f7993190','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c1867572dc8dc1fcd7fc4975d4eb18b56a592c084b9e312dd804359873fc6a0',1987,'GI','Gibraltar','communications',287,'Mediterranean
Bay of Gibraltar Sea
Fortress
heedquarters
Strait of Gibraitar
Lighthouse
See regional map V
Railroads: 1.000-meter gauge system in
dockyard area only
Highways: 50 km, mostly good bitumen
and concrete
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 total, 1 usable with
permanent-surface runways 1,220-2,439 m
Gibraltar (continued)
Telecommunications: adequate interna-
tional radiocommunication facilities;
automatic telephone system serving 9,400
telephones (81.5 per 100 popl.); 1 AM, 6
FM, 4 TV stations; 1 Atlantic Ocean
satellite station
Defense Forces
Defense is the responsibility of the United
Kingdom
Branches: Gibraltar Regiment','54886549f9510f593ace3cd67f8874561356e1c91fdd0a7761fadfad645f4037','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d6d9578764fa74c8d823da72bec565e5c27f81eff24abe3460c097f84591b4b',1987,'GR','Greece','communications',292,'150 km
Corfu @BLimnos
Lesvos
& Aegean Sea
fonian
6
.
Rhodes
.
Maditerranean Saa ale eee f
See regional map V
Railroads: 2,476 km total; 1,565 km 1.435-
meter standard gauge, of which 36 km
electrified and 100 km double track, 889
km 1.000-meter gauge; 22 km 0.750-meter
narrow gauge; all government owned
Highways: 38,938 km total; 16,090 km
paved, 18,676 km crushed stone and
gravel, 5,632 km improved earth, 3,540
km unimproved earth
Inland waterways: system consists of
three coastal canals and three unconnected
rivers, which provide navigable length of
just under 80 km
Pipelines: crude oil, 26 km; refined prod-
ucts, 547 km
Ports: 4 major, 11 secondary, 42 minor
Civil air: 89 major transport aircraft
Airfields: 80 total, 78 usable; 58 with
permanent-surface runways; 20 with
runways 2,440-3,659 m, 21 with runways
1,220-2,489 m
Telecommunications: adequate, modern
networks reach all areas on mainland
islands; 3.52 million telephones (85.5 per
100 popl.); 29 AM, 37 FM, 361 TV sta-
tions; 7 submarine cables; 1 satellite station
with 2 Atlantic Ocean antennas, 1 Indian
Ocean antenna, 1 EUTELSAT antenna
Defense Forces
Branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force
Military manpower: males 15-49,
2,387,000; 1,837,000 fit for military ser-
vice; about 80,000 reach military age (21)
annually
Military budget: for fiscal year ending 31
December 1986, $2.6 billion; 16.1% of
central government budget
95
ch','bbd9cb9fa250ee4d9110bdf3f020f269e84e5b5d1ee98211ccd9522d2604e8c4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65d46ea4e511c2c1b0116d2e6a39a06e08d6bb7a5ac9f5c45c9c6616365b9e66',1987,'GL','Greenland','communications',297,'Arctic Ocean
Sea
Danmark
Havn
&
Battin Bay
iteeqgortoormiit
\\a
Qeqertaraua
Davis Strait
Ammaaaalik
GODTHAB Oanmark Strait
See regional map Il
Railroads: none
Highways: 80 km
Ports: 1 major, 7 secondary, 9 minor
Civil air: 2 major transport aircraft
Airfields: 10 total, 7 usable; 5 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: adequate domestic
and international service provided by
cables and radio-relay; 17,900 telephones
(31.0 per 100 popl.); 6 AM, 35 FM, 9 TV
stations; 2 coaxial submarine cables; 1
Atlantic Ocean satellite station
Defense Forces
Defense is responsibility of Denmark
Military manpower: included with Den-
mark
96','d18d52969bc9eb441e58a61e686193c24d8a69427f111a6f5f5459bca8f4d210','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46ef4516137c28f0d07724696b0a3263a710393803f73c6cd56544680df14038',1987,'GD','Grenada','communications',302,'ase ZB 2
“s Carriacou
s of
Caribbean Ka 3
Sea &
Oe g
Caribbean
Sea
See regional map lll
Railroads: none
Highways: 1,000 km total; 600 km paved,
800 km otherwise improved; 100 km
unimproved
Ports: 1 major (St. George’s), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 2 with
permanent-surface runways, } with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: automatic, islan-
dwide telephone system with 5,650 tele-
phones (5.1 per 100 popl.); new SHF links
to Trinidad and Tobago and St. Vincent;
VHF and UHF links to Trinidad and
Carriacou; 1 AM and 1 TV stations
Defense Forces
Branches: Royal Grenada Police Force','53945ea50cf47ebe1ffc776d3715fdab5b603d27a18b276e0d4069632732e359','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35c1ea559fafbbb31129db3936f39603e012837cc1c41ec5b4e09c4047f69781',1987,'GP','Guadeloupe','communications',307,'20 km
Pointe-a-Pitre
Caribbean
BASSE-TERRE Sea
Marie-
les des Saintes Galante
iP
nd
St Martin and St. Barthalemy
are not shown
See regional map Il
Railroads: privately owned, narrow-gauge
plantation lines
{
}
!
|
Highways: 1,954 km total; 1,600 km
paved, 340 km gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
|
Civil air: 2 major transport aircraft
Airfields: 9 total, 9 usable, 8 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439
Telecommunications: domestic facilities
inadequate; 57,300 telephones (17.4 per
100 popl.); interisland radio-relay to An-
tigua and Barbuda, Dominica, and Martin-
ique; 2 AM, 6 FM, 9 TV stations; 1
INTELSAT satellite station
Defense Forces
Defense is responsibility of France
Military manpower: males 15-49, 89,000','dcb88216976937831b3d09d4db4a81abac4eb1e109ab72ab82391447436449d2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b3712c325a89aa85a34d1de8fa0edd227e10cf7aa96938f61d05472cfde046',1987,'GG','Guernsey','communications',312,'Burhow OF
Alderney
English Channel
St. Sampson
Herm |
Yethou
Brecqhou?
Little Serk™.
Sark
See regional map V
Railroads: none
Ports: St. Peter Port, St. Sampson
Airfield; 1 total, 1 usable with permanent-
surface runway, 1,463 m (La Villiaze)
Telecommunications: 1 AM radio station,
which broadcasts 24 hours a week; 1 TV
station with 4 channels; 41,900 telephones
(74.8 per 100 popl.)
Defense Forces
Defense is the responsibility of the United
Kingdom','785e0abc17b6a19086fc10ae8bac4f74ec17ddd9402d0a7599f797cd50069789','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5834360099c040d3b84666d9c3b04523636b30c31aa7c9524cfd26a19adffc3d',1987,'GW','Guinea-Bissau','communications',319,'100 km
eee ee
Arquipélago ~
dos Bijagés
North Atlantic Ocean
See regional map VII
Railroads: none
Highways: 3,218 km (418 km bituminous,
remainder earth)
Inland waterways: scattered stretches are
important to coastal commerce
Ports: 1 major (Bissau)
Civil air: 1 major transport aircraft
Airfields: 54 total, 89 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 6 with runways
1,220-2,439 m
Telecommunications: limited system of
open-wire lines, radio-relay links, and
radiocommunication stations; 3,000 tele-
phones (0.5 per 100 popl.); 1 AM, 1 FM,
no TV stations
Defense Forces
Branches; People’s Revolutionary Armed
Force (FARP); Army, Navy, and Air Force
are separate components
Military manpower: males 15-49, 194,000;
110,000 fit for military service','a7b5929d9e33e57a65714fda6d3637c089839f8525d6a37ab92f0149eca84380','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9deac45f5699c1cc253ce012bb8299b1dbf4717ef0c2d0b9c211fae1b4c7e576',1987,'GY','Guyana','communications',324,'200. km North Atlantic
Maberuma Ocean
EQRGETOWN
Boundary representation 1s
not necessarily authoritative
See regional map 1V
Railroads: 187 km total, all single track
0.914-meter gauge
Highways: 7,665 km total; 550 km paved,
5,000 km gravel, 1,525 km earth, 590 km
unimproved
Inland waterways: 6,000 km total of
navigable waterways; Berbice, Demerara,
and Essequibo rivers are navigable by
oceangoing vessels for 150 km, 100 km,
and 80 km, respectively
Ports: 1 major (Georgetown), 6 minor
Civil air: 5 major transport aircraft
Airfields: 70 total, 66 usable; 6 with
permanent-surface runways; 11 with
runways 1,220-2,439 m
Telecommunications: fair system with
radio-relay network and over 27,000
telephones (3.3 per 100 popl.); tropospheric
scatter link to Trinidad; 4 AM, 3 FM, 1
shortwave, no TV stations; 1 Atlantic
Ocean satellite station
Defense Forces
Branches: Guyana Defense Force (includ-
ing Maritime Corps and Air Corps),
Guyana Police Force, Guyana People’s
Militia, Guyana National Service
Military manpower: males 15-49, 195,000;
149,000 fit for military service
105','47109baf86f98e29e0be4171811475027769a74f33da28716b9b5e2b9b602d08','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa2ccec5db3091ff2e8c24652b1ac8b9beabc58de8d3e5aca97634dd8de64327',1987,'HT','Haiti','communications',329,'Bin North Atlantic Ocean
lle de la Tortuga"
Golfe de la Gonave
ile de la Gonave
Jéramie
2.
Caribbean Sea
See regional map [11
Railroads: 40 km 0.760-meter narrow
gauge, single-track, privately owned indus-
trial line
Highways: 4,000 km total; 950 km paved,
900 km otherwise improved, 2,150 km
unimproved
Inland waterways: negligible; less than
100 km navigable
Ports: 2 major (Port-au-Prince,
Cap-Haitien), 12 minor
Civil air: 4 major transport aircraft
Airfields: 15 total, 11 usable; 3 with
permanent-surface runways; ] with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,489 m
Telecommunications: domestic facilities
barely adequate, international facilities
slightly better; 36,000 telephones (0.5 per
100 popl.); 33 AM, 4 TV stations; } Atlan-
tic Ocean satellite station
Defense Forces
Branches: Army, Navy, Air Corps
Military manpower: males 15-49,
1,491,000; 803,000 fit for military service;
70,000 reach military age (18) annually
|
|
t
== ___
\\Honduras
Swan islands
Caribbean Sea
gen 2
Islas de la Bahia
-
"Sen Pedro Sula
*Sante Rose
Copan” Juticalpa
Fonseca
Boundary representation is
Nol necessarily authoritative
See reglonal map Il]
Railroads: 545 km total; 320 km 1.067-
meter gauge, 225 km 0.914-meter gauge
Highways: 8,950 km total; 1,700 km
paved, 5,000 km otherwise improved,
2,250 km unimproved earth
Inland waterways: 465 km navigable by
small craft
Ports: | major (Puerto Cortés), 4 minor
Civil air: 9 major transport aircraft
Airfields: 198 total, 181 usable; 8 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m; 11 with runways
1,220-2,439 m
Telecommunications: improved, but still
inadequate; connection into Central Amer-
ican microwave net; 35,100 telephones (0.9
per 100 popl.); 169 AM, 8 shortwave, 21
TV stations; 2 Atlantic Ocean satellite
ground stations
Defense Forces
Branches: Armed Forces, Naval Forces,
Air Force
Military manpower: males 15-49,
1,090,000; 649,000 fit for military service;
56,000 reach military age (18) annually
Military budget: for fiscal year ending 31
December 1987, $67.5 million; about 7%
of central government budget
108','c19d98d030ef6ad45bf3374f3e4ee7c04617219703a33f9b568926d003c37fe8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffea9f8b91372a107e160b01b4f6a8d63bf2cd91b60f0d9aeb27849f248777d1',1987,'HK','Hong Kong','communications',334,'15 km
oe
Island
eG
Lema Channel
See regiona! map VIII
Railroads: 35 km 1.435-meter standard
gauge, government owned
Highways: 1,160 km total; 794 km paved,
806 km gravel, crushed stone, or earth
Ports: 1 major (Hong Kong)
Civil air: 16 major transport aircraft
Airfields: 2 total; 2 usable; 2 with
permanent-surface runways; ] with run-
ways 2,440-3,659 m
Telecommunications: modern facilities
provide excellent domestic and interna-
tional services; 62 telephone exchanges, 1.5
million telephones; 5 AM and 9 FM
radiobroadcast stations with 11 transmit-
ters; 5 TV stations; 2.5 million radio and
1.1 million TV receivers; 10,100 Telex
subscriber lines with direct connections to
47 countries; 2 INTELSAT ground stations
with access to Pacific and Indian Ocean
satellites; coaxial cable to Guangzhou
(Canton), China; 3 international submarine
cables; troposcatter to Taiwan available
but inactive
Defense Forces
Defense is the responsibility of United
Kingdom
Branches: Headquarters of British Forces,
Gurkha Field Forces, Royal Navy, Royal
Air Force, Royal Hong Kong Auxiliary Air
Force, Royal Hong Kong Police Force
Military manpower: males 15-49,
1,720,000; 1,340,000 fit for military ser-
vice; 45,000 reach military age (18) annu-
ally
Military budget: est. for fiscal year ending
80 June 1986, $205.5 million; about 4.3%
of central government budget and 1% of
GDP','5d1916d11a7ced8adf0ddd16de4c99eb4057bd15fbb534b6abcfa624eadeff2e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf08e9ee8b801021293ee25a8baf7e2b8e128e72f0ea0bf8eb1e96679d9b3743',1987,'HU','Hungary','communications',339,'125 km
Miskolc
*
Dabrecen,
*Gyor os
BUDAPEST
Dunadjvéros*
See regional map V
Railroads: 7,766 km total; 7,510 km 1.435-
meter standard gauge, 22] km narrow
gauge (mostly 0.760-meter), 35 km 1.524-
meter broad gauge, 1,130 km double
track, 1,801 km electrified; government
owned (1984)
Highways: 140,000 km total; 29,633 km
concrete, asphalt, stone block; 58,495 km
country roads (66 percent unpaved), and
51,872 km other roads (70 percent
unpaved) (1985)
Inland waterways: 1,622 km (1983)
Pipelines: crude oil, 1,160 km; refined
products, 600 km; natural gas, 3,732 km
(1984)
Freight carried: rail—117.0 million metric
tons, 22.3 billion metric tons/km; high-
way—554.5 million metric tons, 11.9
billion metric tons/km; waterway—est.
12.5 million metric tons, 9.5 billion metric
tons/km (public and private use) (1984)
River ports: 2 principal (Budapest, Dun-
atjvaros); no maritime ports; outlets are
Rostock, GDR; Gdafisk, Gdynia, and
Szczecin in Poland; and Galati and Braila
in Romania
Civil air: 22 major transport aircraft
Airfields: 95 total; 16 with runways 2,500
m or longer
Telecommunications: 12 AM, 11 FM, 20
TV stations; 8 Soviet TV relays; 2,848,000
TV sets; 5,500,000 receiver sets; at least 1
satellite ground station
Defense Forces
Branches: Hungarian People’s Army,
Frontier Guard, Air and Air Defense
Command
Military manpower: males 15-49,
2,595,000; 2,077,000 fit for military ser-
vice; about 77,000 reach military age (18)
annually
Military budget: announced for fiscal year
ending 31 December 1986, 25.1 billion
forints; 4.2% of total budget','14984296dafd64414f355d2149a207d008b7b68c04cf455a32436ce8a703c75e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d8578f79b0db77badb668e6c676938bb2c437f717a8a799e6c2057e2d365ee',1987,'IS','Iceland','communications',344,'Seydhistiordhur,
North Atlantic Ocean
See regional map V
Railroads: none
Highways: 12,343 km total; 166 km bitu-
men and concrete; 1,284 km bituminous
treated and gravel; 10,893 km earth
Ports: 1 major (Reykjavik), 3 secondary
(Akureyri, Hafnarfjérdhur, Seydhis-
fjordhur), and numerous minor
Civil air: 20 major transport aircraft
Airfields: 100 total, 93 usable; 3 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 12 with runways
1,220-2,439 m
Telecommunications: adequate domestic
service, wire and radio communication
system; 135,000 telephones (52.5 per 100
popl.); 4 AM, 33 FM, 129 TV stations; 2
submarine cables; 1 satellite station with 2
Atlantic Ocean antennas
Defense Forces
Branches: Police, Coast Guard
Military manpower: males 15-49, 64,000;
58,000 fit for military service (Iceland has
no conscription or compulsory military
service)
112','d1775648768d1c7af21eb0588cf30eed038f80c9e440488e7f5a6948a6830d8b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d72913579f9185af0e641f646e4949c50e130623251239bbb280fd6e07bead50',1987,'JP','Japan','communications',350,'Railroads: 61,850 km total (1985); 33,553
km 1.676-meter broad gauge, 24,051 km
1.000-meter gauge, 4,246 km narrow
gauge (0.762-meter and 0.6]0-meter);
12,617 km is double track; 6,078 km is
electrified
Highways: 1,633,300 km total (1985);
515,300 km secondary and 1,118,000 km
gravel, crushed stone, or earth
Inland waterways: 16,180 km; 3,63] km
navigable by large vessels
Pipelines: crude oil, 3,497 km; refined
products, 1,828 km; natural gas, 260 km
Ports: 9 major, 79 minor
Civil air: 93 major transport aircraft
Airfields: 346 total, 299 usable; 194 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 54 with runways
2,440-3,659 m, 95 with runways
1,220-2,439 m
Telecommunications: fair domestic tele-
phone service where available, good inter-
nal microwave links; telegraph facilities
widespread; AM broadcast adequate;
international radio communications ade-
quate; 3.] million telephones (0.4 per 100
popl.); about 170 AM transmitters at 94
locations, 14 TV centers and 170 TV
relays; domestic satellite system for com-
munications and TV; submarine cable
extends to Sri Lanka and Malaysia
Defense Forces
Branches: Army, Navy, Air Force, Coast
Guard, Paramilitary Forces
Military manpower: males 15-49,
211,199,000; 124,745,000 fit for military
service; about 9,211,000 reach military age
(17) annually
Military budget: for fiscal year ending 31
March 1986; est. budget $6.5 billion;
15.6% of central government budget
ite Hokkaido} » Rf
Sapporo
Occupied by
D> Soviet Union ance
1945, claime:
Sea of im
Sendai
Korea i TOKYO
Strait
Kitekyaaha Mean
= Pacific
East Ocean
Railroads: none
Highways: 19,200 km total; 640 km
paved, 10,960 km gravel, crushed stone, or
stabilized soil surface, 7,600 km unim-
proved earth
Inland waterways: 10,940 km
Ports: 5 principal, 9 minor
Civil air; about 15 major transport aircraft
Papua New Guinea (continued)
Airfields: 551] total, 445 usable; 15 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m; 35 with runways
1,220-2,4389 m
Telecommunications: services are ade-
quate and being improved; facilities pro-
vide radiobroadcast, radiotelephone and
telegraph, coastal radio, aeronautical radio
and international radiocommunication
services; submarine cables extend to Aus-
tralia and Guam; 51,483 telephones (1.5
per 100 popl.); 31 AM, 2 FM, no TV
stations, 1 satellite station
Defense Forces
Branches: Papua New Guinea Defense
Force
Military manpower: males 15-49, 880,000;
489,000 fit for military service
Military budget: for fiscal year ending 31
December 1986, $34.5 million; about 3.5%
of central government budget
Railroads: 8,193 km 1.485-meter standard
gauge; 204 km double track; 109 km
electrified (1985)
Highways: 49,615 km total; 26,915 km
bituminous; 16,500 km gravel or crushed
stone; 4,000 km improved earth; 2,200 km
unimproved earth (1985)
Inland waterways: about 1,200 km
Pipelines: 1,738 km crude oil; 2,321 km
refined products
Ports: 4 major, 10 secondary, 18 minor
Civil air: 30 major transport aircraft
(1985)
248
Airfields: 122 total, 106 usable; 62 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 27 with runways
2,440-3,659 m, 26 with runways
1,220-2,439 m
Telecommunications: fair domestic and
international systems; trunk radio-relay
network; 2.8 million telephones (5.5 per
100 popl.); 17 AM, 49 FM, 356 TV sta-
tions; 2 satellite ground station antennas, 1
submarine telephone cable
Defense Forces
Branches: Land Forces, Navy, Air Force,
Gendarmerie
Military manpower: males 15-49,
18,296,000; 8,136,000 fit for military
service; 582,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1986, $2.9 billion; 17.3% of
central government budget
Turks and
Caicos Islands
i ———20kms
North Atlantic ia
Ocean
North Caicos
att Middle Caicos
Anam East Caicos
g Providenciales
West
Carcos x
Cockburn, GRAND TURK*
Harbour (Cockburnf/
i Town) Si
i + Salt 4+;
x Cay 7
=# Turks
Islands
North Atlantic
Ocean
See regional map II]
Railroads: none
Highways: 121 km, including 24 km
tarmac
Ports: 4 major (Grand Turk, Salt Cay,
Providenciales, Cockburn Harbour)
Civil air: Air Turks and Caicos (passenger
service) and Turks Air Ltd. (cargo service)
Airfields: 7 total, 7 usable; 4 with
permanent-surface runways; 4 with run-
ways 1,220-2,439 m
Telecommunications: fair cable and radio
services; 1,400 telephones (16.9 per 100
popl.); 1 AM station; 2 submarine cables; 1
satellite ground station; several TV stations
Defense Forces
Defense is the responsibility of the United
Kingdom
Branches: police','ec234a0d141a35aa92c9e897b781d102218febcc09996a2d87a66ceb22fa2ee6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06de6ecf8b045234c4c6f2358cd2cd5dbbc410ca3237718973f8e422df9052cd',1987,'IQ','Iraq','communications',351,'Samerra,
BAGHDAD,
Fd
Ar Rutbah Al Hittah,
°AL Kut
An N6sirtyah
Ai Begrah,
Persian
Gulf
See regional map V1
Railroads: 2,200 km total; 1,680 km 1.435-
meter standard gauge, 520 km 1.000-meter
gauge
Highways: 20,800 km total; 6,490 km
paved, 4,654 km improved earth, 9,656
km unimproved earth
Inland waterways: 1,015 km; Shatt al
Arab navigable by maritime traffic for
about 104 km (closed since September
1980 because of Iran-Iraq war); Tigris and
Euphrates navigable by shallow-draft
steamers (of little importance); Shatt al
Basrah canal navigable by shallow-draft
vessels
Ports: 3 major but closed because of war
(Al Basrah, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,950 km; 725 km
refined products; 1,360 km natural gas
Civil air: 15 major transport aircraft
Airfields: 107 total, 95 usable; 61 with
permanent-surface runways; 7 with run-
ways over 3,659 m, 50 with runways
2,440-3,659 m, 12 with runways
1,220-2,489 m
Telecommunications: good network
consists of coaxial cables, radio-relay links,
and radiocommunication stations; about
632,000 telephones (4.0 per 100 popl.); 9
AM, no FM, 81 TV stations; 1 Atlantic
Ocean, 1 Indian Ocean, and 1 Intersputnik
satellite station; coaxial cable and radio-
relay to Kuwait, Jordan, Syria, and Turkey
Defense Forces
Branches: Army, Navy, Air Force, Border
Guard Force, mobile police force
Military manpower: males 15-49,
3,795,000; 2,119,000 fit for military ser-
vice; 177,000 reach military age (18)
annually
Railroads: none
Highways: 2,600 km total; 2,300 km
bituminous; 300 km earth, sand, light
gravel
Pipelines: crude oil, 877 km; refined
products, 40 km; natural gas, 140 km
Ports: 3 major (Ash Shuwaykh, Ash
Shu‘aybah, Mina’ al Ahmadi), 6 minor
Civil air: 26 major transport aircraft
Airfields: 9 total, 4 usable; 4 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m
Telecommunications: excellent interna-
tional, adequate domestic facilities;
258,000 telephones (14.6 per 100 popl.); 2
AM, 2 FM, 8 TV stations; I Indian Ocean
and 2 Atlantic Ocean INTELSAT stations,
1] INMARSAT satellite station; 1
ARABSAT station; coaxial cable and radio-
relay to Iraq and Saudi Arabia
Defense Forces
Branches: Army, Navy, Air Force, Na-
tional Police Force, National Guard
Military manpower: males 15-49, about
626,000; about 376,000 fit for military
service
Military budget: operating expenditures
for fiscal year ending 30 June 1986, $876
million; 7.5% of central government
budget
Laos
See regional map [X
Highways: about 27,527 km total; 1,856
km bituminous or bituminous treated;
7,451 km gravel, crushed stone, or im-
proved earth; 18,220 km unimproved
earth and often impassable during rainy
season mid-May to mid-September
Inland waterways: about 4,587 km, pri-
marily Mekong and tributaries; 2,897
additional kilometers are sectionally navi-
gable by craft drawing less than 0.5 m
Pipelines: 136 km, refined products
Ports (river): 5 major, 4 minor
Airfields: 64 total, 49 usable; 9 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 11 with runways
1,220-2,4389 m
Telecommunications: service to general
public considered poor; radio network
provides generally erratic service to gov-
ernment users; about 10 AM stations; 1 TV
station; over 5,000 telephones; 1 satellite
ground station
Defense Forces
Branches: Lao People’s Army (LPA,
which consists of an army with naval,
aviation, and militia elements), Air Force,
National Police Department
Military manpower: males 15-49, 900,000;
482,000 fit for military service; 41,000
reach military age (18) annually; no con-
scription age specified
138','85db7785c270f4547674f76d82e0e6e0ee8dda6df363b9f0783e4a61b8f6ae41','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc71fd7acdc2e948ff9eb49512469857641fc8ca336e2769be55035f082a40a3',1987,'IE','Ireland','communications',356,'100 km
trish
B as Sea
North ‘
Atlantic Wicklow.
Ocean
See regional map v
Railroads: Irish National Railways (CIE)
operates 1,940 km 1.602-meter gauge,
government owned; 485 km double; 38 km
electrified
Highways: 92,294 km total; 87,422 km
surfaced, 4,872 km gravel or crushed stone
Inland waterways: limited for commercial
traffic
Pipelines: natural gas, 225 km
Ports: 2 major, 6 secondary, 38 minor
Civil air: 23 major transport aircraft
Airfields: 42 total, 39 usable; 17 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: small, modern
system using cable and radio-relay circuits;
900,000 telephones (23.5 per 100 popl.); 47
AM, 33 FM, 86 TV stations; 4 coaxial
submarine cables; | satellite ground station
Defense Forces
Branches: Army, Naval Service, Army Air
Corps
Military manpower: males 15-49, 793,000;
635,000 fit for military service; 37,000
reach military age (17) annually
Military budget: for fiscal year ending 31
December 1986, $256.955 million; 2.5% of
central government budget
Railroads: Great Britain—16,800 km total;
British Railways (BR) operates 16,800 km
1.435-meter standard gauge (3,802 km
electrified and 12,591 km double or multi-
ple track); several additional small
standard-gauge and narrow-gauge lines are
privately owned and operated; Northern
Ireland Railways (NIR) operates 332 km
1.600-meter gauge, 190 km double track
Highways: United Kingdom, 362,982 km
total; Great Britain, 339,483 km paved
(including 2,573 km limited-access divided
highway); Northern Ireland, 23,499 km
(22,907 paved, 592 km gravel)
Inland waterways: 3,219 km publicly
owned; 605 km major commercial routes
Pipelines: 933 km crude oil, almost all
insignificant; 2,993 km refined products;
12,800 km natural gas
Ports: 9 major, 15 secondary, 190 minor
Civil air: 618 major transport aircraft
Airfields: 499 total, 332 usable; 243 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 36 with runways
2,440-3,659 m, 133 with runways
1,220-2,4389 m
Telecommunications: modern, efficient
domestic and international system; 29.5
million telephones (52.5 per 100 popl.);
excellent countrywide broadcast systems
with 216 AM, 478 FM, 3,065 TV stations;
86 coaxial submarine cables; 4 satellite
ground stations with a total of 14 antennas','ecf10ec4353a0a978812426fd3223d80e17b8b83b6dc443490b4e94316afeae7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b96bae2440ccf555aa342c1e8afab1cbf56a755da675ab0cf57b597ca3ae2f2',1987,'IL','Israel','communications',361,'(West Bank and Gaza Strip entry
on page 276)
100 km
Laka
Tiberias
Mediterranean
Sea
Tal Aviv-Yaf
Ashdod Jarusalam
Boundary representation is
not necessarily authoritative
See regional map VI
Note: the Arab territories occupied by
Israel since the 1967 war are not included
in the data below; as stated in the 1978
Camp David Accords and reaffirmed by
the President’s 1 September 1982 peace
initiative, the final status of the West Bank
and Gaza Strip, their relationship with
their neighbors, and a peace treaty be-
tween Israel and Jordan are to be negoti-
ated among the concerned parties; Camp
David further specifies that these negotia-
tions will resolve the location of the re-
spective boundaries; pending the comple-
tion of this process, it is US policy that the
final status of the West Bank and Gaza
Strip has yet to be determined (see West
Bank and Gaza Strip entry); on 25 April
1982 Israel relinquished control of the
Sinai to Egypt; statistics for the Israeli-
occupied Golan Heights are included in
the Syria entry
Railroads: 516 km 1.435-meter gauge
single track; diesel operated
Highways: 4,500 km; majority is bitumi-
nous surfaced
Inland waterways: none
Pipelines: crude oil, 708 km; refined
products, 290 km; natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5
minor
Israel (continued)
Civil air: 26 major transport aircraft
Airfields: 56 total, 53 usable; 27 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m, 11 with runways
1,220-2,439 m
Telecommunications: most highly devel-
oped in the Middle East though not the
largest; good system of coaxial cable and
radio-relay; 1,500,000 telephones (35.6 per
100 popl.); 11 AM, 24 FM, 54 TV stations;
2 submarine cables; 2 Atlantic Ocean
INTELSAT stations; 1 Indian Ocean
INTELSAT station
Defense Forces
Branches: Israel Defense Forces; histori-
cally there have been no separate Israeli
military services; ground, air, and naval
components are branches of Israel Defense
Forces
Military manpower: eligible 15-49,
2,015,000; of 1,014,000 males 15-49,
839,000 fit for military service; of
1,002,000 females 15-49, 826,000 fit for
military service; 41,000 males and 39,000
females reach military age (18) annually;
both sexes liable for military service
Military budget: for fiscal year ending 31
March 1987, $4.6 billion; about 24% of
central government budget
Railroads: West Bank—none; Gaza
Strip—one line, abandoned
Highways: West Bank—small, poorly
developed indigenous road network, Israe-
lis have improved major axial highways;
Gaza Strip—small, poorly developed
indigenous road network, Israelis have
improved major axial highways
Ports: West Bank—none (landlocked),
Gaza Strip—facilities for small boats to
service Gaza
277
Airfields: West Bank—2 total, 2 usable
with permanent-surface runways, 1 with
runways 1,220-2,439 m; Gaza Strip—1
total, 1 usable with permanent-surface
runways
Telecommunications: West Bank—
planned telephone system currently being
upgraded, no local radio or TV stations;
Gaza Strip—no local radio or TV stations
Main committees
Standing and procedural
committees
Other subsidiary organs of the
General Assembly
UNRWA,: United Nations Relief
and Works Agency for Palestine
Refugees in the Near East
UNCTAD: United Nations
Conference on Trade and
Development
UNICEF: United Nations
Children’s Fund
UNHCR: United Nations Office
of High Commissioner for
Refugees
WEP: World Food Program
Instn for Trotting oad
institute for
Research
UNDP: United Nations
Development Program
UNIDO: United Nations
Industrial Development
Organization
UNEP; United Nations
Environment Program
UNU: United Nations
University
HABITAT: United Nations
Center for Human Settlements
UNFPA: United Nations Fund
for Population Activities
United Nations Special Fund
World Food Council
Based on a chart trom the UN Chronicle
Appendix A
The United Nations System
@ Principal organs of the United
Nations
* Other United Nations organs
O Specialized agencies and other
autonomous organizations
within the system
278
UNDOF: United Nations
Disengagement Observer Force
UNFICYP: United Nations
Force in Cyprus
UNIFIL: United Nations Interim
Forces in Lebanon
UNMOGIP: United Nations
Military Observer Group in
India and Pakistan
UNTSO: United Nations Truce
Supervision Organization
Military Staff Committee
C) IAEA: International Atomic
Energy Agency
r — —O GATT: General Agreement on
Tariffs yt
and Trade
C) ILO: International Labor
Organization
© FAO: Food and Agriculture
Organization of the United
Nations
[] UNESCO: United Nations
Educational, Scientific, and
Cultural Organization
C1) WHO: World Health
Organization
2 IMF: International Monetary
Fund
0) IDA: International
Development
1 IBRD: International Bank for
Reconstruction and
O) IFC: International Finance
Corporation
1) ICAO: International Civil
Aviation Organization
© UPU: Universal Postal Union
1) ITU: International
Telecommunication Union
C WMO: World Meteorological
Organization
CO IMO: International Maritime
Organization
1} WIPO: World Intellectual
Property Organization
— — O IFAD: International Fund for
Agricultural Development
Appendix B
International Organizations
A AAPSO _ Afro-Asian People’s Solidarity Organization
ADB Asian Development Bank = 2
AfDB 7 African Development Bank =
AIOEC Association of Iron Ore. Exporting Countries
ANRPC Association of Natural Rubber Producing Countries
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and
the United States an ss
APC a African Peanut (Groundnut) Council
ae Arab ] League (League of Arab States) ae
ASEAN Association of Southeast Asian Nations _=
ASPAC Asian and Pacific Council
ASSIMER International Mercury Producers Association
B BENELUX —— Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
Cc CACM | — Central American Common Market in a
CARICOM Caribbean Common Market 7
CARIFTA ; Caribbean Free Trade Association
CCC 2 ‘Customs Cooperation Council
CDB Caribbean Development Bank “3
CEAO West African Economic Community
CEMA Council for Mutual Economic Assistance
CENTO Central Treaty Organization
CIPEC Intergovernmental Council of Copper Exporting Countries
Colombo Plan _ ee eee ae
Council of Europe .
D DAC : 7 ‘Development Assistance Committee (OECD) i”
E EAMA African States associated with the EEC
EC European Communities -
ECA a _Economic Commission for Africa (UN)
ECE : Economic Commission for Europe (UN) _
ECLA Economic Commission for Latin America (UN) Zi
ECOSOC Economic and Social Council (UN) eee i
ECOWAS ____ Economic Community of West African States =
ECWA _ Economic Commission fo for Western Asia (UN) _
EFTA European Free Trade Association =
EIB European Investment Bank
ELDO European Space Vehicle Launcher Development Organization
EMS _— European Monetary System :
ENTENTE Political-Economic Association of Ivory Coast, Benin, Niger,
Burkina,and Togo) is =
ESCAP Economic and Social Commission for Asia and the Pacific (UN) |
ESRO European Space Research Organization
F FAO | Food and Agriculture Organization (UN) 7
G G-77 Group of 77 X =
GA General Assembly (UN)
GATT 7 _ General Agreement on Tariffs and Trade (UN)
GCC Gulf Cooperation Council
I IADB 7 ___ Inter-American Defense > Board a
IAEA International Atomic ‘Energy Agency (UN)
IATP International Association of Tungsten Producers
IBA International Bauxite Association
IBEC International Bank for Economic Cooperation
279
IBRD International Bank for Reconstruction and Development (“World Bank,” UN)
ICAC International Cotton Advisory Committee
ICAO International Civil Aviation Organization (UN) a
ICCAT International Commission for the Conservation of Atlantic Tunas
IcCO International Cocoa Organization
ICEM Intergovernmental Committee for European Migration S
ICES = International Cooperation in Ocean Exploration
IC) International Court of Justice (UN)
Ico International Coffee Organization
IDA International Development Association (IBRD affiliate, UN) 7
IDB ___ Inter-American Development Bank
IDB Islamic Development Bank :
IEA International Energy Agency (associated with OECD)
IFAD International Fund for Agricultural Development (UN)
IFC International Finance Corporation (IBRD affiliate, UN)
IHO International Hydrographic Organization
IIB International Investment Bank a a a .
ILO International Labor Organization (UN)
a ____ International Lead and Zinc Study Group
IMF International Monetary Fund (UN)
IMO International Maritime Organization (UN) —_
INRO International Natural Rubber Organization
INTELSAT International Telecommunications Satellite Organization
100C __ International Olive Oil Council a
IPU Inter-Parliamentary Union
IRC International Rice Council
ISO International Sugar Organization ‘
ITC International Tin Council : 7
ITU International Telecommunication Union (UN) a
IWC International Whaling Commission
IwC International Wheat Council
LAIA Latin American Integration Association
NAM Nonaligned Movement
NATO North Atlantic Treaty Organization
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU | Organization of African Unity =
OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development =
OIC Organization of the Islamic Conference 7
OPEC Organization of Petroleum Exporting Countries
PAHO Pan American Health Organization
SAARC South Asian Association for Regional Cooperation
SADCC Southern African Development Coordination Committee
sc Security Council (UN) -
SELA Latin American Economic System -
SPC South Pacific Commission
SPEC South Pacific Bureau for Economic Cooperation
SPF South Pacific Forum
TC Trusteeship Council (UN)
TDB Trade and Development Board (UN)
UDEAC Economic and Customs Union of Central Africa
UEAC Union of Central African States
UNCTAD UN Conference on Trade and Development
UNDP UN Development Program
UNESCO UN Educational, Scientific, and Cultural Organization
UNICEF UN Children’s Fund
UNIDO UN Industrial Development Organization
UPEB Union of Banana Exporting Countries
UPU Universal Postal Union (UN)
WEU Western European Union
WFC World Food Council (UN)
WFTU World Federation of Trade Unions
WHO World Health Organization (UN)
WIPO World Intellectual Property Organization (UN)
WMO World Meteorological Organization (UN)
WPC World Peace Council
WSG International Wool Study Group
WTO World Tourism Organization
281
Appendix C
Country Membership in International Organizations
Country International Organizations
ADB ARAB ASEAN CACM CARICOM CEMA EC G-77. GCC 1B? IDB INTELSAT LAIA | NAM NATO OAPEC OAS','8249bb0728e6c5487c16b892a14857678763d0b630b702f28657022660e2b47a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c95a23ba000b89c35642416a6ce15c9add026e835e892c68f6612f70340a714a',1987,'IT','Italy','communications',366,'Sardinia
Cagliari Tyrrhenian
Sea
Pilea lonian
é / Sea
Mediterranean ‘aggio
Sea Calabria
See regional map V
Railroads: 20,011 km total; 16,066 km
1.435-meter government-owned standard
gauge, 8,843 km electrified; 3,945 km
privately owned—2,100 km 1.435-meter
standard gauge, 1,155 km electrified, and
1,845 km 0. 950-meter narrow gauge, 380
km electrified
Highways: 294,410 km total; autostrada
5,900 km, state highways 45,170 km,
provincial highways 101,680 km, commu-
nal highways 141,660 km; 260,500 km
123
concrete, bituminous, or stone block,
26,900 km gravel and crushed stone, 7,010
km earth
Inland waterways: 1,600 km for various
types of commercial traffic
Pipelines: crude oil, 1,703 km; refined
products, 2,148 km; natural gas, 17,300 km
Ports: 9 major, 11 secondary, 40 minor
Civil air: 182 major transport aircraft
Airfields: 147 total, 140 usable; 85 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 35 with runways
2,440-3,659 m, 40 with runways
1,220-2,439 m
Telecommunications: well engineered,
well constructed, and efficiently operated;
25.6 million telephones (44.8 per 100
popl.); 137 AM, 1,841 FM, 1,500 TV
stations; 21 submarine cables; 2 communi-
cation satellite ground stations with a total
of 10 antennas
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
14,474,000; 12,637,000 fit for military
service; 449,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1986, $13.3 billion; about 4.6%
of central government budget
Ivory Coast
(Céte d''Ivoire)
Gulf of Guinea
See regional map VII
Railroads: 657 km of the 1,175 km
Abidjan to Ouagadougou, Burkina Faso,
line, al] single track 1.000-meter gauge;
only diesel locomotives in use
Highways: 46,600 km total; 3,600 km
bituminous and bituminous-treated sur-
face; 32,000 km gravel, crushed stone,
laterite, and improved earth; 11,000 km
unimproved
Inland waterways: 740 km navigable
rivers and numerous coastal lagoons
Ports: 2 major (Abidjan, San-Pédro), 2
minor
Civil air: 19 major transport aircraft,
including multinationally owned Air
Afrique fleet
Airfields: 50 total, 45 usable; 3 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m; 15 with runways
1,220-2,489 m
Telecommunications: system above Afri-
can average; consists of open-wire lines
and radio-relay links; 87,700 telephones
(1.0 per 100 popl.); 8 AM, 17 FM, 11 TV
stations; 2 Atlantic Ocean satellite stations;
2 coaxial submarine cables
Defense Forces
Branches: Army, Navy, Air Force, para-
military Gendarmerie
Military manpower: males 15-49,
2,528,000; 1,305,000 fit for military ser-
vice; 98,000 males reach military age (18)
annually
Railroads: 9,279 km total; (all 1.435-meter
standard gauge) including 898 km double
track, 3,462 km electrified (1984)
Highways: 116,602 km total; 65,222 km
asphalt, concrete, stone block; 33,048 km
macadam, asphalt treated, gravel, crushed
stone; 18,332 km earth (1983)
Inland waterways: 2,600 km (1982)
Freight carried: rail—91.7 million metric
tons, 28.7 billion metric tons/km; high-
way—229.3 million metric tons, 121.8
billion metric tons/km; waterway—21.0
million metric tons, 4.3 billion metric
tons/km (excluding international transit
traffic) (1984)
Pipelines: 1,378 km crude oil; 2,900 km
natural gas; 150 km refined products
Ports: 9 major (most important: Rijeka,
Split, Koper, Bar, and Ploée), 24 minor;
principal inland water port is Belgrade
Airfields: 185 total, 183 usable; 51 with
permanent-surface runways; 22 with
runways 2,440 to 3,659 m, 22 with run-
ways 1,220-2,439 m
Telecommunications: 199 AM, 87 FM
stations; 11 main TV centers and about 50
TV stations; 3,915,113 TV sets; 4,456,213
receiver sets; 2 satellite ground stations
Defense Forces
Branches: Yugoslav People’s Army—
Ground Forces, Naval Forces, Air and Air
Defense Forces, Frontier Guard, Territo-
rial Defense Force
Military manpower: males 15-49,
6,029,000; 4,890,000 fit for military ser-
vice; 184,000 reach military age (19)
annually
Military budget: announced for fiscal year
ending 31 December 1986, 889.0 billion
dinars; about 5.2% of national income
270
Zaire
500 km
Sumbs
e
e
Kisangant
* Mbandake Ne
Boundary representation is
not necessarily authoritative
Lubumbashi
See regional map VII
Railroads: 5,254 km total; 3,968 km 1.067-
meter gauge (851 km electrified); 125 km
1.000-meter gauge; 1386 km 0.615-meter
gauge; 1,025 km 0.600-meter gauge
Highways: 145,050 km total; 2,350 km
bituminous, 46,230 km gravel and im-
proved earth; remainder unimproved earth
Inland waterways: comprising the Congo,
its tributaries, and unconnected lakes, the
waterway system affords over 15,000 km
of navigable routes
Pipelines: refined products, 390 km
Ports: 2 major (Matadi, Boma), 1 minor
Civil] air: 49 major transport aircraft
Airfields: 335 total, 296 usable; 25 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 6 with runways
2,440-3,659 m, 70 with runways
1,220-2,4389 m
Telecommunications: barely adequate
wire and radio-relay service, 31,200 tele-
phones (0.1 per 100 popl.); 10 AM, 3 FM,
17 TV stations; 1 Atlantic Ocean satellite
station and 13 domestic satellite stations
Defense Forces
Branches: Army, Navy, Air Force, Na-
tional Gendarmerie, Logistics Corps,
Special Presidential Brigade
Military manpower: males 15-49,
7,141,000; 3,608,000 fit for military service
Ivory Coast','c8105555eb0ab138c3d473309619d932a7cf37a63091dbeba06c35dbbaa55a6b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7bb7db757600755e5da579c4125a1f9f93759ba456c265a82af29e77ab7d689',1987,'JM','Jamaica','communications',371,'Caribbean Sea
Caribbean Sea
See regional map Il
Railroads: 370 km, all 1.435-meter stan-
dard gauge, single track
Highways: 18,200 km total; 12,600 km
paved, 3,200 km gravel, 2,400 km im-
proved earth
Pipelines: refined products, 10 km
Ports: 2 major (Kingston, Montego Bay), 10
minor
Civil] air: 6 major transport aircraft
Airfields: 42 total, 27 usable; 14 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: fully automatic
domestic telephone network with 127,000
telephones (6.0 per 100 popl.); 2 Atlantic
Ocean INTELSAT stations; 9 AM, 16 FM,
8 TV stations; 3 coaxial submarine cables
Defense Forces
Branches: Jamaica Defense Force (in-
cludes Coast Guard and Air Wing)
Military manpower: males 15-49, 590,000;
420,000 fit for military service; no con-
scription; 28,000 reach minimum volun-
teer age (18) annually
126','688f2aec81dbda3ebfbec3576acd4ee85ba8722848df78413dd4d99fd318af03','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9191d337c1ade46a15c4b891903b713a32d401283295292001859bf088ffe9',1987,'JE','Jersey','communications',376,'Skm
English Channel
English Channel
See regional map V
Railroads: none
Ports: Saint Helier, Gorey, St. Aubin
Airfields: | total, 1 usable with
permanent-
surface runways 1,220-2,439 m (St. Peter)
Telecommunications: telephones in ser-
vice, 61,400 (80.9 per 100 popl.); 1 radio
station, 1 TV station with 4 channels
Defense Forces
Defense is the responsibility of the United
Kingdom
Railroads: 515 km 1.067-meter gauge,
single track
Highways: 2,853 km total; 510 km paved,
1,230 km crushed stone, gravel, or stabi-
lized soil, and 1,118 km improved earth
Civil air: 1 major transport aircraft
Airfields: 25 total, 25 usable; 1 with
permanent-surfaced runways; 1 with
runways 2,440-8,659, 1 with runways
J,220-2,439 m
233
Telecommunications: system consists of
carrier-equipped open-wire lines and low
capacity radio-relay links; 15,400 tele-
phones (2.3 per 100 popl.); 6 AM, 6 FM,
11 TV stations; Atlantic Ocean INTELSAT
station
Defense Forces
Branches: Umbutfo Swaziland Defense
Force, Royal Swaziland Police Force
Military manpower: males 15-49, 151,000;
87,000 fit for military service','4da325dca7fee751d2811d669c24527001fbd904c171a71c262be0ae505899e5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41294026fae948af51d90c76d7b343afd4885589e4b599eee167acb2edcdfcb3',1987,'JO','Jordan','communications',381,'(West Bank and Gaza Strip entry
on page 276)
Boundary representation is
not necessarily authoritative
See regional map Vi
Note: the war between Israel and the Arab
states in June 1967 ended with Israel in
control of the West Bank; as stated in the
1978 Camp David Accords and reaffirmed
by the President’s 1 September 1982 peace
initiative, the final status of the West Bank
and Gaza Strip, their relationship with
their neighbors, and a peace treaty be-
tween Israel and Jordan are to be negoti-
ated among the concerned parties; Camp
David further specifies that these negotia-
tions will resolve the location of the re-
spective boundaries; pending the comple-
tion of this process, it is US policy that the
final status of the West Bank and Gaza
Strip has yet to be determined
Railroads: 817 km 1.050-meter gauge,
single track
Highways: 6,332 total; 4,887 paved, 1,495
gravel and crushed stone
Pipelines: crude oil, 209 km
Ports: 1 major (Al ‘Aqabah)
Civil air: 28 major transport aircraft
Airfields: 21 total, 19 usable; 14 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 14 with runways
2,440-3,659 m, 1 with runways 1,220-
2,489 m
Telecommunications: adequate system of
radio-relay, cable, and radio; 81,500 tele-
phones (8 per 100 popl.); 3 AM, 2 FM, 24
TV stations; | Atlantic Ocean INTELSAT
station, 1 Indian Ocean INTELSAT sta-
tion; 1 ARABSAT station; coaxial cable
and radio-relay to Iraq, Saudi Arabia, and
Syria; radio-relay to Lebanon inactive
Defense Forces
Branches: Jordan Arab Army, Royal
Jordanian Air Force, Royal Jordanian
Coast Guard
Military manpower: males 15-49, 639,000;
456,000 fit for military service; 36,000
reach military age (18) annually
130','56e6ea79db1e46f820d0cec118e3ffe4dd3e38ead72a3e7db9e2f97fa5514709','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2d778e242eb4a5e20b5046adf5b91b9daa1e12caa83d5516327b5369827146f',1987,'KE','Kenya','communications',386,'See regione! map VII ,
Railroads: 2,040 km 1.000-meter gauge
Highways: 64,590 km total; 7,000 km
paved, 4,150 km gravel, remainder im-
proved earth
Inland waterways: part of Lake Victoria
system is within boundaries of Kenya;
principal inland port is at Kisumu
Pipelines: refined products, 483 km
Ports: 1 major (Mombasa)
Civil air; 10 major transport aircraft
Airfields: 225 total, 205 usable; 10 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 47 with runways
1,220-2,489 m
Telecommunications: in top group of
African systems; consists of radio-relay
links, open-wire lines, and radiocommuni-
cation stations; 231,000 telephones (1.1 per
100 popl.); 11 AM, 4 FM, 4 TV stations; |
Atlantic and 1 Indian Ocean satellite
station
Defense Forces
Branches: Kenya Army, Kenya Navy, Air
Force; paramilitary General Service Unit
Military manpower: males 15-49,
4,554,000; 2,811,000 fit for military ser-
vice; no conscription
Railroads: none
Highways: 5,000 km total; 460 km paved,
1,725 km gravel and/or improved earth,
2,700 km unimproved
Inland waterways: Lac Kivu navigable by
shallow draft barges and native craft
Civil air: | major transport aircraft
Airfields: 8 total, 8 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: fair system with
low-capacity radio-relay system centered
on Kigali; 6,600 telephones (0.1 per 100
popl.); 2 AM, 5 FM, and no TV stations;
SYMPHONIE satellite station, 1 Indian
Ocean satellite station
Defense Forces
Branches: Army, paramilitary, Gendar-
merie
Military manpower: males 15-49,
1,415,000; 725,000 fit for military service;
no conscription
207
St. Christopher and Nevis
10 km
Saint
Christopher
Caribbean
BASSETERAE Sea
Caribbean
Sea
See regional map Ill
Railroads: 58 km 0.760-meter narrow
gauge on St. Christopher for sugarcane
Highways: 300 km total; 125 km paved,
125 km otherwise improved, 50 km unim-
proved earth
Ports: 1 major—Basseterre, St. Chris-
topher, and 1 minor—Charlestown, Nevis
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways; | with run-
ways 2,440-3,659 m
Telecommunications: good interisland
VHF/UHF/SHF radio connections and
international link via Antigua and Barbuda
and St. Martin; about 2,400 telephones (5.0
per 100 popl.); 2 AM, 4 TV stations
Defense Forces
Branches: Royal St. Christopher and Nevis
Police Force
208
St. Helena
a EM _,
South
Atlantic
Ocean
“Ascension and Tristan
da Cunha islands ar
ip Fi] not shown
See regional map VII
Railroads: none
Highways: 87 km bitumen sealed roads,
20 km earth roads on St. Helena; 80 km
sealed on Ascension; 2.7 km sealed on
Tristan da Cunha
Ports: Jamestown on St. Helena, George-
town on Ascension, and St. James Bay
Airfields: none on St. Helena; airstrip
(Miracle Miles) near Georgetown on Ascen-
sion; 1 permanent-surface runway
2,440-3,659 on Tristan da Cunha
Telecommunications: 1,500 radio receiv-
ers; no television service; wireless service
to Cape Town and Ascension; telephones
$10 (1982); coaxial cable relay point be-
tween South Africa, Portugal, and UK at
Ascension
Defense Forces
Defense is the responsibility of the United
Kingdom
Military manpower: St. Helena Constabu-
lary
209
St. Lucia
10 km
Caribbean
Sea
Caribbean
Sea
See regional map II]
Railroads: none
Highways: 760 km total; 500 km paved;
260 km otherwise improved
Ports: 1 major (Castries), 1 minor
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways, 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439
Telecommunications: fully automatic
telephone system with 9,500 telephones
(8.0 per 100 popl.); direct radio-relay link
with Martinique and St. Vincent and the
Grenadines; interisland troposcatter link to
Barbados; 3 AM stations, 1 cable TV
station
Defense Forces
Branches: Royal St. Lucia Police Force
210
St. Vincent and
the Grenadines
10 km
Chateaubelair,
Georgetown
Saint
KINGSTOW Vincent
Caribbean
Bequis Ff Sea
a i"
Caribbean Si cae
Sea ee @ Mustique
AS ae
&
)
fo) Jy Canouen
o
‘Union Islend
See regional map Il :
Railroads: none
Highways: about 1,000 km total; 300 km
paved; 400 km improved; 300 km unim-
proved
Ports: 1 major (Kingstown), 1 minor
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 3 with
permanent-surface runways, 1 with run-
ways 1,220-2,439 m
Telecommunications: islandwide fully
automatic telephone system with 6,500 sets
(4.6 per 100 popl.); VHF/UHF interisland
links to Barbados and the Grenadines; new
SHF links to Grenada and St. Lucia; 4 AM
and | FM stations; St. Vincentian-owned
cable television system
Defense Forces
Branches: Royal St. Vincent and the
Grenadines Police Force
211
Kiribatic
Korea, Northe
Korea, Souths','c3c238bc7eef3d055bdc5131344b639c14a275f83a136531b25f1a4c322636f9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7d9c38109644b2aa6d65201cd1e3bcfd8b89371defed1bf083ed29b0684e83',1987,'KI','Kiribati','communications',391,'—1200 km
North Pacific Ocean
ee
Ei ° ee
{>—* TARAWA Kiritimati ©
As faba tae , (Christmas) wa
Kiribati . cone
(Gilbert Rawaki ‘ o
islands) (Phoenix »
tsfands}
South Pacific Ocean
See regional map X
Railroads: none
Highways: 640 km of motorable roads
Inland waterways: small network of
canals, totaling 5 km, in Line Islands
Ports: main ports are at Banaba and Betio
(Tarawa)
Civil air: 2 Trislanders; no major transport
aircraft
Airfields: 21 total; 18 usable; 4 with
permanent-surface runways, 4 with run-
ways 1,220-2,489 m
Telecommunications: 1,400 telephones
(2.83 per 100 popl.); 1 AM station; 1 satel-
lite ground station
Korea, North
150 km
Boundary representation is
Nol necessarily authoritative
*Najin
a0 sunch’én
P''YONGYANG
vi
See regional mep VIII
Railroads: 4,535 km total operating in
1980; 3,870 km 1.435-meter standard
gauge, 665 km 0.762-meter narrow gauge,
159 km double track; abont 3,175 km
electrified; government owned
Korea, North (continued)
Highways: about 20,280 km (1980); 98.5%
gravel, crushed stone, or earth surface;
1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly
navigable by small craft only
Pipelines: crude oil, 37 km
Ports: 6 major, 26 minor
Telecommunications: 18 AM, O FM, 1]
TV stations; 150,000 TV sets; 3,500,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: North Korean People’s Army
(consists of the army, navy, and air force)
Military manpower: males 15-49,
5,341,000; 3,266,000 fit for military ser-
vice; 238,000 reach military age (18)
annually
Korea, South
Boundary representation is
150 km Pol necessarily authoritative
e
4 . Ulling-do
’ * e
ineh''ss Kangniing
Yellow
Sea Sea of
Jepen
Ulasn
‘ 4° Pusan
1 & iD
eo d
ie Koree
i « Streit
Cheju-do, y
See regional map VIII
Railroads: 3,106.5 km operating in 1983;
3,059.4 km 1.435-meter standard gauge,
46.9 km 0.610-meter narrow gauge, 712.5
km double-track, 417.9 km electrified;
government owned
Highways: 62,936 km total (1982); 13,476
km uational highway, 49,460 km provin-
cial and local roads
Inland waterways: 1,609 km; use re-
stricted to small native craft
135
Freight carried: rail (1983) 51 million
metric tons; highway 126 million metric
tons; air (1983) 47,000 metric tons (domes-
tic)
Pipelines: 294 km refined products
Ports: 1] major, 32 minor
Civil air: 98 major transport aircraft
Airfields: 125 total, 109 usable; 72 with
permanent-surface runways; 2] with
runways 2,440-3,659 m, 15 with runways
1,220-2,4389 m
Telecommunications: adequate domestic
and international services; 4.8 million
telephones (121 per 100 popl.); 79 AM, 46
FM, 256 TV stations (57 of 1 kW or
greater); 1 satellite ground station
Defense Forces
Branches: Army, Navy, Air Force, Naval
Marine Force
Military manpower: males 15-49,
11,836,000; 7,672,000 fit for military
service; 472,000 reach military age (18)
annually
Military budget: proposed for fiscal year
ending 31 December 1987, $5.65 billion;
about 31.4% of central government budget','aa182a78a7bbb90e06946957d3ef8f645414aa4522730e4e79169bcc4ba3d014','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bd4b70c7c8bc8f10d4b6d35766c586c19fa88b816b6158272a0f82585ba2f51',1987,'LB','Lebanon','communications',397,'Meditarraneen
Boundary representation is
not necessarily euthoriative
See regional map V1
Railroads: 378 km total; 296 km 1.435-
meter standard gauge, 82 km 1.050-meter
gauge; all single track; system almost
inoperable
Highways: 7,370 km total; 6,270 km
paved, 450 km gravel and crushed stone,
650 km improved earth
Pipelines: crude oil, 72 km
Ports: 2 major (Beirut, Tripoli); one petro-
leum terminal; 3 legal minor ports; numer-
ous illegal ports controlled by various
political factions
Civil air; 28 major transport aircraft
Airfields: 10 total, 9 usable; 5 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m; 3 with runways
1,220-2,489 m
Telecommunications: rebuilding program
disrupted; had fair system of radio-relay,
cable; about 150,400 telephones (5.6 per
100 popl.); 3 FM, 5 AM, 15 TV stations; 1
Indian Ocean and 2 Atlantic Ocean ~
INTELSAT stations, all inactive; 3 subma-
rine coaxial cables, all inactive; radio-relay
to Jordan and Syria, inoperable
Defense Forces
Branches: Army, Navy, Air Force
140','521f5150ca4b513aafb76f8cfb85eec2105f12bd40eb8a60406f9a68d12f464e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('154f7995849a6ecd175048a9a7a7da899c28fe2442be3c3176d4d96b9fbd6042',1987,'ZA','South Africa','communications',406,'Railroads: 1.6 km; owned, operated, and
included in the statistics of the Republic of
Highways: 5,167 km total; 508 km paved;
1,585 km crushed stone, gravel, or stabi-
lized soil; 946 km improved earth, 2,128
km unimproved earth
Civil air: 1 major transport aircraft
Airfields: 28 total, 28 usable; 2 with per-
manent surface runways; 1 with runways
2,440-3,659 m, 3 with runways 1,220-
2,439 m
Telecommunications: modest system
consisting of a few land lines, a small
radio-relay system, and minor radiocom-
munication stations; 5,920 telephones (0.4
per 100 popl.); 2 AM, 2 FM stations; 1 TV
station planned; 1 Atlantic Ocean
INTELSAT station
Defense Forces
Branches: Army, Army Air Wing, Police
Department
Military manpower: males 15-49, 346,000;
187,000 fit for military service
400 km
Awalviea Bay
* Johanneaburg
Upington ,imbertay _ hadysmith
Bilpemfontein ®
"Oe Aar
South
Atlantic
Ocean
East London
Cape Town Port Elizabeth
oasetbaei
Indian Ocean
See regional map VII','c95b5e79727604aab67ba63ee4862a063983428b2e95cf100eb200e53daa3bc6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c680f7e1ec2d31cc47ad015ed0fe7391970bdf9f4b108eb33f0a2234ba59f4e2',1987,'LR','Liberia','communications',407,'See reglonal map VII Harper
Railroads: 480 km total; 328 km 1.435-
meter standard gange, 152 km 1.067-meter
narrow gauge; all lines single track; rail
systems owned and operated by foreign
steel and financial interests in conjunction
with Liberian Government
Highways: 10,087 km total; 603 km bitu-
minous treated, 2,848 km all-weather,
4,313 km dry-weather
Inland waterways: none
Ports: 3 major (Monrovia, Buchanan,
Greenville), 4 minor
Civil air: 2 major transport aircraft
Airfields: 80 total, 75 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: telephone and
telegraph service via radio-relay network;
main center is Monrovia; 8,500 telephones
(0.4 per 100 popl.); 3 AM, 4 FM, 5 TV
stations; ] Atlantic Ocean satellite station
Defense Forces
Branches: Armed Forces of Liberia,
Liberia National Coast Guard
Military manpower: males 15-49, 569,000;
304,000 fit for military service; no con-
scription','712f65ce3ef834b354c7866e4269b9d29c41a0e7dfae24af0653f8ea497f761d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ad55a4981b2fc34401994b327875f4ad5faab624f1febbc3ce11fb0d9ceff6d',1987,'LY','Libya','communications',412,'ES
TRIPOLI Mediterranean Sea
6 Tobruk
Misratah \\ Guif of Sidra\\ Banghazt
400 km
See regional map VIL
Railroads: none
Highways: 19,300 km total; 10,800 km
bituminous and bituminous treated, 8,500
km gravel, crushed stone and earth
Pipelines: crude oil 4,383 km; natural gas
1,947 km; refined products 443 km (in-
cludes 256 km liquid petroleum gas)
Ports: 4 major (Tobruk, Tripoli, Banghazi,
Misratah), 2 secondary, 15 minor, and 6
petroleum terminals
Civil air: 75 major transport aircraft
Airfields: 127 total, 115 usable; 45 with
permanent-surface runways, 8 with run-
ways over 3,659 m, 25 with runways
2,440-3,659 m, 88 with runways
1,220-2,489 m
Telecommunications: 16 AM, 3 FM, 12
TV stations; 175,000 TV sets; 167,000
receiver sets; ] satellite ground station
Defense Forces
Branches: Armed Forces of the Libyan
Arab Jamahariya (including Army, Arab
Air Force, Air Defense Command, Arab
Navy)
Military manpower: males 15-49, 905,000;
532,000 fit for military service; 44,000
reach military age (17) annually; conscrip-
tion now being implemented
144
Liechtensteine','51121c3fe1cb695277d39d63bce4f7e40f5303f2df0893c21c878e6ec6bac4a1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcb90c15ae571c4f9288e791f2d837bd305219e4f6e802308274785c1774b232',1987,'LI','Liechtenstein','communications',417,'Skm
See regional map V
Railroads: 18.5 km 1.435-meter standard
gauge, electrified; owned, operated, and
included in statistics of Austrian Federal
Railways
Highways: 130.66 km main roads, 192.27
km byroads
Civil air: no transport aircraft
Airfields: none
Telecommunications: automatic telephone
system serving about 21,400 telephones
(77.0 per 100 popl.); no broadcast facilities
Defense Forces
Defense is responsibility of Switzerland
Branches: Police Department','2acfb620546b23292916d96ddc6fc502bfb5fe0800ea49c96c06e5c9ea8373a8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2341a3fde820d0815c9953e25e037b155dc91b2f70694c7b4bd68e2d055264c5',1987,'LU','Luxembourg','communications',422,'Troisvier:
See regional map V
Railroads: Luxembourg National Railways
(CFL) operates 270 km 1.485-meter stan-
dard gauge; 162 km double track; 162 km
electrified
Highways: 5,108 km total; 4,995 km
paved, 57 km gravel, 56 km earth; about
80 km limited access divided highway
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 13 major transport aircraft
Airfields: 2 total, 2 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: adequate and
efficient system, mainly buried cables;
210,000 telephones (55 per 100 pop!.); 2
AM, 83 FM, 3 TV stations
Defense Forces
Branches: Army
Military manpower: males 15-49, 95,000;
80,000 fit for military service; 2,000 reach
military age (19) annually
Macau
2km
Zhujiang
Kou
iha de Coloane
See regional map VIII
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern
communication facilities maintained for
domestic and international services; 13,000
telephones; 4 AM and 8 FM radio broad-
cast transmitters; est. 75,000 radio receiv-
ers; international high frequency radio
communication facility; access to interna-
tional communications carriers provided
via Hong Kong and China
Defense Forces
Defense is responsibility of Portugal
Military manpower: males 15-49, 109,000,
63,000 fit for military service (1986 est.)','a1a2a7a6b91d375666abc4966d4da4d859e2e61c05e34903f31ccc67c2f7f348','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a726ca0d3b52bdf14dc3f11f1adf2c96ac07f755b1ae5d0d0a66bd266e0fcad',1987,'MG','Madagascar','communications',427,'k
3 a Antairanana
Mozembique
Channel
Indian
ANTANANARIVO, Ocean
Morondav:
Faradofay
See cegional map VIl
Railroads: 1,020 km 1.000-meter gauge
Highways: 40,000 km total; 4,694 km
paved, 811 km crushed stone, gravel, or
stabilized soil; remainder improved and
unimproved earth (est.)
Inland waterways: of local importance
only; isolated streams and small portions of
Canal des Pangalanes
Ports: 4 major (Toamasina, Antsiranana,
Mahajanga, Toliara)
Civil air: 8 major transport aircraft
Airfields: 157 total, 128 usable; 28 with
permanent-surface runways; 3 with run-
ways 2,440-8,659 m, 42 with runways
1,220-2,489 m
Telecommunications: fair system includes
open-wire lines, coaxial cables, and radio-
relay links; submarine cable to Bahrain; 1
Indian Ocean INTELSAT station; 96,000
telephones (0.9 per 100 popl.); 14 AM, no
FM, 24 TV stations
Defense Forces
Branches: Popular Army, Aeronaval
Forces (includes Navy and Air Force),
paramilitary Gendarmerie
Military manpower: males 15-49,
2,314,000; 1,380,000 fit for military ser-
vice; 98,000 reach military age (20) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $58.9 million; about 9%
of central government budget','2250fd0dbd26e8e4f0d16b0bf4e518ffad32b7f32e0096e04241b7b0d063004e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea07b9131afba10bc8a69c9a7d3e6372737c0d02da34cefd64a29e79607e6a52',1987,'MW','Malawi','communications',432,'Chisamula Island
Likoma Island
See regional map VII
Railroads: 789 km 1.067-meter gauge
Highways: 13,135 km total; 2,364 km
paved; 251 km crushed stone, gravel, or
stabilized soil; 10,520 km earth and im-
proved earth
Inland waterways: Lake Nyasa, 23,300
km?; Shire River, 144 km, 4 lake ports
Civil air: 6 major transport aircraft
Airfields: 50 total, 49 usable; 6 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m; 9 with runways
1,220-2,439 m
Telecommunications: fair system of
open-wire lines, radio-relay links, and
radio communication stations; 36,800
telephones (0.5 per 100 popl.); 7 AM, 2
FM, and 15 repeaters; no TV stations; 1
Indian Ocean and | Atlantic Ocean satel-
lite station
Defense Forces
Branches: Army, Army Air Wing, Army
Naval Detachment, paramilitary Police
Mobile Unit
Military manpower: males 15-49,
1,511,000; 767,000 fit for military service','1eda78c3b0c0c5d5e51308f79d7fe24d86ef5fa4bc8d1111201d5c323f1a722d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('558fbb114e652621050d94693db5c58260ba7ce8d13f4ad4612af0ca8456af3f',1987,'MY','Malaysia','communications',437,'x x Sarawak
ucking
Malacca ne
See regional map 1X
Railroads: Peninsular Malaysia—1,665 km
1.04-meter gange; 13 km double track,
government owned; Sabah—136 km 1.000-
meter gauge
Highways: Peninsular Malaysia—23,600
km (19,852 km hard surfaced, mostly
bituminous surface treatment and 4,248
km unpaved); Sabah—3,782 km;
Sarawak—1,644 km
Inland waterways: Peninsular Malaysia—
3,209 km; Sabah—1,569 km; Sarawak—
2.518 km
Ports: Peninsular Malaysia—3 major, 14
minor; Sabah—2 major, 3 minor; Sar-
awak—1 major, 9 minor
Civil air: about 28 major transport aircraft
Pipelines: crude oil, 707 km; natural gas,
879 km
Airfields: 126 total, 123 usable; 31 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m, 19 with runways
1,220-2,439 m
Telecommunications: Peninsular Malay-
sia—good intercity service provided
mainly by microwave relay; international
service good; good coverage by radio and
television broadcasts; 849,129 telephones
nationwide in 1984 (5.3 per 100 popl.); 17
AM, 2 FM, 20 TV stations; submarine
cables extend to India and Sarawak; con-
nected to SEACOM submarine cable
terminal at Singapore by microwave relay;
2 international satellite ground stations; 1
domestic satellite ground station; Sabah—
adequate intercity radio-relay network
extends to Sarawak via Brunei; 6 AM, 1
FM, 7 TV stations; SEACOM submarine
cable links to Hong Kong and Singapore; 1
satellite ground station; Sarawak—ade-
quate intercity radio-relay network ex-
tends to Sabah via Brunei; submarine cable
to Peninsular Malaysia; 5 AM, no FM, 6
TV stations; ] satellite ground station
Defense Forces
Branches: Royal Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air
Force, Royal Malaysian Police Force
Military manpower: males 15-49,
4,180,000; 2,552,000 fit for military ser-
vice; 172,000 reach military age (21)
annually
External defense dependent on loose Five
Power Defense Agreement (FPDA), which
replaced Anglo-Malayan Defense Agree-
ment of 1957 as amended in 1963
Military budget: for fiscal year ending 31
December 1987, $937 million; about 9.9%
of central government budget','9360991750eded78e399d5880272e44e42e4b7611431f82f8521e6efefad023e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa66a673457680a016c2ba9cd1fe80bc1e8f2a513de346a7f4a61fb889e46fb4',1987,'ML','Mali','communications',446,'-Koves
See regional map VIL
oO
>
ia)
1c)
fo}
: : >
w
28
oy
United Nations Organizations
FAQ GATT
UPU WIHIOQ WMO
ITU UNESCO
IBRD ICAO ICJ IDA IFAD IFC ILO IMF IMO
IAEA
OPEC SELA WFTU
OAU OECD OIC
i
Le TY ea eet eee ee samme ag a masea Se ee ee ae Seas Ee es eT eR aT Ree ae Sen Te ner ae ee Oe eer ee P
l ‘ el 2 i ja ;
¥ "ah 7 4
LE CoN, Reset Sa AE a MRT ree Regen On nee? PTAA a ee et eo Ta Mean ne ne Ree eS Re en ee eee ee ee ee a ee Sones ees Ree fees eee ca
@ J i Pat?
Bn Rr ets a ee TE ee OS CO RT Ce eS en ee ee ee Cee eee ee ee nF ARRRRAUARRRR
I
i
fF & ''
H 4 : 3
f f q
285
Country International Organizations
ADB ARAB ASEAN CACM CARICOM CEMA EC G-77. GCC 1DB? 1 twB> INTELSAT LAIA| NAM NATO OAPEC OAS','d81f0e969c8305413862a9400ccabbb052014f5b5adeac8a329f631a67f3999c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4717ec3a8557187fcbfe2fa4845a46957562eb9384a9b869800f4b6c10c3c624',1987,'MT','Malta','communications',451,'——— km
Mediterranean
ap ‘emmune Sea
Mediterranean
Sea
” Filla
See regional map V
Highways: 1,291 km total; 1,179 km
paved (asphalt), 77 km crushed stone or
gravel, 35 km improved and unimproved
earth
Ports: 2 major (Valletta, Marsaxlokk is
under development), 1 secondary, 1 minor
Civil air: 8 major transport aircraft
156
Airfields: 1 total, 1 usable with
permanent-surface runways 2,440-3,659 m
Telecommunications: modern automatic
system centered in Valletta; 125,000 tele-
phones (84.6 per 100 popl.); 7 AM, 4 FM,
2 TV stations; 1 coaxial submarine cable
Defense Forces
Branches: Armed Forces, Police, Task
Force, Paramilitary Dejima Force
Military manpower: males 15-49, 98,000;
79,000 fit for military service
Military budget: for fiscal year ending 31
December 1984, $12.2 million; about 2.5%
of central government budget
Man, Isle of
i10km
Irish Sea
lrish Sea
See regional map V
Railroads: 36 km electric track, 24 km
steam track
Highways: 640 km motorable roads
Ports: 3 (Douglas, Ramsey, Peel)
Airfields: 2 total; 1 usable with
permanent-surface runways; 1 with run-
ways 1,220-2,439 m
Telecommunications: radio station; 24,435
telephones
Defense Forces
Defense is the responsibility of the United
Kingdom
Martinique¢','93ad2ac399ecb194ca47acdc6db8fbecd7f3fd36ba7672e1c72fe4c32ddb50b5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('552026f23f71f30c6593ab5319bf52b65a737ba09787c6f935fc8f61db104be8',1987,'MQ','Martinique','communications',456,'—1Okm
Caribbean
Sea
Caribbaan
Sea
Le Vauclin
See regional map Ill
Railroads: none
Highways: 1,680 km total; 1,300 km
paved, 380 km gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport aircraft
Airfields: 3 total; 3 usable; 1 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: domestic facilities
are adequate; 68,900 telephones (21.5 per
100 popl.); interisland radio-relay links to
Guadeloupe, Dominica, and St. Lucia; 2
Atlantic Ocean satellite antennas; 1 AM, 7
FM, 10 TV stations
Defense Forces
Defense is responsibility of France
Military manpower: males 15-49, 92,000','a640cd2f4a4a7c9c02f688a413a24c15eac283421f550a460d1a9a87c04a37fd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93307c873506002508d7c5b5f5392027ad734c24845f5ddebf602ea19f0e575e',1987,'MR','Mauritania','communications',461,'North
Atlantic
Ocean
See regional map VI1
Railroads: 740 km 1.435-meter standard
gauge, single track, privately owned
Highways: 7,540 km total; 1,350 km
paved; 710 km gravel, crushed stone, or
otherwise improved; 5,480 km unimproved
Inland waterways: 800 km
Ports: 2 major (Nouadhibou and
Nouakchott)
Civil air: 2 major transport aircraft
Airfields: 31 total, 30 usable; 10 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m; 16 with runways
1,220-2,439 m
Telecommunications: poor system of
cable and open-wire lines, minor radio-
relay links, and radio communications
stations; 5,200 telephones (0.3 per 100
popl.); 2 AM, no FM, 1 TV stations; 1
Atlantic Ocean and 2 ARABSAT satellite
ground stations
Defense Forces
Branches: Army, Navy, Air Force, para-
military Gendarmerie, paramilitary Na-
tional Guard, paramilitary National Police,
paramilitary Presidential Guard, paramili-
tary Nomad Security Guards
Military manpower: males 15-49, 412,000;
200,000 fit for military service; conscrip-
tion law not implemented
160','57595b5dce68ac81e7e934213e3e9453163d2595b73c8914535afe8c909e449d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60f121a5aba9f9eb79e53ea2d05e239b0a42bfb772ed8cc2f68c1b980b4d359d',1987,'MU','Mauritius','communications',466,'Agalaga Islands. Cargedoa
Carajos Shoals, and
Rodriguas ara not shown
eit
° Goodlands
Triolat
Indian
Ocean
Quatre Bornes
Indian
* ,
coceive Ocean
See regional map VII
Highways: 2,000 km total; 1,200 km
paved, 800 km earth
Ports: 1 major (Port Louis)
Civil air: 8 major transport aircraft
Airfields: 5 total, 4 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: small system with
good service; new microwave link to
Reunion; high-frequency radio links to
several countries; 48,000 telephones (4.7
per 100 popl.); 2 AM, no FM, 4 TV sta-
tions; 1 Indian Ocean satellite station
Defense Forces
Branches: paramilitary Special Mobile
Force, Special Support Units, regular
Police Force
Military manpower: males 15-49, 297,000,
154,000 fit for military service
Military budget: for fiscal year ending 30
June 1983, $13.45 million; 3.2% of central
government budget
Railroads: none
Highways: 2,800 km total; 2,200 km
paved, 600 km gravel, crushed stone, or
stabilized earth
Ports: 1 major (Port de la Pointe des
Galets at Le Port)
Civil air: 1 major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,489 m
204
Telecommunications: adequate system for
needs; modern open-wire line and radio-
relay network; principal center Saint-
Denis; radiocommunication to Comoros
Islands, France, Madagascar; new radio-
relay route to Mauritius; 85,900 telephones
(15.9 per 100 popl.); 8 AM, 13 FM stations;
2 TV stations with 17 relay transmitters; 1
Indian Ocean satellite station
Defense Forces
Defense is the responsibility of France
Military manpower: males 15-49, 144,000;
75,000 fit for military service; 6,000 reach
military age (18) annually','26982448fa303de25475094ac8236a082e4ca551330e9ba325267d7d78746601','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe463968a6a812ef1dec6be0cbce595dea68b19f9dc07259a022922a92e20ca5',1987,'MX','Mexico','communications',475,'Pacific
Ocean
See regional map Il
Railroads: 20,680 km total; 19,950 km
1.435-meter standard gauge; 730 km
0.914-meter narrow gauge
Highways: 210,000 km total; 65,000 km
paved, 30,000 km semipaved or cobble-
stone, 60,000 km rural roads (improved
earth) or roads under construction, 55,000
km unimproved earth roads
Inland waterways: 2,900 km navigable
rivers and coastal canals
Pipelines: crude oil, 4,100 km; refined
products, 6,875 km; natural gas, 11,900 km
Ports: 11 major, 20 minor
Civil air: 174 major transport aircraft
Airfields: 1,905 total, 1,715 usable; 182
with permanent-surface runways; 3 with
runways over 3,659 m, 28 with runways
2,440-3,659 m, 273 with runways
1,220-2,439 m
Telecommunications: highly developed
system with extensive radio-relay links;
connection into Central American micro-
wave net; 6.41 million telephones (8.9 per
100 popl.); 650 AM, 120 TV, and about
180 low-power TV relay stations; 120
domestic satellite terminals; 2 Atlantic
Ocean satellite ground antennas
Defense Forces
Branches: Army, Air Force, Navy, Marine
Corps
Military manpower: males 15-49,
19,784,000; 14,489,000 fit for military
service; 1,030,000 reach military age (18)
annually
Military budget: for year ending 31
December 1986, $630.1 million; 1.2% of
central government expenditures, includ-
ing support of parastatals
164
Railroads: 4,242 km 1.435-meter standard
gauge; Norwegian State Railways (NSB)
operates 4,242 km (2,442 km electrified
and 96 km double track)
Highways: 79,540 km total; 18,600 km
concrete, bituminous, stone block; 19,980
km bituminous treated; 40,960 km gravel,
crushed stone, and earth
Inland waterways: 1,577 km; 1.5-2.4 m
draft vessels maximum
Norway (continued)
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 62 major transport aircraft
Airfields: 101 total, 100 usable; 59 with
permanent-surface runways; 12 with
runways 2,440-3,659 m, 16 with runways
1,220-2,439 m
Telecommunications: high-quality domes-
tic and international telephone, telegraph,
and telex services; 2.7 million telephones
(62.2 per 100 popl.); 8 AM, 1,013 FM,
1,800 TV stations; 4 coaxial submarine
cables; 10 domestic satellite stations
Defense Forces
Branches: Royal Norwegian Army, Royal
Norwegian Navy, Royal Norwegian Air
Force
Military manpower: males 15-49,
1,074,000; 908,000 fit for military service;
34,000 reach military age (20) annually
Military budget: for fiscal year ending 31
December 1986, $2.1 billion; 8.7% of
central government budget
Railroads: none
Highways: 16,900 km total; 2,200 km
bituminous surface, 14,700 km motorable
track
Pipelines: crude oil 1,300 km; natural gas
1,080 km
Ports: 2 major, 5 minor
Civil air: 27 major transport aircraft,
including multinationally owned Gulf Air
Fleet
Airfields: 124 total, 119 usable; 6 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 57 with runways
1,220-2,439 m
Telecommunications: fair system of
open-wire, radio-relay, and radio commu-
nications stations; 23,000 telephones (2.2
per 100 popl.); 3 AM, 3 FM, 11 TV sta-
tions; 1 Indian Ocean INTELSAT station,
8 domestic satellite stations, 1 ARABSAT
satellite station
Defense Forces
Branches: Army, Navy, Air Force, Royal
Oman Police
Military manpower: males 15-49, 290,000;
165,000 fit for military service
Military budget: for fiscal year ending 3]
December 1986, $1.6 billion; 32% of
central government budget
189
Railroads: 27,092 km total; 23,961 km
1.435-meter standard gauge, 397 km
].524-meter broad gauge, 2,734 km nar-
row gauge; 8,964 km double track; 8,902
km electrified; government owned (1985)
Highways: 299,887 km total; 130,000 km
improved hard service (concrete, asphalt,
stone block); 24,000 km unimproved hard
service (crushed stone, gravel); 100,000 km
earth; 4,588 km other urban roads (1985)
Inland waterways: 3,989 km navigable
rivers and canals (1985)
Pipelines: 4,500 km for natural gas; 1,986
km for crude oil (1984); 360 km for re-
fined products
Freight carried: rail—419.4 million metric
tons, 120.6 billion metric ton/km (1985);
highway—1,394 million metric tons, 36.5
billion metric ton/km (1985); inland water-
way—14.54 million metric tons, 1.41
billion metric ton/km (1985); ocean—
177.75 billion metric ton/km (1985)
Ports: 4 major (Gdansk, Gdynia, Szczecin,
Swinoujécie), 12 minor (1979); principal
inland waterway ports are Gliwice,
Wroclaw, and Warsaw (1979)
Civil] air: 42 major transport aircraft
Airfields: 160 total; 36 with runways 2,500
m or longer
Telecommunications: 24 AM, 28 FM, 41
TV stations; 4 Soviet TV relays; 8,864,768
TV sets; 9,286,663 receiver sets; at least 1
satellite ground station
Defense Forces
Branches: Ground Forces, National Air
Defense Forces, Air Force Command,
Navy
Military manpower: males 15-49,
9,398,000; 7,453,000 fit for military ser-
vice; 267,000 reach military age (19)
annually
Military budget: announced for fiscal year
ending 31 December 1986, 371.6 billion
zlotys; 8.1% of total budget
200
Railroads: 2,943 km total; 2,371 1.000-
meter gauge, 130 km standard gauge, 230
km dual gauge, 212 km unoperable
Highways: about 85,000 km total; 9,400
km bituminous, 48,700 km gravel or
improved earth, 26,900 km unimproved
earth
Pipelines: 150 km, refined products
Inland waterways: about 17,702 km
navigable; more than 5,149 km navigable
at all times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: controlled by military
Airfields: 217 total, 128 usable; 46 with
permanent-surface runways; 12 with
runways 2,440-3,659 m, 28 with runways
1,220-2,439 m
Telecommunications: 16 AM, 1 FM, 2 TV
stations, 2,300,000 TV sets; 6,000,000
receiver sets; at least 2 satellite ground
stations
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
15,026,000; 9,582,000 fit for military
service; 735,000 reach military age (17)
annually
Military budget: no expenditure estimates
are available; military aid from the USSR
has been so extensive that actual allocation
of Vietnam’s domestic resources to defense
has not been indicative of total military
effort
263
Monaco‘','31c020c709e0d3c7b578de2105ba3ddcc759f8804f791a9872af62f066155bf3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b47a7b9c60965ccfc549e4c61b606f5847249cbfb4401804e46d7fc289d689e5',1987,'MN','Mongolia','communications',484,'Erdenst * net
*
Choybatsan
*
ULAANGAATAR
Saynahand,
Datandzadgad,
*
Altay
See regional map VIII
Railroads: 1,748 km (1984); all 1.524-
meter broad gauge
Highways: 47,600 km total; 900 km hard
surface; 46,700 km other surfaces (1984)
Inland waterways: 397 km of principal
routes (1984)
Freight carried: rail—10.7 million metric
tons, 3,609 million metric tons/km; high-
way—32.4 million metric tons, 1,837
million metric tons/km; waterway—0.03
million metric tons, 4.2 million metric
tons/km (1984)
Civil air: 22 major transport aircraft
Airfields: 32 total; 17 with runways
2,500 m or longer
166
Telecommunications: 13 AM and 1 FM
stations; 1 main TV center and 18 provin-
cial relay stations plus relay of Soviet TV;
60,000 TV sets; 180,000 receiver sets; at
least 1 satellite ground station
Defense Forces
Branches: Mongolian People’s Army, Air
Force
Military manpower: males 15-49, 467,000;
305,000 fit for military service; 23,000
reach military age (18) annually
Military budget: for fiscal year ending 31
December 1977, 405 million tugriks, 12%
of total budget','b4d603e7f83d5f2d5ef424ed21d98a4e49b788266d534a1579894b47bd20a3ad','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96b4569f7ba80e913d273e8e6f43eff347d4ccd6bd2b748785ada0a5f38c851',1987,'MS','Montserrat','communications',489,'Caribbean
St Pater’s Sea
See regional map UII
Railroads: none
Highways: 280 km total; about 200 km
paved, 80 km gravel and earth
Inland waterways: none
Ports: 1 major (Plymouth)
Airfields: 1 total, 1 with permanent-
surface runway 1,036.32 m
Telecommunications: 3,000 telephones, 26
telex (1984); 9 AM, 1 FM, 2 TV stations
Defense Forces
Defense is the responsibility of the','3ba34f998be0686141762923f12e4208522e996026b7dea2c0a45dc305b84cb0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef60757fbf0a897afec82d2b2675f0687c83d67359d07225bb4adac1a64ac118',1987,'MA','Morocco','communications',494,'300 km Mediterranean Sea
Ceuta (Sp.)
Tenaie Matille(Sp.)
North
Atlantic _ Bou Arta
@Marrakach
See regional map VII
Railroads: 1,779 km 1.435-meter standard
gauge, 178 km double track; 792 km
electrified
Highways: 58,000 km total; 25,750 km
bituminous treated, 32,250 km gravel,
crushed stone, improved earth, and unim-
proved earth
Pipelines: 862 km crude oil; 491 km
(abandoned) refined products; 241 km
natural gas
Ports: 10 major (including Spanish-
controlled Ceuta and Melilla), 14 minor
Civil air: 22 major transport aircraft
Airfields; 78 total, 72 usable; 26 with
permanent-surface runways; 2 with run-
ways over 8,659 m, 14 with runways
2,440-3,659 m, 28 with runways
1,220-2,489 m
Telecommunications: good system com-
posed of wire lines, cables, and radio-relay
links; principal centers Casablanca and
Rabat, secondary centers Fés, Marrakech,
Oujda, Tangier and Tétouan; 270,100
telephones (1.2 per 100 popl.); 14 AM, 6
FM, 47 TV stations; 5 submarine cables; 2
Atlantic Ocean INTELSAT stations; radio-
relay to Gibraltar, Spain, and Western
Sahara; coaxial cable to Algeria
Defense Forces
Branches: Royal Moroccan Army, Royal
Moroccan Navy, Royal Moroccan Air
Force, Royal Gendarmerie
Military manpower: males 15-49,
5,596,000; 3,561,000 fit for military ser-
vice; 276,000 reach military age (18)
annually; limited conscription
Military budget: for fiscal year ending 31
December 1986, $839 million; 15% of
central government budget
169','0aabb259bfd732df44883f1e5287fc855bb8ab0b04bbd8da0f828989a4563f37','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0520fd1fb91b0e3a55e5d97ab4b83bbf64930cb56a3904ed95a074155f0ce27',1987,'MZ','Mozambique','communications',499,'400 km
Necala
‘Quelimana
Channel
Chicualacual
Vilanculoa
Inhambana
See regional map VII
Railroads: 3,436 km total; 3,288 km 1.067-
meter gauge; 148 km 0.750-meter narrow
gauge; (Malawi-Nacala, Malawi-Beira, and
Zimbabwe- Maputo lines are closed because
of insurgency)
Highways: 26,498 km total; 4,593 km
paved; 829 km gravel, crushed stone,
stabilized soil; 21,076 km unimproved
earth
Inland waterways: about 3,750 km of
navigable routes
Pipelines: 306 km crude oil (not operat-
ing); 289 km refined products
Ports: 3 major (Maputo, Beira, Nacala), 2
significant minor
Civil air: 5 major transport aircraft
Airfields: 241 total, 212 usable; 28 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m; 32 with runways
1,220-2,4389 m
170
Telecommunications: fair system of
troposcatter, open-wire lines, and radio-
relay; 57,400 telephones (0.5 per 100
popl.); 9 AM, 3 FM, and 1 TV stations; 1
Atlantic Ocean INTELSAT station; 3
domestic satellite stations
Defense Forces
Branches: Mozambique Armed Forces
(including Army, Border Guard, Naval
Command, Air Force)
Military manpower: males 15-49,
3,255,000; 1,868,000 fit for military service
Military budget: for fiscal year ending 31
December 1985, $240 million; 38% of
central government budget
Namibia‘
Nauru‘','a93a395e16bb45771b750bb139f32d0ad1054b8f87604fe27383f624e1357240','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad5e102ce5eb875cbe8a542e4505e510499eb4720d1ffc34f8c215160e19b3fe',1987,'NA','Namibia','communications',504,'Katima
Swakopmund, WINDHOEK E:
im ‘Go!
Boundary
representation 1s
not necessarily
authortatwe
South
Atlantic
Ocean
300 km
See regional map VII
Railroads: 2,340 km 1.067-meter gauge,
single track
Highways: 54,500 km; 4,079 km paved,
2,540 gravel, remainder earth roads and
tracks
Ports: | minor (Liideritz); relies on Walvis
Bay, South Africa
Civil air: 3 major transport aircraft
Airfields: 154 total, 141 usable; 21 with
permanent-surface runways; | with run- ~
ways over 3,659 m; 4 with runways
2,440-3,659 m, 66 with runways
1,220-2,439 m
Telecommunications: good urban, fair
rural services; radio-relay connects major
towns, wires extend to other population
centers; 62,800 telephones (5.5 per 100
popl.); 2 AM, 13 FM, 3 TV stations
Defense Forces
Defense is responsibility of Republic of
South Africa; however, a South-West
African Territory Force was established 1
August 1980 (includes an air element)
Military manpower: males 15-49, 281,000;
167,000 fit for military service
Military budget: for fiscal year ending 31
March 1984, $128.3; 8% of central govern-
ment budget
Railroads: 36,499 km total (includes Nam-
ibia); 35,793 km 1.067-meter gauge, of
which 6,830 km are multiple track, 16,27]
km electrified; 706 km single track
Highways: 229,690 km total; 80,796 km
paved, 148,894 km crushed stone, gravel,
or improved earth
Pipelines: 93) km crude oil; 1,748 km
refined products; 322 km natural gas
Ports: 7 major (Durban, Cape Town, Port
Elizabeth, Richards Bay, Saldanha, East
London, and Mosselbaai); 1 minor (Walvis
Bay)
Civil air; 82 major transport aircraft
Airfields: 956 total, 846 usable; 112 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 1] with runways
2,440-3,659 m, 215 with runways
1,220-2,439 m
Telecommunications: the system is the
best developed, most modern, and highest
capacity in Africa and consists of carrier-
equipped open-wire lines, coaxial cables,
radio-relay links, and radiocommunication
stations; key centers are Bloemfontein,
Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 3.47 million
telephones (13.4 per 100 popl.); 14 AM,
286 FM, 67 main TV stations with 450
relay transmitters; 1 submarine cable; |
Indian Ocean and 2 Atlantic Ocean
INTELSAT stations
Defense Forces
Branches: Army, Navy, Air Force, Medi-
cal Services
Military manpower: males 15-49,
8,490,000; 5,182,000 fit for military ser-
vice; 369,000 reach military age (18)
annually; obligation for service in Citizen
Force or Commandos begins at 18; volun-
teers for service in permanent force must
be 17; national service obligation is two
years; figures include Bophuthatswana,
Ciskei, Kwazulu, Lebowa, Transkei, and
Venda
224
Soviet Union
2000 km
Arctic Ocean
Barents Sea *i: | ne
Murmansk Be. rs
Baltic Saa y ‘
Leningrad :
*, u Othoisk
"kiay MOSCOW : &
° Svardiovsk
The Unstad States Government has not recognized
the incorporation of Eatoma Lata and Lithuania
into tha Sowat Union Other boundary representation
19 NOt Naceasarily authoritative
See regional maps VIII and XI
Railroads: 144,800 km total; 142,967 km
1.524-meter broad gauge; 1,833 km mostly
0.750-meter narrow gauge; 113,315 km
broad-gauge single track; 47,900 km elec-
trified; does not include industrial lines
(1984)
Highways: 1,516,700 km total; 439,000
km asphalt, concrete, stone block; 354,000
km asphalt treated, gravel, crushed stone;
723,700 km earth (1984)
Inland waterways: 136,700 km navigable,
exclusive of Caspian Sea (1984)
Freight carried: rail—3,958 million metric
tons, 3.72 trillion metric tons/km (1985);
highways—25.5 billion metric tons, 477
billion metric tons/km (1985); waterway—
632 million metric tons, 261.6 billion
metric tons/km, excluding Caspian Sea
(1984)
Pipelines: 78,300 km crude oil and refined
products; 165,000 km natural gas (1984)
Ports: 53 major (most important—Lenin-
grad, Riga, Tallinn, Kaliningrad, Liepaja,
Ventspils, Murmansk, Arkhangel’sk,
Odessa, Novorossiysk, !l’ichevsk, Niko-
layev, Sevastopol’, Vladivostok, Nakhodka),
180 minor; 58 major inland ports (most
important—Astrakhan’, Baku, Gor’kiy,
Kazan’, Khabarovsk, Krasnoyarsk,
Kuybyshev, Moscow, Rostov, Volgograd,
Kiev)
Civil air: 4,500 major transport aircraft
Airfields: 4,400 total; 470 with runways
2,500 m or longer
Telecommunications: extensive network
of AM-FM stations broadcasting both
Moscow and regional programs; main TV
centers in Moscow and Leningrad plus 11
more in the Soviet republics; hundreds of
TV stations; 85,000,000 TV sets;
162,000,000 receiver sets; many satellite
ground stations and extensive satellite
networks
Defense Forces
Branches: Ground Forces, Navy, Air
Defense Forces, Air Forces, Strategic
Rocket Forces
Military manpower: males 15-49,
69,563,000; 55,293,000 fit for military
service; 2,197,000 reach military age (17)
annually','abcc7aab8b4b5a19f288532c3caa9c37b9de960ea8c5c9242a8423af86840fbf','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69925f7ce17d5a7b6c5b3e42ef145c5c87c5197321e198078e20aa90bc023a96',1987,'NR','Nauru','communications',509,'tkm
South
Pacific
Ocaan
Phosphate
facilities
South
Pacific
Ocean
See regional map X
Railroads: none
Highways: about 27 km total; 21 km
paved, 6 km improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 8 major transport aircraft, one
on order
Airfields: 1 total, 1 usable with
permanent-surface runways 1,220-2,439 m
Telecommunications: adequate intraisland
and international radio communications
provided via Australian facilities; 1,600
telephones (20.8 per 100 popl.); 4,000 radio
receivers, 1 AM, no FM, no TV stations; 1
satellite ground station
Defense Forces
No formal defense structure and no regu-
lar armed forces
Military manpower: males 15-49, 2,300;
fit for military service, 1,200; 100 reach
military age (18) annually','da821d416f0fa702885622166de6e7f7de825e7149e42153154dbe2f9736de55','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38e63169315ede81bb9850097ebbab14d4509d5e5135b858590d18b44f0e73cd',1987,'NP','Nepal','communications',514,'200. km
See regional map VIII
Railroads: 52 km (1985), all 0.762-meter
narrow gauge; all in Tarai close to Indian
border; 10 km from Raxaul to Birganj is
government owned
Highways: 5,958 km total (1986); 2,645
km paved, 815 km gravel or crushed
stone, 2,257 km improved and unim-
proved earth; additionally 241 km of
seasonally motorable tracks
Civil air: 5 major and 11 minor transport
aircraft
Airfields: 38 total, 38 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 8 with runways
1,220-2,489 m
Telecommunications: poor telephone and
telegraph service; fair radio communica-
tion and broadcast service; international
radio communication service is poor;
18,400 telephones (0.1 per 100 popl.); 4
AM, 1 TV stations; 1 satellite ground
station
Defense Forces
Branches: Royal Nepalese Army, Royal
Nepalese Army Air Service, Nepalese
Police Force
Military manpower: males 15-49,
4,171,000; 2,157,000 fit for military ser-
vice; 197,000 reach military age (17)
annually
Military budget: for fiscal year ending 15
July 1987, $32 million; 5% of central
government budget
174','0763aff3b2e6edabb678a7a9ab45d38933ff7a24c006a9e0bb153dd1c45f148e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d9f5ee31f8eddd98dca018aa18976d50d8f41627a668360b221fed0f2e71ecc',1987,'NL','Netherlands','communications',519,'See regions! map V
Railroads: Netherlands Railways (NS)
operates 2,824 km 1.435-meter standard
gauge; 3,033 km total track; 1,824 km
electrified, 1,800 km double track, 166 km
privately owned
Highways: 108,360 km total; 92,525 km
paved (including 2,185 km of limited
access, divided highways); 15,835 km
gravel, crushed stone
Inland waterways: 6,340 km, of which
85% is usable by craft of 900 metric ton
capacity or larger
Pipelines: 418 km crude oil; 965 km
refined products; 10,230 km natural gas
Ports: 10 major, 2 minor
Civil air: 98 major transport aircraft
Airfields: 29 total, 28 usable; 19 with
permanent-surface runways; 18 with
runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: highly developed,
well maintained, and integrated; extensive
system of multiconductor cables, supple-
mented by radio-relay links; 8.84 million
telephones (57.5 per 100 popl.); 6 AM, 41
FM, 30 TV stations; 9 submarine cables; 1
satellite station with 2 Atlantic Ocean and
2 Indian Ocean antennas
Defense Forces
Branches: Royal Netherlands Army, Royal
Netherlands Navy/Marine Corps, Royal
Netherlands Air Force
Military manpower: males 15-49,
4,064,000; 3,620,000 fit for military ser-
vice; 124,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1986, $5.3 billion; about 9.3%
of central government budget
Netherlands Antilles
50 km
Islands nat shawn in true
geographical position
Sint Maarten
Caribbean Sea Ebiligsnurg
Sabano
Westpunt & \\ Curacao
3
Kralendij
WILLEMSTAO
. Bonaire
See regional map 111]
Railroads: none
Highways: 950 km total; 300 km paved,
650 km gravel and earth
Ports: 3 major (Willemstad, Philipsburg,
Kralendijk); 6 minor (of which 4 are signif-
icant ports for petroleum tankers)
Civil air: 5 major transport aircraft
Airfields: 7 total, 7 usable; 7 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: generally adequate
facilities; extensive interisland radio-relay
links; 65,000 telephones (24.6 per 100
popl.); 7 AM, 5 FM, and 1 TV stations; 2
submarine cables; 2 Atlantic Ocean satel-
lite antennas
Defense Forces
Defense is responsibility of the Nether-
lands
Military manpower: males 15-49, 49,000,
28,000 fit for military service; 2,000 reach
military age (20) annually
177
Netherlands Antilles¢
New Caledonia‘','2692a4f2c091c88ec5553ea43106dba90107490390c9a62a975d39d93b6268ff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfaccafd27657ba1e79a4126455929302291ea9d6d0d5e3c9ed67a2984131330',1987,'NC','New Caledonia','communications',524,'150 km
Coral Sea
South
Pacific
Ocean
Coral Sea “jle des Pins
Islands of Huon end
SteregionalmapX Chesterfield era not shown,
Railroads: none
Highways: 5,448 km total; 558 km paved,
2,251 km improved earth, 2,689 km unim-
proved earth
Inland waterways: none
Ports: 1 major (Nouméa), 21 minor
Civil air: no major transport aircraft
Airfields: 29 total, 28 usable; 4 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,489 m
Telecommunications: 32,000 telephones
(21 per 100 popl.); 5 AM, 3 FM, 7 TV
stations; 1 satellite ground station
Defense Forces
Defense is the responsibility of France
178','52cf0876f3780710afb40feffd5db165a9dd0d1773a1479a2e496bf4284cd1a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef18d91aa76d8f5bd0af68e35207e8e901127b42b971e055eeecf71ef52493cc',1987,'NZ','New Zealand','communications',529,'500 km Kermadec | ;
Islands °
South
Pacific
2 Ocaan
Tasman
Sea North Island
Aucklan 3
Naw Plymouth ‘Gisborne
ELLINGTON
Christchurch ‘3. Chetham
* Islende
South Island
See reglonal map X','5dc00fce3d9a45faf9e5699e5b1c3b30b7117aec3d8cd492a91bf103ede577f8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0189545761d6c7e85c3680aaeceed7c51c04fdee9a6d951b358e6b3cdcadc41',1987,'TK','Tokelau','communications',535,'Railroads: 4,716 km total (1980); all 1.067-
meter gauge; 274 km double track; 113
km electrified; over 99% government
owned
Highways: 92,648 km total maintained
(March 1984); 49,547 km paved, 43,101
km gravel or crushed stone
Inland waterways: 1,609 km; of little
importance to transportation
Pipelines: 1,000 km natural gas; 160 km
refined products; 150 km condensate
Ports: 3 major
Civil air: about 40 major transport aircraft
Airfields: 205 total, 197 usable; 27 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m; 51 with runways
1,220-2,489 m
Telecommunications: excellent interna-
tional and domestic systems; 2.01 million
telephones (60.8 per 100 popl.); 64 AM, 2
FM, 14 TV stations, and about 400 repeat-
ers; submarine cables extend to Australia
and Fiji; 1 satellite ground station
Defense Forces
Branches: Royal New Zealand Navy, New
Zealand Army, Royal New Zealand Air
Force
Military manpower: males 15-49, 881,000;
753,000 fit for military service; 31,000
reach military age (20) annually
Military budget: for fiscal year ending 31
March 1986, $500 million; about 5.1% of
central government budget
50km
id uv
South Pacific Ocean
. tNukunonu
ty
Fakaofo
See regional map X
Railroads: none
Highways: none
Ports: no natural harbor; offshore anchor-
ages
Airfields: none; lagoon landings by am-
phibious aircraft from Western Samoa
Telecommunications: telephone service
links islands to each other and to Western
Samoa (1985)
Defense Forces
Defense is the responsibility of New
Zealand
243','df7c583cfaaad3604bb61fb4a8356e866f375ad6b55e6e2e9603fe40618e3133','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b44646e79f66bf22dc4084e0e8f2047a328599850a1b682495f73ecd65e4f0de',1987,'NI','Nicaragua','communications',536,'«
Puerto Cabexea hey
isles dal
Maiz
See regional map Ul
Railroads: 344 km 1.067-meter gauge,
government owned; majority of system not
operating; 3 km 1.435-meter gauge line at
Puerto Cabezas (does not connect with
mainline)
Highways: 23,585 km total; 1,655 km
paved, 2,170 km gravel or crushed stone,
5,425 km earth or graded earth, 14,335
km unimproved
Inland waterways: 2,220 km, including 2
large lakes
Pipelines: crude oil, 56 km
181
Ports: 1 major (Corinto), 8 secondary, 13
minor
Civil air: 12 major transport aircraft
Airfields: 289 total, 241 usable; 10 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 12 with runways
1,220-2,439 m
Telecommunications: low-capacity radio-
relay and wire system being expanded;
connection into Central American micro-
wave net; 60,000 telephones (2.2 per 100
popl.); 41 AM, 4 HF, 7 TV stations; Inter-
sputnik communications satellite facility;
Atlantic Ocean satellite station
Defense Forces
Branches: Sandinista People’s Army,
Sandinista Navy, Sandinista Air Force/Air
Defense, Sandinista People’s Militia
Military manpower: males 15-49, 716,000;
448,000 fit for military service; 38,000
reach military age (18) annually
Military budget: estimated for fiscal year
ending 31 December 1986, $1.2-].6 billion;
50-65% of central government budget
(includes both defense and security expen-
ditures)','2b199e9f4b26ba1c0da08d47516c7e972bc3d71d00c97271f432f780be0a409b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddcc6430254af0822c0e23c743c197bbfc1b7f97df6d5547bfe980596b2fc06d',1987,'NE','Niger','communications',541,'See regional msp VII
Railroads: none
Highways: 39,970 km total; 3,170 km
bituminous, 10,330 km gravel and laterite,
8,470 km earthen, 23,000 km tracks
Inland waterways: Niger River navigable
800 km from Niamey to Gaya on the
Benin frontier from mid-December
through March
Civil air: 2 major transport aircraft
Airfields: 33 total, 32 usable; 7 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 13 with runways
1,220-2,439 m
Telecommunications: small system of
wire and radio-relay links concentrated in
southwestern area; 9,800 telephones (0.2
per 100 popl.); 9 AM, 2 FM, 12 TV sta-
tions; 2 Atlantic Ocean satellite stations, 4
domestic satellite stations
Defense Forces
Branches: Army, Air Force, paramilitary
Gendarmerie, paramilitary Republican
Guard, paramilitary Presidential Guard,
paramilitary National Police
Military manpower: males 15-49,
1,468,000; 787,000 fit for military service;
81,000 reach military age (18) annually','b90e98616fec9299d4085e9d8d65e75da9f7f8288bb9c9b5b7d25d04267df800','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44000c521ea3ae0aa35ce5a19546f4bbdeb9a566286725fbf978f7816a3fb423',1987,'NG','Nigeria','communications',546,'e
«Ogbomosho
-ibadan
» Mokurdi
LAGOS * Benin City
Bight of
Railroads: 3,505 km 1.067-meter gauge
Highways: 107,990 km total 30,019 km
paved (mostly bituminous surface treat-
ment); 25,411 km laterite, gravel, crushed
stone, improved earth; 52,560 km unim-
proved
Inland waterways: 8,575 km consisting of
Niger and Benue rivers and smaller rivers
and creeks
Pipelines: 2,042 km crude oil; 264 km
natural gas; 3,000 km refined products
Ports: 6 major (Lagos, Port Harcourt,
Calabar, Warri, Onne, Sapele), 9 minor
Civil air: 77 major transport aircraft
Airfields: 88 total, 84 usable; 31 with
permanent-surface runways; | with run-
ways over 3,659 m, 13 with runways
2,440-3,659 m, 23 with runways
1,220-2,489 m
Telecommunications: above-average
system limited by poor maintenance;
major expansion in progress; radio-relay
and cable routes; 155,000 telephones (0.2
per 100 popl.); 37 AM, 9 FM, 34 TV
stations; satellite station with Atlantic and
Indian Ocean antennas, domestic satellite
system with 19 stations; 1 coaxial subma-
rine cable
Defense Forces
Branches: Army, Navy, Air Force, para-
military Police Force
Military manpower: males 15-49,
25,027,000; 14,295,000 fit for military
service; 1,164,000 reach military age (18)
annually
184','c4226a8d19460129ae88d467d2b12c23bca467494c9d3e454dceb1d9d5733d28','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c807836c322c5fef0eedddf663dbca3b38bb2ca4c0ae86e7a26c978d1c91b378',1987,'NU','Niue','communications',549,'South
Pacitic
Oceen
See regional map X
Railroads: none
Highways: 123 km all-weather roads, 106
km access and plantation roads
Ports: no natural harbor; open roadstead
offers anchorage offshore from Alofi, from
where servicing is by small boat
Airfields: 1 total, ] usable with
permanent-surface runway of 1,650 m
(capable of taking intermediate-size jet
aircraft)
Telecommunications: single-line tele-
phone system connects all villages on
island; 383 telephones; 1,000 radio receiv-
ers (1983 est.); 1 radio station; no TV
service
Defense Forces
Defense is the responsibility of New
Zealand
185','d0b63c5ff1db78a4d7eed39f6f382edd30bc09dbd5f7bac7f30dba3b7fa4e2a2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98b43eae2761b9a8c5028aaf7a3a7b5e2785ec6eb32b341d18b3bb034e5fafd8',1987,'NF','Norfolk Island','communications',554,'« Bumt Pine
Narfolk Island
@Nepean
South
Pacific
Ocean
° Philip Island
See regional map X
Railroads: none
Highways: 80 km of roads, including 53
km of sealed roads; remainder are earth
formed or coral surfaced
Inland waterways: none
Ports: none; loading jetties at Kingston and
Cascade
Airfields: 1 total, 1 usable with
permanent-surface runways 1,220-2,489 m
(Australian-owned airport)
Telecommunications: 1,500 radio receiv-
ers (1982); radio link service with Sydney;
987 telephones (1982)
Defense Forces
Defense is the responsibility of Australia
186','5e28f8a4808124cd7ad8751160f529ded4d913b873e434f08c32de805b62a112','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6fba66a38afec52ea76cb38ff5d6fcc2bcef577f591773c5ffe9b0fb15e5ba9',1987,'NO','Norway','communications',559,'Barents
Sea
Hammarfaste,
Jan Mayen and Svatbard
ara not shown.
See regional maps V and X1','c189a5e9a0b1d0ced958fd20a055342a3de05aebe09cba2c9d9d41872e9f1146','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c2187ff57497ecdddc3446cc920cde073c33adfa4f728d0b9f52d04185d0a54',1987,'OM','Oman','communications',561,'Musendam
Peninsule ~~ Gu
300 km
Boundary representation 1s
not necessarily authoritative
JQ Mesirah
Arabien
Sea
See regional map V1
Arabian Sea
See regional msp VIII','75ee7d5cd9e77f205d86c94c1e195d7f488e65a8a1cebe05a3a1ef9a25e2d1be','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73fd114547a7f96bb69b263eeae64d2535ebb3b6024f62a2a1ba6d2832cd9281',1987,'PK','Pakistan','communications',563,'400 km
Gilgit ,
daromu And
pepe
Pashawer
s
Boundary representation is
not necesaarily authoritative
* ISLAMABAD
Gulf of
Railroads: (1985) 10,097 km total; 7,718
km broad gauge, 445 km meter gauge, and
610 km narrow gauge; 1,037 km broad
gauge double track; 286 km electrified;
government owned
Highways: 101,315 km total (1985); 40,155
km paved, 23,000 km gravel, 29,000 km
improved earth, and 9,160 km unim-
proved earth or sand tracks
Inland waterways: negligible
Pipelines: 250 km crude oil; 2,269 km
natural gas; 885 km refined products
Ports: 2 major, 4 minor
Civil air: 30 major transport aircraft
Airfields: 117 total, 99 usable; 70 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 29 with runways
2,440-8,659 m, 43 with runways
1,200-2,439 m
Telecommunications: good international
radiocommunication service over micro-
wave and INTELSAT satellite; domestic
radio communications poor; broadcast
service good; 474,000 telephones (0.3 per
100 popl.); 21 AM, 23 FM, 16 TV stations;
2 satellite ground stations
Defense Forces
Branches: Army, Air Force, Navy, Civil
Armed Forces, National Guards
Military manpower: males 15-49,
24,249,000; 14,865,000 fit for military
service; 1,196,000 reach military age (17)
annually
Military budget: for fiscal year ending 30
June 1986, $2.17 billion; about 33.6% of
central government budget','4b21c6af1d5ffee47d9d5a826c747665624c5e51afea39cb095a4cc1657597d3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f13ec4d5b9dad6cd762fecf97c54f29a41bb64dddfaf02fa1f92932b2e448193',1987,'PA','Panama','communications',567,'CaribbeanSea
30
Gulf of ta Patma
North Pacific Ocean
See regions! map 111
Railroads: 238 km total; 78 km 1.524-
meter gauge, 160 km 0.914-meter gauge
Highways: 8,530 km total; 2,745 km
paved, 3,270 km gravel or crushed stone,
2.515 km improved and unimproved earth
Inland waterways: 800 km navigable by
shallow draft vessels; 82 km Panama Canal
Pipelines: crude oil, 180 km
Ports: 2 major (Cristobal and Balboa), 8
minor
Civil air: 16 major transport aircraft
Airfields: 138 total, 183 usable; 44 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m; 16 with runways
1,220-2,489 m
Telecommunications: domestic and inter-
national facilities well developed; connec-
tion into Central American microwave net;
2 Atlantic Ocean satellite antennas;
220,000 telephones (10.5 per 100 popl.); 80
AM, 14 TV stations; 1 coaxial submarine
cable
Defense Forces
Branches: Defense Forces of the Republic
of Panama (formerly known as the Na-
tional Guard) includes military ground
forces (still designated National Guard),
Panamanian Air Force, National Navy,
Panama Canal Defense Force, police
force, traffic police/highway patrol, Na-
tional Department of Investigation, De-
partment of Immigration
Military manpower: males 15-49, 579,000;
400,000 fit for military service; no con-
scription
Military budget: for fiscal year beginning
1 January 1987, $104.6 million; about 4%
of central government budget','a7f452520b08cc1104b96c985a472f27fceb5a4835878b2194355b455c4a98f7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cf9b8c20a3502065bbe4ed65ed27bdd60368ff55b13d6203a2d97d8f4a19c3c',1987,'PG','Papua New Guinea','communications',572,'§00 km
South Pacific Ocean
oes « Scag
me = New Ireland
o of a?
* e
.
* = « . *
mee Qo ainville
New 9
Britain
Coral Ses
See regional map X','0f5b41a2b4d055c7a7f142ee4c09e03f55e5814038e7f44f3425c59703eb4da9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f40d26c100ea815b4551050b01328c2c0041003e395f5121016fc1345a7601d6',1987,'PY','Paraguay','communications',577,'Pedro
Juan
Cabaltaro
Boundary representation 1s
not necessarily authoritative
“Encarnacién
See regional map 1V
Railroads: 970 km total; 440 km 1.435-
meter standard gauge, 60 km 1.000-meter
gauge, 470 km various narrow gauge
(privately owned)
Highways: 21,960 km total; 1,788 km
paved, 474 km gravel, and 19,698 km
earth
Inland waterways: 3,100 km
Ports: ] major (Asuncién), 9 minor (all
river)
Civil air: 4 major transport aircraft
Airfields: 896 total, 791 usable; 6 with
permanent-surface runways; 2 with run-
ways 2,440-3,659 m, 39 with runways
1,220-2,489 m
Telecommunications: principal center in
Asuncion, fair intercity microwave net;
78,300 telephones (2.8 per 100 popl.); 41
AM, 3 TV, 8 shortwave stations; 1 Atlantic
Ocean satellite station
Defense Forces
Branches: Paraguayan Army, Paraguayan
Navy, Paraguayan Air Force
Military manpower: males 15-49, 997,000;
728,000 fit for military service; 46,000
reach military age (17) annually
Military budget: for fiscal year ending 31
December 1985, $66.1 million; 18.8% of
central government budget
195','c1d29173fbaa968c9cfaae71f15f325f096d4e0a1d50b7acfa5571453999018e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ad038bfbaa1c5c51f1977a1d4e9f9caa7d0a0684e5498248181e9beedf6d56c',1987,'PE','Peru','communications',582,'500 km
South
Pacific
Ocean
Lago
Titicaca
Boundary representation 18
not necessarily authoritative
See regional map !V
Railroads: 1,876 km total; 1,576 km 1.435-
meter standard gauge, 300 km 0.914-meter
gauge
Highways: 56,645 km total; 6,030 km
paved, 11,865 km gravel, 14,610 km
improved earth, 24,140 km unimproved
earth
Inland waterways: 8,600 km of navigable
tributaries of Amazon River system and
208 km Lago Titicaca
Pipelines: crude oil, 800 km; natural gas
and natural gas liquids, 64 km
Ports: 7 major, 25 minor
Civil air: 27 major transport aircraft
Airfields: 241 total, 225 usable; 33 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 23 with runways
2,440-3,659 m, 42 with runways
1,220-2,4389 m
Telecommunications: fairly adequate for
most requirements; nationwide radio-relay
system; 2 Atlantic Ocean satellite stations,
12 domestic antennas; 544,000 telephones
(2.9 per 100 popl.); 241 AM, 175 short-
wave, 136 TV stations
Defense Forces
Branches: Peruvian Army (Ejercito
Peruano), Peruvian Navy (Marina de
Guerra del Peru), Peruvian Air Force
(Fuerza Aerea del Peru)
Military manpower: males 15-49,
5,082,000; 3,441,000 fit for military ser-
vice; 223,000 reach military age (20)
annually','99d48fe6cb1e652f33df6af4a9c32e0f3e026c044e6f535cc4c1e56a65552b57','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb11c0eef918275f169ace1814011ca19767378b2f018a0c42ae37fb9fb1e8e',1987,'PH','Philippines','communications',587,'500 km ’
Philippine
South Sea
China SND
Sea Seone Say
3 Cab
Pal 4
‘ aa Negros (a) ¥
Sulu Sea 4
a
Zamboangaf/ A) Mindanao
“es
© CelebesSea .
See regional map 1X
Railroads: 378 km operable on Luzon
(1982), 34% government owned; 116 km
on Panay, privately owned
Highways: 156,000 km total (1984); 29,000
km paved; 77,000 km gravel, crushed
stone, or stabilized soil surface; 50,000 km
unimproved earth
Inland waterways: 3,219 km; limited to
shallow-draft (less than 1.5 m) vessels
Pipelines: refined products, 357 km
Ports: 10 major, numerous minor
Civil air: 53 major transport aircraft
Airfields: 319 total, 270 usable; 69 with
permanent-surface runways; 9 with run-
ways 2,440-3,659 m, 5] with runways
1,220-2,439 m
Telecommunications; good international
radio and submarine cable services; do-
mestic and interisland service adequate;
872,900 telephones (1.5 per 100 popl.); 267
AM stations, including 6 US; 55 FM sta-
tions; 33 TV stations, including 4 US;
submarine cables extended to Hong Kong,
Guam, Singapore, Taiwan, and Japan; 1
international satellite ground station; 1]
domestic satellite stations
Defense Forces
Branches: Army, Navy, Air Force, Con-
stabulary—Integrated National Police
Military manpower: males 15-49,
14,926,000; 10,557,000 fit for military
service; 649,000 reach military age (20)
annually (1986)
Military budget: for fiscal year ending 31
December 1987, $585 million; about 9.3%
of central government budget
Pitcairn Islands
: Sandy
Ct ,Henderson
Ducie,
ex ADAMSTOWN
Pitcairn -
South Pacific Ocean
See regional map X
a
Railroads: none
Highways: 6.4 km dirt roads
Ports: boat harbor and jetty at Bounty Bay
Airfields: none
Telecommunications: 24 telephones; party
line telephone service on the island; radio
station at Taro Ground; diesel generator
provides electricity
Defense Forces
Defense is the responsibility of the United
Kingdom','c44808f37a18b9f95a43b3f65ed65a7fca1ca3c7bca9d3dbeb45aaf68c5cba46','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13852065454148e37d29b80fd9da120764cb2affe1a71bbe3bc2d6088ddd6384',1987,'PL','Poland','communications',592,'Baltic Sea
Gdariak
qozezacin
« Bydgoszcz ie ache
Poznan
e WA RSAW
asa *
aWroctaw
dublin
a
Katowice
s Rreazéw
9 4
Krakow
Boundary representation ia
See regional map V not necessarily authoritative','f7ae66393585711820925630c79e35bfdcbb6d88fedf221f85d168d3aff80e47','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2271c9ba87690f251770a09035786872272a6a2ea2232d8b1e5c7941fb455c',1987,'PT','Portugal','communications',594,'128 km
North
Atlantic
Ocean
LISBON
Azores and Madeira
Islands are not shown
See regional map Vand VII
Railroads: 3,630 km total: state-owned
Portuguese Railroad Co. (CP) operates
2,858 km 1.665-meter gauge (434 km
electrified and 426 km double track), 760
km 1.000-meter gauge; 12 km (1.435-
meter gauge) electrified, double track,
privately owned
Highways: 57,499 km total; 61,599 km
paved (bituminous, gravel, and crushed
stone), including 140 km of limited-access
divided highway; 7,962 km improved
earth; plus an additional 4,100 km of
unimproved earth roads (motorable tracks)
Inland waterways: 820 km navigable;
relatively unimportant to national econ-
omy, used by shallow-draft craft limited to
297-metric-ton cargo capacity
Pipelines: crude oil, 11 km; refined prod-
ucts, 58 km
Portugal (continued)
Ports: 7 major, 34 minor
Civil air: 34 major transport aircraft
Airfields: 69 total, 65 usable; 35 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 11 with runways
2,440-3,659 m, 10 with runways
1,220-2,439 m
Telecommunications: facilities are gener-
ally adequate; 1.8 million telephones (16.6
per 100 popl.); 56 AM, 64 FM, 66 TV
stations; 6 submarine cables; 3 Atlantic
Ocean satellite antennas (on mainland and
Azores)
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
2,517,000; 2,048,000 fit for military ser-
vice; 87,000 reach military age (20) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $899 million; about 8.3%
of central government budget','052f821ef17837c60592ff5f894f803275db39964127e983d3d178ba47228e61','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e75b4d2f4609c0b6162856f3e07b5d2c3f6520e4fa54468d7322bec88acfe2f',1987,'QA','Qatar','communications',599,'50 km 7
Persian
Gulf
Hawar Islands are
disputed between ‘y
Bahrain and Qatar
Boundery representation ie
See regional map V1 not necessarily euthoritative.
2 a
Railroads: none
Highways: 840 km total; 490 km bitumi-
nous; 350 km gravel; undetermined mile-
age of earth tracks
Pipelines: crude oil, 235 km; natural gas,
400 km
Ports: 2 major (Doha, Musay‘id), 1 minor
Civil air; 3 major transport aircraft
Airfields: 4 total, 4 usable; 2 with
permanent-surface runways; ] with run-
ways over 3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: modern system
centered in Doha; 96,000 telephones (37
per 100 popl.); 1 Atlantic Ocean and 1
Indian Ocean satellite station; 1 Arab
satellite station under construction; tropo-
spheric scatter to Bahrain; radio-relay to
Saudi Arabia; submarine cable to Bahrain
and UAE; 2 AM, 1 FM, 8 TV stations
Defense Forces
Branches: Army, Sea Arm, Air Force,
Police Department
Military manpower: males 15-49, 122,000;
66,000 fit for military service
203
Reunion
15 km
Indian
Ocean
Saint-Paul i.
Saint-Bancit
,paint-Louls
Saint-Jozeph
Indian Ocean
See regional map VII
Reunion‘','8e5d34dccc553828f13051f3754c20dc27b185520a14366bb7546815de451540','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('416b079f8111fcb8023cb24e7b7df2cb5e19432cefe79b488feba1062a527eec',1987,'RO','Romania','communications',604,'200 km
Oradea asi
aciuj-Nspoce
Selitg 2 Sibiu
° Brasov, Galati
Timisoara re: a
BUCHAREST Constente
Craiova i
Giurgiu
See regional map V
Railroads: 11,106 km total; 10,589 km
1.435-meter standard gauge, 472 km
narrow gauge, 45 km broad gauge; 3,113
km electrified, 2,712 km double track;
government owned (1984)
Highways: 72,799 km total; 15,526 km
concrete, asphalt, stone block; 20,199 km
asphalt treated; 27,874 km gravel, crushed
stone, and other paved surfaces; 9,200 km
unpaved roads (1984)
Inland waterways: 1,724 km (1984)
Pipelines: 2,800 km crude oil; 1,429 km
refined products; 6,400 km natural gas
Freight carried: rail—289.8 million metric
tons, 75.2 billion metric ton/km; high-
way—417.7 million metric tons, 7.8 billion
metric ton/km; waterway—17.21 million
metric tons, 2.5 billion metric ton/km
(1984)
Ports: 4 major (Constanta, Galati, Braila,
Mangalia), 7 minor; principal inland ports
are Giurgiu, Drobeta-Turnu Severin, and
Orsova
Civil air: 70 major transport aircraft
Airfields: 160 total; 15 with runways
2,500 m or longer
Telecommunications: 37 AM, 30 FM, 35
TV stations; 3,910,000 TV sets; 3,225,000
receiver sets; 1 satellite ground station
Defense Forces
Branches: Romanian People’s Army,
Security Troops; Patriotic Guard, Air and
Air Defense Forces, Romanian Navy
Military manpower: males 15-49,
5,648,000; 4,780,000 fit for military ser-
vice; 218,000 reach military age (20)
annually
Military budget: announced for fiscal year
ending 31 December 1985, 12.2 billion lei;
about 3.6% of total budget
Rwanda :
St. Christopher and Nevis
St. Lucia
St. Vincent and
the Grenadines
San Marinos','1c35263ddfa8a88cf6857e296a577072c28428fb3662e2fd23392d7913a1131b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21107fd650aab8afc04afb292c09652cc1eb0f837fa1cc082be58c7c9655aa0e',1987,'SM','San Marino','communications',613,'Z2km
Com
Acquaviva
.
2 orga Maggiore
4 SAN MARINO
Fiorentino
Chiesangova, ° Monte”
Giardino j
See regional map V
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone
system serving 11,700 telephones (34.2 per
100 popl.); no radiobroadcasting or televi-
sion facilities; radio-relay and cable links
into Italian networks','bace6d8b7e91b2e686399a3cda17afbfd108c65ba3bcb5022c823454a6356923','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('193f40d6650d4aaee90ffece4b20f28e0117cb74df97a2e42975b340414a0b60',1987,'ST','Sao Tome and Principe','communications',618,'slihéu Bombom
Ihe do
Principe?,
Pedras ,
Tinhosas ¢
Gulf
of
anto Antonio
ithéu Carocgo
Railroads: none
Highways: 300 km, of which two-thirds is
paved; roads on Principe are mostly
unpaved and in need of repair
Ports: 1 major (Sido Tomé), 1 minor
Civil air: 1 major transport aircraft
Airfields: 2 total, 2 usable; 2 with
permanent-surface runways 1,220-2,439 m
Telecommunications: minimal system;
2,200 telephones (2.0 per 100 popl.); 1 AM,
2 FM, no TV stations; 1 Atlantic Ocean
satellite ground station
Defense Forces
Branches: Army, Navy','6c6ddca7fc2daefceabed6f23ee63a464e8597679f353bb8e624bfb736f172e4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('393c6557a2d831dc75b4dbcbb50844bb3325e9ef7ee75a9a26b4acb35e3cca71',1987,'SC','Seychelles','communications',624,'300 km
VICTORIAS. «>
, Mahe
Amiranta * Island
Isles fis
aes
Indian Ocean a
‘
Aldabra
yislands :
Ld ieee
t Cosmoledo Farquhar
Group +» Group
See regional map VII
Railroads: none
217
Highways: 282 km total; 145 km bitumi-
nous, 137 km crushed stone or earth
Ports: 1 port (Victoria); development
underway will double capacity
Civil air: 2 major transport aircraft
Airfields: 14 total, 14 usable; 2 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m
Telecommunications: direct radio com-
munications with adjacent islands and
African coastal countries; 9,100 telephones
(13.6 per 100 popl.); 2 AM, no FM stations;
1 TV station; 1 Indian Ocean satellite
station; USAF tracking station
Defense Forces
Branches: Army, Navy, Air Force, Militia
Military manpower: males 15-49, 16,000;
8,000 fit for military service
Military budget: for fiscal year ending 31
December 1986, $10 million, 10.3% of
central government budget','e3b11db9715916823e7d9c887781b0168b24fda144b2b4446087cf9009ada1dd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9531cb6ae572bb8f4fd0b106204b0948d0326779adac5a7f7474805af15d173',1987,'SL','Sierra Leone','communications',629,'Banana
islands
Turtle ,
Islands —_
Sherbro
island
North Atlantic Ocean
See regional map VII Sulima
Railroads: about 84 km 1.067-meter
narrow gauge privately owned mineral
line operated by the Sierra Leone Devel-
opment Company
Highways: 7,400 km total; 1,150 km
bituminous, 490 km laterite (some gravel),
remainder improved earth
Inland waterways: 800 km; 600 km
navigable year round
Ports: 1 major (Freetown), 2 minor
Civil air: 3 major transport aircraft
Airfields: 13 total, 10 usable; 5 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,489 m
Telecommunications: fair telephone and
telegraph service; 16,000 telephones (0.4
per 100 popl.); 1 INTELSAT Atlantic
Ocean satellite ground station; 3 AM, 1
FM, 2 TV stations
Defense Forces
Branches: Army, Navy
Military manpower: males 15-49, 857,000;
413,000 fit for military service; no con-
scription','f2f165b17b7e77f2ae31d9cda5bb79fe62bbaf76e980219e5d5d8db3b3ee7f47','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3418f8c772762d67aeee8cc5cbeb1fd8b32ce35e1013faa714fbb9a09bd887e',1987,'SG','Singapore','communications',634,'(pS
—1okm_
Pulau
Tekong
Besar
e
Johore
Strait
Johore Pulau
oodiands Strait _Ubin
4,0,
ae
SB Santose
x
N
&
bd Singapore Strait
Main Strait
See regional map IX','be3446a5c3eab7bd9af94b2844c207ba04056378fe3a06354fd03b041e25e03f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc140e58e714d9aa4f3addaf11bd4d6c63ac33438b6bd41aee85a5deeffb0fb4',1987,'SB','Solomon Islands','communications',639,'400 km
South
Pacific
os Ocean
Choisaul
oy,
= = Santa Isabal
2
° :
Gizo SY, wy s
on atk a ow Malaita
anaing CHO 1ARA
Gusdsicanal 4 . Santa
@ Cruz
San
Ge Cristobal tq islands ,
Coral Sea
See regional map X
Railroad: none
Highways: about 2,100 km total (1982); 30
km sealed, 290 km gravel, 980 km earth,
800 private logging and plantation roads of
varied construction
Ports: 5 minor
Civil] air: no major transport aircraft
Airfields: 24 total, 22 usable; 2 with
permanent-surface runways; 4 with run-
ways 1,220-2,439 m
Telecommunications: 3,000 telephones; 4
AM, no FM, no TV stations; 1 satellite
ground station
221','b8088614cb62ff86230ce901ec02527465e6501f6d61e6402903626a6f57be0c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e1e9a72d58223f464fe1b5b129897b477dc88cbfe3b0da6f68478b6bd153a33',1987,'SO','Somalia','communications',644,'Gulf of Adan
300 km
- Bender
Gerbera Caasim
* Hergeyse
Garoa
*
Boundary representation is
Not necessarily authoritative
Chisimayu
See regiona! map Vil
Railroads: none
222
Highways: 21,300 km total; including
2,335 km bituminous surface, 2,880 km
gravel, and 12,000 km improved earth or
stabilized soil
Pipelines: 15 km crude oil
Ports: 3 major (Mogadishu, Berbera, Chis-
imayu)
Civil air: 8 major transport aircraft
Airfields: 65 total, 53 usable; 6 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 6 with runways
2,440-3,659 m; 21 with runways
],220-2,489 m
Telecommunications: poor telephone and
telegraph service; radio-relay system
centered on Mogadishu connects a few
towns; 6,000 telephones (0.1 per 100 popl.);
1 Indian Ocean satellite station; 2 AM, no
FM stations; 1 TV station
Defense Forces
Branches: Somali National Army (includ-
ing Navy, Air Force, and Air Defense
Force), National Police Force
Military manpower: males 15-49,
1,710,000; 958,000 fit for military service;
no conscription','ff036d5312bbbe32683841e3f4807331c22dd15fbf19f72897b3d7d9d42a5f8b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84f3bd27cceaabaa7a0d507220ce2d00ec30057037f390e2a0b9aed56234e34a',1987,'LK','Sri Lanka','communications',652,'ff
da tng 100km
-
Paik
Bay
Manna’
Gut
of
Mannar
Hambantota
See regional map Vill Indian Ocean
Railroads: 1,868 km total (1985); all 1.868-
meter broad gauge; 102 km double track;
no electrification; government owned
Highways: 66,176 km total (1985); 24,300
km paved (mostly bituminous treated),
28,916 km crushed stone or gravel, 12,960
km improved earth or unimproved earth;
in addition, several thousand km of tracks,
mostly unmotorable
Inland waterways: 430 km; navigable by
shallow-draft craft
Pipelines: crude, 14 km; refined products,
55 km
Ports: 3 major, 9 minor
Civil air; 8 major transport (including 1
leased)
Airfields: 14 total, 12 usable; 11 with
permanent-surface runways; | with run-
ways 2,440-3,659 m, 7 with runways
1,220-2,439 m
229
Telecommunications: good international
service; 106,500 (est.) telephones (0.6 per
100 popl.); 12 AM, 3 FM, and | TV sta-
tions; submarine cables extend to Indone-
sia, Djibouti, India; 1 satellite ground
station
Defense Forces
Branches: Army, Air Force, Navy, Police
Force, Special Police Task Force, National
Auxiliary Force
Military manpower: males 15-49,
4,262,000; 3,344,000 fit for military ser-
vice; 174,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1986, $370 million, 18% of
central government estimated budget','7ed6d9a9077b04bad0299e3d2bcb983b37ec16157efd12974fc6e0601f6f983b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5410feab4b6b3704f8ef9bee23e3272159a6f7edecbd53e3ccef5b85d91de839',1987,'SD','Sudan','communications',657,'500 km
Red
Dunqulah Sea
*
Agbarah ,
KHARTOUM, Kassalé
Alfishir, © Wed Madani”
a
2 AUbavvid” kia
Nyala
Matekal
>
authoritative
See regional map VII
Railroads: 5,516 km total; 4,800 km 1.067-
meter gauge, 716 km 1.6096-meter gauge
plantation line
Highways: 20,000 km total; 2,000 km
bituminous treated, 4,000 km gravel, 2,304
km improved earth; remainder unim-
proved earth and track
Inland waterways: 5,310 km navigable
Pipelines: refined products, 815 km
Ports: 1 major (Port Sudan)
Civil air: 13 major transport aircraft
Airfields: 88 total, 79 usable; 8 with
permanent-surface runways; 4 with run-
ways 2,440-3,659 m, 3] with runways
1,220-2,489 m
Telecommunications: large system by
African standards, but barely adequate;
consists of radio relay, cables, radio com-
munications, and troposcatter,; domestic
satellite system with 14 stations; 68,500
telephones (0.3 per 100 popl.}; 4 AM, 1
FM, 2 TV stations; 1 Atlantic Ocean
satellite station
Defense Forces
Branches: Army, Navy, Air Force, Air
Defense Force
Military manpower: males 15-49,
5,314,000; 3,247,000 fit for military ser-
vice; 249,000 reach military age (18)
annually
Military budget: for fiscal year ending 30
June 1986, $134.4 million; 5.5% of central
government budget
e
°
°
tz
} t ‘ E:
° >
2)
¢
co]
I
Bg
286
United Nations Organizations
OAU OECD OIC OPEC SELA WFTU FAO GATT IAEA {IBRD ICAO ICJ IDA IFAD IFC ILO IMF IMO ITU UNESCO
287
Country International Organizations
ADB ARAB ASEAN CACM CARICOM CEMA
LEAGUE
CC tDB? «wee INTELSAT LAIA
ro
2?
=|
iz]
Cc
Zz
AM NATO OAPEC OAS
Suriname — 4
Swaziland','e6f30b15990d6d430c33235cd2387de25322b9608353b6b8133ed2e26168dcfa','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a6dbabedea60f6df1b585967d86d004bdf559f1ddef0ffa983878f6604cf5d7',1987,'SR','Suriname','communications',662,'North Atlantic
Ocean
Nieuw
Nickerie
Brokopando,
Prof. Dr, tr.
W. # van
Blommestein
Meer
km
See regional map1V','4c8609698ac7ba62c4f6cf1230271c21ea7da8c303bb6e3673149039410ea9cc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84dabb4c498eadedbc880acc9811f09cfbbd554c932d746c166c68a8ee243a6f',1987,'GE','Georgia','communications',668,'Railroads: 166 km total; 86 km 1.000-
meter gauge, government owned, and 80
km 1.435-meter standard gauge; all single
track
Highways: 8,300 km total; 500 km paved;
5,400 km bauxite gravel, crushed stone, or
improved earth; 2,400 km sand or clay
Inland waterways: 1,200 km; most impor-
tant means of transport; oceangoing vessels
with drafts ranging from 4.2 m to 7 m can
navigate many of the principal waterways
while native canoes navigate upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 2 major transport aircraft
Airfields: 45 total, 40 usable; 4 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 1 with runways
1,220-2,439 m
Telecommunications: international facili-
ties good; domestic radio-relay system;
27,500 telephones (6.3 per 100 popl.); 4
AM, 7 FM, and | shortwave stations; 6 TV
stations; 2 Atlantic satellite stations
Defense Forces
Branches: National Army (including
Infantry Battalion, Military Police Brigade,
Navy, Air Force)
Military manpower: males 15-49, 100,278;
59,971 fit for military service
Military budget: 1983, $41.8 million; 8.2%
of central government budget
232
Swaziland
50 km
Mhiume”
QiBABANE
hohe mba Siteki,
* Manzini
e S
Manksyane Pa
s
. Nhlangano
See regional map VII','5b3a149a5d524f06b27debc2dd2cbbcb6a3da6a5154b0b7a6024c6cf79ef7a33','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e6c6145c560ff374cdf2e4a751e8e6d8fb6c9f53f055e670850a511ecb741ff',1987,'SE','Sweden','communications',669,'400 km
STOCKHOLM
’ Jonkoping
Gotebor: ry Gotland
Kattegat Hand Baltic Sea
Malmo Kariskrona
See regional map V
Railroads: 12,520 km total; Swedish State
Railways (SJ)—11,180 km 1.435-meter
standard gauge, 6,960 km electrified and
1,152 km double track; 182 km 0.891-
meter gauge; 117 km rail ferry service;
privately owned railways—51] km 1.435-
meter standard gange, 332 km electrified;
371 km 0.891-meter gauge electrified
Highways: 97,400 km (51,899 km paved,
20,659 km gravel, 24,842 km unimproved
earth)
Inland waterways: 2,052 km navigable for
small] steamers and barges
Pipelines: 84 km natural gas
Ports: 17 major and 30 minor
_ Civil air: 65 major transports
Airfields: 265 total, 261 usable; 137 with
permanent-surface runways; 10 with
runways 2,440-3,659 m, 89 with runways
1,220-2,489 m
Telecommunications: excellent domestic
and international facilities; 7.8 million
telephones (89.0 per 100 popl.); 5 AM, 361
FM, 877 TV stations; 5 submarine coaxial
cables, 2 Atlantic Ocean satellite antennas,
1 Eutelsat antenna
Defense Forces
Branches: Royal Swedish Army, Royal
Swedish Air Force, Royal Swedish Navy
Military manpower: males 15-49,
2,095,000; 1,840,000 fit for military ser-
vice; 57,000 reach military age (19) annu-
ally
Military budget: for fiscal year ending 30
June 1987, $3.45 billion; 7.9% of central
government budget
235
Switzerland:
Syria
Tanzania','c3c51b8307d38c98b595d9bae9035aba738058303d37b3601252d3fc1a27f9b3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91208af051fa327ad7b11e9d0187dea8b2859884456feeea0ff0191bc3addd7a',1987,'CH','Switzerland','communications',674,'Scheffheusen
Bodensee
Basal
Ziirich 4 Zitricher
Seo
N ate! SERN «
“ * Lucerns
Fribourg
Leke
Genavi
See regions! map V
Railroads: 5,174 km total, of which 2,971
km are government owned (SBB), and
2,203 km are nongovernment owned; the
SBB network consists of 2,897 km 1.435-
meter standard gauge and 74 km 1.000-
meter narrow gauge track; 1,432 km
double track, 99% electrified; the nongov-
ernment network consists of 710 km 1.435-
meter standard gauge, 1,418 km 1.000-
meter gauge, and 75 km 0.790-meter
gauge track, 100% electrified
Highways: 62,145 km total (all paved), of
which 18,620 km are canton and 1,057 km
are national highways (740 km autobahn);
42,468 km are communal roads
Pipelines: 314 km crude oil; 1,438 km
natural gas
Inland waterways: 65 km; Rhine River
(Basel to Rheinfelden, Schaffhausen to
Bodensee); 12 navigable lakes
Ports: 1 major (Basel), 2 minor (all inland)
Civil air: 89 major transport aircraft
Airfields: 73 total, 71 usable; 42 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 6 with runways
2,440-3,659 m, 16 with runways
1,220-2,489 m
Telecommunications: excellent domestic,
international, and broadcast services; 5.44
million telephones (78.9 per 100 popl.); 7
AM, 265 FM, 1,340 TV stations; 1 satellite
station with 2 Atlantic Ocean and 1 Indian
Ocean antennas
Defense Forces
Branches: Army, Air Force
Military manpower: males 15-49,
1,736,000; 1,502,000 fit for military ser-
vice; 47,000 reach military age (20) annu-
ally
Military budget: proposed for fiscal year
ending 31 December 1985, $2.0 billion;
21.3% of proposed central government
budget
Syria
Al Heaskah
na)
"Ar Rlaqqeh
Latekia
Mediterranean
Sea
Day ax Zewr
*Tedmur
Boundary representation 1s
not necessarily authoritative
See regional map V1
Railroads: 1,543 km total; 1,28] km stan-
dard gauge, 262 km 1.050-meter narrow
gauge
Highways: 16,939 km total; 12,051 km
paved, 2,625 km gravel or crushed stone,
2,263 km improved earth
Inland waterways: 672 km; of little im-
portance
Pipelines: 1,304 km crude oil; 515 km
refined products
Ports: 2 major (Tartts, Latakia), 1 petro-
leum terminal (Baniy4s), 2 minor
Civil air: 26 major transport aircraft
Airfields: 99 total, 94 usable; 27 with
permanent-surface runways; 21 with
runways 2,440-3,659 m, 5 with runways
1,220-2,439 m
Telecommunications: fair system cur-
rently undergoing significant improve-
ment; 512,600 telephones (4.7 per 100
popl.); 9 AM, no FM, 40 TV stations; 1
Indian Ocean INTELSAT station; 1 Inter-
sputnik satellite station under construction;
1 submarine cable; coaxial cable and
radio-relay to Iraq, Jordan, Turkey, and
Lebanon (inactive)
Defense Forces
Branches: Syrian Arab Army, Syrian Arab
Air Force, Syrian Arab Navy
Military manpower: males 15-49,
2,398,000; 1,341,000 fit for military ser-
vice; 182,000 reach military age (19)
annually
238
Tanzania
See regional map VII
Railroads: 3,555 km total; 960 km 1.067-
meter gauge; 2,595 km 1.000-meter gauge,
6.4 km double track, 962 km Tazara
(Tan-Zam) Railroad 1.067-meter gauge in
Tanzania; 115 km 1.000-meter gauge
planned by end of decade
Highways: total 81,900 km, 3,600 km
paved; 5,600 km gravel or crushed stone;
remainder improved and unimproved
earth
Pipelines: 982 km crude oil
Inland waterways: several thousand km
navigable on Lakes Tanganyika, Victoria,
and Nyasa; principal inland ports are
Mwanza on Lake Victoria and Kigoma on
Lake Tanganyika
Ports: 8 major (Dar es Salaam, Mtwara,
Tanga)
Civil air: 7 major transport aircraft
Airfields: 100 total, 92 usable; 12 with
permanent-surface runways; 3 with run-
ways 2,440-3,659 m, 45 with runways
1,220-2,439 m
Telecommunications: fair system of open
wire, radio relay, and troposcatter; 103,800
telephones (0.5 per 100 popl.); 6 AM, no
FM, 2 TV stations; 1 Indian Ocean satel-
lite station
Defense Forces
Branches: Tanzanian People’s Defense
Force includes Army, Navy, and Air
Force; paramilitary Police .Field Force
Unit; Militia
Military manpower: males 15-49,
4,813,000; 2,772,000 fit for military service','05ea1b6145afa8677c032f367f097a3fc77a2ffd87b81c96a02a7789e7f7c5d6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6488ebe3e76e432ed5058d0b3215fcc188e2f104e661dd6c5bbba36fd11405c',1987,'TG','Togo','communications',679,'125 km
Kpelime
See regional map VII Bight of Benin
Railroads: 570 km 1.000-meter gauge,
single track
Highways: 7,000 km total; 1,600 km
paved, 2,700 km improved earth, remain-
der unimproved earth
Inland waterways: section of Mono River
and about 50 km of coastal lagoons and
tidal creeks
Ports: 1 major (Lomé), 1 minor
Civil air: 4 major transport aircraft
Airfields: 11 total, 11 usable; 2 with
permanent-surface runways 2,440-3,659 m
Telecommunications: fair system based on
network of open-wire lines supplemented
by radio-relay routes; 12,000 telephones
(0.4 per 100 popl.); 2 AM, no FM, 4 TV
stations; 1 Atlantic Ocean satellite station
and 1 SYMPHONIE station
Defense Forces
Branches: Army, Navy, Air Force, para-
military Gendarmerie
Military manpower: males 15-49, 714,000;
876,000 fit for military service; no con-
scription
242
Tonga‘','303a475811215caf02503de6d462081a822422e36e2cfbf2164770a4b3fbb635','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a56b6970bd4ca2e5a192012d262eefd3a995982ff83cc9ca7281ca85f971c4b2',1987,'TO','Tonga','communications',686,'— 200 km__ *Nivafo''ou =, Fafahi
Nivatoputapu
South
Pacific
Ocaan
Vava''u..
Group Ss
reneioiu
Ha’apai
Graup * +;
NUKU‘ALOFA® |
¥
Tongatapu
Group
Minerve Reef not shown
See regional map X
Railroads: none
Highways: 198 km sealed road (Tonga-
tapu); 74 km (Vava''u); 94 km unsealed
roads usable only in dry weather
Inland waterways: none
Ports: 2 minor (Nuku’alofa, Neiafu)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with
permanent-surface runways; 2 with run-
ways 1,220-2,439 m
Telecommunications: 3,529 telephones
(3.3 per 100 popl.); 66,000 radio sets; no
TV sets; 1] AM station; 1 satellite ground
station
Defense Forces
Branches: Land Force, Maritime Force
244','24ebb8c26a010dfe2457e02df43f793ea7c03d59455b3eeb4530212ff51f214e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a990e58f93ae852730f0d1030c2b6a03b49b27a06cbd02afb1e81b014e2efbc',1987,'TT','Trinidad and Tobago','communications',691,'SOkm
Se ae wl b
Scarborough
Ceribbean Sea
Toco
a yunapuna
«Sangre Granda
Gulf of Paria Trinidad
San Fernando
* Siparia Guayaguayare
See regional map III
Railroads: minimal agricultural system
near San Fernando
Highways: 8,000 km total; 4,000 km
paved, 1,000 km improved earth, 3,000
km unimproved earth
Pipelines: 1,032 km crude oil; 19 km
refined products; 904 km natural gas
Ports: ] major (Port-of-Spain), 8 minor
Civil air: 14 major transport aircraft
Airfields: 6 total, 5 usable; 3 with
permanent-surface runways; 1 with run-
ways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: excellent interna-
tional service via tropospheric scatter links
to Barbados and Guyana; good local ser-
vice; 1 Atlantic Ocean satellite station;
109,000 telephones (9.6 per 100 popl.); 2
AM, 4 FM, 5 TV stations
Defense Forces
Branches: Trinidad and Tobago Defense
Force, Trinidad and Tobago Police Service
Military manpower: males 15-49, 322,434;
234,451 fit for military service','1092c998377f590c3fee977597cc36d8c6ddc4785e28cf5850810cb8c465220b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('513e408eab987eb70f880877074677bd94124c3ca62218430de327989e030cc2',1987,'TN','Tunisia','communications',696,'200 km__
See
See regional mop VII
Railroads: 2,089 km total; 508 1.435-meter
km standard gauge; 1,586 km 1.000-meter
gauge, 18 km 1.000-meter gauge double
track
Highways: 17,700 km total; 9,100 km
bituminous; 8,600 km improved and
unimproved earth
Pipelines: 797 km crude oil; 86 km re-
fined products; 742 km natural gas
Ports: 5 major, 14 minor; 2 petroleum,
oils, and lubricants terminal
Civil) air: 15 major transport aircraft
Airfields: 31 total, 29 usable; 13 with
permanent-surface runways; 6 with run-
ways 2,440-3,659 m; 8 with runways
1,220-2,489 m
Telecommunications: the system is above
the African average; facilities consist of
open-wire lines, multiconductor cable, and
radio relay; key centers are Safaqis, Sisah,
Bizerte, and Tinis; 233,000 telephones (3.1
per 100 popl.); 18 AM, 4 FM, 14 TV
stations; 4 submarine cables; ARABSAT
satellite back-up control station; coaxial
cable to Algeria; radio-relay to Algeria,
Libya, and Italy
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49,
1,800,000; 1,036,000 fit for military ser-
vice; 83,000 reach military age (20) annu-
ally
Military budget: for fiscal year ending 31
December 1986, $308.5 million; 10.6% of
central government budget
Turkey
400 km
Black Sea
Mediterranean
Sea
See regional map V1
Turkey
Tuvalu ¢','40d5bf143e0338551807ababab57f0d5595ecbbc7d1836d568f53e69e18a5da4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73c454a31bee8189bb06576d826547d66612e2b72ae6eca3da4724e5c7c1c05b',1987,'TV','Tuvalu','communications',704,'Nanumea —150km__
,Niutso
‘Nanumanga
{Nui
Vaitupu
Nukufetaug
FUNAFUTI *—>{
Funatuti
South
Pacitic .
Ocean Nukulaelae
Nurakita
.
See regional map X
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 2 minor (Funafuti, Nukufetau)
Civil air: no major transport aircraft
Airfields: 1 total, 1 usable with runways
1,220-2,439 m
Telecommunications: 1 AM station; about
300 radiotelephones (0.5 per 100 popl.);
4,000 radio receivers; 108 telephones (1.3
per 100 popl.)','d46af5f487f6d9fe6e5b38867e337b74e3dae5b34f7de783a9236e116081ac1d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50944565a2de464a2c2102999b76cffe705af8e704b8f66da4bfe3eb91083ec6',1987,'UG','Uganda','communications',709,'See regional map VII
Railroads: 1,300 km, 1.000-meter gauge
single track
Highways: 30,500 km total; 3,500 km
paved; 7,000 km crushed stone, gravel,
and laterite; remainder earth roads and
tracks
Inland waterways: Lake Victoria, Lake
Albert, Lake Kyoga, Lake George, Lake
Edward; Victoria Nile, Albert Nile; princi-
pal inland water ports are at Jinja and Port
Bell, both on Lake Victoria
Civil air: 4 major transport aircraft
Airfields: 39 total, 34 usable; 5 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 3 with runways
2,440-3,659 m, 11 with runways
1,220-2,4389 m
Uganda (continued)
Telecommunications: fair system with
radio-relay and radio communications
stations in use; 61,600 telephones (0.5 per
100 popl.); 9 AM, no FM, 9 TV stations; 1
Atlantic Ocean INTELSAT station
Defense Forces
Branches: National Resistance Army
(NRA)
Military manpower: males 15-49, about
8,393,000; about 1,831,000 fit for military
service
Union of Soviet Socialist
Republics','d43cf7a69dec0ca8ccd342083c31a42664adf6e56179e4a6549804fc77ba18bd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa99ce92a8df76e1c04b0e9edd31d426befa2b75a9f0c88a47669d2d68403d9',1987,'AE','United Arab Emirates','communications',714,'125km
Persian Gulf pa‘e a Knaymah’
Ash Shiriqah # Ajman:
+ Dubayy, .
+ ABU OHABI + n03
° Ve os
a %. eit
Boundary representation 1s
not necessarily authoritative
See regional map Vi
Railroads: none
Highways: 2,000 km total; 1,800 km
bituminous, 200 km gravel and graded
earth
Pipelines: 880 km crude oil; 870 km
natural gas, including natural gas liquids
Ports: 7 major, 25 minor
Civil air: 5 major transport aircraft
Airfields: 39 total, 31 usable; 17 with
permanent-surface runways; 5 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 6 with runways 1,220-
2,439 m
Telecommunications: adequate system of
radio-relay and coaxial cable; key centers
are Abu Dhabi and Dubayy; 319,000
telephones (24.1 per 100 popl.); 8 AM, 3
FM, 12 TV stations; 1 Atlantic and 2
Indian Ocean INTELSAT stations; 1
ARABSAT satellite station; submarine
cable to Qatar and Bahrain; planned
submarine cables to India and Pakistan;
tropospheric scatter to Bahrain; radio-relay
to Saudi Arabia
Defense Forces
Branches: Army, Navy, Air Force, Central
Military Command, Federal Police Force
Military manpower: males 15-49, 793,000;
441,000 fit for military service
Military budget: for fiscal year ending 31
December 1985, $1.385 billion; 42% of
central government budget
253','9568c9047db4875c1e2f39b52580a7577f791c2504d6ffd57927386a4981978a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e1bc696adaef56bb53f8f049009b46c35041d056b5730466ad0292a5cfed0e',1987,'GB','United Kingdom','communications',719,'— 300 km_ \\‘Shetlend
Islands
< Orkney
islands
Hebrides | g
‘ North
North ce Sea
Atlentic
Ocean
English Channel
See regional map V','3f5cda60d83566d47b2b547d08dddf8de843d4f1102adfbca670f917b821c977','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c42ddea644a0fc2c33ec789db6318839212120d4a71eccadb26dd8f8c1fa636',1987,'US','United States','communications',723,'Defense Forces
3000 km
Branches: Royal Army, Royal Navy,
Royal Air Force, Royal Marines
Military manpower; males 15-49,
14,315,000; 12,117,000 fit for military
service; no conscription
North
Atlantic
Military budget: for fiscal year ending 31 . Oceee
March 1986, $28.4 billion; about 20.1% of
central government budget
+, Hawaiian Gult of
* Islands México
Seeregiona! map Il
Note: this section was compiled from
information in the public domain and does
not represent Intelligence Community
estimates
Railroads: 270,312 km
Highways: 6,365,590 km, including 88,641
km expressways
Inland waterways: est. 41,009 km of
navigable inland channels, exclusive of the
Great Lakes
Freight carried: rai]—1,637.0 million
metric tons, 1,345.6 billion metric ton/km
(1984); highways—987.53 billion metric
ton/km (1984); inland water freight (ex-
cluding Great Lakes traffic)—582.81 mil-
lion metric tons, 358.29 billion metric
ton/km (1984); air—11,495 million metric
ton/km (1984)
Pipelines: petroleum, 883.3 billion metric
ton/km, 1,049.6 million metric tons car-
ried (1984)
Ports: 44 handling 10.9 million metric tons
or more per year
Civil air: 2,960 commercial multiengine
transport aircraft, including 2,724 jet, 185
turboprop, 51 piston (1984)
Airfields: 15,422 in operation (1981)
Telecommunications: 182,558,000 tele-
phones (791 telephones per 1,000 popl.);
4,892 AM, 3,915 FM, 1,285 noncommer-
cial FM stations (10,092 total); 796 com-
mercial, 300 noncommercial (public broad-
casting), 6,200 commercial cable TV
broadcast stations (7,296 total); 495 million
radio and 150 million TV receivers (1982)
Defense Forces
Branches: Department of the Army,
Department of the Navy (including Ma-
rine Corps), US Coast Guard, Department
of the Air Force
Military manpower: 2,185,900 total;
780,800, army; 594,500, air force; 761,400,
navy (includes 196,600 marines) (1984)
Military budget: $289.1 billion; 29.2% of
central government budget (1986)
257','e27251e5523942d29126cdc441c9283c7325fc36af7459c597a8163d0819751a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5d57742b11e6509f908d528c231aea2fb322366497489476ccdc7728e701fcf',1987,'UY','Uruguay','communications',728,'125km
Boundary representation is
not necessarily authoritative
Embatse def
Rio Negro
"Peysandé ea
Ocean
See regional map IV.
Railroads: 3,000 km, all 1.4385-meter
standard gauge and government owned
Highways: 49,900 km total; 6,700 km
paved, 3,000 km gravel, 40,200 km earth
Inland waterways: 1,600 km; used by
coastal and shallow-draft river craft
Ports: 1 major (Montevideo), 9 minor
Civil air: 14 major transport aircraft
Airfields: 97 total, 94 usable; 16 with
permanent-surface runways; 2 with run-
ways 2,440-8,659 m, 14 with runways
1,220-2,439 m
Telecommunications: most modern facili-
ties concentrated in Montevideo; new
nationwide radio-relay network 337,000
telephones (11.3 per 100 popl.); 98 AM, 9
shortwave, 21 TV stations; 2 Atlantic
Ocean satellite stations
Defense Forces
Branches: Army, Navy, Air Force
Military manpower: males 15-49, 689,000;
561,000 fit for military service; no con-
scription','94aa629b3d405164fbe9ae7a98c476d2e450d630186376c1f80b3fc1ce4560ce','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c26078e55a6663ab7d5e0ecf49be9ed0c914ec7ece5087424dd3951fd3bd2c3',1987,'VU','Vanuatu','communications',733,'‘ : 200 km
S
oO.)
Espiritu
Ss. 4 :
aera Aoba \\Meé wo
Luganvite,; 7 De niseas: South
Pacific Ocean
Amb
Malskule &y deste
Epi %
Coral Sea ie
apitore
PORT-VILA
QyFrromango
Tanna
Anatom
See regional map X MS
Railroads: none
Highways: 1,027 km total; at least 240 km
sealed or all-weather roads
Inland waterways: none
Ports: 3 minor (Port-Vila, Luganville,
Palikoulo)
Civil air: no major transport aircraft
Airfields: 31 total, 27 usable; 2 with
permanent-surface runways, 2 with run-
ways 1,220-2,439 m
Telecommunications: 2 AM stations; 3,000
telephones (2.2 per 100 popl.); 1 satellite
ground station
Defense Forces
Personnel: no military forces maintained;
however, a paramilitary force is responsi-
ble for internal and external security
Vatican City
See regional map V
Highways: none (city streets)
Telecommunications: 2 AM and 2 FM
stations; 2,000-line automatic telephone
exchange
Defense Forces
Defense is the responsibility of Italy; Swiss
Papal Guards are posted at entrances to
the Vatican City
Venezuela
Caribbean Sea
jaracsibo es
CARACAS
San Cristobal a 4
iS San Fernando
Puerto Ayachucho
Boundary representation 1s
not necessarily authontative
See regionsl map 1V
Railroads: 439 km total; 260 km 1.435-
meter standard gauge all single track,
government owned; 179 km 1.435-meter
gauge, privately owned
Highways: 77,785 km total; 22,780 km
paved, 24,720 km gravel, 14,450 km earth
roads, and 15,835 km unimproved earth
Inland waterways: 7,100 km; Rio Orinoco
and Lago de Maracaibo accept oceangoing
vessels
Pipelines: 6,370 km crude oil; 480 km
refined products; 3,690 km natural gas
Ports: 6 major, 17 minor
Civil air: 58 major transport aircraft
Airfields: 278 total, 253 usable; 108 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m, 86 with runways
1,220-2,489 m
Telecommunications: modern expanding;
1.44 million telephones (9.5 per 100 popl.);
178 AM, 42 shortwave, 62 TV stations; 3
submarine coaxial cables; 1 Atlantic Ocean
satellite station with 2 antennas, 3 domes-
tic satellite stations
Defense Forces
Branches: Ground Forces, Naval Forces
(Marines, Coast Guard), Air Forces, Armed
Forces of Cooperation (National Guard)
Military manpower: males 15-49,
4,633,000; 3,371,000 fit for military ser-
vice; 199,000 reach military age (18)
annually
Vietnam
400 km
Gulf of
Tonkin
South
6B. dary representation «
natineoeusaly auhon aii China
Sea
Cam Ranh
eHoChi Minh
Gutt of *
Vatican City¢
Venezuela
Vietnam
Western Samoa
Yemen Arab Republic
Yemen, People’s Demo- ©
cratic Republic of
Yugoslavia
Zaire','7ef1267972c08947c6e7d246db27228973e3e005798ff3fba7c1dac9f4828db6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('215825dbff5e5f2d34b3a2d0aea8a52acb2358bc4d862f7bdeba37a665c8e47f',1987,'WF','Wallis and Futuna','communications',738,'50km
erp
ile Uvée¥.
South Pacific Ocean
fle Futuna
@leava
>
tie Aloti
See regional map X
Railroads: none
Highways: 100 km on fle Uvéa (Uvea
Island), 16 km sealed; 20 km earth surface
on [le Futuna (Futuna Island)
Inland waterways: none
Ports: 2 minor
Airfields: 2 total; 2 usable; 1 with
permanent-surface runways; 1 with run-
ways 1,220-2,439 m
Telecommunications: 225 telephones (1.6
per 100 popl.); 1 AM station
Defense Forces
Defense is the responsibility of France','d16ca56cca51076310ee8bdcbf9a91613a2187fdf062669d5b3c7f3789a4774e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cee15377c5de12f01128811b598868e90a6f4b80d16126b75b6afc76a517a39b',1987,'EH','Western Sahara','communications',743,'200km
North
Atlantic
See regional map VII
a
Railroads: none
Highways: 6,100 km total; 1,850 km
surfaced, 4,750 km improved and unim-
proved earth roads and tracks
Ports: 2 secondary (El Aaiin, Ad Dakhla)
Airfields: 16 total, 15 usable; 3 with
permanent-surface runways, 3 with run-
ways 2,440-3,659 m, 6 with runways
],220-2,439 m
Telecommunications: | AM, 0 FM, and 1
TV stations
Western Samoa
50 km
South Pacific Ocean
ag APIA
Manono
South Pacific Ocean
See regional map X
Railroads: none
Highways: 2,042 km total; 375 km sealed;
remainder mostly gravel, crushed stone, or
earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 8 major transport aircraft
Airfields: 4 total, 4 usable; 1 with
permanent-surface runways; 1 with
2,440-8,659 m
Telecommunications: 7,500 telephones
(4.5 per 100 popl.); 70,000 radio receivers;
1 AM station; 1 satellite station
Defense Forces
Military manpower: males 15-49, 45,000;
23,000 fit for military service
Yemen Arab Republic
(North Yemen)
125 km
Boundary representation 1s.
nol necessarily authoritative
See regional map vi
Railroads: none
Highways: 4,000 km total; 1, 775 km
bituminous; 500 km crushed stone and
gravel; 1,725 km earth, sand, and light
gravel
Ports: 1 major (Al Hudaydah), 3 minor
Civil air: 9 major transport aircraft
Airfields: 20 total, 14 usable; 4 with
permanent-surface runways; 7 with run-
ways 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: system poor but
improving; new radio-relay and cable
networks; 50,000 telephones (0.8 per 100
popl.); 3 AM, no FM, 5 TV stations; 1
Indian Ocean, 1 Atlantic Ocean, and 1
ARABSAT satellite station; tropospheric
scatter to South Yemen
Defense Forces
Branches: Army, Navy, Air Force, Police
Military manpower: males 15-49,
1,183,000; 672,000 fit for military service;
about 83,000 reach military age (18)
annually
267
Yemen, People’s Democratic
Republic of
(South Yemen)
—A00km
Boundary representation is
not necessarily authoritative
Arabian
Sea
Socotra
Gulf of Aden
See regional map V1','7004440c1bceebf8196625e19f56652ffa30295423551159209d0680178278b8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da1a0497870df5c0864714b15cd3b461466e9106e5a86fa7f2f9b8e2aa3a7fe2',1987,'YE','Yemen','communications',748,'Defense Forces
Branches: Army, Navy, Air Force,
People’s Militia, People’s Police
Military manpower: males 15-49, 491,000;
277,000 fit for military service
Yugoslavia
Novi
Sad
BELGRADE,
Adriatic SS
See Dubrovnik
See regional map V','d7172184b02b8a3589178a33555b32b7772bb250e5425e36d52ea84146173def','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb7dabdead109393fe8d4dce8616692cafa3e3214c2bf786797b1a99adf4bc8e',1987,'ZM','Zambia','communications',750,'300 km
Leake.
aN Tanganyika
Boundary representation is
not Necessarily authoritative
Mopulungy
“Keaame }
Oo. Loke
Bengweuta
Livingstone
See regional map VII
Railroads: 1,204 km, all 1.067-meter
gauge; 13 km double track
Highways: 36,370 km total; 6,500 km
paved, 7,000 km crushed stone, gravel, or
stabilized soil; 22,870 km improved and
unimproved earth
Inland waterways: 2,250 km, including
Zambezi River, Luapula River, Lake
Tanganyika; Mpulungu is small port on
Lake Tanganyika
Pipelines: 1,724 km crude oil
Civil air: 9 major transport aircraft
Airfields: 128 total, 114 usable; 12 with
permanent-surface runways; 1 with run-
ways over 3,659 m, 4 with runways
2,440-3,659 m, 19 with runways
1,220-2,439 m
Telecommunications: facilities are among
the best in Sub-Saharan Africa; high-
capacity radio relay connects most larger
towns and cities; 71,700 telephones (1.0
per 100 popl.); 9 AM, 2 FM, 10 TV sta-
tions; 1 Indian Ocean satellite station
Defense Forces
Branches: Army, Air Force, paramilitary
Police Mobile Force, Police Paramilitary
Military manpower: males 15-49,
1,500,000; 786,000 fit for military service','ed16ced6e65176c635c79e35ff617292b033fd71eb71acc667cc6c62e3896b25','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df9e513a1fe9c074e1ce2d5cf54bd0cd272c1461734606ef2b33c7260bec4550',1987,'ZW','Zimbabwe','communications',755,'—20 km
Boundary representation ta
Not necessarily authoritative
See regional map VII
Railroads: 3,394 km 1.067-meter gauge;
42 km double track; 335 km electrified
Highways: 85,237 km total; 12,243 km
paved, 28,090 km crushed stone, gravel,
stabilized soil: 23,097 km improved earth;
21,807 km unimproved earth
Inland waterways: Lake Kariba is a
potential line of communication
Pipelines: 8 km refined products
Civil air: 13 major transport aircraft
Airfields: 530 total, 472 usable; 22 with
permanent-surface runways; 2 with run-
ways over 3,659 m, 3 with runways
2,440-3,659 m, 89 with runways
1,220-2,439 m
Telecommunications: system was one of
the best in Africa but now suffers from
poor maintenance; consists of radio-relay
links, open-wire lines, and radio communi-
cations stations; principal center Harare,
secondary center Bulawayo; 247,000 tele-
phones (2.7 per 100 popl.),; 8 AM, 15 FM,
8 TV stations; 1 Atlantic Ocean
INTELSAT station
Defense Forces
Branches: Zimbabwe National Army, Air
Force of Zimbabwe, Police Support Unit,
People’s Militia
Military manpower: males 15-49,
1,876,000; 1,157,000 fit for military service
274
Taiwan
(China listed in
alphabetic order)
100 km Chi-lung
Taiwan Strait
Cheng-hua
Hus-lien
Pescadoras
.
’> Taiwan Philippine
> Ma-kung Sea
Quemoy and Matsu
istanda are not shown
a
See regional map VIII i.
Railroads; about 1,075 km common car-
rier lines and over 3,800 km industrial
lines; common carrier lines consist of the
1.067-meter gauge 708 km West Line and
the 367 km East Line; a 98.25 km South
Link Line connection is under construc-
tion; common carrier lines owned by the
government and operated by the Railway
Administration under Ministry of Commu-
nications; industrial lines owned and
operated by government enterprises
Highways: network totals 18,800 km
(15,800 km are bituminous or concrete
surface); 2,500 km are crushed stone or
gravel surface; and 500 km are graded
earth
Pipelines: 615 km refined products, 97 km
natural gas
Ports: 5 major (Kao-hsiung, Chi-lung,
Hua-lien, Su-ao, and T’ai-tung), 4 minor
(Tan-shui, T’ai-nan, Ta-p’eng, and Ma-
kung)
Airfields: 41 total; 89 usable; 34 with
permanent-surface runways; 3 with run-
ways over 3,659 m, 17 with runways
2,440-3,659 m, 8 with runways 1,220-
2,439 m
Taiwan
(China listed in
alphabetic order) (continued)
Telecommunications: very good interna-
tional and domestic service; 5.1 million
telephones () per 3.5 popl.); about 100
radio broadcast stations with 270 AM and
12 FM transmitters; 12 TV stations and 6
repeaters; 8 million radio receivers and 3.6
million TV receivers; 2 INTELSAT ground
stations; tropospheric scatter links to Hong
Kong and the Philippines available but
inactive; submarine cables to Okinawa
(Japan), the Philippines, Guam, Singapore,
and Hong Kong
Defense Forces
Branches: Army, Navy (including Ma-
rines), Air Force, Combined Services Force
Military manpower: males 15-49,
5,528,000; 4,337,000 fit for military ser-
vice; about 186,000 currently reach mili-
tary age (19) annually
Military budget: announced expenditures
for national defense for fiscal year ending
80 June 1987, $4.2 billion; about 37.1% of
central government budget; however, total
military expenditures may be closer to
$4.7 billion or about 50% of the central
government budget
West Bank and Gaza Strip
§0 km
Nablus
s
Boundary representation ts
not necessanly authoritative
WESY BANK
ilsraeli oceupied—
Status to
Jerusalem
cetnaniill
Meditarranean
See
STRIP
(isrseli occupied —
Stetus to be
determined)
See regiona! map V1
Note: The war between Israel and the
Arab states in June 1967 ended with Israel
in control of the West Bank and the Gaza
Strip, the Sinai, and the Golan Heights. As
stated in the 1978 Camp David Accords
and reaffirmed by the President’s 1 Sep-
tember 1982 peace initiative, the final
status of the West Bank and the Gaza
Strip, their relationship with their neigh-
bors, and a peace treaty between Israel
and Jordan are ta be negotiated among the
concerned parties. Camp David further
specifies that these negotiations will resolve
the respective boundaries. Pending the
completion of this process, it is US policy
that the final status of the West Bank and
the Gaza Strip has yet to be determined.
In the view of the United States, the term
West Bank describes all of the area west of
the Jordan River under Jordanian adminis-
tration before the 1967 Arab-Israeli war.
However, with respect to negotiations
envisaged in the framework agreement, it
is US policy that a distinction must be
made between Jerusalem and the rest of
the West Bank because of the city’s special
status and circumstances. Therefore, a
negotiated solution for the final status of
Jerusalem could be different in character
from that of the rest of the West Bank.
276
Taiwan ¢
F
288
United Nations Organizations
FAQ GATT
UPU WHO WMO
UNESCO
IBRD ICAO 1CjJ IDA IFAD IFC 1LO0) IMF IMO ITU
IAEA
SELA WFTU
OPEC
OAU OECD OIC
289
Appendix D
Mathematical Conversions
To Convert From To Multiply By To Convert From To Multiply By
Acres Hectares 0.4046856 Meters, cubic Tons, register 0.353147
Acres Kilometers, square 0.004046856 Miles, nautical Kilometers ~—«*42-.852.
Acres Meters, square 4046.856 _ Miles, statute Centimeters ____160934.4 ers
Centimeters Meters 0.01 Miles, statute Meters 1609.344 7 2
Centimeters, square Meters, square 0.0001 Miles, statute Kilometers _ 1,609344
Degrees, Fahrenheit Degrees, Celsius subtract 32 and Miles, square Hectares 258.9998 :
multiply by 5/9 Miles, square Kilometers, square —-2.589998 7
Feet Centimeters 30.48 Ounces, avoirdupois Grams | fw 28.349523
Feet Meters 0.3048 Ounces, avoirdupois Kilograms 0.028349523
Feet Kilometers 0.0003048 Ounces, troy Pounds, troy 0.083333,
Feet, cubic Liters 28.316847 Ounces, troy Grams _ 31.10348
Feet, cubic Meters, cubic 0.028316847 Pints, liquid Milliliters 473.176473 =
Feet, square Centimeters, square 929.0804 Pints, liquid Liters 0.473176473 <==
Feet, square Meters, square 0.09290804 Pounds, avoirdupois Grams 453.59237
Gallons, US liquid Liters 3.785412 Pounds, avoirdupois Kilograms 0.45359237 aor
Gallons, US liquid Meters, cubic 0.003785412 Pounds, avoirdupois Quintals = 0.00453592
Grams Ounces, troy 0.032151 Pounds, avoirdupois Tons, metric 0.000453592
Grams Pounds, troy 0.002679 Pounds, troy Ounces, troy 12
Hectares Kilometers, square 0.01 Pounds, troy Grams 973.241722
Hectares Meters, square 10,000 Quarts, dry Liters 1.101221 Es
Inches Centimeters 2.54 Quarts, dry Dekaliters 0.1101 221
Inches Meters 0.0254 Quarts, liquid Milliliters ~ 946.352946
Inches, cubic Milliliters 16.387064 Quarts, liquid Liters 0.946352946
Inches, cubic Liters 0.016387064 Quintals Tons, metric 0.1 -
Inches, cubic Meters, cubic 0.000016387064 Tons, long Kilograms 1016.047 ae)
Inches, square Centimeters, square 6.4516 Tons, long Tons, metric _ 1.016047
Inches, square Meters, square 0.00064516 Tons, metric Quintals 10
Kilograms Ounces, troy 32.15075 Ton-miles, long Ton-kilometers, metric 1.635169 -_
Kilograms Pounds, troy 2.679229 Ton-miles, short Ton-kilometers, metric 1.459972 _ .
Kilograms Tons, metric 0.001 Tons, register Meters, cubic 2.831685 =
Kilometers, square Hectares 100 Tons, short Kilograms 907.185
Liters Milliliters 1000 Tons, short Tons, metric 0.907185
Liters Meters, cubic 0.001 Yards Centimeters 91.44
Meters Millimeters 1000 Yards Meters 0.9144
Meters Centimeters 100 Yards, cubic Liters 764.5549
Meters Kilometers 0.001 Yards, cubic Meters, cubic _0.7645549
Meters, cubic Liters 1000 Yards, square Meters, square 0.836127
290
- ce - » 77 o— | 3 7 — 2
7 a ) _ ow - ~e - > 2 - - =
7 - - i
- _ - aan - 7
ad a + Oo OO : > 7 _ oe
7 = See at = _ eo —) _ - _ —— 7
a = : be a a 7 4 - _
: a o : : =
n> “So i 7 - . - ?
fo)
ee
-
\\
a — : 7 =
. - a i — -
ee | : : 4 - a > a ~~ 7 : -
: - . - 7 a. . ms 7 7 7 ; 7 _
: = . a 25 _ ae
> + ~eaety 70) | a a
ee oe —_ tite : - : - 7
ans. nn a eS ¥.
; - : : Se = ns 7 7 7
7 p Ae a os. ow a .o rar ; f - -
> om | = - 7 ar 3S. ; -
ee ee
ie A Me Cala? - eo
7 7 a “3, - 3a 1s 3. ; a tan a >
: J i ? =o _*. 7 = tS a - 7 7 _ . a :
: SS: a eee eR hi Coke, : Pe
7 : 7 os f be a md 4% ihe a - oe
: ro< : :
7 io 4 7 7 7 ao yo 5 _ —
7 — 7 i) = . tg , i : ee eee 7
a 4 ; a = + a > VE, i a.
= —_ 2 —_ . ee ae miei eee alge ft 7 - oe
7 - . —— 7 7 a : 7
7 7 - > 7 7 - " - p SW;
a : 7 fy - 7 -
7 —_ 7 7 == : Wo = - _
a 7 a ae a f 7 eS 7 7 Te.
» : , a r 6 ol = -
: - y a ao _ a 7 7 7 6
7 - @ Q an 7 7
: on = : i Ms ag —_ : :
ee ; " ,— a an oo: 4
ne ee aS ae ew = ee —_= D a = 7 :
a 717 - _ : -
= G ; : _
a 7 = 7 > ra - q 7
- < an : 7 Fa : - -
: - 7 ; eS - 7 = q : * -@ :
7 7 = 3 oe : 7 7 :
_ _ ~~ +) y _ - 7 =. =a ae > ’ o
a,
ne
-_ :
- _
a
a - :
7 7
>
a om
-
a _
- =
- ——
S
a fe oy
oe
os a
r :
- a
7 oe
'' ¥
: _
7 S
"
a -
; y.
7 -
: 7
-
Q
- =
i. -
_ -
_ , 7
au
7
— A 7 -
y _ — =
7 9 7 :
a fe a =
-
_ —
-
——
7
-
i
oo :
GQ
T=
a
q
_
NNSSNSSSSSSSSSSNNNNNSNSS
NNNSNNNSSNSSNSSSNSNSSSSNN
NNNNSSNSSSNSSSSSSSNSSS
NNSSNSSSSSSSSNSSSSSNNSSSS
NNNNNNSSSNNSSSNSNSSSSSNSN
INNSNSNNSSNNNNNNANANSS
NNN SNSSSSSSSS:
SNANNNNSSSNNNSSS:
SNNSNSNSNSSSSSSSSSS
NNNSSSSSSSSSSSSS
NNESSESNSNNNNS
¢
od ON
4444444
¢
EEEEEEES
yo oe
LAL
33
ad x d & > ©
Na » » Sv ® » as 4 Ao 8 ae
RLOLPLILPLE VOL IVP CIVIC TS OE es SN x x . SN x x
+S SD &® eV od > | ved neh ba .
o 4% SNNNS ae: NNNNNNNS
» ® > 2 ® ‘ @ ee wvvvyY pwrTvVvY" VY @ 4 ®
*@ &% < » a4 y Qo:
»* :
N3 Se: NM
LA
3 0112 071779513','e429473f56dfded7a6dca7f8e4dbc50cb570e98ded961a406c961aa8df22b337','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

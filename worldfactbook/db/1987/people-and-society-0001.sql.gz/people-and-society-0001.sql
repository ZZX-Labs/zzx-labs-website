SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('592e75bbb6c42a3f275178d375f5e79af40ecb001184a8458598746d00e77cd4',1987,'AF','Afghanistan','people-and-society',5,'Population: 14,183,671 (July 1987), aver-
age annual growth rate 1.44%; these esti-
mates include an adjustment for emigra-
tion to Pakistan and Iran during recent
years, but do not take into account other
demographic consequences of the Soviet
intervention in Afghanistan
Nationality: noun—Afghar(s); adjective—
Afghan
Ethnic divisions: 50% Pushtun, 25% Tajik,
9% Uzbek, 9% Hazara; minor ethnic
groups include Chahar Aimaks, Turkmen,
Baluch, and others
Religion: 74% Sunni Muslim, 25% Shi''a
Muslim, 1% other
Language: 50% Pashtu, 35% Afghan
Persian (Dari), 11% Turkic languages
(primarily Uzbek and Turkmen), 4% thirty
minor languages (primarily Baluchi and
Pashai); much bilingualism
Life expectancy: men 42.53, women 40.87
(1986)
Literacy: 12%
Labor force: 4.98 million (1980 est.);
67.8% agriculture aud animal husbandry,
10.2% industry, 6.3% construction, 5.0%
commerce, 7.7% services and other; cur-
rent figures unavailable because of fighting
(1986)
Organized labor: government-controlled
unions are being established','85336daa629977eb05bed44519b6d6007dc01a8f10359a6884ee3dbaa2421f9c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3462d241a375c0b9f603793de0670b3d556d8ee4f9ae76ad49bf394741b1220',1987,'AL','Albania','people-and-society',11,'Population: 3,085,985 (July 1987), average
annual growth rate 2.03%
Nationality: noun—Albanian(s); adjec-
tive—Albanian
Ethnic divisions: 96% Albanian; remain-
ing 4% are Greeks, Vlachs, Gypsies, Serbs,
and Bulgarians
Religion: Albania claims to be the world’s
first atheist state; all churches and mosques
were closed in 1967 and religious obser-
vances prohibited; pre-1967 estimates of
religious affiliation—70% Muslim, 20%
Albanian Orthodox, 10% Roman Catholic
Language: Albanian (Tosk is official dia-
lect), Greek
Infant mortality rate: 86.8/1,000 (1971)
Life expectancy: 69
Literacy: 75%
Labor force: 584,000 (1978); about 22%
agriculture, 40% industry and commerce,
38% other (1978)','adf33be98aafbf6243be281bf705b631977f2b14cb02b478158deb23d9556563','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a074ebf09665e373424071336517c2a4dc5fc512e920eff347424e5c3742e4',1987,'DZ','Algeria','people-and-society',16,'Population: 23,460,614 (July 1987), aver-
age annual growth rate 3.10%
Nationality: noun—Algerian(s); adjec-
tive—Algerian
Algeria (continued)
Ethnic divisions: 99% Arab-Berber, less
than 1% European
Religion: 99% Sunni Muslim (state reli-
gion); 1% Christian and Jewish
Language: Arabic (official), French, Berber
dialects
Infant mortality rate: 106/1,000 (1984)
Life expectancy: 60
Literacy: 52%
Labor force: 3.7 million (1984); 40%
industry and commerce, 30% agriculture,
17% government, 10% services; at least
11% of urban Jabor unemployed
Organized labor: 16-19% of labor force
claimed; General Union of Algerian Work-
ers (UGTA) is the only labor organization
and is subordinate to the National Libera-
tion Front','5a303d8460d3f1dd59ca2890e95ae4adf26d209f4fa9538698d612107fc6bb3e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66cee7cc2e22850ceb039c96822ea3a3d29ff0515772f4f7527cd86d509ba0b9',1987,'AD','Andorra','people-and-society',20,'Population: 47,973 (July 1987), average
annual growth rate 3.19%
Nationality: noun—Andorran(s); adjec-
tive—Andorran
Ethnic divisions: Catalan stock; 61%
Spanish, 30% Andorran, 6% French, 3%
other
Religion: virtually all Roman Catholic
Language: Catalan (official); many also
speak some French and Castilian
Literacy: 100%
Labor force: largely shepherds and farm-
ers','de5a54c78d940dfd5bd307759959c63e28e0f76e158ea737dfa1694a51947935','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0da59b0db144b5cc95caa7122e34382feb3d3e311b0a5005dd9611115d082d5f',1987,'AO','Angola','people-and-society',27,'Population: 7,950,244 (July 1987), average
annual growth rate 2.86%; includes Cabi-
nda 109,802, average annual growth rate
6.64%
Nationality: noun—Angolan(s), adjective—
Angolan
Ethnic divisions: 37% Ovimbundu, 25%
Kimbundu, 13% Bakongo, 2% Mestico, 1%
European
Religion: 68% Roman Catholic, 20%
Protestant, about 12% indigenous beliefs
Language: Portuguese (official); various
Bantu dialects
Infant mortality rate: 148/1,000 (1983)
Life expectancy: men 40.6, women 42.9
Literacy: 20%
Labor force: 2,783,000 economically
active (mid-1985 est.); 85% agriculture,
15% industry
Organized labor: about 450,695 (1980)','a6aa075e430238040580c1a7d97910d28929a2e3fc249b56b039e017016afe82','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a3bbddd212406fa35325c52b41bcb433fc31189aabf49e95dc716efd2b811c6',1987,'AI','Anguilla','people-and-society',32,'Population: 6,828 (1987), average annual
growth rate 0.69%
Nationality: noun—Anguillan(s); adjec-
tive—Anguillan
Ethnic divisions: mainly of black African
descent
Religion: Anglican, Methodist, and Catho-
lic
Language: English (official)
Literacy: 80%
Labor force: 2,000 Anguillans living
overseas send remittances home; 26.4%
unemployed (1984)','bd2b6fe7d7cdafcabc919e38edaa83446dd26e03f22e427ec9fd0a942924854f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd7e7b3addb1adeb68e9c02204a1296114991174ae1d22cac052fa3683a40f2',1987,'AG','Antigua and Barbuda','people-and-society',37,'Population: 69,280 (July 1987), average
annual growth rate 2.47%
Nationality: noun—Antiguan(s); adjec-
tive—Antiguan
Ethnic divisions: almost entirely of black
African origin; some of British, Portuguese,
Lebanese, and Syrian origin
Religion: Anglican (predominant), other
Protestant sects, some Roman Catholic
Language: English (official), local dialects
Infant mortality rate: 31.5/1,000 (1985)
Life expectancy: 70
Literacy: about 90%
Labor force: 30,000; 20% unemployment
(1983); agriculture 11%, industry 7%, and
commerce and services 82%','1fc0d55262362b0adaee91b6f2a7cba5f0d9761a33b8e90ce2aa9eec4aac39ff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('498bfbe6efaa4ededd6dc7e3ba46e8f5b032c823ec85ba6ceb1e16d91bdf8a5f',1987,'AR','Argentina','people-and-society',42,'Population: 31,144,775 (July 1987), aver-
age annual growth rate 1.27%
Nationality: noun—Argentine(s); adjec-
tive—Argentine
Ethnic divisions: 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant,
2% Jewish, 6% other
Language: Spanish (official), English,
Italian, German, French
Infant mortality rate: 36/1,000 (1983)
Life expectancy: 68
Literacy: 94%
Labor force: 16.8 million (1984 est.);
15.9% agriculture, 24.3% manufacturing,
13.2% commerce, 11.5% transport and
communications, 7.7% finance and bank-
ing, 4.4% utilities, 3.6% construction, 2.7%
mining, 16.7% services and other; 6.3%
unemployment (April 1985)
Organized labor: 3 million; about 33% of
labor force','e12c132614d7fe5ad05e4ded5623ceb482c80541c69e06b86b2bcf39dfd7d1dc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03f60ea3d20a2697d5e586f57260547055479a4f7090540c1492eb8b41eb1299',1987,'AW','Aruba','people-and-society',47,'Population: 62,125 (1987 est.), average
annual growth rate 0.34%
Nationality: noun—Aruban(s); adjective—
Aruban
Ethnic divisions: 85% mixed African;
remainder Carib Indian, European, Latin,
and Oriental
Religion: 82% Roman Catholic, 8% Protes-
tant; also small Hindu, Muslim, Confucian,
and Jewish minority
Language: Dutch (official), Papiamento (a
Spanish, Portuguese, Dutch, English dia-
lect), English (widely spoken), Spanish
Literacy: 95%
Labor force: 30% oil refining; 10% unem-
ployment','81be3f8d8ef3e905eafd73dd5a64902059c4ee9897e7f10196a69f79f9f4b6c6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba76d0b7f4c1bcc9c0e2d6cbe452ae27c464d655678e89c3b6b7e86cb99101d0',1987,'AU','Australia','people-and-society',52,'Population: 16,072,986 (July 1987), aver-
age annual growth rate 1.21%
Nationality: noun—Australian(s); adjec-
tive—Australian
Ethnie divisions: 96% Caucasian, 4%
Asian, Aboriginal, and other
Religion: 26.1% Anglican, 26.0% Roman
Catholic, 24.3% other Christian
Language: English, native languages
Infant mortality rate: 10/1,000 (1983)
Life expectancy; men 72.1, women 78.7
(1983)
Literacy: 98.5%
Labor force: 7.6 million (November 1986);
26.9 manufacturing and industry; 22.4
public and community services; 20.0
wholesale and retail trade; 18.1 finance
and services; 6.0% agriculture; 8.2% unem-
ployment (January 1987)
Organized labor: 62% of total employees
(1986)','6e3a352deed6d0365c69507d892cf0e223221a5f23928fed077b44b0fdabe665','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e63534c58c605c6e799ab3267fc275b5c03ab5983fcc5f1db7498f6e0a7b319',1987,'AT','Austria','people-and-society',57,'Population: 7,569,283 (July 1987), average
annual growth rate 0.09%
Nationality: noun—Austrian(s); adjective—
Austrian
Austria (continued)
Ethnic divisions: 99.4% German, 0.3%
Croatian, 0.2% Slovene, 0.1% other
Religion: 88% Roman Catholic, 6% Protes-
tant, 6% none or other
Language: German
Infant mortality rate: 16/1,000 (1983)
Life expectancy: 73
Literacy: 98%
Labor force: 2.9 million (est. 1985);
41.10% industry and crafts, 57.55% ser-
vices, 1.35% agriculture and forestry; 4.8%
unemployed (est. 1985); an estimated
200,000 Austrians are employed in other
European countries; foreign laborers in
Austria number 138,700, about 5.4% of
labor force (1984)
Organized labor: 1,672,820 members of
Austrian Trade Union Federation (1984)
Population: 238,817 (July 1987), average
annual growth rate 1.75%
Nationality: noun—Bahamian(s); adjec-
tive—Bahamian
Ethnic divisions: 85% black, 15% white
15
Religion: Baptist 29%, Anglican 23%,
Roman Catholic 22%, smaller groups of
other Protestants, Greek Orthodox, and
Jews
Language: English; some Creole among
Haitian immigrants
Infant mortality rate: 20.20/1,000 (1984)
Life expectancy: men 64, women 70
Literacy: 89%
Labor force: 82,000 (1982); 30% govern-
ment, 25% hotels and restaurants, 10%
business services, 5% agriculture; 30%
unemployment (1983)
Organized labor: 25% of labor force','28cbfc6ad1c5b7e69e6c4539aacf0994734354d918a6be58314fa4bc1ef37c18','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26e3dbb45732e5c8acd43004b83f9c319954dc661cfce4d3c6063741f6b0472f',1987,'BH','Bahrain','people-and-society',62,'Population: 464,102 (July 1987), average
annual growth rate 3.54%
Nationality: noun—Bahraini(s); adjec-
tive—Bahraini
Ethnic divisions: 63% Bahraini, 18%
Asian, 10% other Arab, 8% Iranian, 6%
other
Religion: Muslim (70% Shi''a, 80% Sunni)
Language: Arabic (official); English also
widely spoken; Farsi, Urdu
Literacy: 40%
Labor force: 140,000 (1982); 42% of labor
force is Bahraini; 85% industry and com-
merce, 5% agriculture, 5% services, 3%','c0c6bdc9a4c995c2b84fdcdac30b0d00076e93d288e663deaa7389c4aab5b52c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cad17db66e320572999b12f20aa5b678b67f93920e8d8cc0fcebd522a002af5d',1987,'IN','India','people-and-society',70,'Population: 107,087,586 (July 1987),
average annual growth rate 2.70%
Nationality: noun—Bangladeshi(s); adjec-
tive—Bangladesh :
Ethnic divisions: 98% Bengali; 250,000
Biharis and fewer than one million tribals
Religion: 83% Muslim, about 16% Hindu,
less than 1% Buddhist, Christian, and other
Language: Bangla (official), English widely
used ;
Infant mortality rate: 119.4/1,000 (1984)
Life expectancy: 53.9
Literacy: 23% (81% men, 16% women)
Labor force: 35.1 million (FY86); extensive
export of labor to Saudi Arabia, UAE,
Oman, and Kuwait; 74% of labor force is
in agriculture, 15% services, 11% industry
and commerce; unemployment and under-
employment 40% (est.)
Population: 800,325,817 (July 1987),
average annual growth rate 2.07%
Nationality: noun—Indian(s); adjective—
Indian
Ethnic divisions: 72% Indo-Aryan, 25%
Dravidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11.0% Muslim,
2.6% Christian, 2.0-2.5% Sikh, 0.7% Bud-
dhist, 0.2% other
Language: Hindi, English, and 14 other
official languages; 24 languages spoken by
a million or more persons each; numerous
other languages and dialects, for the most
part mutually unintelligible; Hindi is the
national language and primary tongue of
30 percent of the people; English enjoys
associate status but is the most important
language for national, political, and com-
mercial communication; Hindustani, a
popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Infant mortality rate: 116/1,000 (1984
est.)
Life expectancy: 54.9
Literacy: 36%
Labor force: (1984/85) about 284.4 mil-
lion; 67% agriculture; more than 10%
unemployed and underemployed
Organized labor: less than 5% of total
labor force','2eae34b6a3c97d49962265baab539eef7d349a46fed1d31512e740318c6a7c9a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08dbaeef794b9389aabc2e20bf1b0b26c0cbe184b94d220edb20029697f875b6',1987,'BB','Barbados','people-and-society',76,'Population: 323,839 (July 1987), average
annual growth rate 3.04%
Nationality: noun—Barbadian(s); adjec-
tive—Barbadian
Ethnic divisions: 80% African, 16%
mixed, 4% European
Religion: 70% Anglican, 9% Methodist, 4%
Roman Catholic, 17% other, including
Moravian
Language: English
Infant mortality rate: 26.8/1,000 (1984)
19
Life expectancy: 70.8
Literacy: 99%
Labor force: 112,800 (1985 est.); 37%
services and government; 22% commerce;
22% manufacturing and construction; 9%
transportation, storage, communications,
and financial institutions; 8% agriculture;
and 2% utilities
Organized labor: 32%','504eab50b82188c070fe13a6b950c0e5f96c32714a8dddd3d8b031a000e53ff4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77d6a31e9fc7b0d33356a17024f64fc57875ced0107500a4bc924a89ade7bf78',1987,'BE','Belgium','people-and-society',81,'Population: 9,873,066 (July 1987), average
annual growth rate 0.07%
Nationality: noun—Belgian(s); adiective—
Belgian
Ethnic divisions: 55% Fleming, 33%
Walloon, 12% mixed or other
Religion: 75% Roman Catholic; remainder
Protestant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilingual;
divided along ethnic lines
Infant mortality rate: 11.15/1,000 (1979)
Life expectancy: men 68.6, women 75.1
Literacy: 98%
Labor force: 4 million; 58% services, 37%
industry, 5% agriculture; 13.6% unem-
ployed (1985)
Organized labor: 70% of labor force','b646e34271f82ffd741c6b5dd9faf6145fd6adca16425052c2031b000586fd87','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c584075d95bf58864e3e26a4749d522bbe3d588b0406b6fb1e1f5840effff8',1987,'GT','Guatemala','people-and-society',86,'Population: 168,204 (July 1987), average
annual growth rate 1.95%
22
Nationality: noun—Belizean(s); adiec-
tive—Belizean
Ethnic divisions: 51% black, 22% mestizo,
19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-Day Adventist, Methodist, Baptist,
Jehovah’s Witnesses, Mennonite
Language: English (official), Spanish Maya,
Carib
Infant mortality rate: 56/1,000 (1984)
Life expectancy: 66
Literacy: about 90%
Labor force: 51,500 (1985); 30.0% agricul-
ture, 16.0% services, 15.4% government,
11.2% commerce, 10.3% manufacturing;
shortage of skilled labor and all types of
technical personnel; over 14% are unem-
ployed
Organized labor: 15% of labor force; 7 of
16 registered unions currently active
Population: 8,622,387 (July 1987), average
annual growth rate 2.45%
99
Nationality: noun—Guatemalan(s); adjec-
tive—Guatemalan
Ethnic divisions: 56% Ladino (mestizo
and westernized Indian), 44% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, includ-
ing Quiche, Cakchiquel, Kekchi)
Infant mortality rate: 66/1,000 (1982)
Life expectancy: 60
Literacy: 50%
Labor force (1985): 2.5 million; 57.0%
agriculture, 14.0% manufacturing, 13.0%
services, 7.0% commerce, 4.0% construc-
tion, 3.0% transport, 0.8% utilities, 0.4%
mining; unemployment and underem-
ployment 40%
Organized labor: 10% of labor force
(1986)','34ce98cba6df7bf166e4636a8b26521b3914d738738f8a8db07792968093298a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e011dc3193c845bd693dd7dfcd53116c8db108c6a103be40157ea2cfbbdd2a4',1987,'BJ','Benin','people-and-society',92,'Population: 4,339,096 (July 1987), average
annual growth rate 3.52%
Nationality: noun—Beninese (sing., pl.);
adiective—Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adia,
Yoruba, Bariba); 5,500 Europeans
Benin (continued)
Religion: 70% indigenous beliefs, 15%
Muslim, 15% Christian
Language: French (official); Fon and
Yoruba most common vernaculars in
south; at least six major tribal languages in
north
Infant mortality rate: 45/1,000 (1984)
Life expectancy: 46.9
Literacy: 11%
Labor force: 1.5 million (1982); 60% of
labor force employed in agriculture; less
than 2% of the labor force work in the
industrial sector, and the remainder are
employed in transport, commerce, and
public services
Organized labor: about 75% of wage
earners (two major and several minor
unions)
Population: 108,579,764 (July 1987),
average annual growth rate 2.93%
Nationality: noun—Nigerian(s); adjec-
tive—Nigerian
183
Ethnic divisions: more than 250 tribal
groups; Hausa and Fulani of the north,
Yoruba of the southwest, and Ibos of the
southeast comprise 65% of the population;
about 27,000 non-A fricans
Religion: 50% Muslim, 40% Christian, 10%
indigenous beliefs
Language: English (official); Hausa,
Yoruba, Ibo, Fulani, and several other
languages also widely used
Infant mortality rate: 113/1,000 (1983)
Life expectancy: men 47, women 50
(1983)
Literacy: 25-30%
Labor force: est. 45-50 million (1984); 54%
agriculture; 19% industry, commerce, and
services; 15% government
Organized labor: 3.52 million wage earn-
ers belong to one of 42 recognized trade
unions, which are under a single national
labor federation, the Nigerian Labor
Congress (NLC)','8d07c4da9ad04e0979beecf93600e8db7757c2da5dc45c5b1655af24255caed9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b17a718f68e3f333ba2243a7def6458664112615b11db36f54af56ffce87c02e',1987,'BM','Bermuda','people-and-society',97,'Population: 58,033 (July 1987), average
annual growth rate 0.18%
Nationality: noun—Bermudian(s); adjec-
tive—Bermudian
Ethnic divisions: 61% black, 39% white
and other
Religion: 37% Anglican, 14% Roman
Catholic, 10% African Methodist Episcopal
(Zion), 6% Methodist, 5% Seventh-Day
Adventist, 28% other
Language: English
Infant mortality rate: 7.1/1,000 (1985)
Life expectancy: men 69, women 76
Literacy: 98%
Labor force: 32,000 employed (1984); 25%
clerical, 22% services, 21% laborers, 13%
professional and technical, 10% adminis-
trative and managerial, 7% sales, 2%
agriculture and fishing
Organized labor: 8,573 members (1985);
largest union is Bermuda [ndustrial Union','ddfb8b13aa564d0660b9811ac69a0e5a74159ef82cf31ec346d72f1852dfaeb6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e59f1402662716de906fdd68703b413a820aadf9c3d72ab2668cbfe369aaf7f',1987,'BT','Bhutan','people-and-society',102,'Population: 1,472,911 (July 1987), average
annual growth rate 2.03%
Nationality: noun—Bhutanese (sing., pl.);
adiective—Bhutanese
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant
tribes
Religion: 75% Lamaistic Buddhism, 25%
Indian- and Nepalese-influenced Hinduism
Language: Bhotes speak various Tibetan
dialects—most widely spoken dialect is
Dzongkha (official); Nepalese speak various
Nepalese dialects
Infant mortality rate: 162/1,000 (1983)
Life expectancy: 43
Literacy: 5%
Labor force: 95% agriculture, 1% industry
and commerce (1983); massive lack of
skilled labor
Population: 6,309,642 (July 1987), average
annual growth rate 2.19%
Nationality: noun—Bolivian(s); adjective
Bolivian
Ethnic divisions: 30% Quechua, 25%
Aymara, 25-30% mixed, 5-15% European
Religion: 95% Roman Catholic; active
Protestant minority, especially Methodist
Language: Spanish, Quechua, and Aymara
(all official)
Infant mortality rate: 142/1,000 (1983)
Life expectancy: 49
Literacy: 63%
Labor force: 1.7 million (1983); 50%
agriculture, 26% services and utilities, 10%
manufacturing, 4% mining, 10% other
Organized labor: 150,000-200,000, con-
centrated in mining, industry, construc-
tion, and transportation; mostly organized
under Bolivian Workers’ Central (COB)
labor federation','5b28bedd25c26b413d4a597aad74ac558a0236888e0b05ab934a9dcbf7b157d7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('888a6bde6122385ab00216ec3c386b4a46d6356accf18a5b83fc81f347cf1732',1987,'BW','Botswana','people-and-society',107,'Population: 1,149,141 (July 1987), average
annual growth rate 3.48%
Nationality: noun—Motswana (sing.),
Botswana (pl.); adjective—Botswana
Ethnic divisions: 95% Batswana; about 4%
Kalanga, Basarwa, and Kgalagadi; about
1% white
Religion: 50% indigenous beliefs, 50%
Christian
Language: English (official), Setswana
28
Infant mortality rate: about 63/1,000
(1985)
Life expectancy: 63.5 (1985)
Literacy: about 24% in English; about 35%
in Tswana; less than 1% secondary school
graduates
Labor force: about 400,000 total; 110,000
formal sector employees (1984); most
others are engaged in cattle raising and
subsistence agriculture; 40,000 formal
sector employees spend at least six to nine
months per year as wage earners in South
Africa (1980); 17% unemployment (1983)
Organized labor: 16 trade unions orga-
nized','170547b9cb5a256c8628a3ff542a6f2ff6c4488023821eb4da8d117a8bbb1356','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c24dd29ff03325b92ca035bcb3357e67eae09b7dd0ee1a280b67509bf6f1cc6',1987,'BR','Brazil','people-and-society',112,'Population: 147,094,739 (July 1987),
average annual growth rate 2.45%
Nationality: noun—Brazilian(s); adjec-
tive—Brazilian
Ethnic divisions: Portuguese, Italian,
German, Japanese, black, Amerindian;
55% white, 38% mixed, 6% black, 1%
other
Religion: (1980) 89% Roman Catholic
(nominal)
Language: Portuguese (official), English
Infant mortality rate: 70/1,000 (1986)
Life expectancy: 62.8
Literacy: 76%
Labor force: 50 million in 1984; 40%
services, 35% agriculture, 25% industry
Organized labor: about 25 million (1986)
Population: no permanent civilian popula-
tion; formerly about 3,000 islanders
Ethnic divisions: civilian inhabitants,
known as the Ilois, evacuated to Mauritius _
before construction of UK and US defense
facilities
Population: 12,374 (July 1987), average
annual growth rate 2.12%
Nationality: noun—Virgin Islander(s);
adjective—Virgin Islander
Ethnic divisions: over 90% black, remain-
der of white and Asian origin
Religion: majority Methodist; others in-
clude Anglican, Church of God, Seventh-
Day Adventist, Baptist, and Roman
Catholic
82
Language: English (official)
Literacy: 98.3%
Work force: 4,911 (1980)
Population: 249,961 (July 1987), average
annual growth rate 3.67%
83
Nationality: noun—Bruneian(s); adjec-
tive—Bruneian
Ethnic divisions: 64% Malay, 20% Chi-
nese, 16% other
Religion: 60% Muslim (official); 8% Chris-
tian; 32% Buddhist and indigenous beliefs
Language: Malay (official), English, and
Chinese
Life expectancy: 73.7
Literacy: 45%
Labor force: 68,128 (includes members of
the Army); 50.4% production of oil, natu-
ral gas, and construction; 47.6% trade,
services, and other; 2.0% agriculture,
forestry, and fishing (1984)
Organized labor: 2% of labor force','5da54307b86e9f7de0e05a2dc269b2772732a080f045fc65d9c7a89f474581ec','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd08997013541acb14addf32ead6fefe56eed1c621b4d2beca34b0fad417c5c',1987,'BG','Bulgaria','people-and-society',117,'Population: 8,960,749 (July 1987), average
annual growth rate 0.08%
Nationality: noun—Bulgarian(s); adjec-
tive—Bulgarian
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, 0.3%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; relig-
ious background of population is 85%
Bulgarian Orthodox, 18% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protes-
tant, Gregorian-Armenian, and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Infant mortality rate: 20.2/1,000 (1983)
Life expectancy: men 69, women 74
Literacy: 95% (est.)
Labor force: 4,113,546 (1983); 34% indus-
try, 22% agriculture, 44% other
Population: 8,276,272 (July 1987), average
annual growth rate 2.42%
Nationality: noun—Burkinabe; adjective—
Burkinabe
Ethnic divisions: more than 50 tribes;
principal tribe is Mossi (about 2.5 million);
other important groups are Gurunsi, Se-
nufo, Lobi, Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about
25% Muslim, 10% Christian (mainly Cath-
olic)
Language: French (official); tribal lan-
guages belong to Sudanic family, spoken
by 50% of the population
Infant mortality rate: 182/1,000 (1984)
Life expectancy: 42
Literacy: 7%
Labor force: 90% agriculture; 10% indus-
try, commerce, services, and government;
about 30,000 are wage earners; about 20%
of male labor force migrates annually to
neighboring countries for seasonal employ-
ment
Organized labor: four principal trade
union groups represent less than 1% of
population
Population: 38,822,484 (July 1987), aver-
age annual growth rate 2.08%
Nationality: noun—Burmese; adjective—
Burmese
Ethnic divisions: 68% Burman, 9% Shan,
7% Karen, 4% Raljome, 3% Chinese, 2%
Indian, 7% other
Religion: 85% Buddhist, 15% indigenous
beliefs, Muslim, Christian, or other
Language: Burmese; minority ethnic
groups have their own languages
Infant mortality rate: 96/1,000 (1986)
Life expectancy: 57
Literacy: 78%
Labor force: 14.8 million (est. 1985/86);
66.1% agriculture, 12.0% industry, 10.6%
government, 9.7% trade, 1.6% other
Organized labor: Workers’ Asiayone or
association (1.8 million members) and
Peasants’ Asiayone (7.6 million members)
integrated into the country’s sole political
party','0cffe2e693b141a3cefc16a924e068cfe59d91e2b1145e7fe6d8ab54775b2ce9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ac9f9d153645b74e586953ea176fa8e07f0bd531fffd84400a7d3054ce47ba',1987,'BI','Burundi','people-and-society',122,'Population: 5,005,504 (July 1987), average
annual growth rate 2.92%
Nationality; noun—Burundian(s); adjec-
tive—Burundi
Ethnic divisions: Africans—85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and
Zairians; non-Africans include about 3,000
Europeans and 2,000 South Asians
Religion: abont 67% Christian (62% Ro-
man Catholic, 5% Protestant), 32% indige-
nous beliefs, 1% Muslim
Language: Kirundi and French (official);
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Infant mortality rate: 121/1,000 (1983)
Life expectancy: 42.3
Literacy: 25%
Labor force: about 1.9 million (1983);
93.0% agriculture, 4.0% government, 1.5%
industry and commerce, 1.5% services
Organized labor: sole group is the Union
of Burundi Workers (UTB); by charter,
membership is extended to all Burundi
workers (informally), figures denoting
active membership unobtainable','82de4480fc56f56cdf7dffcdbd1783c00337411dbbd32b9179cb18ced816cf0c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05647dc7d9b1073bc185127e78133f873b7d1af8dbe9a27047fb346550f42e30',1987,'TH','Thailand','people-and-society',127,'Population: 6,536,079 (July 1987), average
annual growth rate 2.26%.
Nationality: noun—Cambodian(s); adjec-
tive—Cambodian
Ethnic divisions: 90% Khmer (Cambo-
dian), 5% Chinese, 5% other minorities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Life expectancy: men 42, women 44.9
Literacy: 48%
Population: 53,645,823 (July 1987), aver-
age annual growth rate 1.78%
Nationality: noun—Thai (sing. and pl.);
adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95.5% Buddhist, 4% Muslim,
0.5% other
Language: Thai; English is the secondary
language of the elite; ethnic and regional
dialects
Infant mortality rate: 51.4/1,000 (1985)
Life expectancy: men 59.5, women 65.1
Literacy: 82%
Labor force: 26 million (1984); 73% agri-
culture, 11% industry and commerce, 10%
services, 6% government; 8% unemploy-
ment rate','86ed2a8c406f24472b1f93fa8d725ca62266fc7ca593731fe0865b1060bed647','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca21d90c27c357b5d6306afe2d2421731fc41f1aea30e057bcf0ad08324a2392',1987,'CM','Cameroon','people-and-society',132,'Population: 10,255,332 (July 1987), aver-
age annual growth rate 2.66%
Nationality: noun—Cameroonian(s); adjec-
tive—Cameroonian
4l
Ethnic divisions: over 200 tribes of widely
differing background; 31% Cameroon
Highlanders, 19% Equatorial Bantu, 11%
Kirdi, 10% Fulani, 8% Northwestern
Bantu, 7% Eastern Nigritic, 18% other
African, less than 1% non-African
Religion: 51% indigenous beliefs, 33%
Christian, 16% Muslim
Language: English and French (official),
24 major African language groups
Infant mortality rate: 113/1,000 (1985)
Life expectancy: 44
Literacy: 65%
Labor force: (1983) 74.4% agriculture,
11.4% industry and transport, 14.2% other
services
Organized labor: under 45% of wage
labor force','34a0d0f3d2a92ce0acfca471bb2b5dd35b725f537f893f37049875d5fde1b0f6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('592c0b6e28ceda14f5b6e234022a17b82d554c0842cfcb79a01605387bfe48a6',1987,'CA','Canada','people-and-society',137,'Population: 25,857,943 (July 1987), aver-
age annual growth rate 0.91%
Nationality: noun—Canadian(s); adjec-
tive—Canadian
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 16%
United Church, 10% Anglican
Language: English and French (official)
Infant mortality rate: 9.1/1,000 (1982)
Life expectancy: men 71.9, women 79
Literacy: 99%
Labor force: 12.88 million (1986 average);
68% services (37% government, 23% trade
and finance, 8% transportation), 18%
manufacturing, 6% construction, 3.8%
agriculture, 4.2% other; 9.6% unemploy-
ment (1986 average)
Organized labor: 80.6% of labor force;
39.6% of nonagricultural paid workers
Population: 344,282 (July 1987), average
annual growth rate 2.61%
Nationality: noun—Cape Verdean(s);
adjective—Cape Verdean
Ethnic divisions: about 71% Creole
(mulatto), 28% African, 1% European
44
Religion: Catholicism fused with indige-
nous beliefs
Language: Portuguese and Crioulo, a
blend of Portuguese and West African
words
Infant mortality rate: 60/1,000 (1983)
Life expectancy: 61
Literacy: 837%
Labor force: bulk of population engaged
in subsistence agriculture','288b1b95f63b87d9343fc9d7b51a8e0615e9fe1c0dbebcfd31f2983b63d1d7af','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da5cb9df1731ca05b10aef21a5057b32b3a21c62cd84b7615fad8cdb5411417',1987,'KY','Cayman Islands','people-and-society',142,'Population: 23,192 (July 1987), average
annual growth rate 3.46%
Nationality: noun—Caymanian(s); adjec-
tive—Caymanian
Ethnic divisions: 40% mixed, 20% white,
20% black, 20% expatriates of various
ethnic groups
Religion: United Church (Presbyterian
and Congregational), Anglican, Baptist,
Roman Catholic, Church of God, other
Protestant denominations
Language: English
45
Literacy: 97.5%
Labor force: 8,061; 18.7% service workers,
18.6% clerical, 12.5% construction, 6.7%
finance and investment, 5.9% directors and
business managers (1979)
Organized labor: Global Seaman’s Union;
Cayman All Trade Union','90fc4bf1c15ebdfc734cb94be9ab62cd68b8c8f2c57133b45e2d3fc5ea49d68d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67cbb1353661051eba7bc8da25985c9db0fa8dbc35dbfd9c7f4dc4e9d8701b2f',1987,'CF','Central African Republic','people-and-society',147,'Population: 2,669,293 (July 1987), average
annual growth rate 2.44%
Nationality: noun—Central African(s),
adjective—Central African
Ethnic divisions: about 80 ethnic groups,
the majority of which have related ethnic
and linguistic characteristics; 34% Baya,
27% Banda, 10% Sara, 21% Mandiia, 4%
Mboum, 4% M’Baka; 6,500 Europeans, of
whom 3,600 are French
46
Religion: 24% indigenous beliefs, 25%
Protestant, 25% Roman Catholic, 15%
Muslim; animistic beliefs and practices
strongly influence the Christian majority
Language: French (official); Sangho (lingua
franca and national language); Arabic,
Hunsa, Swahili
Infant mortality rate: 134/1,000 (1986)
Life expectancy: 44
Literacy: 20%
Labor force: 775,413 (1986 est.); 85%
agriculture, 8.9% commerce and services,
2.9% industry, 3% government; about
64,000 salaried workers
Organized labor: 1% of labor force','39be5b95bdc21176b2d68b002a600506c0def6460f6149896dbc2c72e46dcd2a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41f1ff3286808e9465008e6f0227a3b7a1f662953e41fbd606d5340df54e16f8',1987,'TD','Chad','people-and-society',152,'Population: 4,646,054 (July 1987), average
annual growth rate 2.44%
Nationality: noun—Chadian(s); adjec-
tive—Chadian
Ethnic divisions: some 200 distinct ethnic
groups, most of whom are Muslims (Arabs,
Toubou, Fulbe, Kotoko, Hausa, Kanem-
bou, Baguirmi, Boulala, and Maba) in the
Chad (continued)
north and center and non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moudang,
Moussei, Massa) in the south; some 150,000
nonindigenous, of whom 1,000 are French
Religion: 44% Muslim, 23% indigenous
beliefs, 33% Christian
Language: French and Arabic (official);
Sara and Sango in south; more than 100
different languages and dialects are spoken
Infant mortality rate: 142/1,000 (1983)
Life expectancy: men 42.0, women 45.0
Literacy: about 17%
Labor force: 85% agriculture (engaged in
unpaid subsistence farming, herding, and
fishing)
Organized labor: about 20% of wage labor
force','7d80535bbb96cd35b13611de61176d6abe7bd1524e85aad63071c7b64f3427fe','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f560b465cef22b671134b922611f05df146dccea409bde0eddd4273c42b368c1',1987,'CL','Chile','people-and-society',157,'Population: 12,448,008 (July 1987), aver-
age annual growth rate 1.54%
Nationality: noun—Chilean(s); adjective—
Chilean
Ethnic divisions: 95% European and
European-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11%
Protestant, and small Jewish population
Language: Spanish
Infant mortality rate: 20/1,000 (1984)
Life expectancy: men 63.8, women 70.4
Literacy: 94%
Labor force: 3.84 million; 38.6% services
(including government—12%), 31.3%
industry and commerce; 15.9% agriculture,
forestry, and fishing; 8.7% mining; 4.4%
construction (1985); unemployed 13.9%
(1984)
Organized labor: 12% of labor force
organized into labor unions (1982)','9cc121520998fcf513db309c269378c0b75b5db1b3c47872093e73a70edda695','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a0990e9993b9e2559ea512f0ff7c612502b96ad926dcbbf52d0aa4220b7be65',1987,'CN','China','people-and-society',162,'Population: I ,064,147,038 (July 1987),
average annual growth rate 0.99%
Nationality: noun—Chinese (sing., pl.);
adjective—Chinese
Ethnic divisions: 93.8% Han Chinese;
6.7% Zhuang, Uygur, Hui, Yi, Tibetan,
Miao, Manchu, Mongol, Buyi, Korean, and
numerous lesser nationalities
Religion: officially atheist, but traditionally
pragmatic and eclectic; most important
elements of religion are Confucianism,
Taoism, and Buddhism; about 2-3% Mus-
lim, 1% Christian
Language: Standard Chinese (Putonghua)
or Mandarin (based on the Beijing dialect);
also Yue (Cantonese), Wu (Shanghainese),
Minbei (Fuzhou), Minnan (Hokkien-
Taiwanese), Xiang, Gan, Hakka dialects,
and minority languages (see ethnic divi-
sions)
Life expectancy: 68
Literacy: over 75%
Labor force: 476 million (1984 est.); 68.2%
agriculture and forestry, 18.2% industry
and commerce, 3.9% construction and
mining, 3.7% social services, 6% other
Organized labor: All-China Federation of
Trade Unions (ACFTU) follows the leader-
ship of the Chinese Communist Party;
membership over 80 million (about 65% of
the urban work force) (1985)
Population: 122,124,293 (July 1987),
average annual growth rate 0.55%
Nationality: noun—Japanese (sing., pl.);
adjective—Japanese
Ethnic divisions: 99.4% Japanese, 0.6%
other (mostly Korean)
Religion: most Japanese observe both
Shinto and Buddhist rites; about 16%
belong to other faiths, including 0.8%
Christian
Language: Japanese
Infant mortality rate: 6/1,000 (1984)
Life expectancy: men 74.54, women 80.18
Literacy: 99%
Labor force: (1985) 59.3 million; 53%
trade and services; 33% manufacturing,
mining, and construction; 9% agriculture,
forestry, and fishing; 3% government;
2.68% unemployed (1985 average)
Organized labor: about 80% of labor force','951153593485236f1dec607cfd7683d70ee0f612c724701a19516bffabea8f91','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f5f85decefc469cc9a76f56331c23acc4599fe3a96708230f84842636a7ed3c',1987,'CX','Christmas Island','people-and-society',167,'Population: 2,243 (July 1987), average
annual growth rate -0.76%
Nationality: noun—Christmas Islander(s),
adjective—Christmas Island
Ethnic divisions: 61% Chinese, 25%
Malay, 11% European, 3% other; no indig-
enous population
Language: English
52
Labor force: all workers are employees of
the Phosphate Mining Company of Christ-
mas Island, Ltd.','ab23f08985e316cfbe663668947bdba8218b2ae49e01bd678268e5dd25143fc4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c379e0c501fa85b5054d7601256b5b3c6ef1f4775fbca5c725f06a5793c6320',1987,'CO','Colombia','people-and-society',172,'Population: 30,660,504 (July 1987), aver-
age annual growth rate 2.07%
Nationality: noun—Colombian(s); adjec-
tive—Colombian
Ethnic divisions: 58% mestizo, 20% white,
14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Infant mortality rate: 56/1,000 (1985);
Indians about 233/1,000
Life expectancy: 65 (1985); Indians about
34
Literacy: 87.8% (1985 est.); Indians about
40%
Labor force: 11 million (1986); 53% ser-
vices, 26% agriculture, 21% industry
(1981); 14% official unemployment (1985)
Organized labor: 900,000 members (1986),
about 8 percent of labor force','fb2a90ff560a603fac1c8729e8261d489c19d3c8ff750a55c183dab5853a4142','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd73ad7bd4136af709d6f9c0ec21a4167a666d84e590667ba45b751f51767323',1987,'YT','Mayotte','people-and-society',178,'Population: 415,220 (July 1987), average
annual growth rate 3.82%
Nationality: noun—Comoran(s); adjec-
tive—Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dialect),
Malagasy, French
Infant mortality rate: 92.3/1,000 (1983)
Life expectancy: 48.8
Literacy: 15%
Labor force: 140,000 (1982); 80% agricul-
ture, 3% government; significant unem-
ployment','f272b9e85dbb447caf0aff7f3f97cbd3543acccdd79e0bc4413699a702be4937','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d112b4e8b36dd33213cf0f4e916a189224b448a522431efc34d42f727927324b',1987,'CG','Congo','people-and-society',183,'Population: 2,082,154 (July 1987), average
annual growth rate 3.38%
Nationality: noun—Congolese (sing., pl.);
adjective—Congolese or Congo
Ethnic divisions: about 15 ethnic groups
divided into some 75 tribes, almost all
Bantu; most important ethnic groups are
Kongo (48%) in the south, Sangha (20%)
Congo (continued)
and M’Bochi (12%) in the north, Teke
(17%) in the center; about 8,500 Europe-
ans, mostly French
Religion: 42% animist, 50% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Infant mortality rate: 200/1,000 (1985)
Life expectancy: 46.5
Literacy: over 80%
Labor force: about 40% of population
economically active (1985); 75% agricul-
ture, 25% commerce, industry, govern-
ment; 79,100 wage earners; 40,000-60,000
unemployed
Organized labor: 20% of total labor force
(1979 est.)','99217f4c542b87c45843d0ff48083fb9eddaa49472908e9e6ae14117e7a7bcbe','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6964f6aaa57662dee77d42aa2cac9108d009b836b137b7f43a40482a28b1c8c8',1987,'CK','Cook Islands','people-and-society',188,'Population: 17,898 (July 1987), average
annual growth rate 0.55%
Nationality: noun—Cook Islander(s);
adjective—Cook Islander
Ethnic divisions: 81.3% Polynesian (full
blood), 7.7% Polynesian and European,
7.7% Polynesian and other, 2.4% Euro-
pean, 0.9% other
Religion: Christian, majority of populace
members of Cook Islands Christian Church
Language: English','7522f3513fd0490af1998016b4a3b0cee16ada04a227640ca37fcef3da693b4b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c61f3ea5a8779c7b2370418fcaf284782020a605890ed2668fc66ba23a12fd3',1987,'CR','Costa Rica','people-and-society',193,'Population: 2,811,652 (July 1987), average
annual growth rate 2.78%
Nationality: noun—Costa Rican(s); adjec-
tive—Costa Rican
Ethnic divisions: 96% white (including
mestizo), 3% black, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), with Jamai-
can dialect of English spoken around
Puerto Limon
Infant mortality rate: 18.8/1,000 (1983)
Life expectancy: men 67.5, women 71.9
Literacy: 93%
Labor force: 868,300 (1985 est.); 34%
industry and commerce, 27% agriculture,
21% government and services, 8% other;
10% unemployment (1985 est.)
Organized labor: about 15.1% of labor
force','205fd4ffc645426a7f802db03db86c043f4d660ffa0aa8b164b032746776d9a0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79284159f4480a59458c033021bac198a5b254459e2264d3562a4cbcc1c085d0',1987,'CU','Cuba','people-and-society',198,'Population: 10,259,473 (July 1987), aver-
age annual growth rate 0.90%
Nationality: noun—Cuban(s); adjective—
Cuban
Cuba (continued)
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Infant mortality rate: 15/1,000 (1985)
Life expectancy: 74
Literacy: 96%
Labor force: 3.0 million; 47% industry and
commerce, 28% services and government,
25% agriculture (1982)','063e73ad7a490a648ba0c7951f2aadf0ecacae02b33bfd672282814358d6f1e8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d40b1c71cb0791dc1d5525169292f32e8f805e81663cb931aadcda877c6bbf0',1987,'CY','Cyprus','people-and-society',203,'Population: 683,651 (July 1987), average
annual growth rate 1.26%
Nationality: noun—Cypriot(s); adjective—
Cypriot
Ethnic divisions: 78% Greek; 18% Turk-
ish; 4% Armenian, Maronite, and other
Religion: 78% Greek Orthodox; 18%
Muslim; 4% Maronite, Armenian, Apos-
tolic, and other
Language: Greek, Turkish, English
Infant mortality rate: 17/1,000 (1984)
Life expectancy: men 72.8, women 76.0
(1981)
Literacy: about 99%
Greek Sector labor force: 251,406; 42%
services, 33% industry, 22% agriculture;
3.4% unemployed (1986)
Population: 15,581,993 (July 1987), aver-
age annual growth rate 0.26%
Nationality: noun—Czechoslovak(s); adjec-
tive—Czechoslovak
Ethnic divisions: 64.3% Czech, 30.5%
Slovak, 3.8% Hungarian, 0.4% German,
0.4% Polish, 0.3% Ukrainian, 0.1% Russian,
0.2% other (Jewish, Gypsy)
Religion: 77% Roman Catholic, 20%
Protestant, 2% Orthodox, 1% other
Language: Czech and Slovak (official),
Hungarian
Infant mortality rate: 16/1,000 (1983)
Life expectancy: 71.6 (1985)
Literacy: 99%
Labor force: 7.6 million (1985); 38.1%
industry; 12.5% agriculture; 49.4% con-
struction, communications, and other
(1982)','7da68b3d0ef2c7e633cadc771a431728ec61b01b7fc5f5c926f9956338c6cc67','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02440ab4eaf215c0708bbe95a801ba5776dfeb6716ed8758440059244de2bbf',1987,'DK','Denmark','people-and-society',208,'Population: 5,121,766 (July 1987), average
annual growth rate 0.07%
Nationality: noun—Dane(s); adjective—
Danish
Ethnic divisions: Scandinavian, Eskimo,
. Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic
(an Eskimo dialect); small German-
speaking minority
Infant mortality rate: 7.7/1,000 (1983)
Life expectancy: men 71.5, women 77.5
Literacy: 99%
Labor force: 2,779,000 (1985); 33.2%
government; 20.7% manufacturing; 13.2%
commerce; 2.0% agriculture, forestry, and
fishing; 5.9% construction; 7.5% banking
and business services; 7.2% transportation;
10.8% unemployment rate
Organized labor: 65% of labor force','339429303a9c5580b4b746743f7c8c6b9fef45d5ca3242ddeb2dbbf89c46e500','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2abeffc1f091ee20fdcd6540522d091587d13484458302c4ce0d5eed8676e50f',1987,'DJ','Djibouti','people-and-society',213,'Population: 312,405 (July 1987), average
annual growth rate 2.538%
Nationality: noun—Djiboutian(s); adjec-
tive—Diiboutian
Djibouti (continued)
Ethnic divisions: 60% Somali (Issa); 35%
Afar, 5% French, Arab, Ethiopian, and
Italian
Religion: 94% Muslim, 6% Christian
Language: French (official); Arabic, So-
mali, and Afar widely used
Infant mortality rate: 140/1,000 (1985)
Life expectancy: 50
Literacy: 20%
Labor force: a small number of semi-
skilled laborers at port; 3,000 railway
workers
Organized labor: 3,000 railway workers','d248619040e0b6aeed09995670245e15c3b30af0058256a18117284a03d977ca','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ec95d4baa6b3074856bb709d8b90034bf4dd227ccb64fdaf7acb19753caee0',1987,'DM','Dominica','people-and-society',218,'Population: 94,191 (July 1987), average
annual growth rate 3.80%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: mostly black; some
Carib-Indians
Religion: 80% Roman Catholic; Anglican,
Methodist
Language: English (official); French patois
widely spoken
Infant mortality rate: 24.1/1,000 (1981)
Life expectancy: men 57, women 59.
Literacy: about 80%
Labor force: 25,000; 40% agriculture, 32%
industry and commerce, 28% services;
15-20% unemployment (1984)
Organized labor: 25% of labor force','e4d38187ba566fbc0327e7e5257f94a52b8d4a26f356ad52b2492db73e2c57c6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d932fe374b461e523bda9f88131eae836644f7fe256e20c805bb6c0522717eb',1987,'DO','Dominican Republic','people-and-society',223,'Population: 6,960,743 (July 1987), average
annual growth rate 2.49%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Dominican Republic (continued)
Language: Spanish
Infant mortality rate: 63/1,000 (1983)
Life expectancy: 60
Literacy: 68%
Labor force: over 2 million (1986); 45%
agriculture, 34% industry, 16% services
Organized labor: between 200,000 and
250,000 (1986); 10-15% of labor force','2bd93d22341093f72587fc88a447e91b6a5295466f14618b3f879f9ca55a7c05','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7626bcd9b954f7f13b93c9838f934089e1293698510fdd0556978e1fa995ba73',1987,'EC','Ecuador','people-and-society',228,'Population: 9,954,609 (July 1987), average
annual growth rate 2.80%
Nationality: noun—Ecuadorean(s); adjec-
tive—Ecuadorean
Ethnic divisions: 55% mestizo (mixed
Indian and Spanish), 25% Indian, 10%
Spanish, 10% black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian lan-
guages, especially Quechua
Infant mortality rate: 68.4/1,000 (1984)
Life expectancy: 64 (1984)
Literacy: 85% (1981)
Labor force: (1983) 2.8 million; 52%
agriculture, 18% manufacturing, 7% com-
merce, 4% construction, 4% public admin-
istration, 16% other services and activities
Organized labor; less than 15% of labor
force','ba8831908d298d52df1fe24f5d1de04d0b4abf82975e14f69a39998fe76745cd','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('814968d5a055e8e8dc062039fe355c776d3f9a5b48d0dbff72f91a2cf9274cdd',1987,'EG','Egypt','people-and-society',233,'Population: 51,929,962 (July 1987), aver-
age annual growth rate 2.74%
Nationality: noun—Egyptian(s); adjec-
tive—Egyptian
Ethnic divisions: 90% Eastern Hamitic
stock; 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official), English and
French widely understood by educated
classes
Infant mortality rate: 94/1,000 (1984)
Life expectancy: 60
Literacy: 40%
Labor force: about 13.0 million (1985);
40-45% agriculture, 36% government (local
and national), public sector enterprises,
and armed forces; 20% privately owned
service and manufacturing enterprises
(1984); shortage of skilled labor; unemploy-
ment about 7% (official estimate); esti-
mated 2.0 million Egyptians work abroad,
mostly in Iraq and the Gulf Arab states
(1986)
Organized labor: about 2.5 million
Population: 5,260,478 (July 1987), average
annual growth rate 2.37%
Nationality: noun—Salvadoran(s); adjec-
tive—Salvadoran
72
Ethnic divisions: 89% mestizo, 10% In-
dian, 1% white
Religion: about 97% Roman Catholic, with
activity by Protestant groups throughout
the country
Language: Spanish, Nahua (among some
Indians)
Infant mortality rate: 41/1,000 (1984)
Life expectancy: men 62.6, women 66.3
Literacy: 65%
Labor force: 1.7 million (est. 1982); 40%
agriculture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
services, 6% transportation (1984 est.);
shortage of skilled labor and large pool of
unskilled labor, but manpower training
programs improving situation; significant
unemployment and underemployment
Organized labor: 8% total labor force;
10% agricultural labor force; 7% urban
labor force (1982)','a4d845bd4fdd4eaa4959b1392a9c9eea8144a7ada850390b1c684a3fc6b509e7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ac3392a630a261bca2cc543096b2d82d0c19029037fef25aefb49390bd484c',1987,'GQ','Equatorial Guinea','people-and-society',238,'Population: 340,434 (July 1987), average
annual growth rate 1.83%; includes Rio
Muni 265,281, average annual growth rate
1.83%, and Bioko 75,153, average annual
growth rate 1.83%
Nationality: noun—Equatorial Guinean(s):
adjective-—Equatorial Guinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernandinos,
Rio Muni, primarily Fang; less than 1,000
Europeans, mostly Spanish
Religion: natives all nominally Christian
and predominantly Roman Catholic; some
pagan practices retained
Language: Spanish (official), pidgin En-
glish, Fang
Infant mortality rate: 142.9/1,000 (1984)
Life expectancy: men 44, women 48
Literacy: 55%
Labor force: most involved in subsistence
agriculture; labor shortages on plantations','5d339f6ddf754888cd4151a12c899429594098ef096a57d903ea64751fc8acdf','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6abd3ddd99361307df103a50d84862cc0d79c2a61ef5a34ff52ecc5d078a22c4',1987,'ET','Ethiopia','people-and-society',244,'Population: 46,706,229 (July 1987), aver-
age annual growth rate 3.69%
Nationality: noun—Ethiopian(s); adjec-
tive—Ethiopian
Ethnic divisions: 40% Oromo, 32%
Amhara and Tigrean, 9% Sidamo, 6%
Shankella, 6% Somali, 4% Afar, 2%
Gurage, 1% other
Religion: 40-45% Muslim, 35-40% Ethio-
pian Orthodox, 15-20% animist, 5% other
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Infant mortality rate: 145/),000 (1983)
Life expectancy: 38
Literacy: about 35%
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and
quasi-government
Organized labor: All Ethiopian Trade
Union formed by the government in
January 1977 to represent 273,000 regis-
tered trade union members
Population; 1,821 (July 1987), average
annual growth rate 0.00%; population may
be declining slightly each year
76
Nationality: noun—Falkland Islander(s);
adjective—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Anglican
Language: English
Literacy: compulsory education up to age
14
Labor force: 1,100 (est.); about 95% in
agriculture, mostly sheepherding','31170def6f1df634493febbe8428975fe0ca936fb6276d137958471645fae352','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0c1605ee49e09ce58d878cf8e9aa01220a904f3d2e6973e9c4c6392a903edc9',1987,'FO','Faroe Islands','people-and-society',249,'Population: 46,429 (July 1987), average
annual growth rate 0.91%
Nationality: noun—Faroese (sing., pl.);
adjective—Faroese
ae
Ethnic divisions: homogeneous white
population
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in
fishing, manufacturing, transportation, and
commerce
Population: 727,902 (July 1987), average
annual growth rate 2.25%
Nationality: noun—Fijian(s), adjective—
Fijian
Ethnic divisions: 50% Indian, 45% Fijian;
5% European, other Pacific Islanders,
overseas Chinese, and others
Religion: Fijians are mainly Christian,
Indians are Hindu with a Muslim minority
78
Language: English (official); Fijian;
Hindustani
Infant mortality rate: 29/1,000 (1983)
Life expectancy: 72
Literacy: 80%
Labor force: 176,000 (1979); 40% of total
work force paid employees, remainder
involved in subsistence agriculture; 43.4%
agriculture, 15.6% industry
Organized labor: about 45,000 employees
belong to some 46 trade unions, which are
organized along lines of work and ethnic
origin (1983)','0fe76586429affd572d81b7a041232927cb6b312514abf7eac9a8eb9a6f1cc8a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a06d0b0bcb57507b6f99d45cdff31a709f4a01deeb08c90dc837baeb33b7522d',1987,'FI','Finland','people-and-society',254,'Population: 4,939,880 (July 1987), average
annual growth rate 0.86%
Nationality: noun—Finn(s); adjective—
Finnish
Ethnic divisions: Finn, Swede, Lapp,
Gypsy, Tatar
Religion: 97% Evangelical Lutheran, 1.2%
Greek Orthodox, 1.8% other
Language: 93.5% Finnish, 6.8% Swedish
(both official); small Lapp- and Russian-
speaking minorities
Infant mortality rate: 6.2/1,000 (1983)
Life expectancy: men 70.1, women 78.1
Literacy: almost 100%
Labor force: 2.487 million (1985); 24.5%
mining and manufacturing; 27.9% services;
20.9% commerce; 11.5% agriculture,
forestry, and fishing; 7.3% construction;
7.6% transportation and communications;
6.2% unemployed (1985 average)
Organized labor: 80% of labor force','37ef3258e1d1534f1b0e65dd2bc1acee48c4b0087750ec146f2d658b3c727448','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04d2637907b4f69b2d83104155c57dbfb3cb9befe5293771614ebcbc89956846',1987,'FR','France','people-and-society',259,'Population: 55,596,030 (July 1987), aver-
age annual growth rate 0.38%
Nationality: noun—Frenchman(men);
adjective—French
Ethnic divisions: Celtic and Latin with
Teutonic, Slavic, North African, Indo-
chinese, and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim (North Afri-
can workers), 6% unaffiliated
Language: French (100% of population);
rapidly declining regional dialects (Proven-
eal, Breton, Germanic, Corsican, Catalan,
Basque, Flemish)
Infant mortality rate: 9/1,000 (1984)
Life expectancy: 75
Literacy: 99%
Labor force: 23.98 million; 60.8% services,
24.0% industry, 7.6% agriculture, 7.6%
other; 10.6% unemployed (1986)
Organized labor: about 20% of labor force','b14839eda96b64112c4fe0b518477782e7639845b1384ce679baab513d0bc1ac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a770d768d2e59b1b3e38fa0c660102bb747096d6712bedbb2eae83f5d4076c7f',1987,'GF','French Guiana','people-and-society',264,'Population: 92,038 (July 1987), average
annual growth rate 4.06%
Nationality: noun—French Guianese
(sing., pl.); adjective—French Guiana
83
Ethnic divisions: 66% black or mulatto;
12% Caucasian; 12% East Indian, Chinese,
Amerindian; 10% other
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 23,265; services, government,
and commerce 60.6%; industry 21.2%;
agriculture 18.2%; 10% unemployment
(1980)
Organized labor: 7% of labor force','de0dee4fa9367040f17aba31c2363766f99c4bf00c50eb3a0954ab21f3c4ac48','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ed45a9e8fae1d788a6b81af9e0efe505a18bab1ee7bc369a36f2a9c4c7b6e63',1987,'PF','French Polynesia','people-and-society',269,'Population: 185,683 (July 1987), average
annual growth rate 2.84%
Nationality: noun—French Polynesian(s);
adjective—French Polynesian
Ethnic divisions: 78% Polynesian, 12%
Chinese, 6% local French, 4% metropolitan
French
Religion: mainly Christian; 55% Protes-
tant, 32% Catholic','9f9c1754df3bc26e27edcdf653244b607fa0b24029e87459f4681dd6ad826871','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d80a8f72261b5b415fb3b149bb116f355cd35ae57fd073cbc15d3b1b591325be',1987,'GA','Gabon','people-and-society',273,'Population: 1,039,006 (July 1987), average
annual growth rate 1.31%
Nationality: noun—Gabonese (sing., pl.);
adjective—Gabonese
Ethnic divisions: about 40 Bantu tribes,
including 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000
expatriate Africans and Europeans, includ-
ing 35,000 French
85
Gabon (continued)
Religion: 55-75%°Christian, less than 1%
Muslim, remainder animist
Language: French (official), Fang, Myene,
Bateke, Bapounou/Eschira, Bandjabi
Infant mortality rate: 117/1,000 (1983)
Life expectancy: 50
Literacy: 65%
Labor force: 120,000 salaried (1983);
65.0% agriculture, 30.0% industry and
commerce, 2.5% services, 2.5% govern-
ment
Organized labor: there are 38,000 mem-
bers of the national trade union, the Ga-
bonese Trade Union Confederation
(COSYGA)','22624ee1f3693657109d334de6f7ee6d5465b93ab17de8a3360a75ab7022ff56','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c2eaf676d781c15a8088ef550ffcc1a32ed56bd36e39cbfdd705c8be561a1be',1987,'SN','Senegal','people-and-society',277,'Population: 760,362 (July 1987), average
annual growth rate 2.44%
Nationality: noun—-Gambian(s); adjec-
tive—Gambian
Ethnic divisions: 99% African (42% Man-
dinka, 18% Fula, 16% Wolof, 10% Jola, 9%
Serahuli, 4% other); 1% non-Gambian
Religion: 90% Muslim, 9% Christian, 1%
indigenous beliefs
Language: English (official); Mandinka,
Wolof, Fula, other indigenous vernaculars
Infant mortality rate: 174/1,000
Life expectancy: 42
Literacy: 12%
Labor force: 165,000 (1988 est.); 75.0%
agriculture; 18.9% industry, commerce,
and services; 6.1% government
Organized labor: 25-30% of wage labor
force
Population: 16,610,265, including East
Berlin (July 1987), average annual growth
rate -0.10%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: 99.7% German, 0.3%
Slavic and other
Religion: 47% Protestant, 7% Roman
Catholic, 46% unaffiliated or other; less
than 5% of Protestants and about 25% of
Roman Catholics active participants
Language: German, Sorbian
Infant mortality rate: 9.6/1,000 (1985)
Life expectancy: men 69.6, women 75.4
(1984)
Literacy: 99%
Labor force: 8.937 million; 37.9% indus-
try, 21.0% services, 10.2% commerce,
10.8% agriculture and forestry, 7.4%
transport and communications, 6.8%
construction, 3.1% handicrafts, 2.8% other
(1985)
Organized labor: 87.7% of total labor
force
Population: 60,989,419, including West
Berlin (July 1987), average annual growth
rate -0.03%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: primarily German;
Danish minority
Religion: 45% Roman Catholic, 44%
Protestant, 11% other
Language: German
Infant mortality rate: 11/1,000 (1983)
Life expectancy: men 67.2, women 73.4
Literacy: 99%
Labor force: 27.8 million, including
armed forces (est. avg. 1985); 41.6% indus-
try, 34.7% services and other, 18.2% trade
and transport, 5.4% agriculture; 9.0%
unemployment (1986)
Organized Jabor: 9.3 million total, 7.76
million in German Trade Union Federa-
tion (DGB); union membership constitutes
about 40% of union-eligible labor force,
34% of total labor force, and 35% of wage
and salary earners (1986)
Population: 7,064,025 (July 1987), average
annual growth rate 3.01%
Nationality: noun—Senegalese (sing. and
pl.); adjective—Senegalese
Ethnic divisions: 836% Wolof, 17% Fulani,
17% Serer, 9% Toucouleur, 9% Diola, 9%
Mandingo, 1% European and Lebanese
Religion: 92% Muslim, 6% indigenous
beliefs, 2% Christian (mostly Roman Cath-
olic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Infant mortality: 112/1,000
Life expectancy: 48
Literacy: 10%
Labor force: 2,509,000; 77% subsistence
agricultural workers; 175,000 wage earn-
ers—40% private sector, 60% government
and parapublic
Organized labor: majority of wage-labor
force represented by unions; however,
dues-paying membership very limited,
major confederation is National Confeder-
ation of Senegalese Labor (CNTS), an
affiliate of governing party','142f63ff26bc7fa7554507d7ec3ad343b0a7eebbad2a6b4ef7f3fc97b0f4aff6','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d41bb9428bcca3bbddd80b87ddc6aba79d394838431bee767915e554129e93f',1987,'GH','Ghana','people-and-society',284,'Population: 13,948,925 (July 1987), aver-
age annual growth rate 2.89%
Nationality: noun—Ghanaian(s); adjec-
tive—Ghanaian
Ghana (continued)
Ethnic divisions: 99.8% black African
(major tribes Akan, Ewe, Ga), 0.2% Euro-
pean and other
Religion: 88% indigenous beliefs, 30%
Muslim, 24% Christian, 8% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 18% Ewe, and 8% Ga-Adangbe
Infant mortality rate: 97/1,000 (1983)
Life expectancy: 49
Literacy: 80%
Labor force: 3.7 million; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales
and clerical; 7.7% services, transportation,
and communications; 3.7% professional;
400,000 unemployed
Organized labor: 467,000 (about 18% of
labor force)','296eef206ed31f54eaa4dc2c6833b1d58256f1946c6d9fab14e220247b30bd9f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f95f53d09d40cffd0b9727253d5505a644c788c04683bf1f7767e69bdeaba987',1987,'GI','Gibraltar','people-and-society',289,'Population: 29,048 (July 1987), average
annual growth rate 0.36%
Nationality: noun—Gibraltarian; adjec-
tive—Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8%
Church of England, 2.25% Jewish
Language: English and Spanish are pri-
mary languages; Italian, Portuguese, and
Russian also spoken; English used in the
schools and for official purposes
Literacy: about 99%
Labor force: about 14,800 (including
non-Gibraltar laborers)
Organized labor: over 6,000','a4fd8d632a08b02613d4443632a19a40666fcac5e3bd68a28ea5fa725ae356ee','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29863652a7be0363cef784aa7b36d0c530e2e45082ec733131422cabbb68f9e5',1987,'GR','Greece','people-and-society',294,'Population: 9,987,785 (July 1987), average
annual growth rate 0.28%
Nationality: noun—Greek(s); adjective—
Greek
Ethnic divisions: 97.7% Greek, 1.3%
Turkish; 1.0% Vlach, Slav, Albanian,
Pomach (note—the Greek Government
states there are no ethnic divisions in
Greece)
Religion: 98% Greek Orthodox, 1.8%
Muslim, 0.7% other
Language: Greek (official); English and
French widely understood
Infant mortality rate: 13.8/1,000 (1984)
Life expectancy: men 72, women 75
Literacy: 95%
Labor force: 3.86 million (1985); 48%
services, 27% agriculture, 20% manufactur-
ing and mining, 7% construction; 8.3%
unemployment
Organized labor: 10-15% of total labor
force, 20-25% of urban labor force','15795550c566e766b8b9d55f1fc0a4dd071b2c0e757fd7f28d946da5299101b7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2554ae8ebc9715d33e0e846dca8aa9bf3ab881853821f193a5a294056861a8f3',1987,'GL','Greenland','people-and-society',299,'Population: 54,205 (July 1987), average
annual growth rate 1.00%
Nationality: noun—Greenlander(s); adjec-
tive—Greenlandic
Ethnic divisions: 86% Greenlander (Eski-
mos and Greenland-born whites), 14%
Danish
Greenland (continued)
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Infant mortality rate: 37/1,000 (1976-80)
Life expectancy: men 59.7, women 67.3
Literacy: 99%
Labor force: 21,378; largely engaged in
fishing, hunting, and sheep breeding','ee46bbd28c46e1279345d768ec31f1e1b4747c24f0632ab2666c952158d4ed96','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b05eff6f5db918792776a165cd0435fcea626e4c9fac315b55a80f239eec82d7',1987,'GD','Grenada','people-and-society',304,'Population: 84,748 (July 1987), average
annual growth rate —0.49%
Nationality: noun—Grenadian(s); adjec-
tive—Grenadian
Ethnic divisions: mainly of black African
descent
Religion: largely Roman Catholic; Angli-
can; other Protestant sects
Language: English (official); some French
patois
Infant mortality rate: 16.7/1,000 (1985)
Life expectancy: 69
Literacy: 85%
Labor force: 36,000; 31% services, 24%
agriculture, 8% construction, 5% manufac-
turing, 31% other; 35-40% unemployment
(1985)
Organized labor: 80% of labor force','22215c8979f116d205ce75bf03a5bb29c5e95c3f2e0f70fa404a31f5ca61ea7d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfdcd3626147a57b45cdeba2afe2d459abb7ec0840dbb6b455d797fae7e1c371',1987,'GP','Guadeloupe','people-and-society',309,'Population: 336,354 (July 1987), average
innual growth rate 0.61%
Nationality: noun—Guadeloupian(s);
idjective—Guadeloupe
Ethnic divisions: 90% black or mulatto;
5% white; less than 5% East Indian, Leba-
1ese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Infant mortality rate: 18.6/1,000 (1983)
Life expectancy: 67
Literacy: over 70%
Labor force: 120,000; services, govern-
ment, and commerce 53.0%; industry
25.8%; agriculture 21.2%; significant un-
employment
Organized labor: 11% of labor force','ae080c239412e12ad5e766910effbee1938575c772b087b2651db2e805ec84b0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6411a57269db779ad658939f4f7d72cf0552048632daf540b03da336dd0f5ff8',1987,'GG','Guernsey','people-and-society',314,'Population: 52,947 (July 1987), average
annual growth rate -0.12%
Nationality: noun—Channel Islander(s);
adjective—Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic,
Presbyterian, Baptist, Congregational,
Methodist
Language: English, French; Norman-
French dialect spoken in country districts
Literacy: universal education','33f59f3758aa8d77c419f794e5f026f3e8c512760cce1e458ef17bbed8d63cde','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08380bc0b46e4c5d6386b586de0dee17ee4ea36b59716fea10bab26b014f92a4',1987,'GN','Guinea','people-and-society',318,'Population: 6,737,760 (July 1987), average
annual growth rate 2.50%
Nationality: noun—Guinean(s); adjec-
tive—Guinean
Ethnic divisions: Fulani, Malinke, Sousou
15 smaller tribes
’
Religion: 85% Muslim, 5% indigenous
beliefs, 10% Christian
Language: French (official); each tribe has
its own language
Infant mortality rate: 159/1,000
Life expectancy: 40
Literacy: 20% in French; 48% in local
languages
Labor force: 2.4 million (1983); 82.0%
agriculture, 11.0% industry and commerce,
5.4% services, 1.6% government
Organized labor: virtually 100% of wage
labor force loosely affiliated with the
National Confederation of Guinean
Workers
Population: 180,425,534; average annual
growth rate 2.05%
114
Nationality: noun—Indonesian(s); adjec-
tive—Indonesian
Ethnic divisions: majority of Malay stock
comprising 45.0% Javanese, 14.0% Sundan-
ese, 7.5% Madurese, 7.5% coastal Malays,
26.0% other
Religion: 88% Muslim, 6% Protestant, 3%
Roman Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official); English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese
Infant mortality rate: 95/1,000 (1983)
Life expectancy: 54
Literacy: 62%
Labor force: 67 million (1985 est.); 55%
agriculture, 10% manufacturing, 4% con-
struction, 3% transport and communica-
tions
Organized labor: 3 million members
(claimed); about 5% of labor force
Population: 50,407,763 (July 1987), aver-
age annual growth rate 3.32%; figures do
not take into account the impact of the
Iran-Iraq war
Nationality: noun—Iranian(s); adjective—
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish,
3% Arab and other Semitic
Religion: 93% Shi''a Muslim; 5% Sunni
Muslim; 2% Zoroastrian, Jewish, Christian,
and Baha’i
Language: Farsi, Turki, Kurdish, Arabic,
English, French
Infant mortality rate: 110/1,000 (1986
est.)
Life expectancy: 54
Literacy: 48%
Labor force: 12.0 million, (1979 est.); 33%
agriculture, 21% manufacturing; shortage
of skilled labor; unemployment may be as
high as 35%
Population: 114,025 (July 1987), average
annual growth rate 2.89%
Nationality: noun—Sao Tomean(s); adjec-
tive—Sao Tomean
Ethnic divisions: mestico, angolares (de-
scendents of Angolan slaves), forros (de-
scendents of freed slaves), servicais (con-
tract laborers from Angola, Mozambique,
and Cape Verde), tongas (children of
servicais born on the islands), and Europe-
ans (primarily Portuguese)
Religion: Roman Catholic, Evangelical
Protestant, Seventh-Day Adventist
Language: Portuguese (official)
Infant mortality rate: 63/1,000 (1983)
Literacy: est. 50%
Labor force: (1981) 21,096; most of popu-
lation engaged in subsistence agriculture
and fishing; some unemployment; labor
shortages on plantations and for skilled
workers','ff8889054c45e28555c14fb750dfceb595d67d690eaa0ef27378a01339d79031','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc1cd7430ab302a5d84bc84317d75da0943f871c70fb86cd6b7cfc02ed889baf',1987,'GW','Guinea-Bissau','people-and-society',321,'Population: 928,425 (July 1987), average
annual growth rate 2.36%
Nationality: noun—Guinea-Bissauan(s),
adjective—Guinea-Bissauan
Ethnic divisions: about 99% African (80%
Balanta, 20% Fula, 14% Manjaca, 13%
103
Mandinga, 7% Papel); less than 1% Euro-
pean and mulatto
Religion: 65% indigenous beliefs, 30%
Muslim, 5% Christian
Language: Portuguese (official); Criolo and
numerous African languages
Infant mortality rate: 250/1,000 (1982)
Life expectancy: 42
Literacy: 9%
Labor force: 90% agriculture; 5% industry,
services, and commerce; 5% government','35a1b5a8c886c9ea8e8fdcc7ab644e9031da4dc99f044aa7e180743afa1a03ef','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8ee0dd10bc8e467fbff0b791e1223eae08d57a8d4253830bb4109be8cd1095',1987,'GY','Guyana','people-and-society',326,'Population: 765,844 (July 1987), average
annual growth rate 0.03%
104
Nationality: noun—Guyanese (sing., pl.);
adjective—Guyanese
Ethnic divisions: 51% East Indian, 43%
black and mixed, 4% Amerindian, 2%
European and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Infant mortality rate: 41/1,000 (1985)
Life expectancy: 70
Literacy: 85%
Labor force: 268,000 (1985); 44.5% indus-
try and commerce, 33.8% agriculture,
21.7% services; public sector employment
amounts to 60-80% of the total labor force;
unemployment and underemployment
30% (1985 est.)
Organized labor: 34% of labor force','ef025b713e9710fff80af4e7bf43d2e008d11e7c73098fb9391919b6791166c7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea423068ba9a3e5aa11b83a33326d7d7ac515f4cb538d77fec4753259fba450',1987,'HT','Haiti','people-and-society',331,'Population: 6,187,115 (July 1987), average
annual growth rate 1.78%
Haiti (continued)
Nationality: noun—Haitian(s); adjective—
Haitian
Ethnic divisions: 95% black, 5% mulatto
and European
Religion: 75-80% Roman Catholic (of
which an overwhelming majority also
practice Voodoo), 10% Protestant, 10%
other
Language: French (official) spoken by only
10% of population; all speak Creole
Infant mortality rate: 107/1,000 (1983)
Life expectancy: 45
Literacy: 23%
Labor force: 2.3 million (1982); 66%
agriculture, 25% services, 9% industry;
significant unemployment; shortage of
skilled labor, unskilled labor abundant
Organized labor: less than 1% of labor
force
Population: 4,823,818 July 1987), average
annual growth rate 3.33%
Nationality: noun—Honduran(s); adjec-
tive—Honduran
Ethnic divisions: 90% mestizo (mixed
Indian and European), 7% Indian, 2%
black, 1% white
Religion: about 97% Roman Catholic;
small Protestant minority
Language: Spanish, Indian dialects
Infant mortality rate: 78/1,000 (1984)
Life expectancy: 58.7
Literacy: 56%
Labor force: 1.3 million (1985); 62%
agriculture, 20% services, 9% manufactur-
ing, 3% construction, 6% other; 25% unem-
ployed, 25% underemployed
Organized labor: 40% of urban labor
force, 20% of rural work force (1985)','ecb7e05fd195c448b7c569b3fa4b876d660c3e63855bb5a60a0b8cd22215d871','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db87f4fc8b28530df4587e6ad4fa860c410c20dde8ff9aa9cd18d6f1a8ab7b42',1987,'HK','Hong Kong','people-and-society',336,'Population: 5,608,610 (July 1987), average
annual growth rate 1.32%
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture of local
religions, 10% Christian
Language: Chinese (Cantonese), English
Infant mortality rate: 9.2/1,000 (1986)
Life expectancy: 75 (1986)
Literacy: 75%
Labor force: (June 1985) 2.64 million,
86.8% manufacturing; 22.1% commerce;
18.4% services; 7.6% construction; 7.6%
transport and communications; 6.8%
financing, insurance, and real estate; 1.2%
agriculture, fishing, mining, and quarrying;
unemployment (seasonally adjusted) 3.0%
Organized labor: 15.2% of 1984 labor
force','ad9c972100f7138c230b9680020457efc89cb50194f0aed9642f272a17632b90','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cd0b52a5a18647eac283af07df611813105236ffa54b0dd5220ba92777c7ee3',1987,'HU','Hungary','people-and-society',341,'Population: 10,609,447 (July 1987), aver-
age annual growth rate —0.19%
Nationality: noun—Hungarian(s); adjec-
tive—Hungarian
Ethnic divisions: 96.6% Hungarian, 1.6%
German, 1.1% Slovak, 0.3% Southern Slav,
0.2% Romanian
Religion: 67.5% Roman Catholic, 20.0%
Calvinist, 5.0% Lutheran, 7.5% atheist and
other
Language: 98.2% Hungarian, 1.8% other
Infant mortality rate: 19/1,000 (1983)
Life expectancy: men 65.6, women 73.7
(1984)
Literacy: 98.9%
Labor force: 4,913,000 (1985); 31.3%
industry; 21.1% agriculture; 7.2% construc-
tion; 40.4% services, trade, government,
other','24c62e0233b3834e2aa4adbb9d4a2ef4b750cd9d238039bbe844acce80386f0a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc58bb23f578e5cc8b9cfdb8be727f12e0c5eacefdb5e6d3384a42db5ada45e3',1987,'IS','Iceland','people-and-society',346,'Population: 244,676 (July 1987), average
annual growth rate 0.69%
Nationality: noun—Icelander(s); adiec-
tive—Icelandic
lll
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Infant mortality rate: 6.1/1,000 (1983)
Life expectancy: men 73.9, women 79.4
Literacy: 99.9%
Labor force: 122,800; 55.4% commerce,
finance, and services; 11.3% agriculture;
8.0% fish processing; 5.0% fishing; 20.3%
other manufacturing (1985); 0.9% unem-
ployment (1985 average)
Organized labor: 60% of labor force','4513745865cc6d96522d020a33856db75631adf494316fa7662eeef907a2a059','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d14e115b56dbba6c76f948f0518fbf87f7deb2f3a35fff484a25483dc207248',1987,'IQ','Iraq','people-and-society',353,'Population: 16,970,948 (July 1987), aver-
age annual growth rate 3.56%; figures do
not take into account the impact of the
Iran-lraq war
Nationality: noun—lIraaqi(s); adjective—
Iraqi
Ethnic divisions: 75% Arab, 15-20%
Kurdish, 5-10% Turkoman, Assyrian, and
other
Religion: 97% Muslim (60-65% Shi''a,
82-37% Sunni), 3% Christian or other
Language: Arabic (official), Kurdish (offi-
cial in Kurdish regions); Assyrian, Arme-
nian
Infant mortality rate: 76/1,000 (1980)
Life expectancy: 56.1
Literacy: about 50%
Labor force: 3.5 million (1980); 44%
agriculture, 26% industry, 31% services;
severe labor shortage due to war; expatri-
ate labor force about 1,000,000
Organized labor: 11% of labor force
Population: 1,863,615 (July 1987), average
annual growth rate 4.18%
Nationality: noun—Kuwaiti(s); adjective—
Kuwaiti
Ethnic divisions: 39% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9%
other
Religion: 85% Muslim (80% Shi''a, 45%
Sunni), 15% Christian, Hindu, Parsi, and
other
Language: Arabic (official); English widely
spoken
Infant mortality rate: 26.1/1,000 (1985)
Life expectancy: men 69, women 74
Literacy: about 71%
Labor force: 566,000 (1985); 45.0% ser-
vices, 20.0% construction, 12.0% trade,
8.6% manufacturing, 2.6% finance and real
estate, 1.9% agriculture, 1.7% power and
water, 1.4% mining and quarrying; 70% of
labor force is non-Kuwaiti
Organized labor: labor unions, first autho-
rized in 1964, formed in oil industry and
among government personnel
Population: 3,765,887 (July 1987), average
annual growth rate 2.17%
Nationality: noun—Lao (sing., Lao or
Laotian); adjective—Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phouth-
eung (Kha); 14% Tribal Tai; 13% Meo,
Yao, and other
Religion: 50% Buddhist, 50% animist and
other
Language: Lao (official), French, and
English
Infant mortality rate: 159/1,000 (1983)
Life expectancy: men 42, women 45
137
Literacy: 85%
Labor force: about I-1.5 million; 80-90%
agriculture
Organized labor: only labor organization
is subordinate to the Communist Party','520f091a8c7c7864bad625a68938e7c560022b7b46b39b19fcd420822bf06018','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eaa3794b43604749e745ae7f8980c448f2eefa24fa0f03d34aa76039e90a2ec',1987,'IE','Ireland','people-and-society',358,'Population: 3,534,553 July 1987), average
annual growth rate —0.08%
Nationality: noun—Irishman(men), Irish
(collective pl.); adiective—lIrish
Ethnic divisions: Celtic, with English
minority
Religion: 94% Roman Catholic, 4% Angli-
can, 2% other
Language: Irish (Gaelic) and English
(official); English is widely spoken
Infant mortality rate: 11/1,000 (1983)
Life expectancy: 73
Literacy: 99%
Labor force: about 1,299,400 (1985);
27.5% manufacturing and construction;
16.4% agriculture, forestry, fishing; 20.4%
services; 6.6% government; 6.2% transpor-
tation; other 22.9%; 17.4% unemployment
(1985 average)
Organized labor: 36% of labor force','cc12e4d92fe332d6a8baec07e3264a303ecc2bc6831542999b14bde2b85df2b1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fb53405735290db8a1c70f34245383b7ff4202600a3475b9c47285f95cc20bc',1987,'IL','Israel','people-and-society',363,'Population: 4,222,118, excluding West
Bank, Gaza Strip, and East Jerusalem (July
1987), average annual growth rate 1.83%
Nationality: noun—lIsraeli(s); adjective—
Israeli
Ethnic divisions: 83% Jewish, 17% non-
Jewish (mostly Arab)
Religion: 83% Judaism, 13.1% Islam, 2.3%
Christian, 1.6% Druze
Language: Hebrew (official); Arabic used
officially for Arab minority; English most
commonly used foreign language
Infant mortality rate: 14.1/1,000 (1983)
Life expectancy: 72.)
Literacy: 88% Jews, 70% Arabs
Labor force: 1,400,000 (1984 est.); 29.5%
public services; 22.8% industry, mining,
and manufacturing; 12.8% commerce;
9.5% finance and business; 6.8% transport,
storage, and communications; 6.5% con-
struction and public works; 5.5% agricul-
ture, forestry, and fishing; 5.8% personal
and other services; 1.0% electricity and
water (1983); unemployment about 6.7%
(1985)
Organized labor: 90% of labor force','c374b24861c74d4d4e2990c5684389d54d445d65404d31f03de5c1d15bd8e104','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d459440d70c2bf6737da7f04848e0e3ae93f02849b730050e08c75064efeb079',1987,'IT','Italy','people-and-society',368,'Population: 57,350,850 (July 1987), aver-
age annual growth rate 0.19%
122
Nationality: noun—Italian(s); adjective—
Italian
Ethnic divisions: primarily Italian but
population includes small clusters of
German-, French-, and Slovene-Italians in
the north and of Albanian-ltalians in the
south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are
predominantly German speaking; signifi-
cant French-speaking minority in Valle
d’Aosta region; Slovene-speaking minority
in the Trieste-Gorizia area
Infant mortality rate: 11.3/1,000 (1984)
Life expectancy: 73
Literacy: 93%
Labor force: 22.20 million (1985); 30.5%
industry, 10.5% agriculture, 48.6% services
(1984); 10.8% unemployment
Organized labor: 40-45% (est.) of labor
force
Population: 10,766,632 (July 1987), aver-
age annual growth rate 3.82%
Nationality: noun—Ivorian(s); adjective—
Ivorian
Ethnic divisions: over 60 ethnic groups;
most important are the Baoule 23%, Bete
18%, Senoufou 15%, Malinke 11%, and
Agni; about 2 million foreign Africans,
mostly Burkinabe; about 130,000 to
330,000 non-Africans (30,000 French and
100,000 to 300,000 Lebanese)
Religion: 63% indigenous, 25% Muslim,
12% Christian
Language: French (official), over 60 native
dialects; Dioula most widely spoken
Infant mortality rate: 127/1,000 (1980)
Literacy: 24%
Labor force: over 85% of population
engaged in agriculture, forestry, livestock
raising; about 11% of labor force are wage
earners, nearly half in agriculture and the
remainder in government, industry, com-
merce, and professions
Organized labor: 20% of wage labor force
Population: 23,430,830 (July 1987), aver-
age annual growth rate 0.66%
Nationality: noun—Yugoslav(s); adjec-
tive—Yugoslav
Ethnic divisions: 36.3% Serb, 19.7%
Croat, 8.9% Muslim, 7.8% Slovene, 7.7%
Albanian, 5.9% Macedonian, 5.4%
Yugoslav, 2.5% Montenegrin, 1.9% Hun-
garian, 3.9% other (1981 census)
Religion: 50% Eastern Orthodox, 30%
Roman Catholic, 10% Muslim, 1% Protes-
tant, 9% other
Language: Serbo-Croatian, Slovene, Mace-
donian (all official); Albanian, Hungarian
Infant mortality rate: 30/1,000 (1982)
Life expectancy: men 68, women 73
Literacy: 90.5%
Labor force: 10,1 million (1983); 25%
agriculture, 29% mining and manufactur-
ing; about 5% of labor force are guest
workers in Western Europe; unemploy-
ment about 10.0% of domestic labor force,
including private agriculture (August 1986)
Population: 32,342,947 (July 1987), aver-
age annual growth rate 2.88%
Nationality: noun—Zairian(s); adjective—
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu; four larg-
est tribes—Mongo, Luba, Kongo (all
Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the
population
Religion: 50% Roman Catholic, 20%
Protestant, 10% Kimbanguist, 10% Muslim,
10% other syncretic sects and traditional
beliefs
Language: French (official), English,
Lingala, Swahili, Kingwana, Kikongo,
Tshiluba
Infant mortality rate: 108/1,000 (1984)
Life expectancy: men 49, women 52
(1983)
Literacy: 55% males, 37% females
Labor force: about 15 million, but only
about 13% in wage structure','84535d4d0eccf9277c1cb9a87c9124d28f94e7dc1fd439bbe62ee1aa2d5faa51','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbcaa50582c63c7a3f4b9af80f3cde5fad0604862c7a71d051205a69a5d4132d',1987,'JM','Jamaica','people-and-society',373,'Population: 2,455,536 (July 1987), average
annual growth rate 1.17%
Nationality: noun—Jamaican(s); adjec-
tive—Jamaican
Ethnic divisions: 76.3% African, 15.1%
Afro-European, 3.4% East Indian and
Afro-East Indian, 3.2% white, 1.2% Chi-
nese and Afro-Chinese, 0.8% other
125
Religion: predominantly Protestant (in-
cluding Anglican and Baptist), some Ro-
man Catholic, some spiritualist cults
Language: English, Creole
Infant mortality rate: 16.8/1,000 (1984)
Life expectancy: 65
Literacy: 76%
Labor force: 728,700 (1984); 32% agricul-
ture, 28% industry and commerce, 27%
services, 183% government; shortage of
technical and managerial personnel; 30%
unemployment
Organized labor: about 33% of labor force
(1980)','d6a29042d3e3cb7d8ee7c692f660c94f646e9d1eff51d2f9fa9d5ec7c1f00af0','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a6b1c7bca54912b42d507d7dc2b84d162ff87cff8035bd44dc53800a458ebc8',1987,'JE','Jersey','people-and-society',378,'Population: 80,511 July 1987), average
annual growth rate 0.91%
Nationality: noun—Channel Islander(s);
adjective—Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic,
Baptist, Congregational New Church,
Methodist, Presbyterian
128
Language: English and French (official),
with the Norman-French dialect spoken in
country districts
Literacy: probably high
Population: 715,160 (July 1987), average
annual growth rate 2.75%
Nationality: noun—Swazi(s); adjective—
Swazi
Ethnic divisions: 96% African, 3% Euro-
pean, 1% mulatto
Religion: 57% Christian, 43% indigenous
beliefs
Language: English and siSwati (official);
government business conducted in English
Infant mortality rate: 156/1,000 (1982)
Life expectancy: men 46.8, women 50.0
Literacy: 65%
Labor force: 195,000; over 60,000 engaged
in subsistence agriculture; 55,000-60,000
wage earners, many only iutermittently,
with 86% agriculture and forestry, 20%
community and social services, 14% manu-
facturing, 9% construction, 21% other;
12,000 employed in South Africa (1982)
Organized labor: about 15% of wage
earners are unionized','0e882520920c4982acd71bb2f9027b8eceb346ee704706fb3f8575882c4c7cf7','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0863a6cde226946aebda83b9781084792f50596f03787ee6cb0633d7bbeec3e',1987,'JO','Jordan','people-and-society',383,'Population: 2,761,695 (July 1987), average
annual growth rate 3.65%
Nationality: noun—Jordanian(s), adjec-
tive—Jordanian
Ethnic divisions: 98% Arab, 1% Circas-
sian, 1% Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic (official); English widely
understood among upper and middle
classes
Infant mortality rate: 62/1,000 (1983)
Life expectancy: 61.7
Literacy: about 71%
Labor force: 580,000 (1983 est.); 20%
agriculture, 20% manufacturing and min-
ing
Organized labor: about 10% of labor force','4579cee3fef2b41689d154431934bb992ab147e672ca22522d30b3c803f25941','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb05c44ccee170e9b682631e9afb34597398b5fbf568326404c0446a802743a',1987,'KE','Kenya','people-and-society',388,'Population: 22,377,802 (July 1987), aver-
age annual growth rate 4.22%
Nationality: noun—Kenyan(s); adjective—
Kenyan
Ethnic divisions: 21% Kikuyu, 14%
Luhya, 13% Luo, 11% Kalenjin, 11%
Kamba, 6% Kisii, 6% Meru, 1% Asian,
European, and Arab
Religion: 38% Protestant, 28% Catholic,
26% indigenous beliefs, 6% Muslim
Language: English and Swahili (official);
numerous indigenous languages
Infant mortality rate: 59/1,000 (1985)
Life expectancy: men 53, women 58.1
Literacy: 47%
Labor force: 7.4 million; about 1.1 million
wage earners; 50% public sector, 18%
industry and commerce, 17% agriculture,
13% services
Organized labor: about 390,000
Population: 54,775 (July 1987), average
annual growth rate 2.96%
Ethnic divisions: mainly of black African
descent
Nationality: noun—Kittsian(s), Nevisian(s);
adjective—Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy: 80%
St. Christopher
and Nevis (continued)
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 8,524 (July 1987), average
annual growth rate 2.54%
Nationality: noun—St. Helenian(s); adjec-
tive—St. Helenian
Religion: Anglican majority; also Baptist,
Seventh-Day Adventist, and Roman
Catholic
Language: English
Infant mortality rate: 22.37/1,000 (1982)
Literacy: probably high
Labor force: large proportion employed
overseas
Organized labor: St. Helena General
Workers’ Union, 472 members; 10% pro-
fessional and technical, 9% mangement
and clerical, 5% sales, 9% farming and
fishing, 6% transport, 17% crafts, 10%
service, 1% security, and 33% other
Population: 152,305 (July 1987), average
annual growth rate 3.65%
Nationality: noun—St. Lucian(s); adjec-
tive—St. Lucian
Ethnic divisions: 90.3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cau-
casian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
St. Lucia (continued)
Language: English (official), French patois
Infant mortality rate: 27.4/1,000 (1984)
Life expectancy: men 68.3, women 72.4
Literacy: 78%
Labor force: 43,800 (1983 est.); 48.4%
agriculture, 38.9% services, 17.7% industry
and commerce; 30% unemployment (1984)
Organized labor: 20% of labor force
Population: 131,215 (July 1987), average
annual growth rate 4.04%
Nationality: noun—St. Vincentian(s) or
Vincentian(s); adjectives—St. Vincentian or
Vincentian
Ethnic divisions: mainly of black African
descent; remainder mixed, with some
white, East Indian, Carib Indian
Religion: Anglican, Methodist, Roman
Catholic, Seventh-Day Adventist
Language: English, some French patois
Literacy: 82%
Labor force: 67,000 (1984 est.); about 35%
unemployed (1986)
Organized labor: 10% of labor force','b2492bd612ceb460c417415284544cbb8e00b1cdfb6ff8e01ea5ef72e7fe4cff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71cc2637ea7f0b6ecd342d078ec14aeae4624760445bccaf0f30e049a0ba7f5a',1987,'KI','Kiribati','people-and-society',393,'Population: 66,441 (July 1987), average
annual growth rate 1.82%
Nationality: noun—Kiribatian(s), adjec-
tive—Kiribati
Ethnic divisions: Micronesian
Religion: 48% Roman Catholic, 45%
Protestant (Congregational), some Seventh-
Day Adventist and Baha’i
Language: English (official), Gilbertese
Literacy: 90%
Labor force: 7,870 economically active
(1985 est.)
Organized labor: Kiribati Trades Union
Congress—2,500 members
Population: 21,447,977 (July 1987), aver-
age annual growth rate 2.52%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism;
religious activities now almost nonexistent
Language: Korean
Infant mortality rate: 32/1,000 (1983)
Life expectancy: men 63, women 67
Literacy: 95% est.
Labor force: 6.1 million (1980); 48%
agricultural, 52% nonagricultural; shortage
of skilled and unskilled labor
Population: 41,986,669 (July 1987), aver-
age annual growth rate 1.53%
134
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: homogeneous; small
Chinese minority (about 20,000)
Religion: strong Confucian tradition;
vigorous Christian minority (28% of the
total population); Buddhism; pervasive folk
religion (Shamanism); Chondokyo (religion
of the heavenly way), eclectic religion with
nationalist overtones founded in 19th
century, claims about 1.5 million adher-
ents
Language: Korean; English widely taught
in high school
Infant mortality rate: 29/1,000 (1983)
Life expectancy: men 64, women 7]
Literacy: over 90%
Labor force: 15.9 million; 47% services
and other; 80% agriculture, fishing, for-
estry; 21% mining and manufacturing;
average unemployment 4.0% (1986 est.)
Organized labor: about 10% of nonagri-
cultural labor force in government-
sanctioned unions','862c9894612a5f5c7d43ffd8bb71983457083e31d1a2ba6696af2ade360879d3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d18c1a9dbca7ab390b4cc7711b181a3e948be1029d9660523c6c1798c68751b',1987,'LB','Lebanon','people-and-society',399,'Population: 3,320,522 (July 1987), average
annual growth rate 0.83%
Nationality: noun—Lebanese (sing., pl.);
adjective—Lebanese
Ethnic divisions: 98% Arab, 6% Arme-
nian, 1% other
Religion: 57% Muslim (Sunni and Shi‘a)
and Druze, 42% Christian (Maronite,
Greek Orthodox and Catholic, Roman
Catholic, Protestant), 1% other (official
estimates)
Language: Arabic (official); French is
widely spoken; Armenian, English
Infant mortality rate: 48/1,000 (1983)
Life expectancy: men 63, women 67
Literacy: 75%
Labor force: 650,000 (1985); 79% industry,
commerce, and services, 11% agriculture,
10% goverment; high unemployment
Organized labor: about 65,000','ef529682130415bd95eff2a297ed3ced8a2cc02dc16a6e1e1b9dc5004d049dd9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2044c01d8a4fe8e86039148d3f160a4a26df7a10fd7ef8d2ae319e6e3b24e37d',1987,'ZA','South Africa','people-and-society',403,'Population: 1,621,932 (July 1987), average
annual growth rate 2.69%
Nationality: noun—Mosotho (sing.), Baso-
tho (pl.); adjective—Basotho
Ethnic divisions: 99.7% Sotho; 1,600
Europeans, 800 Asians
Religion: 80% Christian, rest indigenous
beliefs
Language: Sesotho (southern Sotho) and
English (official); also Zulu and Xhosa
Infant mortality rate: 97.7/1,000 (1985)
Life expectancy: 54.2 (1985)
Literacy: 60%
Labor force: 426,000 economically active
(1976); 87.4% of resident population en-
gaged in subsistence agriculture;
150,000-250,000 spend from six months to
many years as wage earners in South
Africa
Organized labor: negligible','52f1d5d626322636bb3a0875dd2405a422b38f444db26755295af2a43bc73ecb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a3c39c9e7bc0e2a0fb59a79d8da8d41a5ba02e825669da018a338a812446ec5',1987,'LR','Liberia','people-and-society',409,'Population: 2,384,189 (July 1987), average
annual growth rate 3.27%
Nationality: noun—Liberian(s); adjec-
tive—Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Kru,
Grebo, Mano, Krahn, Gola, Gbandi, Loma,
Kissi, Vai, and Bella; 5% descendants of
repatriated slaves known as Americo-
Liberians
Religion: 70% traditional, 20% Muslim,
10% Christian
Language: English (official); more than 20
local languages of the Niger-Congo lan-
guage group; English used by about 20%
Infant mortality rate: 153/1,000 (1984)
Life expectancy: 54
Literacy: 24%
Labor force: 510,000, of which 220,000
are in monetary economy; non-African
foreigners hold about 95% of the top-level
management and engineering jobs; 70.5%
agriculture, 10.8% services, 4.5% industry
and commerce, 14.2% other
Organized labor: 2% of labor force','c6314d1fc63f8e8e591a50ef014751f33c45f44a65d85142e8262a761a30a129','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7bb6dddf1ac3cd4fe96c9a755a6f1f5aeb4a45c67cd7eb1076b8916f24da586',1987,'LY','Libya','people-and-society',414,'Population: 3,306,825 (July 1987), average
annual growth rate 3.39%
143
Nationality: noun—Libyan(s); adjective—
Libyan
Ethnic divisions: 97% Berber and Arab;
some Greeks, Maltese, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic; Italian and English
widely understood in major cities
Infant mortality rate: 84/1,000 (1985)
Life expectancy: men 56, women 59
Literacy: 50-60%
Labor force: 1 million, of which about
280,000 are resident foreigners; 31% indus-
try, 27% services, 24% government, 18%
agriculture','f1dafaf008bf99a6c615040ff4107503f52d2a5825661aa796475d654612c228','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d075681f04404d6296d7495fe065bbcd11d10019d3d241be88042034bf4f89e',1987,'LI','Liechtenstein','people-and-society',419,'Population: 27,074 (July 1987), average
annual growth rate 0.59%
Nationality: noun—Liechtensteiner(s);
adjective—Liechtenstein
Ethnic divisions: 95% Alemannic, 5%
Italian and other
Religion: 82.7% Roman Catholic, 7.1%
Protestant, 10.2% other
Language: German (official), Alemannic
dialect
Infant mortality rate: 6.3/1,000 (1985)
Life expectancy: men 65, women 74
Literacy: 100%
Labor force: 12,258; 5,078 foreign workers
(mostly from Switzerland and Austria);
54.4% industry, trade, and building; 41.6%
services; 4.0% agriculture, fishing, forestry,
and horticulture; no unemployment','b41b15023ea452020a8c38c784b3a5ef8e230b3724a5d9de0179102db8d01849','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ff2f23af2f261079868761c4ad476100808ed88517eff8e77260d3758fb217',1987,'LU','Luxembourg','people-and-society',424,'Population: 366,127 (July 1987), average
annual growth rate 0.03%
Nationality: noun—Luxembourger(s);
adjective—Luxembourg
Ethnic divisions: Celtic base, with French
and German blend; also guest and worker
residents from Portugal, Italy, and Euro-
pean countries
Religion: 97% Roman Catholic, 3% Protes-
tant and Jewish
Language: Luxembourgish, German,
French; many also speak English
Infant mortality rate: 12/1,000 (1984)
Life expectancy: men 70, women 76.7
Literacy: 100%
Labor force: (1984) 161,000; one-third of
labor force is foreign, comprising mostly
workers from Portugal, Italy, France,
Belgium, and FRG; 48.9% services, 24.7%
industry, 13.2% government, 8.8% con-
struction, 4.4% agriculture; unemployment
1.5% (1985 average)
Population: 437,822 (July 1987), average
annual growth rate 5.53%
Nationality: noun—Macanese (sing. and
pl.); adjective—Macau
Ethnic divisions: 98% Chinese, 2% Portu-
guese
Religion: mainly Buddhist; 17,000 Catho-
lics, of whom about half are Chinese
147
Language: 98% Chinese, 2% Portuguese
Infant mortality: 12/1,000 (1985)
Literacy: almost 100% among Portuguese
and Macanese; no data on Chinese popula-
tion','e8310de3870d32e1bca24d577056b870411a9ad34191b4a5a3ad7f08e1beb8a5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c5731170c64c330c20bceee74221e36f9cfbb07ab5df727342cc961c1ef1565',1987,'MG','Madagascar','people-and-society',429,'Population: 10,730,754 (July 1987), aver-
age annual growth rate 3.11%
148
Nationality: noun—Malagasy (sing. and
pl.); adjective—Malagasy
Ethnic divisions: basic split between
highlanders of predominantly Malayo-
Indonesian origin (Merina 1,643,000 and
related Betsileo 760,000) on the one hand
and coastal tribes—collectively termed the
Cétiers, with mixed black,
Malayo-Indonesian, and Arab ancestry
(Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 375,000) on
the other; there are also 11,000 European
French, 5,000 Indians of French national-
ity, and 5,000 Creoles
Religion: 52% indigenous beliefs; about
41% Christian, 7% Muslim
Language: French and Malagasy (official)
Infant mortality rate: 177/1,000 (1984)
Life expectancy: 46
Literacy: 58%
Labor force: about 4.9 million (1985), of
which 90% are nonsalaried family workers
engaged in subsistence agriculture; of
175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15%
industry, 14% commerce, 11% construc-
tion, 9% services, 6% transportation, 2%
miscellaneous
Organized labor: 4% of labor force','36c57729dc733287585c2b092eb388c70a8d300adc1cc82ac290d30ee3ced990','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d212b20bbdb988c0fa6bf77135fb47da2af7ab6a9dad038f210cf0db64aa5d11',1987,'MW','Malawi','people-and-society',434,'Population: 7,437,911 (July 1987), average
annual growth rate 3.15%
Nationality: noun—Malawian(s); adjec-
tive—Malawian
Ethnic divisions: Chewa, Nyanja, Tum-
buko, Yao, Lomwe, Sena, Tonga, Ngoni,
Asian, European
Religion: 55% Protestant, 20% Roman
Catholic, 20% Muslim; traditional indige-
nous beliefs are also practiced by some
members of these groups
Language: English and Chichewa (official);
Tombuka is second African language
Infant mortality rate: 14/1,000 (1983)
Life expectancy: 47
Literacy: 25%
Labor force: 344,052 wage earners em-
ployed in Malawi (1982); 52% agriculture,
16% personal services, 9% manufacturing,
7% construction, 6% commerce, 4% miscel-
laneous services, 6% other permanently
employed
Organized labor: small minority of wage
earners are unionized','1c56c44427c923b284afac31ae8eea79d2bca34b9de76bc3475f62b12b7cf47f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fec5a73c5779931dbc10e9d44b312ce887fce7c26dcf054319d3e47bc964aaaf',1987,'MY','Malaysia','people-and-society',439,'Population: 16,068,516 (July 1987), aver-
age annual growth rate 2.08%, includes
Peninsular Malaysia—138,280,754, average
annual growth rate 1.98%; Sabah—
1,281,994, average annual growth rate
8.28%; and Sarawak—1,505,768, average
annual growth rate 1.88%
Nationality: noun—Malaysian(s); adjec-
tive—Malaysian
Ethnic divisions: 59% Malay and other
indigenous, 32% Chinese, 9% Indian
Religion: Peninsular Malaysia—Malays
nearly all Muslim, Chinese predominantly
Buddhists, Indians predominantly Hindu;
Sabah—38% Muslim, 17% Christian, 45%
other; Sarawak—85% tribal religion, 24%
Buddhist and Confucianist, 20% Muslim,
16% Christian, 5% other
Language: Peninsular Malaysia—Malay
(official); English, Chinese dialects, Tamil;
Sabah—English, Malay, numerous tribal
dialects, Mandarin and Hakka dialects
predominate among Chinese; Sarawak—
English, Malay, Mandarin, numerous tribal
languages
Infant mortality rate: 25/1,000 (1985)
Life expectancy: 67.7 male, 72.7 female
Literacy: 65.0% overall, age 20 and up;
Peninsular Malaysia—80%; Sabah—60%;
Sarawak—60%
Labor force: 5.95 million (1985); 34.5%
agriculture; trade, hotels, and restaurants;
15.6% manufacturing, 14.9% government;
6.6% construction, 5% finance; 4.9% trans-
port and communications; 1.6% mining;
1.2% utilities
Organized labor: 620,000, about 10% of
total labor force; unemployment about
7.6% of total labor force, but higher in
urban areas (1985)','e6d1ebee9c2ae4d81a4fea2abb5fbfd2de1734e1bc73b08a2291fcf68186af5e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14666e23f4b65fa901fd811158da22781bd3d952517091a513fa66a948275ca8',1987,'MV','Maldives','people-and-society',443,'Population: 195,837 (July 1987), average
annual growth rate 3.65%
Nationality: noun—Maldivian(s); adijec-
tive—Maldivian
153
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala;
script derived from Arabic); English spo-
ken by most government officials
Infant mortality rate: 88/1,000 (1984)
Life expectancy: 46.5
Literacy: 36%
Labor force: about 66,000; fishing industry
employs 80% of labor force','77cc3c2ec98b1207407ae1f05bbab458e0e3e45fd1db2130628426240720c33d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf0a4b7fe6ea58f3137df9ecdd25d588860ef3e7b48951e8927826e11309d1e6',1987,'ML','Mali','people-and-society',448,'Population: 8,422,810 (July 1987), average
annual growth rate 2.80%
Nationality: noun—Malian(s); adjective—
Malian
Ethnic divisions: 50% Mande (Bambara,
Malinke, Sarakole), 17% Peul, 12% Voltaic,
6% Songhai, 5% Tuareg and Moor
Religion: 90% Muslim, 9% indigenous
beliefs, 1% Christian
154
Language: French (official); Bambara
spoken by about 80% of the population
Infant mortality rate: 180/1,000
Life expectancy: 42
Literacy: 10%
Labor force: 3.1 million (1981); 80%
agriculture, 19% services, 1% industry and
commerce
Organized labor: National Union of
Malian Workers (UNTM) is umbrella
organization over 13 national unions','0afee7858724d5a7f61909ccbe4ea9112e48876d3b453a0ea2012e06a6118dac','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('601b8ae84f6cb808d7e456885a05533188f4e0dfbb0123ca0d5d90915278f6a6',1987,'MT','Malta','people-and-society',453,'Population: 361,704 (July 1987), average
annual growth rate 0.66%
Nationality: noun—Maltese (sing. and pl.);
adjective—Maltese
Ethnic divisions: mixture of Arab, Sicil-
ian, Norman, Spanish, Italian, English
Religion: 98% Roman Catholic
Malta (continued)
Language: Maltese and English (official)
Infant mortality rate: 11.2/1,000 (1984)
Life expectancy: 73
Literacy: 83%
Labor force: 121,686 (1984); 30% services
(except government), 24% manufacturing,
21% government (except job corps), 8%
construction, 5% utilities and drydocks, 4%
agriculture; 8.7% registered unemployed
(August 1986)
Organized labor: about 40% of labor force
Population: 64,934 (July 1987), average
annual growth rate 0.01%
Nationality: noun—Manxman, adjective—
Manx
Ethnic divisions: native Manx of Norse-
Celtic descent; British
Religion: Anglican, Roman Catholic,
Methodist, Baptist, Presbyterian, Society of
Friends
Language: English, Manx Gaelic
Literacy: compulsory education between
ages of 5 and 15
Labor force: 25,864; manufacturing 3,467,
construction 2,921, transport and commu-
nications 2,300, retail 2,687, professional
and scientific services 3,737 (1981); unem-
ployment 8% (1984)
Organized labor: 22 labor unions pat-
terned along British lines','a40a9fb85574f3ff6e4ad7e9882771867a303c968a04f87fd510f6773da29ed9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6a1b5fccf0e862583343ce1c204633473e1583232f305a8be8a96190d1b790e',1987,'MQ','Martinique','people-and-society',458,'Population: 344,922 (July 1987), average
annual growth rate 1.84%
Nationality: noun—Martiniquais (sing. and
-pl.); adjective—Martiniquais
Ethnic divisions: 90% African and
African-Caucasian-Indian mixture, 5%
Caucasian, less than 5% East Indian,
Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Infant mortality rate: 12.6/1,000 (1981)
Life expectancy: 68
Literacy: over 70%
Labor force: 100,000; 31.7% service indus-
try, 29.4% construction and public works,
13.1% agriculture, 7.3% industry, 2.2%
fisheries, 16.3% other; 14% unemployed
Organized labor: 11% of labor force','8ba6120feac28093e409f6195d55f5a4b9a4d1a4abfbbda77a1b0ffd461ca032','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a03eeb8e479849eb792baa07435bfaeb5ce68fc85ed6beb4d3671f869c66fbfc',1987,'MR','Mauritania','people-and-society',463,'Population: 1,863,208 (July 1987), average
annual growth rate 2.91%
Nationality: noun—Mauritanian(s); adjec-
tive—Mauritanian
159
Ethnic divisions: 40% mixed Moor/black;
80% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasaniya Arabic (national),
French (official); Toucouleur, Fula,
Sarakole, Wolof
Infant mortality rate: 136/1,000 (1983)
Life expectancy: men 44, women 47
Literacy: 17%
Labor force: total labor force 465,000
(1981 est.); about 45,000 wage earners
(1980 IMF); 47% agriculture, 29% services,
14% industry and commerce, 10% govern-
ment; considerable unemployment
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union','f085da3b2e319ace205e3461a69b7078a40c9e23da7864bc37d7160174c2ad48','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('082ab7b1d0fd5618bbacbdbcb675eb987e36414db99ee2127c68d9f234e91027',1987,'MU','Mauritius','people-and-society',468,'Population: 1,079,627 (July 1987), average
annual growth rate 1.87%
Nationality: noun—Mautritian(s); adjec-
tive—Mauritian
Ethnic divisions: 68% Indo-Mauritian,
27% Creole, 3% Sino-Mauritian, 2%
Franco- Mauritian
Religion: 51% Hindu, 30% Christian
(mostly Roman Catholic with a few Angli-
cans), 17% Muslim
Language: English (official), Creole,
French, Hindi, Urdu, Hakka, Bojpoori
Infant mortality rate: 28/1,000 (1985)
Life expectancy: 67
Literacy: 79%
Labor force: 335,000; 29% government
services, 27% agriculture and fishing, 22%
manufacturing, 22% other; about 15-20%
unemployed
Organized labor: about 35% of labor
force, forming over 270 unions','04bdc410a42923092148c4a1efd22443552372905572f0e1a5c4a8ecdf3efc24','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebd1259c7bef959337a6d498b65347bed59cedec46304a1e54a933d0bc897c29',1987,'KM','Comoros','people-and-society',472,'Population: 64,481 (July 1987), average
annual growth rate 3.71%
Nationality: noun—Mahorais (sing., pl.);
adjective—Mahoran
Religion: 99% Muslim; remainder Chris-
tian, mostly Roman Catholic
Language: Mahorian (a Swahili dialect),
French
Literacy: probably high','5a6802498b9247e66c641369aeef5ba78bfc3a456687b9ae6adbd0337b7b35d4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bb02db26c432a9ea4884330bc27307e448566498fcd95bd562aea3fe4f36431',1987,'MX','Mexico','people-and-society',477,'Population: 81,860,566 (July 1987), aver-
age annual growth rate 2.09%
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo (Indian-
Spanish), 30% Amerindian or predomi-
nantly Amerindian, 9% white or predomi-
nantly white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Infant mortality rate: 51.0/1,000 (1984)
Life expectancy: 65.4
Literacy: 88.1%
Labor force: 26,320,000 (1985); 31.4%
services; 26% agriculture, forestry, hunting,
fishing; 18.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8% transporta-
tion; 1.8% mining and quarrying; 0.3%
electricity; 10% unemployed, 40% under-
employed
Organized labor: 35% of total labor force
Population: 4,178,545 (July 1987), average
annual growth rate 0.30%
Nationality: noun—Norwegian(s); adjec-
tive—Norwegian
Ethnic divisions; Germanic (Nordic,
Alpine, Baltic) and racial-cultural minority
of 20,000 Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small
Lapp- and Finnish-speaking minorities
Infant mortality rate: 7.9/1,000 (1983)
Life expectancy: men 72.7, women 79.5
Literacy: 100%
Labor force: 2.064 million (1985); 30.9%
services; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation;
7.6% construction; 7.2% agriculture, for-
estry, fishing; 5.7% banking and financial
services (1983); 2.8% unemployed (1985)
Organized labor: 66% of labor force
(1985)
Population: 1,226,923 (July 1987), average
annual growth rate 3.10%
Nationality: noun—Omani(s); adjective—
Omani
Ethnic divisions: almost entirely Arab,
with small Baluchi, Zanzibari, and Indian
groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Shi''a Muslim, some Hindu
Language: Arabic (official); English,
Baluchi, Urdu, Indian dialects
Infant mortality rate: 121/1,000 (1983)
Life expectancy: men 51, women 54
Litéracy: 20%
Labor force: 430,000; 58% are
non-Omani; est. 60% agriculture
Population: 37,726,699 (July 1987), aver-
age annual growth rate 0.67%
Nationality: noun—Pole(s); adjective—
Polish
199
Ethnic divisions: 98.7% Polish, 0.6%
Ukrainian, 0.5% Byelorussian, less than
0.05% Jewish
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Infant mortality rate: 19.3/1,000 (1984)
Life expectancy: 71.6
Literacy: 98%
Labor force: 17.54 million; 44% industry
and commerce, 30% agriculture, 11%
services, 8% government (1985)
Organized labor: new government trade
unions formed following dissolution of
Solidarity and all government unions in
October 1982
Population: 63,585,121 (July 1987), aver-
age annual growth rate 2.49%
Nationality: noun— Vietnamese (sing. and
pl.); adjective— Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist,
Roman Catholic, indigenous beliefs, Is-
lamic, Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Infant mortality rate: 53/1,000 (1983)
Life expectancy: men 62, women 66
Literacy: 78%
Labor force: 31.20 million, not including','0b3199ff704d1a8252a2fb5da46ebd8217038f4ffb3e40f1d2d212ea004f5e06','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f7cb38ed9ed76befdcc44cf5629d2a23862b99f6dcf463e7f202a2bbc65c4f',1987,'MC','Monaco','people-and-society',481,'Population: 28,641 (July 1987), average
annual growth rate 0.99%
Nationality: noun—Monacan(s) or Mone-
gasque(s); adjective—Monacan or Mone-
gasque
Ethnic divisions: 47% French, 16% Mone-
gasque, 16% Italian, 21% other
Religion: 95% Roman Catholicism
Language: French (official), English,
Italian, Monegarque
Literacy: 99%','96681aeb83d5ffaeee479fb5d73d20dad7eef392e81f46ae6c6780dab3920467','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('013b3885aafdd63d110515c3b809805f2ddc49b16fae3fa2b7c58644fcc2a308',1987,'MN','Mongolia','people-and-society',486,'Population: 2,011,066 (July 1987), average
annual growth rate 2.79%
Nationality: noun—Mongolian(s); adjec-
tive—Mongolian
Ethnic divisions: 90% Mongol, 4%
Kazakh, 2% Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Bud-
dhist, about 4% Muslim, limited religious
activity because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor languages in-
clude Turkic, Russian, and Chinese
Life expectancy: 63
Mongolia (continued)
Literacy: about 80%; 100% claimed in
1985
Labor force: primarily agricultural; over
half the adult population is in the labor
force, including a large percentage of
women; shortage of skilled labor','ec61cacd6336703dedf521148a02e5affc2cda62db451f56246bcf5f78ddd2dc','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d863042c353889223304abfeae8a3227b34472afc4dca050e202be13642c3ab2',1987,'MS','Montserrat','people-and-society',491,'Population: 12,076 (July 1987), average
annual growth rate 0.07%
Nationality: noun—Montserratian(s);
adjective—Montserratian
Ethnic divisions: mostly black with a few
Europeans
Religion: Anglican, Methodist, Roman
Catholic, Pentecostal, Seventh-Day Adven-
tist, other Christian denominations
Language: English
Literacy: 77%
Infant mortality rate: 124/1,000 (1983)
Labor force: 5,100 (1983 est.); 40.5%
community, social, and personal services,
13.5% construction, 12.3% trade, restau-
rants, and hotels, 10.5% manufacturing,
8.8% agriculture, forestry, and fishing,
14.4% other; 7.0% unemployment (1986)
Organized labor: 3 trade unions with
1,498 members; about 30% of work force
(1984)','ccccbbb9bf3cc09f4e622ccc06343d1f5c68496d6545209f8ad0d92341c533b8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4681c0c8e26b7e4ed6f4da802d757e7c9fa5a9470290e6e740ae0e5d7dee4c7',1987,'MA','Morocco','people-and-society',496,'Population: 23,361,495 (July 1987), aver-
age annual growth rate 2.49%
Nationality: noun—Moroccan(s); adjec-
tive—Moroccan
Ethnic divisions: 99.1% Arab-Berber,
0.7% non-Moroccan, 0.2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of business,
government, diplomacy, and postprimary
education
Infant mortality rate: 117/1,000 (1978)
Life expectancy: 54
Literacy: 28%
Labor force: 7.5 million (1985); 50%
agriculture, 26% services, 15% industry,
9% other; at least 20% of urban labor
unemployed
Organized labor: about 5% of the labor
force, mainly in the Union of Moroccan
Workers (UMT) and the Democratic
Confederation of Labor (CDT)','3cdcc5f966058246d13dc1d1ba27abfb55793df840cfc17d8f45300d02714a75','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c021e9f2658e7a5646a80617753a2e5fd55f1b96344dbd34ebe4f0c3e84f84',1987,'MZ','Mozambique','people-and-society',501,'Population: 14,535,805 (July 1987), aver-
age annual growth rate 2.64%
Nationality: noun—Mozambican(s); adjec-
tive—Mozambican
Ethnic divisions: majority from indige-
nous tribal groups; about 10,000 Europe-
ans, 35,000 Euro-Africans, 15,000 Indians
Religion: 60% indigenous beliefs, 30%
Christian, 10% Muslim
Language: Portuguese (official); many
indigenous dialects
Mozambique (continued)
Infant mortality rate: 109/1,000 (1983)
Life expectancy: men 44, women 47
Literacy: 14%
Labor force: 95% engaged in agriculture','95396ee04bdc7cd459a3471410ec338ea38e216174dcd384df8dc7d1db406026','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d817fcdf44ab588a94f60adf32acc90a99c0295d3a13aaf9819b0f38c460139b',1987,'NA','Namibia','people-and-society',506,'Population: 1,273,263 (July 1987), average
annual growth rate 3.89%
Nationality: noun—Namibian(s); adjec-
tive—Namibian
Ethnic divisions: 85.6% black, 7.5% white,
6.9% mixed; about half the blacks belong
to Ovambo tribe
Religion: whites predominantly Christian,
nonwhites either Christian or indigenous
beliefs
Language: Afrikaans principal language of
about 60% of white population, German of
33%, and English of 7% (all official); sev-
eral indigenous languages
Literacy: 100% whites, 16% nonwhites
Labor force: about 500,000 (1981); 60%
agriculture, 19% industry and commerce,
8% services, 7% government, 6% mining;
15-17% unemployment
Organized labor: 7 trade unions, whose
membership is almost exclusively white
and mulatto, except new mineworkers
union which has sizable black membership
Population: 34,313,356 (July 1987), aver-
age annua] growth rate 2.27%, includes the
four nominally independent homelands
that are not recognized by the US (Bophu-
thatswana 1,750,165, average annual
growth rate 3.85%; Ciskei 982,982, average
annual growth rate 2.62%; Transkei
2,832,345, average annual growth rate
2.70%; Venda 434,395, average annual
growth rate 2.72%)
Nationality: noun—South A frican(s);
adjective—South African
Ethnic divisions: 69.9% black, 17.8%
white, 9.4% colored, 2.9% Indian
Religion: most whites and coloreds and
roughly 60% of blacks are Christian;
roughly 60% of Indians are Hindu, 20%
Muslim
Language: Afrikaans, English (official);
many vernacular languages, including
Zulu, Xhosa, North and South Sotho,
Tswana
Infant mortality rate: whites 14.9/1,000
(1982), coloreds 80.6/1,000 (1982), blacks
80.6/1,000 (1982), Asians 25.3/1,000 (1982)
Life expectancy: whites 70 years, Asians
66 years, coloreds 59 years, blacks 55 years
Literacy: almost all white population
literate; government estimates 50% of
blacks literate
Labor force: 1) million economically
active (1985); 34% services, 30% agricul-
ture, 29% industry and commerce, 7%
mining
Organized labor: about 17% of total labor
force is unionized (mostly white workers);
African unions represent less than 15% of
black labor force
Population: 284,008,160 (July 1987),
average annual growth rate 0.90%
Nationality: noun—Soviet(s); adjective—
Soviet
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 32% among over 100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9%
Muslim; 3% Jewish, Protestant, Georgian
Orthodox, or Roman Catholic; population
is 70% atheist
Language: Russian (official); more than
200 languages and dialects (at least 18 with
more than | million speakers); 75% Slavic
group, 8% other Indo-European, 12%
Altaic, 3% Uralian, 2% Caucasian
Infant mortality rate: 27.9/1,000 (1982)
Life expectancy: men 64, women 74
Literacy: 99%
Labor force: civilian 148 million (midyear
1984), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed
not reported; shortage of skilled labor
reported','0b490477b98b3566320d81f9bd78eefdda60ac823d5bd5f782d8e5741f65dc67','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdc2bed671ebce23656525296222a2d780da2d7212efcfd0812412b24a491f42',1987,'NR','Nauru','people-and-society',511,'Population: 8,748 (July 1987), average
annual growth rate 1.80%
Nationality: noun—Nauruan(s); adjec-
tive—Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% European
Religion: Christian (two-thirds Protestant,
one-third Catholic)
172
Language: Nauruan, a distinct Pacific
Island language (official); English widely
understood and spoken
Literacy: 99%','755ee89f5cbd00a9003613a60e6124b7bbab01ad3a6e3604ef60246cbc32cd1a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e983080ae83f7d5fb0236d637f01d63975712ae660a433ba02616858f1ba2d8e',1987,'NP','Nepal','people-and-society',516,'Population: 17,814,294 (July 1987), aver-
age annual growth rate 2.43%
Nationality: noun—Nepalese (sing. and
pl.); adiective—Nepalese
Ethnic divisions: Newars, Indians, Tibet-
ans, Gurungs, Magars, Tamangs, Bhotias,
Rais, Limbus, Sherpas, as well as many
smaller groups
173
Religion: only official Hindu kingdom in
world, although no sharp distinction be-
tween many Hindu (about 88%) and Bud-
dhist groups; small groups of Muslims and
Christians
Language: Nepali (official); 20 mutually
unintelligible languages divided into nu-
merous dialects
Infant mortality rate: 143/1,000 (1983)
Life expectancy: men 47, women 45
Literacy: 20%
Labor force: 4.1 million; 93% agriculture,
5% services, 2% industry; great lack of
skilled labor','c22240971a7c0275b6ecf48a1907cdf881170085cb04a264a5bfdacab54ce205','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e8ac6797ad99fa4005fcc6fe3474119dba4ad5d369b1b895d43dec0775f9b39',1987,'NL','Netherlands','people-and-society',521,'Population: 14,641,554 (July 1987), aver-
age annual growth rate 0.51%
Nationality: noun—Netherlander(s); adjec-
tive—Netherlands
Ethnic divisions: 99% Dutch, 1% Indo-
nesian and other
Religion: 40% Roman Catholic, 31%
Protestant, 24% unaffiliated, 5% none
Language: Dutch
Infant mortality rate: 8/1,000 (1984)
Life expectancy: 76
Literacy: 99%
Labor force: 5.3 million (1984); 50.1%
services, 27.8% manufacturing and con-
struction, 16.1% government, 6.0% agricul-
ture; unemployment rate 14.4% (1985
average)
Organized labor: 29% of labor force
Population: 182,218 (July 1987), average
annual growth rate 0.28%
Nationality: noun—Netherlands Antil-
lean(s); adjective—Netherlands Antillean
Ethnic divisions: 85% mixed African;
remainder Carib Indian, European, Latin,
and Oriental
Religion: predominantly Roman Catholic;
Protestant, Jewish, Seventh-Day Adventist
Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates; English widely spoken;
Spanish
Literacy: 95%
176
Labor force: 89,000 (1983); 65% govern-
ment, 28% industry and commerce, 1.5%
agriculture; unemployment about 16%
(1984 est.)
Organized labor: 60-70% of labor force','030d662cde9c455e91aac5cf717a7abfd456452e1731e773de6cdefeb9c35b8c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd983967e5100235d2131fbc567e711e485728e5a21e1ccb443c00212378832',1987,'NC','New Caledonia','people-and-society',526,'Population: 149,795 (July 1987), average
annual growth rate 0.66%
Nationality; noun—New Caledonian(s);
adjective—New Caledonian
Ethnic divisions: Melanesian 42.5%,
European 37.1%, Wallisian 8.4%, Polynes-
ian 3.8%, Indonesian 3.6%, Vietnamese
1.6%, other 3.0%
New Caledonia (continued)
Religion: over 60% Roman Catholic, 30%
Protestant, 10% other
Language: French; Melanesian-Polynesian
dialects
Labor force: 50,469 (1980 est.); Javanese
and Tonkinese laborers were imported for
plantations and mines in pre-World War
II period; immigrant labor now coming
from Wallis and Futuna, Vanuatu, and
French Polynesia; est. 8% unemployment','8c2ace4a81d73aa380e36aa8b8042518f179168cdbb6b35f778f46760cbecde5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d59915694d48aad3b25b6a221b7049ee499196e57d6437462d140864771144',1987,'NZ','New Zealand','people-and-society',531,'Population: 3,307,239 (July 1987), average
annual growth rate 0.88%
Nationality: noun—New Zealander(s);
adjective—New Zealand
Ethnic divisions: 88% European, 8.9%
Maori, 2.9% Pacific Islander, 0.2% other
Religion: 81% Christian, 18% none or
unspecified, 1% Hindu, Confucian, and
other
Language: English (official), Maori
Infant mortality rate: 12.5/1,000 (1983)
Life expectancy: men 70.5, women 77.0
Literacy: 98%
Labor force: 1,416,900 (August 1986);
66.6% services, 21.0% manufacturing,
11.8% primary production; 5.0% unem-
ployment rate (1986)
Organized labor: 660,000 members; 41%
of labor force (December 1985)','d9740c7cc915435663a5b5be6a5de0a7b0985a17fea3b2972da3c3510e89c848','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2574678bd9c43b5fe89913f76ccf8f94503cf7c5b084f661e3c2add941eebd64',1987,'NI','Nicaragua','people-and-society',538,'Population: 3,319,059 (July 1987), average
annual growth rate 2.50%
Nationality: noun—Nicaraguan(s); adjec-
tive—Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English- and
Indian-speaking minorities on Atlantic
coast
Infant mortality rate: 84/1,000 (1983)
Life expectancy: men 56, women 60
Literacy: 66%
Labor force: 1,086,000 (1986); 45% ser-
vice, 42% agriculture, 13% industry; 25%
unemployment
Organized labor: 35% of Nicaragua''s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist ori-
ented—the government-sponsored Sandin-
ista Workers’ Central (CST), 115,000
members, including state and municipal
employees; the Association of Campesino
Workers (ATC), 180,000 members; the
General Confederation of Independent
Workers (CGI-1), about 15,000 members;
the Workers Front, about 100 members;
and the Central for Labor Action and
Unity (CAUS), about 3,000 members; the
other two unions are the Nicaraguan
Workers’ Central (CTN), 25,000 members,
and the Confederation of Labor Unifica-
tion (CUS), 50,000 members','de7cb4828e3ad146cc5fdb1ea06304764d77ca41024b9a959810f1c43c3563ba','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63bd15f68a8352657492446f90f2cb6dd548417070b81959bbe308c4c9a7ca61',1987,'NE','Niger','people-and-society',543,'Population: 6,988,540 (July 1987), average
annual growth rate 3.16%
Nationality: noun—Nigerien(s) adjective—
Nigerien
Ethnic divisions: 56% Hausa; 22%
Dierma; 8.5% Fula; 8% Tuareg; 4.3% Beri
Beri (Kanouri); 1.2% Arab, Toubou, and
Gourmantche; about 4,000 French expatri-
ates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official); Hausa,
Djerma
Infant mortality rate: 186/1,000 (1984)
Life expectancy: 45
Literacy: 10%
Labor force: 2.5 million (1982) wage
earners; 90% agriculture, 6% industry and
commerce, 4% government
Organized labor: negligible','b4965f2ad18dcc6f730443e8052ecb471a6650304af115365ae143019b12b664','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610b4329b8e401916c0989d933848278de9c0bf93ef17757809bbf6ec07a39e8',1987,'NU','Niue','people-and-society',551,'Population: 2,602 (July 1987), average
annual growth rate -3.21%
Nationality: noun—Niuean(s); adjective—
Niuean
Ethnic divisions: Polynesian, with some
200 Europeans, Samoans, and Tongans
Religion: 75% Ekalesia Nieue (Niuean
Church)—a Christian Protestant church
closely related to the London Missionary
Society, 10% Morman, 5% Roman Catho-
lic, Jehovah’s Witnesses, Seventh-Day
Adventist
Language: Polynesian tongue closely
related to Tongan and Samoan; English
Literacy: education compulsory between 5
and 14 years of age
Labor force: about 1,000 (1981); most
Niueans work on family plantations; paid
work exists only in government service,
small industry, and the Niue Development
Board','45b6e3df7233656697602840af09e9ff57dadee0213a8aca6ed01890d4fc295c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73506c926b99971c55de6b6424412fd3bc3e9e5bfd9849acad3ececadfa1fc14',1987,'NF','Norfolk Island','people-and-society',556,'Population: 2,537 (July 1987), average
annual growth rate 2.56%
Nationality: noun—Norfolk Islander(s);
adjective—Norfolk Islander
Ethnic divisions: descendants of the
Bounty mutiny; more recently, Australian
and New Zealand settlers
Religion: Church of England, Roman
Catholic Church, Uniting Church in Aus-
tralia, and Seventh-Day Adventists
Norfolk Island (continued)
Language: English (official); Norfolk—a
mixture of 18th Century English and
ancient Tahitian
Literacy: probably high','67bc04e1b20278a6135732997fccdfa53aa3cb1c8d9d5630345e112450162d9e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be5a985fb96a36dd1efe650df31d5d23c46c7d145ddcbf58905913a80bd5179d',1987,'OM','Oman','people-and-society',564,'Population: 104,600,799 (July 1987),
average annual growth rate 2.74%
Nationality: noun—Pakistani(s); adjec-
tive—Pakistani
Ethnic divisions: Punjabi, Sindhi, Pushtun
(Pathan), Baluch
Religion: 97% Muslim, 3% Christian,
Hindu, and other
Language: Urdu and English (official);
total spoken languages—64% Punjabi, 12%
Sindhi, 8% Pushtu, 7% Urdu, 9% Baluchi
and other; English is lingua franca
Infant mortality rate: 119/1,000 (1983)
Life expectancy: men 51, women 49
Literacy: 24%
Labor force: 28.6 million (1985 est.);
extensive export of labor; 53% agriculture,
19% industry, 28% services
Organized labor: about 10% of industrial
work force','68d3811e838e76ad3812ca1500a10fc2568b23b9fa02304f720fd492e58e8648','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3d6cb8fd501a800a9c2e8c0113a2382c3b6ecb0df5fa8d873d46e7ee42fabf',1987,'PA','Panama','people-and-society',569,'Population: 2,274,833 (July 1987), average
annual growth rate 2.14%
Nationality: noun—Panamanian(s); adjec-
tive—Panamanian
191
Ethnic divisions: 70% mestizo, 14% West
Indian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official); 14% speak
English as native tongue; many Pana-
manians bilingual
Infant mortality rate: 20.1/1,000 (1984)
Life expectancy: 71
Literacy: 90%
Labor force: 680,471 (1984 est.); 45%
commerce, finance, and services; 29%
agriculture, hunting, and fishing; 10%
manufacturing and mining; 5% construc-
tion; 5% transportation and communica-
tions; 4% Canal Zone; 1.2% utilities; 20%
unemployed (January 1985 est.); shortage
of skilled labor, but an oversupply of
unskilled labor
Organized labor: 17% of labor force
(1986)','af322d0c74b083ecbd0bf7c79bb548ae803f2efc749fe0e69c7bbcc0a3a1b587','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b61bd61c01c2e5cd7d1762c2547295e459e0d10c582b9a3d97c5a136bd1f5a7',1987,'PG','Papua New Guinea','people-and-society',574,'Population: 3,563,743 July 1987), average
annual growth rate 2.41%
Nationality: noun—Papua New Guin-
ean(s); adjective—Papua New Guinean
Ethnic divisions: predominantly Mela-
nesian and Papuan; some Negrito, Micro-
nesian, and Polynesian
Religion: over half of population nomi-
nally Christian (490,000 Catholic, 320,000
Lutheran, other Protestant sects); remain-
der indigenous beliefs
Language: 715 indigenous languages;
English spoken by 1-2%, pidgin English
widespread, Motu spoken in Papua region
Infant mortality rate: 102/1,000 (1985)
Life expectancy: 50
Literacy: 32%
Labor force: 1.66 million (1980); 732,806
(1980) in salaried employment; 54% agri-
culture, 25% government, 9% industry and
commerce, 8% services','71d37444611ca9a6ffaea89afca2a3243918572bef6fe7d1286d24b0fec5c5ff','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e984a97c8049dd105b6fb587ccc6bfbf7c2438fbeac4bdec729ff602a9e9a4c5',1987,'PY','Paraguay','people-and-society',579,'Population: 4,251,924 (July 1987), average
annual growth rate 3.15%
Nationality: noun—Paraguayan(s); adiec-
tive—Paraguayan
Ethnic divisions: 95% mestizo (Spanish
and Indian), 5% white and Indian
194
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Infant mortality rate: 64/1,000 (1981)
Life expectancy: 68
Literacy: 81%
Labor force: 1.1 million (1983 est.); 44%
agriculture; 34% industry and commerce,
18% services, 4% government; unemploy-
ment rate 25% (1986 est.)
Organized labor: about 5% of labor force','8b43ce9146216e9230890063e693bb97c6edf608cd026beb77a8904967269cfa','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef8b7a21b1b58148d84a69b2323dff59f4cc96ec94a67813c51567c947400f5',1987,'PE','Peru','people-and-society',584,'Population: 20,739,218 (July 1987), aver-
age annual growth rate 2.54%
Nationality: noun—Peruvian(s); adjec-
tive—Peruvian
Peru (continued)
Ethnic divisions: 45% Indian; 37% mestizo
(white-Indian); 15% white; 8% black,
Japanese, Chinese, and other
Religion: predominantly Roman Catholic
Language: Spanish and Quechua (official),
Aymara
Infant mortality rate: 80/1,000 (1985)
Life expectancy: 60.2
Literacy: est. 80%
Labor force: 5.6 million; 44% government
and other services, 38% agriculture, 18%
industry; unemployment 10.9%; underem-
ployment 57.4% (1984)
Organized labor: about 40% of salaried
workers (1983 est.)','0069920ac0ce95a841fe4e028c4451a50e733d83fe5e5b18507bacc4c7a5cd22','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b0ff845c4e64245e715afcb417b9ce9239af0625afe4be384eaf255a0ed94e2',1987,'PH','Philippines','people-and-society',589,'Population: 61,524,761 (July 1987), aver-
age annual growth rate 2.70%
Nationality: noun—Filipino(s); adjective—
Philippine
Ethnic divisions: 91.5% Christian Malay,
4% Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Pilipino (based on Tagalog) and
English (both official)
Infant mortality rate: 59/1,000 (1982)
Life expectancy: 64
Literacy: about 88%
Labor force: 21,643 million (1985); 47.0%
agriculture, 20% industry and commerce,
13.5% services, 10.0% government, 9.5%
other; 6.1% official unemployment rate
(1985); much underemployment
Organized labor: 2,064 registered unions;
total membership 4.8 million (includes 2.7
million members of the National Congress
of Farmers Organizations)
Population: 62 (July 1987), average annual
growth rate 3.28%
Nationality: noun—Pitcairn Islander(s);
adjective—Pitcairn Islander
Ethnic divisions: descendants of Bounty
mutineers
Religion: 100% Seventh Day-Adventists
Language: English (official); also a
Tahitian/English dialect
Literacy: probably high
198
Labor force: no business community in
the usual sense; some public works; subsis-
tence farming and fishing','401b80df21054589ef7e3f249128fd74961935971be61d6ec07151c7328b61e2','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8681f6a005d40ab34c083d2848d6d612a843d52ed38bc9ff2d04fa58739a35b0',1987,'PT','Portugal','people-and-society',596,'Population: 10,314,727 July 1987), aver-
age annual growth rate 0.74%
Nationality: noun—Portuguese (sing. and
pl.); adjective—Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent
who immigrated to mainland during
decolonization number less than 100,000
Religion: 97% Roman Catholic, 1% Protes-
tant sects, 2% other
Language: Portuguese
Infant mortality rate: 19/1,000 (1983)
Life expectancy: 73
Literacy: 83%
Labor force: 4.59 million; 45% services,
84% industry, 21% agriculture; unemploy-
ment, 11.1% (1986 est.)
Organized labor: about 55% of Portuguese
labor is organized; the Communist-
dominated General Confederation of
Portuguese Workers—Intersindical
(CGTP-IN) represents more than half of
theunionized labor force; its main compe-
tition, the General Workers Union (UGT),
is organized by the Socialists and Social
Democrats and represents less than half of
unionized labor','e635af47504c784a06ba259290d34ce23668d4f116c03ef576b9a195bc02c227','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('615dd4f4eb59ca0e7ef08052f19e7dccdee42f12d65277645f2d6d4cc1de54bf',1987,'QA','Qatar','people-and-society',601,'Population: 315,741 (July 1987), average
annual growth rate 3.96%
Nationality: noun—Qatari(s); adjective—
Qatari
Ethnic divisions: 40% Arab, 18% Paki-
stani, 18% Indian, 10% Iranian
Religion: 95% Muslim
Language: Arabic (official); English is
commonly used as second language
Life expectancy: 72
Literacy: 40%
Labor force: 104,000 (1983); 85% non-
Qatari in private sector
Population: 549,697 (July 1987), average
annual growth rate 1.84%
Nationality: noun—Reunionese (sing. and
pl.); adjective—Reunionese
Ethnic divisions: most of the population is
of thoroughly intermixed ancestry of
French, African, Malagasy, Chinese, Paki-
stani, and Indian origin
Reunion (continued)
Religion: 94% Roman Catholic
Language: French (official); Creole widely
used
Literacy: over 80% among younger gener-
ation
Labor force: primarily agricultural work-
ers; high seasonal unemployment','03883ecc0757359cb3b20cf4865b26032d15fa3d7137a70a60e170713de674a3','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dcf114d20235f4bbcb92316ecd6b49eb0d741706babf71f01bc5d14678c87e8',1987,'RO','Romania','people-and-society',606,'Population: 22,936,503 (July 1987), aver-
age annual growth rate 0.44%
Nationality: noun—Romanian(s); adjec-
tive—Romanian
Ethnic divisions: 89.1% Romanian; 7.8%
Hungarian; 1.5% German; 1.6% Ukrainian,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6%
Roman Catholic; 4% Calvinist, Lutheran,
Jewish, Baptist
Language: Romanian, Hungarian, German
Infant mortality rate: 25.6/1,000 (1985)
Life expectancy: men 67.0, women 72.6
Literacy: 98%
Labor force: 10.6 million; 37.1% industry,
28.9% agriculture, 34.0% other nonagri-
cultural (1985)','2ec084d568bf05e4d44a4f61695d1ec76d3f0f78ac8f6dfd404c07000d38eb13','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab67b03362f12cf4fe593017aa2fc1148dda959fc909764dc0a45066d83af4e',1987,'RW','Rwanda','people-and-society',610,'Population: 6,811,336 (July 1987), average
annual growth rate 3.53%
Nationality: noun—Rwandan(s); adjec-
tive—Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi,
1% Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim; indigenous beliefs
Language: Kinyarwanda, French (official);
Kiswahili used in commercial centers
206
Infant mortality rate: 102/1,000 (1985)
Life expectancy: 48
Literacy: 37%
Labor force: 3.6 million (1985); 91%
agriculture, 2% industry and commerce,
7% government and services','7f4dc96ad64626cba618048415b513826f0468efb21964943a62382088cf4c6c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a1077aba8731eb621b338ffdb9bbd77943151ab94a289e0080ac1ee7616159',1987,'SM','San Marino','people-and-society',615,'Population: 22,791 (July 1987), average
annual growth rate 0.86%
Nationality: noun—Sanmarinese (sing. and
pl.); adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Infant mortality rate: 9.6/1,000 (1983)
Literacy: 97%
Labor force: about 4,300
Organized labor: Democratic Federation
of Sanmarinese Workers (affiliated with
ICFTU) has about 1,800 members;
Communist-dominated General Federation
of Labor, 1,400 members
San Marino (continued)','7b3519ea0f19cc6b396cca04458213adf942070c10358d0ec766cf703042febb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e59d592918ec72926f18054f56023702536a789c502a9eba8656b0abc78e93f6',1987,'SA','Saudi Arabia','people-and-society',622,'Population: 14,904,794 (July 1987), aver-
age annual growth rate 4.95%
Nationality: noun—Saudi(s); adjective—
Saudi or Saudi Arabian
Ethnic divisions: 90% Arab, 10% Afro-
Asian
Religion: 100% Muslim
Language: Arabic
Infant mortality rate: 118/1,000 (1983)
Life expectancy: 54
Literacy: 52%
Labor force: about one-third (one-half
foreign) of population; 45% commerce,
services, government, and other; 30%
agriculture; 15% construction; 5% industry;
5% oil and mining
Population: 2,351,131 (July 1987); average
annual growth rate 3.07%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: almost all Arabs; a few
Indians, Somalis, and Europeans
Religion: Sunni Muslim, some Christian
and Hindu
Language: Arabic
Infant mortality rate: 114/1,000 (1980)
Life expectancy: men 40.6, women 42.4
Literacy: 25%','d15af0d187ee6caa69b4d7140c8244bc6f8980ed278e09918c65bc091efd794b','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c599e97eef2941e2feeb8281e97e8cd6ebf297888a3fc454be28016d7309e1',1987,'SC','Seychelles','people-and-society',626,'Population: 67,552 (July 1987), average
annual growth rate 1.52%
Nationality: noun—Seychellois (sing. and
pl.); adjective—Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Angli-
can, 2% other
Language: English and French (official);
Creole
Infant mortality rate: 26/1,000 (1983)
Life expectancy: 66
Literacy: 60%
Labor force: 1984 (est.) formal employ-
ment (all sectors)—38.4 government, 30.7%
parastatal, 30.8% private; formal employ-
ment (by sector)—49.0% industry and
commerce, 39.0% services, 11.5% agricul-
ture, forestry, and fishing
Organized labor: 3 major trade unions','866e13215f9d1ea3b2e3e4934e4be1307279ea6d00cb50bf1032f2254beb255d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dfbef08b8fd341ecb9ba5248d2a7bd9d5aca1da7df4ad63f3b024872c56a610',1987,'SL','Sierra Leone','people-and-society',631,'Population: 3,754,088 (July 1987), average
annual growth rate 2.16%
Nationality: noun—Sierra Leonean(s);
adjective—Sierra Leonean
Ethnic divisions: over 99% native African
(80% Temne, 30% Mende, 2% Creole), rest
European and Asian; 18 tribes
Religion: 830% Muslim, 30% indigenous
beliefs, 10% Christian, 30% other or none
Language: English (official); regular use
limited to literate minority; principal
vernaculars are Mende in south and
Temne in north; Krio is the language of
the resettled exslave population of the
Freetown area and is lingua franca
Life expectancy: 46
Literacy: about 15%
Labor force: about 1.5 million; most of
population engages in subsistence agricul-
ture; only small minority, some 65,000,
earn wages
Organized labor: 35% of wage earners','a89441b485d4ec8abed799827ebc587151db122c3aa38af440527bc05385734c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98b270d3c9c71354d7f1c11ef3ebada678096224b0e87a1e3624fe5a5c468932',1987,'SG','Singapore','people-and-society',636,'Population: 2,616,236 (July 1987), average
annual growth rate 1.18%
Nationality: noun—Singaporean(s), adjec-
tive—Singapore
Ethnic divisions: 76.4% Chinese, 14.9%
Malay, 6.4% Indian, 2.3% other
Religion: majority of Chinese are Bud-
dhists or atheists; Malays nearly all Mus-
lim; minorities include Christians, Hindus,
Sikhs, Taoists, Confucianists
219
Language: Chinese, Malay, Tamil, and
English (official); Malay (national)
Infant mortality rate; 8.3/1,000 (1985)
Life expectancy: men 69, women 74
Literacy: 84.2%
Labor force: 1,154,260 (June 1985); 30.2%
services, 25.5% manufacturing, 23.5%
trade, 10.1% transport and communica-
tion, 8.9% construction, 0.7% agriculture
and fishing; 6.5% unemployment (June
1986)
Organized labor: 202,302, 17.5% of labor
force (1985)','ea5a3ef099533e7d58ce9b5c379405e6aa24cd280271a5a4efa560208e257482','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('362af8e724a1cee3270935121ef971cb0e745357b41b229a469ad878e1aa7ca9',1987,'SB','Solomon Islands','people-and-society',641,'Population: 301,180 (July 1987), average
annual growth rate 3.62%
Nationality: noun—Solomon Islander(s);
adjective—Solomon Islander
Ethnic divisions: 93.0% Melanesian, 4.0%
Polynesian, 1.5% Micronesian, 0.8% Euro-
pean, 0.3% Chinese, 0.4% other
Religion: almost all at least nominally
Christian; Anglican, Seventh-Day Advent-
ist, and Roman Catholic churches domi-
nant
Language: 120 indigenous languages;
Melanesian pidgin in much of the country
is lingua franca; English spoken by 1-2%
of population
Infant mortality rate: 46/1,000 (1980)
Life expectancy; 54
Literacy: 60%
Labor force: 28,448 economically active
(1984); 32.4% agriculture, forestry, and
fishing; 7.0% construction, manufacturing,
and mining; 4.7% commerce, transport,
and finance
Organized labor: most of the cash econ-
omy workers have trade union representa-
tion','efe82a7d63d5f17f582559270dc6842f1bcbfeeb50fadafdb445bd31cfa703d4','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea860b1534ec20e18bf076bf59476c6363509e03a53b19c629059b4ac57a8bd',1987,'SO','Somalia','people-and-society',646,'Population: 7,741,859 (July 1987), average
annual growth rate 3.01%
Nationality: noun—Somali(s); adjective—
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official); Arabic, Italian,
English
Infant mortality rate: 150/1,000 (1984)
Life expectancy: 43.9
Literacy: 60%
Labor force: about 2.2 million; very few
are skilled laborers; 70% pastoral nomad,
30% agriculturists, government employees,
traders, fishermen, handicraftsmen, other
Organized labor: General Federation of
Somali Trade Unions, a government-
controlled organization, established in 1977','e3c98f0ec729d1bcba197d21f508cba47ec9fbb605698eb7e8c008f7a38b3fc1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e2a5ffb42efe660533fc2e33396b65b8d6c74aaa6d6f79140bd709329a2c4f',1987,'ES','Spain','people-and-society',651,'Population: 39,000,804 (July 1987), aver-
age annual growth rate 0.54%
Nationality: noun—Spaniard(s); adjec-
tive—Spanish
226
Ethnic divisions: composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other
sects
Language: Castilian Spanish; second
languages include 17% Catalan, 7% Galic-
ian, and 2% Basque
Infant mortality rate: 9.6/1,000 (1983)
Life expectancy: men 73, women 78
Literacy: 97%
Labor force: 13.7 million (1986 est.);
52.0% services, 24.4% industry, 16.1%
agriculture, 7.5% construction; unemploy-
ment, 21.5% (June 1986)
Organized labor: no more than 25% of
labor force (1984)','856f817a41e2c8fea6538115b12fa3d8ba740ffd406e3f2c2b9e8de015f1ecb9','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bda1494b911b4b54dc90683e1aae62c2cbe47ce8127ffd73a5dcda6024259323',1987,'LK','Sri Lanka','people-and-society',654,'Population: 16,406,576 (July 1987), aver-
age annual growth rate 1.37%
Nationality: noun—Sri Lankan(s); adjec-
tive—Sri Lankan
228
Ethnic divisions: 74% Sinhalese; 18%
Tamil; 7% Moor; 1% Burgher, Malay, and
Veddha
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim
Language: Sinhala (official); Sinhala and
Tamil listed as national languages; Sinhala
spoken by about 74% of population, Tamil
spoken by about 18%; English commonly
used in government and spoken by about
10% of the population
Infant mortality rate: 37/1,000 (1983)
Life expectancy: 68
Literacy: 87%
Labor force: 6.6 million (1985 est.); 45.9%
agriculture, 13.3% mining and manufac-
turing, 12.4% trade and transport, 26.3%
services and other; extensive underemploy-
ment; 19% unemployment (1985 est.)
Organized labor: about 33% of labor
force, over 50% of which employed on tea,
rubber, and coconut estates','f2244dd080a3f5f5700ae1c33f082628a527225975844f155d65005819f217c1','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b91f5b5ea09a11c918144342c195980212d99643da0c543d37a493712e88cb0',1987,'SD','Sudan','people-and-society',659,'Population: 23,524,622 (July 1987), aver-
age annual growth rate 1.90%
Nationality: noun—Sudanese (sing. and
pl.); adjective—Sudanese
Ethnic divisions: 52% black, 39% Arab,
6% Beja, 2% foreigners, 1% other
Religion: 70% Sunni Muslim in north, 20%
indigenous beliefs, 5% Christian (mostly in
south)
Language: Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, and Sudanic languages, English;
program of Arabization in process
Infant mortality rate: 118.9/1,000 (1985)
Life expectancy: 47
Literacy: 20%
Labor force: 6.086 million (1982); roughly
78.4% agriculture, 9.8% industry and
commerce, 6.0% government; labor short-
ages for almost all categories of employ-
ment coexist with urban unemployment','9e0c1eacfe033db9892a89ef3555b2164dd394c0fcd93e52a81b22fa3ff4f123','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('910e637534ecc5752f4a3fab6ef69d866c454229189907a159fda651f4b63b0c',1987,'GE','Georgia','people-and-society',665,'Population: 388,636 (July 1987), average
annual growth rate 1.61%
Nationality: noun—Surinamer(s), adjec-
tive—Surinamese
231
Ethnic divisions: 37.0% Hindustani (East
Indian), 31.0% Creole (black and mixed),
15.38% Javanese, 10.38% Bush black, 2.6%
Amerindian, 1.7% Chinese, 1.0% Europe-
ans, 1.1% other
Religion: 27.4% Hindu, 19.6% Muslim,
22.8% Roman Catholic, 25.2% Protestant
(predominantly Moravian), about 5%
indigenous beliefs
Language: Dutch (official); English widely
spoken; Sranan Tongo (Surinamese, some-
times called Taki-Taki) is native language
of Creoles and much of the younger popu-
lation and is lingua franca among others;
also Hindi Suriname Hindustani (a variant
of Bhoqpuri), and Javanese
Infant mortality rate: 23/1,000 (1984)
Life expectancy: men 64.8, women 69.8
Literacy: 65%
Labor force: 104,000 (1984); unemploy-
ment 25% (1985); about 10.6% of work
force engaged in agriculture, animal hus-
bandry, and fishing
Organized labor: 49,000 members of labor
force organized','fb8dcf08a0673788734778250965cebbad50f85821ffd1759c88c45d5449e0ce','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1ab4045ff53af1c2ed9aac0531b12bd438463feebaba4258ad59c0db06155b',1987,'SE','Sweden','people-and-society',671,'Population: 8,383,026 (July 1987), average
annual growth rate 0.15%
Nationality: noun—Swede(s); adjective—
Swedish
Ethnic divisions: homogeneous white
population; small Lappish minority; est.
12% foreign born or first generation immi-
grants (Finns, Yugoslavs, Danes, Norwe-
gians, Greeks)
Religion: 93.5% Evangelical Lutheran,
1.0% Roman Catholic, 5.5% other
Language: Swedish, small Lapp- and
Finnish-speaking minorities; immigrants
speak native languages
Infant mortality rate: 7/1,000 (1983)
Life expectancy: men 75, women 8]
Literacy: 99%
Labor force: 4.41 million (1984); 32.8%
private services; 30.0% government ser-
vices; 22.0% mining and manufacturing;
5.9% construction; 5.0% agriculture, for-
estry, and fishing; 0.9% electricity, gas, and
waterworks; 2.8% unemployed (1985
average)
Organized labor: 90% of labor force (1985
est.)','b2505d37a7dbe96680b6c6e1232de3f9e33969addbcbb189c0863dccd932971d','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0cf706e450c0dfac2742852a218eff20640d077bb37b03b7f938be9b99eb2ab',1987,'CH','Switzerland','people-and-society',676,'Population: 6,572,739 (July 1987), average
annual growth rate 0.32%
Nationality: noun—Swiss (sing. & pl.);
adjective—Swiss
Ethnic divisions: total popnlation—65%
German, 18% French, 10% Italian, 1%
Romansch, 5% other; Swiss nationals—74%
German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 49% Catholic, 48% Protestant,
0.3% Jewish
’
%
Switzerland (continued)
Language: total population—65% German,
18% French, 12% Italian, 1% Romansch,
4% other; Swiss nationals—74% German,
20% French, 4% Italian, 1% Romansch, 1%
other
Infant mortality rate: 9/1,000 (1985)
Life expectancy: men 70.3, women 76.2
Literacy: 99%
Labor force: 3.05 million, about 706,000
foreign workers, mostly Italian; 42% ser-
vices, 39% industry and crafts, 11% gov-
ernment, 7% agriculture and forestry, 1%
other; 0.9% unemployed (1985)
Organized labor: 20% of labor force
Population: 11,147,763 (July 1987), aver-
age annual growth rate 3.69%
Nationality: noun—Syrian(s); adjective—
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish,
Armenian, Aramaic, Circassian; French
and English widely understood
Infant mortality rate: 57/1,000 (1984)
Life expectancy: men 64.9, women 67.6
Literacy: 47%
Labor force: 2.4 million; 836% miscella-
neous services, 32% agriculture, 32%
industry (including construction); majority
unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 23,502,472 (July 1987), aver-
age annual growth rate 3.28%
Nationality: noun—Tanzanian(s); adjec-
tive—Tanzanian
Ethnic divisions: mainland—99% native
African consisting of well over 100 tribes;
1% Asian, European, and Arab; Zanzibar—
almost all Arab
Religion: mainland—33% Christian, 833%
Muslim, 33% indigenous beliefs; Zanzi-
bar—almost all Muslim
Language: Swahili and English (official);
English primary language of commerce,
administration, and higher education;
Swahili widely understood and generally
used for communication between ethnic
groups; first language of most people is one
of the local languages; primary education
is generally in Swahili
Infant mortality rate: 103/1,000 (1984)
Life expectancy: 52
Literacy: 79%
Labor force: 208,680 in paid employment
(1983); 90% agriculture, 10% industry and
commerce
Organized labor: 15% of labor force','76ffdd1d6ec4c4696e379ada0a9a3364861a2a8d8605d58c39740f92a6abc9eb','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('832585b90c9abb565ed5d81981db28bb28e12b525e2263eb130adee7f63b193c',1987,'TG','Togo','people-and-society',681,'Population: 3,228,635 (July 1987), average
annual growth rate 3.25%
Nationality: noun—Togolese (sing. and
pl.); adjective—Togolese
Ethnic divisions: 37 tribes; largest and
most important are Ewe, Mina, and Ka-
byé; under 1% European and Syrian-
Lebanese
241
Religion: about 70% indigenous beliefs,
20% Christian, 10% Muslim
Language: French, both official and lan-
guage of commerce; major African lan-
guages are Ewe and Mina in the south and
Dagomba and Kabyé in the north
Infant mortality rate: 114/1,000 (1983)
Life expectancy: 47
Literacy: 18%
Labor force: 78% agriculture, 22% indus-
try; about 88,600 wage earners, evenly
divided between public and private sectors
Organized labor: one national union, the
National Federation of Togolese Workers','b997dcc44fbe33d6473e250beebedd058654e2942a218cebc3132701a4c8419c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76bc75fa2a742756de7f8ad6a89ffe421bb226d06618fb21490d1bacea5bd1f8',1987,'TK','Tokelau','people-and-society',685,'Population: 1,713 (July 1987), average
annual growth rate 1.95%
Nationality: noun—Tokelauan(s); adjec-
tive—Tokelauan
Ethnic divisions: all Polynesian, with
cultural ties to Western Samoa
Religion: 70% Congregational Christian
Church, 30% Roman Catholic—on Atafu,
all Congregational] Christian Church of
Samoa; on Nukunonu, all Roman Catholic;
on Fakaofo, both denominations
Language: Tokelauan (a Polynesian lan-
guage) and English
Literacy: probably high','80b1e7f0b9c0b851ba532068d957059b0992bee9b1907f508b3ad2553c691805','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('332a0e0b9a88bc32fc8254e81d12924ea29e7075f5015159e5a8cbff224b76d8',1987,'TO','Tonga','people-and-society',688,'Population: 98,689 (July 1987), average
annual growth rate 0.76%
Nationality: noun—Tongan(s); adjective—
Tongan
Ethnic divisions: Polynesian; about 300
Europeans
Religion: Christian; Free Wesleyan
Church claims over 30,000 adherents
Tonga (continued)
Language: Tongan, English
Infant mortality rate: 6.4/1,000 (1983)
Life expectancy: 58
Literacy: 90-95%; compulsory education
for children ages 6-14
Labor force: 70% engaged in agriculture;
600 engaged in mining','607fafe7e8e4715d3a4c0a65216585b3b3a9caea8afb15adcb55df9c5ee15d2e','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a4a4e68c22b18e3501dca1e6de7d1a72be6bb336c4c6f2e0aa7d8b2162f52a',1987,'TT','Trinidad and Tobago','people-and-society',693,'Population: 1,250,839 (July 1987), average
annual growth rate 2.36%
Nationality: noun—Trinidadian(s),
Tobagan(s); adjective—Trinidadian,
Tobagan
Ethnic divisions; 43% black, 40% East
Indian, 14% mixed, 1% white, 1% Chinese,
1% other
Religion: 36.2% Roman Catholic, 23.0%
Hindu, 13.1% Protestant, 6.0% Muslim,
21.7% unknown
Language: English (official), Hindi,
French, Spanish
Infant mortality rate: 20/1,000 (1984)
Life expectancy: men 67, women 72
Literacy: 89%
Labor force: about 463,900 (est. 1985);
18.1% construction and utilities; 14.8%
manufacturing, mining, and quarrying;
10.9% agriculture; 47.9% other services
(1985); 15.4% unemployment (June 1985)
Organized labor: 40% of labor force
(1984)','e01da282a33acf63e101f421fbc06a5ed5c2ae1da77430ffc3520f07c7320416','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53697b2fa799017c7fe7175235eb2373006ec103f581fdaa332031ad2a45aecb',1987,'TN','Tunisia','people-and-society',698,'Population: 7,561,641 (July 1987), average
annual growth rate 2.33%
Nationality: noun—Tunisian(s); adjec-
tive—Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official); Arabic and
French (commerce)
Infant mortality rate: 83/1,000 (1983)
Life expectancy: men 60, women 63
Literacy: about 62%
Labor force: 1.9 million, 32% agriculture;
15%-25% unemployed; shortage of skilled
labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force;
General Union of Tunisian Workers
(UGTT), quasi-independent of Destourian
Socialist Party
Population: 52,987,778 (July 1987), aver-
age annual growth rate 2.23%
Nationality: noun—Turk(s); adjective—
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish,
Arabic
Infant mortality rate: 15.3/1,000 (1984)
Life expectancy: 57
Literacy: 70%
Labor force: 18.5 million (1986); 58.3%
agriculture, 28.7% service, 13.0% industry
and energy; about 1 million Turks work
abroad (1986); effective unemployment
rate estimated to be over 20% (1986)
Organized labor: 10-15% of labor force','d171b5537042cbf467199416c7ec5f6fb0e89de0b59687bec63d60c388c59676','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d0d2d19bff627d1797553d7e57f0285a821c2a52908097827e1b3d71f0abebe',1987,'JP','Japan','people-and-society',702,'Population: 9,052 (1987), average annual
growth rate 2.66
Ethnic division: majority of African
descent
Religion: Anglican, Roman Catholic
Baptist, Methodist, Church of God,
Seventh-Day Adventist
Language: English (official)
Infant mortality rate: 24.4/1,000
(1981/82)
Literacy: about 99%
,
Labor force: some subsistence agriculture;
majority engaged in fishing and tourist
industries
Organized labor: St. George’s Industrial
Trade Union (Cockburn Harbour), 250
members','8b5b2b172b9ee05e66ff0c7f04c2cdb007a3bf57d87bc826035e740088bce058','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8118da50c651dcdeb0910a862ff34703eae8919ca623c58e35fdc320400dc0f9',1987,'TV','Tuvalu','people-and-society',706,'Population: 8,329 (July 1987), average
annual growth rate 1.73%
Nationality: noun—Tuvaluanss); adjec-
tive—Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant
Language: Tuvaluan, English
Infant mortality rate: 42/1,000 (1979)
Life expectancy: men 57, women 60
Literacy: less than 50%','17f482a0fec2ee255d73646f618d2fd53c24b78843d35d43100634f91b1baafa','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e46146db133cead3ae2131933210153b8c6690fb23d78131f1a965d0cfbcd910',1987,'UG','Uganda','people-and-society',711,'Population: 15,908,896 (July 1987), aver-
age annual growth rate 3.70%
Nationality: noun—Ugandan(s); adjec-
tive—Ugandan
Ethnic divisions: 99% African, 1% Euro-
pean, Asian, Arab
Religion: 833% Roman Catholic, 33%
Protestant, 16% Muslim, rest indigenous
beliefs
Language: English (official), Luganda and
Swahili widely used; other Bantu and
Nilotic languages
Infant mortality rate; 92/],000 (1985)
Life expectancy: men 48, women 50
Literacy: 52%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members','df2312379c01499e3846677d1476fa09684fe95365d17f0e2a00f538b9d4c9d8','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ccf067e3127a4f61a0537c011eccede8b9bb6fb55ae33765ac0d98c11eede8f',1987,'AE','United Arab Emirates','people-and-society',716,'Population: 1,846,373 July 1987), average
annual growth rate 7.47%
Nationality: noun—Emirian(s), adjective—
Emirian
Ethnic divisions: 19% Emirian, 23% other
Arab, 50% South Asian (fluctuating), 8%
other expatriates (includes Westerners and
East Asians); fewer than 20% of the popu-
lation are UAE citizens (1982)
Religion: 96% Muslim (16% Shi''a); 4%
Christian, Hindu, and other
Language: Arabic (official); Farsi and
English widely spoken in major cities;
Hindi, Urdu
Infant mortality rate: 44/1,000 (1983)
Life expectancy: men 68, women 73
Literacy: 68%
Labor force: 580,000 (1985 est.); 85%
industry and commerce, 5% agriculture,
5% services, 5% government; 80% of labor
force is foreign','9b87a6160251c02bf82092bfe057ed4bde4720730f45cd73de03d2f9677b6b7a','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71f9920cb4188b2a31f0af57e86fb08b65d7419266da901681c6405bf35898a8',1987,'GB','United Kingdom','people-and-society',721,'Population: 56,845,195 (July 1987), aver-
age annual growth rate 0.15%
Nationality: noun—Briton(s), British
(collective pl.); adjective—British
Ethnic divisions: 81.5% English, 9.6%
Scottish, 2.4% Irish, 1.9% Welsh, 1.8%
Ulster, 2.8% West Indian, Indian, Paki-
stani, and other
Religion: 27.0 million Anglican, 5.3 mil-
lion Roman Catholic, 2.0 million Presbyte-
rian, 760,000 Methodist, 450,000 Jewish
(registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of
Gaelic (about 60,000 in Scotland)
Infant mortality rate: 10.1/1,000 (1983)
Life expectancy: 7]
Literacy: 99%
Labor force: (1986) 27.94 million; 24.5%
manufacturing and construction, 49.8%
services, 9.8% self-employed, 13.0% gov-
ernment, 1.1% agriculture; 11.4% unem-
ployed (November 1986)
Organized labor: 42% of labor force','85a8877403a7735bee3610cd9962e32fe0e0f90cedc9fbe7a99a5502b94f707f','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3211b93f361f36b1f5c65ca81e51cb5dbd55e6a998b3fffc63d9dc6e9f9739e',1987,'US','United States','people-and-society',725,'Population: 243,084,000 (July 1987),
average annual growth rate 0.92%
Ethnic divisions: 83.1% white; 11.6%
black; 6.448% Spanish origin; 0.622%
American Indian, Eskimo, and Aleut;
0.357% Chinese; 0.343% Filipino; 0.31%
Japanese, 0.1595% other Asian; 0.156%
Korean; 0.115% Vietnamese (1980)
Religion: total membership in religious
bodies 140.170 million; Protestant 76.8
million, Roman Catholic 52.7 million,
Jewish 5.7 million, other religions 5.0
million; 60% of the population have a
religious affiliation (1982)
Language: predominantly English; sizable
Spanish-speaking minority
Infant mortality rate: 10.6/1,000 (1984)
Life expectancy: men 71.6, women 76.3
Literacy: 99%
Labor force: 117.17 million (includes the
armed forces and the unemployed)—
annual averages of monthly data; unem-
ployment rate 7.2% (1985); 7.1% unem-
ployed as a share of total civilian labor
force (1985)
Organized labor: 17.3 million members;
18% of civilian labor force (1985)','93ca9391673fb5f5fd7ccb664721c9db1f6addfb016e44793b07a6caa15ae102','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d00d1d978c307cec5faf5847f55541d8cdbb1f6f1405f0e7a1c08c0d73f7c0',1987,'UY','Uruguay','people-and-society',730,'Population: 2,964,052 (July 1987), average
annual growth rate 0.39%
Nationality: noun—Uruguayan(s); adjec-
tive—Uruguayan
Ethnic divisions: 88% white, 8% mestizo,
4% black
Uruguay (continued)
Religion: 66% Roman Catholic (less than
half adult population attends church
regularly), 2% Protestant, 2% Jewish, 30%
nonprofessing or other
Language: Spanish
Infant mortality rate: 32/1,000 (1983)
Life expectancy: men 67.1, women 73.7
Literacy: 94.3%
Labor force: about 1.28 million (1981);
25% government; 19% manufacturing; 11%
agriculture; 12% commerce; 12% utilities,
construction, transport, and communica-
tions; 21% other services; unemployment
11% (1986 est.)
Organized labor: Interunion Workers’
Assembly /National Workers’ Confedera-
tion (PIT/CNT) Labor Federation','4278a18b04a272d54fca1f9f1bc15ab700b22e5836161ad9dfebfc2b2d442a2c','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebe2d8bb97441ff84bd3bb9fb3fd0474b95f7266620a8d30ddeb0c5739da80a7',1987,'VU','Vanuatu','people-and-society',735,'Population: 149,652 (July 1987), average
annual growth rate 3.36%
Nationality: noun—Vanuatuan(s); adjec-
tive—Vanuatuan
Ethnic divisions: 90% indigenous Melanes-
ian; 8% French; remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Christian
Language: English and French (official);
pidgin (known as Bislama or Bichelama)
Life expectancy: 55
Literacy: probably 10-20%
Population: 738 (July 1987), average
annual growth rate 0.14%
Ethnic divisions: primarily Italians but
also many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various
other languages
Literacy: 100%
Labor force: about 1,500; Vatican City
employees divided into three categories—
executives, office workers, and salaried
employees
Population: 18,291,134 (July 1987), aver-
age annual growth rate 2.66%
Nationality: noun—Venezuelan(s); adjec-
tive—Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official); Indian dia-
lects spoken by about 200,000 Amerind-
ians in the remote interior
Infant mortality rate: 36.2/1,000 (1984)
Life expectancy: men 64.0, women 69.0
Literacy: 85.6%
Labor force: 5.8 million (1985), 56%
services, 28% industry, 16% agriculture
(1980); 10.5% unemployment (December
1986)
Organized labor: 32% of labor force','c5cfa3ae6651e215d6d5cfd50f911f58aa1ada7b6439ae933dc3e950a7fb1dde','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbdc41b14fdcbad009251fe10d812bb980af672d4a93ef375153dbf9d1d77fc7',1987,'WF','Wallis and Futuna','people-and-society',740,'Population: 14,593 (July 1987) average
annual growth rate 2.35%
Nationality: noun—Wallisian(s), Futun-
an(s), or Wallis and Futuna Islanders,
adjective—Wallisian, Futunan, or Wallis
and Futuna Islander
Ethnic divisions: almost entirely Polynes-
ian
Religion: largely Roman Catholic
Wallis and Futuna (continued)','048c39d62d828f6a990f83486f175aaa1e8a03890eb8a20073a2ce22b0e1fff5','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25db30a2d0fec40841a92e491a219b36da0c1ce2b7b66bf42d49b31af7bc9260',1987,'EH','Western Sahara','people-and-society',745,'Population: 93,859 (July 1987), average
annual growth rate 1.78%
Nationality: noun—Saharan(s), Moroc-
can(s); adjective—Saharan, Moroccan
Ethnic divisions: Arab and Berber
264
Religion: Muslim
Language: Hassaniya Arabic, Moroccan
Arabic
Literacy: about 20% among Moroccans,
5% among Saharans
Labor force: 12,000; 50% animal hus-
bandry and subsistence farming
Population: 175,084 (July 1987), average
annual growth rate 2.20%
Nationality: noun—Western Samoan(s);
adjective—Western Samoa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and
Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London
Missionary Society; includes Congrega-
tional, Roman Catholic, Methodist, Latter
Day Saints, Seventh-Day Adventist)
265
Language: Samoan (Polynesian), English
Infant mortality rate: 36/1,000 (1983)
Life expectancy: 63
Literacy: 90%
Labor force: about 37,000 (1983); about
22,000 employed in agriculture
Population: 6,533,265 (July 1987), average
annual growth rate 2.93%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-
Arab (mixed)
Religion: 100% Muslim (Sunni and Shi‘a)
Language: Arabic
Infant mortality rate: 152/1,000 (1983)
Life expectancy: men 37.3, women 88.7
Literacy: 15% (est.)
Labor force: about 30% expatriate labor-
ers; remainder almost entirely agriculture
and herding','201d22e36647fa30b5604c7a726178f7e6ede03de9b3e5bcf8fc13f71b580130','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b961053edfaab599892e3093756ff2938990c18345557dfa16bafec10a80af',1987,'ZM','Zambia','people-and-society',752,'Population: 7,281,738 (July 1987), average
annual growth rate 3.73%
Nationality: noun—Zambian(s); adjec-
tive—Zambian
Ethnic divisions; 98.7% African, 1.1%
European, 0.2% other
Religion: 50-75% Christian, 1% Muslim
and Hindu, remainder indigenous beliefs
Language: English (official); about 70
indigenous languages
Infant mortality rate: 140/1,000 (1984)
Life expectancy: 47
Literacy: 54%
Labor force: 2,455,000; 85% agriculture;
6% mining, manufacturing, and construc-
tion; 9% transport and services
Organized labor: about 238,000 wage
earners are unionized','14ca14bd56e72cd7e0e1aadc5ddedf8e2ae024c30698cb8c9f02dec59b1815ca','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1facbd4c838f86c7aecb2c0ed37a5ec3039091b529993f0784da2b0ac2e9857e',1987,'ZW','Zimbabwe','people-and-society',757,'Population: 9,371,972 (July 1987), average
annual growth rate 3.60%
Nationality: noun—Zimbabwean(s); adjec-
tive-—Zimbabwean
Ethnic divisions: about 96% African (over
73% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian,
part indigenous beliefs), 25% Christian,
24% indigenous beliefs, a few Muslim
273
Language: English (official); ChiShona and
Si Ndebele
Infant mortality rate: 66/1,000 (1985)
Life expectancy: men 53.3, women 56.8
Literacy: 45-55%
Labor force: 1,985,000 (1985); 78% agri-
culture; 18% mining, manufacturing,
construction; 4% transport and services
Organized labor: about one-third of
European wage earners are unionized, but
only a small minority of Africans
Population: 19,768,035, excluding the
population of Chin-men Tao (Quemoy),
Ma-tsu Tao (Matsu), and foreigners (July
1987), average annual growth rate 1.24%
Nationality: noun—Chinese (sing., pl.);
adjective—Chinese
Ethnic divisions: 85% Taiwanese, 14%
mainland Chinese, 2% aborigine
Religion: 98% mixture of Buddhist, Con-
fucian, and Taoist; 4.5% Christian; 2.5%
other
Language: Mandarin Chinese (official);
Taiwanese and Hakka dialects also used
Infant mortality rate: 11.01/1,000 (1983)
Life expectancy: men 69.9, women 74.9
Literacy: 94%
Labor force: 7,491,000 (1984); 41% indus-
try and commerce, 32% services, 20%
agriculture, 7% civil administration; 2.4%
unemployment (1984)
Organized labor: (1983) 1.8 million or
about 18.4% (government controlled)
Administration
Type: one-party presidential regime; the
new political organizations bill (due to be
passed in early 1987) will permit legal
formation of new political parties
Capital: Taipei
Administrative divisions: 16 counties, 5
cities, 2 special municipalities (Taipei and
Kao-hsiung)
Legal system: based on civil law system;
constitution adopted 1946, though 1948
amendments set most of the constitution
aside; martial law (declared in 1949) was
lifted in early 1987; accepts compulsory
IC] jurisdiction, with reservations
National holiday: 10 October
Branches: five independent branches
(executive, legislative, judicial, plus tradi-
tional Chinese functions of examination
and control), dominated by executive
branch; President and Vice President
elected by National Assembly
Government leaders: CHIANG Ching-
kuo, President (since March 1978); YU
Kuo-hua, Premier (since June 1984)
Suffrage: universal over age 20
Elections: national level—Legislative Yuan
every three years; National Assembly and
Control Yuan every six years; no general
election held since 1948 election on main-
land (partial elections for Taiwan province
representatives in December 1969, 1972,
1975, 1980, 1983, 1984, 1985, and 1986);
local level—provincial assembly, county
and municipal executives every four years;
county and municipal assemblies every
four years
Politica] parties and leaders: Kuomint-
ang, or National Party, led by Chairman
Chiang Ching-kuo; Democratic Socialist
Party and Young China Party controlled
by Kuomintang; The Democratic Progres-
sive Party (new opposition party) not
formally recognized by Kuomintang
Voting strength: (1983 Legislative Yuan
elections) 62 seats Kuomintang, 19 seats
independents; 1981 local elections, with
63% turnout of eligible voters, Kuomintang
received 71% of the popular vote, non-
Kuomintang 29%
Member of: expelled from UN General
Assembly and Security Council on 25
October 1971 and withdrew on same date
from other charter-designated subsidiary
organs; expelled from IMF/World Bank
group April/May 1980; member of ADB
and PECC, seeking to join GATT and/or
MFA; attempting to retain membership in
ICAC, ISO, INTELSAT, INTERPOL,
IWC—International Wheat Council, PCA;
suspended from IAEA in 1972, but still
allows [AEA controls over extensive atomic
development
Population: total, 1,529,235 July 1987);
average annual growth rate 2.57%; West
Bank (including East Jerusalem)—969,386
(July 1987), average annual growth rate
2.27%; Gaza Strip—559,849 (July 1987),
average annual growth rate 3.09%
Nationality: West Bank—to be deter-
mined; Gaza Strip—to be determined
Ethnic divisions: West Bank—88% Pales-
tinian Arab and other, 12% Jewish (includ-
ing expanded East Jerusalem), 4% Be-
douin; Gaza Strip—99.8% Palestinian Arab
and other, 0.2% Jewish
Religion: West Bank—80% Muslim (pre-
dominantly Sunni), 12% Jewish, 8% Chris-
tian and other; Gaza Strip—99% Muslim
(predominantly Sunni), 0.8% Christian,
0.2% Jewish
Language: West Bank—aArabic, Israeli
settlers speak Hebrew, English widely
understood; Gaza Strip—Arabic, Israeli
settlers speak Hebrew, English widely
understood
Labor force: West Bank—(excluding
Israeli Jewish settlers) 29.8% small indus-
try, commerce, and business, 24.2% con-
struction, 22.4% agriculture, and 23.6%
service and other (1984); Gaza Strip—
(excluding Israeli Jewish settlers) 32.0%
small industry, commerce and business,
24.4% construction, 25.5% service and
other, and 18.1% agriculture (1984)','d86f212ec138861eb346d89743eecbd786ba789676002d1638822e2e68411018','internet-archive','CIAWorldFactbook1987','txt','035d7df8f4a735297f8ca1383185a10b7e08ab36e6c602670eec6e075a095dd0','https://archive.org/download/CIAWorldFactbook1987/AD1137944_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

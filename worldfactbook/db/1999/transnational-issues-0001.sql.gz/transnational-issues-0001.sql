SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79e4d4e47ee1489c61046b30292aaf1d1d94e8bc6f1a9a797c94b30b43d5cd9d',1999,'EH','Western Sahara','transnational-issues',15,'Disputes— international
Illicit drugs
Disputes - international: claimed and administered
by Morocco, but sovereignty is unresolved and the UN
is attempting to hold a referendum on the issue; the
UN-administered cease-fire has been in effect since
September 1991
World','3d5067b5023590e7e04ba2895fad884b35a41d5af009904ff125f7cd650d5e3d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b8239df9cfb73c45799798d1c4cbd886798308b2938682c550b15c9cc72aed3',1999,'AF','Afghanistan','transnational-issues',16,'Location: Southern Asia, north and west of
Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
wafer: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan
2,430 km, Tajikistan 1 ,206 km, T urkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, talc, barites, sulfur, lead, zinc, iron ore, salt,
precious and semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding
Environment - current issues: soil degradation;
overgrazing; deforestation (much of the remaining
forests are being cut down for fuel and building
materials); desertification
Environment - international agreements:
party to: Desertification, Endangered Species,
Environmental Modification, Marine Dumping,
Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation
Geography - note: landlocked
Disputes - international: support to Islamic
militants worldwide by some factions; question over
which group should hold Afghanistan''s seat at the UN
Illicit drugs: world''s second-largest illicit opium
producer after Burma (cultivation in 1998 - 41 ,720
hectares, a 7% increase over 1997; potential
production in 1998 - 1,350 metric tons) and a major
source of hashish; increasing number of
heroin-processing laboratories being set up in the
country; major political factions in the country profit
from drug trade
Turks and
Caicos Islands
(overseas territory
of the UK)
Amr.tic
North
Caicos
«r„,
Blue
\\Hills~;
{7
p
West
Caicos
Providenciales
Bottle Creek
Middle Caicos
y. East Caicos
Caicos Islands W;1 grand turk
Cockbum Harbour ,;.: ^Town)^^
'' '' South $
i Caicos &
Ambergris Cays m
Noith Alien
Ocean
Seal
Cays
Salt Cay Af''
A*
Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US
495','53c2b21ceefa787119472c2067d83737bc10786d784f328613192933c0313ace','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f687af68cfe45ba5d5c1deb7168a12d1074fe100cafb222846c3aa889a753c',1999,'AL','Albania','transnational-issues',30,'Disputes - international: the Albanian Government
supports protection of the rights of ethnic Albanians
outside of its borders but has downplayed them to
further its primary foreign policy goal of regional
cooperation; Albanian majority in Kosovo seeks
independence from Serbian Republic; Albanians in
The Former Yugoslav Republic of Macedonia claim
discrimination in education, access to public-sector
jobs, and representation in government
Illicit drugs: increasingly active transshipment point
for Southwest Asian opiates, hashish, and cannabis
transiting the Balkan route and - to a far lesser extent
- cocaine from South America destined for Western
Europe; limited opium and cannabis production;
ethnic Albanian narcotrafficking organizations active
and rapidly expanding in Europe
Disputes - international: part of southeastern
region claimed by Libya
7','39d48de2ab8814eb3c1c7456ddc4d8b85dbd9104caabfa7674e5b154ef14f8c2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c267f6f29339015f3781795440ce80728e1c08c4f6daed1cee51adb4a74c9598',1999,'AS','American Samoa','transnational-issues',31,'(territory of the US)
O 190 km
Swains
Island
6 lOO mi
Pacific
Ocean
Samoa °.fu Olosega
Rose
. .. ''au Island
Tutuila
South
Pacific
Ocean
- ''I-** '' ^*•7, f''''*'' (
PAGO PAGO* - (
< ’ ""r
V/”
<* Tutuila
Aunu''u
10 20 km
Disputes - international: none
O 5 10 km
O 5 10 mi
Disputes - international: none','33e57df4105377276d2048163987a184754e70eb65d7d07a14b55d6bfa9c3b4f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e9b9e1d7076d7bd9a42cd67b2df899ae5988907352d2f5139f0850c40946327',1999,'AO','Angola','transnational-issues',44,'Disputes ■ international: none
Illicit drugs: increasingly used as a transshipment
point for cocaine and heroin destined for Western
Europe and other African states','cc8879330a6876476336b8dcf501763335bb8b1c9b9ac5261ee6ebe93e732ffe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('691b461f391e03a300722b6ffe37cc22a2b9cf06c11a956a1aab0a075bddf822',1999,'AI','Anguilla','transnational-issues',45,'(overseas territory
of the UK)
0 20 40 km
North
°Sombrero North
Atlantic
Caribbean Ocean
Sea
Atlantic
Ocean
0 5 10 km
Anguilia^/P
St. Martinoiy%A
O 5 10 mi
f'' ''J? Prickley
Pear; - Seal
° Dog Cays Island
Island
Sci uL)
Island
V THE VALtfEY
Road Bay — f* • >,
Caribbean J
Sea n3lowing Point
St. Martin _ _
(FRANCE and NETH.)
Disputes - international: none','7b95e81462b0628bfef2527caf132d23588f6242ba111e54e02109ccd1572c5c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e62b93bce6db5a536950a60f3eee0fdefc7d7e7ce46101f1714bf1efa5ee54b4',1999,'AQ','Antarctica','transnational-issues',60,'Disputes - international: Antarctic T reaty defers
claims (see Antarctic Treaty Summary above);
sections (some overlapping) claimed by Argentina,
Australia, Chile, France (Adelie Land), New Zealand
(Ross Dependency), Norway (Queen Maud Land),
and UK; the US and most other nations do not
recognize the territorial claims of other nations and
have made no claims themselves (the US reserves
the right to do so); no formal claims have been made
in the sector between 90 degrees west and 150
degrees west
Disputes - international: short section of the
southwestern boundary with Chile is indefinite -
process to resolve boundary issues is underway;
claims UK-administered Falkland Islands (Islas
Malvinas); claims UK-administered South Georgia
and the South Sandwich Islands; territorial claim in
Illicit drugs: increasing use as a transshipment
country for cocaine headed for Europe and the US;
increasing money-laundering center','98bd9f5bb41b4f8cf29830af2ec1e4e33c015853bb0e24db0d0b069f8a89f632','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('108e5e5f05ec892d6baed8b3eeb2ddfa810b9c7566e7508f11f2eec21eb7028d',1999,'AG','Antigua and Barbuda','transnational-issues',61,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area:
total: 440 sq km
land: 440 sq km
wafer: 0 sq km
note: includes Redonda
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters
tourism
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 1 1 %
other: 62% (1 993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment - current issues: water management
- a major concern because of limited natural fresh
water resources - is further hampered by the clearing
of trees to increase crop production, causing rainfall to
run off quickly
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements','b1b3e2fdec7ae305fcc70e3affb9c70d87054e5889f94f3f54b7019514b234d3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55be7ba5aba9d860d53dc06daceedba47ce19df96d5e9967b2c32ec631c7c75d',1999,'GP','Guadeloupe','transnational-issues',69,'Disputes - international: none ''
Illicit drugs: over the long-term, considered a
relatively minor transshipment point for narcotics
bound for the US and Europe and recently, a
transshipment point for heroin from Europe to the US;
potentially more significant as a
drug-money-laundering center
Arctic Ocean
Disputes - international: some maritime disputes
(see littoral states); Svalbard is the focus of a maritime
boundary dispute between Norway and Russia
19','cbb7df25c95b8c6c89e2447d5749d297e32142c9eaaafabeeb4278f61547ff92','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f454a4fb7fe2ab08885a4971c8c0bd356446e24c0852a4039262c792ef44d76',1999,'AR','Argentina','transnational-issues',73,'Background: A part of the Spanish empire until
independence in 1816, Argentina subsequently
experienced periods of internal political conflict
between conservatives and liberals and between
civilian and military factions. Meantime, thanks to rich
natural resources and foreign investment, a modern
agriculture and a diversified industry were gradually
developed. After World War II, a long period of
Peronist dictatorship was followed by rule by a military
junta. Democratic elections finally came in 1983, but
both the political and economic atmosphere remain
susceptible to turmoil.
Illicit drugs: illicit producer of cannabis for the
international drug trade; transshipment country for
Bolivian cocaine headed for Europe and the US
383
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Geographic coordinates: 1 0 00 S, 76 00 W
Map references: South America
Area:
total: 1 ,285,220 sq km
land: 1 .28 million sq km
water: 5,220 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
total: 6,940 km
border countries: Bolivia 900 km, Brazil 1,560 km,
Chile 1 60 km, Colombia 2,900 km, Ecuador 1 ,420 km
Coastline: 2,414 km
Maritime claims:
continental shelf: 200 nm
territorial sea: 200 nm
Climate: varies from tropical in east to dry desert in
west
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern lowland
jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum,
timber, fish, iron ore, coal, phosphate, potash
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 21 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 12,800 sq km (1993 est.)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild volcanic activity
Environment - current issues: deforestation;
overgrazing of the slopes of the costa and sierra
leading to soil erosion; desertification; air pollution in
Lima; pollution of rivers and coastal waters from
municipal and mining wastes
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed , but not ratified: Climate Change-Kyoto
Protocol
Geography - note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bolivia
Disputes - international: on 26 October 1 998, Peru
and Ecuador concluded treaties on commerce and
navigation and on boundary integration, to complete a
package of agreements settling the long-standing
boundary dispute between them; demarcation of the
agreed-upon boundary was scheduled to begin in
mid-January 1999
Illicit drugs: until recently the world''s largest coca
leaf producer, Peru has reduced the area of coca
under cultivation by 26%, from 68,800 hectares in
1997 to 51 ,000 hectares at the end of 1998; most of
cocaine base is shipped to neighboring Colombia and
Brazil for processing into cocaine for the international
drug market, but exports of finished cocaine are
increasing','a3f7d8f8057a544415f4b203fdb640f9cd836362c672ccccfe78bf7876165418','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63874f000fa3e7e12dbbf1b7ed6b81e1e33cb0496fdfcdec86034fa8a93ad484',1999,'AM','Armenia','transnational-issues',77,'Background: Armenia was one of the 15 successor
republics to the USSR in December 1991. Its leaders
remain preoccupied by the long conflict with
Azerbaijan over the Nagorno-Karabakh enclave.
Although a cease-fire has been in effect since May
1994, the sides have not made substantial progress
toward a peaceful resolution. In January 1998,
differences between President TER-PETROSSIAN
and members of his cabinet over the
Nagorno-Karabakh peace process came to a head.
With the prime minister, defense minister, and
security minister arrayed against him, an isolated
TER-PETROSSIAN resigned the presidency on 3
February 1998. Prime Minister Robert KOCHARIAN
was elected president in March 1 998. Concerns about
Armenia''s economic performance have continued
since 1 997 with a slowdown in growth and the serious
impact of the 1998 financial crisis in Russia.','663e32f74df4a82576a2375f0a6e6d4557e20bc8752d4b3418f5e661ec3b4ff0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a51b7b936384b7657b8c0cc9bdb67c5c9bd0809a9fc4bd7682aad9e8eac3c2a',1999,'GE','Georgia','transnational-issues',86,'Disputes - international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; traditional
demands on former Armenian lands in Turkey have
subsided
Illicit drugs: illicit cultivator of cannabis mostly for
domestic consumption; increasingly used as a
transshipment point for illicit drugs - mostly opium and
hashish - to Western Europe and the US via Iran,
Central Asia, and Russia
24
Aruba +
(part of the Kingdom of
the Netherlands)
Location: Caribbean, island in the Caribbean Sea,
north of Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the
Caribbean
Area:
fofa/:193sq km
land: 193 sq km
water: 0 sq km
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: NEGL; white sandy beaches
Land use:
arable land: 11%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 89% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies outside the Caribbean
hurricane belt
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Disputes - international: none
Illicit drugs: drug-money-laundering center and
transit point for narcotics bound for the US and
Europe; added to the US list of major drug producing
or drug transit countries in December 1996
Ashmore and
Cartier islands
(territory of Australia)
Disputes - international: none
Atlantic Ocean
Disputes - international: some maritime disputes
(see littoral states)
Background: Beset by ethnic and civil strife since
independence from the Soviet Union in December
1991 , Georgia began to stabilize in 1994. Political
settlements for separatist conflicts in South Ossetia
and Abkhazia remain elusive. The conflict in South
Ossetia has been dormant since spring 1994, but
sporadic violence continues between Abkhaz forces
and Georgian partisans in western Georgia. Russian
peacekeepers are deployed in both regions and a UN
Observer Mission is operating in Abkhazia. As a result
of these conflicts, Georgia still has about 250,000
internally displaced people. In 1995, Georgia adopted
a new constitution and conducted generally free and
fair nationwide presidential and parliamentary
elections. In 1996, the government focused its
attention on implementing an ambitious economic
reform program and professionalizing its parliament.
Violence and organized crime were sharply curtailed
in 1 995 and 1 996, but corruption remains rife. Georgia
has taken some steps to reduce its dependence on
Russia, acquiring coastal patrol boats in 1997 to
replace Russian border units along the Black Sea
coast. In 1998, Georgia assumed control of its Black
Sea coast and about half of its land border with Turkey
in line with a June 1 998 agreement with Russia. Since
1 997, Georgia''s parliament has sharpened its rhetoric
against Russia''s continued military presence on
Georgian territory. In February 1 998 an assassination
attempt was made against President
SHEVARDNADZE by supporters of the late former
president Zviad GAMSAKHURDIA. In October 1998,
a disaffected military officer led a failed mutiny in
western Georgia; the armed forces continue to feel the
ripple effect of the uprising, Georgia faces
parliamentary elections this fall, and presidential
elections next spring. After two years of robust growth,
the economy, hurt by the financial crisis in Russia,
slowed in 1998.
Location: Southwestern Asia, bordering the Black
Sea, between Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent
States
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1 ,461 km
border countries: Armenia 164 km, Azerbaijan 322
km, Russia 723 km, Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on
Black Sea coast
Terrain: largely mountainous with Great Caucasus
Mountains in the north and Lesser Caucasus
Mountains in the south; Kolkhet''is Dablobi (Kolkhida
Lowland) opens to the Black Sea in the west; Mtkvari
River Basin in the east; good soils in river valley flood
plains, foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek)
5,048 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper, minor coal and
oil deposits; coastal climate and soils allow for
important tea and citrus growth
Land use:
arable land: 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other: 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: earthquakes
Environment ■ current issues: air pollution,
particularly in Rust''avi; heavy pollution of Mtkvari
River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Law of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Desertification
Disputes - international: none
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption; used
as transshipment point for opiates via Central Asia to
Western Europe','17a3484284dc7ba1b465d44158077836738571ce7f9df4731b2cd7b240888f5f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a514642713eacc62c68202dab69678d8f817e8bda6145207a6937980a683ed',1999,'AU','Australia','transnational-issues',98,'Disputes - international: territorial claim in
Antarctica (Australian Antarctic Territory)
Illicit drugs: Tasmania is one of the world''s major
suppliers of licit opiate products; government
maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
Disputes - international: none
Illicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine destined
for Western Europe
32
Disputes - international: none
Clipperton Island
(possession of France)
Location: Middle America, atoll in the North Pacific
Ocean, 1,120 km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references: World
Area:
total: 7 sq km
land: 1 sq km
water: 0 sq km
Area - comparative: about 1 2 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1km
Maritime claims:
territorial sea: 12 nm
Climate: tropical, humid, average temperature 20-32
degrees C, rains May-October
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all coral)
Irrigated land: 0 sq km (1993)
Natural hazards: subject to tornadoes
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: reef about 8 km in circumference
Disputes - international: none
i
Aj Frederick
. t**
t Saumaroz Rc-ef
\\ \\ West
f r Mot
Wreck Reef-R
Bird Islet
Disputes - international: none
117
Disputes - international: none
Background: Popes in their secular role ruled much
of the Italian peninsula, including Rome, for about a
thousand years, until 1870. A dispute between a
series of popes and Italy was settled in 1929 by
treaties that recognized the Vatican City as an
independent sovereignty and gave Roman
Catholicism special status in Italy. The US established
formal diplomatic relationships with the Vatican in
1984. Present issues in the Vatican concern the ill
health of Pope John Paul II, who turns 79 on 20 May
1999, inter-religious dialogue and reconciliation, and
the adjustment of church doctrine in an era of rapid
change. About 1 billion people worldwide profess the
Roman Catholic faith.
Disputes - international: none
Disputes - international: none
219
Disputes - international: none
Disputes - international: none
Northern Mariana
islands
(commonwealth in political
union with the US)
Farallon de
Pajaros
O lOO 200 km
0 lOO
Maug Islands
200 ml
Asuncion Island
Philippine Agrihan
Sea
Pagan 1 1 North
Pacific
Quguan Ocean
Sarigan
: ''Anatahan
" Farallon de
Medinilla
SAIPAN
• Tinian
Rota','6e5bde7f3d82ba91fbae7b68f3ef43a9883d94a7fd2e6e61d2df166d49d97d4c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e658c5de32ab8d68f392142419875c0fc54c1814f24ca73512b7efcc7be2d7',1999,'BS','Bahamas','transnational-issues',112,'Disputes - international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; banking industry
vulnerable to money laundering','a579058c00fd3f87f06f6fc07ee4fe9bec160436fb3a91be39f1813f95de920c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75fcd11ffafb06fa3744a9547bccedb1124fd74a1fa05dc7fd39b596607a8aa2',1999,'BH','Bahrain','transnational-issues',120,'Disputes - international: territorial dispute with
Qatar over the Hawar Islands and maritime boundary
dispute with Qatar currently before the International
Court of Justice (ICJ)
Baker Island
(territory of the US)
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area:
total: 1 .4 sq km
land: 1 .4 sq km
water: 0 sq km
Area - comparative: about 2.5 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low, nearly level coral island surrounded by
a narrow fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until
1891)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: treeless, sparse, and scattered
39
Baker Island (continued)
vegetation consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds, and marine
wildlife
Disputes - international: none','968ab6f61337022bd7796a3c11bcf588fda721ba6be424c1a7f312fb2923c5fc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('586b6ce7e038420fccdf4a844c54d7cfe8c64c9432617ee4cf940fa4c72ca986',1999,'BD','Bangladesh','transnational-issues',121,'Location: Southern Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
tofa/: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: up to the outer limits of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; cool, dry winter (October to
March); hot, humid summer (March to June); cool,
rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1,230 m
Natural resources: natural gas, arable land, timber
Land use:
arable land: 73%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 15%
other: 5% (1993 est.)
Irrigated land: 31,000 sq km (1993 est.)
Natural hazards: droughts, cyclones; much of the
country routinely flooded during the summer monsoon
season
Environment - current issues: many people are
landless and forced to live on and cultivate
flood-prone land; limited access to potable water;
water-borne diseases prevalent; water pollution
especially of fishing areas results from the use of
commercial pesticides; intermittent water shortages
because of falling water tables in the northern and
central parts of the country; soil degradation;
deforestation; severe overpopulation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Disputes - international: a portion of the boundary
with India is indefinite; dispute with India over South
Talpatty/New Moore Island
Illicit drugs: transit country for illegal drugs
produced in neighboring countries','611f51a4637f79041d4a1aacd39ccac117cb53f35431a6bc588bad1aa6090dde','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('488989e3067d90dd9a6dac6d1af49ba749eb3b53315883df3bfbae6b62aa7ee5',1999,'BB','Barbados','transnational-issues',128,'0
5 10 km
0
5 10 mi
/
North
\\ \\
Atlantic
l \\
Ocean
r Speightstown \\
1 \\
Bathsheba
Holetown
" V
\\
BRIDGETOWN
l
)
/
/
/The
. - Crane
'' . Y
Caribbean Sea
/
telephone— [1] (246) 431 1600
FAX-J1] (246) 426 7269
established— 1 8 October 1969
effective— 26 January 1970
aim— to promote economic development and
cooperation
regional members— (20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands,
Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members— (6) Canada, China, France, Germany, Italy, UK
Cartagena Group
see Group of 1 1
555
Appendix C: International Organizations and Groups (continued)
Central African Customs and Economic members— (6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
Union (UDEAC)
note— acronym from Union Douaniere et
Economique de I''Afrique Centrale
address— BP 969, Bangui, Central African
Republic
telephone-^ 236] 61 09 22, 61 45 77
FAX— [236] 61 21 35
established— 8 December 1964
effective— 1 January 1 966
aim— to promote the establishment of a
Central African Common Market
Central African States Development Bank members— (9) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, France,
(BDEAC) Gabon, Germany, Kuwait
nofe— acronym from Banque de
Developpement des Etats de I''Afrique Centrale
address— BDEAC, Place du Gouvernement, BP
1177, Brazzaville, Republic of the Congo
telephone— {2A2] 83 01 26, 83 01 49, 81 02 12,
81 02 21
FAX— [242] 83 02 66
established— 3 December 1975
aim— to provide loans for economic
development
Central American Bank for Economic members— { 5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
Integration (BCIE) nonregional members— {A) Argentina, Colombia, Mexico, T aiwan
note— acronym from Banco Centroamericano
de Integracion Economico
address— Apartado Postal 772, Tegucigalpa
DC, Honduras
telephone— [504] 372230 through 372239,
371 184 through 371 188
FAX— [504] 370793, 373904
established— 13 December 1960
aim— to promote economic integration and
development
Central American Common Market (CACM)
address— do SIECA, Apart Postal 1237, 4a
Avenida 10-25, Zona 14, Guatemala 01901,','4e6540a7fdf75d4d1718bc07011f841c078e2a12a7cc0b6e0976d6e7f16146ba','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3448a27af18e5c28550ff6df78c603717d3a176590cb1758dac6474112d9d516',1999,'LC','Saint Lucia','transnational-issues',137,'Disputes - international: none
Illicit drugs: one of many Caribbean transshipment
points for narcotics bound for the US and Europe
Bassas da India
(possession of France)
II
/
Sti ml Loci
i Channel
O 4 8 km
)
North
'' \\ Atlantic
i, Ocean
Caribbean /^CASTRIES >
>
f Anse La Raye
jDennery
/
S
?
c.
,fSoufri6re
(
TMicoud
.Choiseul
C
V''- ’ > /
V-. (
Vieux Fort*) ( ^
Saint Vincent Passage','ea5e6721ba00329a264d49f0b47718b0116d965347a28fd80c005b96f9c56294','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ff6045a9a5eb0ab106735c22512eb67d12923b4f21dd9765f8c7160f5390a71',1999,'MZ','Mozambique','transnational-issues',138,'Channel
y" "X /
i V
1 /
/j/lOL''f
/ /
''''V
//
* . y
Disputes - international: claims
French-administered Mayotte; the islands of Anjouan
(Nzwani) and Moheli (Mwali) have moved to secede
from Comoros
110
Congo, Democratic
Republic of the
Channel
reef t
-JC
Jr \\
Jj
% Vj( MAMOUTZOu/ -pl^udzi
% Mayotte /o \\$le
i; \\ Pamanzi
?,lV§ada is.?
J
\\ A ^Bandile
reei
i J
fa'' .
10 km
Location: Southern Africa, bordering the
Mozambique Channel, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801 ,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area - comparative: slightly less than twice the size
of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South Africa 491
km, Swaziland 105 km, Tanzania 756 km, Zambia 41 9
km, Zimbabwe 1 ,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center,
high plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 8%
other: 22% (1993 est.)
Irrigated land: 1,180 sq km (1993 est.)
Natural hazards: severe droughts and floods occur
in central and southern provinces; devastating
cyclones
Environment - current issues: a long civil war and
recurrent drought in the hinterlands have resulted in
increased migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; pollution of surface
and coastal waters
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Disputes - international: none
Illicit drugs: Southern African transit hub for South
American cocaine probably destined for the European
and US markets; producer of hashish and
methaqualone
Disputes - international: quadripoint with
Botswana, Namibia, and Zambia is in disagreement
Illicit drugs: significant transit point for African
cannabis and South Asian heroin, mandrax, and
methamphetamines destined for the South African
and European markets
Location: Eastern Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area - comparative: slightly smaller than Maryland
and Delaware combined
Land boundaries: 0 km
Coastline: 1,448 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudiness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
538
Taiwan (continued)
highest point : Yu Shan 3,997 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 5%
forests and woodland: 55%
other: 15%
Irrigated land: NAsqkm
Natural hazards: earthquakes and typhoons
Environment - current issues: air pollution; water
pollution from industrial emissions, raw sewage;
contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste
disposal
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Disputes - international: involved in complex
dispute over the Spratly Islands with China, Malaysia,
Philippines, Vietnam, and possibly Brunei; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does China
Illicit drugs: considered an important heroin transit
point; major problem with domestic consumption of
methamphetamines and heroin
540
Appendix A:
Abbreviations
ABEDA
Arab Bank for Economic Development in Africa
ACC
Arab Cooperation Council
ACCT
Agence de Cooperation Culturelle et Technique; see Agency for
Cultural and Technical Cooperation; changed name in 1996 to Agence
de la francophonie or Agency for the French-Speaking Community
ACP Group
African, Caribbean, and Pacific Group of States
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
AG
Andean Group; see Andean Community of Nations (CAN)
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Oxides
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent
Organic Pollutants
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Organic Compounds
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL
Arab League
ALADI
Asociacion Latinoamericana de Integracion; see Latin American Integration
Association (LAIA)
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Ancom
Andean Common Market; see Andean Community ofNations (CAN)
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
Autodin
Automatic Digital Network
BAD
Banque africaine de developpement; see African Development Bank (AfDB)
BADEA
Banque Arabe de Developpement Economique en Afrique; see Arab Bank for
Economic Development in Africa (ABEDA)
BCIE
Banco Centroamericano de Integracion Economico; see Central American Bank
for Economic Integration (BCIE)
BDEAC
Banque de Developpment des Etats de I''Afrique Centrale; see Central African
States Development Bank (BDEAC)
Benelux
Benelux Economic Union
541
Appendix A: Abbreviations (continued)
BID
Banco Interamericano de Desarrollo; see Inter-American Development Bank
(IADB) Biodiversity Convention on Biological Diversity
BIS
Bank for International Settlements
BOAD
Banque Ouest-Africaine de Developpement; see West African Development Bank
(WADB)
BSEC
Black Sea Economic Cooperation Zone
C
C
Commonwealth
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
CAN
Andean Community of Nations
Caricom
Caribbean Community and Common Market
CB
citizen’s band mobile radio communications
CBSS
Council of the Baltic Sea States
CCC
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEAO
Communaute Economique de I''Afrique de I''Ouest; see West African Economic
Community (CEAO)
CEEAC
Communaute Economique des Etats de I''Afrique Centrale; see Economic
Community of Central African States (CEEAC)
CEI
Central European Initiative
CEMA
Council for Mutual Economic Assistance; also known as CMEA or Comecon
CEPGL
Communaute Economique des Pays des Grands Lacs; see Economic Community
of the Great Lakes Countries (CEPGL)
CERN
Conseil Europeen pour la Recherche Nucleaire; see European Organization for
Nuclear Research (CERN)
CG
Contadora Group
c.i.f.
cost, insurance, and freight
CIS
Commonwealth of Independent States
CITES
see Endangered Species
Climate Change
United Nations Framework Convention on Climate Change
Climate Change-Kyoto
Protocol
Kyoto Protocol to the United Nations Framework Convention on Climate Change
CMEA
Council for Mutual Economic Assistance (CEMA); also known as Comecon
COCOM
Coordinating Committee on Export Controls
Comecon
Council for Mutual Economic Assistance (CEMA); also known as CMEA
Comsat
Communications Satellite Corporation
CP
Colombo Plan
CSCE
Conference on Security and Cooperation in Europe; see Organization on Security
and Cooperation in Europe (OSCE)
CY
calendar year
D
DC
developed country
Desertification
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
DSN
Defense Switched Network
DWT
deadweight ton
542
Appendix A: Abbreviations (continued)
EADB
East African Development Bank
EAPC
Euro-Atlantic Partnership Council
EBRD
European Bank for Reconstruction and Development
EC
European Community; see European Union (EU)
ECA
Economic Commission for Africa
ECAFE
Economic Commission for Asia and the Far East; see Economic and Social
Commission for Asia and the Pacific (ESCAP)
ECE
Economic Commission for Europe
ECLA
Economic Commission for Latin America; see Economic Commission for Latin
America and the Caribbean (ECLAC)
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Social Council
ECOWAS
Economic Community of West African States
ECSC
European Coal and Steel Community; see European Union (EU)
ECWA
Economic Commission for Western Asia; see Economic and Social Commission
for Western Asia (ESCWA)
EEC
European Economic Community; see European Union (EU)
EFTA
European Free Trade Association
EIB
European Investment Bank
EMU
European Monetary Union
Endangered Species
Convention on the International Trade in Endangered Species of Wild Flora and
Fauna (CITES)
Entente
Council of the Entente
Environmental
Convention on the Prohibition of Military or Any Other Hostile Use of
Modification
Environmental Modification Techniques
ESA
European Space Agency
ESCAP
Economic and Social Commission for Asia and the Pacific
ESCWA
Economic and Social Commission for Western Asia
est.
estimate
EU
European Union
Euratom
European Atomic Energy Community; see European Community (EC)
Eutelsat
European Telecommunications Satellite Organization
Ex-lm
Export-Import Bank of the United States
FAO
Food and Agriculture Organization
FAX
facsimile
f.o.b.
free on board
FLS
Front Line States
FRG
Federal Republic of Germany (West Germany); used for information dated before
3 October 1990 or CY91
FSU
former Soviet Union
FY
fiscal year (FY93/94, for example, began in calendar year 1993 and ended in
calendar year 1994)
FYROM
The Former Yugoslav Republic of Macedonia
FZ
Franc Zone
543
Appendix A: Abbreviations (continued)
G
G-2
Group of 2
G-3
Group of 3
G-5
Group of 5
G-6
Group of 6 (not to be confused with the Big Six)
G-7
Group of 7
G-8
Group of 8
G-9
Group of 9
G-10
Group of 10
G-11
Group of 1 1
G-15
Group of 15
G-19
Group of 19
G-24
Group of 24
G-30
Group of 30
G-33
Group of 33
G-77
Group of 77
GATT
General Agreement on Tariffs and Trade; subsumed by the World Trade
Organization (WTrO) on 1 January 1995
GCC
Gulf Cooperation Council
GDP
gross domestic product
GDR
German Democratic Republic (East Germany); used for information dated before
3 October 1990 or CY91
GNP
gross national product
GRT
gross register ton
GWP
gross world product
H
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
HF
high-frequency
1
IADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IBEC
International Bank for Economic Cooperation
IBRD
International Bank for Reconstruction and Development (World Bank)
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICEM
Intergovernmental Committee for European Migration; see International
Organization for Migration (IOM)
ICFTU
International Confederation of Free Trade Unions; see World Confederation of
Labor (WCL)
ICJ
International Court of Justice
ICM
Intergovernmental Committee for Migration; see International Organization for
Migration (IOM)
ICRC
International Committee of the Red Cross
ICRM
International Red Cross and Red Crescent Movement
IDA
International Development Association
IDB
Islamic Development Bank
IEA
International Energy Agency
IFAD
International Fund for Agricultural Development
544
Appendix A: Abbreviations (continued)
IFC
International Finance Corporation
IFCTU
International Federation of Christian Trade Unions
IFRCS
International Federation of Red Cross and Red Crescent Societies
IGAD
Inter-Governmental Authority on Development
IGADD
Inter-Governmental Authority on Drought and Development
IHO
International Hydrographic Organization
MB
International Investment Bank
ILO
International Labor Organization
IMCO
Intergovernmental Maritime Consultative Organization; see International Maritime
Organization (IMO)
IMF
International Monetary Fund
IMO
International Maritime Organization
Inmarsat
International Mobile Satellite Organization
InOC
Indian Ocean Commission
Intelsat
International Telecommunications Satellite Organization
Interpol
International Criminal Police Organization
Intersputnik
International Organization of Space Communications
IOC
International Olympic Committee
IOM
International Organization for Migration
ISO
International Organization for Standardization
ITU
International Telecommunication Union
K
kHz
kilohertz
km
kilometer
kW
kilowatt
kWh
kilowatt hour
L
LAES
Latin American Economic System
LAIA
Latin American Integration Association
LAS
League of Arab States; see Arab League (AL)
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
LDC
less developed country
LLDC
least developed country
London Convention
see Marine Dumping
LORCS
League of Red Cross and Red Crescent Societies; see International Federation of
Red Cross and Red Crescent Societies (IFRCS)
LOS
see Law of the Sea
M
m
meter
Marecs
Maritime European Communications Satellite
Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation
Convention on Fishing and Conservation of Living Resources of the High Seas
MARPOL
see Ship Pollution
Medarabtel
Middle East Telecommunications Project of the International T elecommunications
Union
Mercosur
Mercado Comun del Cono Sur; see Southern Cone Common Market
MHz
megahertz
MINURSO
United Nations Mission for the Referendum in Western Sahara
545
Appendix A: Abbreviations (continued)
MINUGUA
United Nations Verification Mission in Guatemala
MIPONUH
United Nations Civilian Police Mission in Haiti
MONUA
United Nations Observer Mission in Angola
MTCR
Missile Technology Control Regime
N
NA
not available
NACC
North Atlantic Cooperation Council; see Euro-Atlantic Partnership Council (EAPC)
NAM
Nonaligned Movement
NATO
North Atlantic Treaty Organization
NC
Nordic Council
NEA
Nuclear Energy Agency
NEGL
negligible
NIB
Nordic Investment Bank
NIC
newly industrializing country; see newly industrializing economy (NIE)
NIE
newly industrializing economy
nm
nautical mile
NMT
Nordic Mobile Telephone
NSG
Nuclear Suppliers Group
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and
Under Water
NZ','7f5e814fcf069c53df727abf20804c59d53b733fc791a0ba5f67a438827a35aa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fe88228e9965f84ed96f465f8828722dae46ec56bd3f5182e5493d301cc744f',1999,'FR','France','transnational-issues',145,'Disputes - international: claimed by Madagascar
Disputes - international: none
Cocos (Keeling)
Islands
(territory of Australia)
0 4 8 km
North Keeling M o '' 4^
Island
Indian
Ocean
South
Keeling
Islands
Horsburah
Island
^ ^ Direction Island
reefs
\\reefs
J^Home Island
South Island
reefs
Disputes - international: none
Illicit drugs: illicit producer of cannabis, mostly for
local consumption; minor transshipment point for
Southwest and Southeast Asian heroin to Europe and
occasionally to the US, and for Latin American
cocaine destined for Europe
Disputes - international: claimed by Madagascar
158
Falkland Islands
(Islas Malvinas)
I (overseas territory of the UK;
also claimed by Argentina)
Disputes - international: claimed by Argentina
Disputes - international: Suriname claims area
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa)
Illicit drugs: small amount of marijuana grown for
local consumption; minor transshipment point to
Europe
171
Disputes - international: "Adelie Land''1 claim in
Antarctica is not recognized by the US
Disputes - international: claimed by Madagascar
Disputes - international: complex maritime, air, and
territorial disputes with Turkey in Aegean Sea; Cyprus
question with Turkey; dispute with The Former
Yugoslav Republic of Macedonia over name; in
September 1995, Skopje and Athens signed an
interim accord resolving their dispute over symbols
and certain constitutional provisions; Athens also
lifted its economic embargo on The Former Yugoslav
Republic of Macedonia
Illicit drugs: a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle East
and Southwest Asia to the West and precursor
chemicals to the East; some South American cocaine
transits or is consumed in Greece
Disputes - international: none
198
Disputes - international: claimed by Madagascar
255
Disputes - international: parts of the border with
Thailand are indefinite
Illicit drugs: world''s third-largest illicit opium
producer (estimated cultivation in 1998 - 26,100
hectares, a 7% decrease over 1997; estimated
potential production in 1998 - 140 metric tons, a 33%
decrease over 1997); potential heroin producer;
transshipment point for heroin and
methamphetamines produced in Burma; illicit
producer of cannabis
274
Disputes - international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for the US and Europe
Disputes - international: none
330
Disputes - international: Matthew and Hunter
Islands claimed by France and Vanuatu
Disputes - international: none
400
Disputes - international: none
415
Saint Vincent and
the Grenadines
^ Soufridte A ^
/Chateaubelair
Saint / ^Georgetown
Vincenti /
@ KINGSTOWN
Caribbean
S e a
Bequla ■/;
Baliceaux Island
<s Mustiquef?-
Savan Island -
Petit Mustique Island
o''
1 Petit Canouan
£ Canouan
Mayreaup .Tobago Cays
Union Island ^ '' - Palm Island
• Petit St. Vincent Is.
Disputes - international: claimed by Madagascar
and Mauritius
Disputes - international: maritime boundary
dispute with Libya; Malta and Tunisia are discussing
the commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Disputes - international: complex maritime, air, and
territorial disputes with Greece in Aegean Sea;
Cyprus question with Greece; dispute with
downstream riparian states (Syria and Iraq) over
water development plans for the Tigris and Euphrates
Rivers; traditional demands on former Armenian lands
in Turkey have subsided
Illicit drugs: major transit route for Southwest Asian
heroin and hashish to Western Europe and - to a far
lesser extent the US - via air, land, and sea routes;
major Turkish, Iranian, and other international
trafficking organizations operate out of Istanbul;
laboratories to convert imported morphine base into
heroin are in remote regions of Turkey as well as near
Istanbul; government maintains strict controls over
areas of legal opium poppy cultivation and output of
poppy straw concentrate
491
Disputes - international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivator of opium poppy,
mostly for domestic consumption; limited government
eradication program; increasingly used as
transshipment point for illicit drugs from Southwest
Asia to Russia and Western Europe; also a
transshipment point for acetic anhydride destined for
Disputes - international: Northern Ireland issue
with Ireland (historic peace agreement signed 1 0 April
1998); Gibraltar issue with Spain; Argentina claims
Falkland Islands (Islas Malvinas); Argentina claims
South Georgia and the South Sandwich Islands;
Mauritius claims island of Diego Garcia in British
Indian Ocean Territory; Rockall continental shelf
dispute involving Denmark, Iceland, and Ireland
(Ireland and the UK have signed a boundary
agreement in the Rockall area); territorial claim in
Antarctica (British Antarctic Territory); Seychelles
claims Chagos Archipelago in British Indian Ocean
Territory
Illicit drugs: gateway country for Latin American
cocaine entering the European market; producer and
major consumer of synthetic drugs, synthetic
precursor chemicals; transshipment point for
Southwest Asian heroin; money-laundering center
Disputes - international: maritime boundary
disputes with Canada (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island); US
Naval Base at Guantanamo Bay is leased from Cuba
and only mutual agreement or US abandonment of the
area can terminate the lease; Haiti claims Navassa
Island; US has made no territorial claim in Antarctica
(but has reserved the right to do so) and does not
recognize the claims of any other nation; Marshall
Islands claims Wake Atoll
Illicit drugs: consumer of cocaine shipped from
Colombia through Mexico and the Caribbean;
consumer of heroin, marijuana, and increasingly
methamphetamines from Mexico; consumer of
high-quality Southeast Asian heroin; illicit producer of
cannabis, marijuana, depressants, stimulants,
hallucinogens, and methamphetamines;
drug-money-laundering center
Disputes - international: none
Background: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
("the DOP"), signed in Washington on 13 September
1 993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Permanent status
negotiations began on 5 May 1996, but have not
resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and
responsibilities to the Palestinian Authority, which
includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A
transfer of powers and responsibilities for the Gaza
Strip and Jericho took place pursuant to the
Israel-PLO 4 May 1 994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of
the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO
1 5 January 1 997 Protocol Concerning Redeployment
in Hebron, and the Israel-PLO 23 October 1998 Wye
River Memorandum. The DOP provides that Israel will
retain responsibility during the transitional period for
external security and for internal security and public
order of settlements and Israelis. Permanent status is
to be determined through direct negotiations.
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation
528
telephone— [33] (1 ) 49 53 28 28
FAX— [33] (1) 49 53 29 42
established— HA 1919
aim— to promote free trade and private
enterprise and to represent business interests at
national and international levels
members— (62 national councils) Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Burkina Faso,
Cameroon, Canada, Chile, China, Colombia, Cote d''Ivoire, Cyprus, Denmark, Ecuador, Egypt, Finland, France,
Germany, Greece, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait,
Lebanon, Lithuania, Luxembourg, Madagascar, Mexico, Morocco, Netherlands, Nigeria, Noway, Pakistan, Peru,
Portugal, Saudi Arabia, Senegal, Singapore, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan,
Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
572
Appendix C: International Organizations and Groups (continued)
International Civil Aviation Organization
(ICAO)
address— ICAO, 999 University Street, Montreal
H3C 5H7, Canada
telephone— {1] (514) 954 8219
FAX— [1] (514) 954 6077
established— 7 December 1944
effective— 4 April 1947
aim— to promote international cooperation in
civil aviation; a UN specialized agency
International Committee of the Red Cross
(ICRC)
members— { 185) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Palau, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
members— (25 individuals) all Swiss nationals
address— ICRC, 19 Avenue de la Paix,
CH-1202 Geneva, Switzerland
telephone— [4''\\] (22) 734 60 01
FAX— [41] (22) 733 20 57
established— HA 1863
aim— to provide humanitarian aid in wartime
members— (206 affiliated organizations in the following 141 countries) Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bangladesh, Barbados, Basque Country, Belgium, Belize, Benin, Bermuda,
Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, El
Salvador, Eritrea, Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Holy See, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea,
Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius, Mexico,
Moldova, Mongolia, Montserrat, Morocco, Mozambique, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico,
Romania, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri
Lanka, Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, UK, US, Vanuatu, Venezuela, Zambia, Zimbabwe
International Court of Justice (ICJ)
note— also known as the World Court
address— Peace Palace, NL-2517 KJ The
Hague, Netherlands
fe/ephone— [31] (70) 302 23 23
FAX— [31] (70) 364 99 28
established— 26 June 1945
effective— 24 October 1945
aim— primary judicial organ of the UN
members— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal
systems
International Confederation of Free Trade
Unions (ICFTU)
address— International Trade Union House,
Boulevard Emile Jacqmain 155, B-1210
Brussels, Belgium
fe/ephone— [32] (2) 224 02 11
FAX— [32] (2) 201 58 15, 203 07 56
established— HA December 1949
aim— to promote the trade union movement
573
Appendix C: International Organizations and Groups (continued)
International Criminal Police Organization
(Interpol)
address— BP 6041 , F-6941 1 Lyon CEDEX 06,
telephone— {33} (4) 72 44 70 00
FAX— [33] (4) 72 44 71 63
established— 1 3 June 1 956
aim— to promote international cooperation
among police authorities in fighting crime
International Development Association (IDA)
address— 1818 H Street NW, Washington, DC
20433, US
telephone— [t] (202) 477 1234
FAX— {1] (202) 477 6391
established— 26 January 1960
effective— 24 September 1960
aim— UN specialized agency and IBRD affiliate
that provides economic loans for low income
countries
International Energy Agency (IEA)
address— 2 Rue Andre Pascal, F-75775 Paris
CEDEX 16, France
fe/ephone— [33] (1)45 24 82 00
FAX— [33] (1)45 24 99 88
established— 1 5 November 1974
aim— to promote cooperation on energy
matters, especially emergency oil sharing and
relations between oil consumers and oil
producers; established by the OECD
members— (177) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
subbureaus— { 14) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Guam,
Hong Kong, Macau, Montserrat, Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands, Virgin Islands
members— { 160)
Part I— (26 developed countries) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany,
Iceland, Ireland, Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South Africa, Spain,
Sweden, Switzerland, UAE, UK, US
Part II— (134 less developed countries) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Azerbaijan,
Bangladesh, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone,
Slovakia, Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia,','71fcf0d7d3c03f143c54c78a838331030577895ca447dedd11c157c76f8d4128','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a349f58908d377a0ecf9dc7f0735913d5160656fb8474862edf7041f2fd7c09',1999,'DE','Germany','transnational-issues',155,'Disputes - international: none
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via Russia,
and to the Baltics and Western Europe
47
0 20 40 km
0 20 40 ml
Disputes - international: none
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for cocaine, heroin, hashish, and marijuana
entering Western Europe
O 50 iOO km
O 50 IOO mi
Disputes ■ international: individual Sudeten
German claims for restitution of property confiscated
in connection with their expulsion after World War II
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for and consumer of Southwest Asian heroin and
hashish, Latin American cocaine, and
European-produced synthetic drugs
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km,
Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters, cool
summers
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in the
north; steep slope down to Moselle floodplain in the
southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Burgplatz 559 m
Natural resources: iron ore (no longer exploited)
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21 %
other: 34%
Irrigated land: 10 sq km (including Belgium (1993
est.)
Natural hazards: NA
Environment - current Issues: air and water
pollution in urban areas
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
290
Luxembourg (continued)
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Environmental Modification, Law of the Sea
Geography - note: landlocked
Disputes ■ international: none
Macau
(Chinese territory under
Portuguese administration)
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 10 N, 1 13 33 E
Map references: Southeast Asia
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area ■ comparative: about 0.1 times the size of
Washington, DC
Land boundaries:
total: 0.34 km
border countries: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm
summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 1 74 m
Natural resources: NEGL
292
Macau (continued)
Land use:
arable land: 0%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1998 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Ozone Layer Protection (extended from
Portugal)
signed, but not ratified: NA
Geography - note: essentially urban; one causeway
and two bridges connect the two islands of Coloane
and Taipa to the peninsula on mainland
Disputes - international: none
Disputes - international: dispute with Greece over
name; in September 1995, Skopje and Athens signed
an interim accord resolving their dispute over symbols
and certain constitutional provisions; Athens also
lifted its economic embargo on The Former Yugoslav
Republic of Macedonia; the border commission
formed by The Former Yugoslav Republic of
Macedonia and Serbia and Montenegro in April 1996
to resolve differences in delineation of their mutual
border has made no progress so far; Albanians in
Macedonia claim discrimination in education, access
to public-sector jobs and representation in
government; Party for Democratic Action (DPA),
which is now a member party of the government, calls
for a rewrite of the constitution to declare ethnic
Albanians a national group and allow for regional
autonomy
Illicit drugs: increasing transshipment point for
Southwest Asian heroin and hashish; minor transit
point for South American cocaine destined for Europe
296
Madagascar m
Location: Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total: 587,040 sq km
land: 581 ,540 sq km
water: 5,500 sq km
Area - comparative: slightly less than twice the size
of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or 1 00 nm from the 2,500-m
deep isobath
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, temperate inland, arid
in south
Terrain: narrow coastal plain, high plateau and
mountains in center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, salt, quartz, tar sands, semiprecious stones,
mica, fish
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 4 1 %
forests and woodland: 40%
other: 14% (1993 est.)
Irrigated land: 10,870 sq km (1993 est.)
Natural hazards: periodic cyclones
Environment - current issues: soil erosion results
from deforestation and overgrazing; desertification;
surface water contaminated with raw sewage and
other organic wastes; several species of flora and
fauna unique to the island are endangered
Environment - international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Marine Life Conservation, Nuclear T est Ban,
Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the
Sea
Geography - note: world''s fourth-largest island;
strategic location along Mozambique Channel
Disputes - international: claims Bassas da India,
Europa Island, Glorioso Islands, Juan de Nova Island,
and Tromelin Island (all administered by France)
Illicit drugs: illicit producer of cannabis (cultivated
and wild varieties) used mostly for domestic
consumption; transshipment point for heroin
Disputes - international: with Bhutan over 91 ,000
Bhutanese refugees in Nepal
Illicit drugs: illicit producer of cannabis for the
domestic and international drug markets; transit point
for opiates from Southeast Asia to the West','7a9fd5533a27f969f0c46ff96c60b40f6235ec31bbfc9ba72c8658f6cfa7b4e4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f0ca54d19cd659e863ad34ac80283149f3e9e431111cbe7f8f6751fa3011e82',1999,'BZ','Belize','transnational-issues',160,'Hf)
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the
Caribbean
Area:
total: 22,960 sq km
land: 22,800 sq km
water: 160 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm in the north, 3 nm in the south;
note - from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3 nm;
according to Belize''s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial
differences with Guatemala
Climate: tropical; very hot and humid; rainy season
(May to February)
Terrain: flat, swampy coastal plain; low mountains in
south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1 , 1 60 m
Natural resources: arable land potential, timber,
fish
Land use:
arable land: 2%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 92%
other: 3% (1993 est.)
50
Belize (continued)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent, devastating hurricanes
(September to December) and coastal flooding
(especially in south)
Environment - current issues: deforestation; water
pollution from sewage, industrial effluents, agricultural
runoff; Hurricane Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertication,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Marine Dumping, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: national capital moved 80 km
inland from Belize City to Belmopan because of
hurricanes; only country in Central America without a
coastline on the North Pacific Ocean
Disputes - international: border with Guatemala in
dispute
Illicit drugs: transshipment point for cocaine;
small-scale illicit producer of cannabis for the
international drug trade; minor money-laundering
center','cdb4ce52696bddf729c2561950f26416d8b2f0046974da51d2c9420f911268ae','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5c30e2de34a592164b7c42b51d40bbd08243b4a77c8e32581f145caf388a01',1999,'BJ','Benin','transnational-issues',174,'Disputes - international: none
Illicit drugs: transshipment point for narcotics
associated with Nigerian trafficking organizations and
most commonly destined for Western Europe and the
US','c97d144a8a4874493cec0fb4b8b6d0ff4e6f8d9ca71a29ee879101aab61c42f5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('034ad854a747cfa1b4c2313e1f736beeb366a275ca4cf499d785e852bd551a21',1999,'BM','Bermuda','transnational-issues',175,'(overseas territory of
the UK)
Location: North America, group of islands in the
North Atlantic Ocean, east of North Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total: 50 sq km
land: 50 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: subtropical; mild, humid; gales, strong
winds common in winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (1997 est.)
note: developed (55%) and rural/open space (39%)
comprise 94% of Bermudian land area
Irrigated land: NA sq km
Natural hazards: hurricanes (June to November)
Environment - current issues: asbestos disposal;
water pollution; preservation of open space
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: consists of about 360 small coral
54
Bermuda (continued)
islands with ample rainfall, but no rivers or freshwater
lakes; some land, reclaimed and otherwise, was
leased by US Government from 1941 to 1995
Disputes - international: none','33b8a878898b04cf562d42d184bc87737baa4cc97fba7fa04d0adeee324df188','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f30782d461a96e717c8a1029fa465c560439f0b58138d021427fa5c4a11915',1999,'BT','Bhutan','transnational-issues',182,'Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area - comparative: about half the size of Indiana
Land boundaries:
total: 1 ,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern plains; cool
winters and hot summers in central valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile
valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower, gypsum,
calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 66%
other: 26% (1993 est.)
Irrigated land: 340 sq km (1993 est.)
Natural hazards: violent storms coming down from
the Himalayas are the source of the country''s name
which translates as Land of the Thunder Dragon;
frequent landslides during the rainy season
Environment - current issues: soil erosion; limited
access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Nuclear Test
Ban
signed, but not ratified: Law of the Sea
Geography - note: landlocked; strategic location
between China and India; controls several key
Himalayan mountain passes
Disputes - international: with Nepal over 91 ,000
Bhutanese refugees in Nepal
Bolivia QHIIJ
Background: Bolivia broke away from Spanish rule
in 1825. Its subsequent history has been marked by a
seemingly endless series of coups, counter-coups,
and abrupt changes in leaders and policies.
Comparatively democratic civilian rule was
established in the 1980s, but the leaders have faced
difficult problems of deep-seated poverty, social
unrest, strikes, and drug dealing. Current issues
include encouraging and negotiating the terms for
foreign investment; strengthening the educational
system; continuing the privatization program;
pursuing judicial reform and an anti-corruption
campaign.','03dcaf27c959a8539a134b1d540f9c193c4f90a2f7ea02e47b2b8fb51fb0cc84','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af385a8d83f77545f4cc905795ffc7719bc6edc276b9ee302ed80a33dcfb90c',1999,'BR','Brazil','transnational-issues',196,'Disputes - international: has wanted a sovereign
corridor to the South Pacific Ocean since the Atacama
area was lost to Chile in 1884; dispute with Chile over
Rio Lauca water rights
Illicit drugs: world''s third-largest cultivator of coca
(after Peru and Colombia) with an estimated 46,900
hectares under cultivation in 1 997, a 2.5% decrease in
overall cultivation of coca from 1996 levels; Bolivia,
however, is the second-largest producer of coca leaf;
even so, farmer abandonment and voluntary and
forced eradication programs resulted in leaf
production dropping from 75,100 metric tons in 1996
to 73,000 tons in 1997, a 3% decrease from 1996;
government considers all but 12,000 hectares illicit;
intermediate coca products and cocaine exported to
or through Colombia, Brazil, Argentina, and Chile to
the US and other international drug markets;
alternative crop program aims to reduce illicit coca
cultivation
60
Bosnia and
Herzegovina
Disputes - international: disputes with Serbia over
Serbian populated areas
Illicit drugs: minor transit point for marijuana and
opiate trafficking routes to Western Europe
63
Disputes - international: quadripoint with Namibia,
Zambia, and Zimbabwe is in disagreement; dispute
with Namibia over uninhabited Kasikili (Sidudu) Island
in Linyanti (Chobe) River is presently at the ICJ; at
least one other island in Linyanti River is contested
65
Location: Southern Africa, island in the South
Atlantic Ocean, south-southwest of the Cape of Good
Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 58 sq km
land: 58 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; maximum elevation about 800 m;
coast is mostly inaccessible
Elevation extremes:
fowesf point: Atlantic Ocean 0 m
highest point: unnamed location 780 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all ice)
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: covered by glacial ice
North
French Atlantic.
il6m
''■‘^SoLufs
Fortaleza* '' N
Belo
’ Horizqnte
Sao /vit6ria
Paulo, -•sj''1 .
Santps "lod.e
Janeiro
South Atlantic
Ocean
300 600 mi
Disputes - international: two short sections of
boundary with Uruguay are in dispute - Arroio
Invernada (Arroyo de la Invernada) area of the Rio
Quarai (Rio Cuareim) and the islands at the
confluence of the Rio Quarai and the Uruguay River
Illicit drugs: limited illicit producer of cannabis,
minor coca cultivation in the Amazon region, mostly
used for domestic consumption; government has a
large-scale eradication program to control cannabis;
important transshipment country for Bolivian,
Colombian, and Peruvian cocaine headed for the US
and Europe; increasingly used by traffickers as a way
station for narcotics air transshipments between Peru
and Colombia
British Indian
Ocean Territory
(overseas territory
of the UK)
Peros ( ''”''1
Banhos) . .
Salomon Islands
Chagos
Archipelago
, Nelsons
Island
• .Three Brothers
Danger 4
Island
'' Eagle Islands
Indian
- Egmonl Islands
Ocean
O 25 50 km
Zie9°
Garcia
6 25
50 mi','15065569770ba76d3a86a561f8ea0673f7df84bd6c9755bec1c9e93d917723ac','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8c59bb7c5663b5c325cea743c138f212ef9dae6b6687a8b7ba7dc59d59718ec',1999,'NO','Norway','transnational-issues',198,'Disputes - international: none
Disputes ■ international: none
246
Disputes - international: islands of Etorofu,
Kunashiri, Shikotan, and the Habomai group occupied
by the Soviet Union in 1945, now administered by
Russia, claimed by Japan; Liancourt Rocks
(Takeshima/Tokdo) disputed with South Korea;
Senkaku-shoto (Senkaku Islands) claimed by China
and Taiwan
Jarvis island
(territory of the US)
0 0.5 1 km
O 0,5 lmi
South Pacific Ocean
Disputes - international: territorial claim in
Antarctica (Queen Maud Land); Svalbard is the focus
of a maritime boundary dispute in the Barents Sea
between Norway and Russia
Illicit drugs: minor transshipment point for drugs
shipped via the CIS and Baltic states for the European
market; increasing domestic consumption of cannabis
and amphetamines
368
Oman (continued)
Environment - current issues: rising soil salinity;
beach pollution from oil spills; very limited natural
fresh water resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location with small
foothold on Musandam Peninsula adjacent to Strait of
Hormuz, a vital transit point for world crude oil
Disputes - international: southern boundary with
the United Arab Emirates has not been bilaterally
defined; northern section in the Musandam Peninsula
is an administrative boundary
Pacific Ocean
Disputes - international: some maritime disputes
(see littoral states)
Disputes - international: status of Kashmir with
India; water-sharing problems with India over the
Indus River (Wular Barrage)
Illicit drugs: producer of illicit opium and hashish for
373
Pakistan (continued)
the international drug trade (poppy cultivation in 1998
- 3,030 hectares, a 26% drop from 1997 because of
eradication and alternative development); limited
center for processing Afghan heroin; key transit area
for Southwest Asian heroin moving to Western
markets; narcotics still move from Afghanistan into
Baluchistan Province','7429e754e4a9647179e6ca5bc2c36284b275caf32711702e1844ad11237895af','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a84c6b5493fe07b1fea53757605dabb312ec063e4c5d4a94c8059a5e6bed6d01',1999,'IO','British Indian Ocean Territory','transnational-issues',209,'Disputes - international: the Chagos Archipelago is
claimed by Mauritius and Seychelles
British Virgin
Islands
(overseas territory
of the UK)
O 5 10 km
O 5 10 mi
t . ( ,
Anegada
A ‘.‘/i/lfiC
Virgin
Jost Van
Gorda
Tortola
■ >
^ * ROAD
- - TOWN
■fro W-Q j ■
Virgin Islands
(US.)
S :•.}
Disputes - international: none
71
Brune*
Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
wafer: 500 sq km
Area - comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
exclusive economic zone: 200 nm or to median line
territorial sea: 12 nm
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east;
hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 85%
other: 12% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: typhoons, earthquakes, and
severe flooding are very rare
Environment - current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment - international agreements:
party to: Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution
signed , but not ratified: none of the selected
agreements
Geography - note: close to vital sea lanes through
South China Sea linking Indian and Pacific Oceans;
two parts physically separated by Malaysia; almost an
enclave of Malaysia
Disputes - international: possibly involved in a
complex dispute over the Spratly Islands with China,
Malaysia, Philippines, Taiwan, and Vietnam; in 1984,
Brunei established an exclusive fishing zone that
encompasses Louisa Reef in the southern Spratly
Islands, but has not publicly claimed the island
73
Disputes - international: twenty bilateral
agreements remain unsigned in a dispute over
Bulgarian nonrecognition of Macedonian as a
language distinct from Bulgarian
Illicit drugs: major European transshipment point for
Southwest Asian heroin and, to a lesser degree,
South American cocaine for the European market;
limited producer of precursor chemicals; significant
producer of amphetamines, much of which are
consumed in the Middle East','3de25a85cf34609e0eef2fdc2c5a1b9939d154b8ac9ddaeda3dc685f661c76c1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69f0b5396b1d83caa420895a176341e356121b8b9819b015edbe6447eac0b6cb',1999,'NG','Nigeria','transnational-issues',220,'Disputes - international: none
Burma
Disputes - international: sporadic conflict with
Thailand over alignment of border
Illicit drugs: world''s largest producer of illicit opium
(cultivation in 1998 - 130,300 hectares, a 16% decline
from 1997; potential production - 1 ,750 metric tons,
down 26% due to drought and the first eradication
effort since the current government took power in
1987) and a minor producer of cannabis for the
international drug trade; surrender of drug warlord
KHUN SA''s Mong Tai Army in January 1996 was
hailed by Rangoon as a major counternarcotics
success, but lack of serious government commitment
and resources continues to hinder the overall antidrug
effort; growing role in the production of
methamphetamines for regional consumption
Disputes - international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria; dispute with Cameroon over
land and maritime boundaries around the Bakasi
Peninsula is currently before the International Court of
Justice; maritime boundary dispute with Equatorial
Guinea because of disputed jurisdiction over oil-rich
areas in the Gulf of Guinea
Illicit drugs: facilitates movement of heroin en route
from Southeast and Southwest Asia to Western
Europe and North America; increasingly a transit
route for cocaine from South America intended for
European, East Asian, and North American markets','61aef897e3a286a128c156b3077ee9a6126c60cdd7fc07a6e6fa322e53edc6b6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6227098d2f8678134584309ea7e59c79cbd41efc6f9692dbee9c5a325278931',1999,'BI','Burundi','transnational-issues',224,'Background: Since the end of the Belgian
trusteeship in 1962, Burundi has suffered from ethnic
uprisings, coups, and other societal dislocations. In a
series of waves since October 1993, hundreds of
thousands of refugees have fled the ethnic violence
between the Hutu and Tutsi factions in Burundi and
have crossed into Rwanda, Tanzania, and Zaire (now
called the Democratic Republic of the Congo or
DROC). Since October 1996, an estimated 120,000
Burundian Hutu refugees from the DROC have been
compelled to return to Burundi because of insecurity in
the region. Continuing ethnic violence with the Tutsi
has caused additional Hutu to flee to Tanzania, thus
raising their numbers in the United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps in that country to about 260,000. Burundian
troops have joined armies from Rwanda and Uganda
and Congolese Tutsi in trying to overthrow DROC
President KABILA and restore security to their
borders with the Democratic Republic of the Congo.
Disputes - international: none
Disputes - international: offshore islands and
sections of the boundary with Vietnam are in dispute;
maritime boundary with Vietnam not defined; parts of
border with Thailand are indefinite; maritime boundary
with Thailand not clearly defined
Illicit drugs: transshipment site for Golden T riangle
heroin; possible money laundering; narcotics-related
corruption reportedly involving some in the
government, military, and police; possible small-scale
opium, heroin, and amphetamine production; large
producer of cannabis for the international market
84
Disputes - international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria; dispute with Nigeria over
land and maritime boundaries around the Bakasi
Peninsula and Lake Chad is currently before the
International Court of Justice
86','f1e858b1edb2f213289573844869401f911b399528ee191be664faffa87e604b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b67526b8da40d0b1b8e79d5dff3a60b77b654c50510f7f7124bcffa6a65231',1999,'CA','Canada','transnational-issues',239,'Disputes - international: maritime boundary
disputes with the US (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island)
Illicit drugs: illicit producer of cannabis for the
domestic drug market; use of hydroponics technology
permits growers to plant large quantities of
high-quality marijuana indoors; growing role as a
transit point for heroin and cocaine entering the US
market
Disputes - international: territorial disputes with
Colombia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank; with respect to
the maritime boundary question in the Golfo de
Fonseca, the International Court of Justice (ICJ)
referred the disputants to an earlier agreement in this
century and advised that some tripartite resolution
among El Salvador, Honduras, and Nicaragua likely
would be required; maritime boundary dispute with','403c10a2a5d81ba22fc4cf5a12efc3f3d7e7b04b8074dceaffe6c262088859f3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6b50c8fe1f3291f9ddfa0b83ae8408eac92f4f79112dff4ae7905e7a4bd6901',1999,'KY','Cayman Islands','transnational-issues',247,'Disputes - international: none
Illicit drugs: used as a transshipment point for illicit
drugs moving from Latin America and Africa destined
for Western Europe
Location: Caribbean, island group in Caribbean
Sea, nearly one-half of the way from Cuba to','ad9bc87b9b696aba4e5f7daf5f296f25fcc465494e499f3ba378eab9659a0ff4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d8b94fffdead6bc0157255b3a2d4fc63696433430422c5abc9b5dcdcd978ba',1999,'HN','Honduras','transnational-issues',248,'Geographic coordinates: 1 9 30 N, 80 30 W
Map references: Central America and the
Caribbean
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; warm, rainy summers (May
to October) and cool, relatively dry winters (November
to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 23%
other: 69% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes (July to November)
Environment - current issues: no natural fresh
water resources; drinking water supplies must be met
by rainwater catchment
91
Cayman Islands (continued)
Environment - international agreements:
parly to: NA
signed, but not ratified: NA
Geography - note: important location between
Cuba and Central America
Disputes - international: none
Illicit drugs: vulnerable to drug money laundering
and drug transshipment
Central African
Republic
Background: In 1996, the country experienced three
mutinies by dissident elements of the armed forces,
which demanded back pay as well as political and
military reforms. Subsequent violence between the
government and rebel military groups over pay issues,
living conditions, and lack of opposition party
representation in the government, destroyed many
businesses in the capital, reduced tax revenues, and
exacerbated the government''s problems in meeting
expenses. African peacekeepers restored order in
1997; in April 1998 the United Nations Mission in the
Central African Republic (MINURCA) assumed
responsibility for peacekeeping operations.
Disputes - international: none
Background: In 1960, Chad gained full
independence from France, In December 1990, after
Chad had endured three decades of ethnic warfare as
well as invasions by Libya, former northern guerrilla
leader Idriss DEBY seized control of the government.
His transitional government eventually suppressed or
came to terms with most political-military groups,
settled the territorial dispute with Libya on terms
favorable to Chad, drafted a democratic constitution
which was ratified by popular referendum in 1996,
held multiparty national presidential elections in 1996
(DEBY won with 69% of the vote), and held multiparty
elections for the National Assembly in 1 997 (DEBY''s
Patriotic Salvation Movement won a majority of the
seats). But by the end of 1998, DEBY was beset with
numerous problems including heavy casualties in the
Democratic Republic of the Congo where Chadian
troops had been deployed to support embattled
President KABILA, a new rebellion in northern Chad,
and further delays in the Doba Basin oil project in the
south.
Disputes ■ international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria
Caribbean Sea
Islas de la Bahfa
Swan
Islands
_ . Puerto Castilla
Puerto Cort6s — ~-''~
. Tela La Ceiba
San .
Pedro San Lorenzo
Sula
#Juticalpa
TEGUCIGALPA,
Choluteca
Lago d$
» ( \\Nicaragua
\\v\\
Disputes - international: demarcation of boundary
with El Salvador defined by 1992 International Court
of Justice (ICJ) decision has not been completed;
small boundary section left unresolved by ICJ
decision not yet reported to have been settled; with
respect to the maritime boundary in the Golfo de
Fonseca, ICJ referred to an earlier agreement in this
century and advised that some tripartite resolution
among El Salvador, Honduras, and Nicaragua likely
would be required; maritime boundary dispute with
Illicit drugs: transshipment point for cocaine
destined for the US','33781c16e07628a863a9d3d0a9261c1c36a448b425741ae8ae135f1161f5a140','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5fadfb8de604a91148b4092162426386bc67fa26cb822d7c7e0ec2190f32adb',1999,'CL','Chile','transnational-issues',256,'South
Pacific
Ocean
Isla San
Ambrosio
Isla
San Fblix
Disputes - international: short section of the
southwestern boundary with Argentina is indefinite -
process to resolve boundary issues is underway;
Bolivia has wanted a sovereign corridor to the South
Pacific Ocean since the Atacama area was lost to
Chile in 1884; dispute with Bolivia over Rio Lauca
water rights; territorial claim in Antarctica (Chilean
Antarctic Territory) partially overlaps Argentine and
99
Chile (continued)
British claims
Illicit drugs: a growing transshipment country for
cocaine destined for the US and Europe; economic
prosperity has made Chile more attractive to
traffickers seeking to launder drug profits; imported
precursors pass on to Bolivia
telephone— {56] (2) 2102000
FAX— [56] (2) 2080252, 2081946
established— 25 February 1948 as Economic
Commission for Latin America (ECLA)
aim— to promote economic development as
a regional commission of the UN''s Economic
and Social Council
members— (41 ) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba, Dominica, Dominican Republic, Ecuador, El Salvador, France, Grenada, Guatemala,
Guyana, Haiti, Honduras, Italy, Jamaica, Mexico, Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Spain, Suriname, Trinidad and Tobago, UK,
US, Uruguay, Venezuela
associate members— (7) Anguilla, Aruba, British Virgin Islands, Montserrat, Netherlands Antilles, Puerto Rico,
Virgin Islands
Economic Commission for Western Asia
(ECWA)
see Economic and Social Commission for Western Asia (ESCWA)
Economic Community of Central African
States (CEEAC)
members— { 1 1 ) Angola, Burundi, Cameroon, Central African Republic, Chad, Democratic Republic of the Congo,
Republic of the Congo, Equatorial Guinea, Gabon, Rwanda, Sao Tome and Principe
note— acronym from Communaute Economique
des Etats de I''Afrique Centrale
address— CEEAC, BP 2112, Libreville, Gabon
fe/ep/rone— [241] 73 35 47, 73 35 48, 73 36 77
established— 18 October 1983
aim— to promote regional economic cooperation
and establish a Central African Common Market
Economic Community of the Great Lakes
Countries (CEPGL)
members— (3) Burundi, Democratic Republic of the Congo, Rwanda
note— acronym from Communaute Economique
des Pays des Grands Lacs
address— IRAZ-CEPGL, BP 91, Gitega, Burundi
established— 26 September 1976
aim— to promote regional economic cooperation
and integration
Economic Community of West African States
(ECOWAS)
members— (16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau,
Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone, Togo
address— 6 King George V Road, PMB 12745,
Lagos, Nigeria
telephone— {234] (1) 636839, 636841 , 636064,
630398
FAX— {234] (1) 636822
established— 28 May 1975
aim— to promote regional economic cooperation
564
Appendix C: International Organizations and Groups (continued)
Economic Cooperation Organization (ECO)
address— No. 1 Goulbou Alley, Kamraniyeh,
P.O. Box 14155-6176, Teheran, Iran Islamic
Republic
telephone— {%] (21) 2831731 , 2831733
FAX— (98] (21) 2831732
established— NA 1985
aim— to promote regional cooperation in trade,
transportation, communications, tourism,
cultural affairs, and economic development
members— {t0) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan,','6fab4de838c4d0439e1b788a6e88620e2225919dea5f78863369489e2cfd538d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60087e98a9375469510a88fc33fec587bb9670d2273996dda4638ab78744e2f5',1999,'CN','China','transnational-issues',264,'(also see separate Hong Kong and Taiwan entries)
Disputes - international: none
■Taiwan
i
''\\
\\ /
V
O 100 200 km
6 100 200 mi
Aparri
Luzon
.Baguio
San Fernando, _
-Quezon
MANILA®
Batangas.
Mindoro
.Ugaspi
Samar
Panay
Palawan
Iloilo. Bacolod ~~i^0
„ . . Cebu . ^
Gutmaras '' *
_ . Island l" /
Puerto
Princesa Negros
Cagayan de Oro. Butuan
lligan*
Mindanao
f''r
Zamboanga,
Davao,
“''xlr''-,
Sea
Fiery Cross
Reef »
Southwest Cay-\\*
West York
• Jsland
■ Thltu Island Flat
* Jsland
. <~Lankiam Cay \\
\\.Loaita Island , A
Itu Aba Island ^ '' ,''Eldad Reef fjanshan
Loaita Nan s
Sand CayN
J .
Sin Co we"
Island
- Namyit
Island
’-JX''* Mischief °
Island
'' Spratly
Island
Amboyna *
Cay
Alison^ n
Reef
Pigeon Reef
Half ^
Moon *
Shoal
.
\\
-r* S
0 50 100 km
6 50
lOO mi','5a4942f4d90774644c2b612e97a4576dd020cc22393db0ec1c38b72ec5cbdb99','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eabfda7da6767b9bdcbb6e35ed2c7e6a1c0e9e2b0f72099cba40ee19bc144712',1999,'HK','Hong Kong','transnational-issues',274,'Disputes - international: boundary with India in
dispute; dispute over at least two small sections of the
boundary with Russia remain to be settled, despite
1 997 boundary agreement; most of the boundary with
Tajikistan in dispute; 33-km section of boundary with
North Korea in the Paektu-san (mountain) area is
indefinite; involved in a complex dispute over the
Spratly Islands with Malaysia, Philippines, Taiwan,
Vietnam, and possibly Brunei; maritime boundary
dispute with Vietnam in the Gulf of Tonkin; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does Taiwan; sections of land border with Vietnam are
indefinite
Illicit drugs: major transshipment point for heroin
produced in the Golden Triangle; growing domestic
drug abuse problem','cf9e3ac8755318c82ea3899ef00f0b49960aff318fd76bed0f499b6a48fdd0bc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8e2e958272ff37c3366069462b3ae193bcc031e625ad86612985210a2700c30',1999,'CX','Christmas Island','transnational-issues',275,'(territory of Australia)
Location: Southeastern Asia, island in the Indian
Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
total: 135 sq km
land: 135 sq km
water: 0 sq km
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims:
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; heat and humidity moderated by
trade winds
Terrain: steep cliffs along coast rise abruptly to
central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: located along major sea lanes of
Indian Ocean','e312a422e510080a479b7c69f6de08087ebca8b40d7fa0b4589fc2506bcdfe34','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7a7997c3a97998d1b827e57b496d2267c767ac2199f39452619c8ae47e8f20f',1999,'CO','Colombia','transnational-issues',291,'Background: Colombia gained its independence
from Spain in 1 81 9. Earlier than most countries in the
area, it established traditions of civilian government
with regular, free elections. In recent years, however,
assassinations, widespread guerrilla activities, and
drug trafficking have severely disrupted normal public
and private activities.
Disputes - international: maritime boundary
dispute with Venezuela in the Gulf of Venezuela;
territorial disputes with Nicaragua over Archipelago de
San Andres y Providencia and Quita Sueno Bank
Illicit drugs: illicit producer of coca, opium poppies,
and cannabis; cultivation of coca in 1997 - 79,500
hectares, an 18% increase over 1996; potential
production of cocaine in 1997 - 125 metric tons, a 14%
increase over 1996; cultivation of opium in 1997 -
6,600 hectares, a 5% increase over 1996; potential
production of opium in 1997 - 66 metric tons, a 5%
increase over 1996; the world''s largest processor of
coca derivatives into cocaine; supplier of cocaine to
the US and other international drug markets; active
aerial eradication program seeks to virtually eliminate
coca and opium crops
108
aim— to provide a forum for largest debtor
nations in Latin America
members— (11) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay,
Venezuela
Group of 15 (G-1 5)
nofe— byproduct of the Nonaligned Movement
address— Technical Support Facility, Ch du
Champ d’Ancier 17, Case Postale 326, CH-121 1
Geneva 19, Switzerland
telephone— (41] (22) 798 42 10
FAX— [41] (22) 798 38 49
established— September 1989
aim— to promote economic cooperation among
developing nations; to act as the main political
organ for the Nonaligned Movement
members— (15) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia, Mexico, Nigeria, Peru,
Senegal, Venezuela, former Yugoslavia, Zimbabwe
569
Appendix C: International Organizations and Groups (continued)
Group of 19 (G-1 9)
established— HA October 1975
aim— to represent the interests of the less
developed countries (LDCs) that participated in
the Conference on International Economic
Cooperation (CIEC) held in several sessions
between NA December 1975 and 3 June 1977
members— (19) Algeria, Argentina, Brazil, Cameroon, Democratic Republic of the Congo, Egypt, India, Indonesia,
Iran, Iraq, Jamaica, Mexico, Nigeria, Pakistan, Peru, Saudi Arabia, Venezuela, Yugoslavia, Zambia
Group of 24 (G-24)
address— do European Commission, DGIA -
G-24 Coordination Unit, Rue de la Loi 200,
B-1049 Brussels, Belgium
telephone— {32] (2) 299 22 44
FAX— {32] (2) 299 06 02
established— HA January 1972
aim— to promote the interests of developing
countries in Africa, Asia, and Latin America
within the IMF
members— (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Egypt,
Ethiopia, Gabon, Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri Lanka,
Syria, Trinidad and Tobago, Venezuela, Yugoslavia
Group of 30 (G-30)
address— 1990 M Street NW, Suite 450,
Washington, DC 20036, US
telephone— {1] (202) 331 2472
FAX— [1] (202) 785 9423
established— NA 1979
aim— to discuss and propose solutions to the
world''s economic problems
members— (30) informal group of 30 leading international bankers, economists, financial experts, and business
leaders organized by Johannes Witteveen (former managing director of the IMF)
Group of 33 (G-33)
members— (33) leading economists from 13 countries
established-NA 1987
aim— to promote solutions to international
economic problems
Group of 77 (G-77)
address— Office of the Chairman, United
Nations, Room S-3959, P.O. Box 20, New York,
NY 10017, US
telephone— {1] (212) 963 3816, 963 0192, 963
4777
FAX— [1] (212) 963 3515, 963 1753
established— NA October 1967
aim— to promote economic cooperation among
developing countries; name persists in spite of
increased membership
members— (131 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine
Liberation Organization
570
Appendix C: International Organizations and Groups (continued)
Gulf Cooperation Council (GCC)
members— { 6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
note— also known as the Cooperation Council
tor the Arab States of the Gulf
address— P.O. Box 7153, Riyadh 11462, Saudi
Arabia
telephone— [966] (1) 482 7777, extension 1238
FAX— [966] (1) 482 9109
established— 25 May 1981
aim— to promote regional cooperation in
economic, social, political, and military affairs
Hexagonal Group
see Central European Initiative (CEI)
high-income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC)
members— (5) Comoros, France (for Reunion), Madagascar, Mauritius, Seychelles
address— Q4 Avenue Sir Guy Forget, BP7,
Quatre Bornes, Mauritius
telephone— {230] 425 9564, 425 1652
FAX— [230] 425 1 209
established— 17 July 1982
aim— to organize and promote regional
cooperation in all sectors, especially economic
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB)
note— also known as Banco Interamericano
de Desarrollo (BID)
address— 1300 New York Avenue NW,
Washington, DC 20577, US
telephone— {!] (202) 623 1000
FAX— [1] (202) 623 3096
established— 8 April 1959
effective— 30 December 1959
aim— to promote economic and social
development in Latin America
members— { 46) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, Mexico, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK,
US, Uruguay, Venezuela
Inter-Governmental Authority on
Drought and Development (IGADD)
see Inter-Governmental Authority on Development (IGAD)
Inter-Governmental Authority on
Development (IGAD)
members— { 7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan, Uganda
note— formerly known as Inter-Governmental
Authority on Drought and Development (IGADD)
address— P. O. Box 2653, Djibouti, Djibouti
telephone— [253] 354050
FAX— [253] 356994, 356284
established— 1 5-1 6 January 1 986 as the
Inter-Governmental Authority on Drought and
Development
revitalized— 21 March 1996 as the Inter-
Governmental Authority on Development
aim— to promote a social, economic, and
scientific community among its members
571
Appendix C: International Organizations and Groups (continued)
International Atomic Energy Agency (IAEA)
address— Wagramerstrasse 5, P.O. Box 100,
A-1400 Vienna, Austria
telephone— [43] (1) 20600
FAX— {43] (1) 20607
established— 26 October 1956
effective— 29 July 1957
aim— to promote peaceful uses of atomic energy
members— { 127) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belarus,
Belgium, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burma, Cambodia, Cameroon, Canada, Chile, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finland, France, Gabon, Georgia,
Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malaysia, Mali,
Malta, Marshall Islands, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
International Bank for Economic
Cooperation (IBEC)
was established on 22 October 1963 to promote economic cooperation and development; members were Bulgaria,
Cuba, Czechoslovakia, GDR, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian bank with
a new charter
International Bank for Reconstruction and
Development (IBRD)
note— also known as the World Bank
address— 1818 H Street NW, Washington, DC
20433, US
telephone— {t] (202) 477 1234
FAX— [1] (202) 477 6391
established— 22 July 1944
effective— 27 December 1945
aim— to provide economic development loans; a
UN specialized agency
members— { 181) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Chamber of Commerce (ICC)
address— 38 Cours Albert 1st, F-75008 Paris,','7c10eb8e35591edce5f1f915c61d65a28373f2c775dda88eed9bd6ba3afa80bd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98362d605b000ebe696fa4e572baf1ad58bd9a4b31540636e1d1fd8ab6309833',1999,'CG','Congo','transnational-issues',306,'Disputes - international: the Democratic Republic
of the Congo is in the grip of a civil war that has drawn
in military forces from neighboring states, with
Uganda and Rwanda supporting the rebel movement
which occupies much of the eastern portion of the
state; most of the Congo River boundary with the
Republic of the Congo is indefinite (no agreement has
been reached on the division of the river or its islands,
except in the Pool Malebo/Stanley Pool area)
Illicit drugs: illicit producer of cannabis, mostly for
domestic consumption
Congo, Republic of the
Disputes - international: most of the Congo River
boundary with the Democratic Republic of the Congo
is indefinite (no agreement has been reached on the
division of the river or its islands, except in the Stanley
Pool/Pool Malebo area)','2c850e550af667d2ebc96e06905bf678392a0fdf44ad996c4481fb46598ef443','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80d2a077a44f91b753312e6d651c9e98ce59f038c1b0c1c40c428455a0362a32',1999,'CK','Cook Islands','transnational-issues',309,'(self-governing in free
association with
New Zealand)
Rakahanga . Penrhyn
Pukapuka _
Manihiki
'' Nassau
Island
Suwarrow
South Pacific Ocean
Palmerston
Aitutaki ,
Manuae
Takutea ., . Mitiaro
Atlu Mauke
O 150 300 km
O 150 300 mi
AVARUA
Rarotonga
° Mangaia
Disputes - international: none
Coral Sea Islands
(territory of Australia)
^ Osprey Reef
^ Shark Reef
O 200
/ f Bougainville
\\\\ ''Reef% Willis Islets
t Holmes Reefs $ ij^Magdelaine Cays
< e Flora Reef * ^^-Coringa Islets
\\ C Jerald Cays-^b •• Tregrosse Islets
) Flinders / ■***■•“■.
/ % <S> ■SRes'' & Lihou
V-. Treorosse Reefs
/ > C''Q, Abington Reefs
Vfc * RCOf
-C. '' **2?sA
Marion
O Rccf
Coral
Sea
Disputes - international: none','af1ea5e9d4cf3b6796f4da11d87b2def7c4c6c5ed092777dc480972d7da80f92','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c4217fc28a196c26ea84a560fab9ee55b616e6101c3ee5e2a34993f0b8177bb',1999,'CR','Costa Rica','transnational-issues',325,'Disputes - international: none
Illicit drugs: transshipment country for cocaine and
heroin from South America; illicit production of
cannabis on small, scattered plots','3dd23614b52f73c4487fb39bb3110e9c31f04d7470fc6113a756792abf5576eb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80b33b17373cabc3b1bfcfc4a6e7b910e0f8c7a1fde9c40e0845cedff6979ecb',1999,'SI','Slovenia','transnational-issues',334,'Disputes - international: Eastern Slavonia, which
was held by ethnic Serbs during the ethnic conflict,
was returned to Croatian control by the UN
T ransitional Administration for Eastern Slavonia on 1 5
January 1998; Croatia and Italy made progress
toward resolving a bilateral issue dating from World
War II over property and ethnic minority rights;
significant progress has been made with Slovenia
toward resolving a maritime border dispute over direct
access to the sea in the Adriatic; Serbia and
Montenegro is disputing Croatia''s claim to the
Prevlaka Peninsula in southern Croatia because it
124
Croatia (continued)
controls the entrance to Boka Kotorska in
Montenegro; Prevlaka is currently under observation
by the UN military observer mission in Prevlaka
(UNMOP)
Illicit drugs: transit point along the Balkan route tor
Southwest Asian heroin to Western Europe; a minor
transit point for maritime shipments of South
American cocaine bound for Western Europe','07253672a7aed6fbc4e3f4917c4f8cba2c504cbbd35fd7f641fba4f30de5d234','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a49aff4ff0d190960e4ae484d34bfd1a72a9d131cff49d7ffbc33beaa87568a6',1999,'CU','Cuba','transnational-issues',343,'Disputes - international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territory serves as transshipment zone
for cocaine bound for the US and Europe
127','3b7db2c885467c8bb1b2681559b27bef950d7b61000ec4c415dbf04dc81c5056','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd4126087217ba9c5e0ae377ab873b2ba1c5a4a5bdb65c97483773f5bb58c32',1999,'CY','Cyprus','transnational-issues',351,'Disputes - international: 1 974 hostilities divided the
island into two de facto autonomous areas, a Greek
Cypriot area controlled by the internationally
recognized Cypriot Government (59% of the island''s
land area) and a T urkish-Cypriot area (37% of the
island), that are separated by a UN buffer zone (4% of
the island); there are two UK sovereign base areas
within the Greek Cypriot portion of the island
Illicit drugs: transit point for heroin and hashish via
air routes and container traffic to Europe, especially
from Lebanon and Turkey; some cocaine transits as
well
130
Czech Republic','967c6b2ee46d850ab7cc84d2eac8bd2d2afb42620d03d6e60396ddc3bb4627a9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914c276a326baca8a32f2c649635e63b813a43cab2001bc38821b4994a547a00',1999,'PL','Poland','transnational-issues',352,'D£cin?\\ALjberec
S'' "Usti nad
Labem < ^ .
\\ PRAGUE®
Hradec^
\\ Vlzert
Kralove Ostrava*!
Olomouc •
CSske
-ftVl a /
* Brn°^_r
j — XV Budejovice
GERMANY^JX.
Danube ( SLOVAKIA
A U S T R
P HUNGARY ]
574
Appendix C: International Organizations and Groups (continued)
International Federation of Red Cross and
Red Crescent Societies (IFRCS)
note— formerly known as League of Red Cross
and Red Crescent Societies (LORCS)
address— Chemin des Crets 17, CP 372,
Petit-Saconnex, CH-1211 Geneva 19,','1ca9978d42c57d8d78332562733b04aa8a1b4c596067478c23c0d9e31ad90600','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5199f52db1790664a89316b1235be98b6dc7906afd246a70230ff00f32e29e31',1999,'DK','Denmark','transnational-issues',362,'Disputes - international; Liechtenstein claims
restitution for 1 ,600 sq km of property in the Czech
Republic confiscated from its royal family in 1918; the
Background: Once the seat of rapacious Viking
raiders and later a major power in northwestern
Europe, Denmark has evolved into a modern,
prosperous nation that is participating in the political
and economic integration of Europe. So far, however,
they have opted out of some aspects of the European
Union''s Maastricht T reaty including the new monetary
system launched on 1 January 1999.
Disputes - international: Rockall continental shelf
dispute involving Iceland, Ireland, and the UK (Ireland
and the UK have signed a boundary agreement in the
Rockall area)
135
Disputes - international: none
137
Disputes - international: none','54ec541b319b96b6e463bfbc3868ae0fdf66271cc87d03810c55ead69c656fe1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d967fade23aa3a19f22865a2c2f82f37d5fdb1e60ba8dd43274ab21e0669800',1999,'DO','Dominican Republic','transnational-issues',374,'Disputes - international: none
Illicit drugs: transshipment point for narcotics bound
for the US and Europe; minor cannabis producer;
banking industry is vulnerable to money laundering
Location: Caribbean, eastern two-thirds of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, east of Haiti
Geographic coordinates: 1 9 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area:
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area - comparative: slightly more than twice the
size of New Hampshire
Land boundaries:
total: 275 km
border countries: Haiti 275 km
Coastline: 1 ,288 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile
valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 43%
forests and woodland: 12%
other: 15% (1993 est.)
Irrigated land: 2,300 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
139
Dominican Republic (continued)
October; occasional flooding; periodic droughts
Environment - current issues: water shortages:
soil eroding into the sea damages coral reefs;
deforestation; Hurricane Georges damage
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: shares island of Hispaniola with
Haiti (eastern two-thirds is the Dominican Republic,
western one-third is Haiti)
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US
141
Disputes - international: none','c4e032500533cc893f247ee714273842e0b4635bec6a0339fb5cb09ec8ce866c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eac414fb3680520cdbcc1d07b935719a0d3c2ba30387838235aeef8ae116b11f',1999,'PE','Peru','transnational-issues',386,'Disputes - international: on 26 October 1 998, Peru
143
Ecuador (continued)
and Ecuador concluded treaties on commerce and
navigation and on boundary integration, to complete a
package of agreements settling the long-standing
boundary dispute between them; demarcation of the
agreed-upon boundary was scheduled to begin in
mid-January 1999
Illicit drugs: significant transit country for derivatives
of coca originating in Colombia, Bolivia, and Peru;
importer of precursor chemicals used in production of
illicit narcotics; important money-laundering hub','d389252c47259d855ac87d467fac3c1d85d0081bf77778064c5032679830de37','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6e72be404c6970a84801b601076698b1f91c8ecdaa42cd083766228da91ee1e',1999,'EG','Egypt','transnational-issues',395,'Disputes - international: Egypt asserts its claim to
the "Hala''ib Triangle," a barren area of 20,580 sq km
under partial Sudanese administration that is defined
by an administrative boundary which supersedes the
treaty boundary of 1899
Illicit drugs: a transit point for Southwest Asian and
Southeast Asian heroin and opium moving to Europe
and the US; popular transit stop for Nigerian couriers
146','a5fa7b5054c076c06337221782ca3adcf7cb9114d5d46a8d2906eac80ffb75b9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3928f885d264c7f6b10e72dd2cd2b1b2946abf7190474707bafc706a3ff2fde3',1999,'GN','Guinea','transnational-issues',401,'Disputes - international: maritime boundary
dispute with Gabon because of disputed sovereignty
over islands in Corisco Bay; maritime boundary
dispute with Nigeria because of disputed jurisdiction
over oil-rich areas in the Gulf of Guinea
Disputes ■ international: dispute over alignment of
boundary with Ethiopia led to armed conflict in 1998,
which is still unresolved despite arbitration efforts;
Hanish Islands dispute with Yemen resolved by
arbitral tribunal in October 1998
Gitif 0:
JDarijy Pjpu:
is £ \\ ''(: ''■ 1
¥i
AUSTRALIA;
South
New Pacific
^J/eland Ocean
Bismark *
Rabaul#^\\ *
New Britain^ j O '' 0 0
0s fV V.Kieta
“) Bougainville Q *.
Lae \\ Solomon jC"
PORT . Sea SOLOMON “''X
MORESBY ‘ ... islands
L_,4s - ■ • ''
...
^r:-
Cora I Sea.','e0934ff26a73f43dbde10847957a99d4b1c9e1931acca3a8a1b74b3172e9db4b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dfb5949fbc449a5ffa0cc951d757735593f5dadc059ac213292851f6c009e94',1999,'EE','Estonia','transnational-issues',405,'Background: In and out of Swedish and Russian
control over the centuries, this little Baltic state was
re-incorporated into the USSR after German
occupation in World War II. Independence came with
the collapse of the USSR in 1991 ; the last Russian
troops left in 1994. Estonia thus became free to
promote economic and political ties with Western
Europe. The position of ethnic Russians (29% of the
population) remains an issue of concern to Moscow.
European Union (EU) membership negotiations,
which began in 1998, remain a domestic issue.
Disputes - international: Estonian and Russian
negotiators reached a technical border agreement in
December 1996 which has not been ratified
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and the Caucasus via
Russia, and cocaine from Latin America to Western
Europe and Scandinavia; possible precursor
manufacturing and/or trafficking
155','41b91ef56a1e8a84bbbd7678a4b9d2e1159a544f45eb37b6d2f7da1110bc1ff0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b21111104cea0b7afaad27282434bcbe678d44532dc211d8ae5b295f2e0af9',1999,'DJ','Djibouti','transnational-issues',421,'Disputes - international: most of the southern half
of the boundary with Somalia is a Provisional
Administrative Line; territorial dispute with Somalia
over the Ogaden; dispute over alignment of boundary
with Eritrea led to armed conflict in 1998, which is still
unresolved despite arbitration efforts
Illicit drugs: transit hub for heroin originating in
Southwest and Southeast Asia and destined for
Europe and North America as well as cocaine
destined for markets in southern Africa; cultivates qat
(chat) for local use and regional export
Europa Island V ■
(possession of France) wll','4bd7bd63c4ac07adf59a8c3b443a0bedc43df602ea565c5f0ec7c8338ed7817c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6830b65922217012bd66dd8548a275446cd64f9c108d2c7f263ede1d957b2a5',1999,'JE','Jersey','transnational-issues',441,'Disputes -international: none
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Golan Heights is Israeli-occupied; Israeli troops in
southern Lebanon since June 1982
Illicit drugs: increasingly concerned about cocaine
and heroin abuse; drugs primarily arrive in country
from Lebanon
240
(^SWITZERLAND^
AUSTRIA J HUNGARY
Trieste.? SL 0. —
.Milan CROATIA
• 1 urin Ravenna wenicfeyg^
''Genoa, Bologna\\|sAN ■ ^ \\T Bosnia £*»J
(La Spezia . W“;°ncorf.
Livorno'', Florence^"™"* ''X,^,
. iPiombino \\ %■ (Mont!
\\ V ‘ '' N A1
''vat,c*n@R0ME X
CITY X-J3aeta C^Bari ALfc
\\, Naples
''**'' MONACO
Corsica f
(FRANCE) / v
Porto Sl
Torrez>^\\
\\ Sardinia
Oristany j
V’Cagliari
Mediterranean
Sea
~\\s>
i
Tyrrhenian V
Sea \\ \\
• J ( Ionian
Sea
S/c/7y - ^atan,a/ dl Calabria
AugustaX o 100 km
* a v__r i 1 i 1 . ,
0 100 mi
(British crown dependency)
0 2 4 km
0 2 4 mi
English Channel
[ St.John
\\ \\
\\ --s'')
\\
\\
St. Aubin^
/''''N /
Goife de Saint-Malo
Disputes - international: none
Disputes - international: in November 1994, Iraq
formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council
Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to
Bubiyan and Warbah islands; ownership of Qaruh and
Umm al Maradim islands disputed by Saudi Arabia
Disputes - international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
462
Background: Having long lost its military prowess of
the 17th century, Sweden has evolved into a
prosperous and peaceful constitutional monarchy with
a capitalist system interlarded with substantial welfare
elements. As the 20th century comes to an end, this
long successful formula is being undermined by high
unemployment; the rising cost of a “cradle to the
grave" welfare state; the decline of Sweden''s
competitive position in world markets; and indecision
over the country''s role in the political and economic
integration of Europe. A member of the European
Union, Sweden chose not to participate in the
introduction of the euro on 1 January 1999.
i Geography
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
land: 41 0,928 sq km
water: 39,036 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: agreed boundaries or
midlines
territorial sea: 12 nm (adjustments made to return a
portion of straits to high seas)
Climate: temperate in south with cold, cloudy winters
and cool, partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,111m
Natural resources: zinc, iron ore, lead, copper,
silver, timber, uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 68%
of/?er: 24% (1993 est.)
Irrigated land: 1 ,150 sq km (1993 est.)
Natural hazards: ice floes in the surrounding waters,
especially in the Gulf of Bothnia, can interfere with
maritime traffic
Environment - current issues: acid rain damaging
soils and lakes; pollution of the North Sea and the
Baltic Sea
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location along Danish
Straits linking Baltic and North Seas
Disputes - international: none
Illicit drugs: minor transshipment point for and
consumer of narcotics shipped via the CIS and Baltic
states; increasing consumer of European
amphetamines','aa4118200e3ba140c93ec48f27aeec00fcf084073eaf675fb294b6e23ca999df','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d69aeb1af5b5bf4136a7a57fd88ce0826bcab368f6b8562f9b6ec167132591b8',1999,'FI','Finland','transnational-issues',450,'Disputes - international: none
Illicit drugs: minor transshipment point for Latin
American cocaine for the West European market
166','ea0627177abac9b9fafdc83244b24deed41e2a95a0287f0e98ea6cfd20a6acf8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eadf641e4b281fd7e711c529e5bf67da9059a170109476c76dcdeba32bc3444d',1999,'WF','Wallis and Futuna','transnational-issues',457,'Disputes - international: Madagascar claims
Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, and Tromeiin Island; Comoros
claims Mayotte; Mauritius claims Tromeiin Island;
territorial dispute between Suriname and French
Guiana; territorial claim in Antarctica (Adelie Land);
Matthew and Hunter Islands east of New Caledonia
claimed by France and Vanuatu
Illicit drugs: transshipment point for and consumer
of South American cocaine and Southwest Asian
heroin
169
0 50 100 mi
Disputes - international: claimed by Marshall
Islands','bfdef22f2a93dea1fc7e06b80c7532a4b2b602ced51f0c8187cb38094b378ded','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cc9aef5e511055b2d1420e558a5e8afc15db35910fc5b926febfd3efdf221fb',1999,'KI','Kiribati','transnational-issues',460,'lies
'' Marquises
South Pacific
Ocean
Makatea
Uturoav
Society
Islands
^PAPEETE
\\ *
Tahiti
Archipel des
Tuamotu
t. '' Mataura
lies - •.
Tubuai
Mururua Q
Rikitea..
!i , Rapa
0 250 500 km
0 250 500 ml','7c5e9fa8a44c3a3137dd4b6257ce8e44124a6b79b17bab604729b74c13844043','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14233126e9d6df1a23ca1c55198de7a36da0354db2712959bcc5313f92ba6f9',1999,'GA','Gabon','transnational-issues',475,'Disputes - international: maritime boundary
dispute with Equatorial Guinea because of disputed
sovereignty over islands in Corisco Bay
Gambia, The
Disputes - international: short section of boundary
with Senegal is indefinite
Gaza Strip
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation
180','58a2945e66da61687e7d1739a8a21f5827860dd3a1b2f9cce3618c46957e835f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61116d87be7f0fb2876f60713462520a64925b56b255ea4ccc8b76d5864d41ae',1999,'GH','Ghana','transnational-issues',484,'Disputes - international: none
Illicit drugs: illicit producer of cannabis for the
international drug trade; transit hub for Southwest and
Southeast Asian heroin and South American cocaine
destined for Europe and the US','0d7566d87e933efdef5454d937ba23be600b97eeb2a837555e80dc64cb09d0aa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc0c57f4384fc8aa6481a2967deb9fb37b30bd7afa41536c7ffc4075059e0575',1999,'GI','Gibraltar','transnational-issues',485,'(overseas territory
of the UK)
Disputes - international: claims and administers
Western Sahara, but sovereignty is unresolved and
the UN is attempting to hold a referendum on the
issue; the UN-administered cease-fire has been in
effect since September 1 991 ; Spain controls five
places of sovereignty (plazas de soberania) on and off
the coast of Morocco - the coastal enclaves of Ceuta
and Melilla which Morocco contests, as well as the
islands of Penon de Alhucemas, Penon de Velez de la
Gomera, and Islas Chafarinas
Illicit drugs: illicit producer of hashish; trafficking on
the increase for both domestic and international drug
markets; shipments of hashish mostly directed to
Western Europe; transit point for cocaine from South
America destined for Western Europe','a1d2ab42c9b5109e34e0c6d6827d7bebe34b3e8d8064a6482fc5a2e2b24db558','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('054dc89ff25c2943f0d09ff9ce401b8a422731986f5cbaed1913fda50c6ddf61',1999,'ES','Spain','transnational-issues',493,'Disputes - international: source of friction between
Spain and the UK
Glorioso Islands
(possession of France)
Wreck
Rock
V lie du Lys
n ./
?fl f
weather / # s "V
station ''^r A ‘ *"''■
He | Verte
| ; airstrip Glorieuse Rocks
C:; ^ /
,/3,T / South
Rock
Indian Ocean
Disputes - international: Gibraltar issue with UK;
Spain controls five places of sovereignty (plazas de
soberania) on and off the coast of Morocco - the
coastal enclaves of Ceuta and Melilla, which Morocco
contests, as well as the islands of Penon de
Alhucemas, Penon de Velez de la Gomera, and Islas
Chafarinas
Illicit drugs: key European gateway country for Latin
American cocaine and North African hashish entering
the European market; transshipment point for and
consumer of Southwest Asian heroin
451
Spratly Islands
Northeast Cay
South','c94f79317f05388ff22c695f2fa03a6cbb93d23b9a01d6a0d5c9a27111dfda6e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02e7c9ea6b7e43c29318b886172020e914296a0b863c69b2396bdd119f50fc15',1999,'GD','Grenada','transnational-issues',508,'Disputes - international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
196
Location: Caribbean, islands in the eastern
Caribbean Sea, southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the
Caribbean
Area:
total: 1 ,780 sq km
land: 1 ,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited
islands, including Basse-Terre, Grande-Terre,
Marie-Galante, La Desirade, lies des Saintes, Saint
Barthelemy, and part of Saint Martin
Area - comparative: 10 times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Netherlands Antilles (Sint Maarten)
10.2 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical tempered by trade winds;
moderately high humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation;
most of the seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,467 m
Natural resources: cultivable land, beaches and
climate that foster tourism
Land use:
arable land: 14%
permanent crops: 4%
permanent pastures: 1 4%
forests and woodland: 39%
other: 29% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: hurricanes (June to October);
Soufriere is an active volcano
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Disputes - international: none
Illicit drugs: transshipment pointforSouth American
drugs destined for the US and Europe
417','dc09a386b230305eef63b12c4ca73436917c0ffb6c6c7b76cd01ee673e93fb05','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4780339bc0379f3c0971cc08a78395f516a7ad84a8f4d019be290fe61889ab1b',1999,'GU','Guam','transnational-issues',509,'■ (territory of the US)
Disputes -international: none
Disputes - international: border with Belize in
dispute
Illicit drugs: transit country for cocaine shipments;
minor producer of illicit opium poppy and cannabis for
the international drug trade; active eradication
program of cannabis crop effectively eliminated in
1996
202','7c4c78b47794e1645c64cc9126949ea0ef8c1a73a647e013dcea750872cdced4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26ddab46bfe20be9b69d049f8163dca04a98d8ed5e466000ff8ef76c3438afba',1999,'GG','Guernsey','transnational-issues',517,'(British crown dependency)
Location: Western Europe, islands in the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 194 sq km
land: 194 sq km
wafer: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and
some other smaller islands
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: large, deepwater harbor at Saint
Peter Port
Disputes - international: none
Disputes - international: none','877549eb9dc1b463ff804d9baa46294f62b741f71f35d0440987ce34f9754fb8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00cf3a1c2194d88631dd4f552e53feacc9578bf361f2717cd33eabc3fe5db113',1999,'GW','Guinea-Bissau','transnational-issues',525,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total: 36,120 sq km
land: 28,000 sq km
wafer 8,120 sq km
Area - comparative: slightly less than three times
the size of Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical: generally hot and humid;
monsoonal-type rainy season (June to November)
with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast
corner of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, unexploited deposits of petroleum
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 38%
forests and woodland: 38%
other: 12% (1993 est.)
Irrigated land: 17 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment - current issues: deforestation; soil
erosion; overgrazing; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Wetlands
signed, but not ratified: none of the selected
agreements','b1e7c41f1f428cf6be384ad54e1895ada0d73dd23f4f8c719e9fabbd7935994e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd42ed4d8c291ecfba0565c370081426af071ced0663bc5acd57ac6d3acb7e70',1999,'ET','Ethiopia','transnational-issues',529,'Disputes - international: none
Disputes ■ international: none
fe/ephone— [251] (1) 51 72 00
FAX— [251] (1) 51 4416
established— 29 April 1958
aim— to promote economic development as
a regional commission of the UN''s Economic
and Social Council
Economic Commission for Asia and the Far see Economic and Social Commission for Asia and the Pacific (ESCAP)
East (ECAFE)
Economic Commission for Europe (ECE)
address— Palais des Nations, CH-121 1 Geneva
10, Switzerland
telephone— {4t] (22) 917 2727, 917 4444
FAX-i 41] (22) 917 0505
established— 28 March 1947
aim— to promote economic development as
a regional commission of the UN''s Economic
and Social Council
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Hungary, Iceland, Ireland, Israel, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway,
Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda,
Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania,
Togo, Tunisia, Uganda, Zambia, Zimbabwe
associate members— (2) France, UK
563
Appendix C: Internationa! Organizations and Groups (continued)
Economic Commission for Latin America
(ECLA)
see Economic Commission for Latin America and the Caribbean (ECLAC)
Economic Commission for Latin America
and the Caribbean (ECLAC)
address— Edificio Naciones Unidas, Avenida
Dag Hammarskjold, Casilla 179 D, Santiago,
telephone— {251] (1) 517700
FAX— [251] (1) 512622, 517844
established— 25 May 1963
aim— to promote unity and cooperation among
African states
Organization of American States (OAS)
address— corner of 1 7th Street and Constitution
Avenue NW, Washington, DC 20006, US
telephone— {1] (202) 458 3000
FAX— [1] (202) 458 3967
established— 30 April 1948
effective— 13 December 1951
aim— to promote regional peace and security as
well as economic and social development
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway,
Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia (suspended)
partners for cooperation— (7) Algeria, Egypt, Israel, Japan, South Korea, Morocco, Tunisia
members— (168) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Morocco, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi
Arab Democratic Republic, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
members— (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic,
Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama,
Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago, US, Uruguay, Venezuela
observers— (40) Algeria, Angola, Austria, Belgium, Bosnia and Herzegovina, Croatia, Cyprus, Czech Republic,
Egypt, Equatorial Guinea, EU, Finland, France, Germany, Greece, Holy See, Hungary, India, Israel, Italy, Japan,
Kazakhstan, South Korea, Latvia, Lebanon, Morocco, Netherlands, Pakistan, Poland, Portugal, Romania, Russia,
Saudi Arabia, Spain, Sri Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK
584
Appendix C: International Organizations and Groups (continued)
Organization of Arab Petroleum Exporting
Countries (OAPEC)
members— { 10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, UAE
address— P.0. Box 20501, Safat 13066, Kuwait
telephone— [965] 4844500
FAX— [965] 4815747
established— 9 January 1968
aim— to promote cooperation in the petroleum
industry
Organization of Eastern Caribbean States
(OECS)
address— OECS, P.O. Box 179, Morne Fortune,
Castries, Saint Lucia
telephone— {t] (758) 45 22537, 45 22538
FAX— [1] (758) 45 31628
established— 18 June 1981
effective—* 4 July 1981
aim— to promote political, economic, and
defense cooperation
members— (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines
associate members— (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting
Countries (OPEC)
members— ( 11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
address— Obere Donaustrasse 93, A-1020
Vienna, Austria
telephone— {43] (1) 21 11 20
FAX— [43] (1)216 43 20
established— 14 September 1960
aim— to coordinate petroleum policies
Organization of the Islamic Conference (OIC)
address— 6 km Makkah Al-Mukarramah Road,
P.O. Box 178, Jeddah 21411, Saudi Arabia
fe/epbone— [966] (2) 680-0800
FAX— [966] (2) 687-6568
established— 22-25 September 1969
aim— to promote Islamic solidarity in economic,
social, cultural, and political affairs
members— (54 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal,
Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Uzbekistan, Yemen, Palestine Liberation Organization
observers— { 4) Bosnia and Herzegovina, Central African Republic, Guyana, “Turkish Republic of Northern Cyprus"
Paris Club
see Group of 10
Partnership for Peace (PFP)
address— NATO Office of Information and
Press, B-1 110 Brussels, Belgium
telephone— {32] (2) 728 4415
FAX— [32] (2) 728 45 79
established— 10-11 January 1994
aim— to expand and intensify political and
military cooperation throughout Europe,
increase stability, diminish threats to peace, and
build relationships by promoting the spirit of
practical cooperation and commitment to
democratic principles that underpin NATO;
program under the auspices of NATO
members— (27) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria, Czech Republic, Estonia, Finland,
Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of Macedonia,
Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, Turkmenistan, Ukraine, Uzbekistan
585
Appendix C: International Organizations and Groups (continued)
Permanent Court of Arbitration (PCA)
address— Peace Palace, Carnegieplein 2,
NL-2517 KJ The Hague, Netherlands
fe/ephone— [31] (70) 302 42 42
FAXH31] (70) 302 41 67
established— 29 July 1899
aim— to facilitate the settlement of international
disputes
members— (83) Argentina, Australia, Austria, Belarus, Belgium, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia,
Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, France, Germany, Greece, Guatemala,
Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Israel, Italy, Japan, Jordan, Kyrgyzstan, Laos, Lebanon, Libya,
Liechtenstein, Luxembourg, Malta, Mauritius, Mexico, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan,
Panama, Paraguay, Peru, Poland, Portugal, Romania, Russia, Senegal, Singapore, Slovakia, Slovenia, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Zimbabwe
Population Commission
see Commission on Population and Development
Rio Group (RG)
nofe— formerly known as Grupo de los Ocho,
established in December 1986
address— Ministerio de Relaciones Exteriores,
Edificio AYFRA, Piso 10, Pdte Franco y Ayolas,
Asuncion, Paraguay
fe/ephone— [595] (21) 448409, 493872
FAX— [595] (21 ) 45091 1 , 49391 0
established— NA 1988
aim— to consult on regional Latin American
issues
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian
governments and command economies based on the Soviet model; the term is fading from use; see centrally
planned economies
Sistema Economico Latinoamericana (SELA)
see Latin American Economic System (LAES)
Social Commission
see Commission for Social Development
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production; note— the
term is sometimes used incorrectly as a synonym for communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the
counterpart of the North; see less developed countries (LDCs)
South Asian Association for Regional
Cooperation (SAARC)
members— (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
address— P.O. Box 4222, Kathmandu, Nepal
telephone— {977] (1) 221785, 226350, 221792,
228029
FAX— [977] (1) 227033, 223991
established— 8 December 1985
aim— to promote economic, social, and cultural
cooperation
South Pacific Commission (SPC)
address— BP D5, 98848 Noumea CEDEX, New
Caledonia
fe/epbone— [687] 26 20 00
FAX— [687] 26 38 18
established— 6 February 1947
effecf/Ve— 29 July 1948
aim— to promote regional cooperation in
economic and social matters
members— (26) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Palau, Papua
New Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, US, Vanuatu, Wallis and Futuna
586
Appendix C: International Organizations and Groups (continued)
South Pacific Forum (SPF)
address— cl o Forum Secretariat, Ratu Sukuna
Road, Private Mail Bag, Suva, Fiji
telephone— [679] 312 600, 303 106
FAX— [679] 301 102, 305 573
established— 5 August 1971
aim— to promote regional cooperation in political
matters
South Pacific Regional Trade and Economic members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Cooperation Agreement (Sparteca) Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
address— do forum Secretariat, Ratu Sukuna
Road GPO Box 856, Suva, Fiji
te/ephone— [679] 312 600, 303 106
FAX— [679] 302 204
established— NA 1981
aim— to redress unequal trade relationships of
Australia and New Zealand with small island
economies in the Pacific region
Southern African Customs Union (SACU) members— (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
address— Director of Customs and Excise,
Ministry of Finance, Private Bag 13295,
Windhoek, Namibia
established— 11 December 1969
aim— to promote free trade and cooperation in
customs matters
Southern African Development Community members— (1 4) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Malawi, Mauritius, Mozambique,
(SADC) Namibia, Seychelles, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
note— evolved from the Southern African
Development Coordination Conference
(SADCC)
address— Private Bag 0095, Gaborone,','9af2dc6cba6b6b3f9a04f4b897e380ff645fd67abdb5ecdb761a1397adf74a7e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54926e17adfe93959f37d8b7c96691724b5417253ca6fab9547a8f33d625b801',1999,'GY','Guyana','transnational-issues',535,'Disputes - international: all of the area west of the
Essequibo River claimed by Venezuela; Suriname
claims area between New (Upper Courantyne) and
Courantyne/Kutari [Koetari] Rivers (all headwaters of
the Courantyne)
Illicit drugs: transshipment point for narcotics from
South America ■ primarily Venezuela - to Europe and
the US; producer of cannabis
Disputes - international: claims area in French
Guiana between Litani Rivier and Riviere Marouini
(both headwaters of the Lawa Rivier); claims area in
Guyana between New (Upper Courantyne) and
Courantyne/Koetari [Kutari] Rivers (all headwaters of
the Courantyne)
Illicit drugs: transshipment point for South American
drugs destined mostly for Europe
G e o g r a p h y
Location: Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total: 62,049 sq km
land: 62,049 sq km
wafer: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area - comparative: slightly smaller than West
Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing zone: 200 nm unilaterally claimed by
Norway but not recognized by Russia
territorial sea: 4 nm
Climate: arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlantic
Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land
ice covered; west coast clear of ice about one-half of
the year; fjords along west and north coasts
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (no trees and the only bushes are
crowberry and cloudberry)
Svalbard (continued)
Irrigated land: NAsqkm
Natural hazards: ice floes often block up the
entrance to Bellsund (a transit point for coal export) on
the west coast and occasionally make parts of the
northeastern coast inaccessible to maritime traffic
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total area
Disputes - international: Svalbard is the focus of a
maritime boundary dispute in the Barents Sea
between Norway and Russia
460
0 20 40 mi','9d290b4d5d398f1d3d35913e1ab42f7f6c73dc5c5c29212649227bef374c0006','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b672aeae0562acf7ab3fe758a161ca7a29d8f039d5d302df91505149e0e7a7',1999,'HT','Haiti','transnational-issues',540,'Disputes - international: claims US-administered
Navassa Island
Illicit drugs: transshipment point for cocaine and
marijuana en route to the US and Europe
Heard Island
and McDonald
Islands
(territory of Australia)
O 8 16 km
O 8
16 mi
McDonald
Islands
Flat Island
McDonald Island
f
1 Shag
, Island
■■•VI .p......
) " v\\
< \\
i X ^
\\ x"
y''
Heard Island
Indian
Ocean
Debt - external: $1 billion (1997 est.)
Economic aid - recipient: $730.6 million (1995)
Currency: 1 gourde (G) = 100 centimes
Exchange rates: gourdes (G) per US$1 - 16.778
(January 1 999), 1 6.205 (1 998), 1 7.31 1 (1 997), 1 5.093
(1996), 16.160 (1995), 12.947(1994)
Fiscal year: 1 October - 30 September','a2564e1626b90a7cd933d7779c0fbb361174e78be219ba6ff6b9ef4398a7a5ee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b34d3d16b597cca765b03c0133f2ff55d019215904c8e203cc2cd48b0cba065c',1999,'NI','Nicaragua','transnational-issues',545,'Illicit drugs: transshipment point for drugs and
narcotics; illicit producer of cannabis, cultivated on
small plots and used principally for local consumption
216
South China Sea
I _ d _ I
Disputes - international: none
Illicit drugs: a hub for Southeast Asian heroin trade;
transshipment and money-laundering center;
increasing indigenous amphetamine abuse
218
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Costa Rica and Honduras
Geographic coordinates: 1 3 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area:
fofa/:1 29,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area - comparative: slightly smaller than the state
of New York
Land boundaries:
total: 1 ,231 km
border countries: Costa Rica 309 km, Honduras 922
km
Coastline: 910 km
Maritime claims:
contiguous zone: 25-nm security zone
continental shelf: natural prolongation
territorial sea: 200 nm
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal plain
interrupted by volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 27%
other: 17% (1993 est.)
Irrigated land: 880 sq km (1993 est.)
Natural hazards: destructive earthquakes,
volcanoes, landslides, and occasionally severe
hurricanes
Environment - current issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Environmental Modification, Law of the Sea','07794ce82280e7fbc1ce6ab12a7a19fd161bce9b7206de78a8a2784c5cab6ee4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ff483108aa7a6b91e853dca08baf8fd0840b66aea7a2084589fc92b3ef4e64b',1999,'HU','Hungary','transnational-issues',554,'government and economy were refashioned on the
communist model. Increased nationalist opposition,
which culminated in the government''s announcement
of withdrawal from the Warsaw Pact in 1956, led to
massive military intervention by Moscow and the swift
crushing of the revolt. In the more open GORBACHEV
years, Hungary led the movement to dissolve the
Warsaw Pact and steadily moved toward multiparty
democracy and a market-oriented economy.
Following the collapse of the USSR in 1 991 , Hungary
has developed close political and economic relations
with western Europe and is now being considered a
possible future member of the European Union.','37aba2dedc98d3d9c9cc5c8145fa246cf573d221271ba129a009c7e4801ac711','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d297d062db1e50619c12a11bd6d8905995081a402e50b6c3ceb01f307d8fd9c',1999,'AT','Austria','transnational-issues',562,'Disputes - international: ongoing Gabcikovo Dam
dispute with Slovakia is before the International Court
of Justice
Illicit drugs: major transshipment point for
Southwest Asian heroin and cannabis and transit
point for South American cocaine destined for
Western Europe; limited producer of precursor
chemicals, particularly for amphetamines and
methamphetamines
telephone— [43] (1) 213450
FAY— [43] (1) 21345-5885
established— 16 February 1946
aim— Economic and Social Council organization
dealing with illicit drugs programs of UN
members— (53) selected on a rotating basis from all regions with emphasis on producing and processing countries
Commission on Population and
Development
address— Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainable Development,
United Nations, Room 2963, New York, NY
10017, US
telephone^]] (212) 963 1234
FAY— [1] (212) 963 5935
established -3 October 1946
aim— to deal with population matters of
importance to the UN, as part of Economic and
Social Council
members— (47) selected on a rotating basis from all regions
Commission on Science and Technology
for Development
address— United Nations, New York, NY 1 001 7,
US
telephone— {]] (212) 963 1234
FAY— [1] (212) 758 2718
established— 30 April 1992
aim— to promote international cooperation, as
part of the Economic and Social Council, in the
field of science and technology
members— (53) selected on a rotating basis from all regions
558
Appendix C: International Organizations and Groups (continued)
Commission on the Status of Women members— { 45) selected on a rotating basis from all regions
address— Division for the Advancement of
Women, Department for Ecumenical and Social
Affairs, United Nations, Room DC2-1200, New
York, NY 10017, US
telephone-^] (212) 9634666
FAX— [1] (212) 963 3463
established— 21 June 1946
aim— to deal, as part of the Economic and Social
Council, with women''s rights goals of UN
Commission on Sustainable Development members— (53) selected on a rotating basis from all regions
address— Division for Sustainable
Development, UN DPCSD, Room DC2-2274,
New York, NY 10017, US
telephone— {)] (212) 963 0902
FAX— {1] (212) 9634260
established— 12 February 1993
aim— to monitor, as part of the Economic and
Social Council, implementation of agreements
reached at the UN Conference on Environment
and Development
Commonwealth (C)
note— also known as Commonwealth of Nations
address— c/o Commonwealth Secretariat,
Marlborough House, Pall Mall, London SW1Y
5HX, UK
fe/ep/rone— {44](171)839 3411
FAX-{44] (171) 930 0827
established— 31 December 1931
aim— to foster multinational cooperation and
assistance, as a voluntary association that
evolved from the British Empire
Commonwealth of Independent States (CIS) members— (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
address— Kirov Street 17, 220000 Minsk,
fe/ep/rone— [43] (1) 514 36-190
FAX— [43] (1) 514 36-96
established — 1 January 1995
aim— to foster the implementation of human
rights, fundamental freedoms, democracy, and
the rule of law; to act as an instrument of early
warning, conflict prevention and crisis
management; and to serve as a framework for
conventional arms control and confidence
building measures
Organization for the Prohibition of Chemical
Weapons (OPCW)
address— Johan de Wittlaan 32, NL-2517 JR
The Hague, Netherlands
fe/ep/jone— (3 1 ] (70) 376 17 00
FAX— [31] (70) 360 09 44
established— 29 April 1 997
aim— to enforce the Convention on the
Prohibition of the Development, Production,
Stockpiling and Use of Chemical Weapons and
on Their Destruction; to provide a forum for
consultation and cooperation among the
signatories of the Convention
Organization of African Unity (OAU)
address— P. O. Box 3243, Addis Ababa,','053133dc37eaf55ab3a5701485c171eae53fdeba15fa957e33d391a75135f0f8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('755eef64613deac32100b81c33e27f3d638edfa2ca51d30999d5e0c5a7c3abb7',1999,'IS','Iceland','transnational-issues',563,'Ib
50 lOOkm
(sa,i6rd^f^lfe
Greenland Sea
Qrlmsey , ^Raufarhdfn
^REYKJAVIK
[fjflrdhur
Vestmannaeyjar *K
Surtsey
tflln
Hornafjordur
North Atlantic Ocean
Disputes - international: Rockall continental shelf
dispute involving Denmark, Ireland, and the UK
(Ireland and the UK have signed a boundary
agreement in the Rockall area)
224
Disputes - international: some maritime disputes
(see littoral states)
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 1 0 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg 2,277
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm{1993)
Natural hazards: dominated by the volcano Haakon
VII Toppen/Beerenberg; volcanic activity resumed in
1970
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: barren volcanic island with some
moss and grass','827847e2f312db24dcd8c108bf6a4ef3418b35c1f830a5b7a50ec12cb92bdd01','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1858898861d41b98e4f51e6424201212b0720ed4cf54637fa72ba6c97148457',1999,'ID','Indonesia','transnational-issues',572,'Background: Indonesia declared its independence
in 1945 from the Netherlands, a claim disputed, then
recognized by the Dutch in 1949. In 1975 Indonesian
troops occupied Portuguese East Timor. Current
issues include implementing IMF-mandated reforms
(particularly restructuring and recapitalizing the
insolvent banking sector), effecting a transition to a
popularly elected government, addressing
longstanding grievances over the role of the ethnic
Chinese business class and charges of cronyism and
corruption, alleged human rights violations by the
military, the role of the military and religion in politics,
and growing pressures for some form of
independence or autonomy by Aceh, Irian Jaya, and
East Timor.
Disputes - international: Indonesian sovereignty
over Timor Timur (East Timor Province), which is not
recognized by the UN, is the subject of discussions
between the UN, Indonesia, and Portugal; two islands
in dispute with Malaysia
Illicit drugs: illicit producer of cannabis largely lor
domestic use; possible growing role as transshipment
point for Golden Triangle heroin
230
Disputes - international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shaft al Arab
waterway; Iran occupies two islands in the Persian
Gulf claimed by the UAE: Lesser T unb (called Tunb as
Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called
Tunb al Kubra in Arabic by UAE and Jazireh-ye
Tonb-e Bozorg in Persian by Iran); it jointly
administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by
UAE and Jazireh-ye Abu Musa in Persian by Iran) -
over which Iran has taken steps to exert unilateral
control since 1 992, including access restrictions and a
military build-up on the island; the UAE has garnered
significant diplomatic support in the region in
protesting these Iranian actions; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: despite substantial interdiction efforts,
Iran remains a key transshipment point for Southwest
Asian heroin to Europe; domestic consumption of
narcotics remains a persistent problem and Iranian
press reports estimate that there are at least 1 .2
million drug users in the country
Disputes - international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab
waterway; in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had
been spelled out in Security Council Resolutions 687
(1991 ), 773 (1 993), and 883 (1 993); this formally ends
earlier claims to Kuwait and to Bubiyan and Warbah
islands although the government continues periodic
rhetorical challenges; dispute over water development
plans by Turkey for the Tigris and Euphrates Rivers
235
Background: Growing Irish nationalism resulted in
independence from the United Kingdom in 1 921 , with
six largely Protestant northern counties remaining
within the UK. After World War II bloody strife between
Catholics and Protestants over the status of Northern
Ireland cost thousands of lives. In 1998, substantial
steps toward peace were agreed to by the British and
Irish governments and the Roman Catholics and
Protestants of Northern Ireland.
Disputes - international: Northern Ireland issue
with the UK (historic peace agreement signed 10 April
1998); Rockall continental shelf dispute involving
Denmark, Iceland, and the UK (Ireland and the UK
have signed a boundary agreement in the Rockall
area)
Illicit drugs: transshipment point for and consumer
of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; transshipment point for heroin and cocaine
destined for Western Europe
c LUMPUR
.Port Dicklop 0 , *e^/auan
Anambas
(INDONESIA)
..a Baharu
/\\Kepulauan
■C) Natuna
(INDONESIA)
tvtelaka
Spratly p
Islands
Kudat/J?*
Suiu
Sea
Kota Kinabalu C
Pulau Labuan0
bruneI/V*
MirilT
.Sandakan
Disputes - international: involved in a complex
dispute over the Spratly Islands with China,
Philippines, Taiwan, Vietnam, and possibly Brunei;
Philippines have not fully revoked claim to Sabah
State; two islands in dispute with Singapore; two
islands in dispute with Indonesia
Illicit drugs: transit point for some illicit drugs going
to Western markets; drug trafficking prosecuted
vigorously and carries severe penalties
303
\\ J
PAPUA NEWACUNe)*
C\\ SOLOMON
V .ISLANDS
- \\
T ''
Disputes -international: none
Midway Islands
(territory of the US)
Geo g r a p h y
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references: Oceania
Area:
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit
Island
Area - comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 15 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical, but moderated by prevailing
easterly winds
Terrain: low, nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 4 m
Natural resources: wildlife, terrestrial and aquatic
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: a coral atoll managed as a
national wildlife refuge and open to the public for
wildlife-related recreation in the form of wildlife
325
Midway Islands (continued)
observation and photography, sport fishing,
snorkeling, and scuba diving
Disputes - international: none
Moldova
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent
States
Area:
total: 33,843 sq km
land: 33,371 sq km
wafer: 472 sq km
Area - comparative: slightly larger than Maryland
Land boundaries:
total: 1 ,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black
Sea
Elevation extremes:
lowest point: Nistru River 2 m
highest point: Mount Balaneshty 430 m
Natural resources: lignite, phosphorites, gypsum
Land use:
arable land: 53%
permanent crops: 14%
permanent pastures: 1 3%
forests and woodland: 1 3%
other: 7% (1993 est.)
Irrigated land: 3,1 10 sq km (1993 est.)
Natural hazards: landslides (57 cases in 1998)
Environment - current issues: heavy use of
agricultural chemicals, including banned pesticides
such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poor farming
methods
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked
Disputes - international: separatist Transdniester
region, comprising the area between the Nistru
(Dniester) River and Ukraine, has its own de facto
government, dominated by Moldovan Slavs
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for CIS consumption; transshipment
point for illicit drugs from Southwest Asia via Central
Asia to Russia, Western Europe and possibly the
*
Disputes - international: involved in a complex
dispute over the Spratly Islands with China, Malaysia,
Taiwan, Vietnam, and possibly Brunei; claim to
Malaysia''s Sabah State has not been fully revoked
Illicit drugs: exports locally produced marijuana and
hashish to East Asia, the US, and other Western
markets; serves as a transit point for heroin and
crystal methamphetamine
388
Pitcairn Islands
| (overseas territory
of the UK)
O 50 100 km
O 50 lOO ml
0Sandy
Oeno
ADAMSTOWN
*
^..Bounty
Pitcairn Bay
0 Henderson
Ducie c,
South Pacific Ocean
Disputes - international: none
Disputes - international: two islands in dispute with
telephone— {62] (21) 7262410, 7262991,
7262272, 7251988
FAX— [62] (21) 7398234, 7243348
established— 9 August 1967
aim— to encourage regional economic, social,
and cultural cooperation among the
non-Communist countries of Southeast Asia
members— (9) Brunei, Burma, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
observers— (2) Cambodia, Papua New Guinea; note— Cambodia has been accepted as a member of ASEAN but
must go through the entry ceremony
associate partners— (2) China, Russia
Australia Group
established— 1984
aim— to consult on and coordinate export
controls related to chemical and biological
weapons
members— (28) Argentina, Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Poland,
Portugal, Slovakia, Spain, Sweden, Switzerland, UK, US; note— may now include only 23 countries
observer— { 1) Singapore
553
Appendix C: International Organizations and Groups (continued)
Australia-New Zealand-United States
Security Treaty (ANZUS)
members— (3) Australia, NZ, US
address— do Department of Foreign Affairs and
Trade, Bag 8, Queen Victoria Terrace, Canberra
ACT 2600, Australia
fe/ep/rone— {61] (6) 261 91 11
FAX-{61] (6) 261 21 51
established— 1 September 1951
effective— 29 April 1952
aim— to implement a trilateral mutual security
agreement, although the US suspended security
obligations to NZ on 1 1 August 1986; Australia
and the US continue to hold annual meetings
Banco Centroamericano de Integracion
Economico (BCIE)
see Central American Bank for Economic Integration (BCIE)
Banco Interamericano de Desarrollo (BID)
see Inter-American Development Bank (IADB)
Bank for International Settlements (BIS)
address— Centralbahnplatz 2, CH-4002 Basel,','c71792caa8bfc5a36360408e3d046f1ded38b192fce8ca8bfd11ce9bbf9110ca','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14172b159ace1bed86f09889d1a7139a7488be0086d8d3c45cf4afbadb7896c',1999,'IL','Israel','transnational-issues',576,'(also see separate Gaza Strip
and West Bank entries)
Background: The territories occupied by Israel since
the 1967 war are not included in the data below,
unless otherwise noted. In keeping with the
framework established at the Madrid Conference in
October 1991, bilateral negotiations are being
conducted between Israel and Palestinian
representatives, and Israel and Syria, to achieve a
permanent settlement between them. On 25 April
1982, Israel withdrew from the Sinai pursuant to the
1 979 Israel-Egypt Peace treaty. Outstanding territorial
and other disputes with Jordan were resolved in the
26 October 1994 Israel-Jordan Treaty of Peace.','7a62d4918d13267f0f13d862463b317fd717cb8824272b46f9af7d44f2271a84','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d66339bb9d42ec9b89a3b49611aec4e69708fff10c2545c19f48acbdd388f77',1999,'TN','Tunisia','transnational-issues',584,'Disputes - international: Italy and Slovenia made
progress in resolving bilateral issues; Croatia and Italy
made progress toward resolving a bilateral issue
dating from World War II over property and ethnic
minority rights
Illicit drugs: important gateway for and consumer of
Latin American cocaine and Southwest Asian heroin
entering the European market
243','3de4566a04ec7bee981e72beef201e9c9e0dd845ee5b72378f94b49653fc35ae','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deae1b8747d3ad7e65f6314a47a049bf1760ca53fe240cb5e11e846aeedd17f2',1999,'JM','Jamaica','transnational-issues',585,'\\ _____ Mandeville.
Black River|
\\
Alligator Porid
Caribbean
Sea
Spanish
Town.
May
Pen. Portmore.
Port Esquivel*. >''
Port4"
Antonio
KINGSTON
. Morant :
Bay .
Rocky
Point
o
15
30 km
0
15 30 mi
Disputes - international: none
Illicit drugs: transshipment point tor cocaine from
Central and South America to North America and
Europe; illicit cultivation of cannabis; government has
an active manual cannabis eradication program
Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of','a56b2e1ca6e0077969db8d29dabd6defed7f4e4c2ad9d0787b388f81f17a92be','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c08f78aa09fe4d466defdafd1e2f294ca0e2847fe5c162ccf6fb8c5359bc71a6',1999,'KZ','Kazakhstan','transnational-issues',605,'Background: As a republic within the USSR
(1920-91), Kazakhstan suffered greatly from Stalinist
purges, from environmental damage, and saw the
ethnic Russian portion of its population rise to 37%
while other non-Kazakhs made up almost 20%.
Current issues include the pace of market reform and
privatization; fair and free elections and democratic
reform; ethnic differences between Russians and
Kazakhs; environmental problems; and how to
convert the country''s abundant energy resources into
a better standard of living.
Disputes - international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan; Russia
leases approximately 6,000 sq km of territory
enclosing the Baykonur Cosmodrome
Illicit drugs: significant illicit cultivation of cannabis
and limited cultivation of opium poppy and ephedra
(for the drug ephedrone); limited government
eradication program; cannabis consumed largely in
the CIS; used as transshipment point for illicit drugs to
Russia, North America, and Western Europe from
Southwest Asia
Disputes - international: administrative boundary
with Sudan does not coincide with international
boundary
Illicit drugs: widespread harvesting of small, wild
plots of marijuana and qat (chat); transit country for
South Asian heroin destined for Europe and,
sometimes, North America; Indian methaqualone also
transits on way to South Africa
260
Kingman Reef
(territory of the US)
O
1 2km
O
1 2 mi
X V
''V V
%
\\
\\
\\\\
V \\
North Pacific
\\N
-V •’n.
Ocean
\\ \\
Vf\\x
Yw/vvw, ,ee^
* jy*
))
% — ^','25a9b36369b5a55f4b25b1e94a08a5dab4ecaa55e54ebcd967d5c0a05613bdd2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3cc988d0fe99bf57d0b7335ebb0740ae9ecb1257b5a154100317c1fd362fb9f',1999,'WS','Samoa','transnational-issues',619,'Disputes -international: none
Disputes -international: none
Disputes - international: 33-km section of
boundary with China in the Paektu-san (mountain)
area is indefinite; Demarcation Line with South Korea
265
Disputes - international: Demarcation Line with
North Korea; Liancourt Rocks (Takeshima/Tokdo)
claimed by Japan
Disputes - international: none
376
Disputes - international: none
419','ffca4d4b2a35582905ea4d24b409476c931703d5f69008b15d4b8b11c82dac7a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c95afaa12c6dbe8344db4721441ccaefbe67e5fcc4350b1f53ac77edb6274974',1999,'KG','Kyrgyzstan','transnational-issues',623,'and proud nomadic traditions, Kyrgyzstan became
part of the Russian empire in 1864. In the Czarist and
Soviet periods, Russian managers and technicians
were sent to Kyrgyzstan and have recently made up
more than one-fifth of the population. Many Russians
have been returning home since Kyrgyzstan gained
its independence in 1991 when the USSR collapsed.
Privatization of state-owned enterprises, expansion of
democracy and political freedoms, and inter-ethnic
relations are current issues.
Disputes - international: territorial dispute with
Tajikistan on southwestern boundary in Isfara Valley
area
Illicit drugs: limited illicit cultivator of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; increasingly used
as transshipment point for illicit drugs to Russia and
Western Europe from Southwest Asia
272
Location: Southeastern Asia, northeast of Thailand,
west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area - comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1 ,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain: mostly rugged mountains; some plains and
plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum,
tin, gold, gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 40% (1993 est.)
Irrigated land: 1 ,250 sq km (1 993 est.)
note: rainy season irrigation - 2,169 sq km; dry season
irrigation - 750 sq km (1998 est.)
Natural hazards: floods, droughts, and blight
Environment - current issues: unexploded
ordnance; deforestation; soil erosion; a majority of the
population does not have access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','15dbf563d394bd95361d13dd3153a4d3f165388fcfed276a6fabea93579dd93e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('757d7269e6444a30789bf7a658b1b05ae67ce13bb266e91db0fe7d3e80d12d5f',1999,'LV','Latvia','transnational-issues',639,'Disputes - international: draft treaty delimiting the
boundary with Russia has not been signed; ongoing
talks over maritime boundary dispute with Lithuania
(primary concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and
cannabis from Central and Southwest Asia to Western
Europe and Scandinavia and Latin American cocaine
and some synthetics from Western Europe to CIS;
limited production of illicit amphetamines, ephedrine,
and ecstasy for export','2da1a92436916ab988a709d316b3501ed925808f523480da878f5d4a262fea91','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600b105126c0d531b1950f6d4985f0977d1dfc46d41d52d7535a4936c36445d2',1999,'LB','Lebanon','transnational-issues',648,'Disputes - international: Israeli troops in southern
Lebanon since June 1982; Syrian troops in northern,
central, and eastern Lebanon since October 1976
279
Lebanon (continued)
Illicit drugs: inconsequential producer of hashish
and heroin; some heroine and cocaine processing
mostly in the Bekaa valley; a Lebanese/Syrian
eradication campaign started in the early 1990s has
practically eliminated the opium and cannabis crops','e4a7afcf329ce2354e49afca5131b374a8ebbaf72aad6c4e08cee0717432ef51','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c141409d9f55e5cd1025803b880282bc8187a7bd1b7a2db9fe7bde138be9fd82',1999,'ZA','South Africa','transnational-issues',656,'Disputes - international: none
Liberia Q
Disputes -international: none
illicit drugs: increasingly a transshipment point for
Southeast and Southwest Asian heroin and South
American cocaine for the European and US markets','14c85191b191bb4157c0a0e70192e3b89a67b186dd74d3f969171fddf93a3c4f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288e52403253b4952e1148cbca174d31aae748884eac523d394e7260f88e8719',1999,'LY','Libya','transnational-issues',666,'Disputes - international: maritime boundary
dispute with T unisia; Libya claims about 1 9,400 sq km
in northern Niger and part of southeastern Algeria','3a31684873019e0aa9e0b48c0398788bdd0517f0cd2bef59a184e17ba33a219a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a077b2a0b61c6672110cca34bdae5e01da395c0139ae24520f31f2d1c1260e62',1999,'CH','Switzerland','transnational-issues',674,'Disputes - international: claims 1 ,600 sq km of
property in the Czech Republic confiscated from its
royal family in 1918; the Czech Republic insists that
restitution does not go back before February 1948,
when the communists seized power
Disputes - international: ongoing talks over
maritime boundary dispute with Latvia (primary
concern is oil exploration rights); 1997 border
agreement with Russia not yet ratified
Illicit drugs: transshipment point for opiates and
other illicit drugs from Southwest Asia, Latin America,
and Western Europe to Western Europe and
Scandinavia
fe/ep/rone— [41] (61) 280 80 80
FAX— [41] (61) 280 91 00, 280 81 00
established— 20 January 1930
effective— 17 March 1930
aim— to promote cooperation among central
banks in international financial settlements
members— (42) Australia, Austria, Belgium, Brazil, Bulgaria, Canada, China, Czech Republic, Denmark, Estonia,
Finland, France, Germany, Greece, Hong Kong, Hungary, Iceland, India, Ireland, Italy, Japan, South Korea, Latvia,
Lithuania, Mexico, Netherlands, Norway, Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, UK, US, Yugoslavia (suspended)
pending members— (2) Croatia, Macedonia
Banque Africaine de Developpement
(BAD)
see African Development Bank (AfDB)
Banque Arabe de Developpement
Economique en Afrique (BADEA)
see Arab Bank for Economic Development in Africa (ABEDA)
Banque de Developpement des Etats de
I''Afrique Centrale (BDEAC)
see Central African States Development Bank (BDEAC)
Banque Ouest-Africaine de Developpement
(BOAD)
see West African Development Bank (WADB)
Benelux Economic Union (Benelux)
members— (3) Belgium, Luxembourg, Netherlands
note— acronym from Belgium, Netherlands, and
telephone— {41] (22) 917 12 34, 907 12 34
FAY— {41] (22) 733 32 46
established— 18 February 1946
aim— to assist, as part of the Economic and
Social Council, with human rights programs of
UN
members— (53) selected on a rotating basis from all regions
Commission on Narcotic Drugs
address— do United Nations Drug Control
Programme, Treaty Implementation and Legal
Affairs Branch, P.O. Box 500, A-1400 Vienna,
fe/eptone— [41] (22) 730 4222
FAX-{ 41] (22) 733 0395
established— 5 May 1919
aim— to organize, coordinate, and direct
international relief actions; to promote
humanitarian activities; to represent and
encourage the development of National
Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to
reduce the vulnerability of people through
development programs
International Finance Corporation (IFC)
address— 2121 Pennsylvania Avenue NW,
Washington, DC 20433, US
telephone— [t] (202) 473 0631, 477 1234
FAX— [1] (202) 974 4384, 477 6391
established— 25 May 1955
effective— 20 July 1956
aim— to support private enterprise in
international economic development; a UN
specialized agency and IBRD affiliate
International Fund for Agricultural
Development (IFAD)
address— Via del Serafico 107, 1-00142 Rome,
fe/ep/rone— [41] (31) 350 31 11
FAX— [41] (31) 350 31 10
established— 9 October 1874, affiliated with
the UN 15 November 1947
effective— 1 July 1948
aim— to promote international postal
cooperation; a UN specialized agency
members— (189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Overseas Territories of the UK, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member
states at the time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier
members included GDR and Albania
597
Appendix C: International Organizations and Groups (continued)
West African Development Bank (WADB)
members— (7) Benin, Burkina Faso, Cote d''Ivoire, Mali, Niger, Senegal, Togo
note— also known as Banque Ouest-Africaine
de Developpement (BOAD); is a financial
institution of WAEMU
address— 68 Avenue de la Liberation, BP 1172,
Lome, Togo
telephone— [228] 21 59 06, 21 42 44, 21 01 13
FAX— {228] 21 52 67, 21 72 69
established— 14 November 1973
aim— to promote regional economic
development and integration
West African Economic and Monetary Union
(WAEMU)
members— (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
note— also known as Union Economique et
Monetaire Ouest africaine (UEMOA)
address— Commission de I''UEMOA, 01 BP 543,
Ouadgadougou, Burkina Faso
telephone— [226] (35) 31 88 73 through 76
FAX— [226] (35) 31 88 72
established — 1 August 1994
aim— to increase competitiveness of members''
economic markets; to create a common market
West African Economic Community (CEAO)
note— acronym from Communaute Economique
de I’Afrique de I’Ouest
established on 3 June 1 972 to promote regional economic development; its members were Benin, Burkina Faso,
Cote d''Ivoire, Mali, Mauritania, Niger, Senegal; it was disbanded in 1994
Western European Union (WEU)
address— Rue de la Regence 4, B-1000
Brussels, Belgium
telephone— {32] (2) 500 44 11
FAX— [32] (2) 511 32 70
established— 23 October 1954
effective— 6 May 1955
aim— to provide mutual defense and to move
toward political unification
members— { 10) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (3) Iceland, Norway, Turkey
associate partners— (10) Bulgaria, Czech Republic, Estonia, Hungary, Latvia, Lithuania, Poland, Romania,
Slovakia, Slovenia
observers— (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank
see International Bank for Reconstruction and Development (IBRD)
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association
(IDA), and International Finance Corporation (IFC)
World Confederation of Labor (WCL)
address— Rue de Treves 33, B-1040 Brussels,
fe/ep/ione— {41] (22) 730 81 11
FAX— {41] (22) 734 23 26
established— 11 October 1947
effective— A April 1951
aim— to sponsor meteorological cooperation; a
UN specialized agency
World Tourism Organization (WToO)
address— Calle Capitan Haya 42, 28020
Madrid, Spain
fe/ep/7one — [34] (1) 567 81 00
FAX— {34] (1) 571 37 33
established— 2 January 1975
aim— to promote tourism as a means of
contributing to economic development,
international understanding, and peace
members— { 168) Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
members— (185) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, British Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, T rinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
members— (133) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Austria, Bangladesh, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt,
Ei Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Libya, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
Nicaragua, Niger, Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Rwanda, San Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Switzerland, Syria, Tanzania, Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— (4) Aruba, Macau, Madeira Islands, Netherlands Antilles
observer— (1) Holy See
600
Appendix C: International Organizations and Groups (continued)
World Trade Organization (WTrO)
note— succeeded General Agreement on Tariff
and Trade (GATT)
address— Centre William Rappard, 154 Rue de
Lausanne, CH-1211 Geneva 21, Switzerland
telephone— [At] (22) 739 51 11
FAX— {41] (22) 739 54 58
established— 15 April 1994
effective— 1 January 1995
aim— to provide a means to resolve trade
conflicts between members and to carry on
negotiations with the goal of further lowering
and/or eliminating tariffs and other trade barriers
Zangger Committee (ZC)
established— early 1970s
a/m— to establish guidelines for the export
control provisions of the Nonproliferation of
Nuclear Weapons Treaty (NPT)
members— (134) Angola, Antigua and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon,
Canada, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, EU, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho,
Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Mongolia, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
observers— { 5) Azerbaijan, Laos, Somalia, Tajikistan, Turkmenistan
applicants— (33) Albania, Algeria, Armenia, The Bahamas, Belarus, Cambodia, Cape Verde, China, Comoros,
Croatia, Equatorial Guinea, Estonia, Georgia, Jordan, Kazakhstan, Kiribati, Lithuania, The Former Yugoslav
Republic of Macedonia, Moldova, Nepal, Oman, Russia, Sao Tome and Principe, Saudi Arabia, Seychelles, Tonga,
Tuvalu, Ukraine, Uzbekistan, Vanuatu, Vietnam, Yemen, Taiwan; note— some of these countries applied to GATT
and are still under consideration for membership in WTrO; the following member of GATT had not become a
member of WTrO as of 1 January 1998: Yugoslavia (suspended)
members— (29) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania,
Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, UK, US
601
Appendix D:
Selected International
Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic
Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur
Emissions or Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of
Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature— 1 December 1959
entered into force— 23 June 1 961
objective— to ensure that Antarctica is used for
peaceful purposes, such as, for international
cooperation in scientific research, and that it does
not become the scene or object of international
discord
parties— { 43) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba,
Czech Republic, Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy,
Japan, North Korea, South Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania,
Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
note— abbreviated as Hazardous Wastes
opened for signature— 22 March 1989
entered into force— 5 May 1992
objective— to reduce transboundary movements of
wastes subject to the Convention to a minimum
consistent with the environmentally sound and
efficient management of such wastes; to minimize
the amount and toxicity of wastes generated and
ensure their environmentally sound management as
closely as possible to the source of generation; and
to assist LDCs in environmentally sound
management of the hazardous and other wastes
they generate
parties— (123) Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burundi, Canada, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Dominica, Ecuador, Egypt, El Salvador, Estonia, EU, Finland, France, The Gambia,
Germany, Greece, Guatemala, Guinea, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Japan, Jordan, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Liechtenstein, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malawi, Malaysia, Maldives, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified— (3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
602
Appendix D: Selected International Environmental Agreements (continued)
Convention on Biological Diversity
note-abbreviated as Biodiversity
opened for signature— 5 June 1 992
entered into force— 29 December 1993
objective— to develop national strategies for the
conservation and sustainable use of biological
diversity
parties— ( 175) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,','69f7e3dbb706dab911b8aed76c2d13f1d195d5135b1e507626b26e2f74922e16','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e8119ca05da089f6c17f58bdf38369abd96d4527292b893310c0afd1cdc1121',1999,'LU','Luxembourg','transnational-issues',679,'Location: Western Europe, between France and
address— Rue de la Regence 39, B-1000
Brussels, Belgium
fe/ep/rone— {32] (2)519 3811
FAX— [32] (2)51342 06
established— 3 February 1958
effective— 1 November 1960
aim— to develop closer economic cooperation
and integration
554
Appendix C: International Organizations and Groups (continued)
Big Seven
members— (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
note— membership is the same as the
Group of 7
established— NA 1975
aim— to discuss and coordinate major
economic policies
Big Six
members— (5) Canada, France, Germany, Italy, Japan, UK
note— not to be confused with the Group of 6
established— NA 1967
aim— to foster economic cooperation
Black Sea Economic Cooperation Zone
(BSEC)
address— Istinye Cad Musir Fuad Pasa Yalisi
Eski Tersame, Istinye 80860, Istanbul, Turkey
telephone— {%] (212) 229 6330
FAX— [90] (212) 229 6336
established— 25 June 1992
aim— to enhance regional stability through
economic cooperation
members— ( 11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Turkey,','c5b13573d8891d74d3d29fb041a82330d7fb45f5ccbaa68b5323a2bee40ea118','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73514cee1e82407bd473b14af8211cdaece3fd7c4e0cc4894c48e1f7694e6c7b',1999,'MW','Malawi','transnational-issues',680,'Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area:
tofa/; 1 1 8,480 sq km
land: 94,080 sq km
wafer: 24,400 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1 ,569 km, Tanzania
475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; rainy season (November to May);
dry season (May to November)
Terrain: narrow elongated plateau with rolling plains,
rounded hills, some mountains
Elevation extremes:
lowest point: junction of the Shire River and
international boundary with Mozambique 37 m
highest point: Sapitwa 3,002 m
Natural resources: limestone, unexploited deposits
of uranium, coal, and bauxite
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 20%
forests and woodland: 39%
other: 23% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation; land
degradation; water pollution from agricultural runoff,
sewage, industrial wastes; siltation of spawning
grounds endangers fish populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked','98222518cb91cea9aaddba22c0a79658272f558827e65fff339ef43537a607de','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('372e705848f72c784e2352d1dca965e46ae348be1e4c55965fdaa2afc9354785',1999,'JP','Japan','transnational-issues',688,'Disputes - international: dispute with Tanzania
over the boundary in Lake Nyasa (Lake Malawi)','9c3fcfdaf152297c735add0d3343681913951c51ae88e1fd5bb8920e85669579','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b349f5612619b18b3efcbbf38a49839d6f054b3299f148c3e571e46c44b975c2',1999,'MY','Malaysia','transnational-issues',689,'VI^TNAMf0
100 200 km
PHILIPPINE
,Kota Baharu
\\v ,
''•(George Town YKuaia Terengganu
| JP°h \\
LumuV.
Strait £ /
of \\ KUALA *Kuantan
-.Malacca \\ ^ LUMPUR
South China
Sea
Kelang
Vo
Jolo*
V
INDONESIA y
Illicit drugs: transit point for Golden T riangle heroin
going to the US, Western Europe, and the Third
World; also a money-laundering center
436','2a0007599dfc1feed7cc049aaeadeafa6ba491404e90b923f540543dd15d3dcc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf2f85924186a069f9c39a663583f0d8294c6e690fe7c1a0c33756010d8477b',1999,'MV','Maldives','transnational-issues',690,'*" y Male Atoll
Arabian . *’■,
Se-i ''*MALE
Laccadive
.ft
Addu AtolL*-
_ - Gan _
Disputes - international: none','1d033fb87e7ea84cac5fbe69e895f794ffc22f0c57d92253c71109b2b62f7ea2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1122c748dd3e60dac887f71e7612f843056191fbfa837cdec16f091e68c8bf52',1999,'MT','Malta','transnational-issues',705,'Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
total: 320 sq km
land: 320 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Washington, DC
Land boundaries: 0 km
Coastline: 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
Climate: Mediterranean with mild, rainy winters and
hot, dry summers
Terrain: mostly low, rocky, flat to dissected plains;
many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Ta''Dmejrek 253 m (near Dingli)
Natural resources: limestone, salt
Land use:
arable land: 38%
permanent crops: 3%
permanent pastures: NA%
forests and woodland: NA%
other: 59% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: very limited natural
fresh water resources; increasing reliance on
desalination
Environment - international agreements:
party to: Air Pollution, Climate Change,
307
Malta (continued)
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol
Geography - note: the country comprises an
archipelago, with only the three largest islands (Malta,
Ghawdex or Gozo, and Kemmuna or Comino) being
inhabited; numerous bays provide good harbors
Disputes - international: Malta and Tunisia are
discussing the commercial exploitation of the
continental shelf between their countries, particularly
for oil exploration
Illicit drugs: minor transshipment point for hashish
from North Africa to Western Europe
Man, Isle of
(British crown dependency)
Disputes - international: none','18659f8388862b87c00e36c884ef734c3d4a046c764d5a787a72b52aa7078742','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90fbfdb14560f52637153905241dfcbe13d4421ed34f4d29868e48da4daef502',1999,'MH','Marshall Islands','transnational-issues',713,'150 300 km
150 300 mi
North Pacific Ocean
cTaongi
1 Enewetak
Bikar
ni
r Rongerik
c'' Rongeiap — -
■ Wotho
-PL
ERATED STATES
F MICRONESIA
Kosrae
v s *
Taka
/) .Mejit
?wotno ?
^ ^ Likiep" ^Wotje
Ujae '' Ebeye ^ Maloelap
<5, -f- '' Kwajalein Enkub ''v''
" \\yNamu
v r
<Y Majuro , Amo
Ailinglapalap ''
MAJURO® Mill
Namorik ^ Jaluit
Mill
Knox
Disputes - international: claims US territory of
Wake Atoll','7604027adbeef3dda1108baaaa72a258dd06cf6bb21376cb931b6ee01670591c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5005dd87ce9e61ae07336f80c0c9f6e440e67c0690297d4e268476d5dad5b5ea',1999,'MQ','Martinique','transnational-issues',721,'(overseas department
of France)
Disputes - international: none
Illicit drugs: transit point for South American drugs
destined for the US and Europe
Saint Pierre
and Miquelon
(territorial collectivity
of France)
O 5 10 km
6 5 10 mi
Miquelon* y
{ i
\\
Miquelon
Gulf of \\r—
(Grande
St. Lawrence \\^j
\\ ■
Miquelon)
Langlade ^
lie Saint-Pierre
(Petite Miquelon) :
/ / c.
North Atlantic Ocean
/ *SAINT-PIERRE','5877fa60710b02c98a0f5c34c5c7e4408c5d37380f80cd931fb54dbd4ebda8c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca118046b91d3c90d94255912ba87441c08d02e17f817358d44a35bb9e80ee3',1999,'MR','Mauritania','transnational-issues',725,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1 ,030,700 sq km
land: 1 ,030,400 sq km
water: 300 sq km
Area - comparative: slightly larger than three times
the size of New Mexico
Land boundaries:
total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper,
phosphate
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 38%
forests and woodland: 4%
other: 58% (1993 est.)
Irrigated land: 490 sq km (1993 est.)
Natural hazards: hot, dry, dust/sand-laden sirocco
wind blows primarily in March and April; periodic
droughts
Environment - current issues: overgrazing,
deforestation, and soil erosion aggravated by drought
are contributing to desertification; very limited natural
fresh water resources away from the Senegal which is
the only perennial river
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the population
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country
Disputes - international: none
Disputes ■ international: short section of boundary
with The Gambia is indefinite
Illicit drugs: transshipment point for Southwest and
Southeast Asian heroin moving to Europe and North
America; illicit cultivator of cannabis
Serbia and','607fc8bb8be512e204405beb86a64afd94a3e609a9c1b1f23e55c76a0329d110','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('363cf9ec1495f4e928ca2dcaf690956e0365d7e774bcc33691713d7e976a8488',1999,'MU','Mauritius','transnational-issues',739,'Disputes - international: claims the Chagos
Archipelago in UK-administered British Indian Ocean
Territory; claims French-administered Tromelin Island
Illicit drugs: illicit producer of cannabis for the
international drug trade; heroin consumption and
transshipment are growing problems','0cfad4c05d9d8cfc22502a86b0c040086dd3fb8e59828d72e46dde7f03b23d5e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b59c994356ef1fbcfdb78908c106fc0888a6486124fa13000374f38c2a9125c',1999,'YT','Mayotte','transnational-issues',740,'(territorial collectivity
of France)
Chissioi
M''Zamboro
r&sif
Administered by FRANCE,
claimed by COMOROS.
%;._roe
Disputes - international: claimed by Comoros
320','22bbcd2adc643ceb313740c963aed9d478ae1a1b20d25e215271a0c9ff8a019d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc15a222d43014000d07165c98b8f72a4c76bfbbfc0238a6d773242a65ec858d',1999,'MX','Mexico','transnational-issues',752,'Disputes -international: none
Illicit drugs: illicit cultivation of opium poppy
(cultivation in 1998 - 5,500 hectares; potential
production - 60 metric tons) and cannabis cultivation
in 1998 - 4,600 hectares; government eradication
efforts have been key in keeping illicit crop levels low;
major supplier of heroin and marijuana to the US
market; continues as the primary transshipment
country for US-bound cocaine from South America;
involved in the production and distribution of
methamphetamines
Micronesia,
Federated
States of
Northern 9
350 700 km
i-TiiiipiJine . Mariana 0
350 700 mi
Ss
i * Islands
\\ (U.S.)
North
Pacific
Guam (U.s.).- 0cean Marshall
Yap
Islands
Hall
ISLANDS
/ • .
Islands
. • . ./V .
PALIKIR
C a to ! in e''"'' Islands = • \\ Pohnpei
Truk-*"
Islands
(Chuuk)
Kosrae''
Eauator
Kapingamarangi
■r"--
■'' 5 - „.. -
South Pacific
Ocean
Disputes • international: none
Illicit drugs: major illicit producer of amphetamines
for the international market; transshipment point for
Asian and Latin American illicit drugs to Western
Europe
392','ebba57d2a0466efa8ff84833b31b9f99b76eec8e4d15603ac886d91e0af3024b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ffbf580d6e3fe40d7f773a03f0b1f21bbffb63992e8f798a94ee8cc9bf6038d',1999,'US','United States','transnational-issues',753,'328
USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated
before 25 December 1991
USSR/EE
Union of Soviet Socialist Republics/Eastern Europe
V
VHF
very-high-frequency
W
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
WCO
World Customs Organization; see Customs Cooperation Council
Wetlands
Convention on Wetlands of International Importance Especially As Waterfowl
Habitat
WEU
Western European Union
WFC
World Food Council
WFP
World Food Program
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WIPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
see WToO for World Tourism Organization or WT rO for World T rade Organization
WToO
World Tourism Organization
WTrO
World Trade Organization
Y
YAR
Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for information
dated before 22 May 1990 or CY91
Z
ZC
Zangger Committee
548
Appendix B:
United Nations System
MINUGUA
MINURSO
MIPONUH
MONUA
UNDOF
UNF1CYP
UNIFIL
UNIKOM
UNMIBH
UNMOGIP
UNMOP
UN MOT
UNOMIG
UNOMIL
UNOMSIL
UNPREDEP
UNTSO
Military Staff Committee
IAEA
FAO
IBRD
IDA
IFC
ICAO
IFAD
ILO
IMF
IMO
ITU
UNESCO
UNIDO
UPU
WHO
WIPO
WMO
WTrO
Based on chart from the UN Chronicle
549
Appendix C:
International Organizations
and Groups
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development;
see newly industrializing economies (NIEs)
advanced economies
a new term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 advanced economies: Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hong
Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; nofe— this group would presumably also cover the
following seven smaller countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein, Monaco, and San
Marino which are included in the more comprehensive group of developed countries"
African, Caribbean, and Pacific
Group of States (ACP Group)
address— Avenue Georges Henri 451, B-1200
Brussels, Belgium
telephone— {32] (2) 743 06 00
FAX— [32] (2) 735 55 73
established— 1 April 1976
aim— to manage their preferential economic
and aid relationship with the EU
members— (70) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d’Ivoire, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati,
Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Papua
New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, Sudan, Suriname, Swaziland, Tanzania,
Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB)
note— also known as Banque Africaine de
Developpement (BAD)
address— 01 BP 1387, Abidjan 01, Cote d’Ivoire
telephone— [225] 20 44 44
FAX— [225] 21 77 53
established— 4 August 1963
aim— to promote economic and social
development
regional members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya,
Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger,
Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members— (25) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France,
Germany, India, Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, UAE, UK, US
Agence de Cooperation Culturelle
et Technique (ACCT)
see Agency for the French-speaking Community (ACCT)
Agence de la francophonie (ACCT)
see Agency for the French-speaking Community (ACCT)
Agency for Cultural and Technical
Cooperation (ACCT)
see Agency for the French-speaking Community (ACCT); acronym from Agence de Cooperation Culturelle et
Technique
Note: The Socialist Federal Republic of Yugoslavia (SFRY) ceases to exist. None of the successor states of the former Yugoslavia, including Serbia and Montenegro,
have been permitted to participate solely on the basis of the membership of the former Yugoslavia in the United Nations General Assembly and Economic and Social
Council and their subsidiary bodies and in various United Nations specialized agencies. The United Nations, however, permits the seat and nameplate of the SFRY to
remain, permits the SFRY mission to continue to function, and continues to fly the flag of the former Yugoslavia. For a variety of reasons, a number of other organizations
have not yet taken action with regard to the membership of the former Yugoslavia. The World Factbook therefore continues to list Yugoslavia under international
organizations where the SFRY seat remains or where no action has yet been taken.
550
Appendix C: International Organizations and Groups (continued)
Agency for the French-Speaking
Community (ACCT)
note— formerly Agency for Cultural and
Technical Cooperation
address— 13 Quai Andre-Citroen, F-75015
Paris, France
telephone— {33] (1) 44 37 33 00
FAX— {33] (1) 45 7914 98
established— 21 March 1970
name changed— 1996
aim— to promote cultural and technical
cooperation among French-speaking countries
members— {At) Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo (may have dropped out), Republic of
the Congo, Cote d''Ivoire, Djibouti, Dominica, Equatorial Guinea, France, Gabon, Guinea, Haiti, Laos, Lebanon,
Luxembourg, Madagascar, Mali, Mauritius, Moldova, Monaco, Niger, Romania, Rwanda, Sao Tome and Principe,
Senegal, Seychelles, Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associate members— (5) Egypt, Guinea-Bissau, Mauritania, Morocco, Saint Lucia
participating governments— (2) New Brunswick (Canada), Quebec (Canada)
Agency for the Prohibition of Nuclear
Weapons in Latin America and the
Caribbean (OPANAL)
note— acronym from Organismo para la
Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)
address— Temistocles 78, Col Polanco, CP
011560, Mexico City 5 DF, Mexico
telephone— {52] (5) 280 4923, 280 5064, 280
2715
FAX— [52] (5) 280 2965
established— t 4 February 1967
aim— to encourage the peaceful uses of atomic
energy and prohibit nuclear weapons
members— (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia,
Costa Rica, Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras,
Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Suriname, Trinidad and Tobago, Uruguay, Venezuela
Andean Community of Nations (CAN)
aim— formerly known as the Andean Group
(AG), the Andean Parliament, and the Andean
Common Market (Ancom)
address— do JUNAC, Pasco de la Republica
3895, Casilla 18-1177, Lima 18, Peru
fe/ephone— [51] (1) 221 2222
FAX— [51] (1) 221 3329
established— 26 May 1969
effective— 16 October 1969
aim— to promote harmonious development
through economic integration
members— (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
associate members— (1) Panama
Andean Group (AG)
see Andean Community of Nations (CAN)
Arab Bank for Economic Development
in Africa (ABEDA)
note— also known as Banque Arabe de
Developpement Economique en Afrique
(BADEA)
address— Abdel Rahman El Mahdi Avenue,
P.O. Box 2640, Khartoum, Sudan
fe/ep/rone— [249] (11) 770498, 773646, 773709
FAX— [249] (11)770600
established— 18 February 1974
effective— 16 September 1974
aim— to promote economic development
members— (1 7 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation
Organization; note— these are ail the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
551
Appendix C: International Organizations and Groups (continued)
Arab Cooperation Council (ACC)
members— (A) Egypt, Iraq, Jordan, Yemen
established— 16 February 1989
aim— to promote economic cooperation and
integration, possibly leading to an Arab
Common Market
Arab Fund for Economic and Social
Development (AFESD)
address— P. 0. Box 21923, Safat 13080, Kuwait
fe/eptone— {965] 4844500
FAX— {965] 4815750, 4815760, 4815770
established— 16 May 1968
aim— to promote economic and social
development
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt (suspended
from 1979 to 1988), Iraq (suspended 1993), Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar,
Saudi Arabia, Somalia (suspended 1993), Sudan (suspended 1993), Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arab League (AL)
note— also known as League of Arab States
(LAS)
address— Midan Attahrir, Tahrir Square, P.O.
Box 11642, Cairo, Egypt
telephone— [20] (2) 750 51 1
FAX— {20] (2) 740 331
established— 22 March 1945
aim— to promote economic, social, political, and
military cooperation
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU)
members— (5) Algeria, Libya, Mauritania, Morocco, Tunisia
address— 27 Avenue Okba Agdal, Rabat,','10d5f8c023c81d3df12df51bf86bfde8467c7cac11ac25bb736433421bcfa815','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68dcdd1759bca20a0f2a37012b8dfb12498982d2bb0b09c90904b1fbf30ad972',1999,'MN','Mongolia','transnational-issues',760,'Erdenet,
Bulgan*
.Bayanhongor
Dalandzadgad .
RUSSIA
Choybalsan.
ULAANBAATAR
Buyant-Uhaa,','07c10e3f759e7128f5f345810f70ba982504b9bb01e2b62d29d01f307f2370f6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feea03da70927d57fad69254ec8d24011f4b5c32a83489aef887d8491fb105d2',1999,'PT','Portugal','transnational-issues',771,'North
Atlantic
Ocean
SPAIN _
\\ '' Mediterranean |
Strait of Gibraltar~J^/Ceuia (Sp ,j Sea
Tangier''*’ Vetouan
RABA
Casablanc;
Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total: 92,391 sq km
land: 91 ,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 1,214 km
border countries: Spain 1 ,21 4 km
Coastline: 1,793 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime temperate; cool and rainy in north,
warmer and drier in south
Terrain: mountainous north of the Tagus River,
rolling plains in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on llha
do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork), tungsten,
iron ore, uranium ore, marble
Land use:
arable land: 26%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 36%
other: 20% (1993 est.)
Irrigated land: 6,300 sq km (1993 est.)
Natural hazards: Azores subject to severe
earthquakes
Environment - current issues: soil erosion; air
pollution caused by industrial and vehicle emissions;
water pollution, especially in coastal areas
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol,
Environmental Modification, Nuclear Test Ban,
Tropical Timber 94
Geography ■ note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar
Disputes - international: as former colonial power,
Portugal plays a key role in the issue of Indonesia''s
sovereignty over Timor Timur (East Timor Province),
which has not been recognized by the UN
Illicit drugs: important gateway country for Latin
American cocaine entering the European market;
transshipment point for hashish from North Africa to
Europe; consumer of Southwest Asian heroin','776463d0b79c8f83adc6272b08343d37e6070aa34381576dab0a84e1a322357e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71654f8cdf7ac0273aa82d2343aedb23d042a68a1fb95f4158082b7b5f628ae6',1999,'NA','Namibia','transnational-issues',786,'Disputes - international: quadripoint with
Botswana, Zambia, and Zimbabwe is in
disagreement; dispute with Botswana over
uninhabited Kasikili (Sidudu) Island in Linyanti
(Chobe) River is presently at the ICJ; at least one
other island in Linyanti River is contested','0f20cab9231f034450d15971dc8f17df5ee3913ccf774c3863d1ab27724846e7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddb90b47166841d2e3d002af91228fe084c5337162e0784a064f9de7a1b502b9',1999,'NR','Nauru','transnational-issues',787,'Location: Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area - comparative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim 61
m
Natural resources: phosphates
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: periodic droughts
Environment - current issues: limited natural fresh
water resources, roof storage tanks collect rainwater;
intensive phosphate mining during the past 90 years -
mainly by a UK, Australia, and New Zealand
consortium - has left the central 90% of Nauru a
wasteland and threatens limited remaining land
resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping
signed, but not ratified: none of the selected
agreements
Geography - note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia; only 53 km south of
Equator
Disputes - international: none
342
Disputes - international: claimed by Haiti
343','cbd7755ffb7302b876e081a4e1218d626814f37957b3893999c76cef1c81b3ff','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35907540223893b68637263a9ac05195b4885c7b92e7cc7bf6d97a71281805ab',1999,'NL','Netherlands','transnational-issues',799,'O 25 50 km
25 50 mi
m j i Den -
North Holder*.
Sop. !
The Hague/
T)elfzijlwL-^
; Leeuwarden ’Groningen
’Assen >
Europoort
•Dordrecht "• Nijmegen'' J
riZZgSZ Tilburg.
Antilles
(part of the Kingdom of
the Netherlands)
O 10 20 km
O 10 20 mi
CsinbbOrin
Son
Saint-Martin ^
(FRANCE >
''''r><JSint
Philipsburg Maarten
Islands not shown
Saba in true geographical
;> position.
Sint
Eustatius ''■-J
.Westpunt
Curasao
f''\\ Bonaire
WILLEMSTAD*'' V.
Kralendijk )
\\j
<) Klein
Curasao
Disputes - international: none
Illicit drugs: money-laundering center;
transshipment point for South American drugs bound
for the US and Europe','43b76f9557e53ff75dc78e71c1d23f0a345282689fa6391a9b9a01c1832477c5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47f3bc960d2df055838e7fad0eba8ca334fbf5fcd5bec29ee0bcc39cb8060647',1999,'BE','Belgium','transnational-issues',800,'Maastricht
Disputes - international: none
Illicit drugs: important gateway for cocaine, heroin,
and hashish entering Europe; major European
producer of illicit amphetamines and other synthetic
drugs
telephone— {32] (2) 230 62 95
FAX— [32] (2) 230 87 22
established— 19 June 1920 as the International
Federation of Christian Trade Unions (IFCTU),
renamed 4 October 1968
aim— to promote the trade union movement
members— (99 national organizations) Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, Austria,
Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire Island, Botswana, Brazil, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cuba, Curacao, Cyprus, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana,
Gabon, The Gambia, Ghana, Grenada, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Indonesia, Iran, Italy, Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg, Madagascar, Malaysia, Mali,
Malta, Martinique, Mauritius, Mexico, Montserrat, Namibia, Netherlands, Nicaragua, Niger, Nigeria, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Martin, Saint Vincent and the Grenadines, Senegal, Seychelles, Sierra Leone, Spain, Sri Lanka,
Suriname, Switzerland, Taiwan, Tanzania, Thailand, Togo, UK, US, Uruguay, Venezuela, Vietnam, Zambia,','c33d55a632f0b59422f58cc8df7d940b80709d562fc71f9c70cf1b6474788f57','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07442348cc34c14f07f3aaaa3cb94bfa19c45cc04c071674bea943a1d743fe3',1999,'NZ','New Zealand','transnational-issues',816,'Antipodes Islands, Auckland
Islands, Bounty Islands,
Campbell Island, Chatham
Islands, and Kermadec
Islands are not shown.
South Pacific
Ocean
Auckland)-. ;"'';:
Hamilton. .Tauranga .
t ■'' r
North Island j Gisb0m e.J
New Plymouth*
4''Napier
Cooi\\\\ /
*t ir-},( •Palmerston
( j J Ndrth
) w’ ;Y^ELL,NGT0N
f /
Greymouth. .
South Island .Christchurch
,■:? South Pacific
Invercargill. , ''Dunedin Ocean
Stewart
Island
O 150 300 km
O 150 300 ml
Disputes - international: territorial claim in
Antarctica (Ross Dependency)
354
O
■
Disputes -international: none
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; producer of
cannabis
Tromelin Island H H
(possession of France) Si ’fg|
0
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
ODA
official development assistance
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OIC
Organization of the Islamic Conference
ONUMOZ
see United Nations Operation in Mozambique (UNOMOZ)
ONUSAL
United Nations Observer Mission in El Salvador
OOF
other official flows
OPANAL
Organismo para la Proscripcion de las Armas Nucleares en la America Latina y el
Caribe; see Agency for the Prohibition of Nuclear Weapons in Latin America and
the Caribbean
OPCW
Organization for the Prohibition of Chemical Weapons
OPEC
Organization of Petroleum Exporting Countries
OSCE
Organization on Security and Cooperation in Europe Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
P
PCA
Permanent Court of Arbitration
PDRY
People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen]; used
for information dated before 22 May 1990 or CY91
PFP
Partnership for Peace
R
Ramsar
see Wetlands
RG
Rio Group
S
SAARC
South Asian Association for Regional Cooperation
SACU
Southern African Customs Union
SADC
Southern African Development Community _
546
Appendix A: Abbreviations (continued)
SADCC
Southern African Development Coordination Conference; see Southern African
Development Community (SADC)
SELA
Sistema Economico Latinoamericana; see Latin American Economic System
(LAES)
SFRY
Socialist Federal Republic of Yugoslavia; dissolved 5 December 1991
SHF
super-high-frequency
Ship Pollution
Protocol of 1978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
Sparteca
South Pacific Regional Trade and Economic Cooperation Agreement
SPC
South Pacific Commission
SPF
South Pacific Forum
sq km
square kilometer
sq mi
square mile
T
TAT
Trans-Atlantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
U
UAE','0fbdadb14aa15c0fca41510841089c69decafbca656d240408ca9bcb4d7ea1d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9621f74a72e7d6fe827f006f39cc9d55b64ebd9cd4f93e59f5e0ab1be0f3649a',1999,'NE','Niger','transnational-issues',830,'Disputes - international: Libya claims about 1 9,400
sq km in northern Niger; delimitation of international
boundaries in the vicinity of Lake Chad, the lack of
which led to border incidents in the past, is completed
and awaits ratification by Cameroon, Chad, Niger, and','b0a4e8daac4ca2ddcfce3e6ba69e90df948cf17a3122f5527fae3f974c25da56','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fc3f05d42192767d2215dc189eb7256ed457bd60fb43b03a8e96e1e87c25524',1999,'PA','Panama','transnational-issues',853,'Disputes - international: none
Illicit drugs: major cocaine transshipment point and
major drug-money-laundering center; no recent signs
of coca cultivation; monitoring of financial transactions
is improving','8111f8871ac36336846e1bf3a546bb2cbafff54837ce778469bdb0c72210b724','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7dc5e159ca69e1658b9b022d879024b6d891b71aa5aa2c08b0a94abb9a815a4',1999,'PH','Philippines','transnational-issues',855,'Disputes - international: none
Population: no indigenous inhabitants
note: there are scattered Chinese garrisons
Disputes - international: occupied by China, but
claimed by Taiwan and Vietnam
381
Disputes - international: all of the Spratly Islands
are claimed by China, Taiwan, and Vietnam; parts of
them are claimed by Malaysia and the Philippines; in
1984, Brunei established an exclusive fishing zone,
which encompasses Louisa Reef in the southern
Spratly Islands, but has not publicly claimed the island','ea1102c6b07021878b0c4e8dccee387bbbf1a137f54a471f6ed5a308daca2db6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d4479110e1dd088ac61b501bae123a96c3702c06c062694cc1d20993e55305',1999,'PR','Puerto Rico','transnational-issues',866,'(commonwealth associated with the US)
Disputes - international: none
524
Wake Atoll
(territory of the US)','dc95fd252bc29877269fa7abd892974ae2cf3d99030e3f0471e38da52bd4b584','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e0bf9983a79e4e4cc32a99094acb4c7bf4faf5d5a4d2d8fbe53b8eb10a4945',1999,'QA','Qatar','transnational-issues',876,'Disputes - international: territorial dispute with
Bahrain over the Hawar Islands and maritime
boundary dispute with Bahrain currently before the
International Court of Justice (ICJ); in 1996, agreed
with Saudi Arabia to demarcate border per 1992
accord; that process is ongoing
Reunion
(overseas department
of France)','b60c1272dff271c1d0e42d3c58bdbf48a0c38fc4247de270c8e7eaf8c7b4d6d4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0621a2556e32430bc649c7f835404d16b1b5c2301a5c81617793115df449f4a1',1999,'UA','Ukraine','transnational-issues',885,'Disputes - international: dispute with Ukraine over
continental shelf of the Black Sea under which
significant gas and oil deposits may exist; agreed in
1 997 to two-year negotiating period, after which either
party can refer dispute to the International Court of
Justice
Illicit drugs: important transshipment point for
Southwest Asian heroin transiting the Balkan route
and small amounts of Latin American cocaine bound
for Western Europe
Russia
Disputes - international: dispute over at least two
small sections of the boundary with China remain to
be settled, despite 1 997 boundary agreement; islands
of Etorofu, Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Caspian
Sea boundaries are not yet determined among
Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan; Estonian and Russian negotiators
reached a technical border agreement in December
1996 which has not been ratified; draft treaty
delimiting the boundary with Latvia has not been
signed; has made no territorial claim in Antarctica (but
has reserved the right to do so) and does not
recognize the claims of any other nation; 1997 border
agreement with Lithuania not yet ratified; Svalbard is
the focus of a maritime boundary dispute in the
Barents Sea between Norway and Russia
Illicit drugs: limited cultivation of illicit cannabis and
opium poppy and producer of amphetamines, mostly
for domestic consumption; government has active
eradication program; increasingly used as
transshipment point for Southwest and Southeast
Asian opiates and cannabis and Latin American
cocaine to Western Europe, possibly to the US, and
growing domestic market
406
Disputes - international: Rwandan military forces
are supporting the rebel forces in the civil war in the
Democratic Republic of the Congo
Saint Helena S
(overseas territory
of the UK) fSH
O 400 km
Ascension
St. Helena
★
JAMESTOWN
South Atlantic Ocean
TRISTAN DA CUNHA
Inaccessible
Island \\ _ Tristan da Cunha
Nightingale
Islands
Gough Island
Disputes - international: none
410
Saint Kitts
and Nevis
Disputes - international: dispute with Romania
over continental shelf of the Black Sea under which
significant gas and oil deposits may exist; agreed in
1 997 to two-year negotiating period, after which either
party can refer dispute to the International Court of
Justice (ICJ); has made no territorial claim in
Antarctica (but has reserved the right to do so) and
does not recognize the claims of any other nation
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; some
synthetic drug production for export to West; limited
government eradication program; used as
transshipment point for opiates and other illicit drugs
from Africa, Latin America, and T urkey, and to Europe
and Russia; drug-related money laundering a minor,
but growing, problem
502
observers— (7) Austria, Egypt, Israel, Italy, Poland, Slovakia, Tunisia
Caribbean Community and Common Market
(Caricom)
address— Caricom, P.O. Box 10827, Bank of
Guyana Building, 3rd floor, Avenue of the
Republic, Georgetown, Guyana
fe/ep/ione— [592] (2) 69281 through 69289
FAX— {592] (2) 66091 , 67816, 57341
established— A July 1 973
effective— 1 August 1973
aim— to promote economic integration and
development, especially among the less
developed countries
members— ( 14) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Jamaica,
Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members— (2) British Virgin Islands, Turks and Caicos Islands
observers— (11) Anguilla, Aruba, Bermuda, Cayman Islands, Colombia, Dominican Republic, Haiti, Mexico,
Netherlands Antilles, Puerto Rico, Venezuela
Caribbean Development Bank (CDB)
address— P.O. Box 408, Wildey, St. Michael,
Protocol to the 1 979 Convention on Long-Range
Transboundary Air Pollution Concerning the
Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
parties— (26) Austria, Belarus, Bulgaria, Canada, Czech Republic, Denmark, EU, Finland, France, Germany,
Greece, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Spain,
Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified— (2) Belgium, Poland
note— abbreviated as Air Pollution-Nitrogen Oxides
opened for signature— 31 October 1988
entered into force— 1 4 February 1991
objective— to provide for the control or reduction of
nitrogen oxides and their transboundary fluxes
Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
parties— (17) Austria, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (7) Belgium, Canada, EU, Greece, Portugal, Ukraine, US
note— abbreviated as Air Pollution-Volatile Organic
Compounds
opened for signature— 18 November 1991
entered into force— 29 September 1997
objective— to provide forthe control and reduction of
emissions of volatile organic compounds in order to
reduce their transboundary fluxes so as to protect
human health and the environment from adverse
effects
Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on Further
Reduction of Sulphur Emissions
note— abbreviated as Air Pollution-Sulphur 94
opened for signature— 14 June 1994
entered into force— 5 August 1998
objective— to provide for a further reduction in sulfur
emissions or transboundary fluxes
parties— ( 21) Austria, Canada, Czech Republic, Denmark, EU, Finland, France, Germany, Greece, Ireland,
Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (7) Belgium, Bulgaria, Croatia, Hungary, Poland, Russia,
606
Appendix D: Selected International Environmental Agreements (continued)
Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on Persistent
Organic Pollutants
note— abbreviated as Air Pollution-Persistent
Organic Pollutants
opened for signature— 24 June 1 998, but not yet in
force
objective— to provide for the control and reduction of
emissions of persistent organic pollutants in order to
reduce their transboundary fluxes so as to protect
human health and the environment from adverse
effects
part/e— ( 1) Canada
countries that have signed, but not yet ratified— (35) Armenia, Austria, Belgium, Bulgaria, Croatia, Cyprus,
Czech Republic, Denmark, EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, Moldova, Netherlands, Norway, Poland, Portugal, Romania, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Ukraine, UK, US
Protocol to the 1 979 Convention on Long-Range
Transboundary Air Pollution on the Reduction of
Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
parties— (21) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Finland, France,
Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden,
Switzerland, Ukraine
nofe— abbreviated as Air Pollution-Sulphur 85
opened for signature— 8 July 1985
entered into force— 2 September 1987
objective— to provide for a 30% reduction in sulfur
emissions or transboundary fluxes by 1993
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973
(MARPOL)
Treaty Banning Nuclear Weapon Tests in the
Atmosphere, in Outer Space, and Under Water
nofe— abbreviated as Nuclear Test Ban
opened for signature— 5 August 1963
entered into force— 10 October 1963
objective— to obtain an agreement on general and
complete disarmament under strict international
control in accordance with the objectives of the
United Nations; to put an end to the armaments race
and eliminate incentives for the production and
testing of all kinds of weapons, including nuclear
weapons
parties— ( 122) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas,
Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burma, Canada, Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Liberia, Libya, Luxembourg, Madagascar, Malawi, Malaysia, Malta, Mauritania,
Mauritius, Mexico, Mongolia, Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San Marino,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Yemen, former Yugoslavia, Zambia
countries that have signed, but not yet ratified— (12) Algeria, Burkina Faso, Burundi, Cameroon, China, Ethiopia,
Haiti, Mali, Paraguay, Portugal, Somalia, Vietnam
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
607
Appendix D: Selected International Environmental Agreements (continued)
United Nations Convention on the Law of the
Sea (LOS)
note— abbreviated as Law of the Sea
opened for signature— 10 December 1982
entered into force— 1 6 November 1 994
objective— to set up a comprehensive new legal
regime for the sea and oceans; to include rules
concerning environmental standards as well as
enforcement provisions dealing with pollution of the
marine environment
parties— (130) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burma,
Cameroon, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Laos, Lebanon, The Former Yugoslav Republic of Macedonia, Malaysia, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda, UK, Uruguay, Vietnam,
Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (40) Afghanistan, Bangladesh, Belarus, Bhutan, Burkina Faso,
Burundi, Cambodia, Canada, Central African Republic, Chad, Colombia, Republic of the Congo, Denmark,
Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea, Lesotho, Liberia, Libya, Liechtenstein,
Luxembourg, Madagascar, Malawi, Maldives, Morocco, Nicaragua, Niger, Niue, Qatar, Rwanda, Swaziland,
Switzerland, Thailand, Tuvalu, Ukraine, UAE, Vanuatu
United Nations Convention to Combat
Desertification in Those Countries Experiencing
Serious Drought and/or Desertification,
Particularly in Africa
note— abbreviated as Desertification
opened for signature— 1 4 October 1 994
entered into force— 26 December 1996
objective— to combat desertification and mitigate
the effects of drought through national action
programs that incorporate long-term strategies
supported by international cooperation and
partnership arrangements
parlies— (148) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Austria, Azerbaijan,
Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Paraguay, Peru, Portugal, Romania,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Togo, Tonga, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, United
Arab Emirates, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (9) Australia, Colombia, Republic of the Congo, Croatia,
Georgia, South Korea, Philippines, US, Vanuatu
United Nations Framework Convention on
Climate Change
note— abbreviated as Climate Change
opened for signature— 9 May 1 992
entered into force— 21 March 1994
objective— to achieve stabilization of greenhouse
gas concentrations in the atmosphere at a low
enough level to prevent dangerous anthropogenic
interference with the climate system
parties— ( 177) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (7) Afghanistan, Angola, Belarus, Liberia, Libya, Madagascar,','60aa6dbc45ab0c528e4b978634e549e54b67aa61d08ac97c0f257710a678589c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04db29c748b7700316c81680beff1026ac7f2eba76b9a85d26476e5ae0ccb993',1999,'TT','Trinidad and Tobago','transnational-issues',895,'Disputes - international: none
Illicit drugs: transshipment points for South
American drugs destined for the US','1ee5de1de3d2805006e246f9154c49e02b72794c01c72ecabfc43a56baa07902','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bf764bf90aea5f8e5703acaea230a9c6b59caaa918514418d94deba4115caee',1999,'IT','Italy','transnational-issues',911,'Disputes -international: none
Sao Tome
and Principe
Disputes - international: none
Illicit drugs: because of more stringent government
regulations, used significantly less as a
money-laundering center; transit country for and
consumer of South American cocaine and Southwest
Asian heroin
467
Syria
Disputes - international: Golan Heights is Israeli
occupied; dispute with upstream riparian Turkey over
Turkish water development plans for the Tigris and
Euphrates Rivers; Syrian troops in northern, central,
and eastern Lebanon since October 1976
Illicit drugs: a transit point for opiates and hashish
bound for regional and Western markets
Entry
follows
telephone— [39] (6) 54591
FAX— [39] (6) 5043463
established— NA November 1974
aim— to promote agricultural development; a UN
specialized agency
members— (175) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
associate members— {A) Comoros, Cyprus, Gabon, Tuvalu
members— (174) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
members— { 160)
Category I— (22 industrialized aid contributors) Australia, Austria, Belgium, Canada, Denmark, Finland, France,
Germany, Greece, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Noway, Portugal, Spain, Sweden,
Switzerland, UK, US
Category II— (12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Category /// — (126 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia,
Azerbaijan, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d’Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos,
Lebanon, Lesotho, Liberia, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
575
Appendix C: International Organizations and Groups (continued)
International Hydrographic Organization
(IHO)
nofe— name changed from International
Hydrographic Bureau on 22 September 1970
address— BP 445, 4 Quai Antoine 1st, Monaco
MC 98011, CEDEX, Monaco
telephone— {33] (93) 01 81 00
FAX— (33] (93) 10 81 40
established— HA June 1919
effective— NA June 1921
aim— to train hydrographic surveyors and
nautical cartographers to achieve
standardization in nautical charts and electronic
chart displays; to provide advice on nautical
cartography and hydrography; to develop the
sciences in the field of hydrography and
techniques used for descriptive oceanography
members— (64) Algeria, Argentina, Australia, Bahrain, Belgium, Brazil, Canada, Chile, China, Democratic Republic
of the Congo, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt, Estonia, Fiji, Finland, France,
Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran, Italy, Japan, North Korea, South Korea, Malaysia,
Monaco, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland,
Portugal, Russia, Singapore, South Africa, Spain, Sri Lanka, Suriname, Sweden, Syria, Thailand, Tonga, Trinidad
and Tobago, Tunisia, Turkey, UAE, UK, US, Uruguay, Venezuela, Yugoslavia
membership pending— { 10) Bangladesh, Bulgaria, Colombia, Jamaica, Kuwait, Mauritania, Morocco, Mozambique
Qatar, Ukraine
International Investment Bank (MB)
established on 7 July 1970; to promote economic development; members were Bulgaria, Cuba, Czechoslovakia,
East Germany, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian bank with a new charter
International Labor Organization (ILO)
address— International Labor Office, 4 route des
Morillons, CH-1211 Geneva 22, Switzerland
fe/epbone— [41](22)799 61 11
FAX— [41] (22) 798 86 85
established—1 11 April 1919 (affiliated with the
UN 14 December 1946)
a/m— to deal with world labor issues; a UN
specialized agency
members— (174) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Noway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
International Maritime Organization (IMO)
note— name changed from Intergovernmental
Maritime Consultative Organization (IMCO) on
22 May 1982
address— 4 Albert Embankment, London SE1
7SR, UK
fe/ephone— [44] (171) 735 7611
FAX— [44] (171) 587 3210
established— 17 March 1958
aim— to deal with international maritime affairs;
a UN specialized agency
members— (155) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Brunei,
Bulgaria, Burma, Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended)
associate members— (2) Hong Kong, Macau
International Maritime Satellite
Organization (Inmarsat)
see International Mobile Satellite Organization (Inmarsat)
576
Appendix C: International Organizations and Groups (continued)
International Mobile Satellite Organization
(Inmarsat)
note— formerly International Maritime Satellite
Organization
address— 99 City Road, London EC1Y 1 AX, UK
telephone— [44] (171) 728 1212
FAX— (44](171)728 1602
established— 3 September 1976
effective— 26 July 1979
aim— to provide worldwide communications for
commercial, distress, and safety applications, at
sea, in the air, and on land
International Monetary Fund (IMF)
address— 700 19th Street NW, Washington, DC
20431, US
telephone— {1] (202) 623 7000
FAX— [1] (202) 623 4661 , 623 7491 , 623 4662
established— 22 July 1944
effective— 21 December 1945
aim— to promote world monetary stability and
economic development; a UN specialized
agency
International Olympic Committee (IOC)
note— there are 194 National Olympic
Committees of which 1 85 are recognized by the
International Olympic Committee
address— Chateau de Vidy, CH-1007
Lausanne, Switzerland
fe/ephone— [41](21)621 61 11
FAX— (41] (21) 621 6216
established— 23 June 1894
aim— to promote the Olympic ideals and
administer the Olympic games: 2000 Summer
Olympics in Sydney, Australia; 2002 Winter
Olympics in Salt Lake City, United States; 2004
Summer Olympics in Athens, Greece
members— (81 ) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Brazil, Brunei,
Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Egypt, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Israel, Italy, Japan, South Korea, Kuwait, Lebanon, Liberia, Malaysia, Malta, Marshall Islands, Mauritius,
Mexico, Monaco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Singapore, Slovakia, South Africa, Spain, Sri
Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UAE, UK, US, Yugoslavia
members— { 182) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palua, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
National Olympic Committees— (1 96 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria,
American Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, Netheriands Antilles, NZ, Nicaragua, Niger, Nigeria, Noway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen,
Yugoslavia (Serbia and Montenegro), Zambia, Zimbabwe, Palestine Liberation Organization
577
Appendix C: International Organizations and Groups (continued)
International Organization for Migration
(IOM)
note— established as Provisional
Intergovernmental Committee for the Movement
of Migrants from Europe; renamed
Intergovernmental Committee for European
Migration (ICEM) on 15 November 1952;
renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current
name adopted 14 November 1989
address— 17 route des Morillons, CP 71,
CH-1211 Geneva 19, Switzerland
telephone— [A]] (22) 717 91 11
FAXH41] (22) 798 61 50
established— 5 December 1951
aim— to facilitate orderly international emigration
and immigration
International Organization for
Standardization (ISO)
address— CP 56, 1 Rue de Varembe, CH-121 1
Geneva 20, Switzerland
fe/ep/rone— {41] (22) 749 01 11
F/4X— [41] (22) 733 34 30
established— HA February 1947
aim— to promote the development of
international standards with a view to facilitating
international exchange of goods and sen/ices
and to developing cooperation in the sphere of
intellectual, scientific, technological and
economic activity
International Red Cross and Red Crescent
Movement (ICRM)
address— CICR, 19 Avenue de la Paix,
CH-1202 Geneva, Switzerland
fe/ep/rone— [41] (22) 734 60 01
FAX— [41] (22) 733 20 57
established— HA 1928
aim— to promote worldwide humanitarian aid
through the International Committee of the
Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent
Societies (IFRCS; formerly League of Red
Cross and Red Crescent Societies or LORCS)
in peacetime
members— (60) Albania, Angoia, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Bolivia, Bulgaria,
Canada, Chile, Colombia, Costa Rica, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Finland, France, Germany, Greece, Guatemala, Haiti, Honduras, Hungary, Israel, Italy, Japan,
Kenya, South Korea, Liberia, Luxembourg, Netherlands, Nicaragua, Norway, Pakistan, Panama, Paraguay, Peru,
Philippines, Poland, Portugal, Senegal, Slovakia, South Africa, Sri Lanka, Sweden, Switzerland, Tajikistan,
Thailand, Uganda, US, Uruguay, Venezuela, Zambia
observers— (49) Afghanistan, Belarus, Belize, Bosnia and Herzegovina, Brazil, Cape Verde, Democratic Republic
of the Congo, Cuba, Georgia, Ghana, Guinea, Guinea-Bissau, Holy See, India, Indonesia, Iran, Ireland, Jamaica,
Jordan, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Madagascar, Malta, Mexico, Moldova, Morocco, Mozambique,
Namibia, NZ, Romania, Russia, Rwanda, San Marino, Sao Tome and Principe, Slovenia, Somalia, Spain, Sudan,
Tanzania, Tunisia, Turkey, Turkmenistan, Ukraine, UK, Vietnam, Yugoslavia, Zimbabwe
members— (85 national standards organizations) Albania, Algeria, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Colombia, Costa
Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Finland, France, Germany,
Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Kenya, North Korea,
South Korea, Libya, The Former Y ugoslav Republic of Macedonia, Malaysia, Mauritius, Mexico, Mongolia, Morocco,
Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines, Poland, Portugal, Romania, Russia, Saudi
Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania,
Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yugoslavia, Zimbabwe
correspondent members— (32) Bahrain, Barbados, Bolivia, Botswana, Brunei, Cote d''Ivoire, El Salvador, Estonia,
Georgia, Guatemala, Guinea, Hong Kong, Jordan, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lithuania, Malawi, Malta,
Moldova, Mozambique, Nepal, Oman, Papua New Guinea, Paraguay, Peru, Qatar, Sudan, Turkmenistan, Uganda,
UAE
subscriber members— ( 10) Antigua and Barbuda, Benin, Bolivia, Cambodia, Dominican Republic, Fiji, Grenada,
Guyana, Namibia, Saint Lucia
National Societies— (175 countries) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland,
France, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Sain','39fefc66709a57d699633e25a4285f5beb86591b5f8d879e858a1d27f07166dc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73ed5717688663b17dffd5170d4e0a6d5d8f30454f1bb298217fbd75d2575138',1999,'IT','Italy','transnational-issues',912,'t Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia, Zambia, Zimbabwe
578
Appendix C: International Organizations and Groups (continued)
International Telecommunication Union (ITU)
address— Place des Nations, CH-121 1 Geneva
20, Switzerland
fe/ep/rone— [41] (22) 730 6184
FAX— [41] (22) 733 7256, 730 6614
established— 9 December 1932
effective—'' 1 January 1934
affiliated with the UN—td November 1947
aim— to deal with world telecommunications
issues; a UN specialized agency
members— { 188) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
International Telecommunications Satellite
Organization (Intelsat)
address— Intelsat, 3400 International Drive NW,
Washington, DC 20008-3098, US
telephone— {t] (202) 944 7500
FAX— [1] (202) 944 7890
established— 20 August 1971
effective— 12 February 1973
aim— to develop and operate a global
commercial telecommunications satellite system
members— (1 42) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal,
Singapore, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
nonsignatory users— (43) Albania, Antigua and Barbuda, Belarus, Belize, Burma, Burundi, Cambodia, Comoros,
Cook Islands, Cuba, Djibouti, Eritrea, The Gambia, Guinea-Bissau, Guyana, Kiribati, North Korea, Laos, Latvia,
Lesotho, Liberia, Lithuania, The Former Yugoslav Republic of Macedonia, Maldives, Marshall Islands, Moldova,
Nauru, Niue, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Seychelles, Sierra
Leone, Slovakia, Slovenia, Solomon Islands, Suriname, Tonga, Turkmenistan, Tuvalu, Ukraine, Vanuatu
Islamic Development Bank (IDB)
address— P. O. Box 5925, Jeddah 21432, Saudi
Arabia
telephone— {966] (2) 6361400
FAX-[966] (2) 6366871
established— 15 December 1973
aim— to promote Islamic economic aid and
social development
members— (48 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives,
Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone,
Somalia, Sudan, Syria, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen, Palestine Liberation Organization
579
Appendix C: Internationa! Organizations and Groups (continued)
Latin American Economic System (LAES)
note— also known as Sistema Economico
Latinoamericana (SELA)
address— SELA, Avda Francisco de Miranda,
Torre Europa, Piso 4, Chacaito, Apartado de
Correos 17035, Caracas 1010-A, Venezuela
telephone— {58] (2) 905 5111
FAX— {58] (2) 951 6953, 951 7246
established— 17 October 1975
aim— to promote economic and social
development through regional cooperation
members— (27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
Panama, Paraguay, Peru, Suriname, Trinidad and Tobago, Uruguay, Venezuela
Latin American Integration Association
(LAIA)
note— also known as Asociacion
Latinoamericana de Integracion (ALADI)
address— Calle Cebollati 1461, Casilla de
Correo 577, 11000 Montevideo, Uruguay
telephone— {598] (2) 400 1 1 21 , 409 59 1 5
FAX— [598] (2) 409 06 49
established— 12 August 1980
effective— 18 March 1981
aim— to promote freer regional trade
members— (11) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay,
Venezuela
observers— (20) China, Commission of the European Communities, Costa Rica, Dominican Republic, El Salvador,
Guatemala, Honduras, Inter-American Development Bank, Italy, Nicaragua, Organization of American States,
Panama, Portugal, Romania, Russia, Spain, Switzerland, United Nations Development Program, United Nations
Economic Commission for Latin America and the Caribbean
League of Arab States (LAS)
see Arab League (AL)
League of Red Cross and Red Crescent
Societies (LORCS)
see International Federation of Red Cross and Red Crescent Societies (IFRCS)
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as
having no significant economic growth, per capita GDPs normally less than $1,000, and low literacy rates; also
known as the undeveloped countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, SaoTome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
580
Appendix C: International Organizations and Groups (continued)
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and often less than $1 ,500; however, the
group also includes a number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of growth; includes the advanced developing countries, developing countries, Four Dragons (Four Tigers),
least developed countries (LLDCs), low-income countries, middle-income countries, newly industrializing
economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto
Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia,
Zimbabwe; note— similar to the new International Monetary Fund (IMF) term "developing countries" which adds
Malta, Mexico, South Africa, and Turkey but omits in its recently published statistics American Samoa, Anguilla,
British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint
Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and
Futuna, West Bank, Western Sahara
low-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries
(LDCs)
London Suppliers Group
see Nuclear Suppliers Group (NSG)
Mercado Comun del Cono Sur (Mercosur)
see Southern Cone Common Market
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries
(LDCs)
Missile Technology Control Regime (MTCR)
established— 16 April 1987
aim— to arrest the proliferation of missiles
(unmanned delivery vehicles of mass
destruction) by controlling the export of key
missile technologies and equipment
members— (28) Argentina, Australia, Austria, Belgium, Brazil, Canada, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UK, US
Near Abroad
Russian term for the 1 4 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in
which Moscow has expressed a strong national security interest; the 1 4 countries are Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,','0aa8acef5d45719f332f09c5130bd9c2e866829d0f667a41e66de2668087c694','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43c336c6e75bd349b628e232ebc706abb0306186a397473407e38d7e8e4e01a8',1999,'SA','Saudi Arabia','transnational-issues',919,'Disputes - international: large section of boundary
with Yemen not defined; location and status of
boundary with UAE is not final, de facto boundary
reflects 1974 agreement; Kuwaiti ownership of Qaruh
and Umm al Maradim islands is disputed by Saudi
Arabia; in 1996, agreed with Qatar to demarcate
border per 1992 accord; that process is ongoing
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin and cocaine','5daa836411e12ce49b84329b64f92b5081e3667730c48507ae2d136354d33b47','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ffd517b15745ebba07db5974458248ce27c593b0cd73d8b62b5714d3b46d36c',1999,'ME','Montenegro','transnational-issues',921,'Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiere Africaine
francs (CFAF) per US$1 - 560.01 (December 1998),
589.95 (1998), 583.67 (1997), 511.55 (1966), 499.15
(1995), 555.20(1994)
Fiscal year: calendar year
Disputes - international: disputes with Bosnia and
Herzegovina over Serbian populated areas; Albanian
majority in Kosovo seeks independence from Serbian
republic; Serbia and Montenegro is disputing Croatia''s
claim to the Prevlaka Peninsula in southern Croatia
because it controls the entrance to Boka Kotorska in
Montenegro; Prevlaka is currently under observation
by the UN military observer mission in Prevlaka
(UNMOP); the border commission formed by The
Former Yugoslav Republic of Macedonia and Serbia
and Montenegro in April 1 996 to resolve differences in
delineation of their mutual border has made no
progress so far
Illicit drugs: major transshipment point for
Southwest Asian heroin moving to Western Europe on
the Balkan route','508f37733c5ce5cdadfa573bacd63a9acc0f72a99a06ac34f5519f22f729e612','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ec807de12a3f581bb3cb409e116c6755a5fd590a115f91909af11948d02b14',1999,'SC','Seychelles','transnational-issues',930,'O 100 200 km
6 100 200 mi
VICTORIA®^.
Les
Mah£
Amirantes
Groupe
d''Aldabra
/
^ Atoll de
■*-, Atoll de
Coetivy
Cosmoledo
Farquhar
Disputes - international: claims Chagos
Archipelago in British Indian Ocean Territory','e2a2924fe91b9cf920780915135b4ef0fda567d2b8c85a9447cee25eaed3ff50','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d56a93c8e30211360c8935c09c03b846bb67a23669a722551af5c24f0019f1a',1999,'SL','Sierra Leone','transnational-issues',938,'Background: On 25 May 1997, the
democratically-elected government of President
Ahmad Tejan KABBAH was overthrown by a
disgruntled coalition of army personnel from the
Armed Forces Revolutionary Council (AFRC) and the
Revolutionary United Front (RUF) under the
command of Major Johnny Paul KOROMA; President
KABBAH fled to exile in Guinea. The Economic
Community of West African States Cease-Fire
Monitoring Group (ECOMOG) forces, led by a strong
Nigerian contingent, undertook the suppression of the
rebellion. They were initially unsuccessful, but, by
October 1997, they forced the rebels to agree to a
cease-fire and to a plan to return the government to
democratic control. President KABBAH returned to
office on 10 March 1998 to face the task of restoring
order to a demoralized population and a disorganized
and severely damaged economy. Many of the leaders
of the coup were tried and executed in October 1998.
In January 1999, the situation had deteriorated even
further, with commerce at a standstill, hundreds of
thousands of people driven from their homes, and
bitter fighting between the AFRC/RUF and ECOMOG
troops intensifying by large-scale import of arms.
Disputes - international: none','cd3dc4fa8794ab54126fdbee8e606f85ccb779ad65fcb901dba60b54fb4f329a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b04c2f6bf722cf7be622fe84b7f1e6986841e19c8997c118e66a57669ca3f634',1999,'SK','Slovakia','transnational-issues',945,'Background: After centuries under foreign rule,
mainly by Hungary, the Slovaks joined with their
neighbors to form the new nation of Czechoslovakia in
1918. Following the chaos of World War II,
Czechoslovakia became a communist nation within
Soviet-ruled Eastern Europe. Soviet influence
collapsed in 1989, and Czechoslovakia once more
was an independent country turning toward the West.
The Slovaks and the Czechs agreed to separate
peacefully on 1 January 1993. Slovakia has
experienced more difficulty than the Czech Republic
in developing a modern market economy.
Disputes - international: ongoing Gabcikovo Dam
dispute with Hungary is before the International Court
of Justice; unresolved property issues with Czech
Republic over redistribution of former Czechoslovak
federal property
Illicit drugs: minor, but increasing, transshipment
point for Southwest Asian heroin and hashish bound
for Western Europe','9138bb4cdaccb7870bb6d2416323b397b6a7a1ef0dbe546c370a0672214a5c86','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9325e230d0d70990c9765e3d9fb201eb83897de013f30d7e80aeafd082c63315',1999,'SB','Solomon Islands','transnational-issues',955,'Disputes - international: significant progress has
been made with Croatia toward resolving a maritime
border dispute over direct access to the sea in the
Adriatic; Italy and Slovenia made progress in
resolving bilateral issues
Illicit drugs: transit point for Southwest Asian heroin
bound for Western Europe and for precursor
chemicals
Disputes - international: none','c2b24b53918b46fbcb409ee8bb337b1574af2f14945745b4b352f99e32225468','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5031998807e0077b8bb19f85ec080912e8fbcd58521793a0164d82ad96d19f1f',1999,'SO','Somalia','transnational-issues',969,'Disputes - international: most of the southern half
of the boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with Ethiopia
over the Ogaden
Disputes - international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Illicit drugs: transshipment center for heroin and
cocaine; cocaine consumption on the rise; world''s
largest market for illicit methaqualone, usually
imported illegally from India through various east
African countries; illicit cultivation of marijuana
South Georgia
and the South
Sandwich Islands
(overseas territory of the UK,
also claimed by Argentina)
Shag Rocks
are not shown.
O 100 200 km
0 100 200 mi
South Georgia
rytviken
Bird \\
Island \\i>
South
Atlantic Ocean
Clerke °
Rocks
Traversay 0
Islands °fi
South
Scotia Sea
Sandwich Saunders l.°
Islands „
Montagu 1.0
Bristol l.°
Administered by U.K.,
claimed by ARGENTINA.
Southern *
Thule
Disputes - international: claimed by Argentina','9590cb1069fe4c9dd45d711743bbd92324e74007b80225604e1d394211340595','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f65f6961309b54afda39acb1e0d215b090e71d162ff1f290c3f02d6b3cc3c9c',1999,'SD','Sudan','transnational-issues',984,'Disputes - international: administrative boundary
with Kenya does not coincide with international
boundary; Egypt asserts its claim to the "Hala''ib
Triangle,''1 a barren area of 20,580 sq km under partial
Sudanese administration that is defined by an
administrative boundary which supersedes the treaty
boundary of 1899','6b7db32dc6bf4e39f9660f3e80528a73cbb47ca7d0bda31bac8be2ca947470c5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('805d35cb36f12e3ee9bf95b46ab68445aa9690bb6103a54e6b678ad844dab848',1999,'ZW','Zimbabwe','transnational-issues',989,'470
members— (24) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK,
US
observers— (16) Commission of the European Communities, Czech Republic, Iceland, South Korea, Mexico,
World Court
see International Court of Justice (ICJ)
World Customs Organization (WCO)
see Customs Cooperation Council (CCC)
598
Appendix C: International Organizations and Groups (continued)
members— (125 and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia,
NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico,
Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Council (WFC) established 1 7 December 1 974; to study world food problems and to recommend solutions; ECOSOC organization;
there were 36 members selected on a rotating basis from all regions; subsumed by the World Food Program and
Food and Agriculture Organization
World Food Program (WFP) members— { 36) selected on a rotating basis from all regions
address— V ia Cesare Giullio Viola, 68/70 Parco
de Medici, 1-00148 Rome, Italy
telephone— {39] (6) 522821
FAX— [39] (6) 59602348, 52282840
established— 24 November 1961
aim— to provide food aid in support of economic
development or disaster relief; an ECOSOC
organization
World Health Organization (WHO)
address— CH-1211 Geneva 27, Switzerland
fe/ep/rone— [41] (22) 791 21 11, 791 32 23
FAX-{ 41] (22) 791 07 46
established— 22 July 1946
effecf/Ve — 7 April 1948
aim— to deal with health matters worldwide; a
UN specialized agency
members— (191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niue, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia,
associate members— (2) Puerto Rico, Tokelau
World Federation of Trade Unions (WFTU)
address— Branicka 112, 14000 Prague 4, Czech
Republic
telephone— {42] (2) 44 46 21 40, 44 46 20 85, 44
46 29 61
FAX— [42] (2)44 4613 78
established— 3 October 1945
aim— to promote the trade union movement
599
Appendix C: International Organizations and Groups (continued)
World Intellectual Property Organization
(WIPO)
address— 34 Chemin des Colombettes, Case
Postale 18, CH-121 1 Geneva 20, Switzerland
fe/ep/ione— [41] (22) 730 9111
FAX-{ 41] (22) 733 5428
established— 14 July 1967
effective— 26 April 1970
aim— to furnish protection for literary, artistic,
and scientific works; a UN specialized agency
World Meteorological Organization (WMO)
address— Case Postale 2300, 41 Avenue
Giuseppe-Motta, CH-1211 Geneva 2,
countries that have signed, but not yet ratified— (12) Afghanistan, Azerbaijan, Kuwait, Liberia, Libya, Malta, Sao
Tome and Principe, Thailand, Tuvalu, UAE, US, former Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention on Fishing and Conservation of
Living Resources of the High Seas
note— abbreviated as Marine Life Conservation
opened for signature-29 April 1958
entered into force— 20 March 1966
objective— to solve through international
cooperation the problems involved in the
conservation of living resources of the high seas,
considering that because of the development of
modern technology some of these resources are in
danger of being overexploited
parties— (37) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark,
Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra Leone, Solomon Islands, South Africa, Spain,
Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela, former Yugoslavia
countries that have signed, but not yet ratified— {2 1 ) Afghanistan , Argentina, Bolivia, Canada, Costa Rica, Cuba,
Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka,
Tunisia, Uruguay
Convention on Long-Range Transboundary Air
Pollution
note— abbreviated as Air Pollution
opened for signature— 13 November 1979
entered into force— 1 6 March 1 983
objective— to protect the human environment
against air pollution and to gradually reduce and
prevent air pollution, including long-range
transboundary air pollution
parties— ( 44) Armenia, Austria, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Turkey, Ukraine, UK, US, former Yugoslavia
countries that have signed, but not yet ratified— (2) Holy See, San Marino
Convention on the International Trade in
Endangered Species of Wild Flora and Fauna
(CITES)
note— abbreviated as Endangered Species
opened for signature— 3 March 1973
entered into force— 1 July 1975
objective— to protect certain endangered species
from overexploitation by means of a system of
import/export permits
parties— (137) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Guyana, Honduras, Hungary, India, Indonesia, Iran, Israel, Italy, Japan, Jordan, Kenya, Kiribati,
South Korea, Latvia, Liberia, Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius,
Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Tuvalu,
Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (3) Ireland, Kuwait, Lesotho
603
Appendix D: Selected International Environmental Agreements (continued)
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other Matter
(London Convention)
note— abbreviated as Marine Dumping
opened for signature— 29 December 1972
entered into force— 30 August 1 975
objective— to control pollution of the sea by dumping
and to encourage regional agreements
supplementary to the Convention
parties— ( 75) Afghanistan, Antigua and Barbuda, Argentina, Australia, Barbados, Belarus, Belgium, Belize,
Bosnia and Herzegovina, Brazil, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa
Rica, Cote d''Ivoire, Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Finland, France, Gabon, Germany,
Greece, Guatemala, Haiti, Honduras, Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ, Nigeria, Norway,
Oman, Panama, Papua New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles, Slovenia,
Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Tunisia, Tuvalu, Ukraine, UAE,
UK, US, former Yugoslavia
Convention on the Prohibition of Military or Any
Other Hostile Use of Environmental Modification
Techniques
note— abbreviated as Environmental Modification
opened for signature— 10 December 1976
entered into force— 5 October 1978
objective— to prohibit the military or other hostile use
of environmental modification techniques in order to
further world peace and trust among nations
parties— { 64) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus,
Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic,
Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy,
Japan, North Korea, South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway,
Pakistan, Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Sao Tome and Principe, Slovakia,
Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan,
Vietnam, Yemen
countries that have signed, but not yet ratified— (1 7) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy
See, Iceland, Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria,
Turkey, Uganda
Convention on Wetlands of International
Importance Especially as Waterfowl Habitat
(Ramsar)
note— abbreviated as Wetlands
opened for signature— 2 February 1971
entered into force— 21 December 1975
objective— to stem the progressive encroachment
on and loss of wetlands now and in the future,
recognizing the fundamental ecological functions of
wetlands and their economic, cultural, scientific, and
recreational value
parties— (101) Albania, Algeria, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Belgium, Brazil, Bulgaria, Burkina Faso, Canada, Chad, Chile, China, Democratic Republic of the Congo, Costa
Rica, Cote d’Ivoire, Croatia, Czech Republic, Denmark, Ecuador, Egypt, Estonia, Finland, France, Gabon, The
Gambia, Georgia, Germany, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Latvia, Liechtenstein,
Lithuania, Malawi, Mali, Malta, Mauritania, Mexico, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ,
Nicaragua, Niger, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Togo, Trinidad and Tobago, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Vietnam, former
Yugoslavia, Zambia
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/
or Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of T ransboundary Movements of Hazardous Wastes and Their Disposal
International Convention for the Regulation of
Whaling
note— abbreviated as Whaling
opened for signature— 2 December 1946
entered into force— 10 November 1948
objective— to protect all species of whales from
overhunting; to establish a system of international
regulation for the whale fisheries to ensure proper
conservation and development of whale stocks; and
to safeguard for future generations the great natural
resources represented by whale stocks
parties— { 51) Antigua and Barbuda, Argentina, Australia, Austria, Belize, Brazil, Canada, Chile, China, Costa
Rica, Denmark, Dominica, Ecuador, Egypt, Finland, France, Germany, Grenada, Iceland, India, Ireland, Italy,
Jamaica, Japan, Kenya, South Korea, Mauritius, Mexico, Monaco, Netherlands, NZ, Norway, Oman, Panama,
Peru, Philippines, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal,
Seychelles, Solomon Islands, South Africa, Spain, Sweden, Switzerland, UK, US, Uruguay, Venezuela
604
Appendix D: Selected International Environmental Agreements (continued)
International Tropical Timber Agreement, 1983
note— abbreviated as Tropical Timber 83
opened for signature— 18 November 1983
entered into force— 1 April 1985; this agreement
expired when the International Tropical Timber
Agreement, 1994, went into force
objective— to provide an effective framework for
cooperation between tropical timber producers and
consumers and to encourage the development of
national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic
resources
parties— (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan,
South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea,
Peru, Philippines, Portugal, Russia, Spain, Sweden, Switzerland, Thailand, Togo, T rinidad and Tobago, UK, US,
Venezuela
International Tropical Timber Agreement, 1994
note— abbreviated as Tropical Timber 94
opened for signature— 26 January 1994
entered into force— 1 January 1997
objective— to ensure that by the year 2000 exports
of tropical timber originate from sustainably
managed sources; to establish a fund to assist
tropical timber producers in obtaining the resources
necessary to reach this objective
parties— ( 54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African
Republic, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark,
Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India,
Indonesia, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway,
Panama, Papua New Guinea, Peru, Philippines, Spain, Suriname, Sweden, Switzerland, Thailand, Togo,
Trinidad and Tobago, UK, US, Venezuela
countries that have signed, but not yet ratified— (2) Ireland, Portugal
Kyoto Protocol to the United Nations Framework
Convention on Climate Change
note— abbreviated as Climate Change-Kyoto
Protocol
opened for signature— 1 6 March 1 998, but not yet in
force
objective— to further reduce greenhouse gas
emissions by enhancing the national programs of
developed countries aimed at this goal and by
establishing percentage reduction targets for the
developed countries
parties— (7) Antigua and Barbuda, El Salvador, Fiji, Maldives, Panama, Trinidad and Tobago, Tuvalu
countries that have signed, but not yet ratified— (72) Argentina, Australia, Austria, Belgium, Bolivia, Brazil,
Bulgaria, Canada, Chile, China, Cook Islands, Costa Rica, Croatia, Czech Republic, Denmark, Ecuador,
Estonia, EU, Finland, France, Germany, Greece, Guatemala, Honduras, Indonesia, Ireland, Israel, Italy, Japan,
South Korea, Latvia, Liechtenstein, Lithuania, Luxembourg, Mali, Malta, Marshall Islands, Mexico, Federated
States of Micronesia, Monaco, Netherlands, New Zealand, Nicaragua, Niger, Niue, Norway, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Slovakia, Slovenia, Solomon Islands, Spain, Sweden, Switzerland, Thailand,
Turkmenistan, UK, US, Uruguay, Uzbekistan, Vietnam, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London
Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That Deplete
the Ozone Layer
note— abbreviated as Ozone Layer Protection
opened for signature— 16 September 1987
entered into force— 1 January 1989
objective— to protect the ozone layer by controlling
emissions of substances that deplete it
parties— { 168) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal (Portugal has also extended the protocol to Macau), Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal,
Seychelles, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
605
Appendix D: Selected International Environmental Agreements (continued)
Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From
Ships, 1973 (MARPOL)
note— abbreviated as Ship Pollution
opened for signature— 17 February 1978
entered into force— 2 October 1 983
objective— to preserve the marine environment
through the complete elimination of pollution by oil
and other harmful substances and the minimization
of accidental discharge of such substances
parties— (100) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Barbados, Belgium,
Belize, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Ecuador, Egypt, Equatorial Guinea, Estonia, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia,
Lebanon, Liberia, Lithuania, Luxembourg, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Monaco, Morocco, Netherlands, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Poland,
Portugal, Romania, Russia, Saint Vincent and the Grenadines, Senegal, Seychelles, Singapore, Slovakia,
Slovenia, South Africa, Spain, Suriname, Sweden, Switzerland, Syria, Togo, Tonga, Tunisia, Turkey, Tuvalu,
Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, former Yugoslavia
Protocol on Environmental Protection to the
Antarctic Treaty
note— abbreviated as Antarctic-Environmental
Protocol
opened for signature— A October 1991
entered into force— 14 January 1998
objective— to enhance the protection of the
Antarctic environment and dependent and
associated ecosystems
parties— ( 28) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile, China, Ecuador, Finland, France, Germany,
Greece, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain,
Sweden, UK, US, Uruguay
countries that have signed, but not yet ratified— (15) Austria, Canada, Colombia, Cuba, Czech Republic,
Denmark, Guatemala, Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey,','3b05f4964bd449a9be84236cae630497a3869ea926ec889d6d770ffe33b98500','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69072fb3e9b325052fb1b7b537eec8dbd6e307b921c623e985e8410496f0b94c',1999,'TJ','Tajikistan','transnational-issues',998,'Disputes - international: most of the boundary with
China in dispute; territorial dispute with Kyrgyzstan on
northern boundary in Isfara Valley area
Illicit drugs: limited illicit cultivation of cannabis,
mostly for domestic consumption; opium poppy
cultivation negligible in 1998 because of government
eradication program; increasingly used as
transshipment point for illicit drugs from Southwest
Asia to Russia and Western Europe
Tanzania
Disputes - international: dispute with Malawi over
the boundary in Lake Nyasa (Lake Malawi)
Illicit drugs: growing role in transshipment of
Southwest and Southeast Asian heroin and South
American cocaine destined for European and US
markets and of South Asian methaqualone bound for
Southern Africa','eb03486303c71d865fdfbd33861d765dd951e390adbb7cfac5340a5a4d1b4cbf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3560dc224cb8a0df4a146aa4327073059c764f1f5e5206dc562e5a564003b7',1999,'TH','Thailand','transnational-issues',1006,'Disputes - international: parts of the border with
Laos are indefinite; maritime boundary with Vietnam
resolved, August 1 997; parts of border with Cambodia
are indefinite; maritime boundary with Cambodia not
clearly defined; sporadic conflict with Burma over
alignment of border
Illicit drugs: a minor producer of opium, heroin, and
477
Thailand (continued)
marijuana; major illicit transit point for heroin en route
to the international drug market from Burma and Laos;
eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced
by eradication efforts; also a drug money-laundering
center; minor role in amphetamine production for
regional consumption; increasing indigenous abuse of
methamphetamines and heroin
fe/epbone— [66] (2) 2881234
FAX— [66] (2) 2881000
established— 28 March 1947 as Economic
Commission for Asia and the Far East (ECAFE)
aim— to carry out the commitment of the
Economic and Social Council of the UN to
promote economic development
Economic and Social Commission for members— { 12 plus the Palestine Liberation Organization) Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Oman,
Western Asia (ESCWA) Qatar, Saudi Arabia, Syria, UAE, Yemen, Palestine Liberation Organization
address— P.O. Box 11-8575, Riad El-Sohl
Square, Beirut, Lebanon
fe/epbone— [961] (10) 981301
FAX— [961] (10) 981510
established— 9 August 1973 as Economic
Commission for Western Asia (ECWA)
aim— to promote economic development as a
regional commission for the UN''s Economic and
Social Council
members— (51) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia,
China, Fiji, France, India, Indonesia, Iran, Japan, Kazakhstan, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, Netherlands, NZ,
Pakistan, Palau, Papua New Guinea, Philippines, Russia, Samoa, Singapore, Solomon Islands, Sri Lanka,
Tajikistan, Thailand, Tonga, Turkey, Turkmenistan, Tuvalu, UK, US, Uzbekistan, Vanuatu, Vietnam
associate members— (9) American Samoa, Cook Islands, French Polynesia, Guam, Hong Kong, Macau, New
Caledonia, Niue, Northern Mariana Islands
562
Appendix C: International Organizations and Groups (continued)
Economic and Social Council (ECOSOC) members— { 54) selected on a rotating basis from all regions
address— United Nations, New York, NY 10017,
US
telephone— {)] (212) 963 1234
FAY— {1] (212) 758 2718
established— 26 June 1945
effective— 24 October 1945
aim— to coordinate the economic and social
work of the UN; includes five regional
commissions (see Economic Commission for
Africa, Economic Commission for Europe,
Economic Commission for Latin America and
the Caribbean, Economic and Social
Commission for Asia and the Pacific, Economic
and Social Commission for Western Asia) and
1 0 functional commissions (see Commission for
Social Development, Commission on Human
Rights, Commission on Narcotic Drugs,
Commission on the Status of Women,
Commission on Population and Development,
Statistical Commission, Commission on Science
and Technology for Development, Commission
on Sustainable Development, and Commission
on Crime Prevention and Criminal Justice)
Economic Commission for Africa (ECA)
address— P.O. Box 3001-3005, Addis Ababa,','bc2911bc267752bea828171a4a6bada6e12ea9852192062c5c9e9219f39773b4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27f7b929566d2f25259ddfca75db1b67d2d8d9fa5079efcf71784e1f1dbe390',1999,'TG','Togo','transnational-issues',1007,'Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total: 56,790 sq km
land: 54,390 sq km
water: 2,400 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,647 km
border countries: Benin 644 km, Burkina Faso 126
km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: gently rolling savanna in north; central hills;
southern plateau; low coastal plain with extensive
lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Agou 986 m
Natural resources: phosphates, limestone, marble
Land use:
arable land: 38%
permanent crops: 7%
permanent pastures: 4%
forests and woodland: 17%
other: 34% (1993 est.)
Irrigated land: 70 sq km (1993 est.)
Natural hazards: hot, dry harmattan wind can
reduce visibility in north during winter; periodic
droughts
Environment - current issues: deforestation
attributable to slash-and-burn agriculture and the use
of wood for fuel; recent droughts affecting agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements','393cf3729962bfd0cf968e1abd257583e64e9f2349fed101d43ba867065340db','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c58d151fbc9c34629dab18babc83a6281077af27956aaa91d7bfafd8d2f3f3a',1999,'TK','Tokelau','transnational-issues',1016,'Disputes - international: none
Illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers
480
Tokelau (continued)
Disputes - international: none
481
0 SO 100 km
0 50 100 ml
„ Niuafo’ou
Niuatoputapu
Tafahi
South Pacific Ocean
Vava''u
Group
Vava’u
''■^Neiafu
Kao Island
Ha'' apai .Group
angai
NUKUALOFA
Tongatapu
GrOUp M Minerva Reef not shown','fa52c8d821ce86db85dad96a163287edab4daed0386e1bfe26e12f75de9f3df4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a7cb9cb099351c237960bed1e48919364bec15c9edc6e1ec51c1d10000dd60',1999,'TV','Tuvalu','transnational-issues',1022,'> Nanumea
Lolua
Kuha"Niutao
Tong/Nanuman9a
Tanrake''''’Wt" Asau
Vaitupu
South
Or mm
Nukufetau
Sava ve
Funafuti
.FUNAFUTI
Fangaua
Nukulaelae
0 75 150 km
0 ‘ 7 T" So ml Niulakita
Disputes - international: none
Disputes - international: Ugandan military forces
are supporting the rebel forces in the civil war in the
Democratic Republic of the Congo
499','90a4411425475bcb2e99d3e03a839cfcd55c2aff70aa219b5c87ab8f3b7d5759','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc573b1c52f468d6ab6e452cbc2f3e1e6c74603aa93b05cd259c3ef5d959e07b',1999,'AE','United Arab Emirates','transnational-issues',1030,'Location: Middle East, bordering the Gulf of Oman
and the Persian Gulf, between Oman and Saudi
Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 41 0 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in
east
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 2%
forests and woodland: 0%
other: 98% (1993 est.)
Irrigated land: 50 sq km (1993 est, )
Natural hazards: frequent sand and dust storms
Environment - current issues: lack of natural
freshwater resources being overcome by desalination
plants; desertification; beach pollution from oil spills
Environment - international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: Biodiversity, Law of the Sea
Geography - note: strategic location along southern
approaches to Strait of Hormuz, a vital transit point for
world crude oil
Disputes - international: location and status of
boundary with Saudi Arabia is not final, de facto
boundary reflects 1974 agreement; no defined
boundary with mostof Oman, but Administrative Line
in far north; claims two islands in the Persian Gulf
occupied by Iran: Lesser Tunb (called T unb as Sughra
in Arabic by UAE and Jazireh-ye Tonb-e Kuchek in
Persian by Iran) and Greater Tunb (called Tunb al
Kubra in Arabic by UAE and Jazireh-ye Tonb-e
Bozorg in Persian by Iran); claims island in the
Persian Gulf jointly administered with Iran (called Abu
Musa in Arabic by UAE and Jazireh-ye Abu Musa in
Persian by Iran) - over which Iran has taken steps to
exert unilateral control since 1992, including access
restrictions and a military build-up on the island; the
UAE has garnered significant diplomatic support in
the region in protesting these Iranian actions
Illicit drugs: growing role as heroin transshipment
and money-laundering center due to its proximity to
southwest Asian producing countries and the bustling
free trade zone in Dubai
UDEAC
Union Douaniere et Economique de I''Afrique Centrale; see Central African
Customs and Economic Union (UDEAC)
UEMOA
Union economique et monetaire Ouest africaine; see West African Economic and
Monetary Union (WAEMU)
UHF
ultra-high-frequency
UK','bb498fdce90fac77d4bbe6ab1ee86e345e0967bf21dbe9d9155b1de8593f93b2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa2fa230144e6eebb6143d10f304cb71264eff4b8ab114f503d33f519c5acf9',1999,'GB','United Kingdom','transnational-issues',1037,'75 150 km
North
Atlantic
Ocean
The island of Rockall
not shown.
Vo$''£ Shetland
cA& Islands
Orkney
Islands
Hebrides ^
ply
? <4 i»...
6 o/j k Scotland j
StjT. Dundee. / North
^gra^gemouth Sea
, * EdinBltfgh
.Newcastle
upon Tyne
’Middlesbrough
.Kingston
- ; - / ~ upon Hull
Sea ’Manchester
England
’Birmingham
w s LONDON^
Cardiff ’/''"Bristol Dover^S
UN
United Nations
UNAMIR
United Nations Assistance Mission for Rwanda
UNAVEM III
United Nations Angola Verification Mission III
UNCRO
United Nations Confidence Restoration Operation in Croatia
UNCTAD
United Nations Conference on Trade and Development
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Peace-keeping Force in Cyprus
UNFPA
United Nations Fund for Population Activities; see UN Population Fund (UNFPA)
UNHCR
United Nations High Commissioner for Refugees
UNICEF
United Nations Children''s Fund
UNIDO
United Nations Industrial Development Organization
UNIFIL
United Nations Interim Force in Lebanon
UNIKOM
United Nations Iraq-Kuwait Observation Mission
UNITAR
United Nations Institute for Training and Research
UNMIH
United Nations Mission in Haiti
UNMIBH
United Nations Mission in Bosnia and Herzegovina
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNMOP
United Nations Mission of Observers in Prevlaka
UNMOT
United Nations Mission of Observers in Tajikistan
UNOMIG
United Nations Observer Mission in Georgia
547
Appendix A: Abbreviations (continued)
UNOMIL
United Nations Observer Mission in Liberia
UNOMOZ
United Nations Operation in Mozambique
UNOMSIL
United Nations Mission of Observers in Sierra Leone
UNOMUR
United Nations Observer Mission Uganda-Rwanda
UNOSOM II
United Nations Operation in Somalia II
UNPREDEP
United Nations Preventive Deployment Force
UNPROFOR
United Nations Protection Force
UNRISD
United Nations Research Institute for Social Development
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in the Near East
UNSMIH
United Nations Support Mission in Haiti
UNTAC
United Nations Transitional Authority in Cambodia
UNTAES
United Nations Transitional Administration in Eastern Slavonia, Baranja, and
Western Sirmium
UNTSO
United Nations Truce Supervision Organization
UNU
United Nations University
UPU
Universal Postal Union
US','a16b567d6abb8230fb9f62632eefb45967d0bae958e0241f6c978bff31bfee8f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a92b8c94395860e9169db249c792a2c2113305a73f1ca7cf9103e30496e2b4',1999,'UY','Uruguay','transnational-issues',1040,'Location: Southern South America, bordering the
South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area - comparative: slightly smaller than the state
of Washington
Land boundaries:
total: 1 ,564 km
border countries: Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 200 nm; overflight and navigation
guaranteed beyond 12 nm
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedra! 514 m
Natural resources: fertile soil, hydropower, minor
minerals, fisheries
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 77%
forests and woodland: 6%
other: 10% (1997 est.)
Irrigated land: 7,700 sq km (1997 est.)
Natural hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind which
blows north from the Argentine pampas), droughts,
floods; because of the absence of mountains, which
act as weather barriers, all locations are particularly
vulnerable to rapid changes in weather fronts
Environment - current issues: Working with Brazil
to monitor and minimize transboundary pollution
caused by Brazilian power plant near border; water
pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Dumping, Marine Life Conservation
Disputes - international: none
Illicit drugs: limited illicit cultivation of cannabis and
very small amounts of opium poppy, mostly for
domestic consumption, almost entirely eradicated by
an effective government eradication program;
increasingly used as transshipment point for illicit
drugs from Afghanistan to Russia and Western
Europe and for acetic anhydride destined for
United Nations Observer Mission in Liberia
(UNOMIL)
members— { 6) Bangladesh, Egypt, India, Kenya, Malaysia, Pakistan
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {!] (212) 963 1234
FAX— [1] (212) 963 4879
established— 22 September 1993
aim— to assist in the implementation of the
peace agreement; established by the UN
Security Council
594
Appendix C: International Organizations and Groups (continued)
United Nations Observer Mission
Uganda-Rwanda (UNOMUR)
established 1 993 for six months to monitor the Uganda/Rwanda border to verify that no military assistance reaches
Rwanda across the border; established by the UN Security Council; members were Bangladesh, Botswana, Brazil,
Hungary, Netherlands, Senegal, Slovakia, Zimbabwe; subsumed by UNAMIR
United Nations Operation in Mozambique
(UNOMOZ)
established 1 6 December 1 992 to supervise the cease-fire; established by the UN Security Council; members were
Argentina, Austria, Bangladesh, Botswana, Brazil, Canada, Cape Verde, China, Czech Republic, Egypt,
Guinea-Bissau, Hungary, India, Ireland, Italy, Japan, Jordan, Malaysia, Netherlands, Norway, Portugal, Russia,
Spain, Sweden, US, Uruguay, Zambia; shut down operations 31 January 1995
United Nations Operation in Somalia
(UNOSOM II)
established 24 April 1992 to facilitate an immediate cessation of hostilities, to maintain a cease-fire in order to
promote a political settlement, and to provide urgent humanitarian assistance; established by the UN Security
Council; members were Australia, Bangladesh, Botswana, Canada, Egypt, India, Ireland, Malaysia, Nepal, NZ,
Nigeria, Pakistan, Romania, Zimbabwe; UN peacekeepers left Somalia on 1 March 1995; some UN personnel
remain in Somalia engaged in humanitarian work
United Nations Peace-keeping Force in
Cyprus (UNFICYP)
members— (9) Argentina, Australia, Austria, Canada, Finland, Hungary Ireland, Slovenia, UK
address— Chief of Mission, P.O. Box 1642,
Nicosia, Cyprus
telephone— [357] (2) 359 700
FjAX — [357] (2) 359 753
established— 4 March 1964
aim— to serve as a peacekeeping force between
Greek Cypriots and Turkish Cypriots in Cyprus;
established by the UN Security Council
United Nations Population Fund (UNFPA)
members— (34) selected on a rotating basis from all regions
note— acronym retained from predecessor
organization UN Fund for Population Activities
address— 220 East 42nd Street, 19th Floor,
Room DN-1901, New York, NY 10017, US
telephone— [t] (212) 297 5000
FAX— [1] (212) 557 6416
established— HA July 1967
aim— to assist both developed and developing
countries to deal with their population problems
United Nations Preventive Deployment Force
(UNPREDEP)
established 31 March 1 995; to monitor border activity in the Former Yugoslav Republic of Macedonia; members
were Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, Ghana,
Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Sweden,
Switzerland, Turkey, Ukraine, US; mandate ended 25 March 1999
United Nations Protection Force
(UNPROFOR)
established 28 February 1 992; to create conditions for peace and security required for the negotiation of an overall
settlement of the "Yugoslav" crisis; established by the UN Security Council; members were Bangladesh, Belgium,
Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan,
Kenya, Malaysia, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Spain, Sweden,
Switzerland, Ukraine, UK, US; disbanded December 1995; replaced by the Implementation Force (IFOR), which has
been replaced by the Stabilization Force (SFOR)
595
Appendix C: International Organizations and Groups (continued)
United Nations Relief and Works Agency
for Palestine Refugees in the Near East
(UNRWA)
members— { 10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
address— P. 0. Box 371 , Gaza City,
Cisjordania-Gaza
telephone— {972] (7) 677 7333, 824 508
FAX— {972] (7) 677 7555
established— 8 December 1949
aim— to provide assistance to Palestinian
refugees
United Nations Research Institute for Social
Development (UNRISD)
members— no country members, but a Board of Directors consisting of a chairman appointed by the UN secretary
general and 10 individual members
address— Palais des Nations, CH-121 1 Geneva
10, Switzerland
telephone— {At] (22) 798 84 00, 798 58 50
FAX— [41] (22) 740 07 91
established— 1 July 1964
aim— to conduct research into the problems of
economic development during different phases
of economic growth
United Nations Secretariat
members— the UN Secretary General and staff
address— see United Nations
established— 26 June 1945
effective— 24 October 1945
aim— to serve as the primary administrative
organ of the UN; a Secretary General is
appointed for a five-year term by the General
Assembly on the recommendation of the
Security Council
United Nations Security Council
address— do United Nations, Room S-3520A,
New York, NY 10017, US
telephone— [\\] (212) 963 1234
FAX— [1] (212) 758 2718
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security
permanent members— (5) China, France, Russia, UK, US
nonpermanent members— (1 0) elected for two-year terms by the UN General Assembly; Bahrain (1998-99), Brazil
(1998-99), Costa Rica (1997-98), Gabon (1998-99), The Gambia (1998-99), Japan (1997-98), Kenya (1997-98),
Portugal (1997-98), Slovenia (1998-99), Sweden (1997-98)
United Nations Transitional Administration
in Eastern Slavonia, Baranja, and Western
Sirmium (UNTAES)
established 1 2 November 1 995; aim to facilitate and supervise the Basic Agreement between the government of the
Republic of Croatia and the local Serbian community that will lead to a peaceful integration of that region into the
national state of Croatia; members were Argentina, Bangladesh, Belgium, Brazil, Czech Republic, Denmark, Egypt,
Fiji, Finland, Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Niger, Norway, Pakistan, Poland, Russian,
Slovakia, Sweden, Switzerland, Tunisia, Ukraine, UK, US; disbanded 15 January 1998; a UN Civilian Police Support
Group was established in December 1997 as follow-on mission to UNTAES; the support group will continue to
monitor the Croatian police in the Danube region, particularly in connection with the return of displaced people
United Nations Transitional Authority in
Cambodia (UNTAC)
established by the UN Security Council on 28 February 1 992 to contribute to the restoration and maintenance of
peace and to the holding of free elections; disbanded sometime after the UN-supervised election in May 1 993;
members were Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brunei, Bulgaria, Cameroon, Canada,
Chile, China, Colombia, Egypt, Fiji, France, Germany, Ghana, Hungary, India, Indonesia, Ireland, Italy, Japan,
Jordan, Kenya, Malaysia, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland,
Russia, Senegal, Singapore, Sweden, Thailand, Tunisia, UK, US, Uruguay
596
Appendix C: International Organizations and Groups (continued)
United Nations Truce Supervision
Organization (UNTSO)
address— Government House, P.O. Box 490,
Jerusalem 91004, Israel
telephone— {972] (2) 673 4223
FAX— {972] (2) 673 5282, 673 4223 extension
400
established— NA May 1948
aim— to supervise the 1948 Arab-lsraeli
cease-fire; currently supports timely deployment
of reinforcements to other peacekeeping
operations in the region as needed; initially
established by the UN Security Council
members— (20) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France,
Ireland, Italy, Netherlands, NZ, Norway, Russia, Sweden, Switzerland, US
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 1 1 UN trust
territories; members were China, France, Russia, UK, US; it formally suspended operations 1 November 1995 after
the Trust Territory of the Pacific Islands (Palau) became the Republic of Palau, a constitutional government in free
association with the US; the Trusteeship Council was not dissolved
United Nations University (UNU)
address— 5 3-70 Jingumae 5-chome,
Shibuya-ku, Tokyo 150, Japan
fe/ep/rone— [81 ](3)3499 2811
FAX— [81] (3) 3499 2828
established— 6 December 1973
aim— to conduct research in development,
welfare, and human survival and to train
scholars
members— { 38 associated institutes in 33 countries) Argentina, Australia, Austria, Bangladesh, Brazil, Canada,
Chile, China, Colombia, Costa Rica, Ethiopia, France, Ghana, Guatemala, Hungary, Iceland, India, Japan, Kenya,
South Korea, Mexico, Netherlands, Nigeria, Philippines, Spain, Sri Lanka, Sudan, Switzerland, Thailand, Trinidad
and Tobago, UK, US, Venezuela
United National Verification Mission in
Guatemala (MINUGUA)
established on 20 January 1997; to verify fulfillment of cease-fire provisions; established by UN Security Council;
members were Argentina, Australia, Austria, Brazil, Canada, Columbia, Ecuador, Germany, Italy, Norway, Russia,
Singapore, Spain, Sweden, Ukraine, US, Uruguay, Venezuela; mandate terminated in May 1997
Universal Postal Union (UPU)
address— Bureau International de I’UPU,
Weltpoststrasse 4, CH-3000 Berne 15,','48160a73e2836feedaa5b7e28a64323505218c3527327b3bfda102357c4f4504','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef6090c31752ab8dc30b9ab24b733cd2a7db8bff259cef16b699a89fc79498b',1999,'VU','Vanuatu','transnational-issues',1048,'lies
Torres
lies
Banks
Espiritu
Santo
Aoba Maiwo
Luqanville
Pentecote
CD
Malakula
Ambrym
5
X
Epi
CD
cr
Forari
PORT® Elate
VILA
ex
CD
Erromango JP0*a ^
Ccr.'' •:
Tanna
St-. •
Anatom
Matthew
islands claimed Hunter
by FRANCE
and VANUATU
0 75
150 km
O
75 150 mi
Disputes - international: claims Matthew and
Hunter Islands east of New Caledonia
Venezuela
Disputes - international: claims all of Guyana west
of the Essequibo River; maritime boundary dispute
with Colombia in the Gulf of Venezuela
Illicit drugs: illicit producer of cannabis, opium, and
coca leaf for the international drug trade on a small
scale; however, large quantities of cocaine and heroin
transit the country from Colombia bound for US and
Europe; important money-laundering hub; active
eradication program primarily targeting opium
Location: Southeastern Asia, bordering the Gulf of
Thailand, Gulf of Tonkin, and South China Sea,
alongside China, Laos, and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
rice, bananas, vegetables, coffee; beef, pork, milk,
eggs; fish
Exports: $16.9 billion (f.o.b., 1998)
Exports - commodities: petroleum, bauxite and
aluminum, steel, chemicals, agricultural products,
basic manufactures (1998)
Exports - partners: US and Puerto Rico 57%,
Colombia, Brazil (1997)
Imports: $12.4 billion (f.o.b,, 1998)
Imports - commodities: raw materials, machinery
and equipment, transport equipment, construction
materials (1998)
Imports - partners: US 53%, Japan, Colombia,
Italy, Germany (1997)
Debt - external: $26.5 billion (1996)
Economic aid - recipient: $50.8 million (1995)
Currency: 1 bolivar (Bs) = 100 centimos
Exchange rates: bolivares (Bs) per US$1 - 570.267
(January 1999), 547.556 (1998), 488.635 (1997),
417.333 (1996), 176.843 (1995), 148.503 (1994)
Fiscal year: calendar year
Disputes - international: maritime boundary with
Cambodia not defined; involved in a complex dispute
over the Spratly Islands with China, Malaysia,
Philippines, Taiwan, and possibly Brunei; maritime
boundary with Thailand resolved, August 1997;
522
Vietnam (continued)
maritime boundary dispute with China in the Gulf of
Tonkin; Paracel Islands occupied by China but
claimed by Vietnam and Taiwan; offshore islands and
sections of boundary with Cambodia are in dispute;
sections of land border with China are indefinite
Illicit drugs: minor producer of opium poppy with
3,000 hectares cultivated in 1998, capable of
producing 20 metric tons of opium; probably minor
transit point for Southeast Asian heroin destined for
the US and Europe; growing opium/heroin addiction;
possible small-scale heroin production
Virgin Islands
(territory of the US)','d0499ebdc4e65b293eed6488a6d6f2a98e0182398fc666feb46b14d02804c31d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4964fddbd987bd748e40fb291e80d964e434ced08d49212b3b2cecd9961c024b',1999,'YE','Yemen','transnational-issues',1067,'Disputes - international: a large section of
boundary with Saudi Arabia is not defined; Hanish
Islands dispute with Eritrea resolved by arbitral
tribunal in October 1998','62fdf0d7ce8e2423ccd9f0a969d384fac5d1d9586e8e548add374cfffe1f74e0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c654e7a0389388e3858998223db7f8f03446d1f0a6c5ccc0bfff95b28bc8b26b',1999,'ZM','Zambia','transnational-issues',1068,'7%, France 6%, Brazil 5% (1997)
Debt - external: $4.9 billion (1998)
Economic aid - recipient: $176.1 million (1995)
Currency; Yemeni rial (YRI) (new currency)
Exchange rates: Yemeni rials (YRI) per US$1 -
140.940 (October 1998), 129.286 (1997), 94.157
(1996), 40.839 (1995), 12.010 (official fixed rate
1991-94)
Fiscal year: calendar year
Disputes - international: quadripoint with
Botswana, Namibia, and Zimbabwe is in
disagreement
Illicit drugs: transshipment point for methaqualone,
heroin, and cocaine bound for Southern Africa and
Europe; regional money-laundering center','c68f12a52c767d053f1de14d3627a0f2eeaa27e73d3b80519dcfab53d6964650','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c41874788207acecf7fd7faf7e34b8bdcb0ab303cc43bb1488c18da77363ffc5',1999,'MA','Morocco','transnational-issues',1082,'telephone^ 212] (7) 77 26 82, 77 26 76, 77 26
68
FAX— [212] (7) 77 26 93
established— 17 February 1989
aim— to promote cooperation and integration
among the Arab states of northern Africa
Arab Monetary Fund (AMF)
address— P.O. Box 2818, Abu Dhabi, United
Arab Emirates
fe/epbone— [971] (2) 215000, 328500
FAX— [971] (2) 326454
established— 27 April 1976
effective— 2 February 1977
aim— to promote Arab cooperation,
development, and integration in monetary
and economic affairs
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen,
Palestine Liberation Organization
552
Appendix C: International Organizations and Groups (continued)
Asia-Pacific Economic Cooperation (APEC)
address— 438 Alexandra Road, Alexandra Point
Building, 14th Floor 01/04, Singapore 119958,','b19c77029fa7c67d0c9dc90b4bb246d758e8026434aa3bf56027e3dcab5118ef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e5b04efc4c33e6c1ca833acae6edf726dc36a710d3e109eaf887de469bbffe7',1999,'SG','Singapore','transnational-issues',1083,'telephone— [65] 276 1880
FAX— [65] 276 1775
established— 7 November 1989
aim— to promote trade and investment in the
Pacific basin
members— (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia,
Mexico, NZ, Papua New Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers— { 3) Association of Southeast Asian Nations, Pacific Economic Cooperation Conference, South Pacific
Forum
Asian Development Bank (AsDB)
address— 6 ADB Avenue, Mandaluyong, 0401
METRO Manila, Philippines
telephone— [63] (2) 71 1 3851
FAX— [63] (2) 741 7961 , 631 6816
established— 19 December 1966
aim— to promote regional economic cooperation
regional members— (40) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, China, Cook Islands, Fiji,
Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives,
Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea,
Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Thailand, Tonga, Tuvalu, Uzbekistan,
Vanuatu, Vietnam
nonregional members— (1 6) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Netherlands,
Norway, Spain, Sweden, Switzerland, Turkey, UK, US
Asociacion Latinoamericana de Integracion
(ALADI)
see Latin American Integration Association (LAIA)
Association of Southeast Asian Nations
(ASEAN)
note— the ASEAN Regional Forum (ARF)
consists of the 9 ASEAN members, 2 observers,
2 consultative partners, and 8 dialogue partners:
Australia, Canada, EU, India, Japan, South
Korea, New Zealand, US
address— 70 A Jalan Sisingamangaraja,
Kebayoran Baru, P.O. Box 2072, Jakarta 121 10,','32bd70533c5db573a54d366476824735a540a0f7e79f01145e61742b771fd33c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd1c0ebf229043634c11e91609b5097dd04df6317c3619d4a35cb43777f7fdd',1999,'GT','Guatemala','transnational-issues',1084,'telephone— {502] (2) 682151 , 682152, 682153,
682154
FAX— [502] (2) 681071
established— 13 December 1960
effective— 3 June 1961
aim— to promote establishment of a Central
American Common Market
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua; nofe— Panama pursues full regional
cooperation
556
Appendix C: International Organizations and Groups (continued)
Central European Initiative (CEI)
note— evolved from the Hexagonal Group
address— European Bank for Reconstruction
and Development, One Exchange Square,
London EC2A2EH, UK
telephone— {44] (171) 338 6152
FAX— [44] (171)338 7472
established— 27 July 1991
aim— to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas
members— { 16) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary,
Italy, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia, Ukraine
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the former USSR for leadership; most are
now evolving toward more democratic and market-oriented systems; also known formerly as the Second World or
as the communist countries; through the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba,
Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP)
address— Colombo Plan Bureau, P.O. Box 596,
12 Melbourne Avenue, Colombo 4, Sri Lanka
telephone— {94] (1) 581813, 581853, 581754
FAX— {94] (1) 581754
established— 1 July 1951
aim— to promote economic and social
development in Asia and the Pacific
members— (26) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Canada, Fiji, India, Indonesia,
Iran, Japan, South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, UK, US
Commission for Social Development
members— { 46) selected on a rotating basis from all regions
note— formerly Social Commission
address— Division Policy Coordination
ECOSOC Affairs, Department Policy
Coordination and Sustainable Development,
United Nations, Room S-29631 , New York, NY
10017, US
telephone— {1] (212) 963 1234
FAX— [1] (212) 963 5935
established— 21 June 1946 as the Social
Commission, renamed 29 July 1966
aim— to deal, as part of the Economic and Social
Council, with social development programs of
UN
Commission on Crime Prevention and
Criminal Justice
members— (40) selected on a rotating basis from all regions
address— Crime Prevention and Criminal
Justice Division, Vienna International Center,
P.O. Box 500, A-1400 Vienna, Austria
telephone— [43] (1) 21345, extension 4272
FAX— [43] (1) 21345 5898
established— 6 February 1992
aim— to provide guidance, as part of the
Economic and Social Council, on crime
prevention and criminal justice
557
Appendix C: Internationa! Organizations and Groups (continued)
Commission on Human Rights
address- do Secretariat, United Nations Office
of the High Commissioner of Human Rights,
Palais des Nations, CH-1211 Geneva 10,','02edfc93d0ee7fbdc3b71f40ad9e9482d7f25a9fe977b26fe0f89b969f11a147','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('644003e05aec7183865714005f0ab69096b4f95ea030a2be2bb11d2b9d983b3c',1999,'BY','Belarus','transnational-issues',1085,'fe/eptone— [375] 293434, 293517
FAX— {375] 261894, 261944
established— 8 December 1991
effective— 21 December 1991
aim— to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR _
Commonwealth of Nations
see Commonwealth (C)
Communaute Economique de I''Afrique
de I''Ouest (CEAO)
see West African Economic Community (CEAO)
Communaute Economique des Etats
de I''Afrique Centrale (CEEAC)
see Economic Community of Central African States (CEEAC)
Communaute Economique des Pays
des Grands Lacs (CEPGL)
see Economic Community of the Great Lakes Countries (CEPGL)
members— (52) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei,
Cameroon, Canada, Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, NZ, Nigeria (suspended),
Pakistan, Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga,
Trinidad and Tobago, Uganda, UK, Vanuatu, Zambia, Zimbabwe
special members— { 2) Nauru (soon to become full member), Tuvalu
559
Appendix C: International Organizations and Groups (continued)
communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the
Soviet model; most of the original and the successor states are no longer communist; see centrally planned
economies
Conference on Security and Cooperation
in Europe (CSCE)
see Organization for Security and Cooperation in Europe (OSCE)
Conseil Europeen pour la Recherche
Nucleaire (CERN)
see European Organization for Nuclear Research (CERN)
Contadora Group (CG)
established 5 January 1983 (on the Panamanian island of Contadora) to reduce tensions and conflicts in Central
America; has evolved into the Rio Group (RG); members included Colombia, Mexico, Panama, Venezuela
Cooperation Council for the Arab States of
the Gulf
see Gulf Cooperation Council (GCC)
Coordinating Committee on Export Controls
(COCOM)
established in 1949 to control the export of strategic products and technical data from member countries to
proscribed destinations; members were Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy,
Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM
members are working on a new organization with expanded membership which focuses on nonproliferation export
controls as opposed to East-West control of advanced technology
Council for Mutual Economic Assistance
(CEMA)
note— also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and abolished 1 January 1991;
members included Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola
(observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia,
Mozambique (observer), Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer), Yugoslavia
(associate)
Council of Arab Economic Unity (CAEU)
address— International Trade Centre Building,
12th Floor, 1191 Cornish El Nile, P.O. Box 1,
Mohamad Fareed, Cairo, Egypt
telephone-{ 20] (2) 754252, 755321
FAX— [20] (2) 754090
established— 3 June 1957
effective— 30 May 1964
aim— to promote economic integration among
Arab nations
members— { 1 1 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania, Somalia,
Sudan, Syria, UAE, Yemen, Palestine Liberation Organization
Council of Europe (CE)
address— Palais de I’Europe, F-67075
Strasbourg CEDEX, France
telephone— {33] (3) 88 41 20 00
FAX— [33] (3) 88 41 27 81 , 88 41 27 82
established— 5 May 1949
effective— 3 August 1949
aim— to promote increased unity and quality of
life in Europe
members— (40) Albania, Andorra, Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands, Norway, Poland, Portugal, Romania,
Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
guests— {A) Armenia, Azerbaijan, Bosnia and Herzegovina, Georgia
observers— (5) Canada, Israel, Italy, Japan, US
Council of the Baltic Sea States (CBSS)
address— Ministry for Foreign Affairs, Box
16121, S-10323 Stockholm, Sweden
telephone— [46] (8) 405 1000
FAX— [46] (8) 723 1176
established— 5 March 1992
aim— to promote cooperation among the Baltic
Sea states in the areas of aid to new democratic
institutions, economic development,
humanitarian aid, energy and the environment,
cultural programs and education, and
transportation and communication
members— (12) Denmark, Estonia, EU, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia,','b28a9927048b865d71bcca27d87f0106c6e93f0f6da1a43e9a8d88fd4ba7c62e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e015805e84d68a756d8c2cfda1929902369b51f65d4f5f734164969aa5e75135',1999,'SE','Sweden','transnational-issues',1086,'560
Appendix C: International Organizations and Groups (continued)
Council of the Entente (Entente) members— (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
address— 01 BP 3734, Angle Avenue
Verdier-Rue de Tessieres, Abidjan 01,
Cote d’Ivoire
telephone— {225] 33 1 0 01 , 33 28 35, 32 1 0 74
FAX-{225] 3311 49
established— 29 May 1959
aim— to promote economic, social, and political
coordination
countries in transition a new term used by the International Monetary FUND (IMF) for the middle group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 countries in transition: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech
Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Serbia and Montenegro, Slovakia, Slovenia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan; note— this group is identical to the group traditionally referred to as the “former
USSR/Eastern Europe” except for the addition of Mongolia
members— (144) Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Belarus, Belgium, Bermuda, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Egypt,
Eritrea, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Macau, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
developed countries (DCs) the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and
less developed countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the
European ministates; also known as the First World, high-income countries, the North, industrial countries; generally
have a per capita GDP in excess of Si 0,000 although four OECD countries and South Africa have figures well under
$10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 35 DCs are: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note— similar to the new
International Monetary Fund (IMF) term "advanced economies" which adds Hong Kong, South Korea, Singapore,
and Taiwan but drops Malta, Mexico, South Africa, and Turkey
Customs Cooperation Council (CCC)
note— also known as World Customs
Organization (WCO)
address— Rue de I’lndustrie 26-38, B-1040
Brussels, Belgium
telephone— [32] (2) 508 42 11
FAX— [32] (2) 508 42 40
established— 15 December 1950
aim— to promote international cooperation in
customs matters
561
Appendix C: International Organizations and Groups (continued)
developing countries a new term used by the International Monetary FUND (IMF) for the bottom group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
126 developing countries: Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia,
Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; nofe — this category would
presumably also cover the following 46 other countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands,
Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia,
Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of
Man, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and
Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
East African Development Bank (EADB) members— { 3) Kenya, Tanzania, Uganda
address— 4 Nile Avenue, P.O. Box 7128,
Kampala, Uganda
fe/ep/ione— [256] (41) 230021 , 230825
MX— [256] (41) 259763
established— 6 June 1967
effective— 1 December 1967
aim— to promote economic development
Economic and Social Commission for Asia
and the Pacific (ESCAP)
address— United Nations Building,
Rajadamnern Avenue, Bangkok 10200,','f9b2ab1520897ec5e628cdc305eafda044e1835c785f77d1ecad59bf48418470','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bbf7891fb4396264e58d3dee0d1b92e49e231fb031296f99788f7ad72daf568',1999,'UZ','Uzbekistan','transnational-issues',1087,'associate members— ( 1) “Turkish Republic of Northern Cyprus"
Euro-Atlantic Partnership Council (EAPC)
note— began as the North Atlantic Cooperation
Council (NACC); an extension of NATO
address— do NATO, B-1110 Brussels, Belgium
telephone— {32] (2) 728 41 1 1
FAX— {32] (2) 728 45 79
established— 8 November 1991
effective— 20 December 1991
aim— to discuss cooperation on mutual political
and security issues
members— (44) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Moldova, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and
Development (EBRD)
address— EBRD Headquarters, One Exchange
Square, London EC2A2EH, UK
telephone— {44] (171) 338 6000
FAX— [44] (171) 338 6100
established— 15 April 1991
aim— to facilitate the transition of seven centrally
planned economies in Europe (Bulgaria, former
Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market
economies by committing 60% of its loans to
privatization
members— (60) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank (EIB),
Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Mexico, Moldova, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan;
note— includes all 25 members of the OECD; also includes the EU as a single entity
European Community (or European
Communities, EC)
was established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal
and Steel Community (ESC), the European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe; merged into the European Union (EU)
on 7 February 1992; member states at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
members— ( 4) Iceland, Liechtenstein, Norway, Switzerland
address— 9-1 1 Rue de Varembe, CH-1202
Geneva 20, Switzerland
fe/ephone— [41 ](22)7491 3 35
FAX— [41] (22) 733 92 91
established-4 January 1960
effective— 3 May 1960
aim— to promote expansion of free trade
565
Appendix C: International Organizations and Groups (continued)
European Investment Bank (EIB) members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
address— B d Konrad Adenauer 100, L-2950
Luxembourg, Luxembourg
telephone— [352] 43791
FAX— (352] 437704
established— 25 March 1957
effective—] January 1958
aim— to promote economic development of the
EU and its predecessors, the EEC and the EC
European Monetary Union (EMU) members— (1 1) Austria, Belgium, Finland, France, Germany, Ireland, Italy, Luxembourg, Netherlands, Portugal,
Spain; note— Denmark, Sweden, and UK decided not to join, and Greece did not meet all the criteria to take part
note— a n integral part of the European Union
address— do European Commission, Rue de la
Loi 200, B-1049 Bruxelles, Belgium
telephone— [32] (2) 299 1 1 1 1
proposed— 1 February 1992
aim— to promote a single market by creating a
single currency, the euro; time table— 2 May
1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and
stock exchanges begin using euros; 1 January
2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
European Organization for Nuclear Research members— (1 9) Austria, Belgium, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Italy,
(CERN) Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— { 8) EU, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization
note— acronym retained from the predecessor (UNESCO), US, Yugoslavia (suspended)
organization Conseil Europeen pour la
Recherche Nucleaire
address— CH-1 211 Geneva 23, Switzerland
fe/epbone— [41] (22) 767 61 11
FAX-(41] (22) 767 65 55
established — 1 July 1953
effective— 29 September 1954
aim— to foster nuclear research for peaceful
purposes only
European Space Agency (ESA) members— (14) Austria, Belgium, Denmark, Finland, France, Germany, Ireland, Italy, Netherlands, Norway, Spain,
Sweden, Switzerland, UK
address— ESA Headquarters, 8-1 0 Rue Mario cooperating state— (1 ) Canada
Nikis, F-75738 Paris CEDEX 15, France
telephone— {33] (1) 53 69 76 54
FAX— [33] (1) 53 69 75 60
established —31 July 1973
effective—] May 1975
aim— to promote peaceful cooperation in space
research and technology
566
Appendix C: International Organizations and Groups (continued)
European Union (EU)
note— evolved from the European Community
(EC)
address— do European Commission, Rue de la
Loi 200, B-1049 Brussels, Belgium
telephone— {32] (2) 299 1 1 11
FAX''— [32] (2) 295 01 38 through 295 01 40
established— 7 February 1992
effective— 1 November 1993
aim— to coordinate policy among the 15
members in three fields: economics, building on
the European Economic Community''s (EEC)
efforts to establish a common market and
eventually a common currency to be called the
''euro1, which will supercede the EU''s accounting
unit, the ECU; defense, within the concept of a
Common Foreign and Security Policy (CFSP);
and justice and home affairs, including
immigration, drugs, terrorism, and improved
living and working conditions
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
members— { 12) Albania, Bulgaria, Cyprus, Czech Republic, Estonia, Hungary, Latvia, Lithuania, Malta, Poland,
Romania, Slovakia
First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed
countries (DCs)
Food and Agriculture Organization (FAO)
address— Wale delle Terme di Caracalla,
1-00100 Rome, Italy
telephone— {33] (6) 57051
FAX— [39] (6) 5705 3152
established—] 6 October 1945
aim— to raise living standards and increase
availability of agricultural products, as a UN
specialized agency
members— (176) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Flonduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
associate member— (1) Puerto Rico
former Soviet Union (FSU)
a collective term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of
1 5 countries consists of Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe
(former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 27 countries consists of Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Russia, Serbia and
Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; this group is identical to the IMF
group "countries in transition" except for the IMF''s inclusion of Mongolia
567
Appendix C: International Organizations and Groups (continued)
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also
known as the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF''s "advanced economies" group
Four Tigers
another term for the Four Dragons; see Four Dragons
Franc Zone (FZ)
note— also known as Conference des Ministres
des Finances des Pays de la Zone Franc
address— do Banque de France, Service de la
Zone Franc, 39 Rue des Croix des Petits
Champs, F-75001 Paris, France
telephone-[33\\ (1) 42 92 42 92
FAXH33] (1)42 96 04 23
established— 20 December 1945
aim— to form a monetary union among countries
whose currencies are linked to the French franc
members— { 16) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo,
Cote d''Ivoire, Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo; note— France
includes metropolitan France, the four overseas departments of France (French Guiana, Guadeloupe, Martinique,
Reunion), the two territorial collectivities of France (Mayotte, Saint Pierre and Miquelon), and the three overseas
territories of France (French Polynesia, New Caledonia, Wallis and Futuna)
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included
Angola, Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade
(GATT)
was established 30 October 1947 to promote the expansion of international trade on a nondiscriminatory basis;
subsumed by the World T rade Organization (WT rO) on 1 January 1 995; members at the time were Angola, Antigua
and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad,
Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba,
Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Egypt, El Salvador, Fiji, Finland, France,
Gabon, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea-Bissau, Guyana, Haiti, Honduras,
Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait,
Lesotho, Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname,
Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE,
UK, US, Uruguay, Venezuela, Yugoslavia (suspended), Zambia, Zimbabwe
Group of 2 (G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most
powerful economic giants Japan, US
Group of 3 (G-3)
members— ( 3) Colombia, Mexico, Venezuela
address— do Ministry of Foreign Affairs,
Grupo de los tres, Caracas, Venezuela
established— NA October 1 990
aim— mechanism for policy coordination
Group of 5 (G-5)
members— (5) France, Germany, Japan, UK, US
established— 22 September 1985
aim— to coordinate the economic policies
of five major noncommunist economic powers
Group of 6 (G-6)
note— also known as Groupe des Six Sur le
Desarmement; not to be confused with the Biq
Six
established— 22 May 1984
aim— to achieve nuclear disarmament
members— ( 6) Argentina, Greece, India, Mexico, Sweden, Tanzania
568
Appendix C: International Organizations and Groups (continued)
Group of 7 (G-7)
nofe— membership is the same as the Big
Seven
established— 22 September 1985
aim— to facilitate economic cooperation among
the seven major noncommunist economic
powers
members— (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established NA October 1975 to facilitate economic cooperation among the developed countries (DCs) that
participated in the Conference on International Economic Cooperation (CIEC), held in several sessions between NA
December 1 975 and 3 June 1 977; members were Australia, Canada, EU (as one member), Japan, Spain, Sweden,
Switzerland, US
Group of 9 (G-9)
established— NA
aim— to discuss matters of mutual interest on an
informal basis
members— (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Sweden, Yugoslavia
Group of 1 0 (G-1 0)
nofe— also known as the Paris Club; includes
the wealthiest members of the IMF who provide
most of the money to be loaned and act as the
informal steering committee; name persists in
spite of the addition of Switzerland on NA April
1984
address— do IMF Office in Europe, 64-66
Avenue d’lena, F-751 16 Paris, France
telephone— [33] (1) 40 69 30 80
FAX''— [33] (1) 47 23 40 89
established—NA October 1962
aim— to coordinate credit policy
members— (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
nonstate participants— (4) BIS, EU, IMF, OECD
Group of 11 (G-1 1 )
nofe— also known as the Cartagena Group
established— 22 June 1984, in Cartagena,
581
Appendix C: International Organizations and Groups (continued)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their
economies; formerly known as the newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
address— Permanent Representative of
Colombia to the United Nations, 140 East 57th
Street, New York, NY 10022, US
telephone-{t] (212) 355 7776
FAX— [1] (212) 371 2813
established— 1-6 September 1961
aim— to establish political and military
cooperation apart from the traditional East or
West blocs
members— (1 12 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Qatar, Rwanda, Saint Lucia, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
observers—] 18) Afro-Asian Solidarity Organization, Antigua and Barbuda, Arab League, Armenia, Azerbaijan,
Brazil, China, Costa Rica, Croatia, Dominica, El Salvador, Kanaka Socialist National Liberation Front (New
Caledonia), Mexico, Organization of African Unity, Organization of the Islamic Conference, Socialist Party of Puerto
Rico, UN, Uruguay
guests— (22) Australia, Austria, Bosnia and Herzegovina, Bulgaria, Canada, Dominican Republic, Finland,
Germany, Greece, Hungary, Italy, Netherlands, NZ, Norway, Poland, Portugal, Romania, San Marino, Slovenia,
Spain, Sweden, Switzerland
Nordic Council (NC)
address— Store Strandstraede 18, PB 3043,
DK-1021 Kobenhavn K, Denmark
telephone— [45] 33 96 04 00
FAX— [45] 33 1 1 18 70
established— 16 March 1952
effective— 12 February 1953
aim— to promote regional economic, cultural,
and environmental cooperation
members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
address— Fabianinkatu 34, P.O. Box 249,
FIN-00171 Helsinki, Finland
fe/epfone— [358] (0) 18001
FAX— [358] (0) 1800210
established— 4 December 1975
effective— 1 June 1976
aim— to promote economic cooperation and
development
members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern
Hemisphere; the counterpart of the South; see developed countries (DCs)
North Atlantic Cooperation Council (NACC)
see Euro-Atlantic Partnership Council (EAPC)
North Atlantic Treaty Organization (NATO)
address— B-1 110 Brussels, Belgium
telephone— {32] (2) 7074111
FAX— [32] (2) 707 4579
established— 17 September 1949
aim— to promote mutual defense and
cooperation
members— (16) Belgium, Canada, Denmark, France, Germany, Greece, Iceland, Italy, Luxembourg, Netherlands,
Norway, Portugal, Spain, Turkey, UK, US; note— Czech Republic, Hungary, and Poland to join in April 1999
582
Appendix C: International Organizations and Groups (continued)
Nuclear Energy Agency (NEA)
address— AEN/NE A, Le Seine St. Germain,
12 Boulevard des lies, F-92130
Issy-les-Moulineaux, France
fe/epbone— [33] (1) 45 24 10 10
FAX— [33] (1)452411 10
established— NA 1958
aim— to promote the peaceful uses of nuclear
energy; associated with OECD
members— (27) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal,
Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers
Group or the London Group
address— do Permanent Mission of Japan in
Vienna, Prinz-Eugen Strasse 8-10, A-1040
Vienna, Austria
telephone— {43] (1) 505 5467
FAX— [43] (1) 505 6167
established— NA 1974
effective— NA 1975
aim— to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical information
to countries of proliferation concern and regions
of conflict and instability
members— (34) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
observer— (1 ) European Commission (a policy-planning body for the EU)
Organismo para la Proscripcion de las
Armas Nucleares en la America
Latina y el Caribe (OPANAL)
see Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
Organization for Economic Cooperation
and Development (OECD)
address— 2 Rue Andre Pascal, F-75775 Paris
CEDEX 16, France
telephone— [33] (1) 45 24 82 00
FAX— [33] (1) 45 24 85 00, 45 24 81 76
established— 14 December 1960
effective— 30 September 1961
aim— to promote economic cooperation and
development
members— (29) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
special member— ( 1) EU
583
Appendix C: International Organizations and Groups (continued)
Organization for Security and Cooperation in
Europe (OSCE)
note— formerly the Conference on Security and
Cooperation in Europe (CSCE)
address— Karntner Ring 5-7, A-1 010 Vienna,','ab33ea2f24ff739827b20cbacc17e0e4f96015e4ebb093b65eff74d737e5ad79','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39a32ebd474ee440c969516bec5ea1fc987a026581bcd294718c96c47604773c',1999,'BW','Botswana','transnational-issues',1088,'telephone— [267] (31) 351863, 351864, 351865
FAX— [267] (31) 372848
established— 17 August 1992
aim— to promote regional economic
development and integration
Southern Cone Common Market (Mercosur) members— (A) Argentina, Brazil, Paraguay, Uruguay
associate member— { 1) Chile
note— also known as Mercado Comun del Cono
Sur (Mercosur)
address— Rincon 575 Piso 12, 11000
Montevideo, Uruguay
telephone— [598] (2) 9164590
FAX— [598] (2)9164591
established— 26 March 1991
aim— to increase regional economic cooperation
members— ( 16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
587
Appendix C: International Organizations and Groups (continued)
Statistical Commission
members— (24) selected on a rotating basis from all regions
address— Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainable Development,
United Nations, Room 2963, New York, NY
10017, US
telephone— {1] (212) 963 1234
FAX— [1] (212) 963 5935
established— 21 June 1946
aim— to deal with development and
standardization of national statistics of interest
to the UN, as part of the Economic and Social
Council organization
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed
countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
Union Douaniere et Economique de
I''Afrique Centrale (UDEAC)
see Central African Customs and Economic Union (UDEAC)
United Nations (UN)
address— United Nations, New York, NY 10017,
US
telephone— [1] (212) 963 1234
FAX— [1] (212) 963 4879
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security and to promote cooperation involving
economic, social, cultural, and humanitarian
problems
members— (1 84 excluding Yugoslavia) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe; note - all UN members are
represented in the General Assembly
observers— ( 2 plus the Palestine Liberation Organization) Holy See, Switzerland, Palestine Liberation Organization
United Nations Angola Verification Mission
(UNAVEM III)
successor to original UNAVEM and UNAVEM II; established 20 December 1988; renewed for third time 8 February
1 995; aim was to assist the parties in restoring peace and achieving national reconciliation in Angola on the basis
of the Peace Accords, the Lusaka Protocol, and relevant Security Council resolutions; established by the UN
Security Council; members Bangladesh, Brazil, Bulgaria, Egypt, Fiji, Guinea-Bissau, Hungary, India, Jordan,
Mongolia, Mali, Morocco, Netherlands, Nigeria, Portugal, Sweden, Tanzania, Uruguay, Zambia, Zimbabwe;
disbanded 30 June 1997
United Nations Assistance Mission for
Rwanda (UNAMIR)
established 5 October 1993 to support and provide safe conditions for displaced persons and human rights
monitors, and to assist in training a new national police force; established by the UN Security Council; members
were Argentina, Australia, Austria, Bangladesh, Canada, Chad, Republic of the Congo, Djibouti, Fiji, Germany,
Ghana, Guinea, Guinea-Bissau, India, Jordan, Malawi, Mali, Niger, Nigeria, Pakistan, Russia, Senegal, Switzerland,
Tunisia, Uruguay, Zambia, Zimbabwe; terminated 8 March 1996
588
Appendix C: International Organizations and Groups (continued)
United Nations Children''s Fund (UNICEF) members— (36) selected on a rotating basis from all regions
note— acronym retained from the predecessor
organization UN International Children''s
Emergency Fund
address— UNICEF House, Three United
Nations Plaza, New York, NY 10017, US
telephone— [\\] (212) 326 7000
FAY— [1] (212) 888 7465, 888 7454
established— 11 December 1946
aim— to help establish child health and welfare
services
United Nations Civilian Police Mission in members— (1 1) Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo, Tunisia, US
Haiti (MIPONUH)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
fe/ep/ione— [1] (212) 963 1234
FAX— [1] (212) 963 4879
established— 1 December 1997
aim— to support the professionalization of the
Haitian National Police; established by UN
Security Council; completion was expected by
30 November 1998
United Nations Civilian Police Support members— (20) Argentina, Austria, Denmark, Egypt, Fiji, Finland, Indonesia, Ireland, Jordan, Kenya, Lithuania,
Group in Croatia Nepal, Nigeria, Norway, Poland, Russia, Sweden, Tunisia, Ukraine, US
established— 19 December 1997
aim— to monitor the Croatian police with respect
to the return of displaced persons
United Nations Conference on Trade and members— ( 188) all UN members plus Holy See, Switzerland, Tonga
Development (UNCTAD)
address— UNCTAD, Palais des Nations,
CH-1211 Geneva 10, Switzerland
fe/ephone— [41] (22) 917 12 34, 907 12 34
FAX— [41] (22) 907 00 57
established— 30 December 1964
aim— to promote international trade
United Nations Confidence Restoration established 31 March 1 995 to separate Croatian and Krajina Serb forces; to monitor demilitarization of the Prevlaka
Operation in Croatia (UNCRO) Peninsula; to maintain a presence on Croatia’s international borders; to monitor and report the crossing of military
personnel, equipment, supplies and weapons; to facilitate delivery of humanitarian assistance; to aid refugees and
displaced persons; to protect ethnic minorities; and to clear mines; established by the UN Security Council;
members were Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Estonia,
Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya, Lithuania, Malaysia, Nepal, Netherlands,
Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Senegal, Slovakia, Spain, Sweden, Tunisia, Turkey, Ukraine,
UK, US; disbanded January 1996
589
Appendix C: International Organizations and Groups (continued)
United Nations Development Program members— (36) selected on a rotating basis from all regions
(UNDP)
address— One United National Plaza, New
York, NY 10017, US
telephone— {!] (212) 906 5788, 906 5000
FAX''— [1] (212) 906 5365
established— 22 November 1965
aim— to provide technical assistance to
stimulate economic and social development
United Nations Disengagement Observer members— (A) Austria, Canada, Japan, Poland
Force (UNDOF)
address— do Department of Peace-keeping
Operations, United Nations, Room S-3260E,
New York, NY 10017, US
telephone— {t] (212) 963 1234
FAX— {1] (212) 963 4879
established— 31 May 1974
aim— to observe the 1973 Arab-lsraeli
cease-fire; established by the UN Security
Council
members— { 186) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended),
Zambia, Zimbabwe
assodate members— {A) Aruba, British Virgin Islands, Macau, Netherlands Antilles
United Nations Environment Program members— (58) selected on a rotating basis from all regions
(UNEP)
address— P.O. Box 30552, Nairobi, Kenya
fe/ephone— [254] (2) 230800, 520600, 621234
FAX— [254] (2) 226890, 623927
established— 15 December 1972
aim— to promote international cooperation on all
environmental matters
United Nations Educational, Scientific, and
Cultural Organization (UNESCO)
address— 7 place de Fontenoy, F-75352 Paris
07SP, France
telephone— [33] (1 ) 45 68 10 00
FAX— [33] (1 ) 45 67 1 6 90
established— 16 November 1945
effective— A November 1946
aim— to promote cooperation in education,
science, and culture
590
Appendix C: International Organizations and Groups (continued)
United Nations General Assembly members— { 1 85) all UN members are represented in the General Assembly
address— see United Nations
established— 26 June 1945
effective— 24 October 1945
aim— to function as the primary deliberative
organ of the UN
United Nations High Commissioner for
Refugees (UNHCR)
address— Case Postale 2500, Depot, CH-1211
Geneva 2, Switzerland
fe/ephone— {41] (22) 739 81 11
FAX— [41] (22) 731 95 46
established— 3 December 1949
effective — 1 January 1951
aim— to ensure the humanitarian treatment of
refugees and find permanent solutions to
refugee problems
United Nations Industrial Development members— ( 168) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Austria, Azerbaijan, The Bahamas,
Organization (UNIDO) Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
address— Vienna International Center, P.O. Box African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
300, A-1 400 Vienna, Austria Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
telephone— [43] (1) 21 1 310 Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The
FAX— [43] (1) 23 21 56 Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
established— 17 November 1966 Honduras, Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea,
effective— 1 January 1967 South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Luxembourg, The Former
aim— UN specialized agency that promotes Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
industrial development especially among the Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
members Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senega!, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
United Nations Institute for Training and
Research (UNITAR)
address— Palais des Nations, Bureau 1070,
CH-1211, Geneva 10, Switzerland
fe/ephone— [41] (22) 798-58-50, 798-84-00
FAX— [41] (22) 733-13-83
established— 11 December 1963
aim— to help the UN become more effective
through training and research
members (Board of Trustees)— (17) Argentina, Australia, Austria, Cameroon, Chile, China, Egypt, France, India,
Ireland, Italy, Japan, Libya, Nigeria, Pakistan, Russia, Switzerland; note— the UN Secretary General can appoint up
to 30 members
members— (52) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada, China, Colombia,
Democratic Republic of the Congo, Denmark, Ethiopia, Finland, France, Germany, Greece, Holy See, Hungary,
India, Iran, Israel, Italy, Japan, Lebanon, Lesotho, Madagascar, Morocco, Namibia, Netherlands, Nicaragua,
Nigeria, Norway, Pakistan, Philippines, Poland, Russia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland,
Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yugoslavia
591
Appendix C: International Organizations and Groups (continued)
United Nations Interim Force in Lebanon members— (9) Fiji, Finland, France, Ghana, Ireland, Italy, Nepal, Norway, Poland
(UNIFIL)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [t] (212) 963 1234
FAY— [1] (212) 963 4879
established— 19 March 1978
aim— to confirm the withdrawal of Israeli forces,
and assist in reestablishing Lebanese authority
in southern Lebanon; established by the UN
Security Council
United Nations Iraq-Kuwait Observation
Mission (UNIKOM)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, USA
telephone— {1] (212) 963 1234
FAX—{1] (212) 963 4879
established— 9 April 1991
aim— to observe and monitor the demilitarized
zone established between Iraq and Kuwait;
established by the UN Security Council
United Nations Military Observer Group in members— (8) Belgium, Chile, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
India and Pakistan (UNMOGIP)
address— do Department of Peace-keeping
Operations, Room 3727, United Nations, New
York, NY 10017, US
telephone— {t] (212) 963 5721
FAX— [1] (212) 758 2718
established— 13 August 1948
aim— to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
United Nations Mission for the Referendum members— (27) Argentina, Austria, Bangladesh, China, Egypt, El Salvador, France, Ghana, Greece, Guinea,
in Western Sahara (MINURSO) Honduras, Ireland, Italy, Kenya, South Korea, Malaysia, Nigeria, Pakistan, Poland, Portugal, Russia, Sweden, Togo,
Tunisia, US, Uruguay, Venezuela
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{1] (212) 963 1234
FAX— [1] (212) 963 4879
established— 29 April 1991
aim— to supervise the cease-fire and conduct a
referendum in Western Sahara; established by
the UN Security Council
members— ( 33) Argentina, Austria, Bangladesh, Canada, China, Denmark, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, India, Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania, Russia,
Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay, Venezuela
592
Appendix C: International Organizations and Groups (continued)
United Nations Mission in Bosnia and
Herzegovina (UNMIBH)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {1] (212) 963 1234
FAX- -[1] (212) 758 2718
established— 13 December 1995
aim— to establish an International Police Task
Force (IPTF) to implement the Dayton Peace
Agreement in Bosnia and Herzegovina
United Nations Mission in Haiti (UNMIH) established 23 September 1 993; aim was to assist in implementing the agreement to transfer power back into the
civilian government; established by the UN Security Council; became the United Nations Support Mission in Haiti
(UNSMIH) 28 June 1996 with the aim to assist in the professionalization of the Haitian National Police; members
were Algeria, Canada, France, India, Mali, Pakistan, Togo, US; disbanded 31 July 1997
United Nations Mission in the Central African members— { 1 3) Benin, Burkina Faso, Canada, Chad, Cote d''Ivoire, Egypt, France, Gabon, Mali, Portugal, Senegal,
Republic (MINURCA) Togo, Tunisia
address— c/o Department of Peacekeeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [\\] (212) 963-1234
FAX— [1] (212) 758-2718
established— 17 March 1998
aim— to provide security in the capital as the
government undertakes the necessary reforms
to provide its own security; to provide training to
civilian police
United Nations Mission of Observers in
Prevlaka (UNMOP)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {1] (212) 963 1234
FAX— [1] (212) 758 2718
established— 13 December 1992
aim— to monitor the demilitarization of the
Prevlaka peninsula
United Nations Mission of Observers in members— (1 1) China, Egypt, India, Kenya, Kyrgyzstan, Mali, NZ, Pakistan, Russia, UK, Zambia
Sierra Leone (UNOMSIL)
address— do Department of Peacekeeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-#] (212) 963-1234
FAX— [1] (212) 758-2718
established— 1 3 July 1 998
aim— to monitor the military and security
situation in Sierra Leone; to monitor the
disarmament and demobilization of combatants
and members of the Civil Defense Forces
(CFD); to assist in monitoring respect for
international humanitarian law
members— (25) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland,
Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Sweden, Switzerland, Ukraine
members— (40) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile, Denmark, Egypt, Estonia, Finland,
France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland, Italy, Jordan, Malaysia, Nepal,
Netherlands, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Senegal, Spain, Sweden, Switzerland, Thailand,
Tunisia, Turkey, Ukraine, UK, US
593
Appendix C: International Organizations and Groups (continued)
United Nations Mission of Observers in
Tajikistan (UNMOT)
members— (12) Austria, Bangladesh, Bulgaria, Denmark, Ghana, Indonesia, Jordan, Nigeria, Poland, Switzerland,
Ukraine, Uruguay
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [\\] (212) 963 1234
FAY— {1] (212) 758 2718
established— 16 December 1994
aim— to monitor and investigate violations of the
cease-fire of 17 September 1994 between
Tajikistan and the Tajik opposition and to assist
in the political negotiation process; established
by the UN Security Council
United Nations Observer Mission in Angola
(MONUA)
address— do Department of Peace-keeping
operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-m (212) 758 2718
established— 1 July 1997
aim— to assist in implementation of peace
agreement; oversee normalization of state
administration throughout National territory;
established by UN Security Council
members— (30) Bangladesh, Brazil, Bulgaria, Republic of the Congo, Egypt, France, Guinea-Bissau, Hungary,
India, Jordan, Kenya, Malaysia, Mali, Namibia, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Romania, Russia,
Senegal, Slovakia, Sweden, Tanzania, Ukraine, Uruguay, Zambia, Zimbabwe
United Nations Observer Mission in El
Salvador (ONUSAL)
established 20 May 1 991 to verify cease-fire arrangements and to monitor the maintenance of public order pending
the organization of a new National Civil Police; established by the UN Security Council; members were Argentina,
Austria, Brazil, Canada, Chile, Colombia, France, Guyana, Ireland, Italy, Mexico, Spain, Sweden, Venezuela;
disbanded April 1995
United Nations Observer Mission in Georgia
(UNOMIG)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{t] (212) 963 1234
FAX— [1] (212) 9634879
established— August 1993
aim— to verify compliance with the cease-fire
agreement, to monitor weapons exclusion zone,
and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security
Council
members— (22) Albania, Austria, Bangladesh, Czech Republic, Denmark, Egypt, France, Germany, Greece,
Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,','9951638811921233bbc4bdc970e84a6da062890aea893487256cfda41b0b8198','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('121692365e7a845569f7dfc5db2702c70550016bf73aacf08d212cc8532ae75f',1999,'ST','Sao Tome and Principe','transnational-issues',1089,'Wetlands
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling .
608
Appendix E:
Weights and Measures
Mathematical Notation Mathematical Power Name
1018 or 1,000,000,000,000,000,000
one quintillion
IO16 or 1,000,000,000,000,000
one quadrillion
1012 or 1,000,000,000,000
one trillion
109 or 1,000,000,000
one billion
106 or 1,000,000
one million
103 or 1,000
one thousand
102 or 100
one hundred
101 or 10
ten
1 0° or 1
one
10''1 or 0.1
one-tenth
1 0''2 or 0.01
one-hundredth
1 0''3 or 0.001
one-thousandth
1 0''6 or 0.000 001
one-millionth
109 or 0.000 000 001
one-billionth
1 0''12 or 0.000 000 000 001
one-trillionth
1015 or 0.000 000 000 000 001
one-quadrillionth
IO18 or 0.000 000 000 000 000 001 one-quintillionth
Metric Interrelationships Prefix Symbol Length, Area Volume
weight, or
capacity
exa
E
1018
1036
1054
peta
P
1015
1Q30
1046
tera
T
1012
1024
1036
giga
G
109
IO18
1027
mega
M
106
1012
1018
hectokilo
hk
105
1010
1015
myria
ma
104
10B
1012
kilo
k
103
106
109
hecto
h
102
104
106
basic unit
1 meter,
1 gram,
1 liter
1 meter2
1 meter3
deci
d
io-1
io-2
io-3
centi
c
io-2
io-4
IO6
milli
m
io-3
IO6
io-9
decimilli
dm
10-4
io-8
io-12
centimilli
cm
IO5
10-io
io-15
micro
u
io-6
io-12
10-18
nano
n
io-9
10-ie
io-27
pico
P
io-12
IO-m
IO*
femto
f
io-15
10-so
IQ-45
atto
a
10-18
IQ-36
10-54
609
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
acres
ares
40.468 564 224
acres
hectares
0.404 685 642 24
acres
square feet
43,560
acres
square kilometers
0.004 046 856 422 4
acres
square meters
4,046.856 422 4
acres
square miles (statute)
0.001 562 50
acres
square yards
4,840
ares
square meters
100
ares
square yards
119.599
barrels, US beer
gallons
31
barrels, US beer
liters
117.347 77
barrels, US petroleum
gallons (British)
34.97
barrels, US petroleum
gallons (US)
42
barrels, US petroleum
liters
158.987 29
barrels, US proof spirits
gallons
40
barrels, US proof spirits
titers
151.41647
bushels (US)
bushels (British)
0.968 9
bushels (US)
cubic feet
1.244 456
bushels (US)
cubic inches
2,150.42
bushels (US)
cubic meters
0.035 239 07
bushels (US)
cubic yards
0.046 090 96
bushels (US)
dekaliters
3.523 907
bushels (US)
dry pints
64
bushels (US)
dry quarts
32
bushels (US)
liters
35.239 070 17
bushels (US)
pecks
4
cables
fathoms
120
cables
meters
219.456
cables
yards
240
carat
milligrams
200
centimeters
feet
0.032 808 40
centimeters
inches
0.393 700 8
centimeters
meters
0.01
centimeters
yards
0.010 936 13
centimeters, cubic
cubic inches
0.061 023 744
centimeters, square
square feet
0.001 076 39
centimeters, square
square inches
0.155 000 31
centimeters, square
square meters
0.000 1
centimeters, square
square yards
0.000119 599
610
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
chains, square surveyor''s
ares
4.046 86
chains, square surveyor''s
square feet
4,356
chains, surveyor''s
feet
66
chains, surveyor''s
meters
20.116 8
chains, surveyor''s
rods
4
cords of wood
cubic feet
128
cords of wood
cubic meters
3.624 556
cords of wood
cubic yards
4.740 7
cups
liquid ounces (US)
8
cups
liters
0.236 588 2
degrees Celsius
degrees Fahrenheit
multiply by 1 .8 and add 32
degrees Fahrenheit
degrees Celsius
subtract 32 and divide by 1 .8
dekaliters
bushels
0.283 775 9
dekaliters
cubic feet
0.353146 7
dekaliters
cubic inches
610.237 4
dekaliters
dry pints
18.161 66
dekaliters
dry quarts
9.080 829 8
dekaliters
liters
10
dekaliters
pecks
1.135104
drams, avoirdupois
avoirdupois ounces
0.062 55
drams, avoirdupois
grains
27.344
drams, avoirdupois
grams
1.771 845 2
drams, troy
grains
60
drams, troy
grams
3.887 934 6
drams, troy
scruples
3
drams, troy
troy ounces
0.125
drams, liquid (US)
cubic inches
0.226
drams, liquid (US)
liquid drams (British)
1.041
drams, liquid (US)
liquid ounces
0.125
drams, liquid (US)
milliliters
3.696 69
drams, liquid (US)
minims
60
fathoms
feet
6
fathoms
meters
1.828 8
feet
centimeters
30.48
feet
inches
12
feet
kilometers
0.000 304 8
feet
meters
0.304 8
feet
statute miles
0.000 189 39
feet
yards
0.333 333 3
611
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
feet, cubic
bushels
0.803 563 95
feet, cubic
cubic decimeters
28.316 847
feet, cubic
cubic inches
1,728
feet, cubic
cubic meters
0.028 316 846 592
feet, cubic
cubic yards
0.037 037 04
feet, cubic
dry pints
51.428 09
feet, cubic
dry quarts
25.714 05
feet, cubic
gallons
7.480 519
feet, cubic
gills
239.376 6
feet, cubic
liquid ounces
957.506 5
feet, cubic
liquid pints
59.844 16
feet, cubic
liquid quarts
29.922 08
feet, cubic
liters
28.316 846 592
feet, cubic
pecks
3.214 256
feet, square
acres
0.000 022 956 8
feet, square
square centimeters
929.030 4
feet, square
square decimeters
9.290 304
feet, square
square inches
144
feet, square
square meters
0.092 903 04
feet, square
square yards
0.111 111 1
furlongs
feet
660
furlongs
inches
7,920
furlongs
meters
201.168
furlongs
statute miles
0.125
furlongs
yards
220
gallons, liquid (US)
cubic feet
0.133 680 6
gallons, liquid (US)
cubic inches
231
gallons, liquid (US)
cubic meters
0.003 785 411 784
gallons, liquid (US)
cubic yards
0.004 951 13
gallons, liquid (US)
gills (US)
32
gallons, liquid (US)
liquid gallons (British)
0.832 67
gallons, liquid (US)
liquid ounces
128
gallons, liquid (US)
liquid pints
8
gallons, liquid (US)
liquid quarts
4
gallons, liquid (US)
liters
3.785 411 784
gallons, liquid (US)
milliliters
3,785.411 784
gallons, liquid (US)
minims
61,440
gills (US)
centiliters
11.829 4
gills (US)
cubic feet
0.004 177 517
gills (US)
cubic inches
7.218 75
612
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply by
gills (US)
gallons
0.031 25
gills (US)
gills (British)
0.832 67
gills (US)
liquid ounces
4
gills (US)
liquid pints
0.25
gills (US)
liquid quarts
0.125
gills (US)
liters
0.118 294118 25
gills (US)
milliliters
118.294118 25
gills (US)
minims
1,920
grains
avoirdupois drams
0.036 571 43
grains
avoirdupois ounces
0.002 285 71
grains
avoirdupois pounds
0.000142 86
grains
grams
0.064 798 91
grains
kilograms
0.000 064 798 91
grains
milligrams
64.798 910
grains
pennyweights
0.042
grains
scruples
0.05
grains
troy drams
0.016 6
grains
troy ounces
0.002 083 33
grains
troy pounds
0.000173 61
grams
avoirdupois drams
0.564 383 39
grams
avoirdupois ounces
0.035 273 961
grams
avoirdupois pounds
0.002 204 622 6
grams
grains
15.432 361
grams
kilograms
0.001
grams
milligrams
1,000
grams
troy ounces
0.032 150 746 6
grams
troy pounds
0.002 679 23
hands (height of horse)
centimeters
10.16
hands (height of horse)
inches
4
hectares
acres
2.471 053 8
hectares
square feet
107,639.1
hectares
square kilometers
0.01
hectares
square meters
10,000
hectares
square miles
0.003 861 02
hectares
square yards
11,959.90
hundredweights, long
avoirdupois pounds
112
hundredweights, long
kilograms
50.802 345
hundredweights, long
long tons
0.05
hundredweights, long
metric tons
0.050 802 345
hundredweights, long
short tons
0.056
613
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
hundredweights, short
avoirdupois pounds
100
hundredweights, short
kilograms
45.359 237
hundredweights, short
long tons
0.044 642 86
hundredweights, short
metric tons
0.045 359 237
hundredweights, short
short tons
0.05
inches
centimeters
2.54
inches
feet
0.083 333 33
inches
meters
0.025 4
inches
millimeters
25.4
inches
yards
0.027 777 78
inches, cubic
bushels
0.000 465 025
inches, cubic
cubic centimeters
16.387 064
inches, cubic
cubic feet
0.000 578 703 7
inches, cubic
cubic meters
0.000 016 387 064
inches, cubic
cubic yards
0.000 021 433 47
inches, cubic
dry pints
0.029 761 6
inches, cubic
dry quarts
0.014 880 8
inches, cubic
gallons
0.004 329 0
inches, cubic
gills
0.138 528 1
inches, cubic
liquid ounces
0.554112 6
inches, cubic
liquid pints
0.034 632 03
inches, cubic
liquid quarts
0.017 316 02
inches, cubic
liters
0.016 387 064
inches, cubic
milliliters
16.387 064
inches, cubic
minims (US)
265.974 0
inches, cubic
pecks
0.001 860 10
inches, square
square centimeters
6.451 600
inches, square
square feet
0.006 944 44
inches, square
square meters
0.000 645 16
inches, square
square yards
0.000 771 605
kilograms
avoirdupois drams
564.383 4
kilograms
avoirdupois ounces
35.273 962
kilograms
avoirdupois pounds
2.204 622 622
kilograms
grains
15,432.36
kilograms
grams
1,000
kilograms
long tons
0.000 984 2
kilograms
metric tons
0.001
kilograms
short hundredweights
0.022 046 23
kilograms
short tons
0.001 102 31
kilograms
troy ounces
32.150 75
614
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
kilograms
troy pounds
2.679 229
kilometers
meters
1,000
kilometers
statute miles
0.621 371 192
kilometers, square
acres
247.105 38
kilometers, square
hectares
100
kilometers, square
square meters
1,000,000
kilometers, square
statute miles
0.386102 16
knots (nautical mi/hr)
kilometers/hour
1.852
knots (nautical mi/hr)
statute miles/hour
1.151
leagues, nautical
kilometers
5.556
leagues, nautical
nautical miles
3
leagues, statute
kilometers
4.828 032
leagues, statute
statute miles
3
links, square surveyor''s
square centimeters
404.686
links, square surveyor''s
square inches
62.726 4
links, surveyor''s
centimeters
20.116 8
links, surveyor''s
chains
0.01
links, surveyor''s
inches
7.92
liters
bushels
0.028 377 59
liters
cubic feet
0.035 314 67
liters
cubic inches
61.023 74
liters
cubic meters
0.001
liters
cubic yards
0.001 307 95
liters
dekaliters
0.1
liters
dry pints
1.816166
liters
dry quarts
0.908 082 98
liters
gallons
0.264172 052
liters
gills (US)
8.453 506
liters
liquid ounces
33.814 02
liters
liquid pints
2.113 376
liters
liquid quarts
1.056 688 2
liters
milliliters
1,000
liters
pecks
0.1135104
meters
centimeters
100
meters
feet
3.280 839 895
meters
inches
39.370 079
meters
kilometers
0.001
meters
millimeters
1,000
meters
statute miles
0.000 621 371
meters
yards
1.093 613298
615
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
meters, cubic
bushels
28.377 59
meters, cubic
cubic feet
35.314 666 7
meters, cubic
cubic inches
61,023.744
meters, cubic
cubic yards
1.307 950 619
meters, cubic
gallons
264.172 05
meters, cubic
liters
1,000
meters, cubic
pecks
113.5104
meters, square
acres
0.000 247 105 38
meters, square
hectares
0.000 1
meters, square
square centimeters
10,000
meters, square
square feet
10.763 910 4
meters, square
square inches
1,550.0031
meters, square
square yards
1.195 990 046
microns
meters
0.000 001
microns
inches
0.000 039 4
mils
inches
0.001
mils
millimeters
0.025 4
miles, nautical
kilometers
1.852 0
miles, nautical
statute miles
1.150 779 4
miles, statute
centimeters
160,934.4
miles, statute
feet
5,280
miles, statute
furlongs
8
miles, statute
inches
63,360
miles, statute
kilometers
1.609 344
miles, statute
meters
1,609.344
miles, statute
rods
320
miles, statute
yards
1,760
miles, square nautical
square kilometers
3.429 904
miles, square nautical
square statute miles
1.325
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
sections
1
miles, square statute
square kilometers
2.589 988110 336
miles, square statute
square nautical miles
0.755 miles
miles, square statute
square rods
102,400
milligrams
grains
0.015 432 358 35
milliliters
cubic inches
0.061 023 744
milliliters
gallons
0.000 26417
milliliters
gills (US)
0,008 453 5
milliliters
liquid ounces
0.033 814 02
616
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
milliliters
liquid pints
0,002 113 4
milliliters
liquid quarts
0.001 056 7
milliliters
liters
0.001
milliliters
minims
16.230 73
millimeters
inches
0.039 370 078 7
minims (US)
cubic inches
0.003 759 77
minims (US)
gilts (US)
0.000 520 83
minims (US)
liquid ounces
0.002 083 33
minims (US)
milliliters
0.061 611 52
minims (US)
minims (British)
1.041
ounces, avoirdupois
avoirdupois drams
16
ounces, avoirdupois
avoirdupois pounds
0.062 5
ounces, avoirdupois
grains
437.5
ounces, avoirdupois
grams
28.349 523125
ounces, avoirdupois
kilograms
0.028 349 523125
ounces, avoirdupois
troy ounces
0.911 458 3
ounces, avoirdupois
troy pounds
0.075 954 86
ounces, liquid (US)
cubic feet
0.001 044 38
ounces, liquid (US)
centiliters
2.957 35
ounces, liquid (US)
cubic inches
1.804 687 5
ounces, liquid (US)
gallons
0.007 812 5
ounces, liquid (US)
gills (US)
0.25
ounces, liquid (US)
liquid drams
8
ounces, liquid (US)
liquid ounces (British)
1.041
ounces, liquid (US)
liquid pints
0.062 5
ounces, liquid (US)
liquid quarts
0.031 25
ounces, liquid (US)
liters
0.029 573 53
ounces, liquid (US)
milliliters
29.573 529 6
ounces, liquid (US)
minims
480
ounces, troy
avoirdupois drams
17.554 29
ounces, troy
avoirdupois ounces
1.097143
ounces, troy
avoirdupois pounds
0.068 571 43
ounces, troy
grains
480
ounces, troy
grams
31.103 476 8
ounces, troy
pennyweights
20
ounces, troy
troy drams
8
ounces, troy
troy pounds
0.083 333 3
paces (US)
centimeters
76.2
paces (US)
inches
30
pecks (US)
bushels
0.25
617
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
pecks (US)
cubic feet
0.311 114
pecks (US)
cubic inches
537.605
pecks (US)
cubic meters
0.008 809 77
pecks (US)
cubic yards
0.011 522 74
pecks (US)
dekaliters
0.880 976 75
pecks (US)
dry pints
16
pecks (US)
dry quarts
8
pecks (US)
liters
8.809 767 5
pecks (US)
pecks (British)
0.968 9
pennyweights
grains
24
pennyweights
grams
1.555173 84
pennyweights
troy ounces
0.05
pints, dry (US)
bushels
0.015 625
pints, dry (US)
cubic feet
0.019 444 63
pints, dry (US)
cubic inches
33.600 312 5
pints, dry (US)
dekaliters
0.055 061 05
pints, dry (US)
dry pints (British)
0.968 9
pints, dry (US)
dry quarts
0.5
pints, dry (US)
liters
0.550 610 47
pints, liquid (US)
cubic feet
0.016 710 07
pints, liquid (US)
cubic inches
28.875
pints, liquid (US)
deciliters
4.731 76
pints, liquid (US)
gallons
0.125
pints, liquid (US)
gills (US)
4
pints, liquid (US)
liquid ounces
16
pints, liquid (US)
liquid pints (British)
0.832 67
pints, liquid (US)
liquid quarts
0.5
pints, liquid (US)
liters
0.473 176 473
pints, liquid (US)
milliliters
473.176 473
pints, liquid (US)
minims
7,680
points (typographical)
inches
0.013 837
points (typographical)
millimeters
0.351 459 8
pounds, avoirdupois
avoirdupois drams
256
pounds, avoirdupois
avoirdupois ounces
16
pounds, avoirdupois
grains
7,000
pounds, avoirdupois
grams
453.592 37
pounds, avoirdupois
kilograms
0.453 592 37
pounds, avoirdupois
long tons
0.000 446 428 6
618
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
pounds, avoirdupois
metric tons
0,000 453 592 37
pounds, avoirdupois
quintals
0.004 535 92
pounds, avoirdupois
short tons
0.000 5
pounds, avoirdupois
troy ounces
14.583 33
pounds, avoirdupois
troy pounds
1.215 278
pounds, troy
avoirdupois drams
210.651 4
pounds, troy
avoirdupois ounces
13.165 71
pounds, troy
avoirdupois pounds
0.822 857 1
pounds, troy
grains
5,760
pounds, troy
grams
373.241 721 6
pounds, troy
kilograms
0.373 241 721 6
pounds, troy
pennyweights
240
pounds, troy
troy ounces
12
quarts, dry (US)
bushels
0.031 25
quarts, dry (US)
cubic feet
0.038 889 25
quarts, dry (US)
cubic inches
67.200 625
quarts, dry (US)
dekaliters
0.1101221
quarts, dry (US)
dry pints
2
quarts, dry (US)
dry quarts (British)
0.968 9
quarts, dry (US)
liters
1.101 221
quarts, dry (US)
pecks
0.125
quarts, dry (US)
pints, dry (US)
2
quarts, liquid (US)
cubic feet
0.033 42014
quarts, liquid (US)
cubic inches
57.75
quarts, liquid (US)
deciliters
9.463 53
quarts, liquid (US)
gallons
0.25
quarts, liquid (US)
gills (US)
8
quarts, liquid (US)
liquid ounces
32
quarts, liquid (US)
liquid pints (US)
2
quarts, liquid (US)
liquid quarts (British)
0.832 67
quarts, liquid (US)
liters
0.946 352 946
quarts, liquid (US)
milliliters
946.352 946
quarts, liquid (US)
minims
15,360
quintals
avoirdupois pounds
220,462 26
quintals
kilograms
100
quintals
metric tons
0.1
rods
feet
16.5
rods
meters
5.029 2
rods
yards
5.5
619
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
rods, square
acres
0.006 25
rods, square
square meters
25.292 85
rods, square
square yards
30.25
scruples
grains
20
scruples
grams
1.295 978 2
scruples
troy drams
0.333
sections (US)
square kilometers
2.589 988 1
sections (US)
square statute miles
1
spans
centimeters
22.86
spans
inches
9
steres
cubic meters
1
steres
cubic yards
1.307 95
tablespoons
milliliters
14.786 76
tablespoons
teaspoons
3
teaspoons
milliliters
4.928 922
teaspoons
tablespoons
0.333 333
ton-miles, long
metric ton-kilometers
1.635 169
ton-miles, short
metric ton-kilometers
1.459 972
tons, gross register
cubic feet of permanently enclosed','cae0ffaec9de0e8b40c60085373ae2ab4060397e7affa1f8ab5d70e0c766f403','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d72586e032ed3fe9011d02070ad751d3d7bdb8d3ec5912bf6642ec645d42cb',1999,'ZW','Zimbabwe','transnational-issues',13,'Disputes--international: support to Islamic militants worldwide by
some factions; question over which group should hold Afghanistan''s
seat at the UN
Illicit drugs: world''s second-largest illicit opium producer
after Burma (cultivation in 1998--41,720 hectares, a 7% increase over
1997; potential production in 1998--1,350 metric tons) and a major
source of hashish; increasing number of heroin-processing
laboratories being set up in the country; major political factions
in the country profit from drug trade
======================================================================
@Albania
-------
Disputes--international: the Albanian Government supports
protection of the rights of ethnic Albanians outside of its borders
but has downplayed them to further its primary foreign policy goal
of regional cooperation; Albanian majority in Kosovo seeks
independence from Serbian Republic; Albanians in The Former Yugoslav
Republic of Macedonia claim discrimination in education, access to
public-sector jobs, and representation in government
Illicit drugs: increasingly active transshipment point for
Southwest Asian opiates, hashish, and cannabis transiting the Balkan
route and--to a far lesser extent--cocaine from South America destined
for Western Europe; limited opium and cannabis production; ethnic
Albanian narcotrafficking organizations active and rapidly expanding
in Europe
======================================================================
@Algeria
-------
Disputes--international: part of southeastern region claimed by','6e09441927bc5affdd10500ea43c455b2376529fb9c86d9a08873eb18b2bc2b5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa5a082285b2bf7d1f35e6c009dc0ea2b4a39861f59fea0c02e472d8836c7bfb',1999,'LY','Libya','transnational-issues',14,'======================================================================
@American Samoa
--------------
Disputes--international: none
======================================================================
@Andorra
-------
Disputes--international: none
======================================================================
@Angola
------
Disputes--international: none
Illicit drugs: increasingly used as a transshipment point for
cocaine and heroin destined for Western Europe and other African
states
======================================================================
@Anguilla
--------
Disputes--international: none
======================================================================
@Antarctica
----------
Disputes--international: Antarctic Treaty defers claims (see
Antarctic Treaty Summary above); sections (some overlapping) claimed
by Argentina, Australia, Chile, France (Adelie Land), New Zealand
(Ross Dependency), Norway (Queen Maud Land), and UK; the US and most
other nations do not recognize the territorial claims of other
nations and have made no claims themselves (the US reserves the
right to do so); no formal claims have been made in the sector
between 90 degrees west and 150 degrees west
======================================================================
@Antigua and Barbuda
-------------------
Disputes--international: none
Illicit drugs: over the long-term, considered a relatively minor
transshipment point for narcotics bound for the US and Europe and
recently, a transshipment point for heroin from Europe to the US;
potentially more significant as a drug-money-laundering center
======================================================================
@Arctic Ocean
------------
Disputes--international: some maritime disputes (see littoral
states); Svalbard is the focus of a maritime boundary dispute
between Norway and Russia
======================================================================
@Argentina
---------
Disputes--international: short section of the southwestern
boundary with Chile is indefinite--process to resolve boundary issues
is underway; claims UK-administered Falkland Islands (Islas
Malvinas); claims UK-administered South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
Illicit drugs: increasing use as a transshipment country for
cocaine headed for Europe and the US; increasing money-laundering
center
======================================================================
@Armenia
-------','bb7a4b683b2afe3dfee321fb7d8267db264a4c730f09ad23f460ce2ff292712c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5c3fa4a1d2462111708bb506a902bc0f5224ac552eb772df46dace0a6b45b93',1999,'AM','Armenia','transnational-issues',30,'Disputes--international: Armenia supports ethnic Armenians in the
Nagorno-Karabakh region of Azerbaijan in the longstanding,
separatist conflict against the Azerbaijani Government; traditional
demands on former Armenian lands in Turkey have subsided
Illicit drugs: illicit cultivator of cannabis mostly for domestic
consumption; increasingly used as a transshipment point for illicit
drugs--mostly opium and hashish--to Western Europe and the US via
Iran, Central Asia, and Russia
======================================================================
@Aruba
-----
Disputes--international: none
Illicit drugs: drug-money-laundering center and transit point for
narcotics bound for the US and Europe; added to the US list of major
drug producing or drug transit countries in December 1996
======================================================================
@Ashmore and Cartier Islands
---------------------------
Disputes--international: none
======================================================================
@Atlantic Ocean
--------------
Disputes--international: some maritime disputes (see littoral
states)
======================================================================
@Australia
---------
Disputes--international: territorial claim in Antarctica
(Australian Antarctic Territory)
Illicit drugs: Tasmania is one of the world''s major suppliers of
licit opiate products; government maintains strict controls over
areas of opium poppy cultivation and output of poppy straw
concentrate
======================================================================
@Austria
-------
Disputes--international: none
Illicit drugs: transshipment point for Southwest Asian heroin and
South American cocaine destined for Western Europe
======================================================================
@Azerbaijan
----------
Disputes--international: Armenia supports ethnic Armenians in the
Nagorno-Karabakh region of Azerbaijan in the longstanding,
separatist conflict against the Azerbaijani Government; Caspian Sea
boundaries are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivation of cannabis and opium
poppy, mostly for CIS consumption; limited government eradication
program; transshipment point for opiates via Iran, Central Asia, and
Russia to Western Europe
======================================================================
@Bahamas, The
------------
Disputes--international: none
Illicit drugs: transshipment point for cocaine and marijuana
bound for US and Europe; banking industry vulnerable to money
laundering
======================================================================
@Bahrain
-------','3e36d56c56937c070e9c70a028403da24ae58841b9e737254e0ed6510087e601','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('373b87dd90ff3420e3df954844967e4447ff173a85335c8aedfae104a8fc244d',1999,'SA','Saudi Arabia','transnational-issues',42,'Disputes--international: territorial dispute with Qatar over the
Hawar Islands and maritime boundary dispute with Qatar currently
before the International Court of Justice (ICJ)
======================================================================
@Baker Island
------------
Disputes--international: none
======================================================================
@Bangladesh
----------
Disputes--international: a portion of the boundary with India is
indefinite; dispute with India over South Talpatty/New Moore Island
Illicit drugs: transit country for illegal drugs produced in
neighboring countries
======================================================================
@Barbados
--------
Disputes--international: none
Illicit drugs: one of many Caribbean transshipment points for
narcotics bound for the US and Europe
======================================================================
@Bassas da India
---------------
Disputes--international: claimed by Madagascar
======================================================================
@Belarus
-------
Disputes--international: none
Illicit drugs: limited cultivation of opium poppy and cannabis,
mostly for the domestic market; transshipment point for illicit
drugs to and via Russia, and to the Baltics and Western Europe
======================================================================
@Belgium
-------
Disputes--international: none
Illicit drugs: source of precursor chemicals for South American
cocaine processors; transshipment point for cocaine, heroin,
hashish, and marijuana entering Western Europe
======================================================================
@Belize
------
Disputes--international: border with Guatemala in dispute
Illicit drugs: transshipment point for cocaine; small-scale
illicit producer of cannabis for the international drug trade; minor
money-laundering center
======================================================================
@Benin
-----
Disputes--international: none
Illicit drugs: transshipment point for narcotics associated with
Nigerian trafficking organizations and most commonly destined for
Western Europe and the US
======================================================================
@Bermuda
-------
Disputes--international: none
======================================================================
@Bhutan
------
Disputes--international: with Nepal over 91,000 Bhutanese refugees
in Nepal
======================================================================
@Bolivia
-------
Disputes--international: territorial dispute with Bahrain over the
Hawar Islands and maritime boundary dispute with Bahrain currently
before the International Court of Justice (ICJ); in 1996, agreed
with Saudi Arabia to demarcate border per 1992 accord; that process
is ongoing
======================================================================
@Reunion
-------','7ed0eecfbe8b2e416e255643e22a03b7f0ecea0930468e429e77836320bf3727','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('508b5643abf26d40205a2e159cf15fba9751031d9d3a34e407e905a0b81ba7e3',1999,'PY','Paraguay','transnational-issues',46,'Disputes--international: has wanted a sovereign corridor to the
South Pacific Ocean since the Atacama area was lost to Chile in
1884; dispute with Chile over Rio Lauca water rights
Illicit drugs: world''s third-largest cultivator of coca (after
Peru and Colombia) with an estimated 46,900 hectares under
cultivation in 1997, a 2.5% decrease in overall cultivation of coca
from 1996 levels; Bolivia, however, is the second-largest producer
of coca leaf; even so, farmer abandonment and voluntary and forced
eradication programs resulted in leaf production dropping from
75,100 metric tons in 1996 to 73,000 tons in 1997, a 3% decrease
from 1996; government considers all but 12,000 hectares illicit;
intermediate coca products and cocaine exported to or through
Colombia, Brazil, Argentina, and Chile to the US and other
international drug markets; alternative crop program aims to reduce
illicit coca cultivation
======================================================================
@Bosnia and Herzegovina
----------------------','d5cd38fe8d9ecc61a282b9b212a5d7a02716c7e70d3f813cc84712967c27d8ae','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bdd4188b2f2b7b9a4b1aac991c545e9e4a6c6edeeacde5372fbc49cb74ef70d',1999,'HR','Croatia','transnational-issues',55,'Disputes--international: disputes with Serbia over Serbian
populated areas
Illicit drugs: minor transit point for marijuana and opiate
trafficking routes to Western Europe
======================================================================
@Botswana
--------
Disputes--international: quadripoint with Namibia, Zambia, and
Zimbabwe is in disagreement; dispute with Namibia over uninhabited
Kasikili (Sidudu) Island in Linyanti (Chobe) River is presently at
the ICJ; at least one other island in Linyanti River is contested
======================================================================
@Bouvet Island
-------------
Disputes--international: none
======================================================================
@Brazil
------
Disputes--international: two short sections of boundary with
Uruguay are in dispute--Arroio Invernada (Arroyo de la Invernada)
area of the Rio Quarai (Rio Cuareim) and the islands at the
confluence of the Rio Quarai and the Uruguay River
Illicit drugs: limited illicit producer of cannabis, minor coca
cultivation in the Amazon region, mostly used for domestic
consumption; government has a large-scale eradication program to
control cannabis; important transshipment country for Bolivian,
Colombian, and Peruvian cocaine headed for the US and Europe;
increasingly used by traffickers as a way station for narcotics air
transshipments between Peru and Colombia
======================================================================
@British Indian Ocean Territory
------------------------------
Disputes--international: the Chagos Archipelago is claimed by
Mauritius and Seychelles
======================================================================
@British Virgin Islands
----------------------','78ce94a3470cf5c3db8c8b290947d42efaedb081dcff0b876e7708d96d0e4c08','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9892adb9c5e23d92d18a420a88bfaec0436c6aca6f69214a36dc9cdbbb7df13f',1999,'PR','Puerto Rico','transnational-issues',64,'Disputes--international: none
======================================================================
@Brunei
------
Disputes--international: none
======================================================================
@Morocco
-------
Disputes--international: claims and administers Western Sahara,
but sovereignty is unresolved and the UN is attempting to hold a
referendum on the issue; the UN-administered cease-fire has been in
effect since September 1991; Spain controls five places of
sovereignty (plazas de soberania) on and off the coast of
Morocco--the coastal enclaves of Ceuta and Melilla which Morocco
contests, as well as the islands of Penon de Alhucemas, Penon de
Velez de la Gomera, and Islas Chafarinas
Illicit drugs: illicit producer of hashish; trafficking on the
increase for both domestic and international drug markets; shipments
of hashish mostly directed to Western Europe; transit point for
cocaine from South America destined for Western Europe
======================================================================
@Mozambique
----------
Disputes--international: none
Illicit drugs: Southern African transit hub for South American
cocaine probably destined for the European and US markets; producer
of hashish and methaqualone
======================================================================
@Namibia
-------
Disputes--international: quadripoint with Botswana, Zambia, and
Zimbabwe is in disagreement; dispute with Botswana over uninhabited
Kasikili (Sidudu) Island in Linyanti (Chobe) River is presently at
the ICJ; at least one other island in Linyanti River is contested
======================================================================
@Nauru
-----
Disputes--international: none
======================================================================
@Navassa Island
--------------
Disputes--international: claimed by Haiti
======================================================================
@Nepal
-----
Disputes--international: with Bhutan over 91,000 Bhutanese
refugees in Nepal
Illicit drugs: illicit producer of cannabis for the domestic and
international drug markets; transit point for opiates from Southeast
Asia to the West
======================================================================
@Netherlands
-----------
Disputes--international: none
Illicit drugs: important gateway for cocaine, heroin, and hashish
entering Europe; major European producer of illicit amphetamines and
other synthetic drugs
======================================================================
@Netherlands Antilles
--------------------
Disputes--international: none
Illicit drugs: money-laundering center; transshipment point for
South American drugs bound for the US and Europe
======================================================================
@New Caledonia
-------------
Disputes--international: maritime boundary disputes with Canada
(Dixon Entrance, Beaufort Sea, Strait of Juan de Fuca, Machias Seal
Island); US Naval Base at Guantanamo Bay is leased from Cuba and
only mutual agreement or US abandonment of the area can terminate
the lease; Haiti claims Navassa Island; US has made no territorial
claim in Antarctica (but has reserved the right to do so) and does
not recognize the claims of any other nation; Marshall Islands
claims Wake Atoll
Illicit drugs: consumer of cocaine shipped from Colombia through
Mexico and the Caribbean; consumer of heroin, marijuana, and
increasingly methamphetamines from Mexico; consumer of high-quality
Southeast Asian heroin; illicit producer of cannabis, marijuana,
depressants, stimulants, hallucinogens, and methamphetamines;
drug-money-laundering center
======================================================================
@Uruguay
-------','dc1397da6639abb6ef01ca3af30ae3c64bb19de356cbe34488a4d1fa978bed2e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8dde9279eaa7cb26032615f1ceead7a198f18326bbf484d0031969abb4b7283',1999,'MY','Malaysia','transnational-issues',75,'Disputes--international: possibly involved in a complex dispute
over the Spratly Islands with China, Malaysia, Philippines, Taiwan,
and Vietnam; in 1984, Brunei established an exclusive fishing zone
that encompasses Louisa Reef in the southern Spratly Islands, but
has not publicly claimed the island
======================================================================
@Bulgaria
--------
Disputes--international: twenty bilateral agreements remain
unsigned in a dispute over Bulgarian nonrecognition of Macedonian as
a language distinct from Bulgarian
Illicit drugs: major European transshipment point for Southwest
Asian heroin and, to a lesser degree, South American cocaine for the
European market; limited producer of precursor chemicals;
significant producer of amphetamines, much of which are consumed in
the Middle East
======================================================================
@Burkina Faso
------------
Disputes--international: none
======================================================================
@Burma
-----
Disputes--international: sporadic conflict with Thailand over
alignment of border
Illicit drugs: world''s largest producer of illicit opium
(cultivation in 1998--130,300 hectares, a 16% decline from 1997;
potential production--1,750 metric tons, down 26% due to drought and
the first eradication effort since the current government took power
in 1987) and a minor producer of cannabis for the international drug
trade; surrender of drug warlord KHUN SA''s Mong Tai Army in January
1996 was hailed by Rangoon as a major counternarcotics success, but
lack of serious government commitment and resources continues to
hinder the overall antidrug effort; growing role in the production
of methamphetamines for regional consumption
======================================================================
@Burundi
-------
Disputes--international: none
======================================================================
@Cambodia
--------
Disputes--international: offshore islands and sections of the
boundary with Vietnam are in dispute; maritime boundary with Vietnam
not defined; parts of border with Thailand are indefinite; maritime
boundary with Thailand not clearly defined
Illicit drugs: transshipment site for Golden Triangle heroin;
possible money laundering; narcotics-related corruption reportedly
involving some in the government, military, and police; possible
small-scale opium, heroin, and amphetamine production; large
producer of cannabis for the international market
======================================================================
@Cameroon
--------
Disputes--international: delimitation of international boundaries
in the vicinity of Lake Chad, the lack of which led to border
incidents in the past, is completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria; dispute with Nigeria over land
and maritime boundaries around the Bakasi Peninsula and Lake Chad is
currently before the International Court of Justice
======================================================================
@Canada
------
Disputes--international: maritime boundary disputes with the US
(Dixon Entrance, Beaufort Sea, Strait of Juan de Fuca, Machias Seal
Island)
Illicit drugs: illicit producer of cannabis for the domestic drug
market; use of hydroponics technology permits growers to plant large
quantities of high-quality marijuana indoors; growing role as a
transit point for heroin and cocaine entering the US market
======================================================================
@Cape Verde
----------
Disputes--international: none
Illicit drugs: used as a transshipment point for illicit drugs
moving from Latin America and Africa destined for Western Europe
======================================================================
@Cayman Islands
--------------
Disputes--international: none
Illicit drugs: vulnerable to drug money laundering and drug
transshipment
======================================================================
@Central African Republic
------------------------
Disputes--international: none
======================================================================
@Paracel Islands
---------------
Disputes--international: occupied by China, but claimed by Taiwan
and Vietnam
======================================================================
@Paraguay
--------','a5fa80e4e936ae757eba5bd4120920cde2294e28980b9d658a44820a49a1567b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4395d9ddbcb8d4fed55e981f61e8df9bbed88bbc8e8692543e8038a6afbc03b4',1999,'CG','Congo','transnational-issues',87,'Disputes--international: none
======================================================================
@Chad
----
Disputes--international: delimitation of international boundaries
in the vicinity of Lake Chad, the lack of which led to border
incidents in the past, is completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria
======================================================================
@Chile
-----
Disputes--international: short section of the southwestern
boundary with Argentina is indefinite--process to resolve boundary
issues is underway; Bolivia has wanted a sovereign corridor to the
South Pacific Ocean since the Atacama area was lost to Chile in
1884; dispute with Bolivia over Rio Lauca water rights; territorial
claim in Antarctica (Chilean Antarctic Territory) partially overlaps
Argentine and British claims
Illicit drugs: a growing transshipment country for cocaine
destined for the US and Europe; economic prosperity has made Chile
more attractive to traffickers seeking to launder drug profits;
imported precursors pass on to Bolivia
======================================================================
@China
-----
======================================================================
@Saint Helena
------------
Disputes--international: none
======================================================================
@Saint Kitts and Nevis
---------------------
Disputes--international: none
Illicit drugs: transshipment points for South American drugs
destined for the US
======================================================================
@Saint Lucia
-----------
Disputes--international: none
Illicit drugs: transit point for South American drugs destined
for the US and Europe
======================================================================
@Saint Pierre and Miquelon
-------------------------
======================================================================
@Ukraine
-------
Disputes--international: dispute with Romania over continental
shelf of the Black Sea under which significant gas and oil deposits
may exist; agreed in 1997 to two-year negotiating period, after
which either party can refer dispute to the International Court of
Justice (ICJ); has made no territorial claim in Antarctica (but has
reserved the right to do so) and does not recognize the claims of
any other nation
Illicit drugs: limited cultivation of cannabis and opium poppy,
mostly for CIS consumption; some synthetic drug production for
export to West; limited government eradication program; used as
transshipment point for opiates and other illicit drugs from Africa,
Latin America, and Turkey, and to Europe and Russia; drug-related
money laundering a minor, but growing, problem
======================================================================
@United Arab Emirates
--------------------
Disputes--international: location and status of boundary with
Saudi Arabia is not final, de facto boundary reflects 1974
agreement; no defined boundary with most of Oman, but Administrative
Line in far north; claims two islands in the Persian Gulf occupied
by Iran: Lesser Tunb (called Tunb as Sughra in Arabic by UAE and
Jazireh-ye Tonb-e Kuchek in Persian by Iran) and Greater Tunb
(called Tunb al Kubra in Arabic by UAE and Jazireh-ye Tonb-e Bozorg
in Persian by Iran); claims island in the Persian Gulf jointly
administered with Iran (called Abu Musa in Arabic by UAE and
Jazireh-ye Abu Musa in Persian by Iran)--over which Iran has taken
steps to exert unilateral control since 1992, including access
restrictions and a military build-up on the island; the UAE has
garnered significant diplomatic support in the region in protesting
these Iranian actions
Illicit drugs: growing role as heroin transshipment and
money-laundering center due to its proximity to southwest Asian
producing countries and the bustling free trade zone in Dubai
======================================================================
@United Kingdom
--------------','4639ee6453bda40ccf3a5deb8ec27be751b3d4683addef2ef05b20e8293a73d1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70521e00a1062362139cc2e7daa1df58e085af8e8c01abe4b48dcbe6f771f672',1999,'DE','Germany','transnational-issues',92,'Disputes--international: boundary with India in dispute; dispute
over at least two small sections of the boundary with Russia remain
to be settled, despite 1997 boundary agreement; most of the boundary
with Tajikistan in dispute; 33-km section of boundary with North
Korea in the Paektu-san (mountain) area is indefinite; involved in a
complex dispute over the Spratly Islands with Malaysia, Philippines,
Taiwan, Vietnam, and possibly Brunei; maritime boundary dispute with
Vietnam in the Gulf of Tonkin; Paracel Islands occupied by China,
but claimed by Vietnam and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as does Taiwan; sections
of land border with Vietnam are indefinite
Illicit drugs: major transshipment point for heroin produced in
the Golden Triangle; growing domestic drug abuse problem
======================================================================
@Christmas Island
----------------','00ba0e5928e55b6953b289e9eed7f906cc6628fecc4017611f64582f55950dc8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e317e2453a83966fdf607a5c459680725b904796ef24d6c6164b389f4e5a8a',1999,'AU','Australia','transnational-issues',112,'Disputes--international: none
======================================================================
@Clipperton Island
-----------------
Disputes--international: none
======================================================================
@Cocos (Keeling) Islands
-----------------------
Disputes--international: none
======================================================================
@Colombia
--------
Disputes--international: maritime boundary dispute with Venezuela
in the Gulf of Venezuela; territorial disputes with Nicaragua over
Archipelago de San Andres y Providencia and Quita Sueno Bank
Illicit drugs: illicit producer of coca, opium poppies, and
cannabis; cultivation of coca in 1997--79,500 hectares, an 18%
increase over 1996; potential production of cocaine in 1997--125
metric tons, a 14% increase over 1996; cultivation of opium in
1997--6,600 hectares, a 5% increase over 1996; potential production
of opium in 1997--66 metric tons, a 5% increase over 1996; the
world''s largest processor of coca derivatives into cocaine; supplier
of cocaine to the US and other international drug markets; active
aerial eradication program seeks to virtually eliminate coca and
opium crops
======================================================================
@Comoros
-------
Disputes--international: none
======================================================================
@Costa Rica
----------
Disputes--international: none
Illicit drugs: transshipment country for cocaine and heroin from
South America; illicit production of cannabis on small, scattered
plots
======================================================================
@Cote d''Ivoire
-------------
Disputes--international: none
Illicit drugs: illicit producer of cannabis, mostly for local
consumption; minor transshipment point for Southwest and Southeast
Asian heroin to Europe and occasionally to the US, and for Latin
American cocaine destined for Europe
======================================================================
@Croatia
-------
Disputes--international: Eastern Slavonia, which was held by
ethnic Serbs during the ethnic conflict, was returned to Croatian
control by the UN Transitional Administration for Eastern Slavonia
on 15 January 1998; Croatia and Italy made progress toward resolving
a bilateral issue dating from World War II over property and ethnic
minority rights; significant progress has been made with Slovenia
toward resolving a maritime border dispute over direct access to the
sea in the Adriatic; Serbia and Montenegro is disputing Croatia''s
claim to the Prevlaka Peninsula in southern Croatia because it
controls the entrance to Boka Kotorska in Montenegro; Prevlaka is
currently under observation by the UN military observer mission in
Prevlaka (UNMOP)
Illicit drugs: transit point along the Balkan route for Southwest
Asian heroin to Western Europe; a minor transit point for maritime
shipments of South American cocaine bound for Western Europe
======================================================================
@Cuba
----
Disputes--international: US Naval Base at Guantanamo Bay is leased
to US and only mutual agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territory serves as transshipment zone for cocaine
bound for the US and Europe
======================================================================
@Cyprus
------
Disputes--international: 1974 hostilities divided the island into
two de facto autonomous areas, a Greek Cypriot area controlled by
the internationally recognized Cypriot Government (59% of the
island''s land area) and a Turkish-Cypriot area (37% of the island),
that are separated by a UN buffer zone (4% of the island); there are
two UK sovereign base areas within the Greek Cypriot portion of the
island
Illicit drugs: transit point for heroin and hashish via air
routes and container traffic to Europe, especially from Lebanon and
Turkey; some cocaine transits as well
======================================================================
@Czech Republic
--------------
Disputes--international: Liechtenstein claims restitution for
1,600 sq km of property in the Czech Republic confiscated from its
royal family in 1918; the Czech Republic insists that restitution
does not go back before February 1948, when the communists seized
power; individual Sudeten German claims for restitution of property
confiscated in connection with their expulsion after World War II;
unresolved property issues with Slovakia over redistribution of
former Czechoslovak federal property
Illicit drugs: transshipment point for Southwest Asian heroin and
hashish and Latin American cocaine to Western Europe; domestic
consumption--especially of locally produced synthetic drugs--on the
rise
======================================================================
@Denmark
-------
Disputes--international: Rockall continental shelf dispute
involving Iceland, Ireland, and the UK (Ireland and the UK have
signed a boundary agreement in the Rockall area)
======================================================================
@Djibouti
--------
Disputes--international: none
======================================================================
@Dominica
--------
Disputes--international: some maritime disputes (see littoral
states)
======================================================================
@Indonesia
---------
Disputes--international: Indonesian sovereignty over Timor Timur
(East Timor Province), which is not recognized by the UN, is the
subject of discussions between the UN, Indonesia, and Portugal; two
islands in dispute with Malaysia
Illicit drugs: illicit producer of cannabis largely for domestic
use; possible growing role as transshipment point for Golden
Triangle heroin
======================================================================
@Iran
----
Disputes--international: Iran and Iraq restored diplomatic
relations in 1990 but are still trying to work out written
agreements settling outstanding disputes from their eight-year war
concerning border demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab waterway; Iran
occupies two islands in the Persian Gulf claimed by the UAE: Lesser
Tunb (called Tunb as Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called Tunb al Kubra in
Arabic by UAE and Jazireh-ye Tonb-e Bozorg in Persian by Iran); it
jointly administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by UAE and Jazireh-ye
Abu Musa in Persian by Iran)--over which Iran has taken steps to
exert unilateral control since 1992, including access restrictions
and a military build-up on the island; the UAE has garnered
significant diplomatic support in the region in protesting these
Iranian actions; Caspian Sea boundaries are not yet determined among
Azerbaijan, Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: despite substantial interdiction efforts, Iran
remains a key transshipment point for Southwest Asian heroin to
Europe; domestic consumption of narcotics remains a persistent
problem and Iranian press reports estimate that there are at least
1.2 million drug users in the country
======================================================================
@Iraq
----
Disputes--international: Iran and Iraq restored diplomatic
relations in 1990 but are still trying to work out written
agreements settling outstanding disputes from their eight-year war
concerning border demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab waterway; in
November 1994, Iraq formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council Resolutions
687 (1991), 773 (1993), and 883 (1993); this formally ends earlier
claims to Kuwait and to Bubiyan and Warbah islands although the
government continues periodic rhetorical challenges; dispute over
water development plans by Turkey for the Tigris and Euphrates Rivers
======================================================================
@Ireland
-------
Disputes--international: Northern Ireland issue with the UK
(historic peace agreement signed 10 April 1998); Rockall continental
shelf dispute involving Denmark, Iceland, and the UK (Ireland and
the UK have signed a boundary agreement in the Rockall area)
Illicit drugs: transshipment point for and consumer of hashish
from North Africa to the UK and Netherlands and of European-produced
synthetic drugs; transshipment point for heroin and cocaine destined
for Western Europe
======================================================================
@Israel
------
Disputes--international: West Bank and Gaza Strip are
Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement--permanent status to be
determined through further negotiation; Golan Heights is
Israeli-occupied; Israeli troops in southern Lebanon since June 1982
Illicit drugs: increasingly concerned about cocaine and heroin
abuse; drugs primarily arrive in country from Lebanon
======================================================================
@Italy
-----
Disputes--international: Italy and Slovenia made progress in
resolving bilateral issues; Croatia and Italy made progress toward
resolving a bilateral issue dating from World War II over property
and ethnic minority rights
Illicit drugs: important gateway for and consumer of Latin
American cocaine and Southwest Asian heroin entering the European
market
======================================================================
@Jamaica
-------
Disputes--international: none
Illicit drugs: transshipment point for cocaine from Central and
South America to North America and Europe; illicit cultivation of
cannabis; government has an active manual cannabis eradication
program
======================================================================
@Jan Mayen
---------
Disputes--international: none
======================================================================
@Japan
-----
Disputes--international: islands of Etorofu, Kunashiri, Shikotan,
and the Habomai group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Liancourt Rocks
(Takeshima/Tokdo) disputed with South Korea; Senkaku-shoto (Senkaku
Islands) claimed by China and Taiwan
======================================================================
@Jarvis Island
-------------
Disputes--international: none
======================================================================
@Jersey
------
Disputes--international: Matthew and Hunter Islands claimed by
France and Vanuatu
======================================================================
@New Zealand
-----------
Disputes--international: territorial claim in Antarctica (Ross
Dependency)
======================================================================
@Nicaragua
---------
Disputes--international: territorial disputes with Colombia over
the Archipelago de San Andres y Providencia and Quita Sueno Bank;
with respect to the maritime boundary question in the Golfo de
Fonseca, the International Court of Justice (ICJ) referred the
disputants to an earlier agreement in this century and advised that
some tripartite resolution among El Salvador, Honduras, and
Nicaragua likely would be required; maritime boundary dispute with
Disputes--international: none
======================================================================
@Northern Mariana Islands
------------------------
Disputes--international: none
======================================================================
@Norway
------
Disputes--international: territorial claim in Antarctica (Queen
Maud Land); Svalbard is the focus of a maritime boundary dispute in
the Barents Sea between Norway and Russia
Illicit drugs: minor transshipment point for drugs shipped via
the CIS and Baltic states for the European market; increasing
domestic consumption of cannabis and amphetamines
======================================================================
@Oman
----
Disputes--international: southern boundary with the United Arab
Emirates has not been bilaterally defined; northern section in the
Musandam Peninsula is an administrative boundary
======================================================================
@Pacific Ocean
-------------
Disputes--international: some maritime disputes (see littoral
states)
======================================================================
@Pakistan
--------
Disputes--international: status of Kashmir with India;
water-sharing problems with India over the Indus River (Wular
Barrage)
Illicit drugs: producer of illicit opium and hashish for the
international drug trade (poppy cultivation in 1998--3,030 hectares,
a 26% drop from 1997 because of eradication and alternative
development); limited center for processing Afghan heroin; key
transit area for Southwest Asian heroin moving to Western markets;
narcotics still move from Afghanistan into Baluchistan Province
======================================================================
@Palau
-----
Disputes--international: none
======================================================================
@Palmyra Atoll
-------------
Disputes--international: none
======================================================================
@Panama
------
Disputes--international: none
Illicit drugs: major cocaine transshipment point and major
drug-money-laundering center; no recent signs of coca cultivation;
monitoring of financial transactions is improving
======================================================================
@Papua New Guinea
----------------
Disputes--international: none
======================================================================
@Uganda
------
Disputes--international: Ugandan military forces are supporting
the rebel forces in the civil war in the Democratic Republic of the','b531712ec43854dcb83354ece2959807e45373fd5a13d3da025b956ff4796129','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('066a0b6958668718e49b24c72296cfac13e4540d1e9dc75d1541a001662dc0c1',1999,'KM','Comoros','transnational-issues',124,'Disputes--international: claims French-administered Mayotte; the
islands of Anjouan (Nzwani) and Moheli (Mwali) have moved to secede
from Comoros
======================================================================
@Congo, Democratic Republic of the
---------------------------------
Disputes--international: the Democratic Republic of the Congo is
in the grip of a civil war that has drawn in military forces from
neighboring states, with Uganda and Rwanda supporting the rebel
movement which occupies much of the eastern portion of the state;
most of the Congo River boundary with the Republic of the Congo is
indefinite (no agreement has been reached on the division of the
river or its islands, except in the Pool Malebo/Stanley Pool area)
Illicit drugs: illicit producer of cannabis, mostly for domestic
consumption
======================================================================
@Congo, Republic of the
----------------------','9743eb88ac5b576d337d1212424cc49f8935899e985c1f05708ab0987ed43232','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e49bf8f090f70066564f1a7629b4e601ea68e742475cf142071a49fad6b25bb',1999,'ET','Ethiopia','transnational-issues',131,'Disputes--international: most of the Congo River boundary with the
Democratic Republic of the Congo is indefinite (no agreement has
been reached on the division of the river or its islands, except in
the Stanley Pool/Pool Malebo area)
======================================================================
@Cook Islands
------------
Disputes--international: none
======================================================================
@Malta
-----','3682f07981a5287a1d069140278af039311eb205747a5b26ac2ebd3719e33983','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f52076052b44dd3a46581fae71c5ee79128553781e664ce9e27cc32db8727c5a',1999,'NZ','New Zealand','transnational-issues',141,'Disputes--international: none
======================================================================
@Coral Sea Islands
-----------------','b8bcd12bd371d09f15ebb657198bcb3668d0c04870b9e885208e9223e909a7c0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46acd0bc8e3f305bd3742798367150993af038b73fa7b1167e388281bf545a11',1999,'TT','Trinidad and Tobago','transnational-issues',151,'Disputes--international: none
Illicit drugs: transshipment point for narcotics bound for the US
and Europe; minor cannabis producer; banking industry is vulnerable
to money laundering
======================================================================
@Dominican Republic
------------------
Disputes--international: none
Illicit drugs: transshipment point for South American drugs
destined for the US
======================================================================
@Ecuador
-------
Disputes--international: on October 26, 1998, Peru and Ecuador
concluded treaties on commerce and navigation and on boundary
integration, to complete a package of agreements settling the
long-standing boundary dispute between them; demarcation of the
agreed-upon boundary was scheduled to begin in mid-January 1999
Illicit drugs: significant transit country for derivatives of
coca originating in Colombia, Bolivia, and Peru; importer of
precursor chemicals used in production of illicit narcotics;
important money-laundering hub
======================================================================
@Egypt
-----
Disputes--international: none
Illicit drugs: transshipment point for South American drugs
destined for the US and Europe
======================================================================
@Samoa
-----
Disputes--international: none
======================================================================
@San Marino
----------
Disputes--international: none
======================================================================
@Sao Tome and Principe
---------------------
Disputes--international: none
======================================================================
@Saudi Arabia
------------
Disputes--international: large section of boundary with Yemen not
defined; location and status of boundary with UAE is not final, de
facto boundary reflects 1974 agreement; Kuwaiti ownership of Qaruh
and Umm al Maradim islands is disputed by Saudi Arabia; in 1996,
agreed with Qatar to demarcate border per 1992 accord; that process
is ongoing
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin and cocaine
======================================================================
@Senegal
-------
Disputes--international: short section of boundary with The Gambia
is indefinite
Illicit drugs: transshipment point for Southwest and Southeast
Asian heroin moving to Europe and North America; illicit cultivator
of cannabis
======================================================================
@Serbia and Montenegro
---------------------
Disputes--international: disputes with Bosnia and Herzegovina over
Serbian populated areas; Albanian majority in Kosovo seeks
independence from Serbian republic; Serbia and Montenegro is
disputing Croatia''s claim to the Prevlaka Peninsula in southern
Croatia because it controls the entrance to Boka Kotorska in
Montenegro; Prevlaka is currently under observation by the UN
military observer mission in Prevlaka (UNMOP); the border commission
formed by The Former Yugoslav Republic of Macedonia and Serbia and
Montenegro in April 1996 to resolve differences in delineation of
their mutual border has made no progress so far
Illicit drugs: major transshipment point for Southwest Asian
heroin moving to Western Europe on the Balkan route
======================================================================
@Seychelles
----------','6f7055b7640d76247fd0b8522ea1eabc71d6ebcefe7dcb7ef1f109973474d081','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('525f510b592cc53cff6357ac21e75dc803d434de78e03ff4028da78d965ef633',1999,'MX','Mexico','transnational-issues',161,'Disputes--international: Egypt asserts its claim to the "Hala''ib
Triangle," a barren area of 20,580 sq km under partial Sudanese
administration that is defined by an administrative boundary which
supersedes the treaty boundary of 1899
Illicit drugs: a transit point for Southwest Asian and Southeast
Asian heroin and opium moving to Europe and the US; popular transit
stop for Nigerian couriers
======================================================================
@El Salvador
-----------
Disputes--international: demarcation of boundary with Honduras
defined by 1992 International Court of Justice (ICJ) decision has
not been completed; small boundary section left unresolved by ICJ
decision not yet reported to have been settled; with respect to the
maritime boundary in the Golfo de Fonseca, ICJ referred to an
earlier agreement in this century and advised that some tripartite
resolution among El Salvador, Honduras and Nicaragua likely would be
required
Illicit drugs: transshipment point for cocaine; marijuana
produced for local consumption
======================================================================
@Equatorial Guinea
-----------------
Disputes--international: maritime boundary dispute with Gabon
because of disputed sovereignty over islands in Corisco Bay;
maritime boundary dispute with Nigeria because of disputed
jurisdiction over oil-rich areas in the Gulf of Guinea
======================================================================
@Eritrea
-------
Disputes--international: dispute over alignment of boundary with
Ethiopia led to armed conflict in 1998, which is still unresolved
despite arbitration efforts; Hanish Islands dispute with Yemen
resolved by arbitral tribunal in October 1998
======================================================================
@Estonia
-------
Disputes--international: Estonian and Russian negotiators reached
a technical border agreement in December 1996 which has not been
ratified
Illicit drugs: transshipment point for opiates and cannabis from
Southwest Asia and the Caucasus via Russia, and cocaine from Latin
America to Western Europe and Scandinavia; possible precursor
manufacturing and/or trafficking
======================================================================
@Ethiopia
--------
Disputes--international: most of the southern half of the boundary
with Somalia is a Provisional Administrative Line; territorial
dispute with Somalia over the Ogaden; dispute over alignment of
boundary with Eritrea led to armed conflict in 1998, which is still
unresolved despite arbitration efforts
Illicit drugs: transit hub for heroin originating in Southwest
and Southeast Asia and destined for Europe and North America as well
as cocaine destined for markets in southern Africa; cultivates qat
(chat) for local use and regional export
======================================================================
@Europa Island
-------------','74d24510c8a04105b589cdb19d5e7c322c699247aaa028b46333d5a494296811','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3624e6fd8fd40057a9d5df4346b459d8f6bc24a05983d725d8e9b03de037968',1999,'MZ','Mozambique','transnational-issues',172,'Disputes--international: claimed by Madagascar
======================================================================
@Falkland Islands (Islas Malvinas)
---------------------------------
Disputes--international: claims Bassas da India, Europa Island,
Glorioso Islands, Juan de Nova Island, and Tromelin Island (all
administered by France)
Illicit drugs: illicit producer of cannabis (cultivated and wild
varieties) used mostly for domestic consumption; transshipment point
for heroin
======================================================================
@Malawi
------
Disputes--international: dispute with Tanzania over the boundary
in Lake Nyasa (Lake Malawi)
======================================================================
@Malaysia
--------
Disputes--international: involved in a complex dispute over the
Spratly Islands with China, Philippines, Taiwan, Vietnam, and
possibly Brunei; Philippines have not fully revoked claim to Sabah
State; two islands in dispute with Singapore; two islands in dispute
with Indonesia
Illicit drugs: transit point for some illicit drugs going to
Western markets; drug trafficking prosecuted vigorously and carries
severe penalties
======================================================================
@Maldives
--------
Disputes--international: claimed by Comoros
======================================================================
@Mexico
------
Disputes--international: none
Illicit drugs: illicit cultivation of opium poppy (cultivation in
1998--5,500 hectares; potential production--60 metric tons) and
cannabis cultivation in 1998--4,600 hectares; government eradication
efforts have been key in keeping illicit crop levels low; major
supplier of heroin and marijuana to the US market; continues as the
primary transshipment country for US-bound cocaine from South
America; involved in the production and distribution of
methamphetamines
======================================================================
@Micronesia, Federated States of
-------------------------------
Disputes--international: none
======================================================================
@Midway Islands
--------------
Disputes--international: none
======================================================================
@Moldova
-------
Disputes--international: separatist Transdniester region,
comprising the area between the Nistru (Dniester) River and Ukraine,
has its own de facto government, dominated by Moldovan Slavs
Illicit drugs: limited cultivation of opium poppy and cannabis,
mostly for CIS consumption; transshipment point for illicit drugs
from Southwest Asia via Central Asia to Russia, Western Europe and
possibly the United States
======================================================================
@Monaco
------
Disputes--international: none
======================================================================
@Mongolia
--------
Disputes--international: none
======================================================================
@Montserrat
----------','9e8e30acfa9b4146cda8db4f05de5fbfc09f3c99627261432d15a96908c63187','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('687e26318be6a1dbe6b44bf72371210775136f91754a73402d5f97fcab711f68',1999,'AR','Argentina','transnational-issues',178,'Disputes--international: claimed by Argentina
======================================================================
@Faroe Islands
-------------
Disputes--international: none
======================================================================
@Fiji
----
Disputes--international: none
======================================================================
@Finland
-------
Disputes--international: none
Illicit drugs: minor transshipment point for Latin American
cocaine for the West European market
======================================================================
@France
------
Disputes--international: Madagascar claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova Island, and Tromelin Island;
Comoros claims Mayotte; Mauritius claims Tromelin Island;
territorial dispute between Suriname and French Guiana; territorial
claim in Antarctica (Adelie Land); Matthew and Hunter Islands east
of New Caledonia claimed by France and Vanuatu
Illicit drugs: transshipment point for and consumer of South
American cocaine and Southwest Asian heroin
======================================================================
@French Guiana
-------------
Disputes--international: Suriname claims area between Riviere
Litani and Riviere Marouini (both headwaters of the Lawa)
Illicit drugs: small amount of marijuana grown for local
consumption; minor transshipment point to Europe
======================================================================
@French Polynesia
----------------','934fb365e138991d763e4df4da771704bc0e307132181f562ede686e34a88ed2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c0a98593b5dba20a9338147930b86cdd66aaf6ab956fb37f1fa670cf1056999',1999,'NR','Nauru','transnational-issues',190,'Disputes--international: none
======================================================================
@French Southern and Antarctic Lands
-----------------------------------
Disputes--international: "Adelie Land" claim in Antarctica is not
recognized by the US
======================================================================
@Gabon
-----
Disputes--international: maritime boundary dispute with Equatorial
Guinea because of disputed sovereignty over islands in Corisco Bay
======================================================================
@Gambia, The
-----------
Disputes--international: none
======================================================================
@Korea, North
------------
Disputes--international: 33-km section of boundary with China in
the Paektu-san (mountain) area is indefinite; Demarcation Line with
South Korea
======================================================================
@Korea, South
------------
Disputes--international: Demarcation Line with North Korea;
Liancourt Rocks (Takeshima/Tokdo) claimed by Japan
======================================================================
@Kuwait
------
Disputes--international: in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had been spelled out in
Security Council Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to Bubiyan and
Warbah islands; ownership of Qaruh and Umm al Maradim islands
disputed by Saudi Arabia
======================================================================
@Kyrgyzstan
----------
Disputes--international: territorial dispute with Tajikistan on
southwestern boundary in Isfara Valley area
Illicit drugs: limited illicit cultivator of cannabis and opium
poppy, mostly for CIS consumption; limited government eradication
program; increasingly used as transshipment point for illicit drugs
to Russia and Western Europe from Southwest Asia
======================================================================
@Laos
----
Disputes--international: parts of the border with Thailand are
indefinite
Illicit drugs: world''s third-largest illicit opium producer
(estimated cultivation in 1998--26,100 hectares, a 7% decrease over
1997; estimated potential production in 1998--140 metric tons, a 33%
decrease over 1997); potential heroin producer; transshipment point
for heroin and methamphetamines produced in Burma; illicit producer
of cannabis
======================================================================
@Latvia
------','d932134e72bc6723201258a67819b023ea39c7c8cc815d20697b5e724ebd6ac1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b763743a5067a8b4e1a6d948a9c73ee050fbb4f61540c1871feacf2b115ec0e0',1999,'SN','Senegal','transnational-issues',199,'Disputes--international: short section of boundary with Senegal is
indefinite
======================================================================
@Gaza Strip
----------
Disputes--international: West Bank and Gaza Strip are
Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement--permanent status to be
determined through further negotiation
======================================================================
@Georgia
-------
Disputes--international: none
Illicit drugs: limited cultivation of cannabis and opium poppy,
mostly for domestic consumption; used as transshipment point for
opiates via Central Asia to Western Europe
======================================================================
@Germany
-------
Disputes--international: individual Sudeten German claims for
restitution of property confiscated in connection with their
expulsion after World War II
Illicit drugs: source of precursor chemicals for South American
cocaine processors; transshipment point for and consumer of
Southwest Asian heroin and hashish, Latin American cocaine, and
European-produced synthetic drugs
======================================================================
@Ghana
-----
Disputes--international: none
Illicit drugs: illicit producer of cannabis for the international
drug trade; transit hub for Southwest and Southeast Asian heroin and
South American cocaine destined for Europe and the US
======================================================================
@Gibraltar
---------
Disputes--international: source of friction between Spain and the
UK
======================================================================
@Glorioso Islands
----------------
Disputes--international: claimed by Madagascar
======================================================================
@Greece
------','5170caf23a2f8a21d045caf4a9d3086fe2db9201fad646a60e56d6e13e148e9e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82770891a6e2d1be1f5d7583a14c997f213f2c8afcfd271af6f0ff5de019e131',1999,'GR','Greece','transnational-issues',207,'Disputes--international: complex maritime, air, and territorial
disputes with Turkey in Aegean Sea; Cyprus question with Turkey;
dispute with The Former Yugoslav Republic of Macedonia over name; in
September 1995, Skopje and Athens signed an interim accord resolving
their dispute over symbols and certain constitutional provisions;
Athens also lifted its economic embargo on The Former Yugoslav
Republic of Macedonia
Illicit drugs: a gateway to Europe for traffickers smuggling
cannabis and heroin from the Middle East and Southwest Asia to the
West and precursor chemicals to the East; some South American
cocaine transits or is consumed in Greece
======================================================================
@Greenland
---------
Disputes--international: none
======================================================================
@Grenada
-------
Disputes--international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
======================================================================
@Guadeloupe
----------','b4fafdfc2eb0fa1ecf778778ff7e48ec86e854c40d4545b8e45178029fcd884c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58bc4d996abb2111415f9f1114683fad95e0efb622e0ddbf31f7fabccd91a8d',1999,'MQ','Martinique','transnational-issues',212,'Disputes--international: none
======================================================================
@Guam
----
Disputes--international: none
======================================================================
@Guatemala
---------','551636c2862b0b86643f4376e4aa630d351859632500d0d62675acb5816426f6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc67c2cd272b0935e259aa677961caefa0cfa343938b830e7ce38a305865b427',1999,'GT','Guatemala','transnational-issues',221,'Disputes--international: border with Belize in dispute
Illicit drugs: transit country for cocaine shipments; minor
producer of illicit opium poppy and cannabis for the international
drug trade; active eradication program of cannabis crop effectively
eliminated in 1996
======================================================================
@Guernsey
--------
Disputes--international: none
======================================================================
@Guinea
------
Disputes--international: none
======================================================================
@Guinea-Bissau
-------------
Disputes--international: none
======================================================================
@Guyana
------
Disputes--international: all of the area west of the Essequibo
River claimed by Venezuela; Suriname claims area between New (Upper
of the Courantyne)
Illicit drugs: transshipment point for narcotics from South
America--primarily Venezuela--to Europe and the US; producer of
cannabis
======================================================================
@Haiti
-----
Disputes--international: claims US-administered Navassa Island
Illicit drugs: transshipment point for cocaine and marijuana en
route to the US and Europe
======================================================================
@Heard Island and McDonald Islands
---------------------------------
Disputes--international: none
======================================================================
@Holy See (Vatican City)
-----------------------
Disputes--international: none
======================================================================
@Honduras
--------
Disputes--international: demarcation of boundary with El Salvador
defined by 1992 International Court of Justice (ICJ) decision has
not been completed; small boundary section left unresolved by ICJ
decision not yet reported to have been settled; with respect to the
maritime boundary in the Golfo de Fonseca, ICJ referred to an
earlier agreement in this century and advised that some tripartite
resolution among El Salvador, Honduras, and Nicaragua likely would
be required; maritime boundary dispute with Nicaragua
Illicit drugs: transshipment point for drugs and narcotics;
illicit producer of cannabis, cultivated on small plots and used
principally for local consumption
======================================================================
@Hong Kong
---------
Disputes--international: none
Illicit drugs: a hub for Southeast Asian heroin trade;
transshipment and money-laundering center; increasing indigenous
amphetamine abuse
======================================================================
@Howland Island
--------------
Disputes--international: none
======================================================================
@Hungary
-------
Disputes--international: ongoing Gabcikovo Dam dispute with
Slovakia is before the International Court of Justice
Illicit drugs: major transshipment point for Southwest Asian
heroin and cannabis and transit point for South American cocaine
destined for Western Europe; limited producer of precursor
chemicals, particularly for amphetamines and methamphetamines
======================================================================
@Iceland
-------
Disputes--international: Rockall continental shelf dispute
involving Denmark, Ireland, and the UK (Ireland and the UK have
signed a boundary agreement in the Rockall area)
======================================================================
@India
-----
Disputes--international: boundary with China in dispute; status of
Kashmir with Pakistan; water-sharing problems with Pakistan over the
Indus River (Wular Barrage); a portion of the boundary with
Bangladesh is indefinite; dispute with Bangladesh over New
Moore/South Talpatty Island
Illicit drugs: world''s largest producer of licit opium for the
pharmaceutical trade, but an undetermined quantity of opium is
diverted to illicit international drug markets; major transit
country for illicit narcotics produced in neighboring countries;
illicit producer of hashish and methaqualone; cultivated 2,050
hectares of illicit opium in 1997, a 34% decrease from 1996, with a
potential production of 30 metric tons, a 36% decrease from 1996
======================================================================
@Indian Ocean
------------','3830a587e3b3606b17407bef25cdc2bb7369404fe59289a6ccfb3b856618f07d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c5795ceebef5e770f7e175e00e01bc839c096fb0c6e5de500c023ff569811e5',1999,'FR','France','transnational-issues',233,'Disputes--international: none
======================================================================
@Johnston Atoll
--------------
Disputes--international: none
======================================================================
@Jordan
------
Disputes--international: none
======================================================================
@Macau
-----
Disputes--international: none
Illicit drugs: transshipment point for cocaine and marijuana
bound for the US and Europe
======================================================================
@Mauritania
----------
Disputes--international: none
======================================================================
@Mauritius
---------
Disputes--international: none
======================================================================
@Saint Vincent and the Grenadines
--------------------------------','819fd4d859177d7181ff81b6aaf1387fb22e3c9a5999e5cd73838cd798bcb36d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3cf96c47fee740b0dbf28449933c5efecea4f416803b2d81ab345bc5e14d52e',1999,'CN','China','transnational-issues',241,'Disputes--international: none
======================================================================
@Juan de Nova Island
-------------------
Disputes--international: claimed by Madagascar
======================================================================
@Kazakhstan
----------
Disputes--international: Caspian Sea boundaries are not yet
determined among Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan; Russia leases approximately 6,000 sq km of territory
enclosing the Baykonur Cosmodrome
Illicit drugs: significant illicit cultivation of cannabis and
limited cultivation of opium poppy and ephedra (for the drug
ephedrone); limited government eradication program; cannabis
consumed largely in the CIS; used as transshipment point for illicit
drugs to Russia, North America, and Western Europe from Southwest
Asia
======================================================================
@Kenya
-----
Disputes--international: administrative boundary with Sudan does
not coincide with international boundary
Illicit drugs: widespread harvesting of small, wild plots of
marijuana and qat (chat); transit country for South Asian heroin
destined for Europe and, sometimes, North America; Indian
methaqualone also transits on way to South Africa
======================================================================
@Kingman Reef
------------
Disputes--international: none
======================================================================
@Kiribati
--------','b3f616b74ea7c3e3efff1f7dba963c8b55bd5b7a1943e92f304bc98ccf6e4e9a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b85e362c861f589f5f0c6d7b528439613ee955f24beda173cc4e1dfada352fd2',1999,'SE','Sweden','transnational-issues',250,'Disputes--international: draft treaty delimiting the boundary with
Russia has not been signed; ongoing talks over maritime boundary
dispute with Lithuania (primary concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and cannabis from
Central and Southwest Asia to Western Europe and Scandinavia and
Latin American cocaine and some synthetics from Western Europe to
CIS; limited production of illicit amphetamines, ephedrine, and
ecstasy for export
======================================================================
@Lebanon
-------
Disputes--international: Israeli troops in southern Lebanon since
June 1982; Syrian troops in northern, central, and eastern Lebanon
since October 1976
Illicit drugs: inconsequential producer of hashish and heroin;
some heroine and cocaine processing mostly in the Bekaa valley; a
Lebanese/Syrian eradication campaign started in the early 1990s has
practically eliminated the opium and cannabis crops
======================================================================
@Lesotho
-------
Disputes--international: none
======================================================================
@Liberia
-------
Disputes--international: none
Illicit drugs: increasingly a transshipment point for Southeast
and Southwest Asian heroin and South American cocaine for the
European and US markets
======================================================================
@Libya
-----','aaf9d72668e2fd565a7d2357c9dccefe124b6a28c33be121efffa0c9c85f198c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2439e9050df8b0c4e6ee96124dc9b3a1690377ca0c6d6c8094298a030b52298',1999,'EG','Egypt','transnational-issues',260,'Disputes--international: maritime boundary dispute with Tunisia;
Libya claims about 19,400 sq km in northern Niger and part of
southeastern Algeria
======================================================================
@Liechtenstein
-------------
Disputes--international: claims 1,600 sq km of property in the
Czech Republic confiscated from its royal family in 1918; the Czech
Republic insists that restitution does not go back before February
1948, when the communists seized power
======================================================================
@Lithuania
---------
Disputes--international: ongoing talks over maritime boundary
dispute with Latvia (primary concern is oil exploration rights);
1997 border agreement with Russia not yet ratified
Illicit drugs: transshipment point for opiates and other illicit
drugs from Southwest Asia, Latin America, and Western Europe to
Western Europe and Scandinavia
======================================================================
@Luxembourg
----------','83d58bf67d69f998667a2b0a26895be00c51e719da15d02ff4d8392537dffd45','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05722d999a9dcad97f057e89b165459b2c9a02c4137badca830dedd047aa7ed3',1999,'HK','Hong Kong','transnational-issues',270,'Disputes--international: none
======================================================================
@Macedonia, The Former Yugoslav Republic of
------------------------------------------
Disputes--international: dispute with Greece over name; in
September 1995, Skopje and Athens signed an interim accord resolving
their dispute over symbols and certain constitutional provisions;
Athens also lifted its economic embargo on The Former Yugoslav
Republic of Macedonia; the border commission formed by The Former
Yugoslav Republic of Macedonia and Serbia and Montenegro in April
1996 to resolve differences in delineation of their mutual border
has made no progress so far; Albanians in Macedonia claim
discrimination in education, access to public-sector jobs and
representation in government; Party for Democratic Action (DPA),
which is now a member party of the government, calls for a rewrite
of the constitution to declare ethnic Albanians a national group and
allow for regional autonomy
Illicit drugs: increasing transshipment point for Southwest Asian
heroin and hashish; minor transit point for South American cocaine
destined for Europe
======================================================================
@Madagascar
----------','586f3dcb1e02dc79ae94ae68d515680f4fe4d5560837b4f14fa14b8c289faf99','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6afca64b5e3fd465f6735b239984cf0c790407ad01d202331339d2b3a0520a30',1999,'TH','Thailand','transnational-issues',277,'Disputes--international: none
======================================================================
@Mali
----','56974008362e73b8df0e582ed3b3719fb72606da70cb07454c13575c2bda7485','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd2d6b7d1a6cd22b86eb348ccefba18810c35e6b61c07073d91f361974ff0dda',1999,'MT','Malta','transnational-issues',286,'Disputes--international: Malta and Tunisia are discussing the
commercial exploitation of the continental shelf between their
countries, particularly for oil exploration
Illicit drugs: minor transshipment point for hashish from North
Africa to Western Europe
======================================================================
@Man, Isle of
------------
Disputes--international: none
======================================================================
@Marshall Islands
----------------
Disputes--international: claims US territory of Wake Atoll
======================================================================
@Martinique
----------','ed5cf579a3c6c8f822675fd98be8ffdd7e083a9baa17cbd523690e6107ec2097','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1007a487b874e5aafdad18e74c0067f4f623f61a214a2878bec2b92ab624cef',1999,'MG','Madagascar','transnational-issues',298,'Disputes--international: claims the Chagos Archipelago in
UK-administered British Indian Ocean Territory; claims
French-administered Tromelin Island
Illicit drugs: illicit producer of cannabis for the international
drug trade; heroin consumption and transshipment are growing problems
======================================================================
@Mayotte
-------
Disputes--international: none
======================================================================
@Romania
-------
Disputes--international: dispute with Ukraine over continental
shelf of the Black Sea under which significant gas and oil deposits
may exist; agreed in 1997 to two-year negotiating period, after
which either party can refer dispute to the International Court of
Justice
Illicit drugs: important transshipment point for Southwest Asian
heroin transiting the Balkan route and small amounts of Latin
American cocaine bound for Western Europe
======================================================================
@Russia
------
Disputes--international: dispute over at least two small sections
of the boundary with China remain to be settled, despite 1997
boundary agreement; islands of Etorofu, Kunashiri, and Shikotan and
the Habomai group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Caspian Sea boundaries are
not yet determined among Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan; Estonian and Russian negotiators reached a technical
border agreement in December 1996 which has not been ratified; draft
treaty delimiting the boundary with Latvia has not been signed; has
made no territorial claim in Antarctica (but has reserved the right
to do so) and does not recognize the claims of any other nation;
1997 border agreement with Lithuania not yet ratified; Svalbard is
the focus of a maritime boundary dispute in the Barents Sea between
Norway and Russia
Illicit drugs: limited cultivation of illicit cannabis and opium
poppy and producer of amphetamines, mostly for domestic consumption;
government has active eradication program; increasingly used as
transshipment point for Southwest and Southeast Asian opiates and
cannabis and Latin American cocaine to Western Europe, possibly to
the US, and growing domestic market
======================================================================
@Rwanda
------
Disputes--international: Rwandan military forces are supporting
the rebel forces in the civil war in the Democratic Republic of the
Disputes--international: claimed by Madagascar and Mauritius
======================================================================
@Tunisia
-------
Disputes--international: maritime boundary dispute with Libya;
Malta and Tunisia are discussing the commercial exploitation of the
continental shelf between their countries, particularly for oil
exploration
======================================================================
@Turkey
------
Disputes--international: complex maritime, air, and territorial
disputes with Greece in Aegean Sea; Cyprus question with Greece;
dispute with downstream riparian states (Syria and Iraq) over water
development plans for the Tigris and Euphrates Rivers; traditional
demands on former Armenian lands in Turkey have subsided
Illicit drugs: major transit route for Southwest Asian heroin and
hashish to Western Europe and--to a far lesser extent the US--via air,
land, and sea routes; major Turkish, Iranian, and other
international trafficking organizations operate out of Istanbul;
laboratories to convert imported morphine base into heroin are in
remote regions of Turkey as well as near Istanbul; government
maintains strict controls over areas of legal opium poppy
cultivation and output of poppy straw concentrate
======================================================================
@Turkmenistan
------------
Disputes--international: Caspian Sea boundaries are not yet
determined among Azerbaijan, Iran, Kazakhstan, Russia, and','94dbbf43cc51a51569c167d71f42f9fd8a234b0b9c35ae8e5763196ccd71fb11','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7540b332046fc2d08a1851680281a5aeefeec7fa2976b655d9b7174f0bbeda27',1999,'HN','Honduras','transnational-issues',299,'Illicit drugs: transshipment point for cocaine destined for the US
======================================================================
@Niger
-----
Disputes--international: Libya claims about 19,400 sq km in
northern Niger; delimitation of international boundaries in the
vicinity of Lake Chad, the lack of which led to border incidents in
the past, is completed and awaits ratification by Cameroon, Chad,
Niger, and Nigeria
======================================================================
@Nigeria
-------
Disputes--international: delimitation of international boundaries
in the vicinity of Lake Chad, the lack of which led to border
incidents in the past, is completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria; dispute with Cameroon over land
and maritime boundaries around the Bakasi Peninsula is currently
before the International Court of Justice; maritime boundary dispute
with Equatorial Guinea because of disputed jurisdiction over
oil-rich areas in the Gulf of Guinea
Illicit drugs: facilitates movement of heroin en route from
Southeast and Southwest Asia to Western Europe and North America;
increasingly a transit route for cocaine from South America intended
for European, East Asian, and North American markets
======================================================================
@Niue
----','58759ac3e6c0bfef4bb32667e67ac2e4635216798a9cc28dd7b4472c1aa57aec','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92acbb5d98bc30c08ecf7eab66deb24955ab390039359a37c795b89cb81937f4',1999,'TO','Tonga','transnational-issues',314,'Disputes--international: none
======================================================================
@Norfolk Island
--------------','4a6ee832a61a215d711028c658a027be84de42ac9a1e935becaafd5933f31e8f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585d2944b52dc137d54c80b050b00f691a75fce1e6af17dc976f44766f19544d',1999,'BR','Brazil','transnational-issues',322,'Illicit drugs: illicit producer of cannabis for the international
drug trade; transshipment country for Bolivian cocaine headed for
Europe and the US
======================================================================
@Peru
----
Disputes--international: on 26 October 1998, Peru and Ecuador
concluded treaties on commerce and navigation and on boundary
integration, to complete a package of agreements settling the
long-standing boundary dispute between them; demarcation of the
agreed-upon boundary was scheduled to begin in mid-January 1999
Illicit drugs: until recently the world''s largest coca leaf
producer, Peru has reduced the area of coca under cultivation by
26%, from 68,800 hectares in 1997 to 51,000 hectares at the end of
1998; most of cocaine base is shipped to neighboring Colombia and
Brazil for processing into cocaine for the international drug
market, but exports of finished cocaine are increasing
======================================================================
@Philippines
-----------
Disputes--international: involved in a complex dispute over the
Spratly Islands with China, Malaysia, Taiwan, Vietnam, and possibly
Brunei; claim to Malaysia''s Sabah State has not been fully revoked
Illicit drugs: exports locally produced marijuana and hashish to
East Asia, the US, and other Western markets; serves as a transit
point for heroin and crystal methamphetamine
======================================================================
@Pitcairn Islands
----------------
Disputes--international: none
======================================================================
@Poland
------
Disputes--international: none
Illicit drugs: major illicit producer of amphetamines for the
international market; transshipment point for Asian and Latin
American illicit drugs to Western Europe
======================================================================
@Portugal
--------
Disputes--international: as former colonial power, Portugal plays
a key role in the issue of Indonesia''s sovereignty over Timor Timur
(East Timor Province), which has not been recognized by the UN
Illicit drugs: important gateway country for Latin American
cocaine entering the European market; transshipment point for
hashish from North Africa to Europe; consumer of Southwest Asian
heroin
======================================================================
@Puerto Rico
-----------
Disputes--international: none
======================================================================
@Qatar
-----','dc93aa4eab189607c5a5ae890f789b2dfdfb54e696db5ffaa7062cf575cda8a2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31010cce303f3315cbfbd1e14ad4ee9acce256fd46664f0510d720cf37176d60',1999,'SC','Seychelles','transnational-issues',330,'Disputes--international: claims Chagos Archipelago in British
Indian Ocean Territory
======================================================================
@Sierra Leone
------------
Disputes--international: none
======================================================================
@Singapore
---------','3bd25f4c87c73a456f2fa5884f91c71df9c1cd2680532b14894f190ad74140af','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56cfd2173ac4c62c97c0256f801b4e9c867a164953b708e68f9cd7086e9205b',1999,'ID','Indonesia','transnational-issues',338,'Disputes--international: two islands in dispute with Malaysia
Illicit drugs: transit point for Golden Triangle heroin going to
the US, Western Europe, and the Third World; also a money-laundering
center
======================================================================
@Slovakia
--------
Disputes--international: ongoing Gabcikovo Dam dispute with
Hungary is before the International Court of Justice; unresolved
property issues with Czech Republic over redistribution of former
Czechoslovak federal property
Illicit drugs: minor, but increasing, transshipment point for
Southwest Asian heroin and hashish bound for Western Europe
======================================================================
@Slovenia
--------
Disputes--international: significant progress has been made with
Croatia toward resolving a maritime border dispute over direct
access to the sea in the Adriatic; Italy and Slovenia made progress
in resolving bilateral issues
Illicit drugs: transit point for Southwest Asian heroin bound for
Western Europe and for precursor chemicals
======================================================================
@Solomon Islands
---------------
Disputes--international: none
======================================================================
@Somalia
-------
Disputes--international: most of the southern half of the boundary
with Ethiopia is a Provisional Administrative Line; territorial
dispute with Ethiopia over the Ogaden
======================================================================
@South Africa
------------
Disputes--international: Swaziland has asked South Africa to open
negotiations on reincorporating some nearby South African
territories that are populated by ethnic Swazis or that were long
ago part of the Swazi Kingdom
Illicit drugs: transshipment center for heroin and cocaine;
cocaine consumption on the rise; world''s largest market for illicit
methaqualone, usually imported illegally from India through various
east African countries; illicit cultivation of marijuana
======================================================================
@South Georgia and the South Sandwich Islands
--------------------------------------------
Disputes--international: claimed by Argentina
======================================================================
@Spain
-----','e0b9dff9d24ef3a6c63a3de5bf3433a4bd29e41c44481643b45e54b4b04eb476','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ee74a565deacad44b34ec3fde203e3d5daa621441487114f335fefe00588b02',1999,'GI','Gibraltar','transnational-issues',346,'Disputes--international: Gibraltar issue with UK; Spain controls
five places of sovereignty (plazas de soberania) on and off the
coast of Morocco--the coastal enclaves of Ceuta and Melilla, which
Morocco contests, as well as the islands of Penon de Alhucemas,
Penon de Velez de la Gomera, and Islas Chafarinas
Illicit drugs: key European gateway country for Latin American
cocaine and North African hashish entering the European market;
transshipment point for and consumer of Southwest Asian heroin
======================================================================
@Spratly Islands
---------------
Disputes--international: all of the Spratly Islands are claimed by
China, Taiwan, and Vietnam; parts of them are claimed by Malaysia
and the Philippines; in 1984, Brunei established an exclusive
fishing zone, which encompasses Louisa Reef in the southern Spratly
Islands, but has not publicly claimed the island
======================================================================
@Sri Lanka
---------','08f3c2b63f7a1d938426fda3da179b310b5bcfb3a336e54b643a168dd2fffb95','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f1582dff53f4b8c41e43d14326f22ebf9cea6d2e08a9399c7049d6ac0c15af7',1999,'IN','India','transnational-issues',360,'Disputes--international: none
======================================================================
@Sudan
-----
Disputes--international: administrative boundary with Kenya does
not coincide with international boundary; Egypt asserts its claim to
the "Hala''ib Triangle," a barren area of 20,580 sq km under partial
Sudanese administration that is defined by an administrative
boundary which supersedes the treaty boundary of 1899
======================================================================
@Suriname
--------
Disputes--international: claims area in French Guiana between
Litani Rivier and Riviere Marouini (both headwaters of the Lawa
Rivier); claims area in Guyana between New (Upper Courantyne) and
Illicit drugs: transshipment point for South American drugs
destined mostly for Europe
======================================================================
@Svalbard
--------
Disputes--international: Svalbard is the focus of a maritime
boundary dispute in the Barents Sea between Norway and Russia
======================================================================
@Swaziland
---------
Disputes--international: Swaziland has asked South Africa to open
negotiations on reincorporating some nearby South African
territories that are populated by ethnic Swazis or that were long
ago part of the Swazi Kingdom
======================================================================
@Sweden
------
Disputes--international: none
Illicit drugs: minor transshipment point for and consumer of
narcotics shipped via the CIS and Baltic states; increasing consumer
of European amphetamines
======================================================================
@Switzerland
-----------
Disputes--international: none
Illicit drugs: because of more stringent government regulations,
used significantly less as a money-laundering center; transit
country for and consumer of South American cocaine and Southwest
Asian heroin
======================================================================
@Syria
-----
Disputes--international: Golan Heights is Israeli occupied;
dispute with upstream riparian Turkey over Turkish water development
plans for the Tigris and Euphrates Rivers; Syrian troops in
northern, central, and eastern Lebanon since October 1976
Illicit drugs: a transit point for opiates and hashish bound for
regional and Western markets
======================================================================
@Taiwan
------
Disputes--international: involved in complex dispute over the
Spratly Islands with China, Malaysia, Philippines, Vietnam, and
possibly Brunei; Paracel Islands occupied by China, but claimed by
Vietnam and Taiwan; claims Japanese-administered Senkaku-shoto
(Senkaku Islands/Diaoyu Tai), as does China
Illicit drugs: considered an important heroin transit point;
major problem with domestic consumption of methamphetamines and
heroin
======================================================================
@Tajikistan
----------
Disputes--international: most of the boundary with China in
dispute; territorial dispute with Kyrgyzstan on northern boundary in
Isfara Valley area
Illicit drugs: limited illicit cultivation of cannabis, mostly
for domestic consumption; opium poppy cultivation negligible in 1998
because of government eradication program; increasingly used as
transshipment point for illicit drugs from Southwest Asia to Russia
and Western Europe
======================================================================
@Tanzania
--------
Disputes--international: dispute with Malawi over the boundary in
Lake Nyasa (Lake Malawi)
Illicit drugs: growing role in transshipment of Southwest and
Southeast Asian heroin and South American cocaine destined for
European and US markets and of South Asian methaqualone bound for
Southern Africa
======================================================================
@Thailand
--------
Disputes--international: parts of the border with Laos are
indefinite; maritime boundary with Vietnam resolved, August 1997;
parts of border with Cambodia are indefinite; maritime boundary with
Cambodia not clearly defined; sporadic conflict with Burma over
alignment of border
Illicit drugs: a minor producer of opium, heroin, and marijuana;
major illicit transit point for heroin en route to the international
drug market from Burma and Laos; eradication efforts have reduced
the area of cannabis cultivation and shifted some production to
neighboring countries; opium poppy cultivation has been reduced by
eradication efforts; also a drug money-laundering center; minor role
in amphetamine production for regional consumption; increasing
indigenous abuse of methamphetamines and heroin
======================================================================
@Togo
----
Disputes--international: none
Illicit drugs: transit hub for Nigerian heroin and cocaine
traffickers
======================================================================
@Tokelau
-------
Disputes--international: none
======================================================================
@Tonga
-----
Disputes--international: none
======================================================================
@Trinidad and Tobago
-------------------
Disputes--international: none
Illicit drugs: transshipment point for South American drugs
destined for the US and Europe; producer of cannabis
======================================================================
@Tromelin Island
---------------','10cefea5475ae486fd4b38698479cdb64ebe4c8f2c29ff29174e953463ccf525','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29095cde21d9887bf0d05288e3cd6e353c003ac9fd5fc6fb88e3a2990dcf8663',1999,'TM','Turkmenistan','transnational-issues',362,'Illicit drugs: limited illicit cultivator of opium poppy, mostly
for domestic consumption; limited government eradication program;
increasingly used as transshipment point for illicit drugs from
Southwest Asia to Russia and Western Europe; also a transshipment
point for acetic anhydride destined for Afghanistan
======================================================================
@Turks and Caicos Islands
------------------------
Disputes--international: none
Illicit drugs: transshipment point for South American narcotics
destined for the US
======================================================================
@Tuvalu
------','163abc009c8d1dee31294f0f855e125421298cae2df91a18bf44d03248e76084','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72465b9f833afc8157c5d2cbd91144544da50ccdafe793d18a507fe7b5f1294b',1999,'TC','Turks and Caicos Islands','transnational-issues',375,'Disputes--international: Northern Ireland issue with Ireland
(historic peace agreement signed 10 April 1998); Gibraltar issue
with Spain; Argentina claims Falkland Islands (Islas Malvinas);
Argentina claims South Georgia and the South Sandwich Islands;
Mauritius claims island of Diego Garcia in British Indian Ocean
Territory; Rockall continental shelf dispute involving Denmark,
Iceland, and Ireland (Ireland and the UK have signed a boundary
agreement in the Rockall area); territorial claim in Antarctica
(British Antarctic Territory); Seychelles claims Chagos Archipelago
in British Indian Ocean Territory
Illicit drugs: gateway country for Latin American cocaine
entering the European market; producer and major consumer of
synthetic drugs, synthetic precursor chemicals; transshipment point
for Southwest Asian heroin; money-laundering center
======================================================================
@United States
-------------','d0093d6ca0f7aa107792360fac4e784c4ac93714703a3d20b070780e63276264','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b05d0f7f5bd2af080bc5dcc02430656c5833739e69f364472cbf8657ddfcf02f',1999,'ES','Spain','transnational-issues',383,'Disputes--international: two short sections of the boundary with
Brazil are in dispute--Arroyo de la Invernada (Arroio Invernada) area
of the Rio Cuareim (Rio Quarai) and the islands at the confluence of
the Rio Cuareim (Rio Quarai) and the Uruguay River
======================================================================
@Uzbekistan
----------
Disputes--international: none
Illicit drugs: limited illicit cultivation of cannabis and very
small amounts of opium poppy, mostly for domestic consumption,
almost entirely eradicated by an effective government eradication
program; increasingly used as transshipment point for illicit drugs
from Afghanistan to Russia and Western Europe and for acetic
anhydride destined for Afghanistan
======================================================================
@Vanuatu
-------
Disputes--international: claims Matthew and Hunter Islands east of','1f3fb750838543dca26622b4805a249d9ae2d30e666df7c8edd8392f7e436c3a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d946ad1bc8ac7d84c94eb39121c98455fe80a05c48980711aa906943be1d7100',1999,'NC','New Caledonia','transnational-issues',387,'======================================================================
@Venezuela
---------
Disputes--international: claims all of Guyana west of the
Essequibo River; maritime boundary dispute with Colombia in the Gulf
of Venezuela
Illicit drugs: illicit producer of cannabis, opium, and coca leaf
for the international drug trade on a small scale; however, large
quantities of cocaine and heroin transit the country from Colombia
bound for US and Europe; important money-laundering hub; active
eradication program primarily targeting opium
======================================================================
@Vietnam
-------
Disputes--international: maritime boundary with Cambodia not
defined; involved in a complex dispute over the Spratly Islands with
China, Malaysia, Philippines, Taiwan, and possibly Brunei; maritime
boundary with Thailand resolved, August 1997; maritime boundary
dispute with China in the Gulf of Tonkin; Paracel Islands occupied
by China but claimed by Vietnam and Taiwan; offshore islands and
sections of boundary with Cambodia are in dispute; sections of land
border with China are indefinite
Illicit drugs: minor producer of opium poppy with 3,000 hectares
cultivated in 1998, capable of producing 20 metric tons of opium;
probably minor transit point for Southeast Asian heroin destined for
the US and Europe; growing opium/heroin addiction; possible
small-scale heroin production
======================================================================
@Virgin Islands
--------------
Disputes--international: none
======================================================================
@Wake Atoll
----------
Disputes--international: claimed by Marshall Islands
======================================================================
@Wallis and Futuna
-----------------
Disputes--international: none
======================================================================
@West Bank
---------
Disputes--international: West Bank and Gaza Strip are
Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement--permanent status to be
determined through further negotiation
======================================================================
@Western Sahara
--------------
Disputes--international: claimed and administered by Morocco, but
sovereignty is unresolved and the UN is attempting to hold a
referendum on the issue; the UN-administered cease-fire has been in
effect since September 1991
======================================================================
@World
-----
Disputes--international: a large section of boundary with Saudi
Arabia is not defined; Hanish Islands dispute with Eritrea resolved
by arbitral tribunal in October 1998
======================================================================
@Zambia
------
Disputes--international: quadripoint with Botswana, Namibia, and
Zimbabwe is in disagreement
Illicit drugs: transshipment point for methaqualone, heroin, and
cocaine bound for Southern Africa and Europe; regional
money-laundering center
======================================================================
@Zimbabwe
--------
Disputes--international: quadripoint with Botswana, Namibia, and
Zambia is in disagreement
Illicit drugs: significant transit point for African cannabis and
South Asian heroin, mandrax, and methamphetamines destined for the
South African and European markets
======================================================================
Appendix A: Abbreviations
A ABEDA Arab Bank for Economic Development
in Africa
ACC Arab Cooperation Council
ACCT Agence de Cooperation Culturelle et
Technique; see Agency for Cultural
and Technical Cooperation; changed
name in 1996 to Agence de la
francophonie or Agency for the
French-Speaking Community
ACP Group African, Caribbean, and Pacific
Group of States
AfDB African Development Bank
AFESD Arab Fund for Economic and Social
Development
AG Andean Group; see Andean Community
of Nations (CAN)
Air Pollution Convention on Long-Range
Transboundary Air Pollution
Air Pollution- Protocol to the 1979 Convention on
Nitrogen Oxides Long-Range Transboundary Air
Pollution Concerning the Control of
Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution- Protocol to the 1979 Convention on
Persistent Long-Range Transboundary Air
Organic Pollution on Persistent Organic
Pollutants Pollutants
Air Pollution- Protocol to the 1979 Convention on
Sulphur 85 Long-Range Transboundary Air
Pollution on the Reduction of
Sulphur Emissions or Their
Transboundary Fluxes by at Least
30%
Air Pollution- Protocol to the 1979 Convention on
Sulphur 94 Long-Range Transboundary Air
Pollution on Further Reduction of
Sulphur Emissions
Air Pollution- Protocol to the 1979 Convention on
Volatile Organic Long-Range Transboundary Air
Compounds Pollution Concerning the Control of
Emissions of Volatile Organic
Compounds or Their Transboundary
Fluxes
AL Arab League
ALADI Asociacion Latinoamericana de
Integracion; see Latin American
Integration Association (LAIA)
AMF Arab Monetary Fund
AMU Arab Maghreb Union
Ancom Andean Common Market; see Andean
Community ofNations (CAN)
Antarctic- Protocol on Environmental
Environmental Protection to the Antarctic Treaty
Protocol
ANZUS Australia-New Zealand-United States
Security Treaty
APEC Asia Pacific Economic Cooperation
Arabsat Arab Satellite Communications
Organization
AsDB Asian Development Bank
ASEAN Association of Southeast Asian
Nations
Autodin Automatic Digital Network
B BAD Banque africaine de developpement;
see African Development Bank (AfDB)
BADEA Banque Arabe de Developpement
Economique en Afrique; see Arab
Bank for Economic Development in
Africa (ABEDA)
BCIE Banco Centroamericano de
Integracion Economico; see Central
American Bank for Economic
Integration (BCIE)
BDEAC Banque de Developpment des Etats de
l''Afrique Centrale; see Central
African States Development Bank
(BDEAC)
Benelux Benelux Economic Union
BID Banco Interamericano de Desarrollo;
see Inter-American Development Bank
(IADB) Biodiversity Convention on
Biological Diversity
BIS Bank for International Settlements
BOAD Banque Ouest-Africaine de
Developpement; see West African
Development Bank (WADB)
BSEC Black Sea Economic Cooperation Zone
C C Commonwealth
CACM Central American Common Market
CAEU Council of Arab Economic Unity
CAN Andean Community of Nations
Caricom Caribbean Community and Common
Market
CB citizen''s band mobile radio','3a792fccf25cb14a9fd647a3105f5c7128af08c228443ff0abf674ad7768ad2f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

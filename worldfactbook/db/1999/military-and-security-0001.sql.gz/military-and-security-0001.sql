SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca2fa94c3e2441a1dbc5c8ea4c40e3868dd0c2268903914d467690301271cde3',1999,'EH','Western Sahara','military-and-security',14,'Military branches
Military manpower— military age
Military manpower— availability
males age 15-49
females age 15-49
Military manpower— fit for military service
males age 15-49
females age 15-49
Military manpower— reaching military age
annually
males
females
Military expenditures— dollar figure
Military expenditures— percent of GDP
Military— note
Military branches: ground, maritime, and air forces
at all levels of technology
Military expenditures - dollar figure: aggregate
real expenditure on arms worldwide in 1 998 remained
at approximately the 1997 level, about three-quarters
of a trillion dollars (1998 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1998 est.)','52d968fdb6c08a8a511b8a9f5c77f12b2d32b8c63914e56fddc90804594d30e4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aad9de5387dcd5f90738077335e4506ca4cea0c06e4c1a5ef339b97bc5bea30',1999,'AF','Afghanistan','military-and-security',22,'Military branches: NA; note - the military does not
exist on a national basis; some elements of the former
Army, Air and Air Defense Forces, National Guard,
Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower - military age: 22 years of age
Military manpower - availability:
males age 15-49: 6,326,135 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,392,336 (1999 est.)
Military manpower - reaching military age
annually:
males: 248,320 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK','b91c2129264622b9802bbd11b2fe7d78371f723e5d65b7ca1be4b48d705be6e7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7db6cb912774980c364f34fc0edb90cde40759155ddee64f60625a2fc2f14c42',1999,'AL','Albania','military-and-security',29,'Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 763,949 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 622,013 (1999 est.)
Military manpower - reaching military age
annually:
males: 32,954 (1999 est.)
Military expenditures - dollar figure: $60 million
(1998)
Military expenditures - percent of GDP: 2%
(1998)
Military branches: National Popular Army, Navy, Air
Force, Territorial Air Defense, National Gendarmerie
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 8,237,682 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 5,046,931 (1999 est.)
Military manpower - reaching military age
annually:
males: 359,592 (1999 est.)
Military expenditures - dollar figure: $1 .3 billion
(1994)
Military expenditures - percent of GDP: 2.7%
(1994)','23b24e656f9bf16b1af5a8923ce3eb091628abc1615600a49dae0e457867ec6e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bdcb1070f3c02cf6e83f8eff3e9d464b5495173010d5b481a7d3d074c7f673e',1999,'AS','American Samoa','military-and-security',38,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of
France and Spain','80a63eb59b043e680875d4ea4b42c230852ddde251ea00fbde2ab9777a8713fa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5f2cdafb3058601396c8725426b3fc746b7b490f2b7a8474baca42a3a8bfd18',1999,'AI','Anguilla','military-and-security',47,'Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 2,544,203 (1999 est.)
Military - note: defense is the responsibility of the
UK','a7041a682038f4dcfda8a2889aeb08818cc6e605d92894c7821536c663cec6e8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9969876211643661a3fcfccf7b184625444d259171655d5a8cd98c409bae58d9',1999,'AQ','Antarctica','military-and-security',59,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Argentine Army, Navy of the
Argentine Republic (includes Naval Aviation, Marines,
and Coast Guard), Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 9,169,681 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 7,435,551 (1999 est.)
Military manpower - reaching military age
annually:
males: 343,038 (1999 est.)
Military expenditures • dollar figure: $4.6 billion
(1998)
Military expenditures - percent of GDP: 1 .4%
(1998)','7b35ec22f290df23d2ffad2819d53c1633b355098d2d9ebc287bb2ec57f24536','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84136c2d45c1fb738980dd513be7101a6d26128dbe85ea7de43792e023355f3e',1999,'GP','Guadeloupe','military-and-security',68,'Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (includes Coast Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','f6bfb0f99eb1fb7d37a73430cdc0f049fa841ed8268e8423c8da78f8f01dbf00','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('276e41abb30c04201799cd10a7c0589424b20ca8254c8cf4f89c40d0a904e350',1999,'GE','Georgia','military-and-security',85,'Military branches: Army, Air Force and Air Defense
Aviation, Air Defense Force, Security Forces (internal
and border troops)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 922,124 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 732,495 (1999 est.)
Military manpower - reaching military age
annually:
males: 32,052 (1 999 est.)
Military expenditures - dollar figure: $72.1 million
(1999)
Military expenditures - percent of GDP: 4%
(1999)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
Military branches: Ground Forces, Navy, Air Force,
Air Defense Forces, National Guard, Republic
Security Forces (internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,287,225 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,018,309 (1999 est.)
Military manpower - reaching military age
annually:
males: 40,604 (1999 est.)
Military expenditures • dollar figure: $57 million
(1998)
Military expenditures - percent of GDP: 1%
(1998)
Military - note: a CIS peacekeeping force consisting
of Russian troops is deployed in the Abkhazia region
of Georgia together with a UN military observer group;
a Russian peacekeeping battalion is deployed in
South Ossetia','76c9683d35ba70cb6ffca343c92356922f51a1497000a641f36cebc12866149a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f280a67395f9c7ba9c23bc4d7e3808bc6d69f5aad94e1cf74caccf5cbf430dbb',1999,'AU','Australia','military-and-security',97,'Military branches: Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 4,882,693 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,212,272 (1999 est.)
Military manpower - reaching military age
annually:
males: 130,570 (1999 est.)
Military expenditures - dollar figure: $6.9 billion
(FY97/98)
Military expenditures - percent of GDP: 1 .9%
(FY97/98)
Military branches: Army (includes Flying Division)
Military manpower - military age: 1 9 years of age
Military manpower - availability:
mates age 15-49: 2,091 ,902 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,735,469 (1999 est.)
Military manpower - reaching military age
annually:
males: 48,872 (1 999 est.)
Military expenditures - dollar figure: $1 .8 billion
(1999 est.)
Military expenditures - percent of GDP: 0.82%
(1999 est.)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military - note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the
Vatican City
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military branches: Police Force
Military - note: defense is the responsibility of New
Zealand','836945661204e80f5aae012c73d3f8492d79268229d829fea3176e4fde16f791','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21c4664e5b471158b968a4b75d9d95ab3bc9e0b5943e3615ee3e5ed888660382',1999,'AZ','Azerbaijan','military-and-security',106,'Military branches: Army, Navy, Air and Air Defense
Forces, Border Guards
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,041 ,863 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,639,144 (1999 est.)
Military manpower - reaching military age
annually:
males: 73,486 (1999 est.)
Military expenditures -dollar figure: $121 million
(1999)
Military expenditures - percent of GDP: 2.6%
(1999)
Transnationaf Issues
Disputes - international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; transshipment point
for opiates via Iran, Central Asia, and Russia to
Western Europe','a23ec1cceaad07c37d232ffe7a4ae8edb032270311bea3b8f19ca8fdd48ffcc8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7643fd7a02f666ae8f4c92fa2b7b795ebffc901a9ce0cc890aab5627981e779',1999,'BS','Bahamas','military-and-security',111,'Military branches: Royal Bahamas Defense Force
(Coast Guard only), Royal Bahamas Police Force
Military expenditures - dollar figure: $20 million
(FY95/96)
Military expenditures - percent of GDP: NA%','b6c68174d78c7048977d91385d5249c20c07f1da1eb7c57fcb1c251fa765ddd1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a6d29de0bebd86f8420fb7e9bd522606e3a58d45335e9dfc4d4ccae9532aef4',1999,'BH','Bahrain','military-and-security',119,'Military branches: Ground Force, Navy, Air Force,
Coast Guard, Police Force
Military manpower ■ military age: 1 5 years of age
Military manpower - availability:
males age 15-49: 220,670 (1999 est.)
Military manpower - fit for military service:
males age 75-49: 121 ,451 (1999 est.)
Military manpower - reaching military age
annually:
males: NA
Military expenditures - dollar figure: $276.9
million (1994)
Military expenditures - percent of GDP: 4.5%
(1998)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','907de855e67ba154bea5a3de62e25a391becdfef38c95d0cd18d6153a0194b65','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0cfdafbeba5945aed3ac5f7e3fec660c6b29de560951cc1c5654e3909053e79',1999,'BD','Bangladesh','military-and-security',127,'Military branches: Army, Navy, Air Force,
paramilitary forces (includes Bangladesh Rifles,
Bangladesh Ansars, Village Defense Parties, National
Cadet Corps)
Military manpower - availability:
males age 15-49: 33,374,195 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 19,772,013 (1999 est.)
Military expenditures - dollar figure: $559 million
(FY96/97)
Military expenditures - percent of GDP: 1 .8%
(FY96/97)','c7c0b9cc93450db6b83d6230e2cb31e5945964224a7c62f7f19f758757e404cb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0404dec96fd3d2bc8004bdf30744ee1ca7b609e46969642b816983dcdcfdd7e',1999,'LC','Saint Lucia','military-and-security',136,'Military branches: Royal Barbados Defense Force
(includes Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower - availability:
males age 15-49: 72,111 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 49,600 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','fb8bdcfd1fa7e90f4933cf98ae87ec48ff047d6454f61a2e3be13a1d6f95b931','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01d81f7725062f1d76f9cfe2e783b8274874b3ff990f92daf81aad76e64b33be',1999,'MZ','Mozambique','military-and-security',144,'Military - note: defense is the responsibility of
Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 132,969 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 79,224 (1999 est.)
Military expenditures - dollar figure: $3 million
(1994 est.)
Military expenditures - percent of GDP: NA%
Military branches: Army, Naval Command, Air and
Air Defense Forces, Militia
Military manpower - availability:
males age 15-49: 4,385,483 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,526,447 (1999 est.)
Military expenditures - dollar figure: $72 million
(FY97)
Military expenditures - percent of GDP: 4.7%
(1997)
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower - availability:
males age 15-49: 2,738,963 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,707,348 (1999 est.)
Military expenditures - dollar figure: $427 million
(FY97/98)
Military expenditures - percent of GDP: 4.6%
(FY97/98)
Taiwan
Background: In 1895, military defeat forced China to
cede T aiwan to Japan, however it reverted to Chinese
control after World War II. Following the Communist
victory on the mainland in 1949, 2 million Nationalists
fled to Taiwan and established a government that over
five decades has gradually democratized and
incorporated native Taiwanese within its structure.
Throughout this period, the island has prospered as
one of East Asia''s economic tigers. The dominant
political issue continues to be the relationship
between Taiwan and Mainland China and the
question of eventual reunification.
Military branches: Army, Navy (includes Marines),
Air Force, Coastal Patrol and Defense Command,
Armed Forces Reserve Command, Combined Service
Forces
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 6,544,602 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 5,019,737 (1999 est.)
Military manpower - reaching military age
annually:
males: 204,711 (1999 est.)
Military expenditures - dollar figure: $7,446 billion
(FY98/99)
Military expenditures - percent of GDP: 2.8%
(FY98/99)','ab64982962a7063f8b7e0846d2ce3712718a14511442f4b690ec744fb2b354a4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d38c6192ad1911c71cd25128767846d8890a30d941feb004e20fdf0e2ac1865d',1999,'DE','Germany','military-and-security',154,'Military branches: Army, Air Force, Air Defense
Force, Interior Ministry Troops, Border Guards
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 2,700,034 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,115,121 (1999 est.)
Military manpower - reaching military age
annually:
males: 79,905 (1999 est.)
Military expenditures - dollar figure: $1 00 million
(1998)
Military expenditures - percent of GDP: 2%
(1998)
Military branches: Army, National Gendarmerie
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 108,285 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 88,813 (1999 est.)
Military manpower - reaching military age
annually:
males: 2,452 (1999 est.)
Military expenditures - dollar figure: $124 million
(FY97)
Military expenditures - percent of GDP: 0.8%
(1995)
Military branches: no regular military forces, Police
Force
Military manpower - availability:
males age 15-49: 121,355 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 66,744 (1999 est.)
Military - note: defense is currently the responsibility
of Portugal, but will become the responsibility of China
on 20 December 1999
Military branches: Army, Navy, Air and Air Defense
Forces, Police Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 539,329 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 434,468 (1 999 est.)
Military manpower - reaching military age
annually:
males: 17,291 (1999 est.)
Military expenditures - dollar figure: $71 million
(1998)
Military expenditures - percent of GDP: 2.2%
(1998)
Military branches: Popular Armed Forces (includes
Intervention Forces, Development Forces, Aeronaval
Forces - includes Navy and Air Force), Gendarmerie,
Presidential Security Regiment
Military manpower - military age: 20 years of age
298
Madagascar (continued)
Military manpower - availability:
males age 15-49: 3,41 5,726 (1 999 est.)
Military manpower ■ fit for military service:
males age 15-49:2,027,757 (1999 est.)
Military manpower - reaching military age
annually:
males: 144,779 (1999 est.)
Military expenditures - dollar figure: $29 million
(1994)
Military expenditures - percent of GDP: 1 %
(1994)
Military branches: Royal Nepalese Army, Royal
Nepalese Army Air Service, Nepalese Police Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 5,924,732 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,079,569 (1999 est.)
Military manpower - reaching military age
annually:
males: 281 ,658 (1999 est.)
Military expenditures - dollar figure: $44 million
(FY96/97)
Military expenditures - percent of GDP: 0.9%
(FY96/97)','2cbf8497876a5633d5e665b1a2f6514dd7166d9f6ee1523c1ac0e24f29638f41','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad359100878cd0cfd2a02657312da7c52f8d5454ea31a3ee5f8406f72811d39b',1999,'BZ','Belize','military-and-security',166,'Military branches: Belize Defense Force (includes
Ground Forces, Maritime Wing, Air Wing, and
Volunteer Guard), Belize National Police
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 58,201 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 34,531 (1999 est.)
Military manpower - reaching military age
annually:
males: 2,61 9 (1999 est.)
Military expenditures - dollar figure: $15 million
(FY97/98)
Military expenditures - percent of GDP: 2%
(FY97/98)','ac6fd833dc564bd7f1c04fdc27fdcbadf9e9c3c171954262d04dc540a104864b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e0e29ccb381011dcb63c4aef0976fa0df970978ea2cfb776f7e5a479397f8b',1999,'BJ','Benin','military-and-security',173,'Military branches: Armed Forces (includes Army,
Navy, Air Force), National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,363,878
females age 15-49: 1 ,425,987 (1999 est.)
note: both sexes are liable for military service
Military manpower - fit for military service:
males age 15-49: 697,715
females age 15-49: 722,323 (1999 est.)
Military manpower - reaching military age
annually:
males: 67,622
females: 67,238 (1999 est.)
Military expenditures - dollar figure: $27 million
(1996)
Military expenditures - percent of GDP: 1 .2%
(1996)','e1231a536aa4384fd09aca242c7782196b19d6fb3aeabc6c26187308899abe08','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdfb5d83f9dcc70d6b0fa3562c0cfdc7d04ebda1b862de0325230e74a3dbb3d6',1999,'BM','Bermuda','military-and-security',181,'Military branches: Bermuda Regiment, Bermuda
Police Force, Bermuda Reserve Constabulary
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK','38327246dc586e0fc201ba6085c501b8c1673956ed8b0f8bd43a891d0d69e387','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea1dfc579fee9d1de36ad06e21353f0465dfaacb3df0f621eb893300ba329d65',1999,'BT','Bhutan','military-and-security',188,'Military branches: Royal Bhutan Army, Palace
Guard, Militia, Royal Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 477,944 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 254,992 (1 999 est.)
Military manpower - reaching military age
annually:
males: 19,424 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','6ba44247bea7bc7fac631bc56f576d898e4a404dbd135d220ca380648a2df927','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d40a0da617cac3dbabf1bb722011e574343ef1e2b61fa0d2923812c78bd130b5',1999,'BR','Brazil','military-and-security',195,'Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval Boliviana, includes Marines), Air Force
(Fuerza Aerea Boliviana), National Police Force
(Policia Nacional de Bolivia)
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 1 ,908,454 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,241 ,31 1 (1999 est.)
Military manpower - reaching military age
annually:
males: 84,481 (1999 est.)
Military expenditures - dollar figure: $1 54 million
(1998)
Military expenditures - percent of GDP: 1 .8%
(1998)
Military branches: Federation Army or VF
(composed of both Croatian and Bosnian Muslim
elements), Army of the Serb Republic (composed of
Bosnian Serb elements); note - within both of these
forces air and air defense are subordinate commands
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 951 ,541 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 764,992 (1999 est.)
Military manpower - reaching military age
annually:
males: 28,438 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Botswana Defense Force
(includes Army and Air Wing), Botswana National
Police
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 344,587 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 182,279 (1999 est.)
Military manpower - reaching military age
annually:
males: 18,654 (1999 est.)
Military expenditures - dollar figure: $61 million
(FY99/00)
Military expenditures - percent of GDP: 1 .2%
(FY99/00)
Military - note: defense is the responsibility of
Military branches: Brazilian Army, Brazilian Navy
(includes naval air and marines), Brazilian Air Force,
Federal Police (paramilitary)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 47,230,426 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 31 ,723,597 (1 999 est.)
Military manpower - reaching military age
annually:
males : 1 ,841 ,858 (1 999 est.)
Military expenditures - dollar figure: $14.7 billion
(1998)
Military expenditures - percent of GDP: 1 .9%
(1998)','2239f7eb5da5160bac403fdee1678caaa742be25e3376a884c46c09ccb951344','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31f50fa20975af2206df03f07b0d6a9178c5be8a6b7c1e8bc808240212dd8d81',1999,'IO','British Indian Ocean Territory','military-and-security',208,'Military - note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Military - note: defense is the responsibility of the
UK
Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 88,628 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 51 ,270 (1 999 est.)
Military manpower - reaching military age
annually:
males: 3,078 (1999 est.)
Military expenditures - dollar figure: $343 million
(1997)
Military expenditures - percent of GDP: 6%
(1997)
Military branches: Army, Navy, Air and Air Defense
Forces, Border Troops, Internal Troops
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 2,028,930 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,693,597 (1999 est.)
Military manpower - reaching military age
annually:
males: 59,887 (1999 est.)
Military expenditures - dollar figure: $226.8
million (1997)
Military expenditures - percent of GDP: 2.2%
(1997)','02d3d6c3582eddcfd41bce2a8410cc65ebc043587ebc96c84317de30d6656016','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1ad5b8a421ff105b1789e459bf11b8a4e23c0e55aaeb1898cb35c143bfa3892',1999,'NG','Nigeria','military-and-security',219,'Military branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Military manpower - availability:
males age 15-49: 2,399,724 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,230,71 3 (1 999 est.)
Military expenditures - dollar figure: $66 million
(1996)
Military expenditures - percent of GDP: 2%
(1996) ,
Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 12,475,987
females age 15-49: 12,224,947 (1999 est.)
note: both sexes liable for military sen/ice
Military manpower - fit for military service:
males age 15-49: 6,660,309
females age 15-49: 6,510,730 (1999 est.)
Military manpower - reaching military age
annually:
males: 496,91 2
females: 477,803 (1999 est.)
Military expenditures - dollar figure: $3,904 billion
(FY97/98)
Military expenditures - percent of GDP: 2.1%
(FY97/98)
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 25,967,281 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 14,890,337 (1999 est.)
Military manpower - reaching military age
annually:
males: 1 ,201 ,738 (1 999 est.)
Military expenditures - dollar figure: $236 million
(1999)
Military expenditures - percent of GDP: 0.7%
(1999)','b92ab5d8a2adee365629001de914f29ab570e2ff80f10f9b2e96856b1a8638a7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c759534feb954dda2140eb49cae8d5cd597f72eeecbc3c82c10c89e1d95e3514',1999,'BI','Burundi','military-and-security',231,'Military branches: Army (includes naval and air
units), paramilitary Gendarmerie
Military manpower - military age: 16 years of age
Military manpower - availability:
males age 15-49: 1 ,260,909 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 658,1 15 (1999 est.)
Military manpower - reaching military age
annually:
males: 73,271 (1999 est.)
Military expenditures - dollar figure: $25 million
(1993)
Military expenditures - percent of GDP: 2.6%
(1993)
Military branches: Royal Cambodian Armed Forces
(RCAF) - created in 1 993 by the merger of the
Cambodian People''s Armed Forces and the two
noncommunist resistance armies
note: there are also resistance forces comprised of
the Khmer Rouge (also known as the National United
Army or NUA) and a separate royalist resistance
movement
Military manpower - military age: 18 years of age
Military manpower - availability:
mates age 15-49: 2,562,1 12 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,428,523 (1999 est.)
Military manpower - reaching military age
annually:
males: 11 9,839 (1999 est.)
Military expenditures - dollar figure: $85.3 million
(1998)
Military expenditures - percent of GDP: 2.4%
(1998)
Military branches: Army, Navy (includes Naval
Infantry), Air Force, National Gendarmerie,
Presidential Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 3,388,643 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,716,285 (1999 est.)
Military manpower - reaching military age
annually:
mates: mm (1999 est.)
Military expenditures - dollar figure: $1 55 million
(FY98/99)
Military expenditures - percent of GDP: 1 .4%
(FY98/99)','fafb2bbc6828471d3ff787546d98c1b27f82cb0c71f98b3a67b8f28a9f1c2d55','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fd0e5ab29b348946aa56029894e030c6b99073fc0ae53a1869754818058a286',1999,'CA','Canada','military-and-security',238,'Military branches: Canadian Armed Forces
(includes Land Forces Command or LC, Maritime
Command or MC, Air Command or AC,
Communications Command or CC, Training
Command orTC), Royal Canadian Mounted Police
(RCMP)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 8,243,859 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 7,061,937 (1999 est.)
Military manpower - reaching military age
annually:
males: 21 0,884 (1 999 est.)
Military expenditures - dollar figure: $7.1 billion
(FY97/98)
Military expenditures - percent of GDP: 1 .2%
(FY97/98)
Military branches: Ground Forces, Navy, Air Force
Military manpower - military age: 18 years ot age
Military manpower - availability:
males age 15-49: 1 ,108,146 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 681 ,495 (1 999 est.)
Military manpower - reaching military age
annually:
males: 53,508 (1999 est.)
Military expenditures - dollar figure: $26 million
(1998)
Military expenditures - percent of GDP: 1 .2%
(1998)','d54560c5ab871d6317fe57d516f850b021c1ee5994efef3fdb4c0c20e7bb80d4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33cecc47a92573ef14ab9bf91e08daa2bf47ad56e5a5e86446fa46bbc39f7e9b',1999,'PT','Portugal','military-and-security',245,'Military branches: Armed Forces (AF) (includes all
armed force elements, both ground and naval)
Military manpower - availability:
mates age 15-49: 84,018 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 47,672 (1999 est.)
Military expenditures - dollar figure: $3.8 million
(1996)
Military expenditures - percent of GDP: 1 .8%
(1996)
Military branches: Army, Navy (includes Marines),
Air Force, National Republican Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 2,542,188 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,042,730 (1 999 est.)
Military manpower - reaching military age
annually:
males: 73,405 (1999 est.)
Military expenditures - dollar figure: $2,458 billion
(1997)
Military expenditures - percent of GDP: 2.6%
(1997)','004ac17e96b725242aaaa5fdaee0a1cda6ac8544fe1773d742c0581645a00b51','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11c3fd2f1776f1d4639410c13c8e41e7480890836889d92284764ce665901b44',1999,'KY','Cayman Islands','military-and-security',246,'(overseas territory
of the UK)
Caribbean
Sea
Cayman
Brae
Little ^
Cayman r''
Grand
„ Cayman
g^6rge town
O 20 40 km
O 20 40 mi','17724649939509827983bef6c022c51bbd14e7e859e9dd4397364300560acf00','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3267e59519b04341162c21e6d41ea7dda52176f92ea81bf9732ce957f15c4da6',1999,'HN','Honduras','military-and-security',254,'Military branches: Royal Cayman Islands Police
Force (RCIPF)
Military - note: defense is the responsibility of the
UK
Military branches: Central African Armed Forces
(includes Republican Guard and Air Force),
Presidential Guard, National Gendarmerie, Police
Force
Military manpower - availability:
males age 15-49: 782,678 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 409,044 (1999 est.)
Military expenditures - dollar figure: $29 million
(1996)
Military expenditures - percent of GDP: 2.2%
(1996)
Military branches: Armed Forces (includes Ground
Force, Air Force, and Gendarmerie), Republican
Guard, Rapid Intervention Force, Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1,689,112 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 875,541 (1999 est.)
Military manpower - reaching military age
annually:
males: 70,464 (1 999 est.)
Military expenditures - dollar figure: $39 million
(1996)
Military expenditures - percent of GDP: 3.5%
(1996)
Military branches: Army, Navy (includes Marines),
Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,455,053 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 866,492 (1 999 est.)
Military manpower - reaching military age
annually:
males: 69,646 (1999 est.)
Military expenditures - dollar figure: $33 million
(1998)
Military expenditures - percent of GDP: 0.6%
(1998)','0db065cc30fbdefaec32c07dd9077d8318ce9eb1a96ed0d9d97fff8f5bde4d0c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f80ff3a74c5ab9862ba5675cc819e8ab84b7b133f585e8595e562aafb3df0e1c',1999,'CL','Chile','military-and-security',263,'Military branches: Army of the Nation, National
Navy (includes Naval Air, Coast Guard, and Marines),
Air Force of the Nation, Carabineros of Chile (National
Police), Investigations Police
Military manpower - military age: 1 9 years of age
Military manpower - availability:
malesage 15-49: 3,968,176 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,943,206 (1 999 est.)
Military manpower - reaching military age
annually:
males: 132,202 (1999 est.)
Military expenditures - dollar figure: $2.12 billion
(1998); note - includes earnings from CODELCO
Company and costs of pensions; does not include
funding for the National Police (Carabineros) and
Investigations Police
Military expenditures - percent of GDP: 2.79%
(1998)','81651da82eb86c639b3e118886033234afbbae1970f69b6c6b5862ee13be4da3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b13788a3f63aa36d03907afbc32a514cbe7352f38931c14f8432d13eb063e92',1999,'HK','Hong Kong','military-and-security',273,'Military branches: People’s Liberation Army (PLA),
which includes the Ground Forces, Navy (includes
Marines and Naval Aviation), Air Force, Second
Artillery Corps (the strategic missile force), People''s
Armed Police (internal security troops, nominally
subordinate to Ministry of Public Security, but included
by the Chinese as part of the “armed forces" and
considered to be an adjunct to the PLA in wartime)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 361 ,267,706 (1 999 est.)
Military manpower - fit for military service:
males age 15-49:198,398,601 (1999 est.)
Military manpower - reaching military age
annually:
males: 10,273,696 (1999 est.)
Military expenditures - dollar figure: $12,608
billion (FY99); note-Western analysts believe that
China''s real defense spending is several times higher
than the official figure because several significant
items are funded elsewhere
Military expenditures - percent of GDP: NA%','c2a2f06e029b5b41f7b07eff68515dacf035f4cf22534cc1656b8e005c0a6c24','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b914b0cdc0401d6f5cd08d0406fe84bbfc6a42065c6fe38d10f7147e800897af',1999,'FR','France','military-and-security',290,'Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard
(includes Presidential Guard), Sapeur-Pompier
(Military Fire Group)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 3,677,627 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,917,433 (1999 est.)
Military manpower - reaching military age
annually:
males: 178,860 (1999 est.)
Military expenditures - dollar figure: $94 million
(1998)
Military expenditures - percent of GDP: 0.9%
(1996)
Military branches: British Forces Falkland Islands
(includes Army, Royal Air Force, Royal Navy, and
Royal Marines), Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK
Military branches: French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 47,354 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 30,656 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
173
French Southern
and Antarctic Lands
(overseas territory of France)
Indian Ocean
fie Amsterdam .
lie Saint-Paul
°Q lies Crozet
O o
Cv
lies Kerguelen
O 400 800 km
O 400 800 ml
Military - note: defense is the responsibility of
Military branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force, National Guard, Police
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 2,707,628 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,071 ,670 (1 999 est.)
Military manpower - reaching military age
annually:
males: 79,376 (1999 est.)
Military expenditures - dollar figure: $4.04 billion
(1998 est.)
Military expenditures - percent of GDP: NA%
Military branches: French Forces, Gendarmerie
Military - note: defense is the responsibility of
Military branches: Lao People''s Army (LPA;
includes militia element), Lao People''s Navy (LPN;
includes riverine element), Air Force, National Police
Department
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,200,664 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 648,087 (1999 est.)
Military manpower - reaching military age
annually:
males: 57,047 (1999 est.)
Military expenditures - dollar figure: $77.4 million
(FY96/97)
Military expenditures - percent of GDP: 4.2%
(FY96/97)
Military branches: French forces (Army, Navy, Air
Force), Gendarmerie
Military - note: defense is the responsibility of
314
Martinique (continued)
Military branches: French forces (Army, Navy, Air
Force, and Gendarmerie)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 185,800 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 95,068 (1 999 est.)
Military manpower - reaching military age
annually:
males: 5,902 (1999 est.)
Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
paramilitary forces, National Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 2,601 ,928 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,486,964 (1999 est.)
Military manpower - reaching military age
annually:
males: 99,597 (1999 est.)
Military expenditures - dollar figure: $356 million
(1999)
Military expenditures - percent of GDP: 1 .5%
(1999)
Military branches: Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 18,168,658 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 11,024,173 (1999 est.)
Military manpower - reaching military age
annually:
males: 659,338 (1999 est.)
Military expenditures - dollar figure: $6,737 billion
(1997)
Military expenditures - percent of GDP: 4.3%
(1997)
Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 ,1 10,606 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 901 ,735 (1999 est.)
Military manpower - reaching military age
annually:
males: 45,050 (1999 est.)
Military expenditures - dollar figure: $88 million
(1998)
Military expenditures - percent of GDP: 3%
(1998)
Military branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military manpower - availability:
males age 15-49: 14,458,646 (1999 est.)
507
United Kingdom (continued)
Military manpower - fit for military service:
males age 15-49: 12,053,320 (1999 est.)
Military expenditures - dollar figure: $36.7 billion
(FY98/99)
Military expenditures - percent of GDP: 2.6%
(FY98/99)
Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note: the Coast Guard falls under the Department of.
Transportation, but in wartime reports to the
510
United States (continued)
Department of the Navy
Military manpower - military age: 1 8 years of age
Military manpower - fit for military service:
males age 15-49: NA
Military expenditures - dollar figure: $267.2 billion
(1997 est.)
Military expenditures - percent of GDP: 3.4%
(1997 est.)
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','a552b5e0f060575491ab6a4462e3012750fccefc1e34eb540c5268028ce4b799','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc2f8b654b67f44f2a9e82d08a36584602a0a95f91c9c1899cafbd4b533a826b',1999,'CO','Colombia','military-and-security',298,'Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, includes Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 10,418,21 1 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 6,980,700 (1999 est.)
Military manpower - reaching military age
annually:
males: 360,820 (1999 est.)
Military expenditures - dollar figure: $4 billion
(1998)
Military expenditures - percent of GDP: 4.2%
(1998)','10e713698c5b7ac59c2027740075ad6551221b05523b9d3b53c4d47f344ce861','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6658b559388a11cfd1e28a1a26b7a5baffe7b584fb4c99912ae9546aee6084d4',1999,'CG','Congo','military-and-security',305,'Military branches: Army, Navy, Air Force,
Presidential Security Group, Gendarmerie
Military manpower - availability:
males age 15-49: 10,874,744 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 5,536,277 (1999 est.)
Military expenditures - dollar figure: $250 million
(1997)
Military expenditures - percent of GDP: 4.6%
(1997)
Military branches: NA
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 641 ,543 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 326,834 (1999 est.)
Military manpower - reaching military age
annually:
males: 28,976 (1999 est.)
Military expenditures - dollar figure: $110 million
(1993)
Military expenditures - percent of GDP: 3.8%
(1993)','334f4ce519e626262c6bdf9c1e54ae67cf3975df3cafb45fa889208668791673','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6a8765fa1e55085ed6c0cc8d08aaae72dcf9403cc07f8da079fd087e9104b49',1999,'CK','Cook Islands','military-and-security',317,'Military - note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','a4f188566ab0f216694540426ebb4f18b6401a5e8d927835b402d41afb83c7eb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7539ed1256e59297b627ad5c5f2799908d8c77b477d260e52f78ab2874ca670',1999,'CR','Costa Rica','military-and-security',324,'Military branches: Coast Guard, Air Section,
Ministry of Public Security Force (Fuerza Publica);
note - during 1996, the Ministry of Public Security
reorganized and eliminated the Civil Guard, Rural
Assistance Guard, and Frontier Guards as separate
entities; they are now under the Ministry and operate
on a geographic command basis performing ground
security, law enforcement, counternarcotics, and
119
Costa Rica (continued)
national security (border patrol) functions; the
constitution prohibits armed forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 988,887 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 662,827 (1999 est.)
Military manpower - reaching military age
annually:
males: 36,751 (1999 est.)
Military expenditures - dollar figure: $55 million
(1995)
Military expenditures - percent of GDP: 2%
(1995)','fb7255cebe5531c0aea33cc457d52a82649e6a419ab053ca3b95327665a79fcf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc8058c18df3e88794c6d00caa10bbe554dcb1559afc4f6209bbec7bc0ed151b',1999,'SI','Slovenia','military-and-security',333,'Military branches: Ground Forces, Naval Forces,
Air and Air Defense Forces, Frontier Guard, Home
Guard
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 1,188,898 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 943,719 (1999 est.)
Military manpower - reaching military age
annually:
males: 33,722 (1999 est.)
Military expenditures - dollar figure: $950 million
(1999)
Military expenditures - percent of GDP: 5%
(1999)','cb052c05a00c445fe8110aa8ea4ae8c64283cb9d8c1c89f50685958bd6fe0594','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('404d7627ee984a901aeb4bc3cc45938a904070fd2847e36dc888f0eaa4e703f8',1999,'CU','Cuba','military-and-security',342,'Military branches: Revolutionary Armed Forces
(FAR) includes ground forces, Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial T roops Militia (MTT), and Youth Labor Army
(EJT); the Border Guard (TGF) is controlled by the
Interior Ministry
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 3,068,140
females age 15-49: 3,014,686 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,900,893
females age 15-49: 1,862,411 (1999 est.)
Military manpower - reaching military age
annually:
males: 76,328
females: 72,551 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: roughly
4% (1995 est.)
Military - note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993','67f25a1f40598337f2c11b3574a8d7a93262af9133f7b24a16464b23b97c6444','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a575bd6e1cbaa90bfeb2a72a1349b60ddfbc82197b64df4df7ca7f36d14e4fab',1999,'CY','Cyprus','military-and-security',350,'Military branches: Greek Cypriot area: Greek
Cypriot National Guard (GCNG; includes air and naval
elements), Hellenic Forces Regiment on Cyprus
(ELDYK), Greek Cypriot Police; Turkish Cypriot area:
Turkish Cypriot Security Force (TCSF), Turkish
Forces Regiment on Cyprus (KTKA), Turkish
mainland army units
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 194,337 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 133,559 (1999 est.)
Military manpower - reaching military age
annually:
males: 6,410 (1999 est.)
Military expenditures - dollar figure: $405 million
(1996)
Military expenditures - percent of GDP: 5.4%
(1996)','cdebedb9baa9151c3d38e00fb5d16d15e985cf9b0cedede6371f600e1b297a2b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128e147c54f0bbf93f929023f35753f68291bb2b2ed83aa48a67066edcdbb6a6',1999,'DK','Denmark','military-and-security',361,'Military branches: Army, Air and Air Defense
Forces, Civil Defense, Railroad Units
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,684,817 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,046,079 (1999 est.)
Military manpower - reaching military age
annually:
males: 73,072 (1999 est.)
Military expenditures - dollar figure: $1.1 billion
(1998)
Military expenditures - percent of GDP: 1 .8%
(1998)
Military branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1 ,31 6,584 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,1 29,870 (1 999 est.)
Military manpower - reaching military age
annually:
males: 32,130 (1999 est.)
Military expenditures - dollar figure: $2.5 billion
(1999)
Military expenditures - percent of GDP: 1 .6%
(1999)
Military branches: Djibouti National Army (includes
Navy and Air Force)
Military manpower - availability:
males age 15-49: 105,075 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 61 ,71 2 (1 999 est.)
Military expenditures - dollar figure: $22.5 million
(1997)
Military expenditures - percent of GDP: 4.5%
(1997)
l Transnational Issues
Disputes - international: none','2ee563bc8c82f06eb052398cfc94dc795fb425cddeda627efd0df1be23c69b52','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8323f6e3a9c5b9ab8021617685f07b3fe7b6d443bf7c6142b4a5b8a6d2dbc42d',1999,'DO','Dominican Republic','military-and-security',373,'Military branches: Commonwealth of Dominica
Police Force (includes Special Service Unit, Coast
Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force, National
Police
Military manpower - military age: 18 years of age
Military manpower • availability:
males age 15-49: 2,156,827 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,355,342 (1999 est.)
Military manpower - reaching military age
annually:
males: 82,902 (1999 est.)
Military expenditures - dollar figure: $180 million
(1998)
Military expenditures - percent of GDP: 1.1%
(1998)
Military branches: paramilitary National Guard,
Police Force
Military - note: defense is the responsibility of the
US','e418490480ab6bea95b70751009223218c788aa5bc82c4dd6ccceaf6e60b6993','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3253cb5ea6433e32abb1325b21c579d54a1a53cb1513a1eb08b52072b6d21f86',1999,'PE','Peru','military-and-security',385,'Military branches: Army (Ejercito Ecuatoriano),
Navy (Armada Ecuatoriana, includes Marines), Air
Force (Fuerza Aerea Ecuatoriana), National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 3,259,534 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 2,199,704 (1999 est.)
Military manpower - reaching military age
annually:
males: 130,208 (1999 est.)
Military expenditures - dollar figure: $720 million
(1998)
Military expenditures - percent of GDP: 3.4%
(1998)','d94add3078ade45093eba2cb7e815e917fb46f64fd9ca4bad47fd48dd66d4c1a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da03348f097c76c7bcbbc2060505c461aa57f044a0055afce77aa18f5bfaa955',1999,'EG','Egypt','military-and-security',394,'Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 17,756,706 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,507,058 (1999 est.)
Military manpower - reaching military age
annually:
males: 694,468 (1999 est.)
Military expenditures - dollar figure: $3.28 billion
(FY95/96)
Military expenditures - percent of GDP: 8.2%
(FY95/96)
Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,393,986 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 884,093 (1 999 est.)
Military manpower - reaching military age
annually:
males: 65,224 (1999 est.)
Military expenditures - dollar figure: $1 05 million
(1998)
Military expenditures - percent of GDP: 0.9%
(1998)
i Transnational Issues
Disputes - international: demarcation of boundary
with Honduras defined by 1992 International Court of
Justice (ICJ) decision has not been completed; small
boundary section left unresolved by ICJ decision not
yet reported to have been settled; with respect to the
maritime boundary in the Golfo de Fonseca, ICJ
referred to an earlier agreement in this century and
advised that some tripartite resolution among El
Salvador, Honduras and Nicaragua likely would be
required
Illicit drugs: transshipment point for cocaine;
marijuana produced for local consumption
Equatorial Guinaa |
i J
Location: Western Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,050 sq km
land: 28,050 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, timber, small
unexploited deposits of gold, manganese, uranium
Land use:
arable land: 5%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 46%
of/oer: 41% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: violent windstorms, flash floods
Environment - current issues: tap water is not
potable; desertification
Environment - international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Law of the Sea, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: insular and continental regions
rather widely separated','807dfea84bc131e5e10fe06b9c9a75aa37724b148bda5df14de7cd34bd485cb2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ddcf869fade0344c662ac2fc99b29b77721b7d6b03719ce97557398da9eb015',1999,'GN','Guinea','military-and-security',400,'Military branches: Army, Navy, Air Force, Rapid
Intervention Force, National Police
Military manpower - availability:
males age 15-49: 102,269 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 51 ,979 (1 999 est.)
Military expenditures - dollar figure: $2.5 million
(FY97/98)
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force
Military expenditures - dollar figure: $1 96 million
(1997)
Military expenditures - percent of GDP: 28.6%
(1997)
Military branches: Papua New Guinea Defense
Force (includes Ground, Naval, and Air Forces, and
Special Forces Unit)
Military manpower - availability:
males age 15-49: 1 ,238,683 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 687,978 (1999 est.)
Military expenditures - dollar figure: $41 .5 million
(1998)
Military expenditures - percent of GDP: 1 %
(1998)
Paracel Islands
South China Sea
Na-iii r erf,, Amphitrite
West Sand oTTree Island Group
Pattle
Island
Robert Islands
Woody *°Rockytsland
Island
ci _ Drummond Island
Lincoln
Island
Money Island" Duncan
1 Island -
Discovery Reef
Vuladdore
Reef
Crescent
Group
Passu ^ s
Keah
Bombay
Reef
Triton0
Island
O 30 60 km
O 30 60 mi','e7c50915849499ed2beae5bdfa3ba26a8661b7c3cd4b8b3f63787c139e8655b4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8201600f6ad77bcf06c33593636080fefe36dcf00dda99c43575faee90c5f30',1999,'EE','Estonia','military-and-security',412,'Military branches: Ground Forces, Navy/Coast
Guard, Air and Air Defense Force (not officially
sanctioned), Maritime Border Guard, Volunteer
Defense League (Kaitseliit), Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 349,263 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 274,276 (1999 est.)
Military manpower - reaching military age
annually:
males: 10,503 (1999 est.)
Military expenditures - dollar figure: $70 million
(1999)
Military expenditures - percent of GDP: 1 .2%
(1999)','cd0cac4a63ce22c2dd247f417bb99c93ab23be82dc7a6f3620f3d0819d57e262','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c19b102105195d5b04ff02aa595876fc09d8a37705639abc283206179131be8e',1999,'DJ','Djibouti','military-and-security',420,'Military branches: Ground Forces, Air Force, Police
note: Ethiopia is landlocked and has no navy;
following the de jure independence of Eritrea,
Ethiopian naval facilities remained in Eritrean
possession and ships which belonged to the former
157
Ethiopia (continued)
Ethiopian Navy and based at Djibouti have been sold
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 13,520,302 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 7,052,710 (1999 est.)
Military manpower • reaching military age
annually:
males: 655,290 (1999 est.)
Military expenditures - dollar figure: $1 38 million
(FY98/99)
Military expenditures - percent of GDP: 2.5%
(FY98/99)
Military - note: defense is the responsibility of','f7b96c2427e0c1a9d415bf8f790f104150dfc159ef4542e6dbc0d1f3e0824d9a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04ff1ad9a8052ce49e3802219518f3ab2c2638e44d74b48b17f0ec19c8bd3f0e',1999,'FO','Faroe Islands','military-and-security',431,'Military branches: no organized native military
forces; only a small Police Force and Coast Guard are
maintained
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of','551dde70c2261a8999f0572b63ed53ecb56e4fedddcb191f2e394c5a17efea08','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8457a374998985664785c24207f29d674ec04e65b2651167cb7b1563460928d9',1999,'JE','Jersey','military-and-security',440,'Military branches: Republic of Fiji Military Forces
(RFMF; includes ground and naval forces)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 218,853 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 120,555 (1999 est.)
Military manpower - reaching military age
annually:
mates: 9,326 (1999 est.)
Military expenditures ■ dollar figure: $34 million
(1997)
Military expenditures - percent of GDP: 1 .6%
(1997)
Military branches: Israel Defense Forces (includes
ground, naval, and air components), Pioneer Fighting
Youth (Nahal), Frontier Guard, Chen (women); note -
historically there have been no separate Israeli
military services
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 ,474,046
females age 15-49: 1,439,569 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,206,320
females age 15-49: 1,173,818 (1999 est.)
Military manpower - reaching military age
annually:
males: 50,737
females: 48,546 (1999 est.)
Military expenditures - dollar figure: $8.7 billion
(1999)
Military expenditures - percent of GDP: 9.5%
(1999)
Military - note: defense is the responsibility of the
UK
Tran s it a tional Issues
Disputes - international: none
Johnston Atoll
(territory of the US)
Military - note: defense is the responsibility of the
US
Military branches: Army, Navy, Air Force, National
Police Force, National Guard, Coast Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49:718,061 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 425,126 (1999 est.)
Military manpower - reaching military age
annually:
males: 20,854 (1999 est.)
Military expenditures - dollar figure: $2.7035
billion (FY98/99)
Military expenditures - percent of GDP: 7.9%
(FY98/99)
Military branches: French Armed Forces (Army,
Navy, Air Force, Gendarmerie); Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower - availability:
males age 15-49: 221 , 1 99 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 128,806 (1999 est.)
Military expenditures - dollar figure: $23 million
(FY95/96)
Military expenditures - percent of GDP: 1 .9%
(FY95/96)
Military branches: Swedish Army, Royal Swedish
Navy, Swedish Air Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,076,903 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,817,554 (1999 est.)
Military manpower - reaching military age
annually:
males: 52,486 (1999 est.)
Military expenditures - dollar figure: $4.9 billion
(FY97/98)
Military expenditures - percent of GDP: 2.2%
(FY97/98)','9e7834d0fed545aa7007afde0c70fe8a972654a2b4f79b29a1494bf7a23ed3b0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6229b92c9ae842b96a69ddce51860dbc04b805044574015ca72c0fe72e90c84',1999,'FI','Finland','military-and-security',449,'Military branches: Army, Navy, Air Force, Frontier
Guard (includes Sea Guard)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1 ,274,654 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1,050,944 (1999 est.)
Military manpower - reaching military age
annually:
males: 34,336 (1999 est.)
Military expenditures - dollar figure: $1 .8 billion
(1999)
Military expenditures - percent of GDP: 2%
(1999)','ab58dc3b5f4297a98552734bbd916518661f6cc544698a3ae838fd9b9063a029','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92075116b655ce8bb02cf57185253721010ffb90be132fd5134c754be8559b61',1999,'WF','Wallis and Futuna','military-and-security',456,'Military branches: Army (includes Marines), Navy
(includes Naval Air), Air Force (includes Air Defense,
National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,666,286 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 12,203,675 (1999 est.)
Military manpower - reaching military age
annually:
males: 41 1,911 (1999 est.)
Military expenditures - dollar figure: $39,831
billion (1997)
Military expenditures - percent of GDP: 2.5%
(1995)
Military - note: defense is the responsibility of the
US','3453fe5c7d15ef5aac706de38beb82102e24e1cab2c086e18543d7bae318ac43','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056458b127219c7cec60886b7c044f71afbb78c5221567fd0dca9acfc63e67d3',1999,'KI','Kiribati','military-and-security',467,'Military branches: French Forces (includes Army,
Navy, Air Force), Gendarmerie
Military - note: defense is the responsibility of','2a10efa8340dcb6cf0ff6df9dde524a37e70c34d1720eb51085c5524674504bb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('456db8f1d76518e125c88d1d1fb6f41404dc511f8fe55abd2dc34163e61c5d4a',1999,'GA','Gabon','military-and-security',474,'Military branches: Army, Navy, Air Force,
Republican Guard (charged with protecting the
president and other senior officials), National
Gendarmerie, National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 280,719 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 144,133 (1999 est.)
Military manpower - reaching military age
annually:
males: 1 1 ,392 (1999 est.)
Military expenditures - dollar figure: $91 million
(1996)
Military expenditures - percent of GDP: 1 .6%
(1996)
176
Gabon (continued)
Military branches: Army (includes marine unit),
National Police, National Guard
Military manpower - availability:
males age 15-49: 296,976 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 149,670 (1999 est.)
Military expenditures - dollar figure: $1 .2 million
(FY96/97)
Military expenditures - percent of GDP: 2%
(FY96/97)
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','1c1b47fb6d76b8703af94337885bd2f2feb4e0468e43ab8e8164da198d713ca9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f347fe6c0038644e45f0fd6618e809d29a85a5d11a90c26333eec50557ad16fb',1999,'GH','Ghana','military-and-security',478,'Military branches: Army, Navy (includes Naval Air
Arm), Air Force, Medical Corps, Border Police, Coast
Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 20,860,710 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 17,799,070 (1999 est.)
Military manpower - reaching military age
annually:
males: 472,708 (1999 est.)
Military branches: Army, Navy, Air Force, National
Police Force, Palace Guard, Civil Defense
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 4,520,125 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,507,954 (1999 est.)
Military manpower - reaching military age
annually:
males: 184,360 (1999 est.)
Military expenditures - dollar figure: $53 million
(1999)
Military expenditures - percent of GDP: 0.7%
(1999)','a9a821fa8d6b2dba928f32d596340ca57867074f6ed740ecd508e389b181e1b7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('040a684c849956274433a095c3977d39c562d6a8c8a327834056af5a0512a0e3',1999,'ES','Spain','military-and-security',492,'Military branches: British Army, Royal Navy, Royal
Air Force
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 10,374,314 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 8,346,155 (1999 est.)
Military manpower - reaching military age
annually:
males: 31 1,350 (1999 est.)
Military expenditures - dollar figure: $6.3 billion
(1995)
Military expenditures - percent of GDP: 1 .4%
(1995)','865ef515d02c8fc1427ccb1f5b527ca40488db7517139f35410d14d92a186383','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ca3c84724df30263ace5916fa45df355628d07bb13f23f80cc65627f854157',1999,'GD','Grenada','military-and-security',507,'Military branches: Royal Grenada Police Force
(includes Special Sen/ice Unit), Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Royal Saint Vincent and the
Grenadines Police Force (includes Special Service
Unit), Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','1925bd200075fd9686aa9f97dcba55c4d93f301575342562ca1c288b597f7aa2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eeaccbdbe5db7449a400c98be3107ef1e2924f038f0d1867d8138958a425323',1999,'GU','Guam','military-and-security',516,'Military - note: defense is the responsibility of the
US
Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,915,169 (1999 est.)
Military manpower • fit for military service:
mates age 15-49: 1 ,903,382 (1999 est.)
Military manpower - reaching military age
annually:
mates: 134,964 (1999 est.)
Military expenditures - dollar figure: $1 24 million
(1998)
Military expenditures - percent of GDP: 0.7%
(1998)','2a6d9f858025dfb6f37c92bfff41d79c9cae489453bfdd8ae99e5733b05fcc2b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c19eb0db5a340bae776fbc058c25f6183dce02644e600dcc7ffce68480f12856',1999,'GG','Guernsey','military-and-security',523,'Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force,
Republican Guard, Presidential Guard, paramilitary
National Gendarmerie, National Police Force (Surete
National)
Military manpower - availability:
males age 15-49: 1,726,933 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 871 ,61 5 (1 999 est.)
Military expenditures - dollar figure: $56 million
(1996)
Military expenditures - percent of GDP: 1 .4%
(1996)','5836b4a80f0846067dfbaac51545f47dffafacf118244b2c746f7c9f27130c02','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('705fa7523e8507c4af8e604bdb75ee3711b69e2fecf30d9c4764991dd1ee3266',1999,'ET','Ethiopia','military-and-security',528,'Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower - availability:
males age 15-49: 284,998 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 162,485 (1999 est.)
Military expenditures - dollar figure: $8 million
(1996)
Military expenditures - percent of GDP: 2.8%
(1996)
Military branches: Army, Navy, Security Police
Military manpower - availability:
males age 15-49: 31,724 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 16,766 (1999 est.)
Military expenditures - dollar figure: $500,000
(1994)
Military expenditures - percent of GDP: 1 .5%
(1994)','208743203fe0eabf69dd6389a03672b06ed941f4a8b32b252dc799e76a634cf9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e17cd88e6b82b080ead285801386a541796abba68c8f9ce303d09187254c391',1999,'GY','Guyana','military-and-security',534,'Military branches: Guyana Defense Force (GDF;
includes Ground Forces, Coast Guard, and Air
Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS), Guyana Police Force
Military manpower - availability:
males age 15-49 : 202,509 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 152,839 (1999 est.)
Military expenditures - dollar figure: $7 million
(1994)
Military expenditures - percent of GDP: 1 .7%
(1994)
Military branches: National Army (includes small
Navy and Air Force elements), Civil Police
Military manpower - availability:
males age 15-49: 1 1 8,686 (1999 est.)
Military manpower - fit for military service:
mates age 15-49: 69,842 (1999 est.)
Military expenditures - dollar figure: $8.5 million
(1997 est.)
Military expenditures - percent of GDP: 1 .6%
(1997 est.)
Military - note: demilitarized by treaty (9 February
1920)','6b77d646065100f1310d1bb43ed71e5a0339ecb82ed500da97e88405689b0679','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61049b53cc3a9141b99143198378c2039d8c68d151fac2a5ad3d616ee90406ec',1999,'HT','Haiti','military-and-security',543,'Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until/
unless constitutionally abolished
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,541 ,402 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 835,578 (1999 est.)
Military manpower - reaching military age
annually:
males: 80,1 58 (1999 est.)
Military expenditures - dollar figure: $NA; note -
mainly for police and security activities','86d018510a6241fa4dd4c0895dc51852afea5db8a404d86c7137656d05469bab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d7f751c3ab177c3771abc7932b4e94af11eb043cf1b5b8ba858ce23ed2587d',1999,'NI','Nicaragua','military-and-security',553,'Military branches: Hong Kong garrison of the PLA
including elements of the PLA Army, the PLA Navy
and PLA Air Force; these forces are under the direct
leadership of the Central Military Commission in
Beijing and under administrative control of the
adjacent Guangzhou Military Region
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,924,304 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,452,110 (1999 est.)
Military manpower - reaching military age
annually:
males: 45,656 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of China','699fd11ffe2b92101f3a6b5d7a1b70ddcf122db423a720f57faaa3e88fdf7252','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f401e685f7f7a363a489ac135677fb057a9b4e4930c294f95e9ad614da6c59',1999,'AT','Austria','military-and-security',561,'Military branches: Ground Forces, Air Force,
Border Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 2,601,741 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,073,419 (1999 est.)
Military manpower - reaching military age
annually:
males: 70,393 (1999 est.)
Military expenditures • dollar figure: $645 million
(1997)
Military expenditures - percent of GDP: 1 .4%
(1997)','3cd24db92b4ea5d5c6d7c60ac8d1a0c1af76b4ebef570b44845ee6e1585a6e45','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cdec5db0b4d884306e038010809d22cbb26402545edd90687d0a22a80ae40e5',1999,'IS','Iceland','military-and-security',571,'Military branches: no regular armed forces; Police,
Coast Guard; note - Iceland''s defense is provided by
the US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military manpower - availability:
males age 15-49: 70,958 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 62,570 (1999 est.)
Military expenditures - dollar figure: none
Military - note: Iceland''s defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military ■ note: defense is the responsibility of','71c633c9e176e74357a093cd2783dd7a85b29fc756c175f327674931959fc448','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91ddd0089d18b4bf1a71e1405e23413ab6823f9091bc90466c9ed4335f8b1070',1999,'ID','Indonesia','military-and-security',574,'Military branches: Army, Navy, Air Force, National
Police
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 61,087,521 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 35,804,125 (1999 est.)
Military manpower - reaching military age
annually:
males: 2,268,638 (1999 est.)
Military expenditures - dollar figure: $959.7
million (FY97/98)
Military expenditures - percent of GDP: 1%
(FY97/98)
Military branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air and Air
Defense Forces), Revolutionary Guards (includes
Ground, Air, Navy, Qods, and
Basij-mobilization-forces), Law Enforcement Forces
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 17,203,360 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 10,217,269 (1999 est.)
Military manpower - reaching military age
annually:
males: 767, 152 (1999 est.)
Military expenditures - dollar figure: $5,787 billion
(FY98/99)
Military expenditures - percent of GDP: 2.9%
(FY98/99)
Military branches: Army, Republican Guard and
Special Republican Guard, Navy, Air Force, Air
Defense Force, Border Guard Force, Internal Security
Forces
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 5,459,998 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,058,098 (1999 est.)
Military manpower - reaching military age
annually:
males: 259,91 5 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air Force, Royal
Malaysian Police Force, Marine Police, Sarawak
Border Scouts
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 5,526,555 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,349,066 (1999 est.)
Military manpower - reaching military age
annually:
males: 183,928 (1999 est.)
Military expenditures - dollar figure: $2.1 billion
(1998)
Military expenditures - percent of GDP: 2.1%
(1998)
Military - note: Federated States of Micronesia
(FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
the US for its defense
Military - note: defense is the responsibility of the
US
Military branches: Ground Forces, Air and Air
Defense Forces, Republic Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,151 ,674 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 908,347 (1999 est.)
Military manpower - reaching military age
annually:
males: 38,666 (1999 est.)
Military expenditures - dollar figure: $6.3 million
(FY99)
Military expenditures - percent of GDP: 1%
(1999)
Military branches: Army, Navy (includes Coast
Guard and Marine Corps), Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 20,228,797 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 14,261,514 (1999 est.)
Military manpower - reaching military age
annually:
males: 818,006 (1999 est.)
Military expenditures - dollar figure: $995 million
(1998)
Military expenditures - percent of GDP: 1 .5%
(1998)
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower - availability:
mates age 15-49: 1,042,587 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 757,940 (1999 est.)
Military expenditures - dollar figure: $4,244 billion
(FY98/99)
Military expenditures - percent of GDP: 5.1%
(FY98/99)','e6868dbd34c6ef0e8d5c6999ca193a12bfc0c4e938711a061a2ec8065e9d6904','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e46aa76435e0f9cde1573a1f0f9e760e92884bd9f5a5429cdc4bd8971848d89',1999,'TN','Tunisia','military-and-security',583,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,142,889 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 12,200,780 (1999 est.)
Military manpower • reaching military age
annually:
males: 31 5,952 (1 999 est.)
Military expenditures - dollar figure: $21 .095
billion (FY97)
Military expenditures - percent of GDP: 1 .9%
(1995)','aaf6fe8979cbd30175c31f845d503f60987501267a3b3f6a249c3ee34dac58ee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('181a0dbd0a0c70c4f7ea8ac9ef05144a98e264a6818d2c6b706854338f86bd3a',1999,'NO','Norway','military-and-security',598,'Military branches: Japan Ground Self-Defense
Force (Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 30,646,516 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 26,438,961 (1999 est.)
Military manpower - reaching military age
annually:
males: 784,658 (1999 est.)
Military expenditures - dollar figure: $42.9 billion
(FY98/99)
Military expenditures - percent of GDP: 0.9%
(FY98/99)
Military branches: Norwegian Army, Royal
Norwegian Navy (includes Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Home Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1 ,103,738 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 917,244 (1999 est.)
Military manpower - reaching military age
annually:
males: 27,448 (1999 est.)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: 2.2%
(1998)
Military branches: Army, Navy, Air Force,
paramilitary (includes Roya! Oman Police)
Military manpower - military age: 14 years of age
Military manpower - availability:
males age 15-49: 752,637 (1999 est.)
Military manpower - fit for military service:
mates age 15-49: 420,361 (1999 est.)
Military manpower - reaching military age
annually:
mates: NA
Military expenditures - dollar figure: $1 .672 billion
(1998)
Military expenditures - percent of GDP: 11.1%
(1998)
Military branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 33,496,71 2 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 20,519,762 (1999 est.)
Military manpower - reaching military age
annually:
mates: 1 ,553,31 0 (1 999 est.)
Military expenditures - dollar figure: $2.48 billion
(FY98/99)
Military expenditures - percent of GDP: 4.4%
(FY98/99)
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years
375
Palau (continued)
Transnational Issues Palmyra Atoll
Disputes - international: none (territory of the US)
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to American','396ab20c13e8a4ecc48d82e028356eda0cd575e05231bf2cd91999e64564a603','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e7541b3561f751527760b18f1b9e17f6346f299351a67b8a22ec958c8a44ba',1999,'JO','Jordan','military-and-security',603,'Military branches: Jordanian Armed Forces (JAF;
includes Royal Jordanian Land Force, Royal Naval
Force, and Royal Jordanian Air Force); Badiya
(irregular) Border Guards; Ministry of the Interior''s
Public Security Force (falls under JAF only in wartime
or crisis situations)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,1 13,998 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 793,002 (1999 est.)
Military manpower - reaching military age
annually:
males: 49,954 (1999 est.)
Military expenditures - dollar figure: $608.9
million (FY 98)
Military expenditures - percent of GDP: 7.8%
(1997)
Military - note: defense is the responsibility of','e82fba3763a022c4da60dd2ff3838e9ce4931bdd5425545088f7b4122fe1027b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8686274538a19e7d50a449b6bf0a633b646f4a17fa91f4f1350a56dac99cb3e',1999,'KZ','Kazakhstan','military-and-security',612,'Military branches: General Purpose Forces (Army),
Air Force, Border Guards, Navy, Republican Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 4,450,258 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,550,645 (1999 est.)
Military manpower - reaching military age
annually:
males: 155,767 (1999 est.)
Military expenditures - dollar figure: $232.4
million (1998)
Military expenditures - percent of GDP: 1%
(1998)
Military branches: Army, Navy, Air Force,
paramilitary General Service Unit of the Police
Military manpower - availability:
males age 15-49: 7,094,151 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,397,008 (1999 est.)
Military expenditures - dollar figure: $1 97 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)','00900cc944ecd1a10a7947c974ed1fee2b035f569176eea325c2923bacb61c67','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9cd85029de9cb5921ad5d737ff0ce764b67ee874c885da1b6874a745820615c',1999,'WS','Samoa','military-and-security',618,'Military - note: defense is the responsibility of the
US
Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,768,038 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,483,188 (1999 est.)
Military manpower - reaching military age
annually:
mates; 177,888 (1999 est.)
Military expenditures - dollar figure: $5 billion to
$7 billion (1997 est.)
Military expenditures - percent of GDP: 25% to
33% (1997 est.)
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 13,954,916 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 8,890,144 (1999 est.)
Military manpower - reaching military age
annually:
males: 400,468 (1999 est.)
Military expenditures - dollar figure: $9.9 billion
(FY98/99)
Military expenditures - percent of GDP: 3.2%
(FY98/99)
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
total: 1 1 .9 sq km
land: 1 1 .9 sq km
water: 0 sq km
Area - comparative: about 20 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial, hot, and very rainy
Terrain: very low
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 100%
other: 0%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: about 50 islets covered with
dense vegetation, coconut trees, and balsa-like trees
up to 30 meters tall
Military - note: defense is the responsibility of the
US
Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider any
Samoan request for assistance under the 1 962 T reaty
of Friendship','b8b1d09f88646527e70a0b1626c836b8e529deb67017f3e256c65528866620d4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8297a2b9ae71fd3221c1799af2e72e490a2750807d744bbf42f92321e789489',1999,'KG','Kyrgyzstan','military-and-security',630,'Military branches: Army, National Guard, Security
Forces (internal and border troops), Civil Defense
note: border troops controlled by Russia
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,146,595 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 930,017 (1999 est.)
Military manpower - reaching military age
annually:
mates: 46,561 (1999 est.)
Military expenditures - dollar figure: $1 0.8 million
(1996)
Military expenditures - percent of GDP: 1%
(1996)','04147100bc18d4cf55c6dc2d4728087a10d40f0744d5a90d9f645b85a2cab759','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac7196e0f6fd2b219657368a2c68f429949fdd145466db31d964fd730c7c5a25',1999,'LV','Latvia','military-and-security',638,'Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Security Forces, Border Guard,
Home Guard (Zemessardze)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 565,81 1 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 443,879 (1999 est.)
Military manpower - reaching military age
annually:
males: 16,883 (1999 est.)
Military expenditures - dollar figure: $60 million
(1999)
Military expenditures - percent of GDP: 0.9%
(1999)','000796109b6d6b8f99fa9bbc138505a1b5a70ba7fa5d329c841b9d41dd006749','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c60946b64081572a80e52cd53b618fa331fa3176e46a9a388321895f9e263d21',1999,'LB','Lebanon','military-and-security',647,'Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower - availability:
males age 15-49: 925,834 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 573,093 (1999 est.)
Military expenditures - dollar figure: $445 million
(1997)
Military expenditures - percent of GDP: 5%
(1997)','f589010cb6b575a26cbb5c1d06559c869f799e0b4bbcb60e1154b1614e3ee986','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f83580817fe6abcfa66925b7ecb0a2ebc846a542d8a26f702cdec63feda6f79',1999,'ZA','South Africa','military-and-security',655,'Military branches: Lesotho Defense Force (LDF;
includes Army and Air Wing), Royal Lesotho Mounted
Police (RLMP)
Military manpower - availability:
males age 15-49: 504,442 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 271,925 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Force, Navy
Military manpower - availability:
males age 15-49: 667,032 (1999 est.)
Military manpower - tit tor military service:
males age 15-49: 356,825 (1999 est.)
Military expenditures - dollar figure: $1 .4 million
(1998)
Military expenditures - percent of GDP: 2%
(1998)','3f2c15b437b7677a8fb5125bdb605670ea1676bd887f4f5234e23c927730e0a2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b4af4996f52d5f447dfd30cd51ca26fde1590e3958f12b47cd95cbfc2c5439',1999,'LY','Libya','military-and-security',665,'Military branches: Army, Navy, Air and Air Defense
Command
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1,372,261 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 816,186 (1999 est.)
Military manpower - reaching military age
annually:
males: 62,098 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','24046da96174333192e439d32d469e0d14cbec51db66804024085b16860ca3c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c523ac4205b31c9bcb01bb84092211f100a6278d5eb6a87d596f1b6efca69f6',1999,'CH','Switzerland','military-and-security',678,'Military branches: Ground Forces, Navy, Air and Air
Defense Force, Security Forces (internal and border
troops), National Guard (Skat)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 906,687 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 713,436 (1999 est.)
Military manpower - reaching military age
annually:
males: 26,168 (1999 est.)
Military expenditures - dollar figure: $181 million
(1999)
Military expenditures - percent of GDP: 1 .5%
(1999)','98662b8e59a2e930ad00249542cbb0ddd4104dc7f45d76e358c9e00a3f24dc7c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28a6c74c7a236191fc9ecb5e7f2caacc69c87f233bdda6b074c8ed1aba6d4b65',1999,'JP','Japan','military-and-security',687,'Military branches: Army (includes Air Wing and
Naval Detachment), Police (includes paramilitary
Mobile Force Unit)
Military manpower - availability:
males age 15-49:2,314,509 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1,186,341 (1999 est.)
Military expenditures - dollar figure: $1 7 million
(FY96/97)
Military expenditures - percent of GDP: 0.8%
(FY96/97)','b10e2b1afa3ae2ab1c18de49414bf87964bd4c0963b961378ca444c65adf1e7b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e98397b3957e0a77781ab6e58226ab9b4cf200b7ec6de29277271ff3611877e',1999,'MV','Maldives','military-and-security',697,'Military branches: National Security Service
(paramilitary police force)
Military manpower - availability:
males age 15-49: 66,554 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 37,086 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','de7e2eda44ce106006875d19bbb9c471bf15e1f7e18254017ba3d26ab6e51d6b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1845d2c991e1bca8770b92e8695704c58673c087db7ad15a5be762568d6af509',1999,'ML','Mali','military-and-security',704,'Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower - availability:
males age 15-49: 2,128,375 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,218,732 (1999 est.)
Military expenditures - dollar figure: $49 million
(1996)
Military expenditures - percent of GDP: 2%
(1996)','6f224db86b8daea5c639be9ebac2f9847e5b0402844edc796cc345e23fb96589','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae3e64f6b84889b051d4d54bf045faf90848d638b32c8e91c5d49874b1851870',1999,'MT','Malta','military-and-security',711,'Military branches: Armed Forces (including an air
squadron, a maritime squadron, and the Revenue
Security Corps), Maltese Police Force
Military manpower - availability:
mates age 15-49: 99,067 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 78,855 (1999 est.)
Military expenditures - dollar figure: $65.5 million
(FY96/97)
Military expenditures - percent of GDP: 2.7%
(FY96/97)','3ae6ff2f95322448dda38d3c9e371b59844620d7913d3bd12b1aff0324365fea','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('206ddf70d5e215dcca5c3a4c0d37c062716e212f245bb891a444d5d84e49ab21',1999,'MH','Marshall Islands','military-and-security',720,'Military branches: no regular military forces (a
coast guard may be established); Police Force
Military - note: defense is the responsibility of the
US','17fe5db904e57815a361bff86b661b41dfaa48cc3a18d99bf314fc5c41360b6c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f31de8cb5c3b5405f8cb4b8431e056bf0c3dd96ff4d54a9ce980f35d1899b3c5',1999,'MR','Mauritania','military-and-security',731,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Military manpower - availability:
males age 15-49: 571 ,521 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 277,620 (1999 est.)
Military expenditures - dollar figure: $30 million
(1996)
Military expenditures - percent of GDP: 2.5%
(1996)','8b35b86b18a3b229ae3ffd2cce097b6264845408a5824ef28a6fab34be10e69f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69976611cb20fbbd0fa5f07f52137363f6818ae327e59af226e6ac717671865b',1999,'MU','Mauritius','military-and-security',738,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF, Special
Support Units or SSU, and National Coast Guard)
Military manpower - availability:
males age 15-49: 339,218 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 71 ,705 (1 999 est.)
Military expenditures - dollar figure: $1 1 .2 million
(FY97/98)
Military expenditures - percent of GDP: 0.4%
(FY97/98)','590d403e04e3906ded54fb6c4692015766dd9a94c98d33d8e2145752cf6d6bc0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acaab2bd9486780ca6846956f84e3af6e0107af98a4bd2c4a14fe8ec6ffc3835',1999,'YT','Mayotte','military-and-security',745,'Military - note: defense is the responsibility of
France; small contingent of French forces stationed
on the island','c14c91599d57a098f46b075425b91068423931b2fb1849e349c137de62d62892','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb954bd37c841501b6cf05621815cd80f651268d28e6e55743d109c0dede413',1999,'MX','Mexico','military-and-security',751,'Military branches: National Defense Secretariat
(includes Army and Air Force), Navy Secretariat
(includes Naval Air and Marines)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 25,675,266 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 18,675,524 (1999 est.)
Military manpower - reaching military age
annually:
males: 1 ,085,042 (1999 est.)
Military expenditures • dollar figure: $6 billion
(1998)
Military expenditures - percent of GDP: 1 .3%
(1998)
Military branches: Army, Navy, Air and Air Defense
Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 10,417,314 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 8,104,484 (1999 est.)
Military manpower - reaching military age
annually:
males: 334,420 (1999 est.)
Military expenditures - dollar figure: $3.3 billion
(1998)
Military expenditures - percent of GDP: 2.2%
(1998)','1ccb550066d7fe1a0e0b6dde105588aae417d0100523d446e7a640c6c3b5313d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('573cdb2760911f7458567fbccd51955ac1e5e5bb387562f67afad159d86710eb',1999,'CN','China','military-and-security',764,'Military branches: Mongolian People''s Army
(includes Internal Security Forces and Frontier
Guards), Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 702,141 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 457,270 (1999 est.)
Military manpower - reaching military age
annually:
males: 28,61 3 (1999 est.)
Military expenditures - dollar figure: $20.3 million
(1997)
Military expenditures - percent of GDP: 2%
(1997)','c26791a4670f682bcbcf9ee7e61b8a57c549d175f7997e1b5fd4c139fd2e0e89','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dcd7276644e0c1149f80ee598bfa0919a30f20e525b6742cc111783d67f51c2',1999,'MS','Montserrat','military-and-security',770,'Military branches: Police Force
Military - note: defense is the responsibility of the
UK','69819b9c210f94a556583001a0fae7b3b02769888c4aefe36d53828a9456d0ac','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f6cf09dec2a74331d2f46b8c5285d17d259d442d0be95faddc4ca3e59c9f050',1999,'GI','Gibraltar','military-and-security',778,'Military branches: Royal Armed Forces (includes
Army, Navy, Air Force), Gendarmerie, Auxiliary
Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 7,735,597 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,888,595 (1999 est.)
Military manpower - reaching military age
annually:
males: 320,040 (1999 est.)
Military expenditures - dollar figure: $1 .361 1
billion (FY97/98)
Military expenditures - percent of GDP: 3.8%
(FY97/98)','2984a4a7e4945178cc321f367cacdd22755d39514a8c105d6e4e54ec491dbd1f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a47c72aaa935f430fd52d3f15b16d1f928322b94d5749c9f604a47f0029072d0',1999,'NA','Namibia','military-and-security',785,'Military branches: National Defense Force (Army),
Police
Military manpower - availability:
males age 15-49: 380,528 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 228,225 (1999 est.)
Military expenditures - dollar figure: $90 million
(FY97/98)
Military expenditures - percent of GDP: 2.6%
(FY97/98)','d9cf81d0e943a69cb7d190d83e2fe744970bc93a4b6a3169166a3ce6b59051ee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68c5602223c8f1e8d2a0ed47038dfee45af84294ae915f640d1e82426bab4dd2',1999,'NR','Nauru','military-and-security',793,'Military branches: no regular armed forces;
Directorate of the Nauru Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Nauru maintains no defense forces;
under an informal agreement, Australia is responsible
for defense of the island
Military - note: defense is the responsibility of the
US','178a765f7271bdd64240a41d2868cd289cdf721ee6fbe51b04b4b2c5e74ea8c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0845d49efe8ba50617009f73c784bc6a995d7ab0cd8e2e2f935c2c5d5123cd36',1999,'BE','Belgium','military-and-security',807,'Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 4, 1 1 7,376 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 3,595,693 (1999 est.)
Military manpower - reaching military age
annually:
males: 95,368 (1 999 est.)
Military expenditures - dollar figure: $6,604 billion
(FY97)
Military expenditures - percent of GDP: 2.1%
(1995)','84862b3682c2e15cb6493aadb43300afdc0ab77598733cb2bffaec57df38d194','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('962a4b345396c0768a97019ea7fdb1888e0c6a943140c758eae4a14bc3baf51d',1999,'NL','Netherlands','military-and-security',814,'Military branches: Royal Netherlands Navy, Marine
Corps, Royal Netherlands Air Force, National Guard,
Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-47: 53,285 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 29,888 (1999 est.)
Military manpower - reaching military age
annually:
males: 1,457 (1999 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','49387bba0136e1fe38c3f05508a5020e4f9feab2cabbff37bd1a1ddc3cbc3a1f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2c5086d7ffee6829638d185cd176571c5f3bce465db7c88d3a98bad83af04fc',1999,'NZ','New Zealand','military-and-security',822,'Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 943,624 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 793,814 (1999 est.)
Military manpower - reaching military age
annually:
males: 26,046 (1999 est.)
Military expenditures - dollar figure: $562 million
(FY97/98)
Military expenditures - percent of GDP: 1 .05%
(FY97/98)
Military branches: Tonga Defense Services
(includes, Royal Tongan Marines, Tongan Royal
Guards, Maritime Force, Police); note - a new Air
Wing which will be subordinate to the Defense
Ministry is being developed
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: Trinidad and Tobago Defense
Force (includes Ground Forces, Coast Guard, and Air
Wing), Trinidad and Tobago Police Service
Military manpower - availability:
males age 15-49: 312,870 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 223,200 (1999 est.)
Military expenditures - dollar figure: $83 million
(1994)
Military expenditures ■ percent of GDP: NA%
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of','4ce1852ad1a00474f3567ef6a80b51c88cf2b0bd71674ac4e4e34fb6d3b85af1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ace06a18b68de067684a8718aa55a5bac0a06ef6659c95989b5313aeee8e9e3b',1999,'NE','Niger','military-and-security',829,'Military branches: Army, Air Force, National
Gendarmerie, Republican Guard, National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,117,868 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 , 1 43,355 (1 999 est.)
Military manpower - reaching military age
annually:
males: 102,762 (1999 est.)
Military expenditures - dollar figure: $20 million
(FY96/97)
Military expenditures - percent of GDP: 1.1%
(FY96/97)','b317fbaca9b9e5aa87661cb957aef935b71bac6dead26083701e2e449f2f6aef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89bb36898669f61eaa867dc6c2b17803e62151320fe5cbd9a3b2f22bcd356f39',1999,'PA','Panama','military-and-security',852,'Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the National Police, National Maritime
Service, and National Air Service)
Military manpower - availability:
males age 15-49: 746,910 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 51 1 ,866 (1 999 est.)
Military expenditures - dollar figure: $1 32 million
(1997)
Military expenditures - percent of GDP: 1 .6%
(1997)
Military - note: in October 1994, a month after
President PEREZ BALLADARES assumed office,
Panama''s Legislative Assembly approved a
constitutional amendment prohibiting the creation of a
standing military force, but allowing the temporary
establishment of a "special police force" to counter
acts of "external aggression"','af8b84dd550f382d15a5a32c79d83a396c0415d93d303b2d8f9584d23e346f00','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39e9ed650870448c940edb32bc0a19b7628295434ddf167d93282eefc893eb8',1999,'PH','Philippines','military-and-security',859,'Military - note: occupied by China
Military - note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','492077f3ead706f4a4709669d2d084f74ed0d3499e26fc908ca53ebb10aae0a6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8db3cfa826cd6a878d72cdae99eca1ea4cab099b7e4dbc7c0374f8c0c47a845',1999,'AR','Argentina','military-and-security',863,'Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1 ,31 1 ,382 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 947,347 (1999 est.)
Military manpower - reaching military age
annually:
males: 55,065 (1999 est.)
Military expenditures - dollar figure: $125 million
(1998)
Military expenditures - percent of GDP: 1 .4%
(1998)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru), National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 6,913,471 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,657,649 (1999 est.)
Military manpower - reaching military age
annually:
males: 268,624 (1999 est.)
Military expenditures - dollar figure: $91 3 million
(1998); note - may not include off-budget purchases
related to military modernization program
Military expenditures - percent of GDP: 1 .4%
(1998)','f6e41de3d5c9a08aceea3171e1dee8a293bf3a0f52ff5fa8f5572f5b782c2349','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('658e772c38cb38f314e3c9c63de54ab27922d44873cf6c24a8297ea7302e6237',1999,'QA','Qatar','military-and-security',875,'Military branches: Army, Navy, Air Force, Public
Security
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 301,451 (1999 est.)
note: includes non-nationals
Military manpower - fit for military service:
males age 15-49: 158,114 (1999 est.)
Military manpower - reaching military age
annually:
males: 6,125 (1999 est.)
Military expenditures - dollar figure: $940 million
(FY98/99)
Military expenditures - percent of GDP: 9.6%
(FY98/99)','80b0394c4eb91d0a124796f58a062386e43b9cb4b006107880d12e77947021f9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10f4a1b32609085263db9628286c84b2422b00545ed29f519713bca086b9f870',1999,'UA','Ukraine','military-and-security',884,'Military branches: Army, Navy, Air and Air Defense
Forces, Paramilitary Forces, Civil Defense
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 5,876,91 2 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 4,938,953 (1999 est.)
Military manpower - reaching military age
annually:
males: 193,264 (1999 est.)
Military expenditures - dollar figure: $650 million
(1996)
Military expenditures - percent of GDP: 2.5%
(1996)
Military branches: Ground Forces, Navy, Air
Forces, Strategic Rocket Forces
note: the Air Defense Force merged into the Air Force
in March 1998
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 38,665,138 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 30,173,495 (1999 est.)
Military manpower - reaching military age
annually:
males: 1,149,536 (1999 est.)
Military expenditures - dollar figure: $NA
note: the Intelligence Community estimates that
defense spending in Russia fell by about 10% in real
terms in 1996, reducing Russian defense outlays to
about one-sixth of peak Soviet levels in the late 1 980s
(1997 est.)
Military expenditures - percent of GDP: NA%
Military branches: Army, Gendarmerie
Military manpower - availability:
males age 15-49: 1 ,964,1 1 8 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,000,204 (1 999 est.)
Military expenditures - dollar figure: $92 million
(1999)
Military expenditures - percent of GDP: 3.8%
(1999)
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force, Air
Defense Force, Internal Troops, National Guard,
Border Troops
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 12,434,486 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 9,740,684 (1999 est.)
Military manpower - reaching military age
annually:
males: 365,762 (1999 est.)
Military expenditures - dollar figure: $414 million
(1999)
Military expenditures - percent of GDP: 1 .4%
(1999)','e1b48fbad07edb793a9ad885193fd54bfe2a80c57b7666ad3f2d1fa13a340361','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6a2aef658b97e6fcb3f30cfebfe1ded72a7a045e5e9de08b203009eae9da794',1999,'TT','Trinidad and Tobago','military-and-security',894,'Military branches: Royal Saint Kitts and Nevis
Defense Force, Royal Saint Kitts and Nevis Police
Force, Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','4938db2fd778fad17350a83d5a177107ad99c8869cc094e2c365423b16071e66','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27c84d341de5d2824c2fbb3cf101e56e67b7b9da3f2dd29c718c075fde0328c',1999,'MQ','Martinique','military-and-security',902,'Military branches: Royal Saint Lucia Police Force
(includes Special Service Unit), Coast Guard
Military expenditures - dollar figure: $5 million
(1991); note -for police force
Military expenditures - percent of GDP: 2%
(1991)
Military - note: defense is the responsibility of','8d6f0e31c8c340e2f67a1bd6c0014bbc6059cc51bfb5a331add3512bd3fdf394','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ced8628d2a60295037256144b4eea2300dfe45dfa62bf425faa9f67a23fa39e',1999,'IT','Italy','military-and-security',910,'Military branches: Voluntary Military Force, Police
Force
Military expenditures - dollar figure: $3.7 million
(1995)
Military expenditures - percent of GDP: 1 %
(1995)','b35b77d59ebf652eb9335091fd3ab3b7e328abaaca839228b2486f80274ef6b4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1fb27ef1020f54a988ae77b9e599b40e2dbf86dc20a2c6bfe698e88ba61a80',1999,'SA','Saudi Arabia','military-and-security',918,'Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,696,772 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 3,1 71 ,860 (1 999 est.)
Military manpower - reaching military age
annually:
males: 197,386 (1999 est.)
Military expenditures - dollar figure: $18.1 billion
(1997 est.)
Military expenditures - percent of GDP: 12%
(1997 est.)','538263fbc38992faaca79f2c9a3fc15587e988f36ec800ffe79010fc309fc7b6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aff476f95bb09d5f33b4212ef3458ded2c29aca0b1a57eb8a8727b7eb5f7441c',1999,'ME','Montenegro','military-and-security',924,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police (Surete Nationale)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,096,438 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,095,047 (1 999 est.)
Military manpower - reaching military age
annually:
males: 103,348 (1999 est.)
Military branches: Army (including ground forces
with border troops, naval forces, air and air defense
forces)
Military manpower - military age: Serbia - NA
years of age; Montenegro - 19 years of age
Military manpower - availability:
males age 15-49: Serbia - 2,727,292; Montenegro -
187,198 (1999 est.)
Military manpower - fit for military service:
males age 15-49: Serbia - 2,183,534; Montenegro -
150,415(1999 est.)
Military manpower - reaching military age
annually:
males: Serbia - NA; Montenegro - 5,671 (1999 est.)
Military expenditures - dollar figure: $91 1 million
(1999)
Military expenditures - percent of GDP: 6.5%
(1999)','4ae46c21ef319b35d8a093a129fc8eef2fd815822974edd5135edd359bdc53b4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a15246d27d5c695f4c651d4a1010a77a31d8876ee7e503f31f1a48a552d23195',1999,'SC','Seychelles','military-and-security',937,'Military branches: Army, Coast Guard, Marines, air
wing, National Guard, Presidential Protection Unit,
Police Force
Military manpower - availability:
mates age 15-49: 22,420 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,242 (1 999 est.)
Military expenditures - dollar figure: $13.7 million
(1995)
Military expenditures - percent of GDP: NA%','29a55bbf3c082e9d2892bbf34e826e45bc63c64ef05e1aaa87264124aed48473','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2ff68d33a9f26b8e4ee155ddcea451c4b5570da7ee24d7f824cf54c28171607',1999,'SK','Slovakia','military-and-security',952,'Military branches: Army, Air and Air Defense
Forces, Reserve Force (Home Guards), Civil Defense
Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,478,729 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1,130,482 (1999 est.)
Military manpower - reaching military age
annually:
males: 45,91 9 (1999 est.)
Military expenditures - dollar figure: $436 million
(1998)
Military expenditures - percent of GDP: 2.1 %
(1998)','6f91cdaed2634d1d349ef058d48ed2d18c5f0bef17623f0576523503371d2d30','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e475a4e9949165779f30d59bfb776aa6b7fa24c3c3074766d287ad8b5517d62',1999,'SB','Solomon Islands','military-and-security',954,'Military branches: Slovenian Army (includes Air
and Naval Forces)
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 530,182 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 421 ,864 (1999 est.)
Military manpower - reaching military age
annually:
males: 15,294 (1999 est.)
Military expenditures - dollar figure: $272 million
(1998)
Military expenditures - percent of GDP: 1 .8%
(1998)
Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RSIP)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','66874645be95fe024571e9bc264c15bf7b1ab734b197ab704d296f1ebdfac87b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a521fc95328a39324123e0f695a12357e2e475c12240c787d8c3430ca9c22b0',1999,'SO','Somalia','military-and-security',968,'Military branches: NA; note - no functioning central
government military forces; clan militias continue to
battle for control of key economic or political prizes
Military manpower - availability:
males age 15-49: 1 ,730,450 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 962,545 (1999 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: South African National Defense
Force or SANDF (includes Army, Navy, Air Force, and
Medical Services), South African Police Service or
SAPS
447
South Africa (continued)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 1 ,330,692 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 6,889,631 (1999 est.)
Military manpower - reaching military age
annually:
males: 453,610 (1999 est.)
Military expenditures - dollar figure: $2 billion
(FY99/00)
Military expenditures - percent of GDP: 2.2%
(FY95/96)
Military - note: the National Defense Force
continues to integrate former military, black
homelands forces, and ex-opposition forces
Military - note: defense is the responsibility of the
UK','7efa5e58a7098e5e9dd108bfd233d0a1c7252bde6d30bb808550c1786fd19eab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('602769844a89baf2c5fc0e3227a81ec9ce80f0708aa77e053beb6c55f08189c2',1999,'LK','Sri Lanka','military-and-security',977,'Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,223,590 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,062,758 (1999 est.)
Military manpower - reaching military age
annually:
males: 199,196 (1999 est.)
Military expenditures - dollar figure: $719 million
(1998)
Military expenditures - percent of GDP: 4.2%
(1998)
Transnational Issu e s
Disputes - international: none
454','468418ab186fba484b330e0d3f6b1a10e951c0ccae213ca7c5fa76d946a8c97f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d97ea17b9a5527f989f98576b36edf54f7eed56e063af9d66933b512fc98a911',1999,'SD','Sudan','military-and-security',978,'[■ Geograp h y
Location: Northern Africa, bordering the Red Sea,
between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
fofa/:2,505,810sq km
land: 2.376 million sq km
water: 129,810 sq km
Area - comparative: slightly more than one-quarter
the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1,165 km,
Chad 1 ,360 km, Democratic Republic of the Congo
628 km, Egypt 1 ,273 km, Eritrea 605 km, Ethiopia
1 ,606 km, Kenya 232 km, Libya 383 km, Uganda 435
km
Coastline: 853 km
Maritime claims:
contiguous zone: 1 8 nm
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: tropical in south; arid desert in north; rainy
season (April to October)
Terrain: generally flat, featureless plain; mountains
in east and west
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten, mica,
silver, gold
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 1 9%
other: 30% (1993 est.)
Irrigated land: 19,460 sq km (1993 est,)
Natural hazards: dust storms
Environment - current issues: inadequate
supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: largest country in Africa;
dominated by the Nile and its tributaries
Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 7,942,139 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,889,557 (1999 est.)
Military manpower - reaching military age
annually:
males: 379,174 (1999 est.)
Military expenditures - dollar figure: $550 million
(FY98/99)
Military expenditures - percent of GDP: NA%','41869dc0e9e9fbbf5f631db0e2615a18d57e911c07871f7a5d8dc2f1a935dc51','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eea881afeed12ad0e3af86bd4acb2fcc60e06308396dd6b797d6a6c82637b07',1999,'TJ','Tajikistan','military-and-security',997,'Military branches: Army, Air Force, Air Defense
Forces, Presidential National Guard, Security Forces
(internal and border troops)
Military manpower - military age: 1 8 years of age
472
Tajikistan (continued)
Military manpower - availability:
males age 15-49: 1,478,551 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,21 1 ,514 (1 999 est.)
Military manpower - reaching military age
annually:
males: 65,001 (1999 est.)
Military expenditures - dollar figure: $1 9.3 million
(1997)
Military expenditures - percent of GDP: 1 .8%
(1997)
Military branches: Tanzanian People''s Defense
Force or TPDF (includes Army, Navy, and Air Force),
paramilitary Police Field Force Unit, Militia
Military manpower - availability:
males age 15-49: 7,1 19,106 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,120,617 (1999 est.)
Military expenditures - dollar figure: $21 million
(FY98/99)
Military expenditures - percent of GDP: 0.2%
(FY98/99)','58e4b8aee6ad99c38ca21ef9f90ad998edd097888a3d3121499ce498f558b0b5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92ec5d707749c82f0f68dd29fce84ca7ec73e02f5f3461f303c0cc19815268f5',1999,'TH','Thailand','military-and-security',1005,'Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, Paramilitary Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 17,486,014 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 10,536,417 (1999 est.)
Military manpower - reaching military age
annually:
males: 585,562 (1999 est.)
Military expenditures - dollar figure: $1 .95 billion
(FY97/98)
Military expenditures - percent of GDP: 2.5%
(FY97/98)','1de3ade8b384234a33ba11b517ad413de83206e986aab14cb6edc78caa4c271d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e35c00b8f25e60313f007e8662d4a3888992e3baf1f1e71c239b34d4cf9700',1999,'TK','Tokelau','military-and-security',1015,'Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1,102,453 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 578,109 (1999 est.)
Military expenditures - dollar figure: $27 million
(1996)
Military expenditures - percent of GDP: 2%
(1996)
Military - note: defense is the responsibility of New
Zealand','57744719c26ff7a14d275f7c5156753420d65a3db71355a1b21df247fccda7fb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb30cdeb4263bea5045798c7a3993545ad7d6d6a6f6da3e10b79c5e0290bbf61',1999,'TV','Tuvalu','military-and-security',1029,'Military branches: no regular military forces; Police
Force (consists of 56 full- and part-time personnel),
Police Force (includes Maritime Surveillance Unit for
search and rescue missions and surveillance
operations)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Wing
Military manpower - availability:
males age 15-49: 4,81 2,363 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 2,61 1 ,096 (1999 est.)
Military expenditures - dollar figure: $95 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)','dc05fe1fc226dd90983d1da296ed4e8ea695a5bf6e3599c021c62af2de8349ab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c8cc3c4d974e99812d7f9e12752e957d6e1b9d4d5bf2bdf56da7ef3a85907d7',1999,'AE','United Arab Emirates','military-and-security',1036,'Military branches: Army, Navy, Air Force, Air
Defense, paramilitary (includes Federal Police Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 791 ,097 (1999 est.)
note: includes non-nationals
Military manpower - fit for military service:
males age 15-49: 425,248 (1999 est.)
Military manpower - reaching military age
annually:
males: 23,358 (1999 est.)
Military expenditures - dollar figure: $2,118 billion
(1999)
504
United Arab Emirates (continued)
Military expenditures - percent of GDP: 5%
(1999)','6f2015e8a1f20675326a5fec9cbcb35799a9451df7cce20db513a7291e7845b1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aeaccd57db57bbee5e2858365c7a71413ee3a937182ad2a72f1edea1ba10a63',1999,'UY','Uruguay','military-and-security',1045,'Military branches: Army, Navy (includes Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower - availability:
males age 15-49: 806,451 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 653,796 (1999 est.)
Military expenditures - dollar figure: $172 million
(1998)
Military expenditures - percent of GDP: 0.9%
(1998)
Disputes - international: two short sections of the
boundary with Brazil are in dispute - Arroyo de la
Invernada (Arroio Invernada) area of the Rio Cuareim
(Rio Quarai) and the islands at the confluence of the
Rio Cuareim (Rio Quarai) and the Uruguay River
513
Uzbekistan OllllillllH
Military branches: Army, Air and Air Defense
Forces, Security Forces (internal and border troops),
National Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 6,172,436 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 5,012,944 (1999 est.)
Military manpower - reaching military age
annually:
males: 254,1 14 (1999 est.)
Military expenditures - dollar figure: $200 million
(1997)
Military expenditures - percent of GDP: 1 .4%
(1997)','a1e397f4535c61add3475c3905ddd74be0635d7714a0b8096ba7d7d8a056944b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7dabe49c42a8ad7ac9e4b4ad5f3cdc5e7f444a4de143efbe019e6400a79fc05',1999,'VU','Vanuatu','military-and-security',1055,'Military branches: no regular military forces;
Vanuatu Police Force (VPF; includes the paramilitary
Vanuatu Mobile Force or VMF)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of
Cooperation or National Guard (Fuerzas Armadas de
Cooperacion or Guardia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 6,268,982 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 4,522,757 (1999 est.)
Military manpower - reaching military age
annually:
males: 242,362 (1999 est.)
Military expenditures -dollar figure: $1.1 billion
(1998)
Military expenditures - percent of GDP: 1 %
(1998)
Military branches: People''s Army of Vietnam
(PAVN) (includes Ground Forces, Navy, and Air
Force), Coast Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 20,492,806 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 12,933,945 (1999 est.)
Military manpower - reaching military age
annually:
males: 877,714 (1999 est.)
Military expenditures - dollar figure: $650 million
(1997)
Military expenditures - percent of GDP: 9.3%
(1997)','7bf85d92a62ee69425e0a364ff063a793758765d39b912d589ee6a56579a3d1f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2063e419842eb7e37fcb1f8b9012f21bb3ea2b90742ad5574a2ec0bf01e78be',1999,'ZM','Zambia','military-and-security',1071,'Military branches: Army, Navy, Air Force, Air
Defense Forces, paramilitary (includes Police)
Military branches: Army, Air Force, paramilitary
forces, Police
Military manpower - availability:
males age 15-49: 2,102,167 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,1 13,174 (1999 est.)
Military expenditures - dollar figure: $76 million
(1997)
Military expenditures - percent of GDP: 1 .8%
(1997)','48b55db20db1488186aeff44c3236b2ef4def62e8c4f2221ade766929e81bde8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10d616c63ef55d2412abf6892146cd5785da362725e63c0c6ab3e6edd977da7a',1999,'ZW','Zimbabwe','military-and-security',12,'Military branches: NA; note--the military does not exist on a
national basis; some elements of the former Army, Air and Air
Defense Forces, National Guard, Border Guard Forces, National Police
Force (Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower--military age: 22 years of age
Military manpower--availability:
males age 15-49: 6,326,135 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,392,336 (1999 est.)
Military manpower--reaching military age annually:
males: 248,320 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air and Air Defense Forces,
Interior Ministry Troops, Border Guards
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 763,949 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 622,013 (1999 est.)
Military manpower--reaching military age annually:
males: 32,954 (1999 est.)
Military expenditures--dollar figure: $60 million (1998)
Military expenditures--percent of GDP: 2% (1998)
Military branches: National Popular Army, Navy, Air Force,
Territorial Air Defense, National Gendarmerie
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 8,237,682 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 5,046,931 (1999 est.)
Military manpower--reaching military age annually:
males: 359,592 (1999 est.)
Military expenditures--dollar figure: $1.3 billion (1994)
Military expenditures--percent of GDP: 2.7% (1994)','3059d8aa41948797897a69517785c108f39b5de30ecd3d3db69fab11dfb87b14','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa6a426b5c382c201f50eb2de2aa8b72b6ec05ad7ca08445fed23d6b24837e2',1999,'LY','Libya','military-and-security',22,'Military--note: defense is the responsibility of the US
Military--note: defense is the responsibility of France and Spain
Military branches: Army, Navy, Air and Air Defense Forces,
National Police Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,544,203 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,280,377 (1999 est.)
Military manpower--reaching military age annually:
males: 111,168 (1999 est.)
Military expenditures--dollar figure: $1 billion (FY97/98)
Military expenditures--percent of GDP: 25% (FY97/98)
Military--note: defense is the responsibility of the UK
Military--note: the Antarctic Treaty prohibits any measures of a
military nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use of military
personnel or equipment for scientific research or for any other
peaceful purposes
Military branches: Royal Antigua and Barbuda Defense Force, Royal
Antigua and Barbuda Police Force (includes Coast Guard)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Argentine Army, Navy of the Argentine Republic
(includes Naval Aviation, Marines, and Coast Guard), Argentine Air
Force, National Gendarmerie, National Aeronautical Police Force
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 9,169,681 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 7,435,551 (1999 est.)
Military manpower--reaching military age annually:
males: 343,038 (1999 est.)
Military expenditures--dollar figure: $4.6 billion (1998)
Military expenditures--percent of GDP: 1.4% (1998)','8ad9a96c2106ec50b1ca5cadf259fa8920b59016368bbe3b59359e8ac246f674','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7260bc7ab2665c15bd9fc084bee90147b9b15ba7d6d80603c8a041d895ff5820',1999,'AM','Armenia','military-and-security',29,'Military branches: Army, Air Force and Air Defense Aviation, Air
Defense Force, Security Forces (internal and border troops)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 922,124 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 732,495 (1999 est.)
Military manpower--reaching military age annually:
males: 32,052 (1999 est.)
Military expenditures--dollar figure: $72.1 million (1999)
Military expenditures--percent of GDP: 4% (1999)
Military--note: defense is the responsibility of the Kingdom of
the Netherlands
Military--note: defense is the responsibility of Australia;
periodic visits by the Royal Australian Navy and Royal Australian
Air Force
Military branches: Australian Army, Royal Australian Navy, Royal
Australian Air Force
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 4,882,693 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,212,272 (1999 est.)
Military manpower--reaching military age annually:
males: 130,570 (1999 est.)
Military expenditures--dollar figure: $6.9 billion (FY97/98)
Military expenditures--percent of GDP: 1.9% (FY97/98)
Military branches: Army (includes Flying Division)
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 2,091,902 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,735,469 (1999 est.)
Military manpower--reaching military age annually:
males: 48,872 (1999 est.)
Military expenditures--dollar figure: $1.8 billion (1999 est.)
Military expenditures--percent of GDP: 0.82% (1999 est.)
Military branches: Army, Navy, Air and Air Defense Forces, Border
Guards
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,041,863 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,639,144 (1999 est.)
Military manpower--reaching military age annually:
males: 73,486 (1999 est.)
Military expenditures--dollar figure: $121 million (1999)
Military expenditures--percent of GDP: 2.6% (1999)
Military branches: Royal Bahamas Defense Force (Coast Guard
only), Royal Bahamas Police Force
Military expenditures--dollar figure: $20 million (FY95/96)
Military expenditures--percent of GDP: NA%','6d8ea4272dd1e4c0e17de269469d51f942a7b3072e7b3f98163bc012a739b919','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79058ac23d1ebbdeb7ca45fa70a077614c131d574f0856ffaec999a2f3130019',1999,'SA','Saudi Arabia','military-and-security',41,'Military branches: Ground Force, Navy, Air Force, Coast Guard,
Police Force
Military manpower--military age: 15 years of age
Military manpower--availability:
males age 15-49: 220,670 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 121,451 (1999 est.)
Military manpower--reaching military age annually:
males: NA
Military expenditures--dollar figure: $276.9 million (1994)
Military expenditures--percent of GDP: 4.5% (1998)
Military--note: defense is the responsibility of the US; visited
annually by the US Coast Guard
Military branches: Army, Navy, Air Force, paramilitary forces
(includes Bangladesh Rifles, Bangladesh Ansars, Village Defense
Parties, National Cadet Corps)
Military manpower--availability:
males age 15-49: 33,374,195 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 19,772,013 (1999 est.)
Military expenditures--dollar figure: $559 million (FY96/97)
Military expenditures--percent of GDP: 1.8% (FY96/97)
Military branches: Royal Barbados Defense Force (includes Ground
Forces and Coast Guard), Royal Barbados Police Force
Military manpower--availability:
males age 15-49: 72,111 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 49,600 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of France
Military branches: Army, Air Force, Air Defense Force, Interior
Ministry Troops, Border Guards
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,700,034 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,115,121 (1999 est.)
Military manpower--reaching military age annually:
males: 79,905 (1999 est.)
Military expenditures--dollar figure: $100 million (1998)
Military expenditures--percent of GDP: 2% (1998)
Military branches: Army, Navy, Air Force, National Gendarmerie
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 2,537,544 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,098,883 (1999 est.)
Military manpower--reaching military age annually:
males: 64,180 (1999 est.)
Military expenditures--dollar figure: $4.6 billion (1995)
Military expenditures--percent of GDP: 1.7% (1995)
Military branches: Belize Defense Force (includes Ground Forces,
Maritime Wing, Air Wing, and Volunteer Guard), Belize National Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 58,201 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 34,531 (1999 est.)
Military manpower--reaching military age annually:
males: 2,619 (1999 est.)
Military expenditures--dollar figure: $15 million (FY97/98)
Military expenditures--percent of GDP: 2% (FY97/98)
Military branches: Armed Forces (includes Army, Navy, Air Force),
National Gendarmerie
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,363,878
females age 15-49: 1,425,987 (1999 est.)
note: both sexes are liable for military service
Military manpower--fit for military service:
males age 15-49: 697,715
females age 15-49: 722,323 (1999 est.)
Military manpower--reaching military age annually:
males: 67,622
females: 67,238 (1999 est.)
Military expenditures--dollar figure: $27 million (1996)
Military expenditures--percent of GDP: 1.2% (1996)
Military branches: Bermuda Regiment, Bermuda Police Force,
Bermuda Reserve Constabulary
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of the UK
Military branches: Royal Bhutan Army, Palace Guard, Militia,
Royal Police Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 477,944 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 254,992 (1999 est.)
Military manpower--reaching military age annually:
males: 19,424 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air Force, Public Security
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 301,451 (1999 est.)
note: includes non-nationals
Military manpower--fit for military service:
males age 15-49: 158,114 (1999 est.)
Military manpower--reaching military age annually:
males: 6,125 (1999 est.)
Military expenditures--dollar figure: $940 million (FY98/99)
Military expenditures--percent of GDP: 9.6% (FY98/99)','112f2098d660cc738c4f233c9c2e97ba23a327a64a4e0cd0dac200cb40bfd7cb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('837c447fbae3d5944549909d6b1b569e58e8400ea144b3d67c6c3f2dcf72f67c',1999,'PY','Paraguay','military-and-security',45,'Military branches: Army (Ejercito Boliviano), Navy (Fuerza Naval
Boliviana, includes Marines), Air Force (Fuerza Aerea Boliviana),
National Police Force (Policia Nacional de Bolivia)
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 1,908,454 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,241,311 (1999 est.)
Military manpower--reaching military age annually:
males: 84,481 (1999 est.)
Military expenditures--dollar figure: $154 million (1998)
Military expenditures--percent of GDP: 1.8% (1998)','63865722ff73f5d6642eff049d09fe8fba6c3883be99f080f7d03fb5d8a4649b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2a661ffea84955fbe179057578c2eff0756fdd7a7dd463ab54416be7793625b',1999,'HR','Croatia','military-and-security',54,'Military branches: Federation Army or VF (composed of both
Croatian and Bosnian Muslim elements), Army of the Serb Republic
(composed of Bosnian Serb elements); note--within both of these
forces air and air defense are subordinate commands
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 951,541 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 764,992 (1999 est.)
Military manpower--reaching military age annually:
males: 28,438 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Botswana Defense Force (includes Army and Air
Wing), Botswana National Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 344,587 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 182,279 (1999 est.)
Military manpower--reaching military age annually:
males: 18,654 (1999 est.)
Military expenditures--dollar figure: $61 million (FY99/00)
Military expenditures--percent of GDP: 1.2% (FY99/00)
Military--note: defense is the responsibility of Norway
Military branches: Brazilian Army, Brazilian Navy (includes naval
air and marines), Brazilian Air Force, Federal Police (paramilitary)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 47,230,426 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 31,723,597 (1999 est.)
Military manpower--reaching military age annually:
males: 1,841,858 (1999 est.)
Military expenditures--dollar figure: $14.7 billion (1998)
Military expenditures--percent of GDP: 1.9% (1998)
Military--note: defense is the responsibility of the UK; the US
lease on Diego Garcia expires in 2016','3926bcde914062a9a09a56df783226b46ec637e8652ad95b5ec037b71ecd9574','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d70cd628d5b6ca35c8f953cbdf9982bc60eb8c96a0d8b020bcebe999ab99b2',1999,'PR','Puerto Rico','military-and-security',63,'Military--note: defense is the responsibility of the UK
Military branches: Police Force
Military--note: defense is the responsibility of the UK
Military branches: Royal Armed Forces (includes Army, Navy, Air
Force), Gendarmerie, Auxiliary Forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 7,735,597 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,888,595 (1999 est.)
Military manpower--reaching military age annually:
males: 320,040 (1999 est.)
Military expenditures--dollar figure: $1.3611 billion (FY97/98)
Military expenditures--percent of GDP: 3.8% (FY97/98)
Military branches: Army, Naval Command, Air and Air Defense
Forces, Militia
Military manpower--availability:
males age 15-49: 4,385,483 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,526,447 (1999 est.)
Military expenditures--dollar figure: $72 million (FY97)
Military expenditures--percent of GDP: 4.7% (1997)
Military branches: National Defense Force (Army), Police
Military manpower--availability:
males age 15-49: 380,528 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 228,225 (1999 est.)
Military expenditures--dollar figure: $90 million (FY97/98)
Military expenditures--percent of GDP: 2.6% (FY97/98)
Military branches: no regular armed forces; Directorate of the
Nauru Police Force
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: Nauru maintains no defense forces; under an
informal agreement, Australia is responsible for defense of the
island
Military--note: defense is the responsibility of the US
Military branches: Royal Nepalese Army, Royal Nepalese Army Air
Service, Nepalese Police Force
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 5,924,732 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,079,569 (1999 est.)
Military manpower--reaching military age annually:
males: 281,658 (1999 est.)
Military expenditures--dollar figure: $44 million (FY96/97)
Military expenditures--percent of GDP: 0.9% (FY96/97)
Military branches: Royal Netherlands Army, Royal Netherlands Navy
(includes Naval Air Service and Marine Corps), Royal Netherlands Air
Force, Royal Constabulary
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 4,117,376 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,595,693 (1999 est.)
Military manpower--reaching military age annually:
males: 95,368 (1999 est.)
Military expenditures--dollar figure: $6.604 billion (FY97)
Military expenditures--percent of GDP: 2.1% (1995)
Military branches: Royal Netherlands Navy, Marine Corps, Royal
Netherlands Air Force, National Guard, Police Force
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-47: 53,285 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 29,888 (1999 est.)
Military manpower--reaching military age annually:
males: 1,457 (1999 est.)
Military--note: defense is the responsibility of the Kingdom of
the Netherlands
Military branches: Department of the Army, Department of the Navy
(includes Marine Corps), Department of the Air Force
note: the Coast Guard falls under the Department of Transportation,
but in wartime reports to the Department of the Navy
Military manpower--military age: 18 years of age
Military manpower--fit for military service:
males age 15-49: NA
Military expenditures--dollar figure: $267.2 billion (1997 est.)
Military expenditures--percent of GDP: 3.4% (1997 est.)','46df21809f139fb2c5ca092c7f30c30982205920253892107a20f10dd185829a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee585a1e8d7d029ee1fc39a7a8ff066d966627105f69970aceab87df0d125c6c',1999,'MY','Malaysia','military-and-security',74,'Military branches: Land Forces, Navy, Air Force, Royal Brunei
Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 88,628 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 51,270 (1999 est.)
Military manpower--reaching military age annually:
males: 3,078 (1999 est.)
Military expenditures--dollar figure: $343 million (1997)
Military expenditures--percent of GDP: 6% (1997)
Military branches: Army, Navy, Air and Air Defense Forces, Border
Troops, Internal Troops
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 2,028,930 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,693,597 (1999 est.)
Military manpower--reaching military age annually:
males: 59,887 (1999 est.)
Military expenditures--dollar figure: $226.8 million (1997)
Military expenditures--percent of GDP: 2.2% (1997)
Military branches: Army, Air Force, National Gendarmerie,
National Police, People''s Militia
Military manpower--availability:
males age 15-49: 2,399,724 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,230,713 (1999 est.)
Military expenditures--dollar figure: $66 million (1996)
Military expenditures--percent of GDP: 2% (1996)
Military branches: Army, Navy, Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 12,475,987
females age 15-49: 12,224,947 (1999 est.)
note: both sexes liable for military service
Military manpower--fit for military service:
males age 15-49: 6,660,309
females age 15-49: 6,510,730 (1999 est.)
Military manpower--reaching military age annually:
males: 496,912
females: 477,803 (1999 est.)
Military expenditures--dollar figure: $3.904 billion (FY97/98)
Military expenditures--percent of GDP: 2.1% (FY97/98)
Military branches: Army (includes naval and air units),
paramilitary Gendarmerie
Military manpower--military age: 16 years of age
Military manpower--availability:
males age 15-49: 1,260,909 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 658,115 (1999 est.)
Military manpower--reaching military age annually:
males: 73,271 (1999 est.)
Military expenditures--dollar figure: $25 million (1993)
Military expenditures--percent of GDP: 2.6% (1993)
Military branches: Royal Cambodian Armed Forces (RCAF)--created in
1993 by the merger of the Cambodian People''s Armed Forces and the
two noncommunist resistance armies
note: there are also resistance forces comprised of the Khmer Rouge
(also known as the National United Army or NUA) and a separate
royalist resistance movement
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,562,112 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,428,523 (1999 est.)
Military manpower--reaching military age annually:
males: 119,839 (1999 est.)
Military expenditures--dollar figure: $85.3 million (1998)
Military expenditures--percent of GDP: 2.4% (1998)
Military branches: Army, Navy (includes Naval Infantry), Air
Force, National Gendarmerie, Presidential Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 3,388,643 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,716,285 (1999 est.)
Military manpower--reaching military age annually:
males: 165,670 (1999 est.)
Military expenditures--dollar figure: $155 million (FY98/99)
Military expenditures--percent of GDP: 1.4% (FY98/99)
Military branches: Canadian Armed Forces (includes Land Forces
Command or LC, Maritime Command or MC, Air Command or AC,
Communications Command or CC, Training Command or TC), Royal
Canadian Mounted Police (RCMP)
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 8,243,859 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 7,061,937 (1999 est.)
Military manpower--reaching military age annually:
males: 210,884 (1999 est.)
Military expenditures--dollar figure: $7.1 billion (FY97/98)
Military expenditures--percent of GDP: 1.2% (FY97/98)
Military branches: Armed Forces (AF) (includes all armed force
elements, both ground and naval)
Military manpower--availability:
males age 15-49: 84,018 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 47,672 (1999 est.)
Military expenditures--dollar figure: $3.8 million (1996)
Military expenditures--percent of GDP: 1.8% (1996)
Military branches: Royal Cayman Islands Police Force (RCIPF)
Military--note: defense is the responsibility of the UK
Military branches: Papua New Guinea Defense Force (includes
Ground, Naval, and Air Forces, and Special Forces Unit)
Military manpower--availability:
males age 15-49: 1,238,683 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 687,978 (1999 est.)
Military expenditures--dollar figure: $41.5 million (1998)
Military expenditures--percent of GDP: 1% (1998)
Military--note: occupied by China','ab206c2f7aa4f89c2a84039209d2ef817db4b13e603e9e9d48bacbbcc97afeea','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('420745e3a00f05308a75b611d90333163d640b873310439db8fdff5e0f09ba44',1999,'CG','Congo','military-and-security',86,'Military branches: Central African Armed Forces (includes
Republican Guard and Air Force), Presidential Guard, National
Gendarmerie, Police Force
Military manpower--availability:
males age 15-49: 782,678 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 409,044 (1999 est.)
Military expenditures--dollar figure: $29 million (1996)
Military expenditures--percent of GDP: 2.2% (1996)
Military branches: Armed Forces (includes Ground Force, Air
Force, and Gendarmerie), Republican Guard, Rapid Intervention Force,
Police
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 1,689,112 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 875,541 (1999 est.)
Military manpower--reaching military age annually:
males: 70,464 (1999 est.)
Military expenditures--dollar figure: $39 million (1996)
Military expenditures--percent of GDP: 3.5% (1996)
Military branches: Army of the Nation, National Navy (includes
Naval Air, Coast Guard, and Marines), Air Force of the Nation,
Carabineros of Chile (National Police), Investigations Police
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 3,968,176 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,943,206 (1999 est.)
Military manpower--reaching military age annually:
males: 132,202 (1999 est.)
Military expenditures--dollar figure: $2.12 billion (1998);
note--includes earnings from CODELCO Company and costs of pensions;
does not include funding for the National Police (Carabineros) and
Investigations Police
Military expenditures--percent of GDP: 2.79% (1998)
Military--note: defense is the responsibility of the UK
Military branches: Royal Saint Kitts and Nevis Defense Force,
Royal Saint Kitts and Nevis Police Force, Coast Guard
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Royal Saint Lucia Police Force (includes
Special Service Unit), Coast Guard
Military expenditures--dollar figure: $5 million (1991); note?for
police force
Military expenditures--percent of GDP: 2% (1991)
Military branches: Army, Navy, Air Force, Air Defense Force,
Internal Troops, National Guard, Border Troops
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 12,434,486 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 9,740,684 (1999 est.)
Military manpower--reaching military age annually:
males: 365,762 (1999 est.)
Military expenditures--dollar figure: $414 million (1999)
Military expenditures--percent of GDP: 1.4% (1999)
Military branches: Army, Navy, Air Force, Air Defense,
paramilitary (includes Federal Police Force)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 791,097 (1999 est.)
note: includes non-nationals
Military manpower--fit for military service:
males age 15-49: 425,248 (1999 est.)
Military manpower--reaching military age annually:
males: 23,358 (1999 est.)
Military expenditures--dollar figure: $2.118 billion (1999)
Military expenditures--percent of GDP: 5% (1999)','d51a79498d19d2c027cc2197d992891a761507b7bf45f24d4a27b096037de2c0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19e6e3f2dc11d63f67441b0b05c881bfb571814aa49b37197822f7b8a4c1ad7f',1999,'DE','Germany','military-and-security',91,'Military branches: People''s Liberation Army (PLA), which includes
the Ground Forces, Navy (includes Marines and Naval Aviation), Air
Force, Second Artillery Corps (the strategic missile force),
People''s Armed Police (internal security troops, nominally
subordinate to Ministry of Public Security, but included by the
Chinese as part of the "armed forces" and considered to be an
adjunct to the PLA in wartime)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 361,267,706 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 198,398,601 (1999 est.)
Military manpower--reaching military age annually:
males: 10,273,696 (1999 est.)
Military expenditures--dollar figure: $12.608 billion (FY99);
note-Western analysts believe that China''s real defense spending is
several times higher than the official figure because several
significant items are funded elsewhere
Military expenditures--percent of GDP: NA%','a9f1b61f06996373da0879816711ef1b8b188ab20998caafa7887825013a6863','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f88a943d86683f6e357bc95c450ec7193d97bb2f9f4fb74c2e8824cb20a838f8',1999,'AU','Australia','military-and-security',111,'Military--note: defense is the responsibility of Australia
Military--note: defense is the responsibility of France
Military--note: defense is the responsibility of Australia
Military branches: Army (Ejercito Nacional), Navy (Armada
Nacional, includes Marines and Coast Guard), Air Force (Fuerza Aerea
Colombiana), National Police (Policia Nacional)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 10,418,211 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 6,980,700 (1999 est.)
Military manpower--reaching military age annually:
males: 360,820 (1999 est.)
Military expenditures--dollar figure: $4 billion (1998)
Military expenditures--percent of GDP: 4.2% (1998)
Military--note: defense is the responsibility of Australia;
visited regularly by the Royal Australian Navy; Australia has
control over the activities of visitors
Military branches: Coast Guard, Air Section, Ministry of Public
Security Force (Fuerza Publica); note--during 1996, the Ministry of
Public Security reorganized and eliminated the Civil Guard, Rural
Assistance Guard, and Frontier Guards as separate entities; they are
now under the Ministry and operate on a geographic command basis
performing ground security, law enforcement, counternarcotics, and
national security (border patrol) functions; the constitution
prohibits armed forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 988,887 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 662,827 (1999 est.)
Military manpower--reaching military age annually:
males: 36,751 (1999 est.)
Military expenditures--dollar figure: $55 million (1995)
Military expenditures--percent of GDP: 2% (1995)
Military branches: Army, Navy, Air Force, paramilitary
Gendarmerie, Republican Guard (includes Presidential Guard),
Sapeur-Pompier (Military Fire Group)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 3,677,627 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,917,433 (1999 est.)
Military manpower--reaching military age annually:
males: 178,860 (1999 est.)
Military expenditures--dollar figure: $94 million (1998)
Military expenditures--percent of GDP: 0.9% (1996)
Military branches: Ground Forces, Naval Forces, Air and Air
Defense Forces, Frontier Guard, Home Guard
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 1,188,898 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 943,719 (1999 est.)
Military manpower--reaching military age annually:
males: 33,722 (1999 est.)
Military expenditures--dollar figure: $950 million (1999)
Military expenditures--percent of GDP: 5% (1999)
Military branches: Revolutionary Armed Forces (FAR) includes
ground forces, Revolutionary Navy (MGR), Air and Air Defense Force
(DAAFAR), Territorial Troops Militia (MTT), and Youth Labor Army
(EJT); the Border Guard (TGF) is controlled by the Interior Ministry
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 3,068,140
females age 15-49: 3,014,686 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,900,893
females age 15-49: 1,862,411 (1999 est.)
Military manpower--reaching military age annually:
males: 76,328
females: 72,551 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: roughly 4% (1995 est.)
Military--note: Moscow, for decades the key military supporter and
supplier of Cuba, cut off almost all military aid by 1993
Military branches: Greek Cypriot area: Greek Cypriot National
Guard (GCNG; includes air and naval elements), Hellenic Forces
Regiment on Cyprus (ELDYK), Greek Cypriot Police; Turkish Cypriot
area: Turkish Cypriot Security Force (TCSF), Turkish Forces Regiment
on Cyprus (KTKA), Turkish mainland army units
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 194,337 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 133,559 (1999 est.)
Military manpower--reaching military age annually:
males: 6,410 (1999 est.)
Military expenditures--dollar figure: $405 million (1996)
Military expenditures--percent of GDP: 5.4% (1996)
Military branches: Army, Air and Air Defense Forces, Civil
Defense, Railroad Units
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,684,817 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,046,079 (1999 est.)
Military manpower--reaching military age annually:
males: 73,072 (1999 est.)
Military expenditures--dollar figure: $1.1 billion (1998)
Military expenditures--percent of GDP: 1.8% (1998)
Military branches: Royal Danish Army, Royal Danish Navy, Royal
Danish Air Force, Home Guard
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 1,316,584 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,129,870 (1999 est.)
Military manpower--reaching military age annually:
males: 32,130 (1999 est.)
Military expenditures--dollar figure: $2.5 billion (1999)
Military expenditures--percent of GDP: 1.6% (1999)
Military branches: Djibouti National Army (includes Navy and Air
Force)
Military manpower--availability:
males age 15-49: 105,075 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 61,712 (1999 est.)
Military expenditures--dollar figure: $22.5 million (1997)
Military expenditures--percent of GDP: 4.5% (1997)
Military branches: Army, Navy, Air Force, National Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 61,087,521 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 35,804,125 (1999 est.)
Military manpower--reaching military age annually:
males: 2,268,638 (1999 est.)
Military expenditures--dollar figure: $959.7 million (FY97/98)
Military expenditures--percent of GDP: 1% (FY97/98)
Military branches: Islamic Republic of Iran regular forces
(includes Ground Forces, Navy, Air and Air Defense Forces),
Revolutionary Guards (includes Ground, Air, Navy, Qods, and
Basij-mobilization-forces), Law Enforcement Forces
Military manpower--military age: 21 years of age
Military manpower--availability:
males age 15-49: 17,203,360 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 10,217,269 (1999 est.)
Military manpower--reaching military age annually:
males: 767,152 (1999 est.)
Military expenditures--dollar figure: $5.787 billion (FY98/99)
Military expenditures--percent of GDP: 2.9% (FY98/99)
Military branches: Army, Republican Guard and Special Republican
Guard, Navy, Air Force, Air Defense Force, Border Guard Force,
Internal Security Forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 5,459,998 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,058,098 (1999 est.)
Military manpower--reaching military age annually:
males: 259,915 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army (includes Naval Service and Air Corps),
National Police (Garda Siochana)
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 974,226 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 790,155 (1999 est.)
Military manpower--reaching military age annually:
males: 33,810 (1999 est.)
Military expenditures--dollar figure: $771 million (1997)
Military expenditures--percent of GDP: 1% (1997)
Military branches: Israel Defense Forces (includes ground, naval,
and air components), Pioneer Fighting Youth (Nahal), Frontier Guard,
Chen (women); note--historically there have been no separate Israeli
military services
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,474,046
females age 15-49: 1,439,569 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,206,320
females age 15-49: 1,173,818 (1999 est.)
Military manpower--reaching military age annually:
males: 50,737
females: 48,546 (1999 est.)
Military expenditures--dollar figure: $8.7 billion (1999)
Military expenditures--percent of GDP: 9.5% (1999)
Military branches: Army, Navy, Air Force, Carabinieri
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 14,142,889 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 12,200,780 (1999 est.)
Military manpower--reaching military age annually:
males: 315,952 (1999 est.)
Military expenditures--dollar figure: $21.095 billion (FY97)
Military expenditures--percent of GDP: 1.9% (1995)
Military branches: Jamaica Defense Force (includes Ground Forces,
Coast Guard, and Air Wing), Jamaica Constabulary Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 715,260 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 503,667 (1999 est.)
Military manpower--reaching military age annually:
males: 26,108 (1999 est.)
Military expenditures--dollar figure: $47.9 million (FY97/98 est.)
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of Norway
Military branches: Japan Ground Self-Defense Force (Army), Japan
Maritime Self-Defense Force (Navy), Japan Air Self-Defense Force
(Air Force)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 30,646,516 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 26,438,961 (1999 est.)
Military manpower--reaching military age annually:
males: 784,658 (1999 est.)
Military expenditures--dollar figure: $42.9 billion (FY98/99)
Military expenditures--percent of GDP: 0.9% (FY98/99)
Military--note: defense is the responsibility of the US; visited
annually by the US Coast Guard
Military branches: French Armed Forces (Army, Navy, Air Force,
Gendarmerie); Police Force
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of France
Military branches: New Zealand Army, Royal New Zealand Navy,
Royal New Zealand Air Force
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 943,624 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 793,814 (1999 est.)
Military manpower--reaching military age annually:
males: 26,046 (1999 est.)
Military expenditures--dollar figure: $562 million (FY97/98)
Military expenditures--percent of GDP: 1.05% (FY97/98)
Military branches: Ground Forces, Navy, Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,108,146 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 681,495 (1999 est.)
Military manpower--reaching military age annually:
males: 53,508 (1999 est.)
Military expenditures--dollar figure: $26 million (1998)
Military expenditures--percent of GDP: 1.2% (1998)
Military--note: defense is the responsibility of Australia
Military--note: defense is the responsibility of the US
Military branches: Norwegian Army, Royal Norwegian Navy (includes
Coast Artillery and Coast Guard), Royal Norwegian Air Force, Home
Guard
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 1,103,738 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 917,244 (1999 est.)
Military manpower--reaching military age annually:
males: 27,448 (1999 est.)
Military expenditures--dollar figure: NA
Military expenditures--percent of GDP: 2.2% (1998)
Military branches: Army, Navy, Air Force, paramilitary (includes
Royal Oman Police)
Military manpower--military age: 14 years of age
Military manpower--availability:
males age 15-49: 752,637 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 420,361 (1999 est.)
Military manpower--reaching military age annually:
males: NA
Military expenditures--dollar figure: $1.672 billion (1998)
Military expenditures--percent of GDP: 11.1% (1998)
Military branches: Army, Navy, Air Force, Civil Armed Forces,
National Guard
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 33,496,712 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 20,519,762 (1999 est.)
Military manpower--reaching military age annually:
males: 1,553,310 (1999 est.)
Military expenditures--dollar figure: $2.48 billion (FY98/99)
Military expenditures--percent of GDP: 4.4% (FY98/99)
Military branches: NA
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of the US; under a
Compact of Free Association between Palau and the US, the US
military is granted access to the islands for 50 years
Military--note: defense is the responsibility of the US
Military branches: an amendment to the Constitution abolished the
armed forces, but there are security forces (Panamanian Public
Forces or PPF includes the National Police, National Maritime
Service, and National Air Service)
Military manpower--availability:
males age 15-49: 746,910 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 511,866 (1999 est.)
Military expenditures--dollar figure: $132 million (1997)
Military expenditures--percent of GDP: 1.6% (1997)
Military--note: in October 1994, a month after President PEREZ
BALLADARES assumed office, Panama''s Legislative Assembly approved a
constitutional amendment prohibiting the creation of a standing
military force, but allowing the temporary establishment of a
"special police force" to counter acts of "external aggression"
Military branches: no regular military forces; Police Force
(consists of 56 full- and part-time personnel), Police Force
(includes Maritime Surveillance Unit for search and rescue missions
and surveillance operations)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air Wing
Military manpower--availability:
males age 15-49: 4,812,363 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,611,096 (1999 est.)
Military expenditures--dollar figure: $95 million (FY98/99)
Military expenditures--percent of GDP: 1.9% (FY98/99)','d4d8bf6b8efc94779d5fc88db79ae7acf70b72076969d1f3978bc5c8a7f16fe2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54521090b8d83e005f74f784692d4d0b7d683fe7f6cbc8a2e641ed89e2a5a5a7',1999,'KM','Comoros','military-and-security',123,'Military branches: Comoran Security Force
Military manpower--availability:
males age 15-49: 132,969 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 79,224 (1999 est.)
Military expenditures--dollar figure: $3 million (1994 est.)
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air Force, Presidential Security
Group, Gendarmerie
Military manpower--availability:
males age 15-49: 10,874,744 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 5,536,277 (1999 est.)
Military expenditures--dollar figure: $250 million (1997)
Military expenditures--percent of GDP: 4.6% (1997)','c240d433951d3d000ee35870c2b8853aba12726655a9b19fddf90ce27bf20e3d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a91d7558c1523bda475ea85b7c426de9948c1994d03c15e2fc49a8125b09db',1999,'ET','Ethiopia','military-and-security',130,'Military branches: NA
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 641,543 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 326,834 (1999 est.)
Military manpower--reaching military age annually:
males: 28,976 (1999 est.)
Military expenditures--dollar figure: $110 million (1993)
Military expenditures--percent of GDP: 3.8% (1993)
Military branches: Army, Air Force, Gendarmerie, Republican
Guard, National Guard, National Police (Surete Nationale)
Military manpower--availability:
males age 15-49: 2,128,375 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,218,732 (1999 est.)
Military expenditures--dollar figure: $49 million (1996)
Military expenditures--percent of GDP: 2% (1996)','ddafc390274643710fa2df1d358d97400abea4e6785a7aa8d735bf0753168747','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9b186fa05c818089a3378fae2417fcb900943a4f6954ccede3f61a91dd050ee',1999,'NZ','New Zealand','military-and-security',140,'Military--note: defense is the responsibility of New Zealand, in
consultation with the Cook Islands and at its request','065c8572cab63dc1d7b754eaa0a2ac1151e1da901c522095602cee1bda2d08cd','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb1cc682ea13a694c47e0fde24960e3d57e3ab9b023b5679e50161c223f4875d',1999,'TT','Trinidad and Tobago','military-and-security',150,'Military branches: Commonwealth of Dominica Police Force
(includes Special Service Unit, Coast Guard)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air Force, National Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,156,827 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,355,342 (1999 est.)
Military manpower--reaching military age annually:
males: 82,902 (1999 est.)
Military expenditures--dollar figure: $180 million (1998)
Military expenditures--percent of GDP: 1.1% (1998)
Military branches: Army (Ejercito Ecuatoriano), Navy (Armada
Ecuatoriana, includes Marines), Air Force (Fuerza Aerea
Ecuatoriana), National Police
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 3,259,534 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,199,704 (1999 est.)
Military manpower--reaching military age annually:
males: 130,208 (1999 est.)
Military expenditures--dollar figure: $720 million (1998)
Military expenditures--percent of GDP: 3.4% (1998)
Military branches: Royal Saint Vincent and the Grenadines Police
Force (includes Special Service Unit), Coast Guard
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: no regular armed services; Samoa Police Force
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: Samoa has no formal defense structure or regular
armed forces; informal defense ties exist with NZ, which is required
to consider any Samoan request for assistance under the 1962 Treaty
of Friendship
Military branches: Voluntary Military Force, Police Force
Military expenditures--dollar figure: $3.7 million (1995)
Military expenditures--percent of GDP: 1% (1995)
Military branches: Army, Navy, Security Police
Military manpower--availability:
males age 15-49: 31,724 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 16,766 (1999 est.)
Military expenditures--dollar figure: $500,000 (1994)
Military expenditures--percent of GDP: 1.5% (1994)
Military branches: Land Force (Army), Navy, Air Force, Air
Defense Force, National Guard, Ministry of Interior Forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 5,696,772 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,171,860 (1999 est.)
Military manpower--reaching military age annually:
males: 197,386 (1999 est.)
Military expenditures--dollar figure: $18.1 billion (1997 est.)
Military expenditures--percent of GDP: 12% (1997 est.)
Military branches: Army, Navy, Air Force, National Gendarmerie,
National Police (Surete Nationale)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,096,438 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,095,047 (1999 est.)
Military manpower--reaching military age annually:
males: 103,348 (1999 est.)
Military expenditures--dollar figure: $68 million (1997)
Military expenditures--percent of GDP: 1.4% (1997)
Military branches: Army (including ground forces with border
troops, naval forces, air and air defense forces)
Military manpower--military age: Serbia?NA years of age;
Montenegro--19 years of age
Military manpower--availability:
males age 15-49: Serbia--2,727,292; Montenegro--187,198 (1999 est.)
Military manpower--fit for military service:
males age 15-49: Serbia--2,183,534; Montenegro--150,415 (1999 est.)
Military manpower--reaching military age annually:
males: Serbia--NA; Montenegro--5,671 (1999 est.)
Military expenditures--dollar figure: $911 million (1999)
Military expenditures--percent of GDP: 6.5% (1999)','2fbe1275aff6d0216b5705609b7ba4ae6bbb370ef62d91117e83b1712a852f56','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214f4d1f0a4a44f621ff8099438255d2ef5e9c32ae297d9a02474e3adf2ecc66',1999,'MX','Mexico','military-and-security',160,'Military branches: Army, Navy, Air Force, Air Defense Command
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 17,756,706 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 11,507,058 (1999 est.)
Military manpower--reaching military age annually:
males: 694,468 (1999 est.)
Military expenditures--dollar figure: $3.28 billion (FY95/96)
Military expenditures--percent of GDP: 8.2% (FY95/96)
Military branches: Army, Navy, Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,393,986 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 884,093 (1999 est.)
Military manpower--reaching military age annually:
males: 65,224 (1999 est.)
Military expenditures--dollar figure: $105 million (1998)
Military expenditures--percent of GDP: 0.9% (1998)
Military branches: Army, Navy, Air Force, Rapid Intervention
Force, National Police
Military manpower--availability:
males age 15-49: 102,269 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 51,979 (1999 est.)
Military expenditures--dollar figure: $2.5 million (FY97/98)
Military expenditures--percent of GDP: NA%
Military branches: Army, Navy, Air Force
Military expenditures--dollar figure: $196 million (1997)
Military expenditures--percent of GDP: 28.6% (1997)
Military branches: Ground Forces, Navy/Coast Guard, Air and Air
Defense Force (not officially sanctioned), Maritime Border Guard,
Volunteer Defense League (Kaitseliit), Security Forces (internal and
border troops)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 349,263 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 274,276 (1999 est.)
Military manpower--reaching military age annually:
males: 10,503 (1999 est.)
Military expenditures--dollar figure: $70 million (1999)
Military expenditures--percent of GDP: 1.2% (1999)
Military branches: Ground Forces, Air Force, Police
note: Ethiopia is landlocked and has no navy; following the de jure
independence of Eritrea, Ethiopian naval facilities remained in
Eritrean possession and ships which belonged to the former Ethiopian
Navy and based at Djibouti have been sold
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 13,520,302 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 7,052,710 (1999 est.)
Military manpower--reaching military age annually:
males: 655,290 (1999 est.)
Military expenditures--dollar figure: $138 million (FY98/99)
Military expenditures--percent of GDP: 2.5% (FY98/99)','c8331cb83058a1f04c3f29b426f7644cee2e98c0ddec7c8b7bfdb5bb01cefe88','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92231d837ac086a7e78871be6eb975ccfdc5cb0eb104b0020c667be1b19f6d18',1999,'MZ','Mozambique','military-and-security',171,'Military--note: defense is the responsibility of France
Military branches: Popular Armed Forces (includes Intervention
Forces, Development Forces, Aeronaval Forces--includes Navy and Air
Force), Gendarmerie, Presidential Security Regiment
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 3,415,726 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,027,757 (1999 est.)
Military manpower--reaching military age annually:
males: 144,779 (1999 est.)
Military expenditures--dollar figure: $29 million (1994)
Military expenditures--percent of GDP: 1% (1994)
Military branches: Army (includes Air Wing and Naval Detachment),
Police (includes paramilitary Mobile Force Unit)
Military manpower--availability:
males age 15-49: 2,314,509 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,186,341 (1999 est.)
Military expenditures--dollar figure: $17 million (FY96/97)
Military expenditures--percent of GDP: 0.8% (FY96/97)
Military branches: Malaysian Army, Royal Malaysian Navy, Royal
Malaysian Air Force, Royal Malaysian Police Force, Marine Police,
Sarawak Border Scouts
Military manpower--military age: 21 years of age
Military manpower--availability:
males age 15-49: 5,526,555 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,349,066 (1999 est.)
Military manpower--reaching military age annually:
males: 183,928 (1999 est.)
Military expenditures--dollar figure: $2.1 billion (1998)
Military expenditures--percent of GDP: 2.1% (1998)
Military--note: defense is the responsibility of France; small
contingent of French forces stationed on the island
Military branches: National Defense Secretariat (includes Army
and Air Force), Navy Secretariat (includes Naval Air and Marines)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 25,675,266 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 18,675,524 (1999 est.)
Military manpower--reaching military age annually:
males: 1,085,042 (1999 est.)
Military expenditures--dollar figure: $6 billion (1998)
Military expenditures--percent of GDP: 1.3% (1998)
Military--note: Federated States of Micronesia (FSM) is a
sovereign, self-governing state in free association with the US; FSM
is totally dependent on the US for its defense
Military--note: defense is the responsibility of the US
Military branches: Ground Forces, Air and Air Defense Forces,
Republic Security Forces (internal and border troops)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,151,674 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 908,347 (1999 est.)
Military manpower--reaching military age annually:
males: 38,666 (1999 est.)
Military expenditures--dollar figure: $6.3 million (FY99)
Military expenditures--percent of GDP: 1% (1999)
Military--note: defense is the responsibility of France
Military branches: Mongolian People''s Army (includes Internal
Security Forces and Frontier Guards), Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 702,141 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 457,270 (1999 est.)
Military manpower--reaching military age annually:
males: 28,613 (1999 est.)
Military expenditures--dollar figure: $20.3 million (1997)
Military expenditures--percent of GDP: 2% (1997)','4ed15124ffdfe38d07c2cfbc1c50924157324ecac4fd0cfb863cb59ca47553ac','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('342fca2830690e96952ceace12d40135f1b99cf842778cacb2c65b967bb5b397',1999,'AR','Argentina','military-and-security',177,'Military branches: British Forces Falkland Islands (includes
Army, Royal Air Force, Royal Navy, and Royal Marines), Police Force
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of the UK
Military branches: no organized native military forces; only a
small Police Force and Coast Guard are maintained
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of Denmark
Military branches: Republic of Fiji Military Forces (RFMF;
includes ground and naval forces)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 218,853 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 120,555 (1999 est.)
Military manpower--reaching military age annually:
males: 9,326 (1999 est.)
Military expenditures--dollar figure: $34 million (1997)
Military expenditures--percent of GDP: 1.6% (1997)
Military branches: Army, Navy, Air Force, Frontier Guard
(includes Sea Guard)
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 1,274,654 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,050,944 (1999 est.)
Military manpower--reaching military age annually:
males: 34,336 (1999 est.)
Military expenditures--dollar figure: $1.8 billion (1999)
Military expenditures--percent of GDP: 2% (1999)
Military branches: Army (includes Marines), Navy (includes Naval
Air), Air Force (includes Air Defense, National Gendarmerie
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 14,666,286 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 12,203,675 (1999 est.)
Military manpower--reaching military age annually:
males: 411,911 (1999 est.)
Military expenditures--dollar figure: $39.831 billion (1997)
Military expenditures--percent of GDP: 2.5% (1995)
Military branches: French Forces, Gendarmerie
Military manpower--availability:
males age 15-49: 47,354 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 30,656 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of France','8f5b737808eb6c8cbb89c7193107b2437bb515be6aff41a4180785194d0a8271','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43978485fb2b680960b317522929e33f481acb1655aab990265532f399cb2b68',1999,'NR','Nauru','military-and-security',189,'Military branches: French Forces (includes Army, Navy, Air
Force), Gendarmerie
Military--note: defense is the responsibility of France
Military--note: defense is the responsibility of France
Military branches: Army, Navy, Air Force, Republican Guard
(charged with protecting the president and other senior officials),
National Gendarmerie, National Police
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 280,719 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 144,133 (1999 est.)
Military manpower--reaching military age annually:
males: 11,392 (1999 est.)
Military expenditures--dollar figure: $91 million (1996)
Military expenditures--percent of GDP: 1.6% (1996)
Military branches: no regular military forces; Police Force
(carries out law enforcement functions and paramilitary duties;
small police posts are on all islands)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: Kiribati does not have military forces; defense
assistance is provided by Australia and NZ
Military branches: Korean People''s Army (includes Army, Navy, Air
Force), Civil Security Forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 5,768,038 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,483,188 (1999 est.)
Military manpower--reaching military age annually:
males: 177,888 (1999 est.)
Military expenditures--dollar figure: $5 billion to $7 billion
(1997 est.)
Military expenditures--percent of GDP: 25% to 33% (1997 est.)
Military branches: Army, Navy, Air Force, Marine Corps, National
Maritime Police (Coast Guard)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 13,954,916 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 8,890,144 (1999 est.)
Military manpower--reaching military age annually:
males: 400,468 (1999 est.)
Military expenditures--dollar figure: $9.9 billion (FY98/99)
Military expenditures--percent of GDP: 3.2% (FY98/99)
Military branches: Army, Navy, Air Force, National Police Force,
National Guard, Coast Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 718,061 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 425,126 (1999 est.)
Military manpower--reaching military age annually:
males: 20,854 (1999 est.)
Military expenditures--dollar figure: $2.7035 billion (FY98/99)
Military expenditures--percent of GDP: 7.9% (FY98/99)
Military branches: Army, National Guard, Security Forces
(internal and border troops), Civil Defense
note: border troops controlled by Russia
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,146,595 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 930,017 (1999 est.)
Military manpower--reaching military age annually:
males: 46,561 (1999 est.)
Military expenditures--dollar figure: $10.8 million (1996)
Military expenditures--percent of GDP: 1% (1996)
Military branches: Lao People''s Army (LPA; includes militia
element), Lao People''s Navy (LPN; includes riverine element), Air
Force, National Police Department
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,200,664 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 648,087 (1999 est.)
Military manpower--reaching military age annually:
males: 57,047 (1999 est.)
Military expenditures--dollar figure: $77.4 million (FY96/97)
Military expenditures--percent of GDP: 4.2% (FY96/97)','79a4c6d571814b751e7971ad3dcd0626522500f9ff6f96033ff59a027bd9f22b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d662e0d073c8caff7cbdad8385aae41b7d68dffd17ac4f6168b373712d41e26a',1999,'SN','Senegal','military-and-security',198,'Military branches: Army (includes marine unit), National Police,
National Guard
Military manpower--availability:
males age 15-49: 296,976 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 149,670 (1999 est.)
Military expenditures--dollar figure: $1.2 million (FY96/97)
Military expenditures--percent of GDP: 2% (FY96/97)
Military branches: NA
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Ground Forces, Navy, Air Force, Air Defense
Forces, National Guard, Republic Security Forces (internal and
border troops)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,287,225 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,018,309 (1999 est.)
Military manpower--reaching military age annually:
males: 40,604 (1999 est.)
Military expenditures--dollar figure: $57 million (1998)
Military expenditures--percent of GDP: 1% (1998)
Military--note: a CIS peacekeeping force consisting of Russian
troops is deployed in the Abkhazia region of Georgia together with a
UN military observer group; a Russian peacekeeping battalion is
deployed in South Ossetia
Military branches: Army, Navy (includes Naval Air Arm), Air
Force, Medical Corps, Border Police, Coast Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 20,860,710 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 17,799,070 (1999 est.)
Military manpower--reaching military age annually:
males: 472,708 (1999 est.)
Military expenditures--dollar figure: $32.8 billion (1998)
Military expenditures--percent of GDP: 1.5% (1998)
Military branches: Army, Navy, Air Force, National Police Force,
Palace Guard, Civil Defense
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 4,520,125 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,507,954 (1999 est.)
Military manpower--reaching military age annually:
males: 184,360 (1999 est.)
Military expenditures--dollar figure: $53 million (1999)
Military expenditures--percent of GDP: 0.7% (1999)
Military branches: British Army, Royal Navy, Royal Air Force
Military--note: defense is the responsibility of the UK
Military--note: defense is the responsibility of France','e3afd51fb2feb62e8f46533d34d6a3031927b4a0aabc2cb0f4f1bae66a11c6d5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc39f625f3a1cdf27c72cfdd47716609859f85794882e97d09f5daff832f0550',1999,'GR','Greece','military-and-security',206,'Military branches: Hellenic Army, Hellenic Navy, Hellenic Air
Force, National Guard, Police
Military manpower--military age: 21 years of age
Military manpower--availability:
males age 15-49: 2,707,628 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,071,670 (1999 est.)
Military manpower--reaching military age annually:
males: 79,376 (1999 est.)
Military expenditures--dollar figure: $4.04 billion (1998 est.)
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of Denmark
Military branches: Royal Grenada Police Force (includes Special
Service Unit), Coast Guard
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%','f62f9aa1f3a6be1eb34de1f12580da91464db032ca5c12f1f597c91d3b2097cb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33e7396c6a41476811f4a4d55a46249a90eee9789790dd43f4bd2e78e2a3f0ea',1999,'MQ','Martinique','military-and-security',211,'Military branches: French Forces, Gendarmerie
Military--note: defense is the responsibility of France
Military--note: defense is the responsibility of the US','7102430b003e857c36e705bdbd85b73ea31c7af2ae8b83ea260c0ce37ead690c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c44f26840fdc087e71fbd4ca831cc6123e62000f2ee8a2074a41c608e4e6f84',1999,'GT','Guatemala','military-and-security',220,'Military branches: Army, Navy, Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,915,169 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,903,382 (1999 est.)
Military manpower--reaching military age annually:
males: 134,964 (1999 est.)
Military expenditures--dollar figure: $124 million (1998)
Military expenditures--percent of GDP: 0.7% (1998)
Military--note: defense is the responsibility of the UK
Military branches: Army, Navy, Air Force, Republican Guard,
Presidential Guard, paramilitary National Gendarmerie, National
Police Force (Surete National)
Military manpower--availability:
males age 15-49: 1,726,933 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 871,615 (1999 est.)
Military expenditures--dollar figure: $56 million (1996)
Military expenditures--percent of GDP: 1.4% (1996)
Military branches: People''s Revolutionary Armed Force (FARP;
includes Army, Navy, and Air Force), paramilitary force
Military manpower--availability:
males age 15-49: 284,998 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 162,485 (1999 est.)
Military expenditures--dollar figure: $8 million (1996)
Military expenditures--percent of GDP: 2.8% (1996)
Military branches: Guyana Defense Force (GDF; includes Ground
Forces, Coast Guard, and Air Corps), Guyana People''s Militia (GPM),
Guyana National Service (GNS), Guyana Police Force
Military manpower--availability:
males age 15-49: 202,509 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 152,839 (1999 est.)
Military expenditures--dollar figure: $7 million (1994)
Military expenditures--percent of GDP: 1.7% (1994)
Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force have been
demobilized but still exist on paper until/unless constitutionally
abolished
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,541,402 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 835,578 (1999 est.)
Military manpower--reaching military age annually:
males: 80,158 (1999 est.)
Military expenditures--dollar figure: $NA; note?mainly for police
and security activities
Military expenditures--percent of GDP: NA%
Military--note: the Haitian Armed Forces have been demobilized and
replaced by the Haitian National Police
Military--note: defense is the responsibility of Australia
Military--note: defense is the responsibility of Italy; Swiss
Papal Guards are posted at entrances to the Vatican City
Military branches: Army, Navy (includes Marines), Air Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,455,053 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 866,492 (1999 est.)
Military manpower--reaching military age annually:
males: 69,646 (1999 est.)
Military expenditures--dollar figure: $33 million (1998)
Military expenditures--percent of GDP: 0.6% (1998)
Military branches: Hong Kong garrison of the PLA including
elements of the PLA Army, the PLA Navy and PLA Air Force; these
forces are under the direct leadership of the Central Military
Commission in Beijing and under administrative control of the
adjacent Guangzhou Military Region
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,924,304 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,452,110 (1999 est.)
Military manpower--reaching military age annually:
males: 45,656 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of China
Military--note: defense is the responsibility of the US; visited
annually by the US Coast Guard
Military branches: Ground Forces, Air Force, Border Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,601,741 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,073,419 (1999 est.)
Military manpower--reaching military age annually:
males: 70,393 (1999 est.)
Military expenditures--dollar figure: $645 million (1997)
Military expenditures--percent of GDP: 1.4% (1997)
Military branches: no regular armed forces; Police, Coast Guard;
note--Iceland''s defense is provided by the US-manned Icelandic
Defense Force (IDF) headquartered at Keflavik
Military manpower--availability:
males age 15-49: 70,958 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 62,570 (1999 est.)
Military expenditures--dollar figure: none
Military--note: Iceland''s defense is provided by the US-manned
Icelandic Defense Force (IDF) headquartered at Keflavik
Military branches: Army, Navy (including naval air arm), Air
Force, various security or paramilitary forces (includes Border
Security Force, Assam Rifles, and Rashtriya Rifles)
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 269,339,985 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 158,141,508 (1999 est.)
Military manpower--reaching military age annually:
males: 10,661,786 (1999 est.)
Military expenditures--dollar figure: $10.012 billion (FY98/99)
Military expenditures--percent of GDP: 2.7% (FY98/99)','efc2afebd3651227c52f1896e01d3248a1ef44cc4c2b77797eef8202e60da3fb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84a7dc9d93c5a5ec3a9898fcbf5d3ae3d9262fe1e989761590a2b903649c1af3',1999,'FR','France','military-and-security',232,'Military--note: defense is the responsibility of the UK
Military--note: defense is the responsibility of the US
Military branches: Army, National Gendarmerie
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 108,285 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 88,813 (1999 est.)
Military manpower--reaching military age annually:
males: 2,452 (1999 est.)
Military expenditures--dollar figure: $124 million (FY97)
Military expenditures--percent of GDP: 0.8% (1995)
Military branches: French forces (Army, Navy, Air Force),
Gendarmerie
Military--note: defense is the responsibility of France
Military branches: Army, Navy, Air Force, National Gendarmerie,
National Guard, National Police, Presidential Guard
Military manpower--availability:
males age 15-49: 571,521 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 277,620 (1999 est.)
Military expenditures--dollar figure: $30 million (1996)
Military expenditures--percent of GDP: 2.5% (1996)
Military--note: defense is the responsibility of France','fb46e94ca8e17120b142860d4aef1bb02e0919e1e9e271e7c1bf1c40c3113a0e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51b06302642f8e7c9595e5cdd6f17207c22c9a490e7ffb4a9d13de8a9977bb2f',1999,'CN','China','military-and-security',240,'Military branches: Jordanian Armed Forces (JAF; includes Royal
Jordanian Land Force, Royal Naval Force, and Royal Jordanian Air
Force); Badiya (irregular) Border Guards; Ministry of the Interior''s
Public Security Force (falls under JAF only in wartime or crisis
situations)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,113,998 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 793,002 (1999 est.)
Military manpower--reaching military age annually:
males: 49,954 (1999 est.)
Military expenditures--dollar figure: $608.9 million (FY 98)
Military expenditures--percent of GDP: 7.8% (1997)
Military--note: defense is the responsibility of France
Military branches: General Purpose Forces (Army), Air Force,
Border Guards, Navy, Republican Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 4,450,258 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 3,550,645 (1999 est.)
Military manpower--reaching military age annually:
males: 155,767 (1999 est.)
Military expenditures--dollar figure: $232.4 million (1998)
Military expenditures--percent of GDP: 1% (1998)
Military branches: Army, Navy, Air Force, paramilitary General
Service Unit of the Police
Military manpower--availability:
males age 15-49: 7,094,151 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,397,008 (1999 est.)
Military expenditures--dollar figure: $197 million (FY98/99)
Military expenditures--percent of GDP: 1.9% (FY98/99)
Military--note: defense is the responsibility of the US','61e1a6c82f82b41bd23fbe5daf5134a56f0536042be92f1f099273f9e34a29a0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7066465deba3fe2a5a905f56932e2989fe2f502129f0dd11716849c8dde2c616',1999,'SE','Sweden','military-and-security',249,'Military branches: Ground Forces, Navy, Air and Air Defense
Forces, Security Forces, Border Guard, Home Guard (Zemessardze)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 565,811 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 443,879 (1999 est.)
Military manpower--reaching military age annually:
males: 16,883 (1999 est.)
Military expenditures--dollar figure: $60 million (1999)
Military expenditures--percent of GDP: 0.9% (1999)
Military branches: Lebanese Armed Forces (LAF; includes Army,
Navy, and Air Force)
Military manpower--availability:
males age 15-49: 925,834 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 573,093 (1999 est.)
Military expenditures--dollar figure: $445 million (1997)
Military expenditures--percent of GDP: 5% (1997)
Military branches: Lesotho Defense Force (LDF; includes Army and
Air Wing), Royal Lesotho Mounted Police (RLMP)
Military manpower--availability:
males age 15-49: 504,442 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 271,925 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Army, Air Force, Navy
Military manpower--availability:
males age 15-49: 667,032 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 356,825 (1999 est.)
Military expenditures--dollar figure: $1.4 million (1998)
Military expenditures--percent of GDP: 2% (1998)','f37a840f53d501f68b5c2068a38411bd1eb0b1c83a592431484f9eeb6bffb65a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a01c2693a76a3b461fc2507f7dafc775e421651e6d059b3db5f283e28b59656a',1999,'EG','Egypt','military-and-security',259,'Military branches: Army, Navy, Air and Air Defense Command
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 1,372,261 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 816,186 (1999 est.)
Military manpower--reaching military age annually:
males: 62,098 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military--note: defense is the responsibility of Switzerland
Military branches: Ground Forces, Navy, Air and Air Defense
Force, Security Forces (internal and border troops), National Guard
(Skat)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 906,687 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 713,436 (1999 est.)
Military manpower--reaching military age annually:
males: 26,168 (1999 est.)
Military expenditures--dollar figure: $181 million (1999)
Military expenditures--percent of GDP: 1.5% (1999)','2ad9bce5ba333e36c45a8bda0d6cb312fe84239fd45a2e73183503309b008f2d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5d57c0910843ae83bc7c22d4a0b7b16bb4fd0a8bb97f6a23d7b8fdabf0c7b57',1999,'HK','Hong Kong','military-and-security',269,'Military branches: no regular military forces, Police Force
Military manpower--availability:
males age 15-49: 121,355 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 66,744 (1999 est.)
Military--note: defense is currently the responsibility of
Portugal, but will become the responsibility of China on 20 December
1999
Military branches: Army, Navy, Air and Air Defense Forces, Police
Force
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 539,329 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 434,468 (1999 est.)
Military manpower--reaching military age annually:
males: 17,291 (1999 est.)
Military expenditures--dollar figure: $71 million (1998)
Military expenditures--percent of GDP: 2.2% (1998)','7eab96c6f674b4cb33e280f6d9920b5e711b3e7712db69d6f25bda37ca540f92','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1915afe5da6e4a998529c6f1a0005fd2a7d62f5d532ddb60395bfebc1271a0ab',1999,'TH','Thailand','military-and-security',276,'Military branches: National Security Service (paramilitary police
force)
Military manpower--availability:
males age 15-49: 66,554 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 37,086 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%','b78b12a2539851d1fb6ab37f2027d9fb934b0cedc065e3d28471fc0d548b5461','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f8f189daa6dcdf906a670b0c8ee3ba56108e39411551372acaba9ba0f9fe1a2',1999,'MT','Malta','military-and-security',285,'Military branches: Armed Forces (including an air squadron, a
maritime squadron, and the Revenue Security Corps), Maltese Police
Force
Military manpower--availability:
males age 15-49: 99,067 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 78,855 (1999 est.)
Military expenditures--dollar figure: $65.5 million (FY96/97)
Military expenditures--percent of GDP: 2.7% (FY96/97)
Military--note: defense is the responsibility of the UK
Military branches: no regular military forces (a coast guard may
be established); Police Force
Military--note: defense is the responsibility of the US','47a3eed4de14ad25eee6df840e0e7144fbef18456abfc212a4ec9ca6f1e9229b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de9fb2e1580fd27893ba5425405a34b3a0bd783455b1b9bf4cce762680f799c9',1999,'MG','Madagascar','military-and-security',297,'Military branches: National Police Force (includes the
paramilitary Special Mobile Force or SMF, Special Support Units or
SSU, and National Coast Guard)
Military manpower--availability:
males age 15-49: 339,218 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 171,705 (1999 est.)
Military expenditures--dollar figure: $11.2 million (FY97/98)
Military expenditures--percent of GDP: 0.4% (FY97/98)
Military branches: French forces (Army, Navy, Air Force, and
Gendarmerie)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 185,800 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 95,068 (1999 est.)
Military manpower--reaching military age annually:
males: 5,902 (1999 est.)
Military--note: defense is the responsibility of France
Military branches: Army, Navy, Air and Air Defense Forces,
Paramilitary Forces, Civil Defense
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 5,876,912 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,938,953 (1999 est.)
Military manpower--reaching military age annually:
males: 193,264 (1999 est.)
Military expenditures--dollar figure: $650 million (1996)
Military expenditures--percent of GDP: 2.5% (1996)
Military branches: Ground Forces, Navy, Air Forces, Strategic
Rocket Forces
note: the Air Defense Force merged into the Air Force in March 1998
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 38,665,138 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 30,173,495 (1999 est.)
Military manpower--reaching military age annually:
males: 1,149,536 (1999 est.)
Military expenditures--dollar figure: $NA
note: the Intelligence Community estimates that defense spending in
Russia fell by about 10% in real terms in 1996, reducing Russian
defense outlays to about one-sixth of peak Soviet levels in the late
1980s (1997 est.)
Military expenditures--percent of GDP: NA%
Military branches: Army, Gendarmerie
Military manpower--availability:
males age 15-49: 1,964,118 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,000,204 (1999 est.)
Military expenditures--dollar figure: $92 million (1999)
Military expenditures--percent of GDP: 3.8% (1999)
Military--note: defense is the responsibility of France
Military branches: Army, Navy, Air Force, paramilitary forces,
National Guard
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 2,601,928 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,486,964 (1999 est.)
Military manpower--reaching military age annually:
males: 99,597 (1999 est.)
Military expenditures--dollar figure: $356 million (1999)
Military expenditures--percent of GDP: 1.5% (1999)
Military branches: Land Forces, Navy (includes Naval Air and
Naval Infantry), Air Force, Coast Guard, Gendarmerie
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 18,168,658 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 11,024,173 (1999 est.)
Military manpower--reaching military age annually:
males: 659,338 (1999 est.)
Military expenditures--dollar figure: $6.737 billion (1997)
Military expenditures--percent of GDP: 4.3% (1997)
Military branches: Ministry of Defense (Army, Air and Air
Defense, Navy, Border Troops, and Internal Troops), National Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,110,606 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 901,735 (1999 est.)
Military manpower--reaching military age annually:
males: 45,050 (1999 est.)
Military expenditures--dollar figure: $88 million (1998)
Military expenditures--percent of GDP: 3% (1998)','c6dea65364d083b7c3d3d050538d43be2e3737260c0acb0dc5d9e87dabe37ce5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93c82ae16f412933c45ab7a4cf014330b8c8a6d5b4bbc4a12425b1cf8d11eea3',1999,'HN','Honduras','military-and-security',306,'Military branches: Army, Air Force, National Gendarmerie,
Republican Guard, National Police
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 2,117,868 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,143,355 (1999 est.)
Military manpower--reaching military age annually:
males: 102,762 (1999 est.)
Military expenditures--dollar figure: $20 million (FY96/97)
Military expenditures--percent of GDP: 1.1% (FY96/97)
Military branches: Army, Navy, Air Force, Police Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 25,967,281 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 14,890,337 (1999 est.)
Military manpower--reaching military age annually:
males: 1,201,738 (1999 est.)
Military expenditures--dollar figure: $236 million (1999)
Military expenditures--percent of GDP: 0.7% (1999)','f1036fd4e6a82ee8b3423cc605a639eb282cb3af75736b71674df18afab2bedc','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51570829302a7f58cd344c8187e1d5a6cf0c60cd1141c21a34aebdfe9bc009cb',1999,'TO','Tonga','military-and-security',313,'Military branches: Police Force
Military--note: defense is the responsibility of New Zealand','077d281a2cffb1e88125f937b0dd99d1f74be70c9f8ebeb8879739024f8a6950','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd3927f5fc62f4ba8696d637bfc89e178d160f7c165f7048f49ca59f0c9c3018',1999,'BR','Brazil','military-and-security',321,'Military branches: Army, Navy (includes Naval Air and Marines),
Air Force
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 1,311,382 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 947,347 (1999 est.)
Military manpower--reaching military age annually:
males: 55,065 (1999 est.)
Military expenditures--dollar figure: $125 million (1998)
Military expenditures--percent of GDP: 1.4% (1998)
Military branches: Army (Ejercito Peruano), Navy (Marina de
Guerra del Peru; includes Naval Air, Marines, and Coast Guard), Air
Force (Fuerza Aerea del Peru), National Police
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 6,913,471 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,657,649 (1999 est.)
Military manpower--reaching military age annually:
males: 268,624 (1999 est.)
Military expenditures--dollar figure: $913 million (1998);
note--may not include off-budget purchases related to military
modernization program
Military expenditures--percent of GDP: 1.4% (1998)
Military branches: Army, Navy (includes Coast Guard and Marine
Corps), Air Force
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 20,228,797 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 14,261,514 (1999 est.)
Military manpower--reaching military age annually:
males: 818,006 (1999 est.)
Military expenditures--dollar figure: $995 million (1998)
Military expenditures--percent of GDP: 1.5% (1998)
Military--note: defense is the responsibility of the UK
Military branches: Army, Navy, Air and Air Defense Force
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 10,417,314 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 8,104,484 (1999 est.)
Military manpower--reaching military age annually:
males: 334,420 (1999 est.)
Military expenditures--dollar figure: $3.3 billion (1998)
Military expenditures--percent of GDP: 2.2% (1998)
Military branches: Army, Navy (includes Marines), Air Force,
National Republican Guard
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 2,542,188 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,042,730 (1999 est.)
Military manpower--reaching military age annually:
males: 73,405 (1999 est.)
Military expenditures--dollar figure: $2.458 billion (1997)
Military expenditures--percent of GDP: 2.6% (1997)
Military branches: paramilitary National Guard, Police Force
Military--note: defense is the responsibility of the US','d2a1895c65c92cb9bdaf298a2c46abf57da6b512b1a838e115f485873e2cb607','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21f6830548b89dea5ccde9a593ff06dba4f08269c949836a891c34dd57cae49d',1999,'SC','Seychelles','military-and-security',329,'Military branches: Army, Coast Guard, Marines, air wing, National
Guard, Presidential Protection Unit, Police Force
Military manpower--availability:
males age 15-49: 22,420 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 11,242 (1999 est.)
Military expenditures--dollar figure: $13.7 million (1995)
Military expenditures--percent of GDP: NA%
Military branches: Army
Military manpower--availability:
males age 15-49: 1,119,239 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 543,210 (1999 est.)
Military expenditures--dollar figure: $46 million (FY96/97)
Military expenditures--percent of GDP: 2% (FY96/97)','bdd4be7089f762a233e3e8e4d9fe6be3e4287d48d24601d15fa9796c11d3e8cf','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e98b6465ef753d1ecc7ed37621367d847ed449b13b3b2cd5739f4d1db4846aa0',1999,'ID','Indonesia','military-and-security',337,'Military branches: Army, Navy, Air Force, People''s Defense Force,
Police Force
Military manpower--availability:
males age 15-49: 1,042,587 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 757,940 (1999 est.)
Military expenditures--dollar figure: $4.244 billion (FY98/99)
Military expenditures--percent of GDP: 5.1% (FY98/99)
Military branches: Army, Air and Air Defense Forces, Reserve
Force (Home Guards), Civil Defense Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,478,729 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,130,482 (1999 est.)
Military manpower--reaching military age annually:
males: 45,919 (1999 est.)
Military expenditures--dollar figure: $436 million (1998)
Military expenditures--percent of GDP: 2.1% (1998)
Military branches: Slovenian Army (includes Air and Naval Forces)
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 530,182 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 421,864 (1999 est.)
Military manpower--reaching military age annually:
males: 15,294 (1999 est.)
Military expenditures--dollar figure: $272 million (1998)
Military expenditures--percent of GDP: 1.8% (1998)
Military branches: no regular military forces; Solomon Islands
National Reconnaissance and Surveillance Force; Royal Solomon
Islands Police (RSIP)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: NA; note--no functioning central government
military forces; clan militias continue to battle for control of key
economic or political prizes
Military manpower--availability:
males age 15-49: 1,730,450 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 962,545 (1999 est.)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: South African National Defense Force or SANDF
(includes Army, Navy, Air Force, and Medical Services), South
African Police Service or SAPS
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 11,330,692 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 6,889,631 (1999 est.)
Military manpower--reaching military age annually:
males: 453,610 (1999 est.)
Military expenditures--dollar figure: $2 billion (FY99/00)
Military expenditures--percent of GDP: 2.2% (FY95/96)
Military--note: the National Defense Force continues to integrate
former military, black homelands forces, and ex-opposition forces
Military--note: defense is the responsibility of the UK','2bde13a4c06b3d703c2e196d986a4689fc8cc5034a55fb7da5bd095e797f403c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dea03b1e7092e60beb32cea2f39685ab89db61e33ecab096971da43d498bc4db',1999,'GI','Gibraltar','military-and-security',345,'Military branches: Army, Navy, Air Force, Marines, Civil Guard,
National Police, Coastal Civil Guard
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 10,374,314 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 8,346,155 (1999 est.)
Military manpower--reaching military age annually:
males: 311,350 (1999 est.)
Military expenditures--dollar figure: $6.3 billion (1995)
Military expenditures--percent of GDP: 1.4% (1995)
Military--note: Spratly Islands consist of more than 100 small
islands or reefs, of which about 45 are claimed and occupied by
China, Malaysia, the Philippines, Taiwan, and Vietnam','ba19656f2f91659d2e098f9a64cf6c7166d4b5a31eb2de9d27a404fed62630ec','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9b07f24245f654a00a09a31dd185ed701c79c761391a2608a66f5f1ca0d0090',1999,'IN','India','military-and-security',359,'Military branches: Army, Navy, Air Force, Police Force
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 5,223,590 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,062,758 (1999 est.)
Military manpower--reaching military age annually:
males: 199,196 (1999 est.)
Military expenditures--dollar figure: $719 million (1998)
Military expenditures--percent of GDP: 4.2% (1998)
Military branches: Army, Navy, Air Force, Popular Defense Force
Militia
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 7,942,139 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,889,557 (1999 est.)
Military manpower--reaching military age annually:
males: 379,174 (1999 est.)
Military expenditures--dollar figure: $550 million (FY98/99)
Military expenditures--percent of GDP: NA%
Military branches: National Army (includes small Navy and Air
Force elements), Civil Police
Military manpower--availability:
males age 15-49: 118,686 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 69,842 (1999 est.)
Military expenditures--dollar figure: $8.5 million (1997 est.)
Military expenditures--percent of GDP: 1.6% (1997 est.)
Military--note: demilitarized by treaty (9 February 1920)
Military branches: Umbutfo Swaziland Defense Force (Army), Royal
Swaziland Police Force
Military manpower--availability:
males age 15-49: 221,199 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 128,806 (1999 est.)
Military expenditures--dollar figure: $23 million (FY95/96)
Military expenditures--percent of GDP: 1.9% (FY95/96)
Military branches: Swedish Army, Royal Swedish Navy, Swedish Air
Force
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 2,076,903 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,817,554 (1999 est.)
Military manpower--reaching military age annually:
males: 52,486 (1999 est.)
Military expenditures--dollar figure: $4.9 billion (FY97/98)
Military expenditures--percent of GDP: 2.2% (FY97/98)
Military branches: Army, Air Force, Frontier Guards,
Fortification Guards
Military manpower--military age: 20 years of age
Military manpower--availability:
males age 15-49: 1,867,290 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,592,696 (1999 est.)
Military manpower--reaching military age annually:
males: 41,204 (1999 est.)
Military expenditures--dollar figure: $3.1 billion (1999)
Military expenditures--percent of GDP: 1.2% (1999)
Military branches: Syrian Arab Army, Syrian Arab Navy, Syrian
Arab Air Force, Syrian Arab Air Defense Forces, Police and Security
Force
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 4,060,995 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,271,539 (1999 est.)
Military manpower--reaching military age annually:
males: 188,546 (1999 est.)
Military expenditures--dollar figure: $800 million-$1 billion
(1997 est.); note--based on official budget data that understate
actual spending
Military expenditures--percent of GDP: 8% (1995 est.)
Military branches: Army, Navy (includes Marines), Air Force,
Coastal Patrol and Defense Command, Armed Forces Reserve Command,
Combined Service Forces
Military manpower--military age: 19 years of age
Military manpower--availability:
males age 15-49: 6,544,602 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 5,019,737 (1999 est.)
Military manpower--reaching military age annually:
males: 204,711 (1999 est.)
Military expenditures--dollar figure: $7.446 billion (FY98/99)
Military expenditures--percent of GDP: 2.8% (FY98/99)
Military branches: Army, Air Force, Air Defense Forces,
Presidential National Guard, Security Forces (internal and border
troops)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 1,478,551 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,211,514 (1999 est.)
Military manpower--reaching military age annually:
males: 65,001 (1999 est.)
Military expenditures--dollar figure: $19.3 million (1997)
Military expenditures--percent of GDP: 1.8% (1997)
Military branches: Tanzanian People''s Defense Force or TPDF
(includes Army, Navy, and Air Force), paramilitary Police Field
Force Unit, Militia
Military manpower--availability:
males age 15-49: 7,119,106 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,120,617 (1999 est.)
Military expenditures--dollar figure: $21 million (FY98/99)
Military expenditures--percent of GDP: 0.2% (FY98/99)
Military branches: Royal Thai Army, Royal Thai Navy (includes
Royal Thai Marine Corps), Royal Thai Air Force, Paramilitary Forces
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 17,486,014 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 10,536,417 (1999 est.)
Military manpower--reaching military age annually:
males: 585,562 (1999 est.)
Military expenditures--dollar figure: $1.95 billion (FY97/98)
Military expenditures--percent of GDP: 2.5% (FY97/98)
Military branches: Army, Navy, Air Force, Gendarmerie
Military manpower--availability:
males age 15-49: 1,102,453 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 578,109 (1999 est.)
Military expenditures--dollar figure: $27 million (1996)
Military expenditures--percent of GDP: 2% (1996)
Military--note: defense is the responsibility of New Zealand
Military branches: Tonga Defense Services (includes, Royal Tongan
Marines, Tongan Royal Guards, Maritime Force, Police); note--a new
Air Wing which will be subordinate to the Defense Ministry is being
developed
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: Trinidad and Tobago Defense Force (includes
Ground Forces, Coast Guard, and Air Wing), Trinidad and Tobago
Police Service
Military manpower--availability:
males age 15-49: 312,870 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 223,200 (1999 est.)
Military expenditures--dollar figure: $83 million (1994)
Military expenditures--percent of GDP: NA%','c1f8d054952817f1dd45feab76959349c54a8b23da249c918dcf4603ab8c89e7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c75ae271272428c02a0ad5ceed6195bf7465aa91b14cfd8c79309e1395eb4d',1999,'TC','Turks and Caicos Islands','military-and-security',374,'Military branches: Army, Royal Navy (includes Royal Marines),
Royal Air Force
Military manpower--availability:
males age 15-49: 14,458,646 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 12,053,320 (1999 est.)
Military expenditures--dollar figure: $36.7 billion (FY98/99)
Military expenditures--percent of GDP: 2.6% (FY98/99)','44033e97c5ea303c546b65e0669e14d2e952ef3bd8a58f88ee30a3a90e8992d2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5036efedc761a555493d3c2e6483dea6640d581d89dacb38d528f292139e34dc',1999,'ES','Spain','military-and-security',382,'Military branches: Army, Navy (includes Naval Air Arm, Coast
Guard, Marines), Air Force, Police (Coracero Guard, Grenadier Guard)
Military manpower--availability:
males age 15-49: 806,451 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 653,796 (1999 est.)
Military expenditures--dollar figure: $172 million (1998)
Military expenditures--percent of GDP: 0.9% (1998)
Military branches: Army, Air and Air Defense Forces, Security
Forces (internal and border troops), National Guard
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 6,172,436 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 5,012,944 (1999 est.)
Military manpower--reaching military age annually:
males: 254,114 (1999 est.)
Military expenditures--dollar figure: $200 million (1997)
Military expenditures--percent of GDP: 1.4% (1997)
Military branches: no regular military forces; Vanuatu Police
Force (VPF; includes the paramilitary Vanuatu Mobile Force or VMF)
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%','264eefc2fd1029a67c1b84726e91aac505d48c8a9663930e546f7f6aa28dcf87','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10f4b8ae905299f8082544911ce58f16fbf136c69116427d7c59285431749c7',1999,'NC','New Caledonia','military-and-security',396,'Military branches: National Armed Forces (Fuerzas Armadas
Nacionales or FAN) includes Ground Forces or Army (Fuerzas
Terrestres or Ejercito), Naval Forces (Fuerzas Navales or Armada),
Air Force (Fuerzas Aereas or Aviacion), Armed Forces of Cooperation
or National Guard (Fuerzas Armadas de Cooperacion or Guardia
Nacional)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 6,268,982 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 4,522,757 (1999 est.)
Military manpower--reaching military age annually:
males: 242,362 (1999 est.)
Military expenditures--dollar figure: $1.1 billion (1998)
Military expenditures--percent of GDP: 1% (1998)
Military branches: People''s Army of Vietnam (PAVN) (includes
Ground Forces, Navy, and Air Force), Coast Guard
Military manpower--military age: 17 years of age
Military manpower--availability:
males age 15-49: 20,492,806 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 12,933,945 (1999 est.)
Military manpower--reaching military age annually:
males: 877,714 (1999 est.)
Military expenditures--dollar figure: $650 million (1997)
Military expenditures--percent of GDP: 9.3% (1997)
Military--note: defense is the responsibility of the US
Military--note: defense is the responsibility of the US
Military--note: defense is the responsibility of France
Military branches: NA
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: NA
Military expenditures--dollar figure: $NA
Military expenditures--percent of GDP: NA%
Military branches: ground, maritime, and air forces at all levels
of technology
Military expenditures--dollar figure: aggregate real expenditure
on arms worldwide in 1998 remained at approximately the 1997 level,
about three-quarters of a trillion dollars (1998 est.)
Military expenditures--percent of GDP: roughly 2% of gross world
product (1998 est.)
======================================================================
@Yemen
-----
Military branches: Army, Navy, Air Force, Air Defense Forces,
paramilitary (includes Police)
Military manpower--military age: 18 years of age
Military manpower--availability:
males age 15-49: 3,776,075 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 2,119,308 (1999 est.)
Military manpower--reaching military age annually:
males: 212,005 (1999 est.)
Military expenditures--dollar figure: $413.6 million (1999)
Military expenditures--percent of GDP: 7.6% (1999)
Military branches: Army, Air Force, paramilitary forces, Police
Military manpower--availability:
males age 15-49: 2,102,167 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,113,174 (1999 est.)
Military expenditures--dollar figure: $76 million (1997)
Military expenditures--percent of GDP: 1.8% (1997)
Military branches: Zimbabwe National Army, Air Force of Zimbabwe,
Zimbabwe Republic Police (includes Police Support Unit, Paramilitary
Police)
Military manpower--availability:
males age 15-49: 2,738,963 (1999 est.)
Military manpower--fit for military service:
males age 15-49: 1,707,348 (1999 est.)
Military expenditures--dollar figure: $427 million (FY97/98)
Military expenditures--percent of GDP: 4.6% (FY97/98)','d25420cf84aa915e26ec93b052acbbf7e05f70b027602104a84768d2dfdd8b45','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

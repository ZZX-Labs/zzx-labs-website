SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('488e4f58b10c9016f53b6aa3368a258e2330d0d0b8e7f70eaf0cd2cd5447f6c9',1999,'ST','Sao Tome and Principe','space',1090,'100
tons, gross register
cubic meters of permanently
enclosed space
2.831 684 7
tons, long (deadweight)
avoirdupois ounces
35,840
tons, long (deadweight)
avoirdupois pounds
2,240
tons, long (deadweight)
kilograms
1,016.046 909 8
tons, long (deadweight)
long hundredweights
20
tons, long (deadweight)
metric tons
1.016 046 908 8
tons, long (deadweight)
short hundredweights
22.4
tons, long (deadweight)
short tons
1.12
tons, metric
avoirdupois pounds
2,204.623
tons, metric
kilograms
1,000
tons, metric
long hundredweights
19.684130 3
tons, metric
long tons
0.984 206 5
tons, metric
quintals
10
tons, metric
short hundredweights
22.046 23
tons, metric
short tons
1.102 311 3
tons, metric
troy ounces
32,150.75
tons, net register
cubic feet of permanently enclosed
space for cargo and passengers
100
tons, net register
cubic meters of permanently enclosed
space for cargo and passengers
2,831 684 7
tons, shipping
cubic feet of permanently enclosed
cargo space
42
620
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From To Multiply by
tons, shipping
cubic meters of permanently
enclosed cargo space
1.189 307 574
tons, short
avoirdupois pounds
2,000
tons, short
kilograms
907.184 74
tons, short
long hundredweights
17.857 14
tons, short
long tons
0.892 857 1
tons, short
metric tons
0.907184 74
tons, short
short hundredweights
20
townships (US)
sections
36
townships (US)
square kilometers
93.239 572
townships (US)
square statute miles
36
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
square feet
27,878,400
miles, square statute
square meters
2,589,988.110 336
miles, square statute
square yards
3,097,600
yards
centimeters
91.44
yards
feet
3
yards
inches
36
yards
meters
0.914 4
yards
miles
0.000 568 18
yards, cubic
bushels
21.696 227
yards, cubic
cubic feet
27
yards, cubic
cubic inches
46,656
yards, cubic
cubic meters
0.764 554 857 984
yards, cubic
gallons
201.974 0
yards, cubic
liters
764.554 857 984
yards, cubic
pecks
86.784 91
yards, square
acres
0.000 206 611 6
yards, square
hectares
0.000 083 612 736
yards, square
square centimeters
8,361.273 6
yards, square
square feet
9
yards, square
square inches
1,296
yards, square
square meters
0.836127 36
yards, square
square miles
0.000 000 322 830 6
Note: At this time, only three countries— Burma, Liberia, and the US— have not adopted the International System of Units
(SI, or metric system as their official system of weights and measures. Although use of the metric system has been
sanctioned by law in the US since 1866, it has been slow in displacing the American adaptation of the British Imperial
System known as the US Customary System, The US is the only industrialized nation that does not mainly use the metric
system in its commercial and standards activities, but there is increasing acceptance in science, medicine, government, and
many sectors of industry.
621
Appendix F:
Cross-Reference List of Country Data Codes
FIPS 1 0-4: Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions (FIPS PUB 10-4) is
maintained by the Office of the Geographer and Global Issues (Department of State) and published by the National Institute
of Standards and Technology (Department of Commerce). These two-character alphabetic codes are included in the text of
the Factbook in the Data code entry under the Government category. FIPS 10-4 codes are intended for general use
throughout the US Government, especially in activities associated with the mission of the Department of State and national
defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard. Except for
the numeric codes, ISO 31 66 codes have been adopted in the US as FIPS 1 04-1 : American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of Special Sovereignty for Information Interchange.
Internet:
This is a provisional compilation that generally agrees with the ISO 3166 two-character alphabetic codes.
Entity
FIPS 10-4
ISO 3166
Internet
Comment
1 38 N
725 E
Prussia [region]
Germany, Poland, Russia
53 00 N
14 00 E
Pukapuka Atoll
0 12 N
6 39 E
Sapporo [US Consulate General]','c6c96137f7b19324e38be1de5535fbd08d2ea8d3622cc04c5dae3deb1ad41997','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e15c071f9013606e461247e0d72612306b091ee23669fcd8fa12ec34dc3ff64',1999,'AF','Afghanistan','space',1091,'AF
AF
AFG
004
AF
34 31 N
69 12 E
Kaduna
37 00 N
73 00 E
Valletta [US Embassy]
37 00 N
73 00 E
Wales [region]','c750173f836bae7d88bed0d1753ad6cd01f240855e2b9a9cbd96e15dac151933','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a76f6cb69879421546edcbe2aa94a96b2221157648aff597b0e05b8cd1aa19a9',1999,'AL','Albania','space',1092,'AL
AL
ALB
008
AL
Tirane (see Tirana)
19 50 E
Tirol [region]
Austria, Italy
11 00 E
Tobago [island]','51c8b6094fbc0879b4226f5628267026cb5838145977c474ec68c3e68edbfe53','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('388f67d52f7c04aec41b559452084da0b8643b254bc942122437cfb5f1364dc8',1999,'AS','American Samoa','space',1093,'AQ
AS
ASM
016
AS
14 20 S
170 00 W
Edinburgh [US Consulate General]
14 13 S
169 35 W
Maputo [US Embassy]
14 16 S
170 42 W
Palawan [island]
171 15 W
Swan Islands
14 18 S
170 42 W
Tyrol, South [region]','585cd4e9d34c29079b03dadb556b3c745adbbdd9ff3bcc74682c1c277fd3dbff','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f8a3a2bb927c4cb92c5a3c5f46e45a7375da8cb9c255ec83da90b388986604',1999,'AO','Angola','space',1094,'AO
AO
AGO
024
AO
5 33 S
12 12 E
Cabot Strait
Atlantic Ocean
47 20 N
59 30 W
Caicos Islands
8 48 S
13 14 E
Lubumbashi
Democratic Republic of the Congo
11 40 S
27 28 E
Lusaka [US Embassy]
F / Zambia''" Ail''
Lusaka Jgk L.
\\ NAMIBIA Tl
walvis A Wi"ih0ek r BOTSWANA
tlkland Islands
slas Malvinas)
mistered by U.K.,
;ed by ARGENTINA)
nley
- ’Scotia . 5ea
South Georgia and the V
South Sandwich Islands
(administered by U.K.,
claimed by ARGENTINA)','6d34159c857e88d76727e28995ef8575bad604eca8fadc5f2d2365462fcfff75','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fa20cd3c0abd8afaa7b0f6ac7e42e818fcaa16cf819f34a680e32c6b2e2144c',1999,'AQ','Antarctica','space',1095,'AY
AQ
ATA
010
AQ
ISO defines as the territory south of 60
degrees south latitude
66 30 S
139 00 E
Aden
70 00 W
Alexandria
67 00 S
163 00 E
Balochistan [region]
79 30 S
49 30 W
Berlin [US Branch Office]
62 56 S
60 34 W
Denmark Strait
Atlantic Ocean
67 00 N
24 00W
D''Entrecasteaux Islands
90 35 W
Philip Island
73 30 S
12 00 E
Quemoy [island]
Taiwan
24 27 N
118 23 E
Quito [US Embassy]
79 30 S
162 00 W
Roseau
80 00 S
180 00 E
Ross Island
81 30 S
175 00 W
Ross Sea
76 00 S
175 00 W
Rota [island]
67 24 S
179 55 W
Senyavin Islands
Federated States of Micronesia
6 55 N
158 00 E
Seoul [US Embassy]
South Korea
37 34 N
127 00 E
61 00 S
45 00 W
South Ossetia [region]
62 00 S
59 00 W
South Tyrol [region]
66 30 S
139 00 E
Thailand, Gulf of
Pacific Ocean
10 00 N
101 00 E
Thessaloniki [US Consulate General]
72 20 S
99 00W
Tiberias, Lake','487e5020af3508f7ca72739ebceba799ac2da61f1619d8dc885ee6a625805d42','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20cbea546aedd8c8e55ab53320c0fb3d0460e9b55afa93f83c7921d3da086edc',1999,'AG','Antigua and Barbuda','space',1096,'AC
AG
ATG
028
AG
14 34 N
90 44 W
Antipodes Islands
17 38 N
61 48 W
Barcelona [US Consulate General]
16 55 N
62 19 W
Red Sea
Indian Ocean
20 00 N
38 00 E
Revillagigedo Island
17 06 N
61 51 W
Saint Lawrence, Gulf of
Atlantic Ocean
62 00 W
Saint Lawrence Island','eb3391a3784cb1eaee6b235f080b8396ba2ed4870d8ed666a107d40ea33b02e6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('672c1b346f470b8d1a16022250659d40b315909a88b82e5fc3707506f8001bc0',1999,'AR','Argentina','space',1097,'AR
AR
ARG
032
AR
34 36 S
58 27W
Bujumbura [US Embassy]
35 00 N
63 00 W
Panama [US Embassy]','7894663e69df3b10648b1fcc5bb3b5bd69a5570618e68e8a980ab008d9fc4098','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70eadd5ca979f34b80df4b440895f8827b6a6576b42d5e87381f961659ff2d8',1999,'AW','Aruba','space',1098,'AA
AW
ABW
533
AW
Ashmore and Cartier Islands
AT
—
—
—
—
ISO includes with Australia
12 33 N
70 06W
Oresund (The Sound)
Atlantic Ocean
55 50 N
1240 E
Orkney Islands','9a432c2bcd6b2186c71defffeba19d10a2752b2404eb03deb9e1ec88a387f725','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b376d9b653475153584768ab89abf9589bd03adcf7dc4de48897a6da45f3b44',1999,'AU','Australia','space',1099,'AS
AU
AUS
036
AU
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
10 12 S
142 16 E
Banks Island
27 28 S
153 02 E
Britain (see Great Britain)
35 17 S
149 08 E
639
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Canton (Guangzhou)
23 15 S
155 32 E
Caucasus [region]
Russia
42 00 N
45 00 E
Cayenne
10 25 S
105 39 E
Christmas Island (Kiritimati) [Pacific Ocean]
159 00 E
Louisiade Archipelago
30 07 S
147 24 E
Maddalena, (sola
37 49 S
144 58 E
Melilla
1 1 5 50 E
Pescadores [islands]
Taiwan
1 1 9 30 E
Peshawar [US Consulate]
151 13 E
T Tahiti [island]
43 00 S
147 00 E
Tasman Sea
Pacific Ocean
4 30 S
168 00 E
Taymyr Peninsula (Poluostrov Taymyr)
Russia
76 00 N
104 00 E
Tbilisi [US Embassy]
Baker Island (U.s.) .
Lord Howe
Island
(AUSTL.)
<5reat Australian
Bight
Tasmania
Hqf art.
Canberra^ // Sydney
Tasman Sea
AUCKLAND
ISLANDS *
(N.Z.)
SNARES ISLANDS
(N.Z.)
Macquarie
Island
(AUSTL.)
- - - _ ^DtHci!p,CircleJ66033'')
Ross Sea
Ross Ice. Shetf
* Timor
/''££ Gul f of
Carpentaria
NEW Gl
V ''C f -Portia
i Moresby
>0, . SOLOMON
■jj''"**- ISLANDS
Honiara^ ^
Coral Sea
Islands
,J (AUSTL.)
New
Caledonia *
(FRANCE)
Noumea Vs
^VANUATU
* Port-Vila
Funafuti*
TUVALU*
J ir . SAMOA /
Wallis and Anial
I Futuna .* . /
/ ,, Mata-Utu "* *
I (FRANCE) Pago Pago /
% American /
,* Samoa /
4? (U-S.) /
'' '' Niue /
''(HZ.) /
* Nukualofa /
* TONGA /
Alice Springs
SOUTH
PACIFIC
rreat A u^t rail an
Bteht*
Canberra ,
Melbourne
Tasman Sea
Lord Howe
Island
(AUSTL.)
NEW
ZEALAND*''
OCEAN
KERMADEC
ISLANDS
(N.Z.)
r
'' Wellington
^Christchurch
/ CHATHAM ISLANDS
(N.Z.)
AUCKLAND
ISLANDS S
(N.Z.)
‘SNARES ISLANDS
(N.Z.)
* ^BOUNTY ISLANDS
/ (N.Z.)
NTIPODES ISLANDS y
(N.Z.) /
Macquarie
Island
(AUSTL.)
ntarctic„Circle (66"33’)
June 1 999
aSerbia and Montenegro have asserted the formation
of a joint independent state, but this entity has
not been formally recognized as a state by the
United States.
b Nineteen of 26 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Boundary representation is not necessarily authoritative.
802632AI (R00349) 6-99
Tropic of Cancer
* ©&»
North Pacific
mxgiimxtsm.
Oceian
tSHAlia
Pitcairn Islands
: !U:Ki) ''
Christchurch
South Island;
802646AI (R0211 1)6-99
<&)
SOUTH AMERICA
802636AI (R02108) 6-99
SOUTHEAST ASIA','aa385a3af9ddeba3777393f1db31f0a501105fdb72b6dcc1c464f0b15978588e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a4059584bacbe533fdaab9e8e0d47d3e86c3d5b94e139839abd85d9055df5f',1999,'AT','Austria','space',1100,'AU
AT
AUT
040
AT
47 48 N
13 02 E
Samar [island]
48 12 N
16 22 E
Vientiane [US Embassy]
Laos
17 58 N
102 36 E
Vilnius [US Embassy]','1bc2fd9e7cf3acfc3b1f1aac51fbc41a55e97ac4e2d7f4bbb5e60897b6ccd556','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3f1170f2dd2fed349b6249f9c52790e5d20fbcb8a58a688d678ac299bd67cba',1999,'AZ','Azerbaijan','space',1101,'AJ
AZ
AZE
031
AZ
The Bahamas
BF
BS
BHS
044
BS
40 23 N
49 51 E
Baku [US Embassy]
40 23 N
49 51 E
Baky (see Baku)
40 23 N
49 51 E
Balabac Strait
Pacific Ocean
7 35 N
117 00 E
Balearic Islands
46 40 E
Nagoya [US Consulate]','e1fde2f2faacb1d680f3b012db1957ee2bfee89ee51ef867368277e7a2f36b9e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a66986e18b5dce2d014758f90a980d9a5ea915b162277605a97a6f204db131a',1999,'BH','Bahrain','space',1102,'BA
BH
BHR
048
BH
Baker Island
FQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
50 35 E
Manaus [US Consular Agency]','db8fb6d39eded04c9b16f7475ecefa879384692f7332100ed5dc50a84939992f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b770d899fa0812006334b377cfb90bc5f4665f76efc26bdc15629b9338f9eb6',1999,'BD','Bangladesh','space',1103,'BG
BD
BGD
050
BD
23 43 N
90 25 E
641
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Dhofar [region]
24 00 N
90 00 E
East Siberian Sea
Arctic Ocean
74 00 N
166 00 E
East Timor (Portuguese Timor)','946760da18902fea25472e2f7844f8bca8e1b7f16d3fe1bb953a349f06726e48','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77b969a51203f381c395abc7edd9da14fa461cec49bb6ad6b835f93058d66f94',1999,'BB','Barbados','space',1104,'BB
BB
BRB
052
BB
Bassas da India
BS
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
13 06 N
59 37 W
Brisbane','24f672934fc2922266385e3c83b5464cf15c963c0079616bdd179b16b174c0ac','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('188f235d38eb9aa438b22cc2c0cf6b85e4be7f3ffe1b84c56b98e282de2a0b3d',1999,'BY','Belarus','space',1105,'BO
BY
BLR
112
BY
53 00 N
28 00 E
Bengal, Bay of
Indian Ocean
15 00 N
90 00 E
Bering Sea
Pacific Ocean
60 00 N
175 00 W
Bering Island
Russia
55 00 N
166 30 E
Bering Strait
Pacific Ocean
65 30 N
169 00 W
Berkner Island
28 00 E
C Cabinda [province]
53 54 N
27 34 E
Minorca Island (Isla de Menorca)','cc472be3c13967bfc3f9e60c4e1df7d1752c285c57031b498e60f4fc585f8b97','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('791d4e06e16ebcbe2c2d3db6a9974cd9e96948ac1aab8b7adc0780f9716fe3a2',1999,'BE','Belgium','space',1106,'BE
BE
BEL
056
BE
622
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
4 25 E
Aozou Strip
50 50 N
4 20 E
Bubiyan [island]','36c72cdc06955c8a669df15e3cf0c18c69e89e12a6dadd40c7016da0841040d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdfedcebc3ef5c5a06982124f27514857b857284b0c5ba4d257a6a899768096e',1999,'BZ','Belize','space',1107,'BH
BZ
BLZ
084
BZ
17 30 N
88 12 W
Belle Isle, Strait of
Atlantic Ocean
'' 51 35 N
56 30 W
Bellingshausen Sea
Pacific Ocean
71 00 S
85 00 W
Belmopan
17 15 N
88 46 W
Belorussia
88 45 W
British Solomon Islands','c741e26bdb2c3fdd23212070606d7ce7f5e00a8fa5ef3c68859b882ef138dfef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ede9c0183aa5a5c8ab4f040ce23630aaf01aa0693ef58eb661f1c676fc00e32',1999,'BJ','Benin','space',1108,'BN
BJ
BEN
204
BJ
6 21 N
2 26 E
Courantyne River
Guyana, Suriname
5 57 N
57 06 W
Crete [island]
9 30 N
2 15 E
Daito Islands
6 29 N
2 37 E
Portuguese East Africa','706dde92672a8d2a85ece063b1207caef026ce1a788ca052aad22803aae721a4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb3cdf3a23cd77f99c8bf5a837d687b1fc17b54015917494e4b0d9055f2e5669',1999,'BM','Bermuda','space',1109,'BD
BM
BMU
060
BM
64 46 W
Hanoi [US Embassy]
Vietnam
105 51 E
Harare [US Embassy]
(U.K.)
dklahomia Ci tyB
^Memphis
<rf Phoenix fAlbUquerqu6^ ,
r / rC ''
■ ff .
El Paso
•''''7-Ciudad7N^''i''?"i.
^4 '' vU; Juarez J 1
{'' \\ "Hermosillb .
*■-, %-A v . •‘>#^hihuahu^-
^ > • ; p*\\ iP:
) \\\\ 7^ v.c/.rtSifB
;«f '' ■ '' ■ \\ r
^ Atlanta 1 ^charleston
./•. " . -/\\ Ocea n
■ j \\
i . „ New Orleans.''
San- Houston ;
Antonio • , , "v
t
''•} . Jacksonville^
xMiaml,
X*
iriilf of Mexico
Torreon f
r^Matamoros
1.4 r(J
Scale; 1:38,700,000
Lambert Conformal Conic Projection,
standard parallels 37 ’N and 65 ‘N
MazatlanV |
Guadalajara/’^
_ J7-:V-*-
600 Kilometers
ISLAS
REVILLAGIGEDO
(MEXICO)
300 600 ft
Boundary representation is
not necessarily authoritative.
120
Acapulcoj
?.Pui
A THE BAHAMAS
. Nassau
. &
CUBA '''' '' HAITI;
\\ ~ Port-auPI
pfinee
^ BELIZE
r ~r y^Belmopan
CiLATEMAl.A •
San Salvador"','767fa6efa835cf90a4b244e02bec704c42a1dfdb1a99831c6f2aa13dabb00ab8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07d5ffc6ba6d7028601d42b26ca166ac2ef6407e9ebea3c1b91f779a6633be42',1999,'BA','Bosnia and Herzegovina','space',1110,'BK
BA
BIH
070
BA
44 00 N
18 00 E
Bosporus [strait]
Atlantic Ocean
41 00 N
29 00 E
Bothnia, Gulf of
Atlantic Ocean
20 00 E
Bougainville [island]
44 00 N
18 00 E
Hispaniola [island]
Dominican Republic, Haiti
18 45 N
71 00 W
Ho Chi Minh City
Vietnam
10 45 N
106 40 E
Hokkaido [island]
43 52 N
18 25 E
Sarawak [state]','ba738c7e92ccbfaa9e9847a4190a5ea7c273a3f62f14a8e95f154b1b168f97ab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('694c7bc56c054fb77845cd616b338e71477fdc06f2e5273b52dfaff02099a933',1999,'BW','Botswana','space',1111,'BC
BW
BWA
072
BW
22 00 S
24 00 E
Beijing [US Embassy]
24 45 S
25 55 E
Galapagos Islands (Archipielago de Colon)
Gaborone
Port Elizabeth
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
Scotia Sea
South Georgia and the \\
South Sandwich Islands
(administered by U.K.,
claimed by ARGENTINA)','18325a7239682c434f1910acf4fc53f10b0c46577b5e97404f0d74d6e6c1b738','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52ae0cccfc115c880df63ede4456ff08178a976c9e2717a76b646fc83be5458d',1999,'BV','Bouvet Island','space',1112,'BV
BV
BVT
074
BV
(NORWAY)
■
-• . Pc
Omc
urman
Khai
. ★
toum
SUD
AN
C
.Juba
r
uiidaan
< Mecca
ARABIA
Port Sucliih *
Mumbaf 1
(Bombay) ''
»TOOim GtMofAde n
^Djibouti
1 ETHIOPIA^
isangani
tic /
RWANM
c £
> UGANDA
ampala/
(NORWAY)
SOUTH ORKNEY
ISLANDS
JGQLA
dhoek pj B0XSWANA
- i
Gaborone
..TANZANIA •
Liar ci. aaiaar..','c5daf11a3ab8358e013d9fbf4160f8cc70ec6b5ed54bf142f31f8ff1510406a2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26b88547d73e7a78947340671f2189d20cca08b36b255820fe16d3f22441429f',1999,'BR','Brazil','space',1113,'BR
BR
BRA
076
BR
1 27 S
48 29 W
Belep Islands (lies Belep)
47 55 W
Bratislava [US Embassy]
3 51 S
32 25W
Fernando Po [island] (see Bioko)
343 S
38 30 W
Fort-de-France
3 08 S
60 01 W
Manchukuo
20 30 S
28 51 W
Mas a Tierra (Robinson Crusoe Island)
30 04 S
51 11 W
Port-of-Spain [US Embassy]
8 03 S
34 54W
Redonda [island]
22 54 S
43 14 W
Rio de Oro
3 51 S
33 49 W
Rockall [island]
0 23 N
29 23 W
Saint Peter Port
12 59 S
38 31 W
Salzburg
23 32 S
46 37W
Sao Pedro e Sao Paulo, Penedos de [rocks]
0 23 N
29 23 W
Sao Tiago [island]
Cape Verde
15 05 N
23 40 W
Sao Tome [island]
20 31 S
29 20 W
Tripoli','475f841d44d26138e51bc4999327219e49a88042068e3a7678c225f005393e43','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75519279e234b0334ab413b92d707004693304c92e8b0db1fc94a78424206d55',1999,'IO','British Indian Ocean Territory','space',1114,'10
10
IOT
086
10
British Virgin Islands
VI
VG
VGB
092
VG
Brunei
BX
BN
BRN
096
BN
6 00 S
71 30 E
Channel Islands
Guernsey, Jersey
49 20 N
2 20 W
Charlotte Amalie
Virgin Islands
18 21 N
64 56 W
Chatham Islands
7 20 S
72 25 E
Diego Ramirez [islands]
6 00 S
71 30 E
Okhotsk, Sea of
Pacific Ocean
53 00 N
150 00 E
Okinawa [island group]','10e6dbd5920845982148c76e35f1fb0d102d6aaffcca0ed5488bd22477f7f0a9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b4c6abdfecdc90187cb9d33c827f8b222e171986d39aecc42f020878fea8d00',1999,'BF','Burkina Faso','space',1115,'UV
BF
BFA
854
BF
Burma
BM
MM
MMR
104
MM
ISO uses the name Myanmar
12 22 N
1 31 W
Outer Mongolia
13 00 N
2 00W
Ural Mountains
Kazakhstan, Russia
60 00 N
60 00 E
Ussuri River
China, Russia
48 28 N
135 02 E
V
Vaduz','89e86b79dc53f6db1f0225f5ebb4bea16f7cb5a87aa1a252835fac5ce2a4fa5d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('361d4f66124ed51e5b01d8d7e49edc9072c869355eeb683c920e2255d1faaaed',1999,'KH','Cambodia','space',1116,'CB
KH
KHM
116
KH
103 50 E
Anglo-Egyptian Sudan
13 00 N
105 00 E
Kanton Island
13 00 N
105 00 E
Khuriya Muriya Islands (Kuria Muria Islands)
104 55 E
Phoenix Islands','93ffaca73386acc948e717625552190391cadb046c47e349274590d777c5b73b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('906c851075e0d1c08cb31e37b54da1c7e5171cd6c947b65270d91a5a044ea03d',1999,'CM','Cameroon','space',1117,'CM
CM
CMR
120
CM
4 03 N
942 E
Douglas
Man, Isle of
54 09 N
4 28 W
Dover, Strait of
Atlantic Ocean
51 00 N
1 30 E
Drake Passage
Atlantic Ocean
60 00 S
60 00 W
Dubai [US Consulate General]
6 00 N
12 00 E
French Guinea
3 52 N
11 31 E
Yap Islands
Federated States of Micronesia
9 30 N
138 00 E
Yaren','513827cb6b3ce03972aefa9a9a513a3dff04dda7476838ec6942b4b9f1906097','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a196c4c0dc9ed46a811e157b0e2735232b7cf6233a3fef2b5d067d16277020f',1999,'CA','Canada','space',1118,'CA
CA
CAN
124
CA
Cape Verde
CV
CV
CPV
132
CV
79 30 N
90 00 W
Azad Kashmir
68 00 N
70 00 W
Baghdad [US Embassy temporarily suspended;
US Interests Section located in Poland''s embassy
in Baghdad]
75 15 N
121 30 W
Banks Islands (lies Banks)
51 03 N
114 05 W
California, Gulf of
Pacific Ocean
28 00 N
112 00 W
Campbell Island
76 00 N
87 00 W
Dhahran [US Consulate General]
78 00 N
103 00 W
Ellesmere Island
81 00 N
80 00 W
Ellice Islands
63 36 W
Halmahera [island]
54 00 N
62 00 W
Laccadive Islands
45 31 N
73 34 W
Moravia [region]
Czech Republic
17 00 E
Moravian Gate
Czech Republic
17 50 E
Moroni
52 00 N
56 00 W
650
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Niamey [US Embassy]
45 20 N
73 58 W
Ouagadougou [US Embassy]
46 20 N
63 20 W
Prince Edward Islands
1 1 9 00 W
Principe [island]
52 00 N
72 00 W
Queen Charlotte Islands
53 00 N
132 00 W
Queen Elizabeth Islands
78 00 N
95 00 W
Queen Maud Land [claimed by Norway]
43 55 N
59 50 W
Safety Islands (lies du Salut)
60 09 W
Saint Paul Island
43 39 N
79 23 W
Torres Strait
Pacific Ocean
10 25 S
142 10 E
Torshavn
49 16 N
123 07 W
Vancouver Island
49 45 N
126 00 W
Van Diemen Strait (Osumi Strait)
Pacific Ocean
31 00 N
131 00 E
Vatican City [US Embassy]
Holy See
41 54 N
12 27 E
Velez de la Gomera.Penon de','d0efbf7fd10dd795f30880222070e16bd568715a5c9ea392a54e2df2d67a31f6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e0356076ed7ae1f075777c962296b6040bf8802f275dfce8da191b36ed975ee',1999,'KY','Cayman Islands','space',1119,'CJ
KY
CYM
136
KY
19 20 N
81 23 W
Georgetown
The Gambia
13 30 N
1447 W
Georgetown [US Embassy]
19 20 N
81 20 W
Grand Turk','f50dad9500809dff6e2ed895b77b395f5b459ce6272c05ff963e18efceb8b3d3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f23add0821a5461e1da4ed14030a1939c111e5434556376d30fb721d8318775',1999,'CF','Central African Republic','space',1120,'CT
CF
CAF
140
CF
422 N
18 35 E
Banjul [US Embassy]
The Gambia
13 28 N
16 39 W
Banks Island
7 00 N
21 00 E
Ceuta','bc87720b80d0dfc03583dbc8a15238205c5dd359d899cbc0b37f873817b334a2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae955d1675cc180acf2349b4367962ee4ef1474e4a21472b5282e42413d3408a',1999,'CL','Chile','space',1121,'Cl
CL
CHL
152
CL
24 30 S
69 15 W
Athens [US Embassy]
56 30 S
68 43 W
Diomede Islands
Russia [Big Diomede], United States
[Little Diomede]
65 47 N
169 00 W
Diu
27 07 S
109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean
34 00 N
129 00 E
Eastern Samoa
55 59 S
67 16 W
Horne, lies de
33 00 S
80 00 W
Jubal, Strait of
Indian Ocean
27 40 N
33 55 E
Judaea [region]
Israel, West Bank
31 35 N
35 00 E
Jutland [region]
33 38 S
78 52 W
Mascarene Islands
Mauritius, Reunion
21 00 S
57 00 E
Maseru [US Embassy]
27 07 S
109 22 W
Passion, lie de la
Clipperton Island
10 17 N
109 13 W
Pashtunistan [region]
Afghanistan, Pakistan
32 00 N
69 00 E
Peking (see Beijing)
33 38 S
78 52 W
Rocas, Atol das
26 28 S
105 00 W
Salisbury (see Harare)
26 21 S
79 52 W
San Andres y Providencia, Archipielago
26 17 S
San Jose [US Embassy]
33 27 S
70 40 W
Santo Antao [island]
Cape Verde
17 05 N
25 10W
Santo Domingo [US Embassy]','064c2b160e9dba8de2a52b3902de0529f04cbe6d8603d7c9e8f428568dccb3e5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42ed7028f2c46b0345960c88c1fc6fb09e3a4a14212128b1397dfeb6cb8a0d32',1999,'CN','China','space',1122,'CH
CN
CHN
156
CN
see also Taiwan
39 56 N
116 24 E
Beirut [US Embassy]
23 06 N
113 16 E
Canton Island (Kanton Island)
39 39 N
104 04 E
Chennai (Madras) [US Consulate General]
35 00 N
105 00 E
China, Republic of
Taiwan
23 30 N
105 00 E
Chisinau [US Embassy]
Moldova
47 00 N
28 50 E
Choiseul [island]
23 06 N
113 16 E
Guantanamo Bay [US Naval Base]
19 00 N
109 30 E
644
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Halifax [US Consulate General]
42 00 N
1 1 3 00 E
Ionian Islands
36 00 N
84 00 E
Kuril Islands
Russia [de facto]
46 10N
152 00 E
Kuwait [US Embassy]
44 00 N
124 00 E
Manchuria
44 00 N
124 00 E
Manila [US Embassy]
116 24 E
Pelagian Islands (Isole Pelagie)
31 14 N
121 28 E
Shenyang [US Consulate General]
41 48 N
123 27 E
Shetland Islands
42 00 N
86 00 E
Sint Eustatius [island]
Netherlands Antilles
17 29 N
62 58 W
Sint Maarten [island]
Netherlands Antilles
18 04 N
63 04 W
Skagerrak [strait]
Atlantic Ocean
57 45 N
9 00 E
Skopje [US Embassy]
The Former Yugoslav Republic of Macedonia
41 59 N
21 26 E
Society Islands (lies de la Societe)
90 00 E
Tibilisi (see Tbilisi)','58f94edcf297908bc8164e1e4ae0172c7e9186117cdf9aa34693cd1de0d24c6a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aac8a4ec67750965f5aeaad97f26c454c93cea0003cc4ca4332162612e240bdd',1999,'CX','Christmas Island','space',1123,'KT
CX
CXR
162
CX
Clipperton Island
IP
—
—
—
—
ISO includes with French Polynesia
18 44 N
64 19 W
Severnaya Zemlya (Northland) [island group]
Russia
79 30 N
98 00 E
Shaba [region]
Democratic Republic of the Congo
8 00 S
27 00 E
655
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Shag Island
(AUSTL.)
Ashmonfe and
Cartier Islands
(AUSTL.)
Timor
Sea £?<
neSSS^'' *
Til Gulf of
Carpentaria
rf’ PortV^."
A:i Moresbyp-^-
fiv. •/
Cairnsy ''j ,
S?X.-
_ Jrop[cr3f_Capricqm j£3°27'')
Alice Springs
f> " "','e673b83a0fe797ea8df42dba4a7aa10538c86d2a1bff99afcb08dbede39f92e7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('114111ea5250df5508fc71cb7392b652ce8540660c65692ee609d4663d77c256',1999,'CC','Cocos (Keeling) Islands','space',1124,'CK
CC
CCK
166
CC
12 30 S
96 50 E
Colombo [US Embassy]
12 30 S
96 50 E
Kerguelen, lies
French Southern and Antarctic Lands
49 30 S
69 30 E
Kermadec Islands
12 10 S
96 55 E
West Korea Strait (Western Channel)
Pacific Ocean
34 40 N
129 00 E
West Pakistan','8ad1f118ab1cc485c6421692671475735bf51cd59fdb9def8a88b0c9b224b443','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18a32c76410af1429b2f6375e1942539a9af39a9b27c6e50bea8f27bd7cc4fcc',1999,'CO','Colombia','space',1125,'CO
CO
COL
170
CO
10 59 N
74 48 W
Bashi Channel
Pacific Ocean
22 00 N
121 00 E
Basilan Strait
Pacific Ocean
6 49 N
122 05 E
Basque Provinces
4 36 N
74 05 W
638
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Bohemia [region]
Czech Republic
14 30 E
Bombay (see Mumbai)
4 00 N
90 30 W
Malta Channel
Atlantic Ocean
56 44 N
26 53 E
648
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Malvinas, Islas
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Mamoutzou
13 32 N
80 03W
Roosevelt Island
81 30 W
San Bernardino Strait
Pacific Ocean
124 10 E
San Felix, Isla
14 25 N
Serranilla Bank
15 51 N
79 46 W
Settlement, The','f32eb864e623d872bdf6c6e1a8951c6e9e6c99fbf111c3eceede902013b7624e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cc20bd8127a3c492a88d1f41d33b861ff07c081ba9d5ff9e1702291e2a00494',1999,'KM','Comoros','space',1126,'CN
KM
COM
174
KM
Congo, Democratic Republic of the
CG
ZR
ZAR
180
ZR
formerly Zaire
Congo, Republic of the
CF
CG
COG
178
CG
12 15 S
44 25 E
Ankara [US Embassy]
Turkey
39 56 N
32 52 E
Annobon [island]
11 41 S
43 16 E
Mortlock Islands (Nomoi Islands)
Federated States of Micronesia
5 30 N
153 40 E
Moscow [US Embassy]
Russia
55 45 N
37 35 E
Mount Pinatubo','97142a170ddf98760e47019db5ecdd2df9aa555e8f2811a559611e10c5996682','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8b4e40b3e68caf07690de3ba8c24ed488508f7c74b22fe04eb964a7bb113840',1999,'CK','Cook Islands','space',1127,'CW
CK
COK
184
CK
Coral Sea Islands
CR
—
—
—
—
ISO includes with Australia
21 12 S
159 46 W
Axel Heiberg Island
10 53 S
165 49 W
Danish Straits
Atlantic Ocean
58 00 N
11 00 E
Danish West Indies
Virgin Islands
18 20 N
64 50 W
Danzig (Gdansk)
10 53 S
165 49 W
Pusan [US Consulate]
South Korea
35 06 N
129 03 E
P''yongyang
North Korea
125 45 E
Q
Quebec [US Consulate General]
(N.Z.)
Equator
ILES MARQUISES
(Fr. Poly.)
SOCIETY
ISLANDS
(Fr. Poly.)
* ^ o_
Papeete .
ARCHIPEL DES TUAMOTU
(Fr. Poly.)
Frenc.h Polynesia
i (FRANCE) .
MEX1CC
#te6n
*Guadalajarc
. Mexico*
ISLAS
REVILLAGIGEDO
Ciipperton Island
(FRANCE)
Tropic of Capricorn \\ (23°27‘)
ILES TUBUA1
\\ (Fr. Poly.)
Adamstown* pi''c^ji Islands
(u.K.)
Easter Island
(CHILE)
Isla Sala y Com
(CHILE)
SOUTH
PACIFIC
OCEAN
Antarctic Circle (
Nouakchott!','93c86258bc5c0867544486dab20c71f024628d855b1dca4a8047c14df12d7772','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eddafe90f695a0f6b8abc38dd47d0f5738623a703ee60df994e82f6a2ad06789',1999,'CR','Costa Rica','space',1128,'CS
CR
CRI
188
CR
Cote d''Ivoire
IV
Cl
CIV
384
Cl
5 32 N
87 04 W
Cocos Islands
9 56 N
84 05 W
San Juan','d21c45b571427bd5d3d32f6fc83a46dd258dd573319e854670b184d4a66caa01','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2ead36d4230a8a65121cb07a2dc56e9afa54f8016964693e9a62eca8f324839',1999,'HR','Croatia','space',1129,'HR
HR
HRV
191
HR
43 00 N
17 00 E
Daman (Damao)
42 24 N
18 31 E
Pribilof Islands
45 48 N
15 58 E
Zaire
Democratic Republic of the Congo
15 00 S
30 00 E
Zanzibar [island]
Tanzania
6 10 S
3911 E
Zion, Mount
Israel, Jordan
31 46 N
35 14 E
Zurich','4511e6559d0d31f0cdd613efbf1d6a50c088eeefddcdf79b1f9b46bf7d70afcb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa5c3e56739a2f0264fe2d4d5873a298c4e2790d9912e2dc63456ad65d7bfe21',1999,'CU','Cuba','space',1130,'CU
CU
CUB
192
CU
20 00 N
75 08 W
Guatemala [US Embassy]
23 08 N
82 22 W
Hawaii
21 40 N
82 50 W
Kabul [US Embassy now closed]
82 50 W
Pleasant Island
21 40 N
82 50W
Yucatan Peninsula','bfa551d08d42817eef783afed85709ec145c0e8d4c6b0bd6e9fe46702eb6f88d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7118d10fbb2eae6268a360e5119d3b28a6b6d80e8394499a65a0696e4b621566',1999,'CY','Cyprus','space',1131,'CY
CY
CYP
196
CY
Czech Republic
EZ
CZ
CZE
203
CZ
35 10N
33 22 E
Leipzig [US Consulate General]
35 ION
33 22 E
Nightingale Islands
Saint Helena
37 25 S
12 30 W
Nomoi Islands (Mortlock Islands)
Federated States of Micronesia
5 30 N
153 40 E
North Atlantic Ocean
Atlantic Ocean
30 00 N
45 00 W
North Channel
Atlantic Ocean
55 10N
5 40W
North Frisian Islands
Denmark, Germany
54 50 N
8 12 E
North Island
Beirut
LEBANON/
Haifa At
ISRAELII
Port Jerusalem?/
Mediterranean I Sen.
^Alexandria*
AI Bagrah*
Allubafcj
Ad Darnman^
Dhtte
■fturaydah
UNITED ARAB
/ EMIRATES ,
Oe Facto Boundary','1828f54a8e99eea39d70da4b03f79f47b55f3b5fbad4b1f553040434785f821c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d9db3c885f28b57fd73d5237267d611d7fd43203f44f07bf3d4db3f4cfba9c4',1999,'DK','Denmark','space',1132,'DA
DK
DNK
208
DK
55 10N
15 00 E
Bosnia
55 40 N
12 35 E
Coral Sea
Pacific Ocean
15 00 S
150 00 E
Corfu [island]
56 00 N
9 15 E
Juventud, Isla de la (Isle of Youth)','fec7aebe0ed12240bbc242699b8bc5281ef7b05380731b25df450de45ab2e2f9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('881842e75a6c15a8fb6c2c6be76603b9f068cbecf4a37b21afbd30ed1437ea74',1999,'DJ','Djibouti','space',1133,'DJ
DJ
DJI
262
DJ
623
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
11 30 N
43 00 E
Agalega Islands
11 30 N
43 15 E
Dnieper [river] (Dnyapro, Dnepr, Dnipro)
Belarus, Russia, Ukraine
46 30 N
32 18 E
Dniester [river] (Nistru, Dnister)
Moldova, Ukraine
46 18 N
30 17 E
Dodecanese [islands]
11 30 N
43 00 W
French Sudan
11 30 N
43 00 E
French Togo
,r seated & 1 ,000,000941 ,% i/s&s
■A"-i •-/-/>
Lambert Conformal Conic Projection^
standard parallels I2°N and 3b °^Addi3^>aI>’
;;JivS'''':h\\''’3d_Q;KilprneteTlsv'' s^fb bfl | jjL/jr;
, •Berbt^a:,"4^-
Hargeysa -’f J''SOl
m)
Golan Heights is Israeli-occupied Syria. ''
West Bank and Gaza Strip are Israeli-occupied with current
status subject to the Israeli-Palestinian Interim Agreement — ''
permanent status to be determined through further negotiation.
Israel proclaimed [erusalem as its capital in 1950, but the US, like
nearly all other countries, maintains its Embassy in Tel Aviv.
300 Miles
Bdurida ry representation Is ''
not necessarily authoritative.
802640AI (R02107) 6-99
MIDDLE EAST
NORTH AMERICA
rn"^: Cast
; Cherskiy
A'',\\ ''A 5 ea
I-R0SSM''
j^\\nady r * - . V,
Provide niya.y.J
10 Cvfc-
\\ . 14 Si
.Pevek
fvNorne
Bering
;- 1 -AL^rt? ''
jvjs’v . ^ '' ■£ <
'' y ? ; ‘ C -# j ''.,t
l,\\
A/''1 filh’smfii
* -* ls(aiftt 4 ^h"ny
(^mEk. Elizabeth
islaws • -f §
CrreenUnd .Sea
Itseq<Jdrtoorrtflit.
(Scoresfcysun d)''|
„ Jan Mayen ,
(NORWAY) /
.£/
Cx''','5b00e20ba09ab04bc57cfd67de012e42f17cd1895a509a76436b0680ed976229','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55662147b6f36a1bba17b310e2c370975ad0a0f61a1ac8dacfbcd77d7316c241',1999,'DO','Dominican Republic','space',1134,'DR
DO
DOM
214
DO
East Timor
—
TP
TMP
626
TP
FIPS includes with Indonesia
18 28 N
69 54 W
Sao Paulo [US Consulate General]','7bc5905705f55f1000940b33e0e537c446a7c41f274d606b41ff7369d0258c3d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f990a9702c63c9db48a032bd4b761cc8592254f52f9a040f0b87568b32f731c8',1999,'EC','Ecuador','space',1135,'EC
EC
ECU
218
EC
0 00 N
90 30 W
Commander Islands (Komandorskiye Ostrova)
Russia
167 00 E
Conakry [US Embassy]
0 00 N
90 30W
Galilee [region]
2 13 S
79 54 W
H Ha''apai Group
0 13 S
78 30 W
R
Rabat [US Embassy]','720ba98e2616eba2dcce3c596e7583c78bf65d3b0b5e9a216c2d666fe7a18f0b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef72c60a1456269144ddcdc0a7b2c8cdfecec453a41bc54c4c4e20f6585d2f0',1999,'EG','Egypt','space',1136,'EG
EG
EGY
818
EG
31 12 N
29 54 E
Algiers [US Embassy]
30 03 N
31 15 E
Calcutta [US Consulate General]
30 13 N
33 09 E
Gilbert Islands
30 20 N
32 23 E
Great Britain
30 02 N
32 54 E
649
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Mogadishu
29 30 N
34 00 E
Singapore [US Embassy]
Suez, Gulf of
Indian Ocean
Sulu Archipelago','6dca56ea68d93446ffb81624bb43ae5db25b4a17875470296c2bea590a478a1c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b307621d1139722680f5557ce25842c3fb59345f799a1a765a5267b8ccd72c6',1999,'SV','El Salvador','space',1137,'ES
SV
SLV
222
SV
13 42 N
89 12 W
Santa Cruz
Bolivia
17 48 S
63 10W
Santa Cruz Islands
diorfOuMs^
j -ii/ V ‘C-f
''T^gliCfcafpIv''., \\
^^^SfeARAOUA \\
Sen
Managua
"•{
802633A! (R02067) 6-99
Add time zone number to local time to -
Subtract time zone number from UTC tt
j Greenland Sea
i stand of
NeUffouiidiand
Norwegian
Sea ;
b®#-
FRANZ IOSEF
LAND !
*NOVAYA /
fEMLYA / £±
3 < M
rLUjtlwvskl
Novosibirsk f
•* st. Pierre
~hnd Miquelon
I NORTH I
I |
iATLANTIcj
T |
: OCEAN
ft *|MALTA -- ■ j
PS1A ! Mediterijanean Sea i LEBJ
^ i ISRAEL J
^ArotfAtturmriM
I
Th|E QAMBIA^
QUlMEA-BISSAt
SIERRA! LE&flyVT051^
I DJIBOUTI 1-^','15c14ffd4a0af1adc867550cdd0f43f0a22bb936b991f0b823792c58b5b8a13c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd7927f0e16a4b46989710f75c12fd04a7d90582dba80573a3995492b400e589',1999,'GQ','Equatorial Guinea','space',1138,'EK
GQ
GNQ
226
GQ
1 25 S
5 36 E
Antananarivo [US Embassy]
3 30 N
8 42 E
Biscay, Bay of
Atlantic Ocean
44 00 N
4 00 W
Bishkek [US Embassy]
0 55 N
9 19 E
Corn Islands (Islas del Maiz)
0 59 N
9 33 E
Enderbury Island
3 30 N
8 42 E
Finland, Gulf of
Atlantic Ocean
60 00 N
27 00 E
Florence [US Consulate General]
3 45 N
8 47 E
Malacca, Strait of
Indian Ocean
2 30 N
101 20 E
Malagasy Republic
1 30 N
10 00 E
653
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Riyadh [US Embassy]
2 00 N
Spanish Morocco','580e8af8a75122f7a60d3fd03a976f094cbdfb48f4e97df519aa79d179ed1d98','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('052ec60eebde1429f7391003432b91b4d534cabd282ca22d852334e37d2df247',1999,'ER','Eritrea','space',1139,'ER
ER
ERI
232
ER
15 20 N
38 53 E
Asmera (see Asmara)
15 20 N
38 53 E
Assumption Island','5fd1bb3489780284f4d9b83d07930a0cc99b55c0e6157de07b92a56e78436bac','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ddc15a27a77ac238d6377b1d494080946cb33e6a38187f7abb375918f2fb26c',1999,'ET','Ethiopia','space',1140,'ET
ET
ETH
231
ET
Europa Island
EU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Falkland Islands (Islas Malvinas)
FA
FK
FLK
238
FK
8 00 N
38 00 E
Acapulco
9 02 N
38 42 E
Adelie Land (Terre Adelie) [claimed by France]
it, Helena)
Sf. Helena
SOUTH ist'' ""“T
Falkland Islands
(Islad Malvinas)
Jmlntfetered by U.K.
imed L>y ARQEltnH,
TLANTIC
OCEAN
St. Helena!
iu.k.) ]
IfBURUHDI
il TANZANIA }
Feriijii
m yl
SAUDI \\
\\KABIA
jwwffN |
3 1
r*
YEMEN J\\
4 | Arabian
'' - L 1 S£i
c» Socotra
_ ) (YEMEN! j
yj','9fdff642008c5856fe5b0c8d762b448d1b4f815351893f6deb44bf7daf9f4bfb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a173e0cfe8510afce2ff06372f40988c2f577c4d52151bd15e668ebc2128be1',1999,'FJ','Fiji','space',1141,'FJ
FJ
FJI
242
FJ
18 20 S
178 30 E
Lefkosa (see Nicosia)
12 30 S
177 30 E
Ryukyu Islands
178 25 E
Sverdlovsk (see Yekaterinburg)
Russia
60 39 E
Swains Island
18 00 S
178 00 E
Vladivostok [US Consulate General]
Russia
43 10N
131 56 E
Volcano Islands','f1dd3805bf69ad2ce0a16726a79a488be3d736be919537234431247636f1a34f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2445b06f3356fb0cc93604b54314dc3823ba63fd0bcdf26467ed705277338ae',1999,'FI','Finland','space',1142,'FI
FI
FIN
246
FI
60 15 N
20 00 E
Alaska
60 10N
24 58 E
Hermosillo [US Consulate]','17edc915f4afe34d74bab2b074476cb6b35002d2a400471589a9ced77562a849','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a74e659b420416e255b1e24e79c5f75ccf94744487ce7c4bcf9e5dee9ea2baa2',1999,'FR','France','space',1143,'FR
FR
FRA
250
FR
France, Metropolitan
FX
FXX
249
FX
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
44 50 N
0 34 W
Borneo [island]
Brunei, Indonesia, Malaysia
0 30 N
114 00 E
Bornholm [island]
42 00 N
9 00 E
Cosmoledo Group (Atoll de Cosmoledo)
43 18 N
5 24 E
Martin Vaz, Ithas
48 52 N
2 20 E
Pascua, Isla de (Easter Island)
48 35 N
7 45 E
Stuttgart','72b6daae752466637cf604994e9bc2c0de1938a9d88d0f384a468e5acb64f6a1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2d8015768d3737806b8161fc9fbd8506aa9493679e1dc9584c0ec2764f4f5e',1999,'GF','French Guiana','space',1144,'FG
GF
GUF
254
GF
4 56 N
52 20 W
Cebu [US Consular Agency]
5 17 N
52 35 W
Devon Island
5 20 N
52 37 W
Sahel
Burkina Faso, Cape Verde, Chad, The Gambia,
Guinea-Bissau, Mali, Mauritania, Niger, Senegal
15 00 N
8 00W
Saigon (see Ho Chi Minh City)
Vietnam
10 45 N
106 40 E
Saint Brandon (Cargados Carajos Shoals) [island]
(DENMARK) -h,
, /-
sNuuk (Godthibi
ARCTIC OCEAN
Greenland Sea
Jan Mayen
(NORWAY)
Longyea
Norwegian
Sea
Reykjavik
NORWAY*
* Svalbard
(NORWAY)
i SWEDEN,
Torshavn A (den.)
ED Nortk
LATd
Island'' of
Newfoundland
Si. Pierre
and Miquelon
(FRANCE)
NORTK
ATLANTIC
OCEAN
kr-Amsterd
^GDOM Jnetm
Celtic <6^
, Guernsey <u.k>. m
Jtnty nuu-1
Fcologne Berlin
• GERMAN^
MLuxembouroB
• YFenna''Aj^pJWIa’
-^AUSTRIAf ★Bud
tJubljjU^^nUNGARY J
ROMANIA}
l*g^i''BuChares
r-
Mediterranean Sea
bo
FRANZ JOSEi
LAND
* Svalbard
(NORWAY)
Barents Sea
SWEDEN y
Arkhangelsk
SEVERNAYA
ZEMLYA
Laptev Sea
RUSSIA
Yekaterinburg
\\ Chelyabinsk
Krasnoyarsk
'' ^Honolulu
HAWAIIAN
ISLANDS Jp
(U.S.)
Johnston Atoll
(U.S.)
, Kingman Reef (U.S.)
Palmyra Atoll (U.S.)
* Klritimati
(Christmas Island)
(KIRIBATI)','13fb18bc0c3f989f4a72d47faf71ae4608ec5444736dd4ef8433c1d5a31bc6fe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd2a1f8a78a0b39d10edd4a4225459a80f35c34566d1f4959ebbaefab2d47f5b',1999,'PF','French Polynesia','space',1145,'FP
PF
PYF
258
PF
ISO includes Clipperton Island
French Southern and Antarctic
Lands
FS
TF
ATF
260
FIPS 10-4 does not include the French-
claimed portion of Antarctica (Terre
Adelie)
23 20 S
151 00 W
Avarua
16 30 S
151 45 W
Bordeaux
23 09 S
134 58 W
Gaspar Strait
Pacific Ocean
3 00 S
107 00 E
Geneva [US Consular Agency, US Mission to European
Office of the UN and Other International Organizations]
9 00 S
139 30 W
Marseille [US Consulate General]
17 32 S
149 34 W
Paramaribo [US Embassy]
17 00 S
150 00 W
Socotra [island]
17 37 S
149 27 W
Taipei
Taiwan
25 03 N
121 30 E
Taiwan Strait
Pacific Ocean
24 00 N
1 1 9 00 E
Tallinn [US Embassy]
19 00 S
142 00 W
Tubuai Islands (lies Tubuai)
23 00 S
150 00 W
Tunb al Kubra [island]
Iran
26 14 N
55 19 E
Tunb as Sughra [island]
Iran
26 14 N
55 09 E
Tunis [US Embassy]','2e17aea3050b101e2e6b1d43eef287a1a1e3acb4fb7307af8050b513757be185','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c0e0ac94c8801787833d9849814ee9f9e4d057ca3018f395761df593bc5f1e',1999,'GA','Gabon','space',1146,'GB
GA
GAB
266
GA
The Gambia
GA
GM
GMB
270
GM
Gaza Strip
GZ
—
—
—
—
9 27 E
Ligurian Sea
Atlantic Ocean
9 00 E
Lilongwe [US Embassy]
Bongo
Ascension
(St. Helena)
SOUTH
ATLANTIC
OCEAN
St. Helena
(St. Helena)
St. Helena
(U.K.)
TRISTAN DA CUNHA (St. Helena)
Gough Island
* (St. Helena)
^Kisangani
DEMOCRATIC
RWAND.
REPUBLIC
sOF THE CONGO
Lake
Tanganyika
mm','50857e73cd2d962249346bb5eca8b6c4c535f84bbe472420d7d832b86ae15764','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('373bf3cc6e84f6b985ca8e13443acb15748181bc93103f5704cdee27eb5169cd',1999,'GE','Georgia','space',1147,'GG
GE
GEO
268
GE
43 00 N
41 00 E
Abu Dhabi [US Embassy]
42 20 N
44 00 E
South Pacific Ocean
Pacific Ocean
30 00 S
130 00 W
South Sandwich Islands
41 43 N
44 49 E
Tegucigalpa [US Embassy]
44 49 E
Tien Shan [mountains]
China, Kyrgyzstan
80 00 E
Tierra del Fuego
Argentina, Chile
69 00 W
Tijuana [US Consulate General]','4eff299bea8535de222dcc5a6ee7627e33a5f72f5d80d6e291bae32ac667b74c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0523034a4bb30969cf70cc256ea47154182eead5bd6904b008552cc570333c2c',1999,'DE','Germany','space',1148,'GM
DE
DEU
276
DE
48 30 N
11 30 E
Beagle Channel
Atlantic Ocean
54 53 S
68 10W
Bear Island (see Bjornoya)
Svalbard
74 26 N
19 5 E
Beaufort Sea
Arctic Ocean
73 00 N
140 00 W
Bechuanaland
52 31 N
13 24 E
Berlin, East
52 30 N
13 33 E
Berlin, West
52 30 N
12 20 E
Bern [US Embassy]
48 00 N
8 15 E
Black Rock
50 44 N
7 05 E
Bophuthatswana
53 44 N
7 25 E
East Germany (German Democratic Republic)
52 00 N
13 00 E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean
34 00 N
129 00 E
East Pakistan
50 07 N
840 E
Franz Josef Land [islands]
Russia
81 00 N
55 00 E
Freetown [US Embassy]
52 00 N
13 00 E
German Southwest Africa
51 00 N
9 00 E
9 59 E
Hamilton [US Consulate General]
51 19 N
Lemnos [island]
11 35 E
Musandam Peninsula
Oman, United Arab Emirates
56 24 E
Muscat [US Embassy]
51 00 N
1300 E
Schleswig-Holstein [region]
54 31 N
9 33 E
Scopus, Mount
Israel, West Bank
35 14 E
Scotia Sea
Atlantic Ocean
56 00 S
40 00 W
Scotland [region]
911 E
Sucre
Bolivia
65 17 W
Suez Canal
51 00 N
11 00 E
Thurston Island
53 22 N
5 20 E
659
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Latitude
Longitude
Entry in The World Factbook
(deg min)
(deg min)
West Island','83ea6cac69cb7c3cd4a07aca38a6621f927492c84a4beae61f99334118888bcf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d26af22355b731452cde7cdb0088242fe6cc2c14b82bdef55df2e2c743180e5',1999,'GH','Ghana','space',1149,'GH
GH
GHA
288
GH
5 33 N
0 13 W
Adamstown
Pitcairn Islands
25 04 S
130 05 W
Adana [US Consulate]
Turkey
37 01 N
35 18 E
Addis Ababa [US Embassy]
800 N
2 00 W
Golan Heights [region]
Syria
KESHi
35 45 E
Good Hope, Cape of','530fa9f903791b48c7e5943532a0b2b86fc8b4418189adde22a4250101dcb014','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a579447ece966335cb7cdacab81f28531a843af4366bf13336a52c51f2e31da',1999,'GI','Gibraltar','space',1150,'Gl
Gl
GIB
292
Gl
Glorioso Islands
GO
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
3611 N
5 22 W
Gibraltar, Strait of
Atlantic Ocean
35 57 N
5 36 W
Gidi Pass','cf7f495454b4bbfc1e9b834c471747909ea4e9ad0d5e70c3b8407e3b6653d525','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9b0209fd6ecbedd570c1496b66dd29eefc94fcdbec71a52a1bc34f004554c7',1999,'GR','Greece','space',1151,'GR
GR
GRC
300
GR
38 00 N
25 00 E
Aegean Sea
Atlantic Ocean
38 30 N
25 00 E
Afars and Issas, French Territory of the (FTAI)
24 42 E
Andros Island
The Bahamas
77 57 W
Anegada Passage
Atlantic Ocean
63 40 W
Angkor Wat [ruins]
23 44 E
Attu Island
39 40 N
19 45 E
Corinth
37 56 N
22 56 E
Corisco [island]
35 15 N
24 45 E
Crimea [region]
37 00 N
25 10 E
Czechoslovakia
Czech Republic, Slovakia
49 00 N
18 00 E
D Dahomey
36 00 N
27 05 E
Dodoma
Tanzania
611 S
35 45 E
Doha [US Embassy]
38 30 N
20 30 E
Ionian Sea
Atlantic Ocean
38 30 N
18 00 E
Irian Jaya [province]
39 54 N
Leningrad (see Saint Petersburg)
Russia
59 55 N
30 15 E
647
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Lesser Sunda Islands
39 15 N
26 15 E
Leyte [island]
36 10N
28 00 E
Rhodesia
37 48 N
26 44 E
Sanaa [US Embassy]
40 38 N
22 56 E
Thimphu','37303beeed6c4ce02a436e28d421d0e6de1957f70a6f2b3d8e4983b180483a65','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66a3d6e8f65a44755a1fb6fff3ae2e44a5349cc08324c759b0913b6e5b220bbe',1999,'GD','Grenada','space',1152,'GJ
GD
GRD
308
GD
12 07 N
61 40 W
Grytviken
61 45 W
Saint George''s Channel
Atlantic Ocean
6 00 W
Saint Helier
12 20 N
61 30 W
Southern Rhodesia','bbe2fefab48f81f4f3dc71a3327479243cecc37182a889441f8a55be7c34e607','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4529ee1ff8f03e528aa0534fbb9347d9d1fe8154afced262a0ff20b4f01d1bc',1999,'GP','Guadeloupe','space',1153,'GP
GP
GLP
312
GP
16 00 N
61 44 W
Basseterre
63 04W
Saint Martin (Sint Maarten)
Netherlands Antilles
63 04W
Saint Paul Island','8c604dd3978e130dc19e35d463587a0fb2df0dbd6213a7c447a75cbadaa0bed4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('605130cfa81e20363195237b08f213e1c2912faa916a26f58b55e9aa0fe8af59',1999,'GU','Guam','space',1154,'GQ
GU
GUM
316
GU
13 28 N
144 45 E
Ajaccio
France (Corsica)
41 55 N
8 44 E
Akmola (see Astana)
13 28 N
144 45 E
Hague, The [US Embassy]
(U.S.) *
Hagatna
(Agana)
FEDERATED STATES OF MICRONESIA.
Palikir
•* .
Wake Atoll
(US.)
.MARSHALL
: p ISLANDS
^Majuro
Timor
Sea
/•(% Gulf of
Carpentaria
• • r ''Kn
Bismarck Sea
PARJA T.
NEW Gl
■if,. \\\\b.''
f I Port
/).} Moresby |
Equator
Yaren* NAURU
.SOLOMON
ST''V ISLANDS
Honiara^ '' •
^Tarawa
Howland Island (U.S.)
Coral Sea
Islands
J (AUSTL.) :n
^VANUATU
* Port-Vila
New ygk, .<{
i Caledonia ^jjA, '' *
•- (FRANCE) *
NoumeaV'' ’
Alice Springs','8781acce74dc27effaa5b1d05e1ff93f47660541b45872f0a0bcd4e9576e445d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4494a95fcd82108452084a9d3852019082623fc74f80a7093fee4916f9ebce18',1999,'GT','Guatemala','space',1155,'GT
GT
GTM
320
GT
14 38 N
90 31 W
Guinea, Gulf of
Atlantic Ocean
3 00 N
2 30 E
Guayaquil [US Consulate General]','3dae3092c24cf27d132c152c5faa41f902436b536e8d114ff9104a28f9b40100','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad176df93250e9ebb1dc4df8a0ff4323718a211d1dd9115699efb89e1ccce21b',1999,'GG','Guernsey','space',1156,'GK
—
—
—
—
ISO includes with the United Kingdom
2 32 W
Saint Petersburg [US Consulate General]
Russia
30 15 E
Saint-Pierre
49 26 N
221 W
Saxony [region]','d07f17c775fa85a55722eeac17d30166b50dfb0171b4b1afa11876544e65f6a4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e018b3aced03a32acbf316cdb7625e27877ec15156949a6df0985607b526263',1999,'GN','Guinea','space',1157,'GV
GN
GIN
324
GN
13 43 W
Congo (Leopoldville)
Democratic Republic of the Congo
30 00 E
Con Son [Islands]
Vietnam
8 43 N
106 36 E
Cook Strait
Pacific Ocean
41 15 S
174 30 E
Copenhagen [US Embassy]
11 00 N
10 00W
French Indochina
Cambodia, Laos, Vietnam
15 00 N
107 00 E
French Morocco','21007fddee09d27e30671170848f99c8e45ca9afd96f53e2ed19ce796f8fb7bc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ef45af2bb3267e3260466150c2e7725d40f91d60e0a807e118c1c959d42293',1999,'GW','Guinea-Bissau','space',1158,'PU
GW
GNB
624
GW
624
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
11 25 N
16 20 W
Bikini Atoll
11 51 N
15 35 W
Bjornoya (Bear Island)
Svalbard
74 26 N
19 5 E
Black Forest
12 00 N
15 00W
Portuguese Timor (East Timor)','0f79479eba4ebbe7a9f80ca746894a9e0f75c314787b958f3af986964aae71f5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c501bbf9bd0522dffb1014c8e370c3e10fee067ba5101101d507d3f2771d2e74',1999,'GY','Guyana','space',1159,'GY
GY
GUY
328
GY
59 00 W
British Honduras
6 59 N
58 23 W
Etorofu (Iturup) [island]
Russia [de facto]
44 55 N
147 40 E
F
Farquhar Group (Atoll de Farquhar)
6 48 N
58 10W
German Democratic Republic (East Germany)','98a859a02d1ff0e44807b804bb3bfd81176a4c5557d2526d81c1e2ffedd084c4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3638ca1f1ebdc210f7ca5ceb981cd97d4ffd44ef38ede55d4c5f137901c7433c',1999,'HM','Heard Island and McDonald Islands','space',1160,'HM
HM
HMD
334
HM
Holy See (Vatican City)
VT
VA
VAT
336
VA
53 06 S
73 30 E
Hejaz [region]
53 06 S
73 30 E
Mecca
53 00 S
72 30 E
Shag Rocks','74e231c109db0e60f5cacd4e0580410c398060629b6f51420710f7515b703483','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bff1f5d367887ee0962db0267b1fbf6109899abe7a86cd0d94ed0124c1d1c22',1999,'HN','Honduras','space',1161,'HO
HN
HND
340
HN
83 56 W
Sydney [US Consulate General]
14 06 N
87 13 W
Tehran [US post not maintained; representation
by Swiss Embassy]
Iran
35 40 N
51 26 E
Tel Aviv [US Embassy]','51da7ce36aabb3871d02f32d893a6dd84a43f77db2aadfb91b1f9eed367e9793','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d957f2a44071c28af9672eac3c2b4933f4233a850d945ae26b13ac51d224442e',1999,'HK','Hong Kong','space',1162,'HK
HK
HKG
344
HK
Howland Island
HQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
22 15 N
114 10 E
Honiara
22 18 N
114 10E
Kra, Isthmus of
Burma, Thailand
10 20 N
99 00 E
Krakatoa [volcano]
114 10 E
New York, New York [US Mission to the
United Nations (USUN)]
22 17 N
114 09 E
Victoria','d1628f8960e97a491ca12befb7e880dd7c2637431957db3b5fa520405fccd59e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55ef6cfd6891a9b46fc77394175fc76458eabba79aa07b9fece2389de6389665',1999,'IS','Iceland','space',1163,'1C
IS
ISL
352
IS
19 00 N
111 30 W
Rhodes [island]
UNITE© STATES
, "Bethel Mt. McKinley
c • ■ . (highest'' point in Fairbank;
, North America, 61 94 m)» -.s"-; ,
,/V
17.3jyaldez/
- f Kodiak \\v 7
uulfnf * -
a \\ kv''-LVV.
"?7 v‘ r ^ \\ \\ *£r? \\\\ • #
into A &aW&~} \\
Reykjavik
isiilaq-fV Denmark
(Ammbssalik) .,
* strait
a'' ^ Watson/.''; ''A- - lA'' Yellojyjcnife *.
Atlulvtf.t
’^/EdmontonA,; A .
•Vancquveir >. "^‘.Calgary
U V''. ''* Re8«na.
a.s ;<Res6lu4
;/?• Vi
Baffin
0 $?,■%■ Island ,
.. Kangcrliissniaq
U; - v (Sondre Stronff iord)
\\ U’ < fc. \\ /
\\ X// :■ . Nuuk \\ /
\\ . (Godthab), X
: , -^Narsarsuaq
/
iu vik — (. T''^isuwa . .. ''j r \\m>s \\ J» } \\
./. T/*-, Cambridge Bay •; ; r-S-L- S 4"A j , Paa
...- utpiocnyt ,<V“M O k P''X ^ Strait (Fredc
A :■; J-XV* MAr \\
•■ -f X ''*:ch.) Bay — "I.X /fv" \\ \\ /"
Paamiut V
(Frederikshab) ''
Kangiqcliniq > A V*^v Q
Si
A''-v
(Rankin Inlet)
V » \\ iT77";. 0 \\ Uiln-ador Sea
(7 V, Mv“l,v* r;;>. ... \\
C A N A D A ^ 7
Hudson Bay
Happy Valiev1
- • ■ teoosefeayA*
Scheffeiyille# '' , f * /
-•.v.
Churchill \\
''St (F“rt o*®1**) ■ iff "\\if/
'' AY ; '' . . .
»pA a .
1 ! a»sJ f , ■ ^
•f,A Island of
A • Newfoundland
St.'' John''s*
Asaskatoon , \\ V Winnipeg
■>!. A
Winnipeg*
MoosoneeA A
Pierre
„\\ and Miquelon
(FRANCE)
\\}y ‘ .
^/ChdrlqUqlc^nUsydney
Qudbe^:
Montreal" , A.
Lakcv
V . .. ■''*./ \\
t'' Fredericton \\
£/'' .AA qa- v A "•■ — h— r — ■ Lake?
! • ":. LAUSi^erity^A^.^
4 a A .''A i “ 7
^ <■* V'' Minneapolis*^ «*“%». t '' T .?/, i ,niew vt
e ''■ 7
/ 1^. >f ■ *?. • • inunaui
z U H IT E D \\
Milwaukee^
VDetroifrJL /ysz ,r'' ''■•§<■ * •// .$•
j ^Philadelphia
Cleveland i$ .fo''lialtin
^7A!?n*^A%%shinB,on'' DC-
f IndianaDolls - - ", N O I* i
— - ^ Indianapolis
A^|St. Louis7
§l-T. t
J. Norfolk
ST A T E S
N or t h
E
At la n t i c','99290c1b6ea581264b0f6febe43e6eb552444453d382e48a08fb17aa1855e4fb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b2b9b25e356eb222d9a1a94ddeffef5b92ff9a27305a53c90c480dde8748aed',1999,'IN','India','space',1164,'IN
IN
IND
356
IN
11 30 N
72 30 E
635
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Amirante Isles (Les Amirantes)
12 00 N
92 45 E
Andaman Sea
Indian Ocean
10 00 N
95 00 E
Andorra la Vella
23 16 N
77 24 E
Biafra [region]
18 58 N
72 50 E
Bonaire [island]
Netherlands Antilles
12 ION
68 15 W
Bonifacio, Strait of
Atlantic Ocean
41 01 N
14 00 E
Bonin Islands
22 32 N
88 22 E
Calgary [US Consulate General]
13 04 N
80 16 E
Chesterfield Islands (lies Chesterfield)
20 10N
73 00 E
Damascus [US Embassy]
Syria
33 30 N
36 18 E
Danger Islands (see Pukapuka Atoll)
20 42 N
70 59 E
Djibouti [US Embassy]
14 20 N
74 00 E
Godthab (Nuuk)
32 42 N
74 52 E
Jammu and Kashmir [region]
India, Pakistan
34 00 N
76 00 E
Japan, Sea of
Pacific Ocean
40 00 N
135 00 E
Jars, Plain of
Laos
19 27 N
103 10 E
Java [island]
10 00 N
73 00 E
Laccadive Sea
Indian Ocean
76 00 E
Lagos [US Embassy]
73 00 E
La Paz [US Embassy]
Bolivia
68 09 W
La Perouse Strait
Pacific Ocean
45 45 N
142 00 E
Laptev Sea
Arctic Ocean
76 00 N
126 00 E
Las Palmas
13 04 N
80 16 E
Madrid [US Embassy]
8 17 N
73 02 E
Minsk [US Embassy]
18 58 N
72 50 E
Munich [US Consulate General]
77 12 E
New Guinea
Indonesia, Papua New Guinea
5 00 S
140 00 E
New Hebrides
8 00 N
93 30 E
Nicosia [US Embassy]
27 50 N
88 30 E
Sinai Peninsula','9295c5e0ee31b45bc119c50b306053859067899e37ee8b09854a2295d42fe57b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11cd6a904c7d316811ca51a9058e3b2b1b3cde07247a812b5d107f03618448f6',1999,'ID','Indonesia','space',1165,'ID
ID
IDN
360
ID
Iran
IR
IR
IRN
364
IR
8 20 S
115 00 E
Bali Sea
Indian Ocean
7 45 S
1 1 5 30 E
Balintang Channel
Pacific Ocean
19 49 N
121 40 E
Balintang Islands
2 00 S
121 00 E
Celebes Sea
Pacific Ocean
3 00 N
122 00 E
Celtic Sea
Atlantic Ocean
51 00 N
6 30 W
Central African Empire
5 00 S
120 00 E
Dutch Guiana
9 00 S
126 00 E
Easter Island (Isla de Pascua)
128 00 E
Hamburg [US Consulate General]
138 00 E
Irish Sea
Atlantic Ocean
5 20W
Iron Gate
Romania, Serbia and Montenegro
44 41 N
22 31 E
Islamabad [US Embassy]
6 10 S
106 48 E
Jamestown
Saint Helena
15 56 S
5 44 W
Jammu
7 30 S
110 00 E
Java Sea
Pacific Ocean
5 00 S
1 1 0 00 E
Jeddah (see Jiddah)
0 00 N
1 1 5 00 E
Kamaran [island]
6 07 S
105 24 E
Krakow [US Consulate General]
9 00 S
120 00 E
Lesvos [island]
3 35 N
98 40 E
Mediterranean Sea
Atlantic Ocean
36 00 N
15 00 E
Melbourne [US Consulate General]
2 00 S
28 00 E
Mombasa
102 30 E
Naxcivan [region]
45 20 E
N''Djamena [US Embassy]
120 00 E
Netherlands Guiana
9 00 S
126 00 E
Port-Vila
Spitsbergen [island]
Svalbard
Stanley
Falkland Islands (Islas Malvinas)
51 42 S
57 41 W
Stockholm [US Embassy]
102 00 E
Sumba [island]
120 00 E
Sunda Islands (Soenda Isles)
Indonesia, Malaysia
1 1 0 00 E
Sunda Strait
Indian Ocean
105 45 E
Surabaya [US Consulate General]
112 45 E
Surigao Strait
Pacific Ocean
125 23 E
Surinam
125 00 E
Timor Sea
Pacific Ocean
128 00 E
Tinian [island]','857ecc3947e37935279c036c3cab33cbdcef03576ee2091b9fdb75788e36a37f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a06d4771e1db68a8c04209a1cb3473c76a369a6eaff927a375ea19101616f185',1999,'IQ','Iraq','space',1166,'IZ
IQ
IRQ
368
IQ
33 21 N
44 25 E
Baki (see Baku)
33 00 N
44 00 E
Messina, Strait of
Atlantic Ocean
38 15 N
15 35 E
Mexico [US Embassy]','eff215166cdfb29bf90407af781d12a7fada65fd03377de2056614e50b02bd2e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('917e398b34c36e51609e770164e766b0dc3e443c7473fe00a5cf8caa491b7677',1999,'IE','Ireland','space',1167,'El
IE
IRL
372
IE
53 20 N
6 15 W
Durban [US Consulate General]
53 00 N
8 00 W
Elba [island]','2d0871285fd2fb2a9eddf2939c1558550e9daad83e10a43255f3dcb224f9e410','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49d382e72c28ca0fc8c4ac5fb7ec140b2aa64ad8bf8042f31aa59da264191c16',1999,'IL','Israel','space',1168,'IS
IL
ISR
376
IL
32 54 N
35 20 E
Galleons Passage
Atlantic Ocean
11 00 N
60 55 W
Gambier Islands (lies Gambier)
32 50 N
35 00 E
Haiphong
Vietnam
20 52 N
106 41 E
Hainan Dao [island]
30 30 N
34 55 E
Negros [island]
32 05 N
3448 E
657
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Latitude
Longitude
Entry in The World Factbook
(deg min)
(deg min)
Terre Adelie (Adelie Land) [claimed by France]
35 35 E
Tibet (Xizang)','64e3955e86f4a8e119a2a2d6d712b3adfa4070111c97cfa1982766d2a101ea17','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b84644115f8a6461f9d9bdb464264f876425b57c5780bfef3aa9cc7dcdd9891b',1999,'IT','Italy','space',1169,'IT
IT
ITA
380
IT
42 46 N
10 17 E
Ellef Ringnes Island
38 30 N
Epirus, Northern
Albania, Greece
40 00 N
20 30 E
Espana
43 46 N
11 15 E
Florida, Straits of
Atlantic Ocean
25 00 N
79 45 W
former Soviet Union (FSU)
Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Formosa [island]
Taiwan
23 30 N
121 00 E
Formosa Strait (see Taiwan Strait)
Pacific Ocean
24 00 N
1 1 9 00 E
Fortaleza [US Consular Agency]
44 25 N
8 57 E
George Town
41 13 N
09 24 E
Madeira Islands
45 28 N
9 12 E
Minami-tori-shima (Marcus Island)
14 15 E
Nassau [US Embassy]
The Bahamas
77 21 W
Natuna Besar Islands
1321 E
Palestine
Israel, West Bank
35 15 E
Palikir
Federated States of Micronesia
158 08 E
Palk Strait
Indian Ocean
Pamirs [mountains]
China, Tajikistan
38 00 N
Pampas [region]
36 47 N
12 00 E
Papeete
12 40 E
Peleliu (Beliliou) [island]
41 54 N
12 29 E
Roncador Cay
40 00 N
9 00 E
Sargasso Sea
Atlantic Ocean
30 00 N
55 00 W
Sark [island]
37 30 N
14 00E
Sicily, Strait of
Atlantic Ocean
37 20 N
11 20 E
Sidra, Gulf of
Atlantic Ocean
31 30 N
18 00 E
Sikkim [state]
46 30 N
10 30 E
South Vietnam
Vietnam
12 00 N
108 00 E
South Yemen (People''s Democratic Republic of Yemen)
45 04 N
7 40 E
Turkish Straits
Atlantic Ocean
40 40 N
28 00 E
Turkmeniya
43 25 N
11 00 E
Tutuila [island]
46 30 N
10 30 E
Tyrrhenian Sea
Atlantic Ocean
40 00 N
12 00 E
u
Udorn (Udon Thani) [US Consulate]','c4c337a46bbef20a0aadf5c69a283bcc2e78815b4527416a0f77777dcba4d8e4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c7dc5fa30aa773599098cef31e91d7b13bf1f9cdafae3389aad30374a23b5ed',1999,'JM','Jamaica','space',1170,'JM
JM
JAM
388
JM
Jan Mayen
JN
—
—
—
—
ISO includes with Svalbard
18 00 N
76 48 W
Kingston','afcbd2c5f7237bf11a2ee6bcba590bd2d4700276f5495ade435520fedef267c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e6dc551ab7f8a945459aa14521c80a068fe6fcb57adb0b01c68330fad831822',1999,'JP','Japan','space',1171,'JA
JP
JPN
392
JP
Jarvis Island
DQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
27 00 N
140 10 E
Bonn [US Embassy]
43 00 N
17 00 E
Dakar [US Embassy]
33 35 N
130 24 E
Funafuti
44 00 N
143 00 E
Holland
36 00 N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34 N
56 15 E
Horn, Cape (Cabo de Homos)
34 20 N
133 30 E
Inner Mongolia (Nei Mongol)
141 20 E
645
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Jakarta [US Embassy]
34 41 N
135 10 E
Kodiak Island
33 00 N
131 00 E
Kyyiv (see Kiev)
24 16 N
154 00 E
Mariana Islands
Guam, Northern Mariana Islands
16 00 N
145 30 E
Marion Island
24 16 N
154 00 E
Mindanao [island]
136 55 E
Naha [US Consulate General]
127 40 E
Nairobi [US Embassy]
140 00 E
Naples [US Consulate General]
26 30 N
128 00 E
Oman, Gulf of
Indian Ocean
24 30 N
58 30 E
Ombai Strait
Pacific Ocean
8 30 S
125 00 E
Oran
34 40 N
135 30 E
Oslo [US Embassy]
20 20 N
136 00 E
Paris [US Embassy, US Mission to the Organization
for Economic Cooperation and Development (OECD),
US Observer Mission to the UN Educational, Scientific,
and Cultural Organization (UNESCO)]
26 30 N
128 00 E
Saba [island]
Netherlands Antilles
17 38 N
63 10 W
Sabah [state]
124 00 E
654
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Sakhalin Island (Ostrov Sakhalin) Russia _ 51 00 N _ 143 00 E
Sala y Gomez, Isla
141 21 E
Sapudi Strait
Pacific Ocean
114 10 E
Sarajevo [US Embassy]
33 45 N
133 30 E
Shikotan [island]
Russia [de facto]
43 47 N
146 45 E
Siam
35 42 N
139 46 E
Tonkin, Gulf of
Pacific Ocean
20 00 N
108 00 E
Toronto [US Consulate General]
25 00 N
141 00 E
Vostok Island','ca49ca0f62d7d845a30cbb89b08010275b2a2ce2b70ff78749b21d2ebd4f1b43','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c1c26a17501c3caf76cbf946330065e7da09c9db6bb7e0aba5aca3d9e828a07',1999,'JE','Jersey','space',1172,'JE
—
—
—
—
ISO includes with the United Kingdom
Johnston Atoll
JQ
—
—
—
ISO includes with the US Minor
Outlying Islands
2 37 W
Saint John''s','9781646380fe9cda182a678f84bec62a8e0e2f996c95f6697d24caeeb66aa469','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2f4e9b7253d8d85d600eb7dee35468ff3dae776b7cf778c6780569bfcd9d0b',1999,'JO','Jordan','space',1173,'JO
JO
JOR
400
JO
Juan de Nova Island
JU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
31 57 N
35 56 E
Amsterdam [US Consulate General]
31 00 N
36 00 E
Transkei','c18d594bc6b761f0a4fd2815e78e674adbeeb282db0cbfb0c0705e22f1209435','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('450a7902727e06e4a0aa0a22c2a2f0d85d7377bc25f8f33d4f73e9692092e082',1999,'KZ','Kazakhstan','space',1174,'KZ
KZ
KAZ
398
KZ
51 10N
71 30 E
Aland Islands
43 15 N
76 57 E
Almaty [US Embassy]
43 15 N
76 57 E
Alofi
51 10N
71 30 E
Arab, Shaft al [river]
Iran, Iraq
29 57 N
48 34 E
Arabian Sea
Indian Ocean
15 00 N
65 00 E
Arafura Sea
Pacific Ocean
9 00 S
133 00 E
Aral Sea
Kazakhstan, Uzbekistan
60 00 E
Argun River
China, Russia
53 20 N
121 28 E
Ascension Island
Saint Helena
7 57 S
14 22 W
Ashgabat [US Embassy]
51 10N
71 30 E
Asuncion [US Embassy]','d18baa7ea84ae828b8f6005cdadb3e5b8dd84cd2dbaabc45c25b4ebf545cf2a0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('444472a0b8ed3bf4b8b9b46152bee0d07630beb328febcb1dbaf4a8f294d68ef',1999,'KE','Kenya','space',1175,'KE
KE
KEN
404
KE
Kingman Reef
KQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
4 03 S
39 40 E
Mona Passage
Atlantic Ocean
18 30 N
67 45 W
36 49 E
Nampo-shoto [islands]
★ _ . .
Arabian.
Sea
/ SOMALIA
Mogadishu
LAKSHADWEEP V
(INDIA) ■
La ccadivc
X Sea
^Malc
MALDIVES | o
Bay of
Bengal
BURMA
Rangoon
i Chennai
f (Madras)
ANDAMAN
ISLANDS
'' (INDIA)
w SRI
LANKA
’thaila
v Bangkok >■
ibhnom Renl
. Gulf of ^
W Thailand
Lake ))
an^anyikay
I Lilongwe
I^Dar es Salaam
•^Victoria
\\ MALAWI
Moroni
*
GQMOROS
Mayotte 1 (
(administered by FRANCE, (\\
I claimed by COMOROS) p','2b866372acfbaf8fd70894c3598e87a0e824df19d814edff5e03313a6d7bb0df','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cdf394dc3975cfffb636695e4b7f0d66b841500b63df5df1c8d5586d1687ec2',1999,'KI','Kiribati','space',1176,'KR
Kl
KIR
296
Kl
Korea, North
KN
KP
PRK
408
KP
Korea, South
KS
KR
KOR
410
KR
0 52 S
169 35 E
Bandar Seri Begawan [US Embassy]
Brunei
4 52 S
114 55 E
Banda Sea
Pacific Ocean
5 00 S
128 00 E
Bangkok [US Embassy]
2 49 S
171 40 W
Cape Town [US Consulate General]
1 52 N
157 20 W
Chukchi Sea
Arctic Ocean
69 00 N
171 00 W
Ciskei
3 08 S
171 5 W
Enewetak Atoll (Eniwetok Atoll)
1 25 N
173 00 E
Goa [state]
2 49 S
171 40 W
Karachi [US Consulate General]
157 20 W
Kishinev (see Chisinau)
Moldova
Kithira Strait
Atlantic Ocean
36 00 N
Kobe
0 52 S
169 35 E
Ocean Island (Kure Island)
172 00 W
Pines, Isle of (Isla de la Juventud)
1 25 N
173 00 E
Tatar Strait
Pacific Ocean
50 00 N
141 00 E
Tashkent [US Embassy]
10 06 S
152 23 W
Vrangelya, Ostrov (Wrangel Island)
Russia
71 14 N
179 36 W
w
Wake Island
Wake Atoll
19 17 N
166 36 E
Wakhan Corridor (see Vakhan)
I RAIVAKI > , \\
I (PHOENIX ■ •
V ISLANDS)
VANUATU*
New''''sS^* •
laledonSg''''5
| Norfolk Island |
Sun Sun Sun .
24:00 00:00 1:00
12 12 [ 11
802649AI (R02183) 6-99
Physical Map of the World, August 1 9
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily / AZORES Island / island group
^ Capital
Scale 1 :35,000,000
Robinson Projection
standard parallels 38°N and 38 S
i
Mm
mm
S-*.. v - ;
cJM
i.m
V
Oil''s;''-;;
r%*i*
‘•‘T-
■ • • t -
.O.CiA''N
4l
£S,-
... ili*€,=F’c ,-v '' ''■ £ • ■■ ..*?
JC’f
■■v
.''v >
r'' v,£> ■> fc: **
tr;A
i i
>
*S"V ''
''J&J, L'',,-
■H
?mmm
■;:/rA i
''e&P.tM&Y
-■f''t*'' ''/‘f''i #
. ... . A '' ■ ; .ttO---
. . A ’ '' ■■ ■" V ■ ■ •"'' ’•''■ >«.''>'' .
.V''. "..Ot-i i- .'' v .. f* -ft "is a^t
''■''S>>- < J**»''**V‘ * **-»•* A
.. -
| ., .-- •< ■.* • v''- * • V-'' «. i
;0Y’3mgm:-
*V>f;
vr
^ t '' 5
it.
"P;
ugust 1999
©
<3>
1 ''^’v:? :’■ ■£ - ; - sp :
lAMOOt
August 1999
I
August 1 999
Serbia and Montenegro have asserted the formation
of a joint independent state, but this entity has
not been formally recognized as a state hv the
United States.
Nineteen o! Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Boundary representation is not necessarilv authoritative.
802657AI (R00349) 8-99
Political Map of the World, June 1 999
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily / AZORES Island / island group
★ Capital
Scale 1:35,000,000
Robinson Projection
standard parallels 38"N and 38 "S
u. s..
Anchorage,
Gulf of Alaska
NORTH
PACIFIC
OCE AN
San Francisco 7
U N
Los Angeles
/ Phoenix
/ jSan Diego *
/rijuanar Ei
Mekica IIK~ \\ _ / — A
* * ^Honolulu
HAWAIIAN ^
ISLANDS JP
(U.S.)
Johnston Atoll
(U.S.)
. Kingman Reef (U.S.)
Palmvra Atoll (U.S.''!
Tropic of Cancer (23 27 )
/SMS
REVILLACIGEDO
(MEXICO)
Clipperton Island
(FRANCE)
ine 1999
<2>
^Georgetown
Paramaribo
Funafuti * j
TUVALU’ i
Tokelau * .
(N.Z.)
Wallis and SAM°A . I
/Futuna * , .Apia/
/ Mata-Utu*''* *
I (FRANCE) pago Pag0*/
>. American /
, Samoa /
47 (U.S.) /
''^Nuku''alofa j','14625fb13ba9b56ae2c5f689a7088c17f854b6674120e1b5495bbb8678adfc33','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f166c710c6bdcba9fd467409c75efa9fa3d808fa40f586caf114b19eb5637b9',1999,'KW','Kuwait','space',1177,'KU
KW
KWT
414
KW
29 47 N
48 10 E
Bucharest [US Embassy]
29 20 N
47 59 E
Kuznetsk Basin
Russia
54 00 N
86 00 E
Kwajalein Atoll','5ef686e9847faecd53e8914a0098849cc65fac5301ce6e4324e3634b98e7d8a2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b666f90d6586bc2687af21e947a2feb40480675658049b1e7098bb34c5e1dda7',1999,'KG','Kyrgyzstan','space',1178,'KG
KG
KGZ
417
KG
Laos
LA
LA
LAO
418
LA
42 54 N
74 36 E
Bishop Rock
42 54 N
74 36 E
Fukuoka [US Consulate]
75 00 E
Kiritimati (Christmas Island)','f918b44bd4f15c2ef3dcd2b7c2b35f8a967313daa8a167277cf3d6a4e3cdf78f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66efbcf2b45b105a888e161ae4a7c5a9ef96e6d0ffa4ab69b9be63fcdfa98815',1999,'LB','Lebanon','space',1179,'LE
LB
LBN
422
LB
33 53 N
35 30 E
Belau (Palau Islands)
34 26 N
35 51 E
Tripoli [US post not maintained;
representation by Belgian Embassy]','f85a735bb33ae7353f44732206e12e2842d5b39f44982bf375f7d895f64295e9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e6012466f265ea68dadc7ad6ba5295f14e8c009552e1e4fe14aa2087f9a2f1e',1999,'LS','Lesotho','space',1180,'LT
LS
LSO
426
LS
29 30 S
28 30 E
Batan Islands
29 28 S
27 30 E
Matamoros [US Consulate]','d714dec2651d2146a13da0bdd394c1fd83a1a0d356a090d2ecf5343b8aa7d8a0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80df8ad3a5a37239b66b8b8df68c4ed7ac45f8dbc747407b98279e6436db07a7',1999,'LY','Libya','space',1181,'LY
LY
LBY
434
LY
32 54 N
1311 E
Tristan da Cunha Group
Saint Helena
37 04 S
12 19 W
Trobriand Islands','4a17d4c193d6fd0d456bc1dd0d819e6aa83c64c48e02938f02f149d3c9329b65','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3fbc6cc74e1258be5fd8c2f5398fbff287ddf9ef3c47546cddf04fd8582b319',1999,'LI','Liechtenstein','space',1182,'LS
LI
LIE
438
LI
625
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
47 09 N
9 31 E
Vakhan (Wakhan Corridor)','9cc35819c6d709ddeca887be3f3b1a2ef9b1cfc8324864166128be9ede743328','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0f51319789c636ec0ddcbf901d9970382a974582f81d2ca4e4a3b7eddbf3759',1999,'LU','Luxembourg','space',1183,'LU
LU
LUX
442
LU
Macau
MC
MO
MAC
446
MO
Macedonia, The Former Yugoslav
Republic of
MK
MK
MKD
807
MK
6 10 E
Luzon [island]','711f412ca32745b2f7a707bb905c0fed1f4e2f1e5f78ab79a512c79490b25416','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d23700fb8c5a82377f21bcf081318d3f5ef2364427f4fac996b20b7e6b64f54',1999,'MY','Malaysia','space',1184,'MY
MY
MYS
458
MY
5 26 N
100 16 E
George Town
The Bahamas
23 30 N
75 46W
643
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
George Town
3 10N
101 42 E
Kunashiri (Kunashir) [island]
Russia [de facto]
44 20 N
146 00 E
Kunlun Mountains
100 15 E
Pentland Firth
Atlantic Ocean
3 13 W
Perim [island]
5 20 N
117 10 E
Sable Island
2 30 N
113 30 E
Sardinia [island]','b116ba87dc1577cd1fbd2c1c4ec1bf0ca9a36269903c0aadb5993bb5cb266c69','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0494aa8ba295c844eea15745704036fb63a57964310565eece4c75a63c99b6ec',1999,'MV','Maldives','space',1185,'MV
MV
MDV
462
MV
4 10N
73 31 E
Mallorca (Majorca)
YS/Male
oo
Scale 1:48,000,000
Azimuthal Equal-Area Projection
800 Kilometers
Colombo
E ast ,.z
diiiu r5 ^
s? t
Okinawa x
A v?
SM/f"
''
-floPiS''-
Taiwan
,;^&aiphorrgT''
.Hue
Nannirtg..^^ Kon3 S\\A R-^
^Philippine
Sea
South
Bay of
Bengal
SRI LAMKA
ANDAMAN
ISLANDS
(INDIA)
NICOBAR
ISLANDS
(INDIA)
Equator
4*-''/ ‘-_L China
1 ^VIETMAM
camboH 2 SPRAT/ r
H >9* ISLANDS- ‘
^SdHo Chi Minh
City
miOfPPINES
j>\\ %P%
Bandar Stri ^
jf’rt^LAYSlA
SKuala Lumpur
, ;V
v^ingapore
fej^''SlNQAPORE
Begawan/-
BRUNEL/Rf/’
■C L
4W I Is! DON E*!S 1 A^ -
tffl ji!
1 ym''tigpandanfcl “ftt
h
Indian
O c e a n
, . lava ica
V< , ! Jakarta „
Nf7#"j _ r— -fSnrabaya
> > - Serfiarang
Bandung -
lava
Boundary representation is
not necessarily authoritative.
^AUSTRALIA |
802643AI (R02105) 6-99
art b bean lea:
irranquiU.
Caracas-
ffiZUbto
802635AI (R02068) 6-99
hh; t- -
- - '' i
•• s
. . :"-‘^‘'':^!ffmh '' '' j
. -A
'': ■'' • . i
mPsewa r'' • k,
IMW&wl& - ■ w-
Atlantic
*
Ocean
. "1
HBtiyi . ? .
— — |r~ ”
- - — - — *•-“- —
hgfl
; .. - . ;._:;:i| . .. /,:; _ . ''. • '' -‘ ■ ; '' ..''...
- ''- .-. , "! p>.- ■'' ■ .. :._ : % .''
1 •" #i|
mi&ti-. : ■.-. !:;v '' ''v '' .'':•. ‘ : :
1 -''-.>
CENTRAL BALKAN REGION
802638 A I (R02592) 6-99
COMMONWEALTH OF INDEPENDENT STATES
802644AI (R02110) 6-99
EUROPE
802637AI (R01083) 6-99
-AR I Reunion i
I (FRANCE) |
He iLES CRCtZET
^ | (Er. S. and An^. Lands)
i
i
British Indian
M Odean Territory
6 |™
i
l
i
i
i Cocos
(Keeling) islands
1 (AUSTD {J
i 6 Vi
INDI
Z
<
OC EA
i
tN ;
1
i Antarctic Lands
!
t._ tiES Kerguelen
“ (IT. S. and Ant Lands
5
17:00
18:00
4
6
/— f/*tvternAM
ACAMBODIA)
NORTH
PACI FIC
OCEAN
'' %
northern
Mariana • 1 y
Islands £
»• — i-
'' Ouam |
! , r - !
j ^FEDERATED. STATES C^F HtCRDNESIA
»# * •-
OF5 *
E S I
’•^#T '' ''''
j subtract 24 hours
MARSHALL
, BLANDS* -','61fe7317a243ff4e385cbb2f07420de3e1c3696bd2f801fa319f1075d9ccf240','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a3005c59b289e8049c30be6acd09a7c3af19bee6193c8693a076ef245e440a2',1999,'ML','Mali','space',1186,'ML
ML
MLI
466
ML
12 39 N
8 00W
Banaba (Ocean Island)
17 00 N
4 00W
French Territory of the Afars and Issas (FTAI)
Tombou :tou
*\\SENEGA
la Rani"'' W~u
THE GAMBIA »
Bissau!*^ ^Sj
GUiNEA-BisfAiffiS
Conakry jB
Freetown ^
Bamako^
* 4
Khai town','d7cdadfd92d94c5cfba204db1abca6388623ed248dac01a6d5c1409cbff6836f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b5fa895cb8100353cb3cb93143dfb9a6a9429bbb95b21a6af98132ffc845abe',1999,'MT','Malta','space',1187,'MT
MT
MLT
470
MT
Man, Isle of
IM
—
—
—
—
ISO includes with the United Kingdom
35 54 N
14 31 E
Valley, The','4e75116513bae960ab0ade85746a825e8de958eaa95fedbffddad1911bba8845','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9da42470b80b1c2882a74ad49d1d4e86816d85d9628dd6cebf93f6e49cea8e42',1999,'MH','Marshall Islands','space',1188,'RM
MH
MHL
584
MH
11 35 N
165 23 E
Bilbao
11 30 N
162 15 E
England [region]
11 30 N
162 15 E
642
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Eolie, Isole
9 05 N
167 20 E
Kyushu [island]
7 05 N
171 08 E
Makassar Strait
Pacific Ocean
2 00 S
117 30 E
Malabo
8 00 N
167 00 E
Rangoon [US Embassy]
Burma
16 47 N
96 10 E
Ratak Chain
9 00 N
171 00 E
Recife [US Consulate]','cc747e4decd1993a158bc07d658344a77d9026377a509d7dc5f65bbb00708768','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4957b5d9726f2cf852c175f0f46204b1cf40eeac89b85cd3a36eeb7e1916ae55',1999,'MU','Mauritius','space',1189,'MP
MU
MUS
480
MU
10 25 S
56 40 E
Agana (see Hagatna)
16 25 S
59 38 E
Caroline Islands
Federated States of Micronesia, Palau
7 30 N
148 00 E
Caribbean Sea
Atlantic Ocean
15 00 N
73 00 W
Carpentaria, Gulf of
Pacific Ocean
14 00 S
139 00 E
Casablanca [US Consulate General]
20 10 S
57 30 E
Port Moresby [US Embassy]
19 42 S
63 25 E
Rome [US Embassy, US Mission to the UN Agencies
for Food and Agriculture (FODAG)]
16 25 S
59 38 E
Saint Christopher [island]','75d303414405455198ec4a927e97f0c8bbc5e7eb5a9c44195d0d52718c2b6d61','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61fd5971d39b6840c435adfd9feeb1b86140189fde3978f6bdcc15dda5b14555',1999,'MX','Mexico','space',1190,'MX
MX
MEX
484
MX
Micronesia, Federated
States of
FM
FM
FSM
583
FM
Midway Islands
MQ
—
—
—J
—
ISO includes with the US Minor
Outlying Islands
Miscellaneous (French)
ISO includes Bassas Indian Ocean da
India, Europa Islands Island, Glorioso
Islands, Juan de Nova Island, T romelin
Island
Moldova
MD
MD
MDA
498
MD
16 51 N
99 55 W
Accra [US Embassy]
31 44 N
106 29 W
Cluj-Napoca [US Branch Office]
20 40 N
103 20 W
Guadalcanal [island]
2911 N
118 17 W
Guangzhou [US Consulate General]
29 04 N
1 1 0 58 W
Herzegovina
25 53 N
97 30 W
Mata-Utu
23 13 N
106 25 W
Mbabane [US Embassy]
Swaziland
26 18 S
31 06 E
McDonald Islands
20 58 N
89 37 W
Mesopotamia
19 24 N
99 09 W
Mexico, Gulf of
Atlantic Ocean
25 00 N
90 00 W
Milan [US Consulate General]
25 40 N
100 19 W
Montevideo [US Embassy]
99 31 W
Nuuk (Godthab)
19 00 N
112 45 W
Reykjavik [US Embassy]
11701 W
Timor [island]
19 30 N
89 00 W
Yucatan Channel
Atlantic Ocean
21 45 N
85 45 W
Yugoslavia
Bosnia and Herzegovina, Croatia, The Former
Yugoslav Republic of Macedonia, Serbia and
Montenegro, Slovenia
Z
Zagreb [US Embassy]','5fd7017be15fec83cf494b8c66aafa8762d50c1177e003a69d1dd130ecf87eef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f9a029a98b56a64e1ded0012d15a904df5fecbebd7f080e4b1c3c218cfd96b',1999,'MN','Mongolia','space',1191,'MG
MN
MNG
496
MN
Montenegro*
MW
—
—
—
—
see footnote at end of table
46 00 N
105 00 E
651
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Pacific Islands, Trust Territory of the
Marshall Islands, Federated States of
Micronesia, Northern Mariana Islands, Palau
10 00 N
155 00 E
Pagan [island]
47 55 N
106 53 E
Ullung-do [island]
South Korea
37 29 N
130 52 E
Unimak Pass [strait]
Pacific Ocean
54 20 N
-164 50 W
Union of Soviet Socialist Republics (USSR)
Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
United Arab Republic (UAR)
Egypt, Syria
Upper Volta
HlfiA
i Okhotsk
\\saklwlti ‘
! J*
II ! ^
Jr ■/
. * u,lS- «*;''
^TaN”5’
w
V" occupied by the SOVIET UNION In >943. _
1 administered by RUSSIA, claimed byJAPAM
w^lang Kong
Macau
(PORT, i ''
4 i Arabian
I Sea
_ Bay of _ “
""i’-''1 rzn
ANDAMAHfflyj
| (INDIA)
! v','84058da72823c4bca704d97bd7a8eacfee320a25bc1973736c831c6cfb2504b1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17c3dcf0c8689a5deb0205b0441e6179809d723fbd9d12d4d87e493264a9ee09',1999,'MS','Montserrat','space',1192,'MH
MS
MSR
500
MS
62 14 W
Ponape (Pohnpei) [island]
Federated States of Micronesia
158 15 E
Ponta Delgada [US Consulate]','c0a395c50e62cc01e0e000795b8793d01d9e27c95dcf32ab5249e21b363eeae8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('551383345e3249fbeb77165778c5eff298b0a68a8b5ae23cc33f961bfd6909c8',1999,'MA','Morocco','space',1193,'MO
MA
MAR
504
MA
33 39 N
7 35 W
Castries
32 00 N
5 00 W
French Somaliland
34 02 N
6 51 W
Ralik Chain
32 00 N
7 00 W
Spanish North Africa
Spain (Ceuta, Islas Chafarinas, Mellila,
Penon de Alhucemas, Penon de Velez
de la Gomera)
35 15 N
4 00 W
Spanish Sahara
35 48 N
5 45W
Tarawa [island]','ed836b2422d55eb0c42a7802d9801fff2e20db098024e5b0a786090896e14ebf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67dba4b6f0b89895a621170e6940b7c6c90ee5c7a84bdfff8f80f108acdb19a2',1999,'MZ','Mozambique','space',1194,'MZ
MZ
MOZ
508
MZ
25 58 S
32 35 E
Marcus Island (Minami-tori-shima)
18 15 S
35 00 E
Portuguese Guinea','dcab03cd2b261b88822b3321482fbf251ce770b4d369cc49355ae31da2c12c6f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14db7daf3cb1b8d7150873e0c119e7a843cd0b7ccd54203493389a3d468ca33',1999,'NA','Namibia','space',1195,'WA
NA
NAM
516
NA
22 00 S
17 00 E
Germany, Federal Republic of
22 00 S
17 00 E
Southern Grenadines
22 59 S
14 31 E
Warsaw [US Embassy]
22 34 S
17 06 E
Windward Passage
Atlantic Ocean
20 00 N
73 50 W
Wrangel Island (Ostrov Vrangelya)
Russia
71 14 N
179 36 W
Y
Yalu River
China, North Korea
39 55 N
124 20 E
Yamoussoukro
Cote d''Ivoire
6 49 N
5 17 W
Yangon (see Rangoon)
Burma
16 47 N
96 10 E
Yaounde [US Embassy]
Windhoek r
i * 1','c6aea7084791fb987678ff42463293a6a36253d1faf0bf62e8f8b3f4075f5850','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e22e73ea3ff61653c95bbabcd94d4ff5dc5aa7ea12b5486e17d8b2b8ac6f71',1999,'NR','Nauru','space',1196,'NR
NR
NRU
520
NR
Navassa Island
BQ
—
—
—
—
166 55 E
Plymouth
0 32 S
166 55 E
Yekaterinburg (Sverdlovsk) [US Consulate General]
Russia
56 50 N
60 39 E
Yellow Sea
Pacific Ocean
36 00 N
123 00 E
Yemen (Aden) [People''s Democratic Republic of Yemen]','c3f76c68efdc0c9c71eceed06cfeeb4b17b7276d46be0d592beded0dcf2da3c5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1afb3314cde1e56f73bfabb2d48eae59de054453dc4abad8aa012e663999dc9a',1999,'NP','Nepal','space',1197,'NP
NP
NPL
524
NP
27 43 N
85 19 E
Kattegat [strait]
Atlantic Ocean
57 00 N
11 00 E
Kauai Channel
Pacific Ocean
21 45 N
158 50 W
Keeling Islands','e44cb3f3df31962a479f822cbc2a4713b9cc0299ef34a41603acaab24a246ed1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e91f2115aa4eb4c56cf13f4809590b0060d02e1ee949d815a50a9d34bba124b',1999,'NL','Netherlands','space',1198,'NL
NL
NLD
528
NL
Netherlands Antilles
NT
AN
ANT
530
AN
Amsterdam Island (lie Amsterdam)
French Southern and Antarctic Lands
37 52 S
77 32 E
Amundsen Sea
Pacific Ocean
72 30 S
112 00 W
Amur River
China, Russia
52 56 N
141 10 E
Anatolia [region]
Turkey
39 00 N
35 00 E
Andaman Islands
52 05 N
4 18 E
Haifa
52 30 N
5 45 E
Hong Kong [US Consulate General]
53 26 N
5 30 E
West Germany (Federal Republic of Germany)','c5983581245c40e8685da446592e9d010b77b9437f4fc86c81c32daa59ebb451','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caf8f9b7977c4b8f50ac994b7c213eed70b5cf561ec02954403eceaef6212658',1999,'NC','New Caledonia','space',1199,'NC
NC
NCL
540
NC
19 45 S
163 40 E
Belfast [US Consulate General]
19 52 S
158 15 E
Chiang Mai [US Consulate General]
167 00 E
Luanda [US Embassy]
22 16 S
166 27 E
Novaya Zemlya [islands]
Russia
74 00 N
57 00 E
Nubia','4317e4c92ae9e4542ccb8d9ac8be48fbd1ef24d4d045353581606644de725121','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9709c6018ad7770f79dd3ea7636468fdc0055e4126e27d3af137187ff5f58f',1999,'NZ','New Zealand','space',1200,'NZ
NZ
NZL
554
NZ
49 41 S
178 43 E
Antwerp [European Logistical Support Office]
174 46 E
Auckland Islands
51 00 S
166 30 E
Australes, lies (lies Tubuai)
47 43 S
174 00 E
Brasilia [US Embassy]
52 33 S
169 09 E
Canal Zone
44 00 S
176 30 W
Chechnya (Chechnia)
Russia
43 15 N
45 40 E
Cheju-do [island]
Korea, South
33 20 N
126 30 E
Cheju Strait
Pacific Ocean
34 00 N
126 30 E
Chengdu [US Consulate General]
29 50 S
178 15 W
Kerulen River
China, Mongolia
48 48 N
117 00 E
Khabarovsk
Russia
48 27 N
135 06 E
Khanka, Lake
China, Russia
45 00 N
132 24 E
Khartoum [US Embassy]
39 00 S
176 00 E
North Korea
North Korea
40 00 N
127 00 E
North Pacific Ocean
Pacific Ocean
30 00 N
165 00 W
North Sea
Atlantic Ocean
56 00 N
4 00 E
North Vietnam
Vietnam
23 00 N
106 00 E
North Yemen (Yemen Arab Republic)
43 00 S
171 00 E
South Korea
South Korea
37 00 N
127 30 E
South Orkney Islands
41 28 S
174 51 E
West Frisian Islands','da160095a6403845d476cd22cd93e888cf26ce46f4067a5a7113635c576a385b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daa0f0dcbe395689f360e78759715914a0e147bf81bb39b0e6117ba8822e1c79',1999,'NI','Nicaragua','space',1201,'NU
Nl
NIC
558
Nl
12 15 N
83 00 W
Corocoro Island
Guyana, Venezuela
3 38 N
66 50 W
Corsica (Corse) [island]
12 15 N
83 00 W
Majorca Island (Isla de Mallorca)
86 17 W
Manama [US Embassy]','da2ea2ab53382ea156001e1ae1e36715aff089b485dd50d5a15a24876fbaaec1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145c21f2c60dfc1e9ec101becedc224b9a5e0c20e2c7d11b23a0b386c31bba0f',1999,'NG','Nigeria','space',1202,'Nl
NG
NGA
566
NG
626
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
9 12 N
711 E
Abyssinia
5 30 N
7 30 E
Big Diomede Island
Russia
65 46 N
169 06 W
Bijagos, Arquipelago dos
10 33 N
7 27 E
Kailas Range
China, India
30 00 N
82 00 E
Kalimantan [region]
6 27 N
3 24 E
Lahore [US Consulate General]','13695723a272b4eb9c4587509b384f8f1299403c2b81230c9b8a228770923961','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13066a7f834a95f607a1095102b1d1badfa92eb528a9f161ebddd2abae5f31ba',1999,'NF','Norfolk Island','space',1203,'NF
NF
NFK
574
NF
29 02 S
167 56 E
Byelorussia
29 03 S
167 58 E
Kingstown
167 57 E
Philippine Sea
Pacific Ocean
134 00 E
Phnom Penh [US Embassy]','9a53db230a3e3b3de60eae4b88f55a10e5668511f5917351add5aa8293d8f41c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de24da9567d6b3323659095685e3555aa9c618b1b974b5f05b94324df6078fd7',1999,'MP','Northern Mariana Islands','space',1204,'CQ
MP
MNP
580
MP
145 24 E
Atacama [region]
145 47 E
Pago Pago
14 10 N
145 12 E
Rotuma [island]
145 45 E
Sakishima Islands
145 38 E
Tiran, Strait of
Indian Ocean
Tirana [US Embassy]','2077fcd319a8e366d0136c1a66ff63f0ba295acac6dc0ae80ddc9c0d23242f58','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85de8541e2a7c7b04eb89cd65766d66ae27f7bd420b57380c7556671a619332a',1999,'NO','Norway','space',1205,'NO
NO
NOR
578
NO
59 55 N
1045 E
Osumi Strait (Van Diemen Strait)
Pacific Ocean
31 00 N
131 00 E
Otranto, Strait of
Atlantic Ocean
40 00 N
19 00 E
Ottawa [US Embassy]','e8b887eed0b9d8f395d5a4eb62f6847d7216d5c8b684430d802a1095b3bceb24','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b452433d0fb7ff07cbe14255e00d0e35eacb60a54161b51bcacb8f015f6193e',1999,'OM','Oman','space',1206,'MU
OM
OMN
512
OM
17 00 N
54 10 E
Diego Garcia [island]
17 30 N
56 00 E
Khyber Pass
Afghanistan, Pakistan
34 05 N
71 10 E
Kiel Canal (Nord-Ostsee Kanal)
Atlantic Ocean
53 53 N
9 08 E
646
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Kiev [US Embassy]
Muscat and Oman
Myanma, Myanmar
Burma
98 00 E
N Nagorno-Karabakh [region]
jiddah''','e0f2f214ff1a9ba6f3b62e73d4cda22bc8170acc33ddd1a3fa82478a72efc463','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('313292f800d0fe9291575be621732dcaabaa0a66d3a1dc869eb52709e254b030',1999,'PK','Pakistan','space',1207,'PK
PK
PAK
586
PK
34 30 N
74 00 E
636
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Azores [islands]
28 00 N
63 00 E
Baltic Sea
Atlantic Ocean
57 00 N
19 00 E
Bamako [US Embassy]
33 42 N
73 10 E
Islas Malvinas
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Istanbul [US Consulate General]
Turkey
41 01 N
28 58 E
Istrian Peninsula
Croatia, Slovenia
45 00 N
14 00 E
Italian East Africa
Eritrea, Ethiopia, Somalia
8 00 N
38 00 E
Italian Somaliland
24 52 N
67 03 E
Kara Sea
Arctic Ocean
76 00 N
80 00 E
Karakoram Pass
China, India
35 30 N
77 50 E
Karelian Isthmus
Russia
60 25 N
30 00 E
Karimata Strait
Pacific Ocean
2 05 S
108 40 E
Kashmir [region]
India, Pakistan
34 00 N
76 00 E
Katanga [region]
Democratic Republic of the Congo
10 00S
26 00 E
Kathmandu [US Embassy]
74 18 E
Lakshadweep (Laccadive Islands)
71 33 E
Peter 1 Island
30 00 N
70 00 E
West Siberian Plain
Russia
60 00 N
75 00 E
Western Channel (West Korea Strait)
Pacific Ocean
34 40 N
129 00 E
Western Samoa','56c26d673f0e64d861ee71397cbca5c1e91a229853442e5a0ab5d5a436dfa1c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51f02392ffc41741cfada513859fd0498cd8358cd87596bb8a1c277ca8c7c268',1999,'PW','Palau','space',1208,'PS
PW
PLW
585
PW
Palmyra Atoll
LQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
7 30 N
134 30 E
Belem [US Consular Agency]
7 20 N
134 29 E
Kosovo [region]
Serbia and Montenegro
42 30 N
21 00 E
Kowloon
134 15 E
Pemba Island
Tanzania
39 25 E
Penang Island
^Saipan','49e2f7aae454891dc7dc9c0ab1246bdf3785716f75e43dea75af6704df7b1adf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('259183c69159452635c3cf2d12da63999181d55e7b543c526924ee0ba42ffdd7',1999,'PA','Panama','space',1209,'PM
PA
PAN
591
PA
9 00 N
79 45 W
Canary Islands
8 58 N
79 32 W
Panama Canal
9 00 N
79 45 W
Panama, Gulf of
Pacific Ocean
8 00 N
79 30 W
Panay [island]','d9539f8992507a85dbffb16a271ac2b6b685420b5d21b9f55226629127f2a9e8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02e5b3e1db67ac6b25a0974f5c6afe541d30b2e520f01111f64261b87cb9a87a',1999,'PG','Papua New Guinea','space',1210,'PP
PG
PNG
598
PG
Paracel Islands
PF
—
—
—
—
2 10 S
147 00 E
Adriatic Sea
Atlantic Ocean
42 30 N
16 00 E
Aegean Islands
5 00 S
150 00 E
Bismarck Sea
Pacific Ocean
4 00 S
148 00 E
Bissau [US Embassy]
155 00 E
Bougainville Strait
Pacific Ocean
6 40 S
156 10 E
Bounty Islands
9 30 S
150 40 E
Desolation Islands (Isles Kerguelen)
French Southern and Antarctic Lands
49 30 S
69 30 E
Devils Island (lie du Diable)
4 30 S
154 10 E
Greenland Sea
Arctic Ocean
79 00 N
5 00 W
Grenadines, Northern
11 00 S
153 00 E
Loyalty Islands (lies Loyaute)
150 00 E
New Delhi [US Embassy]
9 30 S
147 10 E
Porto Alegre [US Consulate]
6 00 S
155 00 E
Solomon Islands, southern
8 38 S
151 04 E
Trucial Coast','e919b99558287dcae376668471e3a3cd66287ca9539a7135311ac6e17d4451a7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13211e1922a29bd087690ab802b93babb32d4e315c96c1493589a4a311d77e49',1999,'PE','Peru','space',1211,'PE
PE
PER
604
PE
77 03 W
Lincoln Sea
Arctic Ocean
83 00 N
56 00 W
Line Islands
Jarvis Island, Kingman Reef, Kiribati,
Palmyra Atoll
0 05 N
157 00 W
Lisbon [US Embassy]','1e1e23fe02a29f602a3d1cbbb8be9932c937bd31f0da028a4c8c32951a7c406c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('848b923fef3c12efb939fa4e01a03b92e23fe9ebdf8c449a497666572a7aee4a',1999,'PH','Philippines','space',1212,'RP
PH
PHL
608
PH
Pitcairn Islands
PC
PN
PCN
612
PN
19 10 N
121 40 E
Baffin Bay
Arctic Ocean
73 00 N
66 00 W
Baffin Island
19 55 N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herzegovina, Bulgaria,
Croatia, Greece, Romania, Serbia and
Montenegro, Slovenia, The Former Yugoslav
Republic of Macedonia, Turkey (European part)
42 00 N
23 00 E
Balleny Islands
20 30 N
121 50 E
637
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bavaria (Bayern)
10 18 N
123 54 E
Celebes [island]
10 50 N
124 50 E
Liancourt Rocks [claimed by Japan]
South Korea
131 50 E
Libreville [US Embassy]
121 00 E
Luzon Strait
Pacific Ocean
121 00 E
Lyakhov Islands
Russia
138 00 E
14 35 N
121 00 E
Manipa Strait
Pacific Ocean
3 20 S
127 23 E
Mannar, Gulf of
Indian Ocean
8 30 N
79 00 E
Manua Islands
8 00 N
125 00 E
Mindoro [island]
12 50 N
121 05 E
Mindoro Strait
Pacific Ocean
12 20 N
120 40 E
Minicoy Island
15 08 N
120 21 E
Mozambique Channel
Indian Ocean
19 00 S
41 00 E
Mumbai [US Consulate General]
123 00 E
Netherlands East Indies
118 30 E
Palermo
11 15 N
122 30 E
Pantelleria, Isola di
12 00 N
125 00 E
Samaria [region]
West Bank
32 15 N
35 10 E
Samoa Islands
American Samoa, Samoa
14 00 S
171 00 W
Samos [island]
121 00 E
Sulu Sea
Pacific Ocean
120 00 E
Sumatra [island]
Celebes Sea ''
Northern ’
Mariana
Islands
(U.S.)','293d9150056df4998282f5afda0bd65d9d811d88a9a625b4f11be66a4aa139e0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5a74b03c8164a23bdcef15364fb6fd1ccdbdae11554a8dfb7b227af5c1091f1',1999,'PL','Poland','space',1213,'PL
PL
POL
616
PL
54 23 N
18 40 E
Dao Bach Long Vi [island]
Vietnam
20 08 N
107 44 E
Dardanelles [strait]
Atlantic Ocean
40 15 N
26 25 E
Dar es Salaam [US Embassy]
Tanzania
6 48 S
39 17 E
Davis Strait
Atlantic Ocean
67 00 N
57 00 W
Dead Sea
Israel, Jordan, West Bank
32 30 N
35 30 E
Deception Island
50 03 N
19 58 E
Kuala Lumpur [US Embassy]
52 25 N
16 55 E
Prague [US Embassy]
Czech Republic
40 55 N
21 00 E
Praia [US Embassy]
Cape Verde
14 55 N
23 31 W
Pretoria [US Embassy]
52 15 N
21 00 E
Washington, DC [US Mission to the Organization
of American States (OAS)]','f9965a2252686b228cdc36f09fcbb90d56a3ce5476b45570161831df72a8e3ad','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d0ecf11185aca4331a11499d18281eeacbf447ce70690f1dc905eb1abf6ece7',1999,'PT','Portugal','space',1214,'PO
PT
PRT
620
PT
38 30 N
28 00 W
Azov, Sea of
Atlantic Ocean
49 00 N
36 00 E
B
Bab el Mandeb [strait]
Indian Ocean
12 40 N
43 20 E
Babuyan Channel
Pacific Ocean
18 44 N
121 40 E
Babuyan Islands
38 43 N
9 08 W
Ljubljana [US Embassy]
32 40 N
16 45 W
Madras (see Chennai)
25 40 W
652
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Port-au-Prince [US Embassy]','9efff36e5d4b151024f10c9d1b25f4ab4ad547d3a77a306d4d12b92cd4f1eb2b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f782c1c01977c07328c96964e5dc3d9669c8bf53c4571a42ad51226c5e19f5c',1999,'QA','Qatar','space',1215,'QA
QA
QAT
634
QA
Reunion
RE
RE
REU
638
RE
25 17 N
51 32 E
Donets Basin
Russia, Ukraine
48 15 N
38 30 E
Douala','4955d49740bfc692d2bb1d8372bc75d9ae3989eeaaeed9ecb9176da6caac4a84','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ccb9a4230cd750d07b35a62858a38f2f13d6f33850a82ffce525a5e64c7fdb6',1999,'RO','Romania','space',1216,'RO
RO
ROM
642
RO
Russia
RS
RU
RUS
643
RU
4426 N
26 06 E
Budapest [US Embassy]
46 47 N
23 36 E
Cochin China [region]
Vietnam
11 00 N
107 00 E
Coco, Isla del
46 30 N
24 00 E
Trindade, llha de','5e863d36deb5885949f03f2eef4b8d623a84d80f4ee73ba9c84b42346ecf68c9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16ab785d00956e5f1d6da4af1d4762398336e7d015412f0de4edfca44ba1964',1999,'RW','Rwanda','space',1217,'RW
RW
RWA
646
RW
Saint Helena
SH
SH
SHN
654
SH
1 57 S
30 04 E
Kingston [US Embassy]','15aeda0fcbfc245e7803100c62240540cef31adcb16175812f50d8ebf9895005','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58feeb0d22076ff4bced0aaf993d8c8b857b2352b87395f93b8bd572d692883d',1999,'KN','Saint Kitts and Nevis','space',1218,'SC
KN
KNA
659
KN
17 18 N
62 43 W
Bastia
France (Corsica)
42 42 N
9 27 E
Basutoland
62 35 W
New Britain [island]
62 45 W
Saint Christopher and Nevis
62 45 W
Saint-Denis
Reunion
55 28 E
Saint George''s [US Embassy]','ce0e6c08419037ea0e38f24515ef32c29bb53d21a34184eae4766b022a419f5d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebc4362b01c26a1e629bce7421b9cc69f89e6e6f349b65f04850e6a8d30d5eb',1999,'PM','Saint Pierre and Miquelon','space',1219,'SB
PM
SPM
666
PM
46 46 N
5611 W
Saint Thomas [island]
Virgin Islands
1821 N
64 55 W
Saint Vincent Passage
Atlantic Ocean
13 30 N
61 00 W
Saipan [island]','5f3b4523eada49054e3a893343bbc355ce55e7b25899c0db5ab52f4c6a8b4294','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('937852d03cc6f4506fa20a3a596dc16af1c5177612fc86ddaca3870e5738a0d8',1999,'VC','Saint Vincent and the Grenadines','space',1220,'VC
VC
VCT
670
VC
13 15 N
61 12 W
Grenadines, Southern
13 09 N
61 14 W
Kinshasa [US Embassy]
Democratic Republic of the Congo
4 18 S
15 18 E
Kirghizia
12 45 N
61 15 W
Northern Ireland','a23bf1e28520ab5478d49baf9fb3bd80be3ea6b9d39223aefacf936a27d487c5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4de85d98cfba32425a4a43140243d98baedc7ef85e8776c09978dd86d64baab1',1999,'WS','Samoa','space',1221,'WS
WS
WSM
882
WS
171 44 N
Aqaba, Gulf of
llndian Ocean
29 00 N
34 30 E
Aqmola (see Astana)
13 35 S
172 20 W
Wetar Strait
Pacific Ocean
8 20 S
126 30 E
White Sea
Arctic Ocean
65 30 N
38 00 E
Willemstad
Netherlands Antilles
12 06 N
68 56 W
Windhoek [US Embassy]','73ffbf4af035c07d8ad81915b5e58d06a565f13d24b589ff76bf8fd32275fab6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('972a539f70bbe617545d553a1277d2c15afea2196f2b8fe18f3ca9c92102571c',1999,'SM','San Marino','space',1222,'SM
SM
SMR
674
SM
SaoTome and Principe
TP
ST
STP
678
ST
43 56 N
12 25 E
San Salvador [US Embassy]','19995ff1ce61902bd0c59c978d928eff3c90cc07e1fe6640fdd4556c19c6bc6c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('467164ba908a492cb7de54f20ec467b2b7fb923b16fd2b821fdb04bba8c9bbd2',1999,'SA','Saudi Arabia','space',1223,'SA
SA
SAU
682
SA
26 18 N
50 08 E
Dhaka [US Embassy]
24 30 N
38 30 E
Helsinki [US Embassy]
21 30 N
39 12 E
Jerusalem [US Consulate General]
Israel, West Bank
31 47 N
35 14 E
Jiddah [US Consulate General]
21 30 N
39 12 E
Johannesburg [US Consulate General]
21 27 N
39 49 E
Medan [US Consulate General]
24 38 N
46 43 E
Road Town
British Virgin Islands
18 27 N
64 37 W
Robinson Crusoe Island (Mas a Tierra)','fd5f922035b0b0782b1a0923877173f9bca7addcc36b4e596f52a7569e33ada5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5a252d955a1c0b42790c38cb02b6e2233d8567d04f9fb772670f991a984b5f2',1999,'SN','Senegal','space',1224,'SG
SN
SEN
686
SN
Serbia*
SR
—
—
—
—
see footnote at end of table
Serbia and Montenegro*
—
—
—
—
—
see footnote at end of table
1440 N
17 26 W
Dalmatia [region]','6dd1c7c69988d522e110f442f24c52215da69096b559317ce46046626619fb43','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9bda332460d18c6122190f504e04e34158604b87f65fe794f6cfab6cd9378a0',1999,'SC','Seychelles','space',1225,'SE
SC
SYC
690
SC
7 01 S
5245 E
Amami Strait
Pacific Ocean
28 40 N
129 30 E
Amindivi Islands
6 00 S
53 10 E
Amman [US Embassy]
9 46 S
46 34 E
Astana (Akmola)
9 43 S
47 35 E
Cotonou [US Embassy]
10 10 S
51 10 E
Fernando de Noronha
4 41 S
55 30 E
Maiz, Islas del (Corn Islands)
4 38 S
55 27 E
Vienna [US Embassy, US Mission to International
Organizations in Vienna (UNVIE)]
'' I
Glorioso Islands
(FRANCE)
Tromelin Island
U
/juan de Nova A''
. (FRANCE) 1
l V
yS Island (FR.) j J
;J
MOZA
kKIbIQUE (Antananariio
Chmne{
Bassas
da India ,
(FRANCE)
I Europa Island
- / _ (EBAim _
DAGASCAR
British Indian
Ocean Territory
(U.K.)
INDIAN
O C E A N
Cocos
(Keeling) Islands
(AUSTL.)
JTr^ic_of_Capricqrn (23
fie Amsterdam
. (Fr. S. and Ant. Lands)
lie Saint-Paul
(Fr. S. and Ant. Lands)
French Southern and Antarctic Lands
/ (FRANCE) !
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
ILES CROZET
(Fr. S. and Ant. Lands)
iLES KERGUELEN
(Fr. S. and Ant. Lands)
Heard Island and
& McDonald Islands
(AUSTL.)
Philippi
Moroni Glorioso Islands
* '' (FRANCE)
COMOROS A
Mayotte 1 kJ A
(administered by FRANCE, (v \\
claimed by COMOROS) f |
\\ Tromelin Island
fv • (FRANCE)
du an deNova
Island (FR.)
I MOZAMBIQUE
“r
JEuropa Island
_ (FRANCE), _
Lnanariyo
/ Saint-
/ Denis
AGASCAR o . *
/ Reunion
/ (FRANCE)
INDIAN
O C E A N
lie Amsterdam
, (Fr. S. and Ant. Lands)
lie Saint-Paul
(Fr. S. and Ant. Lands)
French Southern and Antarctic Lands
/ (FRANCE)
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
ILES CROZET
(Fr. S. and Ant. Lands)
ILES KERGUELEN
(Fr, S. and Ant. Lands)
Heard Island and
° McDonald Islands
VAjjakarta , Java $
Sea WJjun^pdang
Banda Sea if
3 1 A N
E A N
Cocos :
(Keeling) Islands
(AUSTL.)','d265b89e965ecf01349e54c9b939ec5081444b466af6ac726f29aef7397fdf7f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f6c3edf1d4f263001838a69dbdace9e51aad62ef8967e466e49849ec90643a2',1999,'SG','Singapore','space',1226,'SN
SG
SGP
702
SG
1 17 N
103 51 E
Singapore Strait
Pacific Ocean
1 15 N
104 00 E
Sinkiang (Xinjiang)','212acdff304c35be97b2d280576b71626bd1847905255310043ae7cc4d054500','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbc4d45db7eea741d1526d60f5daeb681c3d29bf7703e3c8885b9fa33b9bd2fb',1999,'SK','Slovakia','space',1227,'LO
SK
SVK
703
SK
48 09 N
17 07 E
Brazzaville [US Embassy]
Republic of the Congo
4 16 S
15 17 E
Bridgetown [US Embassy]','2ec9f28bb10754e9705975236d39a9ea9e33413b682bb15f47909bd9e42120fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76a214f6e8182905d8214808b89ffa99dba8154babaa75412e6b47a27400662e',1999,'SI','Slovenia','space',1228,'SI
SI
SVN
705
SI
46 03 N
14 31 E
Lobamba
Swaziland
26 27 S
Lombok Strait
Indian Ocean
8 30 S
Lome [US Embassy]','4b2c39c2e264e11f02d98dabff9c4a9bd14e605074684141d21b399713ea94dd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac02ffe890d90932325860561e0c1641ed61d5baeff8d1e3180baa6e3610de7',1999,'SB','Solomon Islands','space',1229,'BP
SB
SLB
090
SB
627
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
8 00 S
159 00 E
British Somaliland
7 05 S
121 00 E
Christmas Island [Indian Ocean]
9 32 S
160 12 E
Guadalupe, Isla de
9 26 S
159 57 E
Honshu [island]
166 15 E
Santiago [US Embassy]
8 00 S
159 00 E
Solomon Sea
Pacific Ocean
8 00 S
153 00 E
Songkhla','bcf54ec087ba459e5f7054b88f8e62a678f76c4ccc5397363831022f5799a432','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc3bf858167cce9a0102da5e7ed26c7c9324b0ca49a6050a68ce1d96b3526f26',1999,'SO','Somalia','space',1230,'SO
SO
SOM
706
SO
49 00 E
Brussels [US Embassy, US Mission to European
Union (USEU), US Mission to the North Atlantic
Treaty Organization (USNATO)]
49 00 E
Iturup (see Etorofu)
Russia [de facto]
14740 E
Ivory Coast
Cote d''Ivoire
iiiggfEQg!!
5 00 W
Iwo Jima [island]
2 04 N
45 22 E
Moldavia [region]
Moldova, Romania
29 00 E
Moluccas (Spice Islands)
1
1
i
i
l
| . SEYCHELLES J
''t?\\
f/
4d. vqascar
M/juRITIUS
*
ft
Reunion
i (FRANCE) !
3
!
i
1
I
BHUsh Indian
ft Oclean Territory !
! (U.K.) |
i Cocos i
(Keeling) Islands j
■ (AUSTU
; INDIAN
iOCEAN
. TRISTAN DA CUNHk
(St. Helena) ;
* Gough Island j
(St. Helena) I
South Qeor^la and the
South Sandwich Islands
(administered by U.K.
.claimed by ARQEimMA)
Coordinated Universal Time (UTC)
formerly j
Greenwich Mean Time (GMT) i
Ffench Southern anfl Antarctic Lands
_ j (FRAHCEj _ ‘
Lpr,^™|rD ■! hESCRdZET
(SOUTH AFRICA) 5 I ^ S and A"} U"dS)
. iLES KERGUELEN
(Fr. S. and Ant Lands)
Add time zone number to local time to obtain UTC.
Subtract time zone number from UTC to obtain local time.
WEST
EAST
Subtract time zone number from local time to obtain UTC.
Add time zone number to UTC to obtain local time.
FRANZ IOSEF
LAND
75
90
105
120 ! '' 135
150
165 ''
16
0 i
i
6
7
? ! f
ib
ij
12
12 |
!$C3
SEVERNAYA
ZEMWA
East Siberian Sea
R U S
m m','00bcd5f259bf6ac7b52ff0ddaa26bc39e47967c74c5dc85760620d3e05cb0e0d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e3daf62a5726fcf59f34e7603803fe86bb8f982aa211e2502627866a67941c',1999,'ZA','South Africa','space',1231,'SF
ZA
ZAF
710
ZA
South Georgia and the South
Sandwich Islands
SX
GS
SGS
239
GS
29 12 S
26 07 E
Boa Vista [island]
Cape Verde
16 05 N
22 50 W
Bogota [US Embassy]
26 30 S
25 30 E
Bora-Bora [island]
33 55 S
18 22 E
Caracas [US Embassy]
Venezuela
10 30 N
66 56 W
Cargados Carajos Shoals
33 00 S
27 00 E
Ciudad Juarez [US Consulate General]
29 55 S
30 56 E
Dushanbe [US Embassy]
a*
18 30 E
Goteborg
26 15 S
28 00 E
Juan de Fuca, Strait of
Pacific Ocean
48 18 N
124 00 W
Juan Fernandez, Isla de
46 51 S
37 52 E
Marmara, Sea of
Atlantic Ocean
40 40 N
28 15 E
Marquesas Islands (lies Marquises)
25 45 S
28 10 E
Prevlaka peninsula
38 00 E
Prince Patrick Island
32 15 S
28 15 E
Transylvania [region]
23 00 S
31 00 E
Verde Island Passage
Pacific Ocean
13 34 N
120 51 E
Victoria','35f30ed4ac3cfa44da8a1c489fe38c6ed870d34204204e66d1b65f565f720c00','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31ece85c5b8a2cd827c8ab58a3e2395bc546d426f8444f6b211be2bf7edc934',1999,'ES','Spain','space',1232,'SP
ES
ESP
724
ES
Spratly Islands
PG
—
—
—
—
35 13 N
3 53W
Alma-Ata (see Almaty)
39 30 N
300 E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30 N
2 00 E
Bali [island]
41 23 N
211 E
Barents Sea
Arctic Ocean
74 00 N
36 00 E
Barranquilla
43 00 N
2 30W
Bass Strait
Pacific Ocean
39 20 S
145 30 E
Basse-Terre
43 15 N
2 58 W
Bioko [island]
28 00 N
15 30W
Canberra [US Embassy]
42 00 N
2 00 E
Cato Island
35 53 N
5 19 W
Ceylon
35 12 N
2 26 W
Chagos Archipelago (Oil Islands)
40 00 N
4 00 W
Essequibo [region] [claimed by Venezuela]
28 06 N
15 24W
Lau Group
40 24 N
3 41 W
Magellan, Strait of
Atlantic Ocean
54 00 S
71 00 W
Maghreb
Algeria, Libya, Mauritania, Morocco, Tunisia
30 00 N
5 00 E
Mahe Island
39 30 N
3 00 E
Majuro [US Embassy]
39 SON
3 00 E
Malpelo, Isla de
35 19 N
2 58W
Merida [US Consulate]
40 00 N
4 00 E
Mitla Pass
3511 N
4 18 W
Venda','4dd28ff97eca57755e7e4eee7be9064129ba6980aa79038a340ecd82d04eaa44','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40a89b5ebe28d27f10ebcffb07ee1be04b0d40ed104767369e6ab7876ffeba97',1999,'LK','Sri Lanka','space',1233,'CE
LK
LKA
144
LK
7 00 N
81 00 E
Chafarinas, Islas
6 56 N
79 51 E
640
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Colon, Archipielago de (Galapagos Islands)','4196ab00eaa1abd349629b49f55cf1497a145048f3cf92777e3d597b32cd2a49','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('206d1dacef6e39be08bb154f204423248659701003188da9adf9cde4c2ae301d',1999,'SD','Sudan','space',1234,'SU
SD
SDN
736
SD
30 00 E
Anjouan [island]
15 36 N
32 32 E
Khmer Republic
33 00 E
Nukualofa
defined boundary
artoum
Wad
''j, Madanf
/Asmara
Arabian Sea
Al Mukalla
Socotra
(YEMEN)
Gulf of Aden
)UTI
Penedos de
Sao Pedro e Sdo Paulo
(BRAZIL)
LEONE^B
Monrovia*
LIB]
Equator
■nsv
y
D’IVOIRE IgHA
Jv V |
Yamoussoukro
* I
* (
L>mel
^^“2''^M^|CAMEROOn|
Malabo*’’? ★
EQUATORIAL GUINEA - - • \\ Yaounde
Gulf of Guinea L*T~Twr>
SAO TOME kND PRINCIPE ■ '' 4^D
_ I Sao Tome* ^Libreville J|
Arquipelago de
Fethando de Noronha
(BRAZIL)
Martin Vaz
J . (BRAZIL)
Annoboti
(EQUA. GUI.)
^Librevilie|','6b851afc8e3c28c827c432baaaec7b52d0dcf66b2a43a7ac0cc1f0f82da977bd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf41deb560a317f67f2ac697f832060f5c7f2a6eb3812ea8709991c49e6fecb',1999,'SR','Suriname','space',1235,'NS
SR
SUR
740
SR
Svalbard
SV
SJ
SJM
744
SJ
ISO includes Jan Mayen
Swaziland
WZ
SZ
SWZ
748
SZ
4 00 N
56 00 W
Dutch West Indies
Netherlands Antilles
52 05 N
4 18 E
Dzungarian Gate
China, Kazakhstan
45 25 N
82 25 E
E East China Sea
Pacific Ocean
30 00 N
126 00 E
East Frisian Islands
56 00 W
Nevis [island]
5 50 N
55 10W
Parece Vela [island]
56 00 W
Suva [US Embassy]','21115176b15020760391496aa7b0d32537275d629d5ea17717f5f96968250872','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4303d65bdb87e74b6f78441f8c7343d3c6f73a360188286b52e8de7857b5caa7',1999,'SE','Sweden','space',1236,'SW
SE
SWE
752
SE
11 58 E
Gotland [island]
18 33 E
Gough Island
Saint Helena
40 10 S
9 45 W
Grand Banks
Atlantic Ocean
47 06 N
55 48 W
Grand Cayman [island]
59 20 N
Strasbourg [US Consulate General]','715efaa8167b1f3b73bcd63519e4110edacb7d61b9ec6d15c42735eb732ac375','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('132e81508425f499182f11561fb84e510f9fb8fbbb189ea618d1ef2b13a8c4e6',1999,'CH','Switzerland','space',1237,'SZ
CH
CHE
756
CH
Syria
SY
SY
SYR
760
SY
Taiwan
TW
TW
TWN
158
TW
46 57 N
7 26 E
Bessarabia [region]
Romania, Moldova, Ukraine
47 00 N
28 30 E
Bhopal
46 12 N
6 10 E
Genoa
47 23 N
8 32 E
660
Ponta
Deleada
AZORES ^
(PORTUGAL) .
Berllivl Warsal*
-'' ’ Kriissa^^ QERMAIt/A POLAND V ''/kIct
r~X"/ BELv&iliX’ Prague ★ vs, -j, / r!„.D , ,IV,;,
# '' Ukraine
swiTZ^^^^r^!AySv^*C^:%’»udapfest''’.f/
^''j^bS»v^advROM|
'''' * j| | ’>
Corsica (4 L r.
SPAIM-T /
(UJSSL/
^AZAKHSTAH
MA0EIRA ISLANDS '' , /•''
^Portugal) Rabat/ .t-0tistantir
j * Casablanca^# •■ r‘ - / ^<-$f"-'':‘r-
ru"chal ./morocco^ :
/ CANARY ISLANDS }
/ 0 (spAim^ ''''''■ _■ ■
I ^ Pa,*a/gS»// ALOE R 1 A
r (El Aaiun)f\\. , ■- ■ !
/j ku rv W^Ashgabat
TURKKV \\
Tinis Amlns-^ *• ''£!■ //'' ;''''r:;i''#r''Telir&i ■>
rAfc> ,, „ H-* •''* ''JZttemo \\ ‘‘TX-''i • ,;''''Y7''.T;-~-
42si*T ’t*°‘ '' ^ah/ ''N
TmiSIA Me ditem nea i 1 Sea Be i r u t rJ#D “ ★ ^“saw*: ^ I R/?W
. J ★ . U^_ l.rusalenlfe/j U BaghdaJS • '' ,; VA
\\| Tripoli >-v. V.. ,SMr.i*
L IB Y A
1 - \\ — 1 _ ircipitfof.Cancer
S A X A R 4/
.CajroM -JORDAN
/ J — MAXJRITAfUA_
». CAPE VERDE F Nouakchott
\\ l •» Kuwait^ T if? ''■ /IBdp''dar,, A\\ . * >\\
KUWAIT''^, p • t X/:
Manama i ’''■*’*%
BAHR/A Doha
WyadV *“?“«
yrah arabia
” * Mecca -;. . •
•*Prala Lw
N IQ E R
(Banjul jlT-. J
THE qAMBlAE^-J
| Bissau#? -j ■/?
QUINEA-BISSXUV. •''•/Qljj
/ Conakry#/-''—''
Freetown #
SIERRA LEOTtE ✓
CHAjD
N''Djameija
* frv cS cOte XrSwf;
S/Krt? /D''IVOIRE /
# ;. <- '' '' ★. ; f io
\\ YamoussoukroVAccraj
iERX’Y ...-•#
Abidjan''^
''QQOr •OgBomoso
/X\\^°und0U _. X t/
A^CETfriML AFR1CAH ^
uniuurman >• t BflunEA j t-uru*ri- : . yp>
. .Khartoum*-^ /;. ★Asnura''. %ana;1 /•: ‘
s u daW
'' ■ .«> Vi Djibouti AJ™ y~!
^ r:wdb*/^^Vawsa /
j CAMEROON V r an a„ i
L •- Douala V “» “i
republic''
EQUATORIAL QUinEA
Malabo jl /? #•/ *
GUINEA V- V-.
Xddis/./'''' V«sl
: iAB^ba < v- ■>;/ *\\ -’
//
Prov. •/
W>'' SOMALIA
^evl,i7^py _ :
QABOrtScOMQO^ BASIN
Annobdn
(EQUA. QUI.)
''’’ . - ffioAHDA\\\\ '' if f *j. - * •'' \\
Kisangani * KEWA
Mogadishu
BM.REP.IS^S
Brazzaville OF| THE CONGO < , fjuJumbura
Pointe-NolrX^^33^|>i_c|f _c j .4 fflURUHDI
AN,,n. aY Kinshasa Kananga i li*®.
South
Atlantic
j - - Lubango
Tropic of Capricorn
/tX'' Kilimanjaro I H. d l 2 IT
W .mghesf point in
i^iumbura >''^//v^.A*#fca,5S95/n; > „ Victoria
BURUriDI , ■ ^ /-/S^Morabasa U L C A H , *
/''tjodoma/, ®1 „ ■•
iha ..* •''. /^y:. -[fc Zanzibar •
TAHZXH’fii- F Dares SEYCHELLES ''
-’ f V Salaam
;/,,. ''1 s fjx COMOROS
j .Moroni . Clorioso Islands
,-■• / j * , * , (FRANCE)
Ipidadei ] (aditfln°fy France,
/ ,de Nacalh l claimed by Comoros) y, /..-j
X/e; - jl de »,, /FRANCE)3"11
''.(/ ■ \\ (FRANCE) f • t ////
^tffBI^UE * f.\\ / /? ff
'' jra.A''h«ambfijite _ \\jA'' J^j^tanianarivo Loufs
Channel '' / St7Denis“ ''#"~20/
S''l. ,„. .r„ MADACiASCAK JL"*“7
(1-KAnC.C.) I t * > • yk''f IFRANTPA
!r.-f’j5,''W si. uems,
MADAGASCAR Reunion
f > ",”|7 (FRANCE
cJ°/"CSbUr8hbahanc
^OUTH ''■ Swfeii^AriD
! #M^serg^
«ralr''». • vr''1 • DlIrb-,r
Scale 1:51,400,000
Azimuthal Equal-Area Projection
Boundary representation is
not necessarily authoritative.
Indian O ce a.1
802641 Al (R02109) 6-99
ANTARCTIC REGION
802648A! (R02207) 6-99
ARCTIC REGION
ASIA
Svalbard *4^--.-
(morway)
''W .
P0 SO 100 120
■RANZ IOSEF 7 / \\
land/ Arctic Ocean
'' SWEDEN
\\Ay *
FINl,ANDj7\\> !V!“™!ansy
.Helsinki
;‘POL>
Warsaw
<k
Arkhangelsk /
Q
Wrange I
Island
tv SIBERIAN
IStANDS
rt% ^u.s.
■Q XTTf- $ ,
vXjXy •'' \\ Providcniya
A - Anadyr*" /
-As..-" /
iH / S.^r"''sk :.i
y> «.
*/S \\ hfil "1
UKR. ( ^ t
-Virfonezh \\Kazan'' / / \\ i
.... Z,,„ U \\,S S I
jiKiev^
AAA- -1 SLd5- *7"
I B ^ B
Yakutsk^ ''s ^sN. ,3
/ ^y\\ 1 4
Magadan* c
Volgogr^c
/Yekaterinburg''
Ufa /* <!
Samara . y / Chelyabinsk
v:
)
•4
AtyraG
,_(Atyrau)
) )
j Krasnoyarsk )
Sslm/nsihlrslr A
7
Astana
_tA-4'' r;4f /7- Vk
7/7^''
''<hM*
Sea of 3}
Okhotsk fc
occupied by the Soviet Union In 1945,
\\ administered by Russia,
claimed by (span. ^
flMn
Khabarovsk.''
/.
Qaraghandy
(Karaganda)
. KAZAKHSTAN
iRKMimsjAi
Ashj;ah.i!
Mashka*
/ '' ''
v JtJ
AMI • , •. ; , -,lA .TVv^i ft'' ~ j*. ''V >,* *• • e.
^7’ 7 K''M^xk? 7i-''.:;V7*u
^ ‘v <f^=7 ■
uzbekistam\\ '' : -%VM0WOOU/»
* [ Almaty-AO*^ ■%''. j..
A& > ■''•■ , ,,
i desert rrrr-twiT^rT 7
★ \\ \\ / L~ ''?''/ , vi V • /j. V Vv''7\\ e ''.fe \\"c\\r7t>
rAri„„. ./ ^ .
^Ulaanbaarar | cha„Ecfiu„^'' |vostok
Sea of
t ,A: \\
§''v \\ ❖ Shenyangi^7.|^)RTH
j& '' ■ \\ gya"g
''Dalian ;« /f Seoul
r»l
ImN
•; '' , li.kyo
& V" Beijii
a4«CF rJ \\ '' M^aKf SOUTH
'' -'' y®n|ln,,^1 W?1''"!, W?*
XiV
<;V.
4’ 0,A/G ^WG GAOYUAN
ESb/ OMAN
New Delhif
★ \\
laiPUr- 1Ucknov,
'' Kanpur^
’> Mt. Everest 7
e / (highest point in tho world,
<£V • • *,f «w«; ;^7
VS^ , t^Lhasa
; Hk , 1 F-“ T #’
■'' * ■'' >.■•. Waif \\\\
■ Nanl!TT|!
,e >v Yj, “ ''■ T''SKF ''■*?- '' i7 .i# Wuhah.-tV„ ''^Vr ^
£ -w ■ ■ •*• X^k'' • V-i &ysr VMfit. r , Hangzhou^
•« '' P ''J t''^Chengdu-f^f; \\firf / • "V ■ " «V
& AMl m
V7r .1 n D I A
(Bombay! ’“"''ecC4N(
Arabian
Sea
^Hyderabad
LAKSHADWEEP -
(INDIA)
'' / / Calcutta 1
* Nagpur . ‘ /^ytelHftagoTi
©^Bangalore a Chennai
X • , ii(Madras)
> ..r 41 “
\\ '''' : r 7','0940291dc162b2a33b0d930a55489b64b1880fa6a1a471812ce3c6aa01900075','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02bd9ecc4701d6425de97fa506c13ab23599968b62f44dbe797d2e99d55b7218',1999,'TJ','Tajikistan','space',1238,'Tl
TJ
TJK
762
TJ
Tanzania
TZ
TZ
TZA
834
TZ
38 35 N
68 48 E
Dutch Antilles
Netherlands Antilles
52 05 N
4 18 E
Dutch East Indies','dfb90af5277af3b8972e30358046a830c58b1a2f748d6eecfdd2cc4dc08e7c5d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f94d09943faa1341b772c448bd782bd3df4b2f126d89fed397e3e472ea977dc8',1999,'TH','Thailand','space',1239,'TH
TH
THA
764
TH
13 45 N
100 31 E
Bangui [US Embassy]
18 47 N
98 59 E
Chihli, Gulf of (see Bo Hal)
Pacific Ocean
38 30 N
120 00 E
China, People''s Republic of
15 00 N
100 00 E
Siberia [region]
Russia
60 00 N
100 00 E
Sibutu Passage
Pacific Ocean
4 50 N
1 1 9 35 E
Sicily [island]
7 12 N
100 36 E
Sound, The (Oresund)
Atlantic Ocean
55 50 N
12 40 E
South Atlantic Ocean
Atlantic Ocean
30 00 S
15 00 W
South China Sea
Pacific Ocean
10 00 N
1 1 3 00 E
South Georgia [island]
17 26 N
102 46 E
Ulaanbaatar [US Embassy]','1a827309c49b1c8818f837fe3535737c847ea66b31f9fcb82fca83df0438bfdf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa8ef519ca96e42c94fe3cd7782a142a3d702ecb920a56ceb6a646329a1f57e',1999,'TG','Togo','space',1240,'TO
TG
TGO
768
TG
8 00 N
1 10 E
French West Indies
Guadeloupe, Martinique
16 30 N
62 00 W
Friendly Islands
1 13 E
London [US Embassy]','37f9ae56338f51ad296a8ed74cbc4885852a51d147357440b2b297f5dd4facc2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66f9f5d0ea52a92982f1ccdf211ff3dbcf64e6daae63b1e07f1ef4173bd3ee7d',1999,'TO','Tonga','space',1241,'TN
TO
TON
776
TO
20 00 S
175 00 W
Frisian Islands
Denmark, Germany, Netherlands
53 35 N
6 40 E
Frunze (see Bishkek)
19 42 S
174 29 W
Habomai Islands
Russia [de facto]
43 30 N
146 10 E
Hadhramaut [region]
175 12 W
Nuevo Laredo [US Consulate]
SOUTH.
PACIFIC
ireat Australian
Bight
Canberra / / sydne!''
Tasman Sea
Lord Howe
Island
(AUSTL.)
NEW
ZEALAND*''
OCEAN
'' Wellington
KERMADEC
ISLANDS
(N.Z.)
/ CHATHAM ISLANDS
(N.Z.)
AUCKLAND
ISLANDS S
(N.Z.)
SNARES ISLANDS
(N.Z.)
ZUNTY ISLANDS
(N.Z.)
ES ISLANDS y
(N.Z.) /
Macquarie
Island
(AUSTL.)
itarctic^Circle (66’33'')
<£>
June 1 999
Ross Sea
(administered by U.K.,
claimed by ARGENTINA)
^Stanley
Scotia Sea
Trindade
(BRAZIL)
Martin Vaz
. (BRAZIL)
Ascension
(St. Helena)
SOUTH
ATLANTIC
OCEAN
St. Helena
(St. Helena)
St. Helena
TRISTAN DA CUNHA (St. Helena)
Cough Island
• (St. Helena)
\\_J"‘','0552c13e3a1dfe5667fb15a7c2a15369c25d780c41638234ac4c3a7cbab29112','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac7bc8ab09e1398c7f88567e18a833326d0b61f1a4cabdf5df2c51a95f275d4',1999,'TT','Trinidad and Tobago','space',1242,'TD
TT
TTO
780
TT
Tromelin Island
TE
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
10 39 N
61 31 W
Porto-Novo
11 15 N
60 40W
Tokyo [US Embassy]','e155db73d9d9eaef7b661e77a6b23a45cd0028b008bd1c2e29c30ea8432ae8c8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6aedbe5cb643976d22b04ba5b631cceea35c77cc5ec4c5f435aa921263286c',1999,'TM','Turkmenistan','space',1243,'TX
TM
TKM
795
TM
37 57 N
58 23 E
Ashkhabad (see Ashgabat)
37 57 N
58 23 E
Asmara [US Embassy]
40 00 N
60 00 E
Turks Island Passage
Atlantic Ocean
21 40 N
71 00 W
658
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Tuscany [region]','15b9044e73dfc8092e8d46ac2da24db9fe121a54367dbf2672cb1e67633fbd26','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a270e10b7de2be68087ec579d2700e7537cb548cf91fca083677a9eec6a2e4e6',1999,'TC','Turks and Caicos Islands','space',1244,'TK
TC
TCA
796
TC
21 56 N
71 58 W
Cairo [US Embassy]
21 28 N
71 08 W
Great Australian Bight
Indian Ocean
35 00 S
130 00 E
Great Belt (Store Baelt)
Atlantic Ocean
55 30 N
11 00 E
Great Bitter Lake','8ced59caf940a82f349ee93e9312e44e71d632e936cd8b78eb507f6b0c19d510','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd280a29833c8c9ea2295d1cb162f206c63f7a9a9416002e2d46a23c86deeb3f',1999,'TV','Tuvalu','space',1245,'TV
TV
TUV
798
TV
8 00 S
178 00 E
Elobey, Islas de
8 30 S
179 12 E
Fundy, Bay of
Atlantic Ocean
45 00 N
66 00 W
Futuna Islands (Hoorn Islands/lles de Horne)','bb74c6b439547240d1c1cc1f27756cd27db94983d5af68c966b3554dc7abca70','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('011564fa93f5cd4c9701c9a54854d0601e00cc733e217816de4e780bf8c8d9dd',1999,'UA','Ukraine','space',1246,'UP
UA
UKR
804
UA
45 00 N
34 00 E
Crimean Peninsula
45 00 N
34 00 E
Crooked Island Passage
Atlantic Ocean
22 55 N
74 35 W
Crozet Islands (lies Crozet)
French Southern and Antarctic Lands
46 30 S
51 00 E
Curacao [US Consulate General]
Netherlands Antilles
1211 N
69 00 W
Cyclades [islands]
50 26 N
30 31 E
Kigali [US Embassy]
50 26 N
30 31 E
L Labrador','452ab0da7723f3496204cdc29893f936968e7af31f9254409ad9a8cb442c1745','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fbdd39eae25634b68873791efe5ba908242d347afef18c81aecb8e93ff015c9',1999,'AE','United Arab Emirates','space',1247,'TC
AE
ARE
784
AE
24 28 N
5422 E
Abu Musa [island]
Iran
25 52 N
55 03 E
Abuja [US Embassy Branch Office]
25 18 N
55 18 E
Dubayy (see Dubai)
25 18 N
55 18 E
Dublin [US Embassy]
24 00 N
54 00 E
Trucial Oman
24 00 N
54 00 E
Trucial States
24 00 N
54 00 E
Islands
Federated States of Micronesia
7 25 N
151 47 E
Tsugaru Strait
Pacific Ocean
41 35 N
141 00 E
Tuamotu Islands (lies Tuamotu)','a8ce1bc76917fed4b5626934edae0301c3750c9d3f4e517b99f2739b7857ad96','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f7c656a0bc436ac59e570f9614b3a59518724a397242d1cd173f4ddc065ac4b',1999,'GB','United Kingdom','space',1248,'UK
GB
GBR
826
UK/GB
ISO includes Guernsey, Isle of Man,
54 35 N
5 55 W
Belgian Congo
Democratic Republic of the Congo
0 00 N
25 00 E
Belgrade
Serbia and Montenegro
44 50N
20 30 E
Belize City [US Embassy]
49 52 N
6 27 W
Bismarck Archipelago
54 00 N
200W
British East Africa
Kenya, Tanzania, Uganda
1 00 N
38 00 E
British Guiana
55 57 N
3 13 W
Eire
52 30 N
1 30 W
English Channel
Atlantic Ocean
50 20 N
1 00 W
Eniwetok Atoll (see Enewetak Atoll)
54 00 N
2 00 W
Great Channel
Indian Ocean
6 25 N
94 20 E
Greater Sunda Islands
Brunei, Indonesia, Malaysia
2 00 S
110 00 E
Green Islands
010W
Longyearbyen
Svalbard
15 33 E
Lord Howe Island
54 40 N
6 45W
Northern Rhodesia
59 00 N
300W
Osaka-Kobe [US Consulate General]
57 35 N
13 48 W
Rodrigues [island]
57 00 N
4 00W
Scott Island
60 30 N
1 30 W
Shikoku [island]
52 30 N
3 30W
Wallis Islands','74da087f7d361902a2c864f016edcc7e175954e770c9aa49354d14b55ab99a01','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9050b3f8d7ce08e3955b6a4c5de09b821b58f8dc018a0b97b968ce94acd503e0',1999,'US','United States','space',1249,'US
US
USA
840
US
United States Minor Outlying
Islands
UM
UMI
581
UM
ISO includes Baker Island, Howland
Island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Palmyra Atoll, Wake Island
65 00 N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00 N
145 00 W
Aldabra Islands (Groupe d’Aldabra)
9 25 S
46 22 E
Alderney [island]
49 43 N
2 12 W
Aleutian Islands
United States (Alaska)
52 00 N
176 00 W
Alexander Archipelago
United States (Alaska)
57 00 N
134 00 W
Alexander Island
172 57 E
Auckland [US Consulate General]
20 00 N
157 45 W
Heard Island
152 23 W
Kola Peninsula (Kol''skiy Poluostrov)
Russia
37 00 E
Kolonia [US Embassy]
Federated States of Micronesia
158 13 E
Korea Bay
Pacific Ocean
39 00 N
124 00 E
40 43 N
74 01 W
Newfoundland [island]
21 30 N
158 00 W
Ocean Island (Banaba)
28 25 N
178 20 W
Ogaden [region]
Ethiopia, Somalia
7 00 N
46 00 E
Oil Islands (Chagos Archipelago)
57 00 N
170 00 W
Prince Edward Island
55 35 N
131 06 W
Revillagigedo Islands
67 00 W
Saint Lawrence Seaway
Atlantic Ocean
67 00 W
Saint Martin [island]
170 16 W
Saint Paul Island (lie Saint-Paul)
French Southern and Antarctic Lands
77 29 E
Saint Peter and Saint Paul Rocks
(Penedos de Sao Pedro e Sao Paulo)
38 53 N
77 02 W
Weddell Sea
Atlantic Ocean
72 00 S
45 00 W
Wellington [US Embassy]
Scale 1:360,000
5 Kilometers
r
Hawaii
0 If
IV
l!
—
0 , 17
idway * a
lands''
u.s.)
0 If
.
0 IE
North Pacific
0 1‘
Ocean.
0
■>
Tropic of Cancer
Scale 1:34,
0 400 K
1 — 1 — I—1 —
000,000
lometers
*
Wa>Un
Kauai
^ ^Honolulu
Oahu Ma[(l
0
400 Miles
i?
o r
0 1C
0 Hawaii 1£
0
(R024I9)
802634AI 6-99','904d0288756f42192114e12f1a2a9029c67e9356eeb671c60c42fc60975d3689','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4d346bf6756f543eb45a8a86d1257d5772886e8168dfb49108f076f390372a6',1999,'UY','Uruguay','space',1250,'UY
UY
URY
858
UY
34 53 S
5611 W
Montreal [US Consulate General, US Mission to
the International Civil Aviation Organization (ICAO)]','ffdd35eb89a442ef6a0e40f824b286902b0a1ed83a0b2f551d38ae3d72c73fe4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af2c950c9d15f89ed52bb37dd08f4fcfe6dfe1c19ea6e9c8727f54ab7c9dbf1',1999,'UZ','Uzbekistan','space',1251,'UZ
UZ
UZB
860
UZ
41 20 N
69 18 E
Tasmania [island]
41 20 N
69 18 E
Transjordan
•NutO&b 5 i
Caspian
Sea
(lowest point In
, Europe, -28 m)
Dashhowu*
Nicosia','51a84543797d700c34a03838e9f50a0b772be572bf27c0c65371bedfdc78b7df','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fdda8d5fbf1444f70b3e6d4a0aa18e891d07bb2c1116726626102c671f08350',1999,'VU','Vanuatu','space',1252,'NH
VU
VUT
548
VU
Venezuela
VE
VE
VEN
862
UE
Vietnam
VM
VN
VNM
704
VN
Virgin Islands
VQ
VI
VIR
850
VI
628
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
Virgin Islands (UK)
—
—
—
—
—
see British Virgin Islands
Virgin Islands (US)
—
—
—
—
—
see Virgin Islands
Wake Atoll
WQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
MOOS
16730 E
Barbuda [island]
16 00 S
167 00 E
New Siberian Islands
Russia
142 00 E
New Territories
17 44 S
168 19 E
Poznan','a00da1c347edf844a39a070db4fa8fe05a15fd825521ec8f624384ab10dffc40','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f970825b38851a94da1ddac9a592ae58791df18d2eb9802c054574fa9d1574ae',1999,'WF','Wallis and Futuna','space',1253,'WF
WF
WLF
876
WF
West Bank
WE
—
—
—
—
14 19 S
178 05 W
G
Gaborone [US Embassy]
14 19 S
178 05 W
Horn of Africa
Djibouti, Eritrea, Ethiopia, Somalia
8 00 N
48 00 E
Hudson Bay
Arctic Ocean
60 00 N
86 00 W
Hudson Strait
Arctic Ocean
62 00 N
71 00 W
Hunter Island
New Caledonia, Vanuatu
22 24 S
172 06 E
Iberian Peninsula
Portugal, Spain
40 00 N
5 00 W
Inaccessible Island
Saint Helena
37 17 S
12 40W
Indochina
Cambodia, Laos, Vietnam
15 00 N
107 00 E
Inland Sea
13 57 S
1 71 56 W
Matsu [island]
Taiwan
26 13 N
1 1 9 56 E
Matthew Island
New Caledonia, Vanuatu
22 20 S
171 20 E
Mazatlan
13 17 S
176 10 W
Walvis Bay','2f79295791e712efd4b683cde549fcefb36041a98420aa31bede8f1ca8671dec','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72d8a82f622ea9bbfb89ed8f8a2e517a4452db80a5a9cdbf10ae1e378d1bd2d7',1999,'EH','Western Sahara','space',1254,'Wl
EH
ESH
732
EH
Western Samoa
—
—
—
—
—
see Samoa
World
the Factbook uses the W data code
from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
23 45 N
15 45 W
Rio Muni
mmmm
Spice Islands (Moluccas)','1a126dc2cddc2c0d99cb5f395661af5673601589cec06807d7f78417a9bb55f0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e6f80ae0f36c57efb49fa25f31a690be5d967d872bb4a9b25b0a69e9621be61',1999,'YE','Yemen','space',1255,'YM
YE
YEM
887
YE
Yugoslavia*
—
YU
YUG
891
YU
see footnote at end of table
Zaire
—
—
—
—
—
see Democratic Republic of the Congo
12 46 N
45 01 E
Aden, Gulf of
Indian Ocean
12 30 N
48 00 E
Admiralty Island
United States (Alaska)
57 44 N
134 20 W
Admiralty Islands
15 00 N
50 00 E
Hagatna (Agana)
1521 N
42 34 E
Kamchatka Peninsula (Poluostrov Kamchatka)
Russia
56 00 N
160 00 E
Kampala [US Embassy]
15 00 N
44 00 E
Northeast Providence Channel
Atlantic Ocean
25 40 N
77 09 W
Northern Epirus
Albania, Greece
40 00 N
20 30 E
Northern Grenadines
43 25 E
Perouse Strait, La
Pacific Ocean
142 00 E
Persia
Iran
53 00 E
Persian Gulf
Indian Ocean
51 00 E
Perth [US Consulate General]
1521 N
44 12 E
San Ambrosio, Isla
12 30 N
54 00 E
Sofia [US Embassy]
14 00 N
48 00 E
South-West Africa
MOON
46 00 E
Yemen Arab Republic
15 00 N
44 00 E
Yemen, North [Yemen Arab Republic]
15 00 N
44 00 E
Yemen (Sanaa) [Yemen ArabRepublic]
15 00 N
44 00 E
Yemen, People''s Democratic Republic of
MOON
46 00 E
Yemen, South [People''s Democratic Republic of Yemen]
MOON
46 00 E
Yerevan [US Embassy]','0bae2f898e23d7518bc97a3bc89c7ed9ab73c424da99f80396ec37a033aed55c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c378d8ea56f6288156b83a6d72f57ac44bbbc8b4aa9954b8f36c54e3dcc6f6e8',1999,'ZM','Zambia','space',1256,'ZA
ZM
ZWB
894
ZM
15 25 S
28 17 E
Luxembourg [US Embassy]
15 00 S
30 00 E
Northwest Passages
Arctic Ocean
74 40 N
100 00 W
Norwegian Sea
Atlantic Ocean
66 00 N
6 00 E
Nouakchott [US Embassy]
15 00 S
30 00 E
Rhodesia, Southern
Walvis Bay.','2b516027fac935ddf1ed80ef3f01b007fdc8812fe0b90788211546673693704c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef82016d78b4d4cf4e1dccc85d980a9d1154d5a871cb16d8f3ebeaa45204a4cf',1999,'ZW','Zimbabwe','space',1257,'Zl
ZW
ZWE
716
ZW
‘Serbia and Montenegro have asserted the formation of a joint independent state, but this entity has not been formally recognized as a state by the US; the US view is that
the Socialist Federal Republic of Yugoslavia (SFRY) has dissolved and that none of the successor republics represents its continuation.
629
Appendix G:
Cross-Reference List of Hydrographic Data Codes
IHO 23-4th:
Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1 986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23-3rd:
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1 953, published by the International Hydrographic Organization
ACICM49-1:
Chart of Limits of Seas and Oceans, revised January 1 958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force; note— ACIC is now part of the National Imagery and Mapping Agency (NIMA)
DIAM 65-18:
Geopolitical Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly
comparable because of differences in the customers, needs, and requirements of the individual organizations. Even the
number of principal water bodies varies from organization to organization. Factbook users, for example, find the Atlantic Ocean
and Pacific Ocean entries useful, but none of the following standards include those oceans in their entirety. Nor is there any
provision for combining codes or overcodes to aggregate water bodies.
Principal Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
IHO
ACIC
DIAM
23-4th
23-3rd*
M 49-1
65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
—
—
—
—
North Atlantic Ocean
1
23
B
1A
South Atlantic Ocean
4
32
C
2A
Baltic Sea
2
1
B26
7B
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
B11
—
Eastern Mediterranean
3.1.2
28 B
—
8E
Western Mediterranean
3.1.1
28 A
—
8W
Pacific Ocean
—
—
—
—
North Pacific Ocean
7
57
D
3A
South Pacific Ocean
8
61
E
4A
South China and Eastern Archipelagic Seas
6
49,48
D18 plus others
3U plus others
Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
IHO
ACIC
DIAM
23-4th
23-3rd*
M 49-1
65-18
ARCTIC OCEAN
9
17
A
5A
East Siberian Sea
9-1
11
A6
5S
Laptev Sea
9.2
10
A5
5P
Kara Sea
9.3
9
A4
5K
Barents Sea
9.4
7
A2
5B
White Sea
9.5
8
A3
5W
630
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
North Greenland Sea
9.6
—
—
—
Norwegian Sea
9.7
6
B30
5N
Iceland Sea
9.8
—
—
—
Davis Strait
9.9
15
B2
IV
Hudson Strait
9.10
16 A
A15
1U
Hudson Bay
9.11
16
A10
1H
Baffin Bay
9.12
14 A
A12
IP
Lincoln Sea
9.13
17 A
A13
5L
Northwest Passages (Northwest Passage,
Northwestern Passages)
9.14
14
A9
5T
Beaufort Sea
9.15
13
A8
5U
Chukchi Sea
9.16
12
A7
5C
James Bay
—
—
All
—
Kane Basin
—
—
A14
—
ATLANTIC OCEAN (see North Atlantic Ocean and
South Atlantic Ocean)
—
—
—
—
BALTIC SEA
2
1
B26
7B
Gulf of Bothnia
2.1
1(a)
B29
7T
Gulf of Finland
2.2
1(b)
B28
7F
Gulf of Riga
2.3
1(c)
B27
7H
The Sound
2.4
2
—
—
The Great Belt
2.5
2
—
—
The Little Belt
2.6
2
—
—
Kattegat
2.7
2
B25
7K
INDIAN OCEAN
5
45
F
6A
Mozambique Channel
5.1
45 A
FI
6Z
Gulf of Suez
5.2
35
F5
6W
Gulf of Aqaba
5.3
36
—
6Q
Red Sea
5.4
37
F4
6E
Gulf of Aden
5.5
38
F3
6D
Persian Gulf (Gulf of Iran)
5.6
41
F7
6P
Gulf of Oman
5.7
40
F6
6M
Arabian Sea
5.8
39
F2
6R
Laccadive Sea (Lakshadweep Sea)
5.9
42
F9
6L
Gulf of Mannar
5.10
—
F8
—
Palk Strait and Palk Bay
5.11
—
—
—
Bay of Bengal
5.12
43
F10
6B
Andaman Sea (Burma Sea)
5.13
44
F11
6N
Strait of Malacca (Malacca Strait)
5.14
46(a)
FI 2
6C
Great Australian Bight
5.15
62
F21
6G
Suez Canal
—
—
—
6U
MEDITERRANEAN REGION
3
—
—
—
Mediterranean Sea
3.1
28
B11
—
Mediterranean Sea, Western Basin
3.1.1
28 A
—
8W
Strait of Gibraltar
3.1.1. 1
28(a)
B7
8S
631
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
Alboran Sea
3.1. 1.2
28(b)
—
8Y
Balearic Sea (Balear Sea, Iberian Sea)
3.1. 1.3
28(c)
B9
8J
Ligurian Sea (Ligure Sea)
3. 1.1.4
28(d)
BIO
8L
Tyrrhenian Sea (Tirreno Sea)
3.1. 1.5
28 (e)
B12
8T
Mediterranean Sea, Eastern Basin
3.1.2
28 B
—
8E
Adriatic Sea
3.1. 2.1
28(g)
B14
8D
Strait ot Sicily (Strait of Sicilia)
3.1. 2.2
—
—
—
Ionian Sea
3.1. 2.3
28(f)
B13
8N
Aegean Sea
3.1. 2.4
28(h)
B15
8G
Sea of Marmara
3.2
29
B16
8M
Black Sea
3.3
30
B17
8B
Sea ot Azov
3.4
31
B18
8Z
Gulf of Lion (Gulf of Lions)
—
—
B8
8X
Aral Sea
—
—
—
8R
Bosporus
—
—
—
8P
Caspian Sea
—
—
—
CO
O
Dardanelles
—
—
—
8U
NORTH ATLANTIC OCEAN
1
23
B
1A
Skagerrak
1.1
3
B24
IS
North Sea
1.2
4
B23
IN
Inner Seas off the West Coast of Scotland
1.3
18
—
IK
Irish Sea and Saint Georges Channel
1.4
19
B22
1R, IQ
Bristol Channel
1.5
20
B21
1C
Celtic Sea
1.6
21 A
—
—
English Channel
1.7
21
B20
IE
Bay of Biscay
1.8
22
B19
IB
Canarias Sea
1.9
—
—
—
Gulf of Guinea
1.10
34
C4
1G
Caribbean Sea
1.11
27
B6
IX
Gulf of Mexico
1.12
26
B5
1M
Bay of Fundy
1.13
25
B4
IF
Gulf of Saint Lawrence
1.14
24
B3
IT
Labrador Sea
1,15
15 A
—
1L
Greenland Sea
1.16
5
A1
5G
Denmark Strait
—
—
B1
ID
Lake Erie
—
—
—
9E
Lake Huron
—
—
—
9H
Lake Michigan
—
—
—
9M
Lake Ontario
—
—
—
9N
Lake Superior
—
—
—
9S
Panama Canal
—
—
—
1J
Saint Lawrence Seaway
—
—
—
9L
NORTH PACIFIC OCEAN
7
57
D
3A
Philippine Sea
7.1
56
D26
3P
Taiwan Strait (Formosa Strait)
7.2
—
D17
3F
East China Sea (Tung Hai)
7.3
50
D13
3E
632
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
Yellow Sea (Huang Hai, Hwang Hai)
7.4
51
D14
3Y
Bo Hai (Bo Sea, Gulf of Chihli)
7.5
—
D16
3X
Liaodong Wan (Liaodong Gulf)
7.6
—
—
—
Inland Sea of Japan (Seto Naikai)
7.7
53
—
314
Sea of Japan (Japan Sea)
7.8
52
Dll
3J
Gulf of Tartary
7.9
—
DIO
—
Sea of Okhotsk
7.10
54
D8
3Q
Bering Sea
7.11
55
D6
5D
Anadyrskiy Zaliv (Anadyrskiy Gulf)
7.12
—
—
5Y
Gulf of Alaska
7.13
58
D4
5F
Coastal Waters of Southeast Alaska
and British Columbia
7.14
59
D3
5E
Gulf of California
7.15
60
D2
3L
Gulf of Panama
7.16
—
D1
—
Amurskiy Liman
—
—
D27
—
Bering Strait
—
—
D7
5R
Bristol Bay
—
—
D5
—
Korea Bay
—
—
D15
3R
Korea Strait
—
—
D12
—
Sakhalinskiy Zaliv
—
—
D28
3B
Zaliv Shelikhova (Zaliv Shelekhova)
—
—
D9
3K
Luzon Strait
—
—
—
31
Tatar Strait
—
—
—
3D
PACIFIC OCEAN (see North Pacific Ocean
and South Pacific Ocean)
—
—
—
—
SOUTH ATLANTIC OCEAN
4
32
C
2A
Rio de la Plata
4.1
33
Cl
2R
Drake Passage
—
—
C5
2D
Golfo San Matias
—
—
C2
2M
Golfo San Jorge
—
—
C3
2J
Scotia Sea
—
—
C6
2S
Weddell Sea
—
—
C7
2W
SOUTH CHINA AND EASTERN
ARCHIPELAGIC SEAS
6
49 and 48
D18 plus others
3U plus others
South China Sea (Nan Hai)
6.1
49
D18
3U
Gulf of Tonkin
6.2
—
D19
3G
Gulf of Thailand (Gulf of Siam)
6.3
47
D20
3T
Natuna Sea
6.4
—
—
—
Singapore Strait
6.5
46 (b)
—
3Z
Sunda Strait
6.6
—
—
—
Java Sea (Jawa Sea)
6.7
48 (n)
FI 3
4J
Makassar Strait (Makasar Strait)
6.8
48 (m)
El
4M
Bali Sea
6.9
48(1)
FI 4
4L
Flores Sea
6.10
48 (j)
FI 6
4F
Sumba Strait
6.11
—
—
—
633
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
Savu Sea (Sawu Sea)
6.12
48 (o)
F15
6S
Timor Sea
6.13
48 (i)
F19
6T
Joseph Bonaparte Gulf
6.14
—
F20
—
Gulf of Carpentaria
6.15
—
E4
4P
Arafura Sea
6.16
48 (h)
E3
4U
Aru Sea
6.17
—
—
—
Banda Sea
6.18
48(g)
E2
4B
Teluk Bone (Gulf of Bone, Gulf of Boni)
6.19
48 (k)
FI 7
4E
Ceram Sea (Seram Sea)
6.20
48(f)
D25
4Q
Gulf of Berau
6.21
—
—
—
Halmahera Sea
6.22
48 (e)
D24
3H
Molucca Sea (Molukka Sea, Maluku Sea)
6.23
48(c)
D23
3M
Teluk Tomini (Gulf of Tomini)
6.24
48 (d)
FI 8
3V
Sulawesi Sea
6.25
—
—
—
Mindanao Sea
6.26
—
—
—
Sulu Sea
6.27
48(a)
D21
3S
Celebes Sea
—
48 (b)
D22
3C
SOUTH PACIFIC OCEAN
8
61
E
4A
Bismarck Sea
8.1
66
E6
4K
Solomon Sea
8.2
65
E7
4S
Torres Strait
8.3
—
E5
—
Coastal Waters of Great Barrier Reefs
8.4
—
—
—
Coral Sea
8.5
64
E9
4C
Tasman Sea
8.6
63
E10
4T
Bass Strait
8.7
62 A
F22
6F
Amundsen Sea
—
—
E12
4D
Bellingshausen Sea
—
—
E13
4G
Cook Strait
—
—
E8
—
Ross Sea
—
—
Ell
4R
* The letters after the numbers are subdivisions, not footnotes.
634
Appendix H:
Cross-Reference List of Geographic Names
This list indicates where various geographic names—
including the location of all United States Foreign
Service Posts, alternate names, former names, and
political or geographical portions of larger entities —
can be found in The World Factbook. Spellings are
normally those approved by the US Board on
Geographic Names (BGN). Additional information is
included in brackets.
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
A
Abidjan [US Embassy]
Cote d''Ivoire
5 19 N
4 02 W
Abkhazia [region]
31 03 E
Hatay [province]
Turkey
36 15 E
Havana [US post not maintained; representation by US
Interests Section (USINT) of the Swiss Embassy]
20 00 S
30 00 E
Rhodesia, Northern
20 00 S
30 00 E
Riga [US Embassy]
17 50 S
105 00 W
Salvador de Bahia [US Consular Agency]
20 00 S
30 00 E
656
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Soviet Union
Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Spanish Guinea','995f6c22956a90e18c5498eb4af60315726baf4a7368ff58db128cea16ce8a2d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de907b9463389c34f2a744b9348fc6f402aeb6d9dceb845f980e0fea29d1e868',1999,'GS','South Georgia and the South Sandwich Islands','space',1258,'53 39 S
41 48 W
Black Sea
Atlantic Ocean
43 00 N
35 00 E
Bloemfontein
54 15 S
36 45 W
Guadalajara [US Consulate General]
53 33 S
42 02 W
Shanghai [US Consulate General]
54 15 S
36 45 W
South Island
57 45 S
26 30 W
South Shetland Islands','6ce676c1496659e3d10ad07bfa91eb4a557b85aaf6d124920cd4fdf7eeac6315','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a437e8ef386df07b529f997e56b472bdf4a849ff9b23f0bb6493905d76c05429',1999,'KR','Korea, Republic of','space',1259,'South Korea
37 00 N
127 30 E
Korea Strait
Pacific Ocean
34 00 N
129 00 E
Koror [US Embassy]','bcce72c631020af96e9d7d5c0fd09bc4590b9cca9735727605d00d98ff161ec7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('680393722b390beade33ae8492703853d058ecf92967111aa3f0fc451e10fbf9',1999,'MO','Macao','space',1260,'Macau
22 10N
113 33 E
Macedonia
The Former Yugoslav Republic of Macedonia
41 50 N
22 00 E
Macquarie Island','5ae42ca4bb8353e1cbe02a6bbf7038b52660ff71ec26d8d2e744e97e2a4721e5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4066b12524bb66f2c657b55d3e3a698618f0cdc68efb677e4b938881de5bdc6',1999,'EH','Western Sahara','communications',12,'Telephones
Telephone system
domestic
international
Radio broadcast stations
Radios
Television broadcast stations
Televisions
Communications - note
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA','92bce420613bbe38e818724c112b854748f3796073ccd94b1b16971397035ec2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29dcbecb826220e5d1d0062d6364c54306668ab96286648ce3f7c07a1cacb9e7',1999,'AF','Afghanistan','communications',20,'Telephones: 31,200 (1983 est.)
Telephone system:
domestic: very limited telephone and telegraph
service; in 1997, telecommunications links were
established between Mazar-e Sharif, Herat,
Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) linked only to Iran and 1 1ntersputnik (Atlantic
Ocean region); commercial satellite telephone center
in Ghazni
Radio broadcast stations: AM 6 (5 are inactive),
FM 1, shortwave 3 (1998)
Radios: 1.67 million (1998 est.)
Television broadcast stations: NA
note: in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces; also,
the government ran a central television station in
Kabul and regional stations in nine of the 30
provinces; it is unknown if any of these stations
currently operate
Televisions: 100,000 (1998 est.)
Telephones: 1 ,359 (1 988 est.)
Telephone system: fair cable and radiotelephone
services
domestic: NA
international: 2 submarine cables; satellite earth
station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave
0
Radios: 7,000 (1992 est.)
Television broadcast stations: 0 (broadcasts from
The Bahamas are received; cable television is
established) (1997)
Televisions: NA','bfd6de3e866263a9b4cd21ce8e7694a3cd805487f649b7ae959af6780160d581','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7640b8435da3965ce5fb1faeb1ca884d6bc5c4f1fff24cfd6ec13f92a79c06a',1999,'AL','Albania','communications',27,'Telephones: 55,000
Telephone system:
domestic: obsolete wire system; no longer provides a
telephone for every village; in 1992, following the fall
of the communist government, peasants cut the wire
to about 1 ,000 villages and used it to build fences
international: inadequate; international traffic carried
by microwave radio relay from the Tirana exchange to
Italy and Greece
Radio broadcast stations: AM 1 6, FM 3, shortwave
4(1998)
Radios: 577,000(1991 est.)
Television broadcast stations: 13 (1997)
Televisions: 300,000 (1993 est.)
Telephones: 1 ,381 ,342 (5,200 cellular telephone
subscribers) (1997)
Telephone system:
domestic: good service in north but sparse in south;
domestic satellite system with 12 earth stations (20
additional domestic earth stations are planned)
international: 5 submarine cables; microwave radio
relay to Italy, France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik,
and 1 Arabsat
Radio broadcast stations: AM 23, FM 1 , shortwave
8(1998 est.)
Radios: 3.5 million (1998 est.)
Television broadcast stations: 18 (not including
low-power stations) (1997)
Televisions: 2 million (1998 est.)','c7378011397fd8326443faa0c34fb2d99df8d9e4433b8ed4f73c041ccee9948a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88c233153a2cd40c47260cdc0965070c8d3f5e3d4cdaf29c7d17f409c8592ebf',1999,'AS','American Samoa','communications',36,'Telephones: 9,000 (1994 est.)
Telephone system:
domestic: good telex, telegraph, facsimile and cellular
phone services; domestic satellite system with 1
Comsat earth station
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave
0(1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 1 2,000 (1994 est.)
Telephones: 21 ,258 (1 983 est.)
Telephone system:
domestic: modern system with microwave radio relay
connections between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 1 5, shortwave
0(1998)
Radios: 10,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: 7,000(1991 est.)','987fa5d1712f35a883530fb47a6dc4a9628af37cf891fd3a5bea86fe773604ee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4bbd7d11607f1f160523409164d616bb551ed74b41f6a33c323a4bf1d347d76',1999,'AO','Angola','communications',43,'Telephones: 78,000(1991 est.)
Telephone system: telephone service limited
mostly to government and business use; HF
radiotelephone used extensively for military links
domestic: limited system of wire, microwave radio
relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 6, FM 8, shortwave
8(1998)
Radios: NA
Television broadcast stations: 7 (1997)
Televisions: 50,000 (1993 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,280,377 (1999 est.)
Military manpower ■ reaching military age
annually:
males: 111,168 (1999 est.)
Military expenditures - dollar figure: $1 billion
(FY97/98)
Military expenditures - percent of GDP: 25%
(FY97/98)','1cd51ef33879905ae762e0f5e7d942d824af39a6718cc904773464036e3087dc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('406ed4d598fb91799ecd92bffaeddfa333cd305d9d2f0fa87eef551c2b8e9582',1999,'AI','Anguilla','communications',52,'Telephones: 890
Telephone system:
domestic: modern internal telephone system
international: microwave radio relay to island of Saint
Martin (Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6, shortwave
1 (1998)
Radios: 2,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: NA','89784f635f38aab730f45030237cb97d2f3311f835ac81bab239bf5673bba570','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5cafd96ada5d3f35222ee7f34beabe25bc9785d3e2ed1415006182fba63a5c7',1999,'AQ','Antarctica','communications',57,'Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM 2 (American
Forces Antarctic Network), shortwave 1 (Argentina
Antarctic Base de Egercito Esperanza) (1998)
Radios: NA
Television broadcast stations: 1 (American
Forces Antarctic Network-McMurdo) (1997)
Televisions: NA
Telephones: 4.6 million (1990)
Telephone system: 12,000 public telephones;
extensive modern system but many families do not
have telephones; despite extensive use of microwave
radio relay, the telephone system frequently grounds
out during rainstorms, even in Buenos Aires
domestic: microwave radio relay and a domestic
satellite system with 40 earth stations serve the trunk
network
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
21
Argentina (continued)
Radio broadcast stations: AM 260 (including 10
inactive stations), FM NA (probably more than 1 ,000,
mostly unlicensed), shortwave 6 (1998 est.)
Radios: 22.3 million (1991 est.)
Television broadcast stations: 42 (in addition,
there are 444 repeaters) (1997)
Televisions: 7.165 million (1991 est.)','f6d0e021304e5884c21a3df2383f3056e3afbad2e2da65b2a204d1d58a7cd383','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d989a81829e8552dcdff999ab25121eb8df8088e1e07a2d4035c0a6ebea4c07c',1999,'AG','Antigua and Barbuda','communications',65,'Telephones: 6,700
Telephone system:
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean); tropospheric
scatter to Saba (Netherlands Antilles) and','591770678530c5941ffad41a52eb37b4c71a795c89a2956562cb7129603d91e6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efae98e67c4c770d429c0665af1f1053854ed661afcdf3e73dbf16235ea56a20',1999,'GP','Guadeloupe','communications',66,'Radio broadcast stations: AM 4, FM 2, shortwave
0 (repeater transmitters for Deutsche Welle and BBC
world broadcasts) (1 998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: 28,000 (1993 est.)
Telephone system:
international: no submarine cables','e35a7c5db55a46c797fef6ffb186112b4bb5ab22f7dac49b14356405d218bf73','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('186b96897b9ddfaa4c7e27874e70c256056dc65fcaed58f9c88432c4348f1e28',1999,'GE','Georgia','communications',83,'Telephones: 730,000 (1998 est.)
Telephone system: the Ministry of Communications
oversees the Ministry of Posts and
Telecommunications; the national operator is
Armentel; the Greek Telecoms Company owns 90%
of Armentel and will provide a $60 million eight-year
loan; Armenia has about 4,000 Internet users on one
satellite channel
domestic: local - 350,000 telephones are located in
Yerevan; a fiber-optic loop provides digital service to
80,000 of Yerevan''s customers; GSM cellular is
available in Yerevan, as is paging; intercity - the
former Soviet system provides service to 380,000
numbers mostly governmental
international: Yerevan is connected to the
Trans-Asia-Europe line through Iran; additional
international service is available by microwave, land
line, and satellite through the Moscow switch; 1
INTELSAT earth station
Radio broadcast stations: AM 9, FM 6, shortwave
1 (1998)
Radios: NA
Television broadcast stations: 3 (in addition,
programs are received by relay from Russia; 1 00% of
the population receive Armenian and Russian TV
programs) (1997)
Televisions: NA
Telephones: 22,922 (1993 est.)
Telephone system:
domestic: more than adequate
international: 1 submarine cable to Sint Maarten
(Netherlands Antilles); extensive interisland
microwave radio relay links
Radio broadcast stations: AM 4, FM 6, shortwave
0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 19,000 (1993 est.)
Telephone system:
international: numerous submarine cables with most
between continental Europe and the UK, between
North America and the UK, and in the Mediterranean;
numerous direct links across Atlantic via satellite
networks
Telephones: 760,000 (1996 est.)
Telephone system:
domestic: local - Tbilisi and K''ut''aisi have cellular
telephone networks with about 10,000 customers
total; urban areas 20 telephones/100 people; rural
areas 4 phones/1 00 people; intercity - a fiber-optic line
connects Tbilisi to K''ut''aisi (Georgia''s second largest
city); nationwide pager service
international: Georgia and Russia are working on a
fiber-optic line between P''ot''i and Sochi (Russia);
present international service is available by
microwave, land line, and satellite through the
Moscow switch; international electronic mail and telex
service available
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note 2 national broadcast stations, 3
regional broadcast stations
Radios: NA
Television broadcast stations: 3
Televisions: NA','a50959c778422c11f84762c17a0d7d33821a14d8203d45ad20fe462654e29c45','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d33e2dd067d11972e83fcf2b4ef7cd63d2ad424dc1bd18bb04fb388711afb7f',1999,'AU','Australia','communications',95,'Telephones: 8.7 million (1987 est.)
Telephone system: excellent domestic and
international service
domestic: domestic satellite system
international: submarine cables to New Zealand,
Papua New Guinea, and Indonesia; satellite earth
stations - 10 Intelsat (4 Indian Ocean and 6 Pacific
Ocean), 2 Inmarsat (Indian and Pacific Ocean
Regions)
Radio broadcast stations: AM 262, FM 345,
shortwave 1 (Australia''s only shortwave station, Radio
Australia, broadcasts to the world in seven languages,
using 23 frequencies) (1998)
Radios: NA
Television broadcast stations: 104 (64 of these
stations are government-owned and 40 are
commercial) (1997)
Televisions: 9.2 million (1992 est.)
Telephones: 3.47 million (1986 est.)
Telephone system:
domestic: highly developed and efficient
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean) and 2 Eutelsat
Radio broadcast stations: AM 1, FM 61 (several
hundred repeaters), shortwave 1 (Austria''s single
shortwave station, Radio Austria International,
transmits its programs to the world in six languages
using 12 frequencies and six communication satellite
relays) (1998)
Radios: 70% of all households had radiosaccoding
to the 1993 census
Television broadcast stations: 51 (in addition,
there are 920 repeaters) (1998)
Televisions: 2,418,584 (1984 est.)
Communications - note: there are automatic
weather relay stations on many of the isles and reefs
relaying data to the mainland
Telephones: 2,000
Telephone system: automatic exchange
domestic: tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4, shortwave
0
Radios: NA
Television broadcast stations: 1 (1996)
Televisions: NA
Telephones: 276 (1992 est.)
Telephone system:
domestic: single-line telephone system connects all
villages on island
international: NA
Radio broadcast stations: AM 1 , FM 1 , shortwave
0(1987 est.)
Radios: 1,000
Television broadcast stations: 1 (1997)
Televisions: 312(1991 est.)','5509249d32f4789b849cc0c128538300cbc26e96414105a73b79676be3a6c397','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b954be62cdf76d9b91b16494abea31989c3a800e173e6885cd6087d1537582',1999,'AZ','Azerbaijan','communications',104,'Telephones: 1.414 million (1998)
Telephone system: Azerbaijani
telecommunications fall under the Ministry of
Communications; Azerbaijan''s telephone system is a
combination of old Soviet era technology used by
Azerbaijani citizens and small- to medium-size
commercial establishments, and modern cellular
phones used by an increasing middle class, large
commercial ventures, international companies, and.
most government officials; the average citizen waits
on a 200,000-person list for telephone service;
Internet and E-mail service are available in Baku
domestic: local - the majority of telephones are in
Baku or other industrial centers; intercity - about 700
villages still do not have public phone service; all long
34
Azerbaijan (continued)
distance service must use Azertel''s (Ministry of
Communications) lines; satellite service connects
Baku to a modern switch in its separated enclave to
Nakhichevan
international: the old Soviet system of cable and
microwave is still serviceable; satellite service
between Baku and Turkey provides access to 200
countries; additional satellite providers supply
services between Baku and specific countries;
Azerbaijan is a signator of the Trans-Asia-Europe
Fiber-Optic Line (TAE); their lines are not laid but the
Turkish satellite and a microwave between Azerbaijan
and Iran can provide Azerbaijan worldwide access
through this system
Radio broadcast stations: AM 10, FM 17,
shortwave 1 (Azerbaijan''s single shortwave station
transmits its programs to the Middle East in eight
languages)
Radios: NA
Television broadcast stations: 2; note - the
Ministry of Communications is the monopoly
broadcaster and rebroadcaster of television in
Azerbaijan; Azerbaijani, Russian, Armenian, Iranian,
British broadcasting companies, Voice of America,
and other European channels are available via
satellite; television is broadcast to Nakhichevan by
satellite
Televisions: NA','ec8e826dfdded121611eb65f016615587bf8e619cfb028621714209cd403bb2e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c865ae1e9e7e5b06b9433c62a314f7b4b5e2650b8e6978b739c6505175e1ba3',1999,'BS','Bahamas','communications',109,'Telephones: 200,000 (1997 est.)
Telephone system:
domestic: 91 ,1 83 telephone subscribers; totally
automatic system; highly developed
international: tropospheric scatter and submarine
cable to Florida; 3 coaxial submarine cables; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave
0(1998)
Radios: 200,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 60,000 (1993 est.)','6b3eca8461d1a1a90fe428b109ae1d3778fdc40e57eef1b452554cab3d261bf1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00084bd9886f702497cb386502d0b35e9bf557e0b08adcb412c4ee4e96e7d11b',1999,'BH','Bahrain','communications',117,'Telephones: 73,552 (1987 est.)
Telephone system: modern system; good domestic
services and excellent international connections
domestic: NA
international: tropospheric scatter to Qatar and UAE;
microwave radio relay to Saudi Arabia; submarine
cable to Qatar, UAE, and Saudi Arabia; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave
0(1998)
Radios: 320,000 (1993 est.)
Television broadcast stations: 4 (1997)
Televisions: 270,000 (1993 est.)','5badc6f17b8b51ed69b1b837b1df092a08029bebb56923685a9be2f8c5840632','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aff129ed9073dab09a017ce9be51348e40a7f847f7f6ccbc51a4da32998a2c79',1999,'BD','Bangladesh','communications',125,'Telephones: 249,800 (1994 est.)
Telephone system:
domestic: poor domestic telephone service
international: satellite earth stations - 2 Intelsat (Indian
Ocean); international radiotelephone communications
and landline service to neighboring countries
Radio broadcast stations: AM 12, FM 12,
shortwave 2 (one of Bangladesh''s two shortwave
stations, Bangladesh Betar or Radio Bangladesh,
transmits its programs to the world in six languages on
four frequencies) (1998)
Radios: NA
Television broadcast stations: 11 (1997)
Televisions: 350,000 (1993 est.)','621174193c85fce0c987ce1a502124f713a2250a9f4e782613a66765a4e9fea5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc4b34f86c96e3ab60aa4808d7fec4f628dcdbe630191173ff18723e86c04a51',1999,'BB','Barbados','communications',133,'Telephones: 87,343(1991 est.)
Telephone system:
domestic: island wide automatic telephone system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); tropospheric scatter to Trinidad and','9fe24c1d8bf696e69fbc7b698a775fbfa8da999f73a31f5b2eb8c14e8463ca94','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17fb65345c9751968ba7ae4832c01190ef02d28c4afa78439440522db2e341cb',1999,'LC','Saint Lucia','communications',134,'Radio broadcast stations: AM 2, FM 3, shortwave
0
Radios: NA
Television broadcast stations: 1 (in addition, there
are two cable channels) (1997)
Televisions: 69,350 (1993 est.)
Telephones: 26,000 (1992 est.)
Telephone system:
domestic: system is automatically switched
international: direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados; international calls
beyond these countries are carried by Intelsat from','b1be8bbc2ef373145c2ea8a171106d78ac5bbe07e9868a382da82da86e6e52af','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c066c72fd99d92a63ebaa76dc084a9913d07c9d928d49195e197bb6632a41b00',1999,'DE','Germany','communications',152,'Telephones: 2.55 million (October 1998)
Telephone system: the Ministry of
Telecommunications controls all telecommunications
through its carrier (a joint stock company) Beltelcom
which is a monopoly
domestic: local - Minsk has a digital metropolitan
network and a cellular NMT-450 network; waiting lists
for telephones are long; local service outside Minsk is
neglected and poor; intercity - Belarus has a partly
developed fiber-optic backbone system presently
serving at least 13 major cities (1998); Belarus''s fiber
optics form synchronous digital hierarchy rings
through other countries'' systems; an inadequate
analog system remains operational
international: Belarus is a member of the
Trans-European Line (TEL), Trans-Asia-Europe
Fiber-Optic Line (TAE) and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments
provide connectivity to Latvia, Poland, Russia, and
Ukraine; worldwide service is available to Belarus due
to this infrastructure; additional analog lines to Russia;
Intelsat, Eutelsat and Intersputnik earth stations
Radio broadcast stations: AM 28, FM 37,
shortwave 1 1
Radios: 3.17 million (1991 est.)
Television broadcast stations: 17 (1997); note -
Belarus has a state-run television broadcasting
network; independent local television stations exist
Televisions: 9,686,854(1996)
Telephones: 5.691 million (1992 est.); 1.7 million
cellular telephone subscribers (1998)
Telephone system: highly developed,
technologically advanced, and completely automated
domestic and international telephone and telegraph
facilities
domestic: nationwide cellular telephone system;
extensive cable network; limited microwave radio
relay network
international: 5 submarine cables; satellite earth
49
Belgium (continued)
stations - 2 Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: AM 5, FM 77, shortwave
1 (Belgium''s single shortwave station, Radio
Vlaanderen Internationaal, transmits its programs
internationally in Dutch, English, French, and
German, using 21 shortwave frequencies)
Radios: 100,000 (1992 est.)
Television broadcast stations: 24 (in addition,
there are Dutch programs on cable, TV-5 Europe by
satellite relay, and American Forces Network by relay
from Germany) (1997)
Televisions: 3,31 5,662 (1 993 est.)
Telephones: 44 million
Telephone system: Germany has one of the world''s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures
since reunification, the formerly backward system of
the eastern part of the country has been modernized
and integrated with that of the western part
domestic: the region which was formerly West
Germany is served by an extensive system of
automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic satellite
system; cellular telephone service is widely available
and includes roaming service to many foreign
countries; since the reunification of Germany, the
telephone system of the eastern region has been
upgraded and enjoys all of the advantages of the
national system
international: satellite earth stations - 14 Intelsat (12
Atlantic Ocean and 2 Indian Ocean), 1 Eutelsat, 1
Inmarsat (Atlantic Ocean region), 2 Intersputnik (1
Atlantic Ocean region and 1 Indian Ocean region); 7
submarine cable connections; 2 HF radiotelephone
communication centers; tropospheric scatter links
Radio broadcast stations: AM 77, FM 1 ,621 ,
shortwave 37, digital audio broadcasting 130
Radios: 47.1 million (1998 est.)
Television broadcast stations: 9,513 (including
repeaters)
Televisions: 51.4 million (1998 est.)
185
Germany (continued)
Military expenditures - dollar figure: $32.8 billion
(1998)
Military expenditures - percent of GDP: 1 .5%
(1998)
Telephones: 279,736(1997)
Telephone system: highly developed, completely
automated and efficient system, mainly buried cables
domestic: nationwide cellular telephone system;
buried cable
international: 3 channels leased on TAT-6 coaxial
submarine cable (Europe to North America)
Radio broadcast stations: AM 0, FM 6, shortwave
0
Radios: 230,000 (1993 est.)
Television broadcast stations: 5 (1997)
Televisions: 100,500 (1993 est.)
Telephones: 200,000 (1997 est.)
Telephone system: fairly modern communication
facilities maintained for domestic and international
services
domestic: NA
international: HF radiotelephone communication
facility; access to international communications
carriers provided via Hong Kong and China; satellite
earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave
0
Radios: 135,000 (1992 est.)
Television broadcast stations: 0 (receives Hong
Kong broadcasts) (1997)
Televisions: 34,000 (1992 est.)
Telephones: 125,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 6, FM 2, shortwave
0
Radios: 350,000 (1992 est.)
Television broadcast stations: 136 (of which 22
are main stations and 114 are low-power stations)
(1997)
Televisions: 327,011 (1992 est.)
Telephones: 34,000(1994)
Telephone system: system is above average for
Africa
domestic: open-wire lines, coaxial cables, microwave
radio relay, and tropospheric scatter links
international: submarine cable to Bahrain; satellite
earth stations - 1 1ntelsat (Indian Ocean) and 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 1 7, FM 3, shortwave
0
Radios: 2.74 million (1994 est.)
Television broadcast stations: 1 (in addition, there
are 36 repeaters) (1997)
Televisions: 280,000 (1994 est.)
Telephones: 115,911 (1996 est.)
Telephone system: poor telephone and telegraph
service; fair radiotelephone communication sen/ice
domestic: NA
international: radiotelephone communications;
satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 88, FM 1 , shortwave
0
Radios: 690,000 (1992 est.)
Television broadcast stations: 6 (1998 est.)
Televisions: 45,000 (1992 est.)','06a89a49c3b1c9892d8c4384ae6acca3ea4ff2ad7ea747c1ceee1f02fc413fd6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('216cf1ac581b75cbbfbdc8b50693e63c2077bff8a45968acb2230a6456d93dd4',1999,'BZ','Belize','communications',164,'Telephones: 29,000 (1996 est.)
Telephone system: above-average system
domestic: trunk network depends primarily on
microwave radio relay
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 (Voice of America
relay station), FM 12, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: 27,048 (1993 est.)','53a724401c1495b3dcaeb6d66b54f48008a5e054534380340020b5befbaff960','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c114208bd4f60f774854b9422690cf257ab2a2596a3c55dd6af49d38746b99c',1999,'BJ','Benin','communications',171,'Telephones: 38,354 (6,286 cellular telephone
subscribers) (1998 est.)
Telephone system:
domestic: fair system of open wire, microwave radio
relay, and cellular connections
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); submarine cable
Radio broadcast stations: AM 2, FM 9, shortwave
4(1998 est.)
Radios: 400,000 (1998 est.)
Television broadcast stations: 2 (one privately
owned) (1997)
Televisions: 30,000 (1998 est.)','e972559934c4a134636a8ce5afa11813f0a99300cfe81abc713b1a74ecfc0767','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15d67189258820b56e1488f8a657512c44b1af59c5e309e1a10cc81c27b5fcee',1999,'BM','Bermuda','communications',179,'Telephones: 54,000(1991 est.)
Telephone system:
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3, shortwave
0
Radios: 78,000 (1992 est.)
Television broadcast stations: 3 (1997)
Televisions: 57,000 (1992 est.)','a1409fe965099720fa51b61f52753a408cd3ad210dfc4d82b6d03b88a3c64146','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9ccfcda6b29d29a82229bd51207bb3b69e4ff5a0dc739c64d7eb55c4abc0e51',1999,'BT','Bhutan','communications',186,'Telephones: 4,620(1991 est.)
Telephone system:
domestic: domestic telephone service is very poor
with very few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AM 0, FM 1, shortwave
1 (1998)
Radios: 23,000 (1989 est.)
Television broadcast stations: 0 (1997)
Televisions: 200 (1985 est.)','0315cbce4eef8d2a27837f9400db58c85adc6ff88520a4458fcd5b73465e93e9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b88e9060498188cb19adf1186beea10333b79fa0d4186716cdcff48071534ab5',1999,'BR','Brazil','communications',193,'Telephones: 144,300 (1987 est.)
Telephone system: new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities
domestic: microwave radio relay system being
expanded
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 177, FM 68,
shortwave 112 (1998)
Radios: NA
Television broadcast stations: 48 (1997)
Televisions: 500,000 (1993 est.)
Telephones: 727,000
Telephone system: telephone and telegraph
network is in need of modernization and expansion;
many urban areas are below average when compared
with services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 1 6, shortwave
1 (1998)
Radios: 840,000
Television broadcast stations: 21 (1997)
Televisions: 1,012,094
Telephones: 1 9,109 (1 985 est.)
Telephone system: sparse system
domestic: small system of open-wire lines, microwave
radio relay links, and a few radiotelephone
communication stations
international: microwave radio relay links to Zambia,
Zimbabwe, and South Africa; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 7, FM 15, shortwave
5(1998)
Radios: NA
Television broadcast stations: 0 (1997)
Televisions: 13,800 (1993 est.)
Communications - note: automatic meteorological
station
Telephones: 14,426,673 (1992 est.)
Telephone system: good working system
domestic: extensive microwave radio relay system
and a domestic satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite
earth stations - 3 Intelsat (Atlantic Ocean), 1 1nmarsat
(Atlantic Ocean Region East)
Radio broadcast stations: AM 1 ,627, FM 251 ,
shortwave 1 14 (of which 91 are associated with AM
stations) (1998)
Radios: 60 million (1993 est.)
Television broadcast stations: 1 38 (1997)
Televisions: 30 million (1993 est.)','3dc2db5186358c97f195bbf14311dac5c64b4b142e47bf192c4bff6082f0d9d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c5de66ace9b9114ca5d2689d2721ced53cf20e5545a23c85a8c3648622d8609',1999,'ID','Indonesia','communications',205,'Telephones: NA
Telephone system: facilities for military needs only
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 2, shortwave
0(1998)
69
Telephones: 1 ,276,600 (1993 est.)
Telephone system: domestic service fair,
international service good
domestic: interisland microwave system and HF radio
police net; domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 618, FM 38,
shortwave 0
Radios: 28.1 million (1992 est.)
Television broadcast stations: 41 (of which 18 are
government-owned and 23 are commercial) (1997)
Televisions: 11.5 million (1 992 est.)
Telephones: 8,991,797 (1997 est.)
Telephone system:
domestic : 25 regional telecommunications authorities
created in 1996; these authorities are responsible for
implementing paging services and cellular systems;
microwave radio relay extends throughout the country
with the system centered in Tehran; system is moving
toward digitization and direct-dial capability; 255
long-distance circuits (1999 est.); 366 telephone
exchanges (1995 est.); 204,400 microwave channels
(1996 est.); 230,000 cellular telephone subscribers
(1997 est.); 3,930 pager subscribers (1995 est.)
international: 13,985 international circuits (1999 est.)
with a plan to reach 14,000 by March 1999; satellite
earth stations - 9 Intelsat (with 50 terminals) and 4
Inmarsat; HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; submarine fiber-optic cable to UAE with
access to Fiber-Optic Link Around the Globe (FLAG);
Trans Asia Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to
Turkmenistan with expansion to Georgia and
Azerbaijan; four Internet service providers as of 1997
with the number increasing (sen/ice limited to
electronic mail to promote Iranian culture)
Radio broadcast stations: AM 72, FM 6, shortwave
5(1998 est.)
Radios: 13 million (1999 est.)
Television broadcast stations: 28 (in addition,
there are 450 low-power repeaters, all government
controlled) (1997)
Televisions: 7 million (1999 est.)
Telephones: 632,000 (1987 est.)
Telephone system: reconstitution of damaged
telecommunication facilities began after the Gulf war;
most damaged facilities have been rebuilt
domestic: the network consists of coaxial cables and
microwave radio relay links
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik
(Atlantic Ocean region) and 1 Arabsat (inoperative);
coaxial cable and microwave radio relay to Jordan,
Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 1 6, FM 1 , shortwave
0
Radios: 3.7 million (1998 est.)
Television broadcast stations: 13 (government
controlled) (1997)
Televisions: 1 million (1992 est.)
Telephones: 900,000 (1987 est.)
Telephone system: modern digital system using
cable and microwave radio relay
domestic: microwave radio relay
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave
0
Radios: 2.2 million (1991 est.)
Television broadcast stations: 10 (in addition,
there are 36 low-power repeaters) (1997)
Televisions: 1 .025 million (1 990 est.)
Telephones: 2,550,957 (1992 est.)
Telephone system: international service good
domestic: good intercity service provided on
Peninsular Malaysia mainly by microwave radio relay;
adequate intercity microwave radio relay network
between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong
and Singapore; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 28, FM 3, shortwave
0
Radios: 8.08 million (1992 est.)
Television broadcast stations: 27 (of which 26 are
government-owned and one is independent and has
1 5 high-power repeater stations to relay its programs)
(1997)
Televisions: 2 million (1993 est.)
Telephones: 960
Telephone system:
domestic: islands interconnected by shortwave
radiotelephone (used mostly for government
purposes)
international: satellite earth stations - 4 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 5, FM 1 , shortwave
1
Radios: 17,000 (1993 est.)
Television broadcast stations: 2 (1997)
Televisions: 1,290 (1993 est.)
Telephones: 600,000 (1998 est.)
Telephone system: the Ministry of Information,
Computers, and Telecommunications controls
telecommunications; the carrier is Modtelecom
domestic: local - Chisinau has a fiber-optic loop and
one cellular GSM provider; the waiting list for
telephones is long; local sen/ice outside Chisinau is
poor; intercity - Moldova''s two fiber-optic segments
form a synchronous digital hierarchy ring through
Romania''s system; an analog backbone system runs
from south to north in Moldova
international: two fiber-optic segments provide
connectivity to Romania; worldwide service can be
available to Moldova through this infrastructure;
additional analog lines are to Russia; Intelsat,
Eutelsat, and Intersputnik earth stations
Radio broadcast stations: AM 4, FM 8, shortwave
NA (1999)
Radios: NA
Television broadcast stations: 1 national station, 3
private stations, 1 5 small local stations outside
Chisinau (1998)
Televisions: 93 televisions/100 people (1996)
Telephones: 1.9 million (1997)
Telephone system: good international
radiotelephone and submarine cable services;
domestic and interisland service adequate
domestic: domestic satellite system with 1 1 earth
stations
international: submarine cables to Hong Kong, Guam,
Singapore, Taiwan, and Japan; satellite earth stations
- 3 Intelsat (1 Indian Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 261 , FM 55,
shortwave 0
Radios: 9.03 million (1992 est.)
Television broadcast stations: 37 (includes six
stations of the US Armed Forces Radio and TV
Service) (1997)
Televisions: 9.2 million (1998)
Telephones: 24
Telephone system: party line telephone service on
the island
domestic: NA
international: radiotelephone
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: NA
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 1.4 million (1997 est.)
Telephone system: good domestic facilities; good
international service
domestic: NA
international: submarine cables to Malaysia (Sabah
and Peninsular Malaysia), Indonesia, and the
Philippines; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean), and 1 Inmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 1 3, FM 4, shortwave
0
Radios: NA
Television broadcast stations: 4 (1997)
Televisions: 1 .05 million (1 992 est.)','fd6facce33fc56708ad0917c7a34f97ab03b8fab4b61745359cfa0b4e9ac38ba','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('751363b2894c1a3a88a029565295e451c3187043b4d2b5fca4709b2e262a1da8',1999,'IO','British Indian Ocean Territory','communications',206,'(continued)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Telephones: 6,291 (1990 est.)
Telephone system: worldwide telephone service
domestic: NA
international: submarine cable to Bermuda
Radio broadcast stations: AM 1 , FM 4, shortwave
0(1998)
Radios: 9,000 (1992 est.)
Television broadcast stations: 1 (in addition, there
is one cable company) (1997)
Televisions: 4,000 (1992 est.)
Telephones: 90,000 (1997 est.)
Telephone system: service throughout country is
excellent; international service good to Europe, US,
and East Asia
domestic: NA
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 3, FM 1 0, shortwave
0(1998)
Radios: 284,000 (1995 est.)
Television broadcast stations: 2 (1997)
Televisions: 173,000 (1995 est.)
Telephones: 2,773,293 (1993 est.)
Telephone system: almost two-thirds of the lines
are residential
domestic: extensive but antiquated transmission
system of coaxial cable and microwave radio relay;
telephone service is available in most villages
international: direct dialing to 36 countries; satellite
earth stations - 1 1ntersputnik (Atlantic Ocean region);
Intelsat available through a Greek earth station
Radio broadcast stations: AM 24, FM 93,
shortwave 2 (1998)
Radios: NA
Television broadcast stations: 33 (in addition,
there are two relays of Russian program OK-1 and two
relays of TV-5 Europe) (1997)
Televisions: 2.1 million (May 1990 est.)','95829afe12ef6d4c80ae5872f4a37fcfdd41d9a2a5805e53d0f0c811bc76ef9d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ae752ead75064a8189e0beb18d147f5eff5476c4cc5ceb809b3b85f0f9b9f0c',1999,'NG','Nigeria','communications',217,'Telephones: 21 ,000 (1 993 est.)
Telephone system: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 17, shortwave
1 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 49,000(1991 est.)
Telephones: 122,195 (1993 est.)
Telephone system: meets minimum requirements
for local and intercity service for business and
government; international service is good
domestic: NA
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave
3(1998)
Radios: NA
Television broadcast stations: 2 (1998 est.)
Televisions: 88,000 (1992 est.)
Telephones: 405,100 (1995 est.)
Telephone system: average system limited by poor
360
Nigeria (continued)
maintenance; major expansion in progress
domestic: intercity traffic is carried by coaxial cable,
microwave radio relay, cellular network, and a
domestic communications satellite system with 20
earth stations
international: satellite earth stations ■ 3 Intelsat (2
Atlantic Ocean and 1 Indian Ocean); 1 coaxial
submarine cable
Radio broadcast stations: AM 82, FM 32,
shortwave 10 (1998 est.)
Radios: 17.2 million (1998 est.)
Television broadcast stations: 1
(government-controlled)
Televisions: 6.1 million (1998 est.)','41d45d5ce6bfc58602ed610925b79f182a9ccc8b63f5c8f05f91f761d61309c4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d21a9e9db9067436fb29e5a0fe0067939cefaf7171bb889660112e294a12870b',1999,'BI','Burundi','communications',229,'Telephones: 7,200 (1987 est.)
Telephone system: primitive system
domestic: sparse system of open wire, radiotelephone
communications, and low-capacity microwave radio
relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave
0(1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 4,500 (1993 est.)
Telephones: 7,000(1981 est.)
Telephone system: adequate landline and/or
cellular service in Phnom Penh and other provincial
cities; rural areas have little telephone service
domestic: NA
international: adequate but expensive landline and
cellular service available to all countries from Phnom
Penh and major provincial cities; satellite earth station
- 1 Intersputnik (Indian Ocean Region)
Radio broadcast stations: AM 7, FM 3, shortwave
3(1998)
Radios: NA
Television broadcast stations: 1
government-operated station and four commercial
stations broadcasting to Phnom Penh and major
provincial cities via relay (1998)
Televisions: 800,000 (1996 est.)
Telephones: 36,737 (1991 est.)
Telephone system: available only to business and','76754f8b089e57a6cffb06dc2084da70436d91d74eeb0cdc11471ead28699f9e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('416bd78354975503c8e37da3b0a5fd6d0afb18d88d35e053bbc6a0ce2503d908',1999,'CA','Canada','communications',236,'Telephones: 1 5.3 million (1 990)
Telephone system: excellent service provided by
modern technology
domestic: domestic satellite system with about 300
earth stations
international: 5 coaxial submarine cables; satellite
earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean
region)
Radio broadcast stations: AM 334, FM 35,
shortwave 7 (one of the shortwave stations, Radio
Canada International, has six transmitters, 48
frequencies, and broadcasts in seven languages; the
transmissions are relayed by repeaters in Europe and
Asia) (1998)
88
Canada (continued)
Radios: NA
Television broadcast stations: 80 (in addition,
there are many repeaters) (1997)
Televisions: 1 1 .53 million (1983 est.)
Telephones: 66,810 (1993 est.)
Telephone system: low-capacity microwave radio
relay and wire system being expanded; connected to
Central American Microwave System
domestic: wire and microwave radio relay
international: satellite earth stations - 1 1ntersputnik
(Atlantic Ocean region) and 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 45, FM 0, shortwave
3
Radios: 1.037 million (1992 est.)
Television broadcast stations: 3 (in addition, there
are seven low-power repeaters) (1997)
Televisions: 260,000 (1992 est.)','5cfbeee50eadcfcf66cc511665ed21e9abddf3fdeb5bee07dd490711ec7ff77d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f9cc32584d54ab5b631879039e19e9a97bc971bca22fe56facaf585dee4f432',1999,'PT','Portugal','communications',243,'Telephones: 22,900 (1995 est.)
Telephone system:
domestic: interisland microwave radio relay system
with both analog and digital exchanges; work is in
progress on a submarine fiber-optic cable system
which was scheduled for completion in 1998
international: 2 coaxial submarine cables; HF
radiotelephone to Senegal and Guinea-Bissau;
satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 6, shortwave
0(1998)
Radios: NA
Television broadcast stations: 1 (1997 est.)
Televisions: 7,000(1991 est.)
Telephones: 3.7 million (1996 est.)
Telephone system:
domestic: generally adequate integrated network of
coaxial cables, open wire, microwave radio relay, and
domestic satellite earth stations
international: 6 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean), NA Eutelsat; tropospheric scatter to Azores;
note - an earth station for Inmarsat (Atlantic Ocean
region) is planned
Radio broadcast stations: AM 57, FM 66
(repeaters 22), shortwave 0
Radios: 2.2 million (1993 est.)
Television broadcast stations: 36 (in addition,
there are 62 repeaters) (1997)
Televisions: 2,970,892 (1993 est.)','5d352e94a0cf36e7afe607c09051885c4dbf5347b8bee09f1d0438d3358cd8c8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333b05293d6a501f407bfc0345301f9901d82c76ef50934408f1aa7654671204',1999,'HN','Honduras','communications',252,'Telephones: 21,584 (1993 est.)
Telephone system:
domestic: NA
international: 1 submarine coaxial cable; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 4 (the four
stations have a total of six frequencies), shortwave 0
(1998)
Radios: 28,200 (1992 est.)
Television broadcast stations: NA
Televisions: 6,000 (1992 est.)
Telephones: 16,867 (1992 est.)
Telephone system: fair system
domestic: network consists principally of microwave
radio relay and low-capacity, low-powered
radiotelephone communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 3 (including
Africa No. 1 and R. France Internationale stations
located in Bangui), shortwave 1 (1998)
Radios: NA
Television broadcast stations: NA
Televisions: 7,500 (1993 est.)
Telephones: 5,000 (1987 est.)
Telephone system: primitive system
domestic: fair system of radiotelephone
communication stations
international: satellite earth station • 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave
3 (one of the shortwave stations has three
frequencies) (1998)
Radios: NA
Television broadcast stations: 1 (broadcasts 1800
to 2100 hours, four days per week) (1997)
Televisions: 7,000(1991 est.)
Telephones: 105,000 (1992 est.)
Telephone system: inadequate system
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 176, FM 0,
shortwave 7
Radios: 2.115 million (1992 est.)
Television broadcast stations: 1 1 (in addition,
there are 17 repeaters) (1997)
Televisions: 400,000 (1992 est.)','9ed4e0c97be8cacd031257c9b3115128d33f0479f225669337cbcd7f38507e0e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d55dc28b4a3937f07a9b3813b6af05b4e5010475e5706ade08198438992b8cf8',1999,'CL','Chile','communications',261,'Telephones: 1 .5 million (1994 est.)
Telephone system: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay links;
domestic satellite system with 3 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 180 (eight inactive),
FM 64, shortwave 17 (one inactive) (1998)
Radios: NA
Television broadcast stations: 63 (in addition,
there are 121 repeaters) (1997)
Televisions: 2.85 million (1992 est.)','9ec6a9baf431f9e3e7679a7a39299d0a91f1d4ef5dcbb75a7668a73bb12971e0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b965d0bbc7b834379b9c54f6c5c6084524c7b4f68eb91dad8d06a52e206c29d',1999,'HK','Hong Kong','communications',271,'Telephones: 1 05 million (1 998 est.)
Telephone system: domestic and international
services are increasingly available for private use;
unevenly distributed domestic system serves principal
cities, industrial centers, and all townships
domestic: interprovincial fiber-optic trunk lines and
cellular telephone systems have been installed; a
domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 Indian Ocean), 1 Intersputnik
(Indian Ocean Region) and 1 Inmarsat (Pacific and
Indian Ocean Regions); several international
fiber-optic links to Japan, South Korea, Hong Kong,
Russia, and Germany
Radio broadcast stations: AM 569, FM NA,
shortwave 173
Radios: 216.5 million (1992 est.)
Television broadcast stations: 209 (China Central
Television, government-owned; in addition there are
31 provincial TV stations and nearly 3,000 city TV
stations) (1997)
Televisions: 300 million','c5c62c43908d97f7e89cda6bbace7920ba07961e4ba3f96f19fe877c01aaa4cf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d2d31d724fbffa5da94b96f804c7ebcca5246658bfbc6fefb29cb39c235ef4e',1999,'CX','Christmas Island','communications',279,'Telephones: NA
Telephone system:
domestic: NA
international: NA
note: external telephone and telex services are
provided by Intelsat satellite
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 500(1992)
Television broadcast stations: NA (1997)
Televisions: 350 (1992)','91849cb57d9adbf233f953bbe4c39c86f4fe527aa8886631a6ffb2f08c5a0fe9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('326cb15a45ba0a72aa8ceda0fceec98abab5897db4469e49c45bf7f9f9cb595e',1999,'FR','France','communications',288,'Telephones: NA
Telephone system:
domestic: NA
international: telephone, telex, and facsimile
communications with Australia and elsewhere via
satellite; 1 satellite earth station of NA type
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 300 (1992 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 200,000 (1988 est.)
Telephone system: well-developed by African
standards but operating well below capacity
domestic: open-wire lines and microwave radio relay
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean); 2 coaxial
submarine cables
Radio broadcast stations: AM 71 , FM 4, shortwave
13
Radios: NA
Television broadcast stations: 14(1 997)
Televisions: 810,000 (1993 est.)
Telephones: 1,180 (1991 est.)
Telephone system:
domestic: government-operated radiotelephone and
private VHF/CB radiotelephone networks provide
effective service to almost all points on both islands
international: satellite earth station - 1 Intelsat
(Atlantic Ocean) with links through London to other
countries
Radio broadcast stations: 1 (government
operated)
Radios: 1,000 (1992 est.)
Television broadcast stations: 2 (operated by the
British Forces Broadcasting Service) (1 997)
Televisions: NA
Telephones: 31 ,000 (1990 est.)
Telephone system:
domestic: fair open wire and microwave radio relay
system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 5, FM 7, shortwave
0
Radios: 79,000 (1 992 est.)
Television broadcast stations: 3 (in addition, there
are eight low-power repeaters) (1997)
Televisions: 22,000 (1992 est.)
Telephones: 5,571,293 (1993 est.)
Telephone system: adequate, modern networks
reach all areas; microwave radio relay carries most
traffic; extensive open-wire network; submarine
cables to off-shore islands
domestic: microwave radio relay, open wire, and
submarine cable
international: tropospheric scatter; 8 submarine
cables; satellite earth stations - 2 Intelsat (1 Atlantic
Ocean and 1 Indian Ocean), 1 Eutelsat, and 1
Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 29, FM 17
(repeaters 20), shortwave 0
Radios: NA
Television broadcast stations: 64 (in addition,
there are about 1 ,000 low-power repeaters and two
stations in the US armed forces network) (1997)
Televisions: 2.3 million (1993 est.)
Telephones: 64,916 (1984 est.)
Telephone system: domestic facilities inadequate
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); microwave radio relay to Antigua
and Barbuda, Dominica, and Martinique
Radio broadcast stations: AM 2, FM 8 (private
stations licensed to broadcast FM 30), shortwave 0
Radios: 100,000 (1993 est.)
Television broadcast stations: 5 (in addition, there
are several low-power repeaters) (1997)
Televisions: 1 50,000 (1 993 est.)
Telephones: 28,000 (1998 est.)
Telephone system: service to general public is poor
but improving, with over 28,000 telephones currently
in service and an additional 48,000 expected by 2001 ;
the government relies on a radiotelephone network to
communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 Intersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 9, FM 5, shortwave
4(1998)
Radios: 580,000 (1995)
Television broadcast stations: 4 (1997)
Televisions: 32,000 (1993 est.)
Telephones: 209,672 (1994 est.)
Telephone system: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe,
Dominica, and Saint Lucia; satellite earth stations - 2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 6, shortwave
0
Radios: 74,000 (1992 est.)
Television broadcast stations: 1 1 (in addition,
there are nine repeaters) (1997)
Televisions: 65,000 (1993 est.)
Telephones: 219,000(1995)
Telephone system: adequate system; principal
center is Saint-Denis
domestic: modern open wire and microwave radio
relay network
international: radiotelephone communication to
Comoros, France, Madagascar; new microwave route
to Mauritius; satellite earth station - 1 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 3, FM 1 3, shortwave
0
Radios: 158,000(1994)
Television broadcast stations: 22 (in addition,
there are 18 low-power repeaters) (1997)
Televisions: 116,181 (1992 est.)
Telephones: 560,000 (1996 est.); 3,185 cellular
telephone subscribers (1998 est.)
Telephone system: the system is above the African
average and is continuing to be upgraded; key centers
are Sfax, Sousse, Bizerte, and Tunis; Internet access
is available through two private service providers
licensed by the government
domestic: trunk facilities consist of open-wire lines,
coaxial cable, and microwave radio relay
international: 5 submarine cables; satellite earth
stations - 1 Intelsat (Atlantic Ocean) and 1 Arabsat
with back-up control station; coaxial cable and
microwave radio relay to Algeria and Libya; participant
in Medarabtel
487
Tunisia (continued)
Radio broadcast stations: AM 7, FM 8, shortwave
1 (1998 est.)
Radios: 1.7 million (1998 est.)
Television broadcast stations: 19 (these are
network stations; there are some additional stations of
low power) (1997)
Televisions: 650,000 (1998 est.)
Telephones: 17 million (in addition, there are 1.5
million cellular telephone subscribers) (1997 est.)
Telephone system: fair domestic and international
systems; undergoing modernization and
refurbishment programs
domestic: cable; AMPS standard cellular system in
Ashkhabad with plans for expansion
international: 12 satellite earth stations - Intelsat
(Atlantic Ocean), Eutelsat, and Inmarsat (Indian and
Atlantic Ocean regions); 3 submarine fiber-optic
cables (1996); connected internationally by the
Trans-Asia-Europe Fiber-Optic Line that became
operational in 1998
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: there are 36 national broadcast stations, 1 08
regional broadcast stations, and 1 ,058 local broadcast
stations (1996)
Radios: 9.4 million (1992 est.)
Television broadcast stations: 69 (in addition,
there are 476 low-power repeaters) (1997)
Televisions: 10.53 million (1993 est.)
Telephones: NA
Telephone system: poorly developed
domestic: NA
international: linked by cable and microwave radio
relay to other CIS republics and to other countries by
leased connections to the Moscow international
gateway switch; a new telephone link from Ashgabat
to Iran has been established; a new exchange in
Ashgabat switches international traffic through Turkey
via Intelsat; satellite earth stations - 1 Orbita and 1
Intelsat
Radio broadcast stations: 1 state-owned radio
broadcast station of NA type
Radios: NA
Television broadcast stations: 3 (much
programming relayed from Russia and Turkey) (1997)
Televisions: NA
Telephones: 29.5 million (1987 est.)
Telephone system: technologically advanced
domestic and international system
domestic: equal mix of buried cables, microwave
radio relay, and fiber-optic systems
international: 40 coaxial submarine cables; satellite
earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 Inmarsat (Atlantic Ocean region),
and 1 Eutelsat; at least 8 large international switching
centers
Radio broadcast stations: AM 225, FM 525 (mostly
repeaters), shortwave 0
Radios: 70 million
Television broadcast stations: 78 (in addition,
there are 869 repeaters) (1997)
Televisions: 20 million
Telephones: 182.558 million (1987 est.)
Telephone system:
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries conventional telephone traffic; a
rapidly growing cellular system carries mobile
telephone traffic throughout country
international: 24 ocean cable systems in use; satellite
earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region),
and 4 Inmarsat (Pacific and Atlantic Ocean regions)
(1990 est.)
Radio broadcast stations: AM 4,987, FM 4,932,
shortwave 0
Radios: 540.5 million (1992 est.)
Television broadcast stations: more than 1 ,500
(including nearly 1 ,000 stations affiliated with the five
major networks - NBC, ABC, CBS, FOX, and PBS; in
addition, there are about 9,000 cable TV systems)
(1997)
Televisions: 215 million (1993 est.)
Telephones: NA; 3.1% of Palestinian households
have telephones
Telephone system:
domestic: NA
international: NA ,
note: Israeli company BEZEK and the Palestinian
company PALTEL are responsible for communication
services in the West Bank
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: NA; note - 82% of Palestinian households
have radios (1992 est.)
Television broadcast stations: NA
Televisions: NA; note - 54% of Palestinian
households have televisions (1992 est.)','514efe264522e97f00cd9f5f3766f30aa9828650b4ced5804119fabaf48d26ff','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eef77cdec618af8ea6d613ee89dabff7525d37ea961f61e93071be8140f674b',1999,'CO','Colombia','communications',296,'Telephones: 1 .89 million (1 986 est.)
Telephone system: modern system in many
respects
domestic: nationwide microwave radio relay system;
domestic satellite system with 1 1 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 463, FM 35,
shortwave 45 (1998 est.)
Radios: NA
Television broadcast stations: 60 (includes seven
low-power stations) (1997)
Televisions: 5.5 million (1993 est.)','c843e9b3b4adacd5ea594189e521aa83f0dda0707744ad7905aeed5fe23b9893','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dc3fef8cae82869ccc45ea96bd43457d6c4c965531e4696d8a99296c179a85d',1999,'MZ','Mozambique','communications',300,'Telephones: 4,000 (1993 est.)
Telephone system: sparse system of microwave
radio relay and HF radiotelephone communication
stations
domestic: HF radiotelephone communications and
microwave radio relay
international: HF radiotelephone communications to
Madagascar and Reunion
Radio broadcast stations: AM 2, FM 1 , shortwave
0
Radios: 81,000(1994)
Television broadcast stations: 0 (1998)
Televisions: 200(1994
Telephones: 70,000 (1998 est.)
Telephone system: fair system of tropospheric
scatter, open-wire lines, and microwave radio relay
338
Mozambique (continued)
domestic: microwave radio relay and tropospheric
scatter
international: satellite earth stations - 5 Intelsat (2
Atlantic Ocean and 3 Indian Ocean)
Radio broadcast stations: AM 29, FM 4, shortwave
0
Radios: 700,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 44,000 (1992 est.)
Telephones: 1 1 .526 million (1 998 est.)
Telephone system:
domestic: extensive microwave radio relay trunk
system on east and west coasts
international: satellite earth stations - 2 Intelsat (1
Pacific Ocean and 1 1ndian Ocean); submarine cables
to Japan (Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle East, and
Western Europe
Radio broadcast stations: AM 158, FM 48,
shortwave 21
Radios: 8.62 million
Television broadcast stations: 29 (in addition,
there are two repeaters) (1997)
Televisions: 1 0.8 million (1 996 est.)','6d5b1c12232c66263b7f004f724d676fafaf0244c49cca81f2a66fbf64ddd058','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8704f93bc6dfa0708b2ca7563f16ed1bacb47a9e705409b82c5031f87cb823',1999,'CG','Congo','communications',303,'Telephones: 34,000(1991 est.)
Telephone system:
domestic: barely adequate wire and microwave radio
relay service in and between urban areas; domestic
satellite system with 14 earth stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 10, FM 4, shortwave
0
Radios: 3.87 million (1992 est.)
Television broadcast stations: 18 (1997)
Televisions: 55,000 (1992 est.)
Telephones: 18,000 (1983 est.)
Telephone system: services barely adequate for
government use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; inter-city lines frequently
out-of-order
domestic: primary network consists of microwave
radio relay and coaxial cable
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 1 , shortwave
0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 8,500 (1993 est.)','6adcbfa8dab9987f0462d5e14c94ed69e72ea4a51e484b809c145e6c69f18e46','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f4ab7ab693ec39c0845b69938f782d4055b93c86ee0f1422d63dec4cb0c98d8',1999,'CK','Cook Islands','communications',315,'Telephones: 4,180(1994)
Telephone system:
domestic: the individual islands are connected by a
combination of satellite earth stations, microwave
systems, and VHF and HF radiotelephone; within the
islands, service is provided by small exchanges
connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave
1
Radios: 13,000 (1994 est.)
Television broadcast stations: 2 (in addition, eight
low-power repeaters provide good coverage on the
island of Rarotonga) (1997)
Televisions: 3,500 (1995 est.)','3713f5e8b3f999e847b7e0c86fcbce1d666ae858a58cede5ce51e1ff0d817d62','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('213b39c753fb9e237cf2e523afa6ee6c7b7b7b12c178f365f701a123cd92553f',1999,'CR','Costa Rica','communications',322,'Telephones: 281 ,042 (1983 est.)
Telephone system: very good domestic telephone
service
domestic: NA
international: connected to Central American
Microwave System; satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 71 , FM 0, shortwave
13
Radios: NA
Television broadcast stations: 6 (in addition, there
are 11 repeaters) (1997)
Televisions: 340,000 (1993 est.)','844949c74f44227cccae7df47454b3717fda012f3ee9b88eb7e7250513caa1f7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9859b77fcd2bcfbf437f710b9e4563e87653e4183ed01735a046269672be4c0',1999,'SI','Slovenia','communications',331,'Telephones: 1 .21 6 million (1 993 est.)
Telephone system:
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 14, FM 8, shortwave
0
Radios: 1,1 million
Television broadcast stations: 18 (in addition,
there are 145 repeaters) (1997)
Televisions: 1 .52 million (1992 est.)','cd4ae448fc62c4e4d049538dfda49361259b0f5f3ab517ac17982bc97b18c96c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f5531422ed48adbfc22cf11e9b054f471c309ce928b865a7c91d6a5e26d548',1999,'CU','Cuba','communications',340,'Telephones: 229,000
Telephone system: among the world''s least
developed telephone systems
domestic: NA
international: satellite earth station - 1 1ntersputnik
(Atlantic Ocean region)
Radio broadcast stations: AM 150, FM 5,
shortwave 1
Radios: 2.14 million (1993 est.)
Television broadcast stations: 58 (1997)
Televisions: 2.5 million (1993 est.)','89c2e6c54b33adfa2f4a56734365922cea0d96551280cffc9bd322a4465a984d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9af3ab41951a987e03799c190693afffee35e65ea13beeff3113db80ddccd358',1999,'CY','Cyprus','communications',348,'Telephones: Greek Cypriot area: 367,000 (1996
est.); Turkish Cypriot area: 80,000 (1996 est.)
Telephone system: excellent in both the Greek
Cypriot and Turkish Cypriot areas
domestic: open wire, fiber-optic cable, and microwave
radio relay
international: tropospheric scatter; 3 coaxial and 5
fiber-optic submarine cables; satellite earth stations -
3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean), 2
Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AM
4, FM 36, shortwave 1, Turkish Cypriot area: AM 2,
FM 6, shortwave 0
Radios: Greek Cypriot area: 500,000 (1996 est.);
Turkish Cypriot area: 130,000 (1996 est.)
Television broadcast stations: Greek Cypriot
area: 7 (in addition, there are 35 low-power repeaters)
(1997); Turkish Cypriot area: 3 (in addition, there are
4 repeaters) (1997)
Televisions: Greek Cypriot area: 300,000 (1996
est.); Turkish Cypriot area: 90,000 (1996 est.)','6a32c15b8ecbc7f208cb60d041d79dd1de7410699bfb8a72efaded1d7fcd8057','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ef91212138c1a4999ee427c706e38e05556e91864f7f235d4ba28b54c4ac9f',1999,'PL','Poland','communications',358,'Telephones: 3,349,539 (1993 est.)
132
Czech Republic (continued)
Czech Republic insists that restitution does not go
back before February 1948, when the communists
seized power; individual Sudeten German claims for
restitution of property confiscated in connection with
their expulsion after World War II; unresolved property
issues with Slovakia over redistribution of former
Czechoslovak federal property
Illicit drugs: transshipment point for Southwest
Asian heroin and hashish and Latin American cocaine
to Western Europe; domestic consumption -
especially of locally produced synthetic drugs - on the
rise','fbbc60c43fb32e79d9de86e46c5f97a1ba42424ca7ff5069b13bac967a6775c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d08d43a42f01cc9b3c2fb628075f9cf10c958ac04540d87427e2074ef4f17b9b',1999,'DK','Denmark','communications',359,'Telephone system:
domestic: NA
international: satellite earth stations - 2 Intersputnik
(Atlantic and Indian Ocean regions)
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Radios: NA
Television broadcast stations: 67 (in addition,
there are 35 low-power stations and about 51
low-power repeaters) (1997)
Televisions: NA
Telephones: 3.2 million (1995 est.); 822,000 cellular
telephone subscribers
Telephone system: excellent telephone and
telegraph services
domestic: buried and submarine cables and
microwave radio relay form trunk network, four cellular
radio communications systems
international: 18 submarine fiber-optic cables linking
Denmark with Norway, Sweden, Russia, Poland,
Germany, Netherlands, UK, Faroe Islands, Iceland,
and Canada; satellite earth stations - 6 Intelsat, 10
Eutelsat, 1 Orion, 1 1nmarsat
(Blaavand-Atlantic-East); note - the Nordic countries
(Denmark, Finland, Iceland, Norway, and Sweden)
share the Danish earth station and the Eik, Norway,
station for world-wide Inmarsat access
Radio broadcast stations: AM 2, FM 3, shortwave
0
Radios: NA
Television broadcast stations: 78 (of which 35 are
low-power stations; in addition, there are 51
low-power repeaters) (1997)
Televisions: 3 million (1996 est.)
Telephones: 7,200 (1986 est.)
Telephone system: telephone facilities in the city of
Djibouti are adequate as are the microwave radio
relay connections to outlying areas of the country
domestic: microwave radio relay network
international: submarine cable to Jiddah, Suez, Sicily,
Marseilles, Colombo, and Singapore; satellite earth
stations - 1 Intelsat (Indian Ocean) and 1 Arabsat;
Medarabtel regional microwave radio relay telephone
network
Radio broadcast stations: AM 1, FM 2, shortwave
0
Radios: 35,000
Television broadcast stations: 1 (in addition, there
are 5 low-power repeaters) (1998)
Televisions: 17,000 (1998)','d19862d1a7e3fdde42a57cae71b9c8a5c017f6affff6ee97562e3828faee1aa6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ffd55d9315625675ec1a8707d888b85c39f77463c9330d739da235cd808cecb',1999,'DM','Dominica','communications',371,'Telephones: 14,613 (1993 est.)
Telephone system:
domestic: fully automatic network
international: microwave radio relay and SHF
radiotelephone links to Martinique and Guadeloupe;
VHF and UHF radiotelephone links to Saint Lucia
Radio broadcast stations: AM 3, FM 2, shortwave
0
Radios: 45,000 (1993 est.)
Television broadcast stations: 0 (there is one
cable television company) (1997)
Televisions: 5,200 (1993 est.)','11ba04dcb9cef523bb395ba49e5c8c57c009100a3802cc6cf7725d7e8424e6fa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8847256d4804fdad1c971fe0962ad174c04f7d96c4bd423e0a54dc9a2a13519',1999,'DO','Dominican Republic','communications',378,'Telephones: 190,000 (1987 est.)
Telephone system:
domestic: relatively efficient system based on
islandwide microwave radio relay network
international: 1 coaxial submarine cable; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 0,
shortwave 6
Radios: NA
Television broadcast stations: 25 (1 997)
Televisions: 728,000 (1 993 est.)
Telephones: 1.389 million (1996 est.)
Telephone system: modern system, integrated with
that of the US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system with about 1
million lines (1990 est.); cellular telephone service
396
Puerto RiCO (continued)
international: satellite earth station - 1 Intelsat;
submarine cable to US
Radio broadcast stations: AM 50, FM 63,
shortwave 0
note: there were 118 radio stations in 1995
Radios: 2.6 million (1994 est.)
Television broadcast stations: 18 (in addition,
there are three stations of the US Armed Forces Radio
and Television Service) (1997)
Televisions: 973,000 (1994 est.)','6405496cfa35a05b501950036f3ae1ba3a3715509ea4a63ca7691cbe016cda07','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2395a7a633f91ab9b93bb2f27fef5b56a56946c36c9d97570d58d2814dc6d7',1999,'PE','Peru','communications',383,'Telephones: 586,300 (1994 est.)
Telephone system:
domestic: facilities generally inadequate and
unreliable
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 272, FM 0,
shortwave 39
Radios: NA
Television broadcast stations: 15 (including one
station on the Galapagos Islands) (1997)
Televisions: 940,000 (1992 est.)','9c71bd244e6144ebc5aeba3be21c09c59e60742e09c9c9df204399eae55c424e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b662123e989101fec3b11f123ba7adb1a45a0f15045348b6224e32ef958927a',1999,'EG','Egypt','communications',392,'Telephones: 3.168 million (1996); 70,000 digital
cellular telephone subscribers (1998); 7,400 analog
cellular telephone subscribers (1997)
Telephone system: large system by Third World
standards but inadequate for present requirements
and undergoing extensive upgrading
domestic: principal centers at Alexandria, Cairo, Al
Mansurah, Ismailia, Suez, and Tanta are connected
by coaxial cable and microwave radio relay
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean), 1 Arabsat, and 1
Inmarsat; 5 coaxial submarine cables; tropospheric
scatter to Sudan; microwave radio relay to Israel;
participant in Medarabtel
Radio broadcast stations: AM 57, FM 14,
shortwave 3 (1998 est.)
Radios: 16.45 million (1998 est.)
Television broadcast stations: 42 (in addition,
there are nine channels received from Europe by
satellite) (1997)
Televisions: 5 million (1998 est.)
Telephones: 350,000 (1997 est.)
Telephone system:
domestic: nationwide microwave radio relay system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 18, FM 80,
shortwave 2
Radios: 1 .5 million (1 997 est.)
Television broadcast stations: 5 (1997)
Televisions: 700,000 (1997 est.)','807ee453361617fb8eb94a53a23015ed7c1e94adec0b5f73af33ecd7f7359f41','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22e97f3774373289396cf728ad1f15256c72d48d21ddb7701446f7096743b221',1999,'GN','Guinea','communications',398,'Telephones: 2,000 (1987 est.)
Telephone system: poor system with adequate
government services
domestic: NA
international: international communications from Bata
and Malabo to African and European countries;
satellite earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave
0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 4,000 (1992 est.)
150
Equatorial Guinea (continued)
Telephones: NA
Telephone system:
domestic: very inadequate; about 4 telephones per
100 families, most of which are in Asmara;
government is seeking international tenders to
improve the system
international: NA
Radio broadcast stations: AM 2, FM 0, shortwave
1
Radios: NA
Television broadcast stations: 1 (government
controlled) (1997)
Televisions: NA
Telephones: 63,212 (1986 est.)
Telephone system: services are adequate and
being improved; facilities provide radiotelephone and
telegraph, coastal radio, aeronautical radio, and
international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and
Guam; satellite earth station - 1 Intelsat (Pacific
Ocean); international radio communication service
Radio broadcast stations: AM 31 , FM 2, shortwave
0
Radios: 298,000 (1992 est.)
Television broadcast stations: 3 (1997)
Televisions: 1 0,000 (1 992 est.)','a029bdaeba7acc89b6d06366fd5d6132a2ce4d5fa490ee3d697cf824835ad49c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1bf654ee2b93fa482c5877a1823cb6e2cf5c299c897a1ae53b0f34f7947038',1999,'EE','Estonia','communications',410,'Telephones: 531,000(1997)
Telephone system: the Ministry of Transportation
and Communications (MOTC) administers Estonia''s
telephone system; Internet services available
throughout most of the country; about 1 50,000 unfilled
subscriber requests
domestic: local - cellular phones services are growing
and expanding to develop rural networks under
direction of the MOTC; intercity - Estonia has a highly
developed fiber-optic backbone (double loop) system
presently serving at least 16 major cities (1998)
international: foreign investment in the form of joint
business ventures greatly improved Estonia''s
telephone service; fiber-optic cables to Finland,
Sweden, Latvia, and Russia provide worldwide packet
switched service
Radio broadcast stations: 27 commercial
broadcast stations, 1 government broadcast station
(1 997); note - by law 51 % of shows must be produced
within the EU; equal air time must be given to all
candidates during elections by public and private
stations
Radios: 1.12 million (1997 est.)
Television broadcast stations: 7 (1997); note -
Ministry of Culture administers television licensing;
mainly Estonian, European, and Russian
programming; by law 51% of shows must be produced
within the EU; equal air time must be given to all
candidates during elections by public and private
stations
Televisions: 1.132 million (1997 est.)','b1ec54c38f40a7d0099bab0b6b32eba35938e3db2f1908a1da013de8719619b7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac06ea8aa6e875535add5b00c9c490a0037832fcf1cefb6464e0f98a54bdc33e',1999,'ET','Ethiopia','communications',417,'Telephones: 100,000 (1983 est.)
Telephone system: open wire and microwave radio
relay system adequate for government use
domestic: open wire and microwave radio relay
international: open wire to Sudan and Djibouti;
microwave radio relay to Kenya and Djibouti; satellite
earth stations - 3 Intelsat (1 Atlantic Ocean and 2
Pacific Ocean)
Radio broadcast stations: AM 5, FM 0, shortwave
1
Radios: 9 million (1998 est.)
Television broadcast stations: 25 (1998)
Televisions: 150,000 (1998 est.)
Telephones: 13,120 (1997 est.)
Telephone system: small system
domestic: combination of microwave radio relay,
open-wire lines, radiotelephone, and cellular
international: NA
Radio broadcast stations: AM 2, FM 3, shortwave
0
Radios: 40,000 (1994 est.)
Television broadcast stations: 2 (1 997)
Televisions: NA
Telephones: 2,200 (1986 est.)
Telephone system:
domestic: minimal system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 2, shortwave
0
Radios: 33,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: NA','a05e380df3313d6493a70e89f44994f6280744178991e36153b3885ec4c0d991','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f99030576b5e97ec94225612c7998e815cd0960e39d45465e6a2b9329a1857f',1999,'FO','Faroe Islands','communications',429,'Telephones: 22,500 (3,500 cellular telephone
subscribers) (1996)
Telephone system: good international
communications; good domestic facilities
domestic: digitalization was to hve been completed in
1998
international: satellite earth stations - 1 Orion; 1
fiber-optic submarine cable linking the Faroe Islands
with Denmark and Iceland
Radio broadcast stations: AM 1 , FM 1 (repeaters
13), shortwave 0
Radios: 11,800 (1996 est.)
Television broadcast stations: 3 (in addition, there
are 29 low-power repeaters; satellite relays of MTV
Europe, BBC World, and Scansat TV3 Eurosport are
also available) (1997)
Televisions: 1 1 ,600 (1996 est.)','e3368427927446daa4bf600934084890a18f4334b7f72165513d938fba0a442e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f7cee79d5a5bf38d650d99624256f7744cbb30756ef6d6598a598b965137cc',1999,'JE','Jersey','communications',438,'Telephones: 60,017 (1987 est.)
Telephone system: modern local, interisland, and
international (wire/radio integrated) public and
special-purpose telephone, telegraph, and teleprinter
facilities; regional radio communications center
domestic: NA
international: access to important cable link between
US and Canada and NZ and Australia; satellite earth
station - 1 1ntelsat (Pacific Ocean)
Radio broadcast stations: AM 7, FM 1 , shortwave
0
Radios: NA
Television broadcast stations: 0
Televisions: 12,000 (1992 est.)
Telephones: 2.6 million (1996)
Telephone system: most highly developed system
in the Middle East although not the largest
domestic: good system of coaxial cable and
microwave radio relay
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave
0
Radios: 2.25 million (1993 est.)
Television broadcast stations: 24 (in addition,
there are 31 low-power repeaters) (1 997)
Televisions: 1.5 million (1993 est.)
Telephones: 61,447 (1983 est.)
Telephone system:
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM 1 , FM 1 , shortwave
0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Telephone system: 13 outgoing and 10 incoming
commercial lines; adequate telecommunications
domestic: 60-channel submarine cable, 22 DSN
circuits by satellite, Autodin with standard remote
terminal, digital telephone switch, Military Affiliated
Radio System (MARS station), UHFA/HF air-ground
radio, a link to the Pacific Consolidated
Telecommunications Network (PCTN) satellite
international: NA
Radio broadcast stations: AM NA, FM 5 channels;
also 1 local volunteer FM radio station;, shortwave
NA;
Television broadcast stations: commercial
satellite television system, with 16 channels (1997)
Telephones: 408,000(1998)
Telephone system: the civil network suffered some
damage as a result of the Gulf war, but most of the
telephone exchanges were left intact and, by the end
of 1994, domestic and international
telecommunications had been restored to normal
operation; the quality of service is excellent
domestic: new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, open wire and
fiber-optic cable; a cellular telephone system operates
throughout Kuwait (with approximately 150,000
subscribers in 1996) and the country is well supplied
with pay telephones; approximately 15,000 Internet
subscribers in 1996
international: coaxial cable and microwave radio relay
to Saudi Arabia; satellite earth stations - 3 Intelsat (1
Atlantic Ocean, 2 Indian Ocean), 1 1nmarsat (Atlantic
Ocean), and 1 Arabsat
Radio broadcast stations: AM 3, FM 0, shortwave
0
Radios: 720,000 (1992 est.)
Television broadcast stations: 13 (in addition,
there are several satellite channels) (1997)
Televisions: 800,000 (1993 est.)
Telephones: 38,748 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave
0
Radios: 97,000 (1992 est.)
Television broadcast stations: 6 (in addition, there
are 25 low-power repeaters) (1997)
Televisions: 47,000 (1992 est.)
Telephones: 691 ,240 (1997 est.)
Telephone system:
domestic: 70% digital; full digitalization scheduled by
2000
international: NA
Radio broadcast stations: AM 6, FM 5, shortwave 0
note: there are more than 20 regional and local radio
broadcast stations
Radios: 596, 1 00 (1 993 est.)
Television broadcast stations: 23 (consisting of 20
network stations and three private stations; there are
also about 400 low-power repeaters) (1997)
Televisions: 454,400 (1993 est.)
Telephones: NA; 45,000 cellular telephone
subscribers (1993 est.)
Telephone system:
domestic: system consists of carrier-equipped,
open-wire lines and low-capacity, microwave radio
relay
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 7, FM 6, shortwave
0
Radios: 200,000 (1998 est.)
Television broadcast stations: 2 (in addition, there
are seven repeaters) (1997)
Televisions: 20,000 (1998 est.)
Telephones: 13 million (1996 est.)
Telephone system: excellent domestic and
international facilities; automatic system
domestic: coaxial and multiconductor cable carry
most voice traffic; parallel microwave radio relay
network carries some additional telephone channels
international: 5 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean), 1 Eutelsat,
and 1 Inmarsat (Atlantic and Indian Ocean regions);
note - Sweden shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations: AM 5, FM 360 (mostly
repeaters), shortwave 0
Radios: 7.272 million (1993 est.)
Television broadcast stations: 163 (1997)
Televisions: 3.5 million','8af6d276f54529e8ff32dbcf3e3421c55679dbdd50d17155fde0c15a2f567156','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c433be8bb1d9548ad74c4d471373046881dd4e4a0a2d7ed2f5333b703a12121a',1999,'FI','Finland','communications',447,'Telephones: 2.5 million (1995 est.)
Telephone system: modern system with excellent
service
domestic: cable, microwave radio relay, and an
extensive cellular net care for domestic needs
international: 1 submarine cable; satellite earth
stations - access to Intelsat transmission service via a
Swedish satellite earth station, 1 Inmarsat (Atlantic
and Indian Ocean regions); note - Finland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 6, FM 105,
shortwave 0
Radios: 4.98 million (1991 est.)
Television broadcast stations: 120 (in addition,
there are 431 low-power repeaters) (1997)
Televisions: 1 .92 million (1 995 est.)','ae3578632d27c0f4d7e602d051c514015614eb39e8c6a65b0d608c0e3a294d8f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a74a9c07d5d9d9a96f9532f550c146b7a4c0236ea30c6e5c638ee728dca1a7a',1999,'WF','Wallis and Futuna','communications',454,'Telephones: 35 million (1987 est.)
Telephone system: highly developed
domestic: extensive cable and microwave radio relay;
extensive introduction of fiber-optic cable; domestic
satellite system
international: satellite earth stations - 2 Intelsat (with
total of 5 antennas - 2 for Indian Ocean and 3 for
Atlantic Ocean), NA Eutelsat, 1 Inmarsat (Atlantic
Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41 , FM 800 (mostly
repeaters), shortwave 0
Radios: 49 million (1993 est.)
Television broadcast stations: 310 (in addition,
there are about 1,400 repeaters) (1997)
Televisions: 29.3 million (1993 est.)
Telephone system: satellite communications; 1
DSN circuit off the Overseas Telephone System
(OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA,
shortwave NA
note: Armed Forces Radio/Television Service
(AFRTS) radio service provided by satellite
Television broadcast stations: 0 (1997)','3d893480684404dfcb9b5ecbaceb0d7efbee72cbfbacafaa2b57b9f378e066e6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2307a98717830a000231962458f6624ab35814b2c545d786e6a0e5c697d6809',1999,'KI','Kiribati','communications',465,'Telephones: 33,200 (1983 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 5, FM 2, shortwave
0
Radios: 116,000 (1992 est.)
Television broadcast stations: 7 (in addition, there
are 17 low-power repeaters) (1997)
Televisions: 35,000 (1992 est.)','07a64d58494c04f6ce07055c0d543e09c5b298f33e3fa3dcc02e7ddda92cdd59','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9435934ed3a98ba0eb900a095dbd8ace79ca281091945953df9719259d268d3e',1999,'GA','Gabon','communications',472,'Telephones: 22,000 (1991 est.)
Telephone system:
domestic: adequate system of cable, microwave radio
relay, tropospheric scatter, radiotelephone
communication stations, and a domestic satellite
system with 12 earth stations
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 6, FM 6, shortwave
0
Radios: 250,000 (1993 est.)
Television broadcast stations: 4 (in addition, there
are five low-power repeaters) (1997)
Televisions: 40,000 (1993 est.)
Telephones: 11,000 (1991 est.)
Telephone system:
domestic: adequate network of microwave radio relay
and open wire
178
Gambia, The (continued)
international: microwave radio relay links to Senegal
and Guinea-Bissau; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 5, shortwave
0
Radios: 1 80,000 (1 993 est.)
Television broadcast stations: 1 (government
owned) (1997)
Televisions: NA
Telephones: NA; 3.1% of Palestinian households
have telephones
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM 0, shortwave
0
Radios: NA; note - 95% of Palestinian households
have radios (1992 est.)
Television broadcast stations: 2 (operated by the
Palestinian Broadcasting Corp.) (1997)
Televisions: NA; note - 59% of Palestinian
households have televisions (1992 est.)','ab6f6dfe356c5f4fedea55cccf67ffb952da7accf1540a4f35d93fc8d2f0b67b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e32ee95b89736191dac6478374057ea6ba5e02b8741065449ff479637339d3a',1999,'GH','Ghana','communications',483,'Telephones: 100,000 (1997 est.)
Telephone system: poor to fair system
domestic: primarily microwave radio relay
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 23, shortwave
0(1997)
Radios: 12.5 million (1997 est.)
Television broadcast stations: 7 (in addition, there
are eight repeaters) (1997)
Televisions: 1.9 million (1997 est.)','7982b9949f8b356be12693fa2a2e10eecc0d12a3fa1a2d820b31924364575200','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0bbf53130dfbaa32269c04707d647504f5f50e64b5b36fac3d32a834d778635',1999,'ES','Spain','communications',491,'Telephones: 19,356(1994)
Telephone system: adequate, automatic domestic
system and adequate international facilities
domestic: automatic exchange facilities
international: radiotelephone; microwave radio relay;
satellite earth station - 1 Intelsat (Atlantic Ocean)
189
Gibraltar (continued)
Radio broadcast stations: AM 1 , FM 6, shortwave
0
Radios: NA
Television broadcast stations: 1 (in addition, there
are 3 low-power repeaters) (1997)
Televisions: NA
j: Transportation
Railways:
total: NA km; 1 .000-m gauge system in dockyard area
only
Highways:
total: 49.9 km
paved: 49.9 km
unpaved: 0 km
Pipelines: Okm
Ports and harbors: Gibraltar
Merchant marine:
total: 1 8 ships (1 ,000 GRT or over) totaling 346m951
GRT/588,765 DWT
ships by type: chemical tanker 2, container 4, oil
tanker 11, roll-on/roll-off cargo 1 (1998 est.)
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Telephones: 12.6 million (1990 est.)
Telephone system: generally adequate, modern
facilities
domestic: NA
international: 22 coaxial submarine cables; satellite
earth stations - 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat, NA Inmarsat, and NA
Marecs; tropospheric scatter to adjacent countries
Radio broadcast stations: AM 190, FM 406
(repeaters 134), shortwave 0
Radios: 12 million (1992 est.)
Television broadcast stations: 542 (382 network
stations, 160 low-power stations, and one US Air
Force Europe station) (1997)
Televisions: 15.7 million (1992 est.)','7ffd501b394401b1c0c43f15b5741d8b28d73b25f97cbb0058e5dc5fac395589','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12c9977e99809f5425596e81e52dc248a3a0feda569495f8cde2e8f3f8510bf5',1999,'GL','Greenland','communications',499,'Telephones: 19,600 (1995 est.)
Telephone system: adequate domestic and
international service provided by cables and
microwave radio relay; totally digitalized in 1995
domestic: microwave radio relay
international: 2 coaxial submarine cables; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: 1 publicly-owned station
and some local radio and TV stations
Radios: 23,000 (1991 est.)
Television broadcast stations: 1 publicly-owned
station and some local low-power stations; in addition,
there are three AFRTS (US Air Force) stations which
broadcast in the NTSC system (1997)
Televisions: 12,000 (1991 est.)','8c1ee52c1e42712c6e4d009704802a9c443d8212265459d6da47fc80dc1220d4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afcbb9a85e6a4c3acd196a7b36aad91ab0831d3d0d92654efa451bfe1db87f05',1999,'GD','Grenada','communications',505,'Telephones: 5,650 (1988 est.)
Telephone system: automatic, islandwide
telephone system
domestic: interisland VHF and UHF radiotelephone
links
international: new SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 80,000 (1993 est.)
Television broadcast stations: 2 (1997)
Televisions: 30,000 (1993 est.)
Telephones: 6,189 (1983 est.)
Telephone system:
domestic: islandwide, fully automatic telephone
system; VHF/UHF radiotelephone from Saint Vincent
to the other islands of the Grenadines
international: VHF/UHF radiotelephone from Saint
Vincent to Barbados; new SHF radiotelephone to
Grenada and to Saint Lucia; access to Intelsat earth
station in Martinique through Saint Lucia
Radio broadcast stations: AM 2, FM 0, shortwave
0
Radios: 76,000 (1992 est.)
Television broadcast stations: 1 (in addition, there
are three repeaters) (1997)
Televisions: 20,600 (1992 est.)','d784d07551541193fee27782bffcf47d4a31326170e476d6b883406cba9b5f20','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d353dbe1468297d686640b1a60c047ab3a76a63eeab9715af8efc4d2c74fc4',1999,'GU','Guam','communications',514,'Telephones: 74,317 (March 1997)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
Radio broadcast stations: AM 3, FM 3, shortwave
0
Radios: 206,000(1994)
Television broadcast stations: 5 (1997)
Televisions: 97,000 (1994 est.)
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (1992 est.)
Labor force: 65,660(1995)
Labor force - by occupation: federal and territorial
government 31%, private 69% (trade 21%, services
33%, construction 12%, other 3%) (1995)
Unemployment rate: 2% (1992 est.)
Budget:
revenues: $524.3 million
expenditures: $361 .4 million, including capital
expenditures of $NA (1995)
Industries: US military, tourism, construction,
transshipment services, concrete products, printing
and publishing, food processing, textiles
Industrial production growth rate: NA%
Electricity - production: 800 million kWh (1996)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1996)
Electricity - consumption: 800 million kWh (1996)
Electricity - exports: 0 kWh (1996)
Electricity - imports: 0 kWh (1996)
Agriculture - products: fruits, copra, vegetables;
eggs, pork, poultry, beef
Exports: $86.1 million (f.o.b., 1992)
Exports - commodities: mostly transshipments of
refined petroleum products, construction materials,
fish, food and beverage products
Exports - partners: US 25%
Imports: $202,4 million (c.i.f., 1992)
Imports - commodities: petroleum and petroleum
products, food, manufactured goods
Imports - partners: US 23%, Japan 1 9%, other 58%
Debt - external: $NA
Economic aid - recipient: $NA; note - although
Guam receives no foreign aid, it does receive large
transfer payments from the general revenues of the
US Federal Treasury into which Guamanians pay no
Telephones: 210,000 (1993 est.)
Telephone system: fairly modern network centered
in the city of Guatemala
domestic: NA
international: connected to Central American
Microwave System; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 91 , FM 0, shortwave
15
Radios: 400,000 (1993 est.)
Television broadcast stations: 6 (in addition, there
are 17 repeaters) (1997)
Televisions: 475,000 (1993 est.)','0f529a614272f955cbb8c7d10351eef5a284e0ddcb3e36840ed4f7e7dc7fca63','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cc95047efacc2ab10949639405d40c5e41829accf8e68f543274884d7fe670b',1999,'GG','Guernsey','communications',521,'Telephones: 41 ,850(1 983 est.)
Telephone system:
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1 , FM 1 , shortwave
0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Telephones: 18,000 (1994 est.)
Telephone system: poor to fair system of open-wire
lines, small radiotelephone communication stations,
and new microwave radio relay system
domestic: microwave radio relay and radiotelephone
communication
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1 , shortwave
0
Radios: 257,000 (1992 est.)
Television broadcast stations: 6 (1997)
Televisions: 65,000 (1993 est.)
205
Guinea (continued)','febb670c1a2a977be22d90abe962d25279a6feec6d81848064f6422565c250d7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10ffba701863c226fae21d5bb4c3069aa3ca5ad7a02cbd69dd9a473df908b9aa',1999,'GY','Guyana','communications',532,'Telephones: 33,000 (1987 est.)
Telephone system: fair system for long-distance
calling
domestic: microwave radio relay network for trunk
lines
international: tropospheric scatter to T rinidad; satellite
209
Guyana (continued)
earth station ■ 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave
1
Radios: 398,000 (1992 est.)
Television broadcast stations: 1 public station;
two private stations relay US satellite services (1997)
Televisions: 32,000 (1992 est.)
Telephones: NA
Telephone system:
domestic: local telephone service
international: satellite earth station - 1 of NA type (for
communication with Norwegian mainland only)
Radio broadcast stations: AM 1 , FM 1 (repeaters
2), shortwave 0
note: there are five meteoroiogical/radio stations
Radios: NA
Television broadcast stations: NA
Televisions: NA','7f03546a9e3c2a825a889b5c4f98a6d724a98e0d1b970e4c98bf4ed77a3bf8a3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34cc1205cfe32b5aaf414387eb4c985d310a31500ed02ce48f4685e769ac40de',1999,'HT','Haiti','communications',541,'Telephones: 50,000 (1990 est.)
Telephone system: domestic facilities barely
adequate; international facilities slightly better
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 33, FM 0, shortwave
2
Radios: 320,000 (1992 est.)
Television broadcast stations: 2 (in addition, there
is a cable TV station) (1997)
Televisions: 32,000 (1992 est.)','32bbb1c77ea7a3b64afbdad0c15e7e47328d8ae79a0594133e1618669af80db8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('186afd6adc9803a36a8d551ec83ed3250153ec9e5a69522a33fdd58034d23661',1999,'NI','Nicaragua','communications',551,'Telephones: 4.47 million (1 998)
Telephone system: modern facilities provide
excellent domestic and international services
domestic: microwave radio relay links and extensive
fiber-optic network
international: satellite earth stations - 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean); coaxial cable to
Guangzhou, China; access to 5 international
submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 6, FM 6, shortwave
0
Radios: 3 million (1992 est.)
Television broadcast stations: 4 (in addition, there
are two repeaters) (1997)
Televisions: 1.75 million (1992 est.)','3edf1e31743fc1f8accc44bd97ecd4fd88236720e2ae84b0f98d8df7c5ac1093','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff858ca1ae0311eca780f6698954fe4f2395d5881ba61bcb0e441bcf4f8d9767',1999,'IS','Iceland','communications',569,'Telephones: 143,600 (1993 est.)
Telephone system: adequate domestic service
domestic: the trunk network consists of coaxial and
fiber-optic cables and microwave radio relay links
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean), 1 Inmarsat (Atlantic and Indian
Ocean regions); note - Iceland shares the Inmarsat
earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 5, FM 147
(transmitters and repeaters), shortwave 0
Radios: 91,500 licensed (1993 est.)
Television broadcast stations: 14 (in addition,
there are 156 low-power repeaters) (1997)
Televisions: 96,100 (1993 est.)
Telephone system:
international: submarine cables from India to UAE and
Malaysia and from Sri Lanka to Djibouti and Indonesia
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: radio and meteorological station','ec0f9daf0d5556fda75ad36c4a4fd588e445c6cd7cad1144507772c13fea874f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a72179aef9e69b4d981cc87524a30df799188bfe4c1a3304359785b2c54a2a1',1999,'JM','Jamaica','communications',590,'Telephones: 350,000 (1997 est.)
Telephone system: fully automatic domestic
telephone network
domestic: NA
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 1 , FM 7, shortwave
0(1997)
Radios: 1 .973 million (1 997)
Television broadcast stations: 7 (1997)
Televisions: 330,000 (1992 est.)','bce7c474301f6aeb6f3b124d16e5e4f18fb853a533229de22039c074ab730165','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('584235e1eaefaa927b977fe8ef7ba9fe536b3c7ea198ea18042b09a9263296cf',1999,'NO','Norway','communications',596,'Telephones: 64 million (1987 est.)
Telephone system: excellent domestic and
international service
domestic: NA
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 Indian Ocean), 1 1ntersputnik
(Indian Ocean region), and 1 Inmarsat (Pacific and
Indian Ocean regions); submarine cables to China,
248
Japan (continued)
Philippines, Russia, and US (via Guam)
Radio broadcast stations: AM 318, FM 58,
shortwave 0
Radios: 97 million (1993 est.)
Television broadcast stations: 7,549 (consisting of
6,995 non-government and non-commercial stations,
of which 95 are main stations of 1 kW or greater power
and 6,900 are low-power stations, and 554
commercial stations of which 1 1 3 are main stations
and 441 are repeaters); note - in addition, US Forces
are served by 3 TV stations and 2 TV cable stations
(1997)
Televisions: 100 million (1993 est.)
Telephones: 2.39 million (1994 est.); 470,000
cellular telephone subscribers (1994)
Telephone system: high-quality domestic and
international telephone, telegraph, and telex services
domestic: NA domestic satellite earth stations
international: 2 buried coaxial cable systems; 4
coaxial submarine cables; satellite earth stations - NA
Eutelsat, NA Intelsat (Atlantic Ocean), and 1 1nmarsat
(Atlantic and Indian Ocean regions); note - Norway
shares the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Iceland, and Sweden)
Radio broadcast stations: AM 46, FM 493 (350
private and 143 government), shortwave 0
Radios: 3.3 million (1993 est.)
Television broadcast stations: 209 (1997)
Televisions: 1 .5 million (1993 est.)
Telephones: 150,000 (1994 est.)
Telephone system: modern system consisting of
open wire, microwave, and radiotelephone
communication stations; limited coaxial cable
domestic: open wire, microwave, radiotelephone
communications, and a domestic satellite system with
8 earth stations
international: satellite earth stations - 2 Intelsat (Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 4, shortwave
1
Radios: 1.043 million (1992 est.)
Television broadcast stations: 13 (in addition,
there are 25 low-power repeaters) (1997)
Televisions: 1 .1 95 million (1 992 est.)
Telephone system:
international: several submarine cables with network
nodal points on Guam and Hawaii
Telephones: 2.828 million (1998)
Telephone system: the domestic system is
mediocre, but improving; service is adequate for
government and business use, in part because major
businesses have established their own private
systems; since 1988, the government has promoted
investment in the national telecommunications system
on a priority basis, significantly increasing network
capacity; despite major improvements in trunk and
urban systems, telecommunication services are still
not readily available to the majority of the rural
population
domestic: microwave radio relay, coaxial cable,
fiber-optic cable, cellular, and satellite
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean); 3 operational
international gateway exchanges (1 at Karachi and 2
at Islamabad); microwave radio relay to neighboring
countries
Radio broadcast stations: AM 26, FM 3, shortwave
18(1998 est.)
Radios: 10.2 million (1998 est.)
Television broadcast stations: 22 (in addition,
there are seven low-power repeaters) (1997)
Televisions: 2.08 million (1998 est.)
Telephones: 1 ,500 (1 988 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave
0
Radios: 9,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 1,600 (1993 est.)','8e3648ae113bb77276dfefecaecfaabac1c30c197ad368c5a1c409bed4cbe22d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aa403547dfb22b0c1c0eb93a1c2b917b935934554f68bf4fc480cc44aea0fe3',1999,'JO','Jordan','communications',601,'Telephones: 425,000(1998)
Telephone system:
domestic: microwave radio relay, coaxial and
fiber-optic cable, and cellular; Jordan has two cellular
telephone providers (with approximately 50,000
subscribers in 1998), ten data service providers, and
four Internet service providers (with approximately
8,000 subscribers in 1998)
international: satellite earth stations - 3 Intelsat, 1
Arabsat, and 29 land and maritime Inmarsat terminals
(1996); coaxial cable, fiber-optic cable, and
microwave radio relay to Iraq, Saudi Arabia, Syria,
and Israel; building a Red Sea Fiber-Optic Link
Around the Globe (FLAG) fiber-optic submarine cable
link and planning to update links with Saudi Arabia
and Israel to fiber-optic cable; 4,000 international
circuits (1998 est.); participant in Medarabtel
Radio broadcast stations: AM 6, FM 7, shortwave
1 (1998 est.)
Radios: 1.1 million (1992 est.)
Television broadcast stations: 8 (in addition, there
are approximately 42 repeaters and 1 TV receive-only
satellite link) (1997)
Televisions: 350,000 (1992 est.)','6d5b43ccdedb6b673953dc89988d4c11c67b8aad8fa9bb40b74a8fc28a8f065e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0851341d9c1e07f50b29882c26d7124506dd89ad0717860c04da3c793a2977b8',1999,'KZ','Kazakhstan','communications',610,'Telephones: 2 million (1997)
Telephone system: service is poor
domestic: landline and microwave radio relay; AMPS
standard cellular systems are available in most of
international: international traffic with other former
Soviet republics and China carried by landline and
microwave radio relay and with other countries by
satellite and through 8 international
telecommunications circuits at the Moscow
international gateway switch; satellite earth stations -
1 1ntelsat and a new digital satellite earth station
established at Almaty; a third satellite earth station at
Atyrau provides teleconnectivity to the AT&T network
via Intelsat; cable connected by the
Trans-Asia-Europe Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Radios: 4.088 million (with multiple speakers for
program diffusion 6.082 million)
Television broadcast stations: 20 (of which at
least eight are government stations and at least 1 2 are
private stations - seven of those are satellite TV relay
stations) (1997)
Televisions: 4.75 million
Telephones: 383,676 (1997); 3,077 cellular
telephone subscribers (1998)
Telephone system:
domestic: primarily microwave radio relay
international: satellite earth stations - 4 Intelsat
Radio broadcast stations: AM 24, FM 7, shortwave
2
Radios: 5 million
Television broadcast stations: 8 (of which six are
qovernment-controlled and two are commercial)
(1997)
Televisions: 500,000','1f4420f9a1d0aa1728116e00e81370a8a4d407dd08abaf82b06c54fec3c4614e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('603b4b5ffe94facc7db41e9d6a099dcacf834e044853aa863c6d0ac4571b8388',1999,'WS','Samoa','communications',620,'Telephones: 1 ,400 (1 984 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
note: Kiribati is being linked to the Pacific Ocean
Cooperative Telecommunications Network, which
should improve telephone service
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 15,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 0(1988)
Telephones: 1 .4 million (1998 est.)
Telephone system:
domestic: system is being expanded with installation
of fiber-optic cable nationwide; access traditionally
reserved for official and business subscribers; public
access is expected to increase
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) and 1 Intersputnik (Indian Ocean Region);
other international connections through Moscow and
Beijing
Radio broadcast stations: AM 27, FM 14,
shortwave 3
Radios: 4.7 million
Television broadcast stations: 38
Televisions: 2 million
Telephones: 16.6 million (1993)
Telephone system: excellent domestic and
international services
domestic: NA
international: fiber-optic submarine cable to China;
satellite earth stations - 3 Intelsat (2 Pacific Ocean and
1 Indian Ocean) and 1 Inmarsat (Pacific Ocean
region)
Radio broadcast stations: AM 79, FM 46,
shortwave 0
Radios: 42 million (1993 est.)
Television broadcast stations: 121 (in addition,
there are 850 relay stations and eight-channel
American Forces Korea Network) (1997)
Televisions: 9.3 million (1992 est.)
Telephones: 7,500 (1988 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 76,000 (1992 est.)
Television broadcast stations: 6 (1997)
Televisions: 6,000 (1992 est.)','976f7fe958a6e197ba22c3f1d8b537a1d69a4bfd60b06972f8f62833db306bd2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('525f45dc620283eef254705a9722ad922c7449d9fdb2d21e6ca580ad37697f6d',1999,'KG','Kyrgyzstan','communications',628,'Telephones: 356,000 (1996 est.)
Telephone system: poorly developed; about
100,000 unsatisfied applications for household
telephones
domestic: principally microwave radio relay; one
cellular provider, probably only limited to Bishkek
region
international: connections with other CIS countries by
landline or microwave radio relay and with other
countries by leased connections with Moscow
international gateway switch and by satellite; satellite
earth stations - 1 Intersputnik and 1 Intelsat;
connected internationally by the Trans-Asia-Europe
Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - one state-run radio broadcast
station
Radios: 825,000 (radio receiver systems with
multiple speakers for program diffusion 748,000)
Television broadcast stations: NA (repeater
stations throughout the country relay programs from
Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Televisions: 875,000','59c36f54a60cbaddc68812d7c4eac788c2187c93778d252be574ac519268698e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29652946ad120fec92faba4342029728797835472c4f87ed8f216ded76eec885',1999,'LV','Latvia','communications',636,'Telephones: 710,848(1997)
Telephone system: Lattelekom is 51 % state owned,
plans to privatize in 2000 to satisfy EU concerns;
50,000 people are on the waiting list to receive
telephone service; Internet service is available
throughout Latvia
domestic: local - two cellular service providers;
NMT-450 and GSM standards provide service
nationwide; over 75% of population covered; intercity
- two synchronous digital hierarchy fiber-optic rings
form the national backbone; 1 1 digital switching
centers, 3 service centers
international: Latvia has international fiber-optic
connectivity to Belarus, Estonia, Lithuania, and an
undersea fiber-optic cable to Sweden
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - there are 25 stations of unknown
type; 75% of commercial broadcasts must be in the
276
Latvia (continued)
Latvian language; remainder mostly in Russian and
European languages
Radios: 1 .4 million (1 993 est.)
Television broadcast stations: 30 (origin of TV
broadcasts must be 40% Latvian and 40% other
European languages)
Televisions: NA; note - almost 100% of the
population have TV access, 16% have VCRs, and
20% have cable or satellite dishes (1995)','ff737195637242c4e116ac9a4b81460285f3b8b46979090b22f6ae23540c13ff','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('692cf343fd68d2160738242fe663682e61c40306ca0275a13dee9ebb1751b771',1999,'LB','Lebanon','communications',645,'Telephones: 150,000 (1990 est.)
Telephone system: telecommunications system
severely damaged by civil war; rebuilding well
underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean) (erratic
operations); coaxial cable to Syria; microwave radio
relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 5, FM 3, shortwave
1
note: government is licensing a limited number of the
more than 100 AM and FM stations operated
sporadically by various factions that sprang up during
the civil war
Radios: 2.37 million (1992 est.)
Television broadcast stations: 28 (1997)
Televisions: 1.1 million (1993 est.)','a3ff4ac7436ea4628b62eb3ccacf3458b356f6602908f18a03bf759f35e855e0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6722553a9775e5d647cf3991fea8b6bb60aacb647b7e62277474f43d079fc4be',1999,'ZA','South Africa','communications',653,'Telephones: 12,000 (1991 est.)
Telephone system: rudimentary system
domestic: consists of a few landlines, a small
microwave radio relay system, and a minor
radiotelephone communication system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
281
Lesotho (continued)
Radio broadcast stations: AM 3, FM 4, shortwave
0
Radios: 66,000
Television broadcast stations: NA
Televisions: 1 1 ,000 (1 992 est.)
Telephones: fewer than 25,000 (1998 est.)
Telephone system: telephone and telegraph
service via microwave radio relay network; main
center is Monrovia
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1 0, shortwave
0
note: two of the FM radio stations are limited to a small
area
Radios: 675,000 (1995 est.); note - 10,000 windup
radios were distributed in the country prior to the 1 997
election
Television broadcast stations: 1 (in addition, there
are four low-power repeaters; the station is located in
Monrovia) (1997)
Televisions: 56,000 (1995 est.)','4484bc556e68ffd32d507868666af9e91883d854fc897c9eec891aea2719b5d5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e97435f7beb25006624091ced103dd3af5a015a8c613d2eb87d76ee2b34e9e',1999,'LY','Libya','communications',663,'Telephones: 411,000 (1999 est.)
Telephone system: telecommunications system is
being modernized; cellular telephone system became
operational in 1996
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations - 4 Intelsat, NA
Arabsat, and NA Intersputnik; submarine cables to
France and Italy; microwave radio relay to T unisia and
Egypt; tropospheric scatter to Greece; participant in
Medarabtel
Radio broadcast stations: AM 17, FM 3, shortwave
3(1998 est.)
Radios: 1 million (1998 est.)
Television broadcast stations: 12 (in addition,
there is one low-power repeater) (1997)
Televisions: 550,000 (1998 est.)','cb8423e1bcebfbc009c7f3f82de18f5bf59bd3cd82eee8c552a6503ebdc983a4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcefebb0719aea4455ff41316cfe2ba10a761dde6c3f6fcc6cb8d24246fcbe5d',1999,'LI','Liechtenstein','communications',672,'Telephones: 22,857 (1996 est.)
Telephone system: automatic telephone system
domestic: NA
international: linked to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: 1 broadcast station in
Triesen
note: linked to Swiss networks
Radios: 12,134(1996)
Television broadcast stations: NA (linked to Swiss
networks) (1997)
Televisions: 11,785(1996)','dc36159ab2c66b29918351821bb01abafc1d705bbad7d4bba2e161b7750766b4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18e1c2b1d458fa0101634ff394a2d64fcd679ef87ebf16768e3a72ec0382eac0',1999,'CH','Switzerland','communications',676,'Telephones: 1.08 million (1998)
Telephone system: the Ministry of Communications
and Informatics, Ministry of Defense, and Ministry of
Internal Affairs oversee Lithuania''s
telecommunications; the national operator is Lietuvos
Telomas; Internet is available
domestic: local - three cellular service providers;
NMT-450 and GSM standards provide services
nationwide; 80% of customers are on the two GSM
networks; 157,000 cellular customers; intercity -
Lithuania is close to completing its fiber-optic
backbone consisting of two small rings inside a larger
ring
international: Lithuania has international fiber-optic
289
Lithuania (continued)
connectivity to Latvia, Poland, and an undersea
fiber-optic cable to Sweden
Radio broadcast stations: AM 13, FM 26,
shortwave 1
Radios: 1 .42 million (1 993 est.)
Television broadcast stations: 3
Televisions: NA; note - 93% of the population have
TV, 30% have cable or satellite dish, and 16% own
VCRs (1996)','97c707eed4f29e6d02311e8b37a114e82f2a224584d7cbfbf001f30dc6408e47','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad94494b6cfe8fb349ae23b9d2d09c0b9ee360cefe9fadb46e4ed9dcbad5d4d',1999,'JP','Japan','communications',685,'Telephones: 43,000 (1985 est.)
Telephone system:
domestic: fair system of open-wire lines, microwave
radio relay links, and radiotelephone communications
stations
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 10, FM 17,
shortwave 0
Radios: 1.011 million (1995)
Television broadcast stations: 0 (1997 est.)
Televisions: NA
300
Malawi (continued)','675a2b1f40e02ef8cd45e6a2ac5b6f639fc4047f05151368c3dfbc9b0d991005','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d15175eb423ce4e2f47c03fcf73924763c2042b0acd6bfd722c64cba4432d23b',1999,'MV','Maldives','communications',695,'Telephones: 8,523 (1992 est.)
Telephone system: minimal domestic and
international facilities
domestic: inter-atoll communication primarily through
HF transceivers and VHF/UHF telephones
international: satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 1 , shortwave
0
Radios: 28,284 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 7,309 (1992 est.)','cd852db8fa7e57eaf7e3a51ca0730453186f5b4ae29ddda3fddd8a65550ca051','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7057a7c2519c40b44fe1ef5c8acf7781e0025240ca03eeae295fcaefa817845',1999,'ML','Mali','communications',702,'Telephones: 1 1 ,000 (1 982 est.)
Telephone system: domestic system poor but
improving; provides only minimal service
domestic: network consists of microwave radio relay,
open wire, and radiotelephone communications
stations; expansion of microwave radio relay in
progress
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave
1
Radios: 430,000 (1992 est.)
Television broadcast stations: 1 (in addition, there
are two repeaters) (1997)
Televisions: 1 1 ,000 (1 992 est.)','701cd5ab0a0ec34adec88ec886924dc775f5b55dae61969e4ad55e786d66d111','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a91ce5636749ac65eec9ab69407a31adf012327d742911ef7b919449d0b511d6',1999,'MT','Malta','communications',709,'Telephones: 1 91 ,876 (1 992 est.)
Telephone system: automatic system satisfies
normal requirements
domestic: submarine cable and microwave radio relay
between islands
international: 2 submarine cables; satellite earth
station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 4, shortwave
0
Radios: 189,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: 300,000 (1996 est.)
Telephones: 46,000(1996)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 4, shortwave
0
Radios: NA
Television broadcast stations: 0 (receives
broadcasts from the UK) (1997)
Televisions: 24,450(1996)','5ef8fc88f70a10fc56c70e65a3566b3b25637533cd428e2663b0756e313f1afc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90a4f47ef7d899e50db34ff1fd6660021e189702a2358ad2f4fdd0f4c2a1183',1999,'MH','Marshall Islands','communications',718,'Telephones: 2,000 (1997 est.)
Telephone system: telex services
domestic: Majuro Atoll and Ebeye and Kwajalein
islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by
shortwave radiotelephone (used mostly for
government purposes)
international: satellite earth stations - 2 Intelsat
(Pacific Ocean); US Government satellite
communications system on Kwajalein
Radio broadcast stations: AM 1 , FM 2, shortwave
1
Radios: NA
Television broadcast stations: 3 (of which one is
an independent station and two are US military
stations) (1 997)
Televisions: NA','fe1e01828146fc41ce6505fed9dc2c0b54585318cf6533553992b3e9d3a2926a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9267c28d92b6f2a84540fbe514c7a9a020182c97232566e8caa1ade24463fda7',1999,'MR','Mauritania','communications',729,'Telephones: 17,000 (1991 est.)
Telephone system: poor system of cable and
open-wire lines, minor microwave radio relay links,
and radiotelephone communications stations
(improvements being made)
domestic: mostly cable and open-wire lines; a recently
completed domestic satellite telecommunications
system links Nouakchott with regional capitals
international: satellite earth stations - 1 Intelsat
(Atlantic Ocean) and 2 Arabsat
Radio broadcast stations: AM 1 , FM 2, shortwave
1 (1998 est.)
316
Mauritania (continued)
Radios: 1 million (1 998 est.)
Television broadcast stations: 1 (1997)
Televisions: 50,000 (1995 est.)','5bf5b90078ab1a885c0f756571aa2753c75dca2cb171383af990887c9ef36616','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e20be2157e666c4acad63627341491e08b70f2ebb509c49f62d01517b37d26e',1999,'MU','Mauritius','communications',736,'Telephones: 107,000(1993)
Telephone system: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station - 1 1ntelsat (Indian
Ocean); new microwave link to Reunion; HF
radiotelephone links to several countries
Radio broadcast stations: AM 2, FM 0, shortwave
0
Radios: 399,000 (1993 est.)
Television broadcast stations: 2 (in addition, there
are 11 repeaters) (1997)
Televisions: 242,000 (1993 est.)','0900dd1761d754194b77c419b90f807bad5851705ac1dca4735b458dc956c28f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ce6dc6917c6632221904d326c26e35875eaf5061cfb9d4e392cb19ab3f6520',1999,'YT','Mayotte','communications',743,'Telephones: 450
Telephone system: small system administered by
French Department of Posts and T elecommunications
domestic: NA
international: microwave radio relay and HF
radiotelephone communications to Comoros and
other international connections
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 30,000 (1994 est.)
Television broadcast stations: 3 (1997)
Televisions: 3,500 (1994 est.)','0fb05d21cde065b0f929d178a2316f3025ec92e1b19b51613e4410cc734a3ab5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2de3a1c5a577678cda9fc15315fbc35b60c4364e296681ed6056b8fd47bf467',1999,'US','United States','communications',758,'Telephones: 53, 1 80 (1 994 est.)
Telephone system: automatic telephone system
domestic: NA
international: no satellite earth stations; connected by
cable into the French communications system
Radio broadcast stations: AM 3, FM 4, shortwave
0
Radios: 33,000 (1994 est.)
Television broadcast stations: 5 (1997)
Televisions: 24,000 (1994 est.)','db6cf170bd52cd00537463e6c05ab9c370b0d90a3138bf360563bbc6b6a90f69','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('805f1a2a55d7f1f1d01b6e23668f314e34fea95464cba3ea54641dff80fc1c21',1999,'CN','China','communications',762,'Telephones: 93,600(1998)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 12, FM 1 , shortwave
0
Radios: 220,000
Television broadcast stations: 1 (in addition, there
are 18 provincial repeaters) (1997)
Televisions: 1 20,000 (1 993 est.)','5a0f5ad9ea85c492d5e8087c2507c04b1ebce38070329edde6e045d1868f9e1c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4248f9697a386cbc6499d3302cbbfd0ce6393d36bdf53404e61c9672d44943f5',1999,'MS','Montserrat','communications',768,'Telephones: 3,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 8, FM 4, shortwave 0
Radios: 6,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1992 est.)','e5b09f538c09f97dd2ec0a4077a9b935bb3d6ade51b20e79a65ae8d3739aa89e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62604a8971fa8a7835394f13fae90743098c62c4533343c53e86374ec4137714',1999,'GI','Gibraltar','communications',776,'Telephones: 1,312,596 (1999 est.)
Telephone system:
domestic: good system composed of open-wire lines,
cables, and microwave radio relay links; principal
centers are Casablanca and Rabat; secondary
centers are Fes, Marrakech, Oujda, Tangier, and
Tetouan
international: 5 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain, and
Western Sahara; coaxial cable and microwave radio
relay to Algeria; participant in Medarabtel
Radio broadcast stations: AM 22, FM 7, shortwave
5(1998 est.)
Radios: 5.1 million (1998 est.)
Television broadcast stations: 26 (in addition,
there are 35 repeaters) (1997)
Televisions: 1.21 million (1998 est.)','885869c22ca4801de8611005d211945b1b85106fd7773021341870490fd5d1aa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7e1769e100255a189d3defc3507cc3b2201705f9998205dca54de57b756a424',1999,'NA','Namibia','communications',783,'Telephones: 89,722 (1992 est.)
Telephone system:
domestic: good urban services; fair rural service;
microwave radio relay links major towns; connections
to other populated places are by open wire
international: NA
note: a fully automated digital network is being
implemented
Radio broadcast stations: AM 4, FM 40, shortwave
0
Radios: 195,000 (1992 est.)
Television broadcast stations: 8 (of which five are
main stations and three are low-power stations; there
are also about 20 low-power repeaters) (1997)
Televisions: 27,000 (1993 est.)','2429a9b28e79d629b2aa062c9307f4aba73552ba85e43e04ad328230497bb6db','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2922b7f76604cd2b9a8f2e15939419af46408850bf01443245997a90d4b67316',1999,'NR','Nauru','communications',792,'Telephones: 2,000 (1989 est.)
Telephone system: adequate local and
international radiotelephone communications
provided via Australian facilities
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 4,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: NA','bd3dfb70def511a9dccf0d1c951f93fb9258df660375573b2772dbd7dcefc024','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b988ef629ac3b00bf9710d224cfc3e88c5f19ae4fa594b5d61db713a43e3d7e3',1999,'BE','Belgium','communications',805,'Telephones: 8.431 million (1998 est.); 3.4 million
cellular telephone subscribers (1998 est.)
Telephone system: highly developed and well
maintained; system of multi-conductor cables
gradually being supplemented/replaced by a
glass-fiber based telecommunication infrastructure;
Mobile GSM-based mobile telephony density rapidly
growing; third generation Universal Mobile
Telecommunications System expected for
introduction by the year 2001
domestic: nationwide cellular telephone system;
microwave radio relay
international: 5 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean), 1 Eutelsat, and 1 Inmarsat (Atlantic and
Indian Ocean Regions)
Radio broadcast stations: AM 3 (relays 3), FM 12
(repeaters 39), shortwave 0
Radios: 14 million (1994 est.)
Television broadcast stations: 15 (in addition,
there are five low-power repeaters) (1997)
Televisions: 7.6 million (1994 est.)','797a257c29048392f118d696e603b3d0d1bd5f345257a22201c0a61e25eb8a05','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdea89ab481a984eb215682fd1bc8c4c9e6a5b135004c998db98a8f94092b7a5',1999,'NL','Netherlands','communications',812,'Telephones: NA
Telephone system: generally adequate facilities
domestic: extensive interisland microwave radio relay
links
international: 2 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4, shortwave
0
Radios: 205,000 (1992 est.)
Television broadcast stations: 3 (in addition, there
is a cable service which supplies programs received
from various US satellite networks) (1997)
Televisions: 64,000 (1992 est.)','ebf8ff9bb1dd39ea085998db6c1efb3669b11b3c7b2947f70dc99a50cdc57abb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df736834c97d45beb3d64d11ce59e1be0c339920903db12a1d086c63184e64e0',1999,'NZ','New Zealand','communications',820,'Telephones: 1 .7 million (1986 est.)
Telephone system: excellent international and
domestic systems
domestic: NA
international: submarine cables to Australia and Fiji;
satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 64, FM 2, shortwave
0
Radios: 3.215 million (1992 est.)
Television broadcast stations: 41 (in addition,
there are 52 medium-power repeaters and over 650
low-power repeaters) (1997)
Televisions: 1.53 million (1992 est.)
Telephones: 6,000 (1994 est.)
Telephone system:
domestic: NA
International: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 66,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1994 est.)
Telephones: 170,000 (1992 est.)
Telephone system: excellent international service;
good local service
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); tropospheric scatter to Barbados
and Guyana
Radio broadcast stations: AM 1 , FM 10, shortwave
0
Radios: 700,000 (1993 est.)
Television broadcast stations: 4 (1997)
Televisions: 400,000 (1992 est.)
Communications - note: important meteorological
station
Telephones: 340(1 985 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: NA','b820653ee8c2d42060d73f563363b714973aa7a4c59be18172ede0bfbe4b16d5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a39285598f77ce27e8121e3001fb4178027fc87caf3d23e4888c173a90439d3',1999,'NE','Niger','communications',827,'Telephones: 14,000 (1995 est.)
Telephone system: small system of wire,
radiotelephone communications, and microwave
radio relay links concentrated in southwestern area
domestic: wire, radiotelephone communications, and
358
Niger (continued)
microwave radio relay; domestic satellite system with
3 earth stations and 1 planned
international: satellite earth stations ■ 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 1 5, FM 6, shortwave
0
Radios: 620,000 (1995 est.)
Television broadcast stations: 10 (in addition,
there are seven low-power repeaters) (1997)
Televisions: 105,000 (1995 est.)','e4fc299e100ee4bcac5654c57c5d05b8c7a2462709f482f72fb05edc52381275','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('102ae76a036240c5932d4427f4d70df1dfd4abf8df398f3bc23fd58cf73360ba',1999,'NF','Norfolk Island','communications',839,'Telephones: 1 ,087 (1983 est.)
Telephone system:
domestic: NA
international: radiotelephone service with Sydney
(Australia)
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 2,000 (1993 est.)
Television broadcast stations: 1 (local
programming station; in addition, there are two
repeaters that bring in Australian programs by
satellite) (1998)
Televisions: 1,500 (1995 est.)','093ac38b39984e3409c2fba937bbf4d3d6173cdb0090ced33cafa5f24147f7d2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d9d6e20f9bb9b4dcd6f1b5af97431b70820c1ccd602c25372999f7bdfff2ee0',1999,'MP','Northern Mariana Islands','communications',843,'Telephones: 13,618 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 2, FM 3
Radios: 15,460 (1995 est.)
Television broadcast stations: 1 (on Saipan and
one station planned for Rota; in addition, two cable
stations on Saipan provide varied programming from
satellite networks) (1997)
Televisions: 15,460 (1995 est.)','82584a42b06e4d359ee6d0e7d1c51409979838dab3735759817cb1dc53ec4a98','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd2d8513fd297703aa0610112abf05bf4196230df0e377a2fc7e23edf23e3b8',1999,'PA','Panama','communications',850,'Telephones: 273,000 (1991 est.)
Telephone system: domestic and international
facilities well developed
domestic: NA
international: 1 coaxial submarine cable; satellite
earth stations - 2 Intelsat (Atlantic Ocean); connected
to the Central American Microwave System
Radio broadcast stations: AM 91 , FM 0, shortwave
0
Radios: 564,000 (1992 est.)
Television broadcast stations: 9 (in addition, there
are 17 repeaters) (1997)
Televisions: 420,000 (1992 est.)','8780310fb23c38eff2690bcd24350904f822ee9302b594f6e1991491e7356886','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0d38fc6eeff661f274d3e36cdf8ea3689386385b29f8d5c00a7bfa12639cc1c',1999,'AR','Argentina','communications',861,'Telephones: 88,730 (1985 est.)
Telephone system: meager telephone service;
principal switching center is Asuncion
domesf/c:fair microwave radio relay network
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 40, FM 0, shortwave
7
Radios: 775,000 (1992 est.)
Television broadcast stations: 10(1 997)
Televisions: 370,000 (1992 est.)
Telephones: 779,306 (1990 est.)
Telephone system: adequate for most
requirements
domestic: nationwide microwave radio relay system
and a domestic satellite system with 1 2 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 273, FM 0,
shortwave 144
Radios: 5.7 million (1992 est.)
Television broadcast stations: 13 (in addition,
there are 1 12 repeaters) (1997)
Televisions: 2 million (1993 est.)','850179ad64c7bf3401467754ae0bd30b777257baa68092d599d999aefbb7cc1c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef0644082481beb5fad737508fbc99c3c14b3f470305ed18399c9d336ef4dd96',1999,'MX','Mexico','communications',864,'Telephones: 8.2 million (1996)
Telephone system: underdeveloped and outmoded
system; government aims to have 10 million
telephones in service by 2000; the process of partial
privatization of the state-owned telephone monopoly
has begun
domestic: cable, open wire, and microwave radio
relay; 3 cellular networks
international: satellite earth stations - 2 Intelsat, NA
Eutelsat, 2 Inmarsat (Atlantic and Indian Ocean
regions), and 1 Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 27, FM 75,
shortwave 1 (1994 est.)
Radios: 9.9 million registered (1996)
Television broadcast stations: 150 (1997)
Televisions: 9.4 million registered (1996)','5cbc42e5da14d1576725a68590d3ba3b473ec92fb6151d09f30d82b67f4a9fd6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8dd77d1ae12cfa6f0a16bf9f42cd60cb17eb2a6531b2df4de4730ca04825081',1999,'QA','Qatar','communications',873,'Telephones: 1 60,71 7 (1 992 est.)
Telephone system: modern system centered in
Doha
domestic: NA
international: tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 1ndian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave
0
Radios: 201,000 (1992 est.)
Television broadcast stations: 2 (in addition, there
are three repeaters) (1997)
Televisions: 205,000 (1992 est.)','54ead9628e2b35db335d20d5febccece564f922fc00d25d8bbf5a97671ef39e4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1246040ad8a32d2a93cde407f1154a2a4e085938cdb0de846311f8f9385d0406',1999,'UA','Ukraine','communications',882,'Telephones: 2.6 million (1993 est.)
Telephone system:
domestic: poor service; 89% of telephone network is
automatic; trunk network is microwave radio relay;
roughly 3,300 villages with no service (February 1 990
est.)
international: satellite earth station - 1 1ntelsat; new
digital international direct-dial exchanges are in
Bucharest (1993 est.)
Radio broadcast stations: AM 1 2, FM 5, shortwave
0
note: in 1 995, 1 35 local radio stations were registered
Radios: 4.64 million (1992 est.)
Television broadcast stations: 130 (in addition,
there are about 400 low-power repeaters) (1997)
Televisions: 4.58 million (1992 est.)
Telephones: 23.8 million (1997 est.)
Telephone system: the telephone system has
undergone significant changes in the 1 990''s; there are
more than 1 ,000 companies licensed to offer
communication services; access to digital lines has
improved, particularly in urban centers; Internet and
e-mail services are improving; Russia has made
progress toward building the telecommunications
infrastructure necessary for a market economy
domestic: cross country digital trunk lines run from St.
Petersburg to Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in 60 regional
capitals have modern digital infrastructures; cellular
services, both analog and digital, are available in
many areas; in rural areas, the telephone services are
still outdated, inadequate, and low density
international: Russia is connected internationally by
three undersea fiber-optic cables; digital switches in
several cities provide more than 50,000 lines for
international calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat, Inmarsat,
and Orbita
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - there are about 1 ,050 (including
AM, FM, and shortwave) radio broadcast stations
throughout the country
Radios: 50 million (1993 est.) (74.3 million radio
receivers with multiple speaker systems for program
diffusion)
Television broadcast stations: 1 1 ,000 (1 996 est.)
Televisions: 54.85 million (1992 est.)
Telephones: 6,400 (1983 est.)
Telephone system: telephone system primarily
serves business and government
domestic: the capital, Kigali, is connected to the
centers of the prefectures by microwave radio relay;
the remainder of the network depends on wire and HF
radiotelephone
international: international connections employ
microwave radio relay to neighboring countries and
satellite communications to more distant countries;
satellite earth stations - 1 Intelsat (Indian Ocean) in
Kigali (includes telex and telefax service)
Radio broadcast stations: AM 1 , FM 1 , shortwave
0
Radios: 630,000 (1993 est.)
Television broadcast stations: 2 (1997)
Televisions: NA
408
Rwanda (continued)
Telephones: 550
Telephone system:
domestic: automatic network; HF radiotelephone from
Saint Helena to Ascension, then into worldwide
submarine cable and satellite networks
international: major coaxial submarine cable relay
point between South Africa, Portugal, and UK at
Ascension; satellite earth stations - 2 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
0
Radios: 2,500 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Communications - note: Gough Island has a
meteorological station
Telephones: 12,531,277(1998)
Telephone system: Ukraine''s phone systems are
administered through the State Committee for
Communications; Ukraine has a telecommunication
development plan through 2005; Internet service is
available in large cities
domestic: local - Kiev has a digital loop connected to
the national digital backbone; Kiev has several cellular
phone companies providing service in the different
standards; some companies offer intercity roaming
and even limited international roaming; cellular phone
service is offered in at least 100 cities nationwide
international: foreign investment in the form of joint
business ventures greatly improved the Ukrainian
telephone system; Ukraine''s two main fiber-optic lines
are part of the Trans-Asia-Europe Fiber-Optic Line
(TAE); these lines connect Ukraine to worldwide
service through Belarus, Hungary, and Poland; Odesa
is a landing point for the Italy-Turkey-Ukraine-Russia
Undersea Fiber-Optic Cable (ITUR) giving Ukraine an
additional fiber-optic link to worldwide service;
Ukraine has Intelsat, Inmarsat, and Intersputnik earth
stations
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - at least 25 local broadcast
stations of NA type (1 998)
Radios: 15 million (1990)
Television broadcast stations: at least 33 (in
addition 21 repeater stations that relay ORT
broadcasts from Russia) (1997)
Televisions: 17.3 million (1992)','afab695b6b96cda632101345af09a77c3bc32ab1ee204995b92c1dfee3e78ed7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('033d4b11d707330251529d37c24fc24d9bb2a98ff1d61d1ad240630fbdae8ac8',1999,'TT','Trinidad and Tobago','communications',892,'Telephones: 3,800 (1986 est.)
Telephone system: good interisland VHF/UHF/SHF
radiotelephone connections and international link via
Antigua and Barbuda and Saint Martin (Guadeloupe
and Netherlands Antilles)
domestic: interisland links are handled by VHF/UHF/
SHF radiotelephone
international: international calls are carried by
radiotelephone to Antigua and Barbuda and from
there switched to submarine cable or to Intelsat, or
carried to Saint Martin (Guadeloupe and Netherlands
Antilles) by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 2, FM 0, shortwave
0
Radios: 25,000 (1993 est.)
Television broadcast stations: 1 (in addition, there
are three repeaters) (1997)
Televisions: 9,500 (1993 est.)','a9440e16cac2c328c4802923364e0a706ae712bbc20493b9c4e5e28267e051b2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5805d047ec364ab87f91921194c78fc46ad2a23d3510ae04479f5a2e38d53074',1999,'MQ','Martinique','communications',900,'Radio broadcast stations: AM 4, FM 1 , shortwave
0
Radios: 104,000 (1992 est.)
Television broadcast stations: 3 (of which two are
commercial stations and one is a community antenna
television [CATV] channel) (1997)
Televisions: 26,000 (1992 est.)
Telephones: 3,650 (1994 est.)
Telephone system:
domestic: NA
international: radiotelephone communication with
most countries in the world; 1 earth station in French
domestic satellite system
Radio broadcast stations: AM 1 , FM 3, shortwave
0
Radios: 3,000 (1992 est.)
Television broadcast stations: 0 (there are,
however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions: 2,000 (1992 est.)','eb98735c336f4e34b0f2f6ae8df21d8e965e1cab29fc4ec73f4b0b257adc6686','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143a534955f715ac5e9f48f7c397560ba9e3565aae0cb4781be407079512735f',1999,'IT','Italy','communications',908,'Telephones: 15,000 (1995 est.)
Telephone system:
domestic: automatic telephone system completely
integrated into Italian system
international: microwave radio relay and cable
connections to Italian network; no satellite earth
stations
Radio broadcast stations: AM 0, FM 0, shortwave
0
Radios: 15,000 (1994 est.)
Television broadcast stations: 1 (San Marino
residents also receive broadcasts from Italy) (1997)
Televisions: 9,000 (1994 est.)
Telephones: 5.24 million (1996 est.); 307,000
cellular telephone subscribers (1994 est.)
Telephone system: excellent domestic and
international services
domestic: extensive cable and microwave radio relay
networks
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean)
Radio broadcast stations: AM 7, FM 50, shortwave
1 (1997)
Radios: 2.8 million (1996)
Television broadcast stations: 108 (1997)
Televisions: 2.647 million licenses (1996)
Telephones: 541 ,465 (1 992 est.)
Telephone system: fair system currently
undergoing significant improvement and digital
upgrades, including fiber-optic technology
domestic: coaxial cable and microwave radio relay
network
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) and 1 Intersputnik (Atlantic Ocean region); 1
submarine cable; coaxial cable and microwave radio
relay to Iraq, Jordan, Lebanon, and Turkey;
participant in Medarabtel
Radio broadcast stations: AM 9, FM 1 , shortwave
0
Radios: 3.392 million (1992 est.)
Television broadcast stations: 54 (of which 36 are
low-power stations and repeaters) (1997)
Televisions: 700,000 (1993 est.)','a9a1f56be98aa64e22c562e79dc8a3f5b7f260c05780ea37bc1a233c0b005d6b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f17c1d90853e15c9e08707f4da100eed938a1c3b3f79e29308b74a12cb7ae40',1999,'SA','Saudi Arabia','communications',916,'Telephones: 1.46 million (1993)
Telephone system: modern system
domestic: extensive microwave radio relay and
coaxial and fiber-optic cable systems
international: microwave radio relay to Bahrain,
Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine cable
to Djibouti, Egypt and Bahrain; satellite earth stations
- 5 Intelsat (3 Atlantic Ocean and 2 Indian Ocean), 1
Arabsat, and 1 Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 43, FM 13,
shortwave 0
Radios: 5 million (1993 est.)
Television broadcast stations: 117 (1997)
Televisions: 4.5 million (1993 est.)','84150ee053e240e49eac934ef00129e340f5b88f44da60a28edd31d001f55df9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2407be2e6f96aa815464fab9a505a8bc5c76234be8cb44413b93f6e84691cc03',1999,'ME','Montenegro','communications',922,'Telephones: 81,988 (1995 est.)
Telephone system:
domestic: above-average urban system; microwave
radio relay, coaxial cable and fiber-optic cable in trunk
system
international: 4 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 6, shortwave
1
Radios: 850,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 61 ,000 (1 993 est.)
Telephones: 700,000
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: 27 (public or
state-owned 1 , private 26)
Radios: 2.015 million
Television broadcast stations: more than 771
(consisting of 86 strong stations, 685 low-power
stations, and 20 repeaters in the principal networks;
there are also numerous local or private stations in
Serbia and Vojvodina) (1997)
Televisions: 1 million','0bf60e3068b854968ff09ff29ce944cfd2b72cf9abda31ed3ce6496195208a35','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4a98748defbad6aae09620edd8c42b03a17ce0f9dafdd1be804893ab7da1dd0',1999,'SC','Seychelles','communications',935,'Telephones: 13,000 (1995 est.)
Telephone system:
domestic: radiotelephone communications between
islands in the archipelago
international: direct radiotelephone communications
with adjacent island countries and African coastal
countries; satellite earth station - 1 1ntelsat (Indian
Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave
0
Radios: 50,000 (1996 est.)
Television broadcast stations: 2 (in addition, there
are 9 repeaters) (1997)
Televisions: 12,000 (1996 est.)','804389ef1062e37e196c8ee7d1fe738066a6e77ad4e15eafc7fb7be99a6ffaf1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a4a49d8982ea8b42e065ab07b9536efd55b5c59ed6382561277ac2a6c7e4d3e',1999,'SL','Sierra Leone','communications',943,'Telephones: 17,526 (1991 est.)
Telephone system: marginal telephone and
telegraph service
domestic: national microwave radio relay system
made unserviceable by military activities
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave
NA
Radios: 980,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: 45,000 (1992 est.)','4777fa7dae7f9736d85ef54b2b02295576220b7532d915a2a48853548e9cde2c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e85dfe7b913aa6e70d4bb3bd2801099aedef469f987748e45cdca92dc0d3e85d',1999,'SK','Slovakia','communications',950,'Telephones: 1,362,178 (1992 est, )
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - there are 22 private broadcast
stations and two public (state) broadcast stations
Radios: 915,000 (1995 est.)
Television broadcast stations: 41 (1997)
Televisions: 1 .2 million (1995 est.)','15c79806fa55613c39708a71121bef449980061f4402c08f8c892773cb2e5db3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70835b9fa796a0c23204792f5f0819a76fd75f8ffea57a633bc06672a0e9366',1999,'SB','Solomon Islands','communications',960,'Telephones: 5,000(1991 est.)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 4, FM 0, shortwave
0
Radios: 38,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: 2,000 (1992 est.)','e4589610b8cff2f8a22af1b004eb6dcfa564cb4360f0542a0367695bbd208962','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6179230a15bf7f9686c43e7286a9edfed625cb3704c97f747c67d95a0cbd121',1999,'SO','Somalia','communications',966,'Telephones: 9,000(1991 est.)
Telephone system: the public telecommunications
system was completely destroyed or dismantled by
the civil war factions; all relief organizations depend
on their own private systems
domestic: recently, local cellular telephone systems
have been established in Mogadishu and in several
other population centers
international: international connections are available
from Mogadishu by satellite
Radio broadcast stations: AM NA, FM NA,
shortwave 5
Radios: 300,000
Television broadcast stations: 1 (1997)
Televisions: 1 1 8,000 (1 993 est.)
Telephones: 4.2 million (1997)
Telephone system: the system is the best
developed, most modern, and has the highest
capacity in Africa
domestic: consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, and radiotelephone communication
stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria
international: 1 submarine cable; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean)
Radio broadcast stations: AM 15, FM 164,
shortwave 1
Radios: 7.5 million (1999 est.)
Television broadcast stations: 556 (includes 156
network stations and 400 privately-owned low-power
stations; in addition, there are 144 network repeaters)
(1997)
Televisions: 7.5 million
Telephone system:
domestic: NA
international: coastal radiotelephone station at
Grytviken','c6783b3f0a13d0ee67acbe644fa2d29689a7441b881225edc39675c79d4ddba5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1ee4528f35eacc68540c6ebc3de007c7c414230e9b83de364ea45551f674d96',1999,'LK','Sri Lanka','communications',975,'Telephones: 352,681 (1997 est.); 114,888 cellular
telephone subscribers (1997 est.)
Telephone system: very inadequate domestic
service, but expanding with the entry of two wireless
loop operators and privatization of national telephone
company; good international service
domestic: NA
international: submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 12, FM 5, shortwave
0
Radios: 3.6 million (1996 est.)
Television broadcast stations: 21 (19 network
stations, two low-power stations) (1997)
Televisions: 1 .6 million (1996 est.)','a05548c8e05a1e469f3bb2984c10b0e86e8b4919c54e4a8b54678a669fc4be2d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c6e6efac07dc88fd185762e510ced1e6893a50a32d75c67db8072e39b1363dc',1999,'SD','Sudan','communications',982,'Telephones: 77,215 (1983 est.)
Telephone system: large, well-equipped system by
African standards, but barely adequate and poorly
maintained by modern standards
domestic: consists of microwave radio relay, cable,
radiotelephone communications, tropospheric scatter,
and a domestic satellite system with 14 earth stations
international: satellite earth stations - 1 1ntelsat
456
Sudan (continued)
(Atlantic Ocean) and 1 Arabsat
Radio broadcast stations: AM 1 1 , FM 1 , shortwave
1 (1998 est.)
Radios: 5.75 million (1998 est.)
Television broadcast stations: 3 (1997)
Televisions: 250,000 (1998 est.)','98f2b5ffbb01198b3ccbdbae287c56805cf6fa6dd892652a84bd8f9daad382b8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69cf61389a3dc5b556cb09f9eda0e2d04d5f0de10ac84c1621d1355051e25d1a',1999,'TJ','Tajikistan','communications',995,'Telephones: 303,000(1991 est.)
Telephone system: poorly developed and not well
maintained; many towns are not reached by the
national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio
relay to other CIS republics, and by leased
connections to the Moscow international gateway
switch; Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite earth
stations - 1 Orbita and 2 Intelsat
Radio broadcast stations: 1 state-owned radio
broadcast station of NA type
Radios: NA
Television broadcast stations: 0 (there are,
however, repeaters that relay programs from Russia,
Iran, and Turkey) (1997)
Televisions: NA
Telephones: 88,000(1994)
Telephone system: fair system operating below
capacity
domestic: open wire, microwave radio relay,
tropospheric scatter
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 1 2, FM 4, shortwave
0
Radios: 740,000 (1994 est.)
Television broadcast stations: 4 (1998)
Televisions: 60,000 (1994 est.)','667d3d61932b316b924e52567d3cca3d2cdde3cca1fd6d77ae41bcad47bf2b88','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e69819072c28bb920626b5bae77907af1f645a67a0607a359bff8bc1347b466',1999,'TH','Thailand','communications',1003,'Telephones: 1 ,553,200 (1994 est.)
Telephone system: service to general public
adequate, but investments in technological upgrades
reduced by recession; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel
cable; domestic satellite system being developed
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 200 (in
government-controlled network), FM 100 (in
government-controlled network), shortwave 0
Radios: 10.75 million (1992 est.)
Television broadcast stations: 5 (all in Bangkok; in
addition, there are 131 repeaters) (1997)
Televisions: 3.3 million (1993 est.)','6ecd8cd8613e16efca614bf121a7342c08545bd0f880fca17a17fa45223bac8d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95286d9abcfb98d5c812e68ab8154ad4c6499b29f9a428c20a5cee25f75a15fd',1999,'TG','Togo','communications',1011,'Telephones: 47,000 (10,000 cellular telephone
subscribers) (1998 est.)
Telephone system: fair system based on network of
microwave radio relay routes supplemented by
open-wire lines and cellular system
domestic: microwave radio relay and open-wire lines
for conventional system; cellular system has capacity
of 10,000 telephones
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Symphonie
Radio broadcast stations: AM 2, FM 0, shortwave
0
Radios: 795,000 (1992 est.)
Television broadcast stations: 3 (in addition, there
are two repeaters) (1997)
Televisions: 24,000 (1992 est.)','22648ebf00e9d5981916e5a930977b733ce7a056389b1cf7483f33a5f99e1761','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('101fcc3c632bc964c7412164d1d0fc6733f4ad4be9fbf8ad34e06cabcae72b50',1999,'TK','Tokelau','communications',1020,'Telephones: NA
Telephone system:
domestic: radiotelephone service between islands
international: radiotelephone service to Western
Samoa; government-regulated telephone service
(TeleTok), with three satellite earth stations,
established in 1997
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: each atoll has a radio broadcast station of NA
type that broadcasts shipping and weather reports
Radios: 1,000 (1993 est.)
Television broadcast stations: NA (1997)
Televisions: NA','3a3ae17ddbccffe224c3a0fca85a39ff645605d37a06efc6be0d696aac41f79f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26044a8ae43132e7163d08febe6dfcae4c9e87ee9188de9b0d13350f3ee2a896',1999,'TV','Tuvalu','communications',1027,'Telephones: 130 (1983 est.)
Telephone system:
domestic: radiotelephone communications between
islands
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave
0
Radios: 4,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 61 ,600 (1990 est.)
Telephone system: fair system but in serious need
of expansion and better maintenance; a cellular
system has been introduced as a stopgap but the
communications problems will not be solved without
substantial investment in the conventional telephone
infrastructure; e-mail and Internet services are
available
domestic: intercity traffic by wire, microwave radio
relay, and radiotelephone communications stations,
cellular system for short range traffic
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 10, FM 0, shortwave
0
Radios: 2.13 million (1993 est.)
Television broadcast stations: 8 (in addition, there
is one low-power repeater) (1997)
Televisions: 220,000 (1993 est.)','09b37fc57b6b8456610052f857cebbf626e72b9e99219e5b0a764fe41dba072a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('334ae0faeb6b44888b7c18604df69fa20fcbfa59deb502be116448d5ea33ab5e',1999,'AE','United Arab Emirates','communications',1034,'Telephones: 677,793 (1993 est.)
Telephone system: modern system consisting of
microwave radio relay and coaxial cable; key centers
are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and
Pakistan; tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 8, FM 3, shortwave
0
Radios: 545,000 (1992 est.)
Television broadcast stations: 15 (1997)
Televisions: 170,000 (1993 est.)','ce94d959cc7b5bb4bf4537dad3258ceac3d82716f14ca35955394659ac47e644','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bec9a3bf61daece96302a3eaa2788fdd16bbed8b34e0198c0a679a7b2c2b9f0b',1999,'UY','Uruguay','communications',1047,'Telephones: 1 .475 million (1998 est.)
Telephone system: poorly developed; ambitiously
engaged in telecommunications modernization
domestic: in 1998 there were six cellular networks
operating in Uzbekistan; 4 GSM, 1 D-AMPS, 1 AMPS
standard
international: linked by landline or microwave radio
relay with CIS member states and to other countries
by leased connection via the Moscow international
gateway switch; new Intelsat links to Tokyo (Japan)
and Ankara (Turkey) give Uzbekistan international
access independent of Russian facilities; satellite
earth stations - NA Orbita and NA Intelsat;
Trans-Asia-Europe Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA,
shortwave NA; note - there are 12 radio broadcast
stations including one state-owned broadcast station
of NA type and four independent stations
515
Uzbekistan (continued)
Radios: 29,016,870
Television broadcast stations: 4 (in addition, there
are two repeater stations that relay Russian ORT
programs and Kazakh, Kyrgyz, and Tadzhik
programs) (1 997)
Televisions: 24,497,850','f279b81ae188548cb98e87de6703966aed39cc8dc106c7809a13fe6b8e514e04','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34f74be79abdd7c50fc81675922b1946d954ea0e794340fe40082080e258afbd',1999,'VU','Vanuatu','communications',1053,'Telephones: 4,000 (1994 est.)
Telephone system:
domestic: NA
517
Vanuatu (continued)
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave
0 ''
Radios: 49,000 (1994 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1994 est.)
Telephones: 1 .44 million (1987 est.)
Telephone system: modern and expanding
domestic: domestic satellite system with 3 earth
stations
international: 3 submarine coaxial cables; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 181, FM 0,
shortwave 26
Radios: 9.04 million (1992 est.)
Television broadcast stations: 66 (in addition,
there are 45 repeaters) (1997)
Televisions: 3.3 million (1992 est.)
Telephones: 800,000 (1995 est.)
Telephone system: while Vietnam''s
telecommunication sector lags far behind other
countries in Southeast Asia, Hanoi has made
considerable progress since 1991 in upgrading the
system; Vietnam has digitized all provincial switch
boards, while fiber-optic and microwave transmission
systems have been extended from Hanoi, Da Nang,
and Ho Chi Minh City to all provinces; the density of
telephone receivers nationwide doubled from 1993 to
1995, but is still far behind other countries in the
region; Vietnam''s telecommunications strategy aims
to increase telephone density to 30 per 1 ,000
inhabitants by the year 2000 and authorities estimate
that approximately $2.7 billion will be spent on
telecommunications upgrades through the end of the
decade
domestic: NA
international: satellite earth stations - 2 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM NA, FM 228,
shortwave 0
Radios: 7.215 million (1992 est.)
Television broadcast stations: NA
Televisions: 2.9 million (1992 est.)','6899370143ed83de98b37fd0266ecad830d3674469a366406f401fc03c4c5dbe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3684c1e52d4a745e1bf2c7284550cc7bac68f569ac53bec93b03c44baf08a2ae',1999,'PR','Puerto Rico','communications',1059,'Telephones: 60,000 (1990 est.)
Telephone system:
domestic: modern, uses fiber-optic cable and
microwave radio relay
international: submarine cable and satellite
communications; satellite earth stations - NA
Radio broadcast stations: AM 4, FM 8, shortwave
0(1988)
Radios: 1 05,000 (1 994 est.)
Television broadcast stations: 2 (1997)
Televisions: 66,000 (1994 est.)','8de3b41606fc3e894c9da355e2256d097f46e7a00dafdd32e278b86fccecee3b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fef344833d9b8e9d76d6bc58196ed534d1b7e8c21e0dea037fa6fb1d7681b4d',1999,'ZM','Zambia','communications',1069,'Telephones: 1 31 ,655 (1 992 est.)
Telephone system: since unification in 1 990, efforts
have been made to create a national
telecommunications network
domestic: the network consists of microwave radio
relay, cable, and tropospheric scatter
international: satellite earth stations - 3 Intelsat (2
Indian Ocean and 1 Atlantic Ocean), 1 1ntersputnik
(Atlantic Ocean region), and 2 Arabsat; microwave
radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 4, FM 1 , shortwave
0
Radios: 325,000 (1993 est.)
Television broadcast stations: 7 (in addition, there
are several low-power repeaters) (1997)
Televisions: 1 00,000 (1 993 est.)','83744f66eb1f8295af20e759b513fc3f4b4c965235424f847de9ad091504c91f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('036e376a6e3f9adb4b93fcf06c3c35da49915ed3d84e9591a915d5d8c5d79010',1999,'ZW','Zimbabwe','communications',1077,'Telephones: 80,900 (1987 est.)
Telephone system: facilities are among the best in
Sub-Saharan Africa
domestic: high-capacity microwave radio relay
connects most larger towns and cities
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 1 1 , FM 5, shortwave
0
Radios: 1,889,140
Television broadcast stations: 9 (1997)
Televisions: 215,000 (1995 est.)
Telephones: 301,000 (1990 est.)
Telephone system: system was once one of the
best in Africa, but now suffers from poor maintenance
domestic: consists of microwave radio relay links,
open-wire lines, and radiotelephone communication
stations
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 8, FM 1 8, shortwave
0
Radios: 890,000 (1992 est.)
Television broadcast stations: 16(1 997)
Televisions: 280,000 (1992 est.)','b95241e3373494a41a86573a999001107f758924b1de7d0a5504d23ee440e010','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d95a8ffc2d97b848de8c8cf806e6b89942b463b5cc19d6f8b11bdf9d81a03d75',1999,'ZW','Zimbabwe','communications',10,'Telephones: 31,200 (1983 est.)
Telephone system:
domestic: very limited telephone and telegraph service; in 1997,
telecommunications links were established between Mazar-e Sharif,
Herat, Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations--1 Intelsat (Indian Ocean)
linked only to Iran and 1 Intersputnik (Atlantic Ocean region);
commercial satellite telephone center in Ghazni
Radio broadcast stations: AM 6 (5 are inactive), FM 1, shortwave
3 (1998)
Radios: 1.67 million (1998 est.)
Television broadcast stations: NA
note: in 1997, there was a station in Mazar-e Sharif reaching four
northern Afghanistan provinces; also, the government ran a central
television station in Kabul and regional stations in nine of the 30
provinces; it is unknown if any of these stations currently operate
Televisions: 100,000 (1998 est.)
Telephones: 55,000
Telephone system:
domestic: obsolete wire system; no longer provides a telephone for
every village; in 1992, following the fall of the communist
government, peasants cut the wire to about 1,000 villages and used
it to build fences
international: inadequate; international traffic carried by
microwave radio relay from the Tirana exchange to Italy and Greece
Radio broadcast stations: AM 16, FM 3, shortwave 4 (1998)
Radios: 577,000 (1991 est.)
Television broadcast stations: 13 (1997)
Televisions: 300,000 (1993 est.)
Telephones: 1,381,342 (5,200 cellular telephone subscribers)
(1997)
Telephone system:
domestic: good service in north but sparse in south; domestic
satellite system with 12 earth stations (20 additional domestic
earth stations are planned)
international: 5 submarine cables; microwave radio relay to Italy,
France, Spain, Morocco, and Tunisia; coaxial cable to Morocco and
Tunisia; participant in Medarabtel; satellite earth stations--2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik, and
1 Arabsat
Radio broadcast stations: AM 23, FM 1, shortwave 8 (1998 est.)
Radios: 3.5 million (1998 est.)
Television broadcast stations: 18 (not including low-power
stations) (1997)
Televisions: 2 million (1998 est.)','52e3aa0b0bbe0f32b3e4db6efd7713aae80a7bc804b6fce91cc653b3657029e4','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f697efc1fdf89472fba290bdf010d862b0acfdb37d4b408c75296a4261db398a',1999,'LY','Libya','communications',20,'Telephones: 9,000 (1994 est.)
Telephone system:
domestic: good telex, telegraph, facsimile and cellular phone
services; domestic satellite system with 1 Comsat earth station
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 12,000 (1994 est.)
Telephones: 21,258 (1983 est.)
Telephone system:
domestic: modern system with microwave radio relay connections
between exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15, shortwave 0 (1998)
Radios: 10,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: 7,000 (1991 est.)
Telephones: 78,000 (1991 est.)
Telephone system: telephone service limited mostly to government
and business use; HF radiotelephone used extensively for military
links
domestic: limited system of wire, microwave radio relay, and
tropospheric scatter
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 16, FM 8, shortwave 8 (1998)
Radios: NA
Television broadcast stations: 7 (1997)
Televisions: 50,000 (1993 est.)
Telephones: 890
Telephone system:
domestic: modern internal telephone system
international: microwave radio relay to island of Saint Martin
(Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6, shortwave 1 (1998)
Radios: 2,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: NA
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM 2 (American Forces Antarctic
Network), shortwave 1 (Argentina Antarctic Base de Egercito
Esperanza) (1998)
Radios: NA
Television broadcast stations: 1 (American Forces Antarctic
Network-McMurdo) (1997)
Televisions: NA
Telephones: 6,700
Telephone system:
domestic: good automatic telephone system
international: 1 coaxial submarine cable; satellite earth station--1
Intelsat (Atlantic Ocean); tropospheric scatter to Saba (Netherlands
Antilles) and Guadeloupe
Radio broadcast stations: AM 4, FM 2, shortwave 0 (repeater
transmitters for Deutsche Welle and BBC world broadcasts) (1998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: 28,000 (1993 est.)
Telephone system:
international: no submarine cables
Telephones: 4.6 million (1990)
Telephone system: 12,000 public telephones; extensive modern
system but many families do not have telephones; despite extensive
use of microwave radio relay, the telephone system frequently
grounds out during rainstorms, even in Buenos Aires
domestic: microwave radio relay and a domestic satellite system with
40 earth stations serve the trunk network
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 260 (including 10 inactive
stations), FM NA (probably more than 1,000, mostly unlicensed),
shortwave 6 (1998 est.)
Radios: 22.3 million (1991 est.)
Television broadcast stations: 42 (in addition, there are 444
repeaters) (1997)
Televisions: 7.165 million (1991 est.)','b54bb13b2c7e53bf439e522b85756ec9ecdfe9c682ab37adadfa5a967cbe5500','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c95f1f2e310884dc6a267899e44f17cc8f9b84d816343b5d1e7f5e6bc474e225',1999,'AM','Armenia','communications',27,'Telephones: 730,000 (1998 est.)
Telephone system: the Ministry of Communications oversees the
Ministry of Posts and Telecommunications; the national operator is
Armentel; the Greek Telecoms Company owns 90% of Armentel and will
provide a $60 million eight-year loan; Armenia has about 4,000
Internet users on one satellite channel
domestic: local--350,000 telephones are located in Yerevan; a
fiber-optic loop provides digital service to 80,000 of Yerevan''s
customers; GSM cellular is available in Yerevan, as is paging;
intercity--the former Soviet system provides service to 380,000
numbers mostly governmental
international: Yerevan is connected to the Trans-Asia-Europe line
through Iran; additional international service is available by
microwave, land line, and satellite through the Moscow switch; 1
INTELSAT earth station
Radio broadcast stations: AM 9, FM 6, shortwave 1 (1998)
Radios: NA
Television broadcast stations: 3 (in addition, programs are
received by relay from Russia; 100% of the population receive
Armenian and Russian TV programs) (1997)
Televisions: NA
Telephones: 22,922 (1993 est.)
Telephone system:
domestic: more than adequate
international: 1 submarine cable to Sint Maarten (Netherlands
Antilles); extensive interisland microwave radio relay links
Radio broadcast stations: AM 4, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 19,000 (1993 est.)
Telephone system:
international: numerous submarine cables with most between
continental Europe and the UK, between North America and the UK, and
in the Mediterranean; numerous direct links across Atlantic via
satellite networks
Telephones: 8.7 million (1987 est.)
Telephone system: excellent domestic and international service
domestic: domestic satellite system
international: submarine cables to New Zealand, Papua New Guinea,
and Indonesia; satellite earth stations--10 Intelsat (4 Indian Ocean
and 6 Pacific Ocean), 2 Inmarsat (Indian and Pacific Ocean Regions)
Radio broadcast stations: AM 262, FM 345, shortwave 1
(Australia''s only shortwave station, Radio Australia, broadcasts to
the world in seven languages, using 23 frequencies) (1998)
Radios: NA
Television broadcast stations: 104 (64 of these stations are
government-owned and 40 are commercial) (1997)
Televisions: 9.2 million (1992 est.)
Telephones: 3.47 million (1986 est.)
Telephone system:
domestic: highly developed and efficient
international: satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean) and 2 Eutelsat
Radio broadcast stations: AM 1, FM 61 (several hundred
repeaters), shortwave 1 (Austria''s single shortwave station, Radio
Austria International, transmits its programs to the world in six
languages using 12 frequencies and six communication satellite
relays) (1998)
Radios: 70% of all households had radiosaccoding to the 1993
census
Television broadcast stations: 51 (in addition, there are 920
repeaters) (1998)
Televisions: 2,418,584 (1984 est.)
Telephones: 1.414 million (1998)
Telephone system: Azerbaijani telecommunications fall under the
Ministry of Communications; Azerbaijan''s telephone system is a
combination of old Soviet era technology used by Azerbaijani
citizens and small- to medium-size commercial establishments, and
modern cellular phones used by an increasing middle class, large
commercial ventures, international companies, and most government
officials; the average citizen waits on a 200,000-person list for
telephone service; Internet and E-mail service are available in Baku
domestic: local--the majority of telephones are in Baku or other
industrial centers; intercity--about 700 villages still do not have
public phone service; all long distance service must use Azertel''s
(Ministry of Communications) lines; satellite service connects Baku
to a modern switch in its separated enclave to Nakhichevan
international: the old Soviet system of cable and microwave is still
serviceable; satellite service between Baku and Turkey provides
access to 200 countries; additional satellite providers supply
services between Baku and specific countries; Azerbaijan is a
signator of the Trans-Asia-Europe Fiber-Optic Line (TAE); their
lines are not laid but the Turkish satellite and a microwave between
Azerbaijan and Iran can provide Azerbaijan worldwide access through
this system
Radio broadcast stations: AM 10, FM 17, shortwave 1 (Azerbaijan''s
single shortwave station transmits its programs to the Middle East
in eight languages)
Radios: NA
Television broadcast stations: 2; note--the Ministry of
Communications is the monopoly broadcaster and rebroadcaster of
television in Azerbaijan; Azerbaijani, Russian, Armenian, Iranian,
British broadcasting companies, Voice of America, and other European
channels are available via satellite; television is broadcast to
Nakhichevan by satellite
Televisions: NA
Telephones: 200,000 (1997 est.)
Telephone system:
domestic: 91,183 telephone subscribers; totally automatic system;
highly developed
international: tropospheric scatter and submarine cable to Florida;
3 coaxial submarine cables; satellite earth station--1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave 0 (1998)
Radios: 200,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 60,000 (1993 est.)','648408f91ad5e34694f4ed7efdff64ff6903f601c88faa76e2aede9809937824','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('060d090dabf3b64b20b04ce9e7cb974510f0cb2519a48f46207e8421cd883415',1999,'SA','Saudi Arabia','communications',39,'Telephones: 73,552 (1987 est.)
Telephone system: modern system; good domestic services and
excellent international connections
domestic: NA
international: tropospheric scatter to Qatar and UAE; microwave
radio relay to Saudi Arabia; submarine cable to Qatar, UAE, and
Saudi Arabia; satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave 0 (1998)
Radios: 320,000 (1993 est.)
Television broadcast stations: 4 (1997)
Televisions: 270,000 (1993 est.)
Telephones: 249,800 (1994 est.)
Telephone system:
domestic: poor domestic telephone service
international: satellite earth stations--2 Intelsat (Indian Ocean);
international radiotelephone communications and landline service to
neighboring countries
Radio broadcast stations: AM 12, FM 12, shortwave 2 (one of
Bangladesh''s two shortwave stations, Bangladesh Betar or Radio
Bangladesh, transmits its programs to the world in six languages on
four frequencies) (1998)
Radios: NA
Television broadcast stations: 11 (1997)
Televisions: 350,000 (1993 est.)
Telephones: 87,343 (1991 est.)
Telephone system:
domestic: island wide automatic telephone system
international: satellite earth station--1 Intelsat (Atlantic Ocean);
tropospheric scatter to Trinidad and Saint Lucia
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: NA
Television broadcast stations: 1 (in addition, there are two
cable channels) (1997)
Televisions: 69,350 (1993 est.)
Telephones: 2.55 million (October 1998)
Telephone system: the Ministry of Telecommunications controls all
telecommunications through its carrier (a joint stock company)
Beltelcom which is a monopoly
domestic: local--Minsk has a digital metropolitan network and a
cellular NMT-450 network; waiting lists for telephones are long;
local service outside Minsk is neglected and poor; intercity--Belarus
has a partly developed fiber-optic backbone system presently serving
at least 13 major cities (1998); Belarus''s fiber optics form
synchronous digital hierarchy rings through other countries''
systems; an inadequate analog system remains operational
international: Belarus is a member of the Trans-European Line (TEL),
Trans-Asia-Europe Fiber-Optic Line (TAE) and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments provide
connectivity to Latvia, Poland, Russia, and Ukraine; worldwide
service is available to Belarus due to this infrastructure;
additional analog lines to Russia; Intelsat, Eutelsat and
Intersputnik earth stations
Radio broadcast stations: AM 28, FM 37, shortwave 11
Radios: 3.17 million (1991 est.)
Television broadcast stations: 17 (1997); note--Belarus has a
state-run television broadcasting network; independent local
television stations exist
Televisions: 9,686,854 (1996)
Telephones: 5.691 million (1992 est.); 1.7 million cellular
telephone subscribers (1998)
Telephone system: highly developed, technologically advanced, and
completely automated domestic and international telephone and
telegraph facilities
domestic: nationwide cellular telephone system; extensive cable
network; limited microwave radio relay network
international: 5 submarine cables; satellite earth stations--2
Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations: AM 5, FM 77, shortwave 1 (Belgium''s
single shortwave station, Radio Vlaanderen Internationaal, transmits
its programs internationally in Dutch, English, French, and German,
using 21 shortwave frequencies)
Radios: 100,000 (1992 est.)
Television broadcast stations: 24 (in addition, there are Dutch
programs on cable, TV-5 Europe by satellite relay, and American
Forces Network by relay from Germany) (1997)
Televisions: 3,315,662 (1993 est.)
Telephones: 29,000 (1996 est.)
Telephone system: above-average system
domestic: trunk network depends primarily on microwave radio relay
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 (Voice of America relay station),
FM 12, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: 27,048 (1993 est.)
Telephones: 38,354 (6,286 cellular telephone subscribers) (1998
est.)
Telephone system:
domestic: fair system of open wire, microwave radio relay, and
cellular connections
international: satellite earth station--1 Intelsat (Atlantic Ocean);
submarine cable
Radio broadcast stations: AM 2, FM 9, shortwave 4 (1998 est.)
Radios: 400,000 (1998 est.)
Television broadcast stations: 2 (one privately owned) (1997)
Televisions: 30,000 (1998 est.)
Telephones: 54,000 (1991 est.)
Telephone system:
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth stations--3
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3, shortwave 0
Radios: 78,000 (1992 est.)
Television broadcast stations: 3 (1997)
Televisions: 57,000 (1992 est.)
Telephones: 4,620 (1991 est.)
Telephone system:
domestic: domestic telephone service is very poor with very few
telephones in use
international: international telephone and telegraph service is by
landline through India; a satellite earth station was planned (1990)
Radio broadcast stations: AM 0, FM 1, shortwave 1 (1998)
Radios: 23,000 (1989 est.)
Television broadcast stations: 0 (1997)
Televisions: 200 (1985 est.)
Telephones: 144,300 (1987 est.)
Telephone system: new subscribers face bureaucratic difficulties;
most telephones are concentrated in La Paz and other cities
domestic: microwave radio relay system being expanded
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 177, FM 68, shortwave 112 (1998)
Radios: NA
Television broadcast stations: 48 (1997)
Televisions: 500,000 (1993 est.)
Telephones: 160,717 (1992 est.)
Telephone system: modern system centered in Doha
domestic: NA
international: tropospheric scatter to Bahrain; microwave radio
relay to Saudi Arabia and UAE; submarine cable to Bahrain and UAE;
satellite earth stations--2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 201,000 (1992 est.)
Television broadcast stations: 2 (in addition, there are three
repeaters) (1997)
Televisions: 205,000 (1992 est.)','86513b5c82f20bf3eca87f81008bf82a5079acde7b306f49c0364c8cbc944cf3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd1f57b734ff7f21b86eaff095c2eeacaefa1ea180bc42e705848da2c6baec7f',1999,'HR','Croatia','communications',52,'Telephones: 727,000
Telephone system: telephone and telegraph network is in need of
modernization and expansion; many urban areas are below average when
compared with services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 16, shortwave 1 (1998)
Radios: 840,000
Television broadcast stations: 21 (1997)
Televisions: 1,012,094
Telephones: 19,109 (1985 est.)
Telephone system: sparse system
domestic: small system of open-wire lines, microwave radio relay
links, and a few radiotelephone communication stations
international: microwave radio relay links to Zambia, Zimbabwe, and
South Africa; satellite earth station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 7, FM 15, shortwave 5 (1998)
Radios: NA
Television broadcast stations: 0 (1997)
Televisions: 13,800 (1993 est.)
Communications--note: automatic meteorological station
Telephones: 14,426,673 (1992 est.)
Telephone system: good working system
domestic: extensive microwave radio relay system and a domestic
satellite system with 64 earth stations
international: 3 coaxial submarine cables; satellite earth
stations--3 Intelsat (Atlantic Ocean), 1 Inmarsat (Atlantic Ocean
Region East)
Radio broadcast stations: AM 1,627, FM 251, shortwave 114 (of
which 91 are associated with AM stations) (1998)
Radios: 60 million (1993 est.)
Television broadcast stations: 138 (1997)
Televisions: 30 million (1993 est.)
Telephones: NA
Telephone system: facilities for military needs only
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 2, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA','6325a6d8c77cc30ed570d9f6efd63ec8ed4dd82b7e8645e29ce7def04556fe4e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca092bec4ee0dc0e78f0af0351cee2ae7dc9b0259810cf3899e28c12eab9404b',1999,'PR','Puerto Rico','communications',61,'Telephones: 6,291 (1990 est.)
Telephone system: worldwide telephone service
domestic: NA
international: submarine cable to Bermuda
Radio broadcast stations: AM 1, FM 4, shortwave 0 (1998)
Radios: 9,000 (1992 est.)
Television broadcast stations: 1 (in addition, there is one cable
company) (1997)
Televisions: 4,000 (1992 est.)
Telephones: 3,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 8, FM 4, shortwave 0
Radios: 6,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1992 est.)
Telephones: 1,312,596 (1999 est.)
Telephone system:
domestic: good system composed of open-wire lines, cables, and
microwave radio relay links; principal centers are Casablanca and
Rabat; secondary centers are Fes, Marrakech, Oujda, Tangier, and
Tetouan
international: 5 submarine cables; satellite earth stations--2
Intelsat (Atlantic Ocean) and 1 Arabsat; microwave radio relay to
Gibraltar, Spain, and Western Sahara; coaxial cable and microwave
radio relay to Algeria; participant in Medarabtel
Radio broadcast stations: AM 22, FM 7, shortwave 5 (1998 est.)
Radios: 5.1 million (1998 est.)
Television broadcast stations: 26 (in addition, there are 35
repeaters) (1997)
Televisions: 1.21 million (1998 est.)
Telephones: 70,000 (1998 est.)
Telephone system: fair system of tropospheric scatter, open-wire
lines, and microwave radio relay
domestic: microwave radio relay and tropospheric scatter
international: satellite earth stations--5 Intelsat (2 Atlantic Ocean
and 3 Indian Ocean)
Radio broadcast stations: AM 29, FM 4, shortwave 0
Radios: 700,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 44,000 (1992 est.)
Telephones: 89,722 (1992 est.)
Telephone system:
domestic: good urban services; fair rural service; microwave radio
relay links major towns; connections to other populated places are
by open wire
international: NA
note: a fully automated digital network is being implemented
Radio broadcast stations: AM 4, FM 40, shortwave 0
Radios: 195,000 (1992 est.)
Television broadcast stations: 8 (of which five are main stations
and three are low-power stations; there are also about 20 low-power
repeaters) (1997)
Televisions: 27,000 (1993 est.)
Telephones: 2,000 (1989 est.)
Telephone system: adequate local and international radiotelephone
communications provided via Australian facilities
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 4,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: NA
Telephones: 115,911 (1996 est.)
Telephone system: poor telephone and telegraph service; fair
radiotelephone communication service
domestic: NA
international: radiotelephone communications; satellite earth
station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 88, FM 1, shortwave 0
Radios: 690,000 (1992 est.)
Television broadcast stations: 6 (1998 est.)
Televisions: 45,000 (1992 est.)
Telephones: 8.431 million (1998 est.); 3.4 million cellular
telephone subscribers (1998 est.)
Telephone system: highly developed and well maintained; system of
multi-conductor cables gradually being supplemented/replaced by a
glass-fiber based telecommunication infrastructure; Mobile GSM-based
mobile telephony density rapidly growing; third generation Universal
Mobile Telecommunications System expected for introduction by the
year 2001
domestic: nationwide cellular telephone system; microwave radio relay
international: 5 submarine cables; satellite earth stations--3
Intelsat (1 Indian Ocean and 2 Atlantic Ocean), 1 Eutelsat, and 1
Inmarsat (Atlantic and Indian Ocean Regions)
Radio broadcast stations: AM 3 (relays 3), FM 12 (repeaters 39),
shortwave 0
Radios: 14 million (1994 est.)
Television broadcast stations: 15 (in addition, there are five
low-power repeaters) (1997)
Televisions: 7.6 million (1994 est.)
Telephones: NA
Telephone system: generally adequate facilities
domestic: extensive interisland microwave radio relay links
international: 2 submarine cables; satellite earth stations--2
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 4, shortwave 0
Radios: 205,000 (1992 est.)
Television broadcast stations: 3 (in addition, there is a cable
service which supplies programs received from various US satellite
networks) (1997)
Televisions: 64,000 (1992 est.)
Telephones: 182.558 million (1987 est.)
Telephone system:
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries conventional
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout country
international: 24 ocean cable systems in use; satellite earth
stations--61 Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5
Intersputnik (Atlantic Ocean region), and 4 Inmarsat (Pacific and
Atlantic Ocean regions) (1990 est.)
Radio broadcast stations: AM 4,987, FM 4,932, shortwave 0
Radios: 540.5 million (1992 est.)
Television broadcast stations: more than 1,500 (including nearly
1,000 stations affiliated with the five major networks--NBC, ABC,
CBS, FOX, and PBS; in addition, there are about 9,000 cable TV
systems) (1997)
Televisions: 215 million (1993 est.)','c5873bf6b87db764de2e5005a9dd6db67ed29d9eb00ba946e24cc78c8c41465d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7aaa12ec626233879b35b9fad678d9e82289392b50782e4169b74f4663494fb',1999,'MY','Malaysia','communications',72,'Telephones: 90,000 (1997 est.)
Telephone system: service throughout country is excellent;
international service good to Europe, US, and East Asia
domestic: NA
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 3, FM 10, shortwave 0 (1998)
Radios: 284,000 (1995 est.)
Television broadcast stations: 2 (1997)
Televisions: 173,000 (1995 est.)
Telephones: 2,773,293 (1993 est.)
Telephone system: almost two-thirds of the lines are residential
domestic: extensive but antiquated transmission system of coaxial
cable and microwave radio relay; telephone service is available in
most villages
international: direct dialing to 36 countries; satellite earth
stations--1 Intersputnik (Atlantic Ocean region); Intelsat available
through a Greek earth station
Radio broadcast stations: AM 24, FM 93, shortwave 2 (1998)
Radios: NA
Television broadcast stations: 33 (in addition, there are two
relays of Russian program OK-1 and two relays of TV-5 Europe) (1997)
Televisions: 2.1 million (May 1990 est.)
Telephones: 21,000 (1993 est.)
Telephone system: all services only fair
domestic: microwave radio relay, open wire, and radiotelephone
communication stations
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 2, FM 17, shortwave 1 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 49,000 (1991 est.)
Telephones: 122,195 (1993 est.)
Telephone system: meets minimum requirements for local and
intercity service for business and government; international service
is good
domestic: NA
international: satellite earth station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 3 (1998)
Radios: NA
Television broadcast stations: 2 (1998 est.)
Televisions: 88,000 (1992 est.)
Telephones: 7,200 (1987 est.)
Telephone system: primitive system
domestic: sparse system of open wire, radiotelephone communications,
and low-capacity microwave radio relay
international: satellite earth station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 4,500 (1993 est.)
Telephones: 7,000 (1981 est.)
Telephone system: adequate landline and/or cellular service in
Phnom Penh and other provincial cities; rural areas have little
telephone service
domestic: NA
international: adequate but expensive landline and cellular service
available to all countries from Phnom Penh and major provincial
cities; satellite earth station--1 Intersputnik (Indian Ocean Region)
Radio broadcast stations: AM 7, FM 3, shortwave 3 (1998)
Radios: NA
Television broadcast stations: 1 government-operated station and
four commercial stations broadcasting to Phnom Penh and major
provincial cities via relay (1998)
Televisions: 800,000 (1996 est.)
Telephones: 36,737 (1991 est.)
Telephone system: available only to business and government
domestic: cable, microwave radio relay, and tropospheric scatter
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 11, FM 8, shortwave 3 (1998)
Radios: 6 million (1998 est.)
Television broadcast stations: 1 (1998)
Televisions: 15,000 (1998)
Telephones: 15.3 million (1990)
Telephone system: excellent service provided by modern technology
domestic: domestic satellite system with about 300 earth stations
international: 5 coaxial submarine cables; satellite earth
stations--5 Intelsat (4 Atlantic Ocean and 1 Pacific Ocean) and 2
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 334, FM 35, shortwave 7 (one of the
shortwave stations, Radio Canada International, has six
transmitters, 48 frequencies, and broadcasts in seven languages; the
transmissions are relayed by repeaters in Europe and Asia) (1998)
Radios: NA
Television broadcast stations: 80 (in addition, there are many
repeaters) (1997)
Televisions: 11.53 million (1983 est.)
Telephones: 22,900 (1995 est.)
Telephone system:
domestic: interisland microwave radio relay system with both analog
and digital exchanges; work is in progress on a submarine
fiber-optic cable system which was scheduled for completion in 1998
international: 2 coaxial submarine cables; HF radiotelephone to
Senegal and Guinea-Bissau; satellite earth station--1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997 est.)
Televisions: 7,000 (1991 est.)
Telephones: 21,584 (1993 est.)
Telephone system:
domestic: NA
international: 1 submarine coaxial cable; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 4 (the four stations have a
total of six frequencies), shortwave 0 (1998)
Radios: 28,200 (1992 est.)
Television broadcast stations: NA
Televisions: 6,000 (1992 est.)
Telephones: 63,212 (1986 est.)
Telephone system: services are adequate and being improved;
facilities provide radiotelephone and telegraph, coastal radio,
aeronautical radio, and international radio communication services
domestic: mostly radiotelephone
international: submarine cables to Australia and Guam; satellite
earth station--1 Intelsat (Pacific Ocean); international radio
communication service
Radio broadcast stations: AM 31, FM 2, shortwave 0
Radios: 298,000 (1992 est.)
Television broadcast stations: 3 (1997)
Televisions: 10,000 (1992 est.)
Bornholm [island] Denmark 55 10 N 15 00 E
Bosnia Bosnia and 44 00 N 18 00 E
Herzegovina
Bosporus [strait] Atlantic Ocean 41 00 N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00 N 20 00 E
Bougainville [island] Papua New Guinea 6 00 S 155 00 E
Bougainville Strait Pacific Ocean 6 40 S 156 10 E
Bounty Islands New Zealand 47 43 S 174 00 E
Brasilia [US Embassy] Brazil 15 47 S 47 55 W
Bratislava [US Embassy] Slovakia 48 09 N 17 07 E
Brazzaville [US Embassy] Republic of the 4 16 S 15 17 E
Green Islands Papua New Guinea 4 30 S 154 10 E
Greenland Sea Arctic Ocean 79 00 N 5 00 W
Grenadines, Northern Saint Vincent 13 15 N 61 12 W
and the
Grenadines
Grenadines, Southern Grenada 12 07 N 61 40 W
Grytviken South Georgia 54 15 S 36 45 W
and the South
Sandwich Islands
Guadalajara [US Mexico 20 40 N 103 20 W
Consulate General]
Guadalcanal [island] Solomon Islands 9 32 S 160 12 E
Guadalupe, Isla de Mexico 29 11 N 118 17 W
Guangzhou [US Consulate China 23 06 N 113 16 E
General]
Guantanamo Bay [US Naval Cuba 20 00 N 75 08 W
Base]
Guatemala [US Embassy] Guatemala 14 38 N 90 31 W
Guinea, Gulf of Atlantic Ocean 3 00 N 2 30 E
Guayaquil [US Consulate Ecuador 2 13 S 79 54 W
General]
H Ha''apai Group Tonga 19 42 S 174 29 W
Habomai Islands Russia [de 43 30 N 146 10 E
facto]
Hadhramaut [region] Yemen 15 00 N 50 00 E
Hagatna (Agana) Guam 13 28 N 144 45 E
Hague, The [US Embassy] Netherlands 52 05 N 4 18 E
Haifa Israel 32 50 N 35 00 E
Haiphong Vietnam 20 52 N 106 41 E
Hainan Dao [island] China 19 00 N 109 30 E
Halifax [US Consulate Canada 44 39 N 63 36 W
General]
Halmahera [island] Indonesia 1 00 N 128 00 E
Hamburg [US Consulate Germany 53 33 N 9 59 E
General]
Hamilton [US Consulate Bermuda 32 17 N 64 46 W
General]
Hanoi [US Embassy] Vietnam 21 02 N 105 51 E
Harare [US Embassy] Zimbabwe 17 50 S 31 03 E
Hatay [province] Turkey 36 30 N 36 15 E
Havana [US post not Cuba 23 08 N 82 22 W
maintained;
representation by US
Interests Section
(USINT) of the Swiss
Embassy]
Hawaii United States 20 00 N 157 45 W
Heard Island Heard Island and 53 06 S 73 30 E
McDonald Islands
Hejaz [region] Saudi Arabia 24 30 N 38 30 E
Helsinki [US Embassy] Finland 60 10 N 24 58 E
Hermosillo [US Mexico 29 04 N 110 58 W
Consulate]
Herzegovina Bosnia and 44 00 N 18 00 E
Herzegovina
Hispaniola [island] Dominican 18 45 N 71 00 W
Republic, Haiti
Ho Chi Minh City Vietnam 10 45 N 106 40 E
Hokkaido [island] Japan 44 00 N 143 00 E
Holland Netherlands 52 30 N 5 45 E
Hong Kong [US Consulate Hong Kong 22 15 N 114 10 E
General]
Honiara Solomon Islands 9 26 S 159 57 E
Honshu [island] Japan 36 00 N 138 00 E
Hormuz, Strait of Indian Ocean 26 34 N 56 15 E
Horn, Cape (Cabo de Chile 55 59 S 67 16 W
Hornos)
Horne, Iles de Wallis and 14 19 S 178 05 W
Futuna
Horn of Africa Djibouti, 8 00 N 48 00 E
Eritrea,
Ethiopia,','95e01d00a0e5640edd8d31d784e3d117aae8dd1b430a92acbaca7f939d364192','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbc3e9c9ec91c37a8ee12bedaa97007f57b9aea16440948b5dfee362a6a777e2',1999,'CG','Congo','communications',83,'Telephones: 16,867 (1992 est.)
Telephone system: fair system
domestic: network consists principally of microwave radio relay and
low-capacity, low-powered radiotelephone communication
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 3 (including Africa No. 1 and
R. France Internationale stations located in Bangui), shortwave 1
(1998)
Radios: NA
Television broadcast stations: NA
Televisions: 7,500 (1993 est.)
Telephones: 5,000 (1987 est.)
Telephone system: primitive system
domestic: fair system of radiotelephone communication stations
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave 3 (one of the
shortwave stations has three frequencies) (1998)
Radios: NA
Television broadcast stations: 1 (broadcasts 1800 to 2100 hours,
four days per week) (1997)
Televisions: 7,000 (1991 est.)
Telephones: 1.5 million (1994 est.)
Telephone system: modern system based on extensive microwave
radio relay facilities
domestic: extensive microwave radio relay links; domestic satellite
system with 3 earth stations
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 180 (eight inactive), FM 64,
shortwave 17 (one inactive) (1998)
Radios: NA
Television broadcast stations: 63 (in addition, there are 121
repeaters) (1997)
Televisions: 2.85 million (1992 est.)
Telephones: 105 million (1998 est.)
Telephone system: domestic and international services are
increasingly available for private use; unevenly distributed
domestic system serves principal cities, industrial centers, and all
townships
domestic: interprovincial fiber-optic trunk lines and cellular
telephone systems have been installed; a domestic satellite system
with 55 earth stations is in place
international: satellite earth stations--5 Intelsat (4 Pacific Ocean
and 1 Indian Ocean), 1 Intersputnik (Indian Ocean Region) and 1
Inmarsat (Pacific and Indian Ocean Regions); several international
fiber-optic links to Japan, South Korea, Hong Kong, Russia, and
Telephones: 550
Telephone system:
domestic: automatic network; HF radiotelephone from Saint Helena to
Ascension, then into worldwide submarine cable and satellite networks
international: major coaxial submarine cable relay point between
South Africa, Portugal, and UK at Ascension; satellite earth
stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 2,500 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Communications--note: Gough Island has a meteorological station
Telephones: 3,800 (1986 est.)
Telephone system: good interisland VHF/UHF/SHF radiotelephone
connections and international link via Antigua and Barbuda and Saint
Martin (Guadeloupe and Netherlands Antilles)
domestic: interisland links are handled by VHF/UHF/SHF radiotelephone
international: international calls are carried by radiotelephone to
Antigua and Barbuda and from there switched to submarine cable or to
Intelsat, or carried to Saint Martin (Guadeloupe and Netherlands
Antilles) by radiotelephone and switched to Intelsat
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 25,000 (1993 est.)
Television broadcast stations: 1 (in addition, there are three
repeaters) (1997)
Televisions: 9,500 (1993 est.)
Telephones: 26,000 (1992 est.)
Telephone system:
domestic: system is automatically switched
international: direct microwave radio relay link with Martinique and
Saint Vincent and the Grenadines; tropospheric scatter to Barbados;
international calls beyond these countries are carried by Intelsat
from Martinique
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: 104,000 (1992 est.)
Television broadcast stations: 3 (of which two are commercial
(1997)
Televisions: 26,000 (1992 est.)
Telephones: 12,531,277 (1998)
Telephone system: Ukraine''s phone systems are administered
through the State Committee for Communications; Ukraine has a
telecommunication development plan through 2005; Internet service is
available in large cities
domestic: local--Kiev has a digital loop connected to the national
digital backbone; Kiev has several cellular phone companies
providing service in the different standards; some companies offer
intercity roaming and even limited international roaming; cellular
phone service is offered in at least 100 cities nationwide
international: foreign investment in the form of joint business
ventures greatly improved the Ukrainian telephone system; Ukraine''s
two main fiber-optic lines are part of the Trans-Asia-Europe
Fiber-Optic Line (TAE); these lines connect Ukraine to worldwide
service through Belarus, Hungary, and Poland; Odesa is a landing
point for the Italy-Turkey-Ukraine-Russia Undersea Fiber-Optic Cable
(ITUR) giving Ukraine an additional fiber-optic link to worldwide
service; Ukraine has Intelsat, Inmarsat, and Intersputnik earth
stations
Radio broadcast stations: AM NA, FM NA, shortwave NA; note--at
least 25 local broadcast stations of NA type (1998)
Radios: 15 million (1990)
Television broadcast stations: at least 33 (in addition 21
repeater stations that relay ORT broadcasts from Russia) (1997)
Televisions: 17.3 million (1992)
Telephones: 677,793 (1993 est.)
Telephone system: modern system consisting of microwave radio
relay and coaxial cable; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations--3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean) and 1 Arabsat; submarine cables to Qatar,
Bahrain, India, and Pakistan; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
Radio broadcast stations: AM 8, FM 3, shortwave 0
Radios: 545,000 (1992 est.)
Television broadcast stations: 15 (1997)
Televisions: 170,000 (1993 est.)
Belgrade Serbia and 44 50 N 20 30 E
Bridgetown [US Embassy] Barbados 13 06 N 59 37 W
Brisbane Australia 27 28 S 153 02 E
Britain (see Great United Kingdom 54 00 N 2 00 W
Britain)
British East Africa Kenya, Tanzania, 1 00 N 38 00 E
Con Son [Islands] Vietnam 8 43 N 106 36 E
Cook Strait Pacific Ocean 41 15 S 174 30 E
Copenhagen [US Embassy] Denmark 55 40 N 12 35 E
Coral Sea Pacific Ocean 15 00 S 150 00 E
Corfu [island] Greece 39 40 N 19 45 E
Corinth Greece 37 56 N 22 56 E
Corn Islands (Islas del Nicaragua 12 15 N 83 00 W
Maiz)
Corocoro Island Guyana, 3 38 N 66 50 W
Venezuela
Corsica (Corse) [island] France 42 00 N 9 00 E
Corsico [island] Equatorial 0 55 N 9 19 E
Kathmandu [US Embassy] Nepal 27 43 N 85 19 E
Kattegat [strait] Atlantic Ocean 57 00 N 11 00 E
Kauai Channel Pacific Ocean 21 45 N 158 50 W
Keeling Islands Cocos (Keeling) 12 30 S 96 50 E
Islands
Kerguelen, Iles French Southern 49 30 S 69 30 E
and Antarctic
Lands
Kermadec Islands New Zealand 29 50 S 178 15 W
Kerulen River China, Mongolia 48 48 N 117 00 E
Khabarovsk Russia 48 27 N 135 06 E
Khanka, Lake China, Russia 45 00 N 132 24 E
Khartoum [US Embassy] Sudan 15 36 N 32 32 E
Khmer Republic Cambodia 13 00 N 105 00 E
Khuriya Muriya Islands Oman 17 30 N 56 00 E
(Kuria Muria Islands)
Khyber Pass Afghanistan, 34 05 N 71 10 E
Kirghiziya Kyrgyzstan 41 00 N 75 00 E
Kiritimati (Christmas Kiribati 1 52 N 157 20 W
Island)
Kishinev (see Chisinau) Moldova 47 00 N 28 50 E
Kithira Strait Atlantic Ocean 36 00 N 23 00 E
Kobe Japan 34 41 N 135 10 E
Kodiak Island United States 57 49 N 152 23 W
Kola Peninsula (Kol''skiy Russia 67 20 N 37 00 E
Poluostrov)
Kolonia [US Embassy] Federated States 6 58 N 158 13 E
of Micronesia
Korea Bay Pacific Ocean 39 00 N 124 00 E
Korea, Democratic North Korea 40 00 N 127 00 E
People''s Republic of
Korea, Republic of South Korea 37 00 N 127 30 E
Korea Strait Pacific Ocean 34 00 N 129 00 E
Koror [US Embassy] Palau 7 20 N 134 29 E
Kosovo [region] Serbia and 42 30 N 21 00 E
Lusaka [US Embassy] Zambia 15 25 S 28 17 E
Luxembourg [US Embassy] Luxembourg 49 45 N 6 10 E
Luzon [island] Philippines 16 00 N 121 00 E
Luzon Strait Pacific Ocean 20 30 N 121 00 E
Lyakhov Islands Russia 73 45 N 138 00 E
M Macao Macau 22 10 N 113 33 E
Macedonia The Former 41 50 N 22 00 E
Yugoslav
Republic of
Macedonia
Macquarie Island Australia 30 07 S 147 24 E
Maddalena, Isola Italy 41 13 N 09 24 E
Madeira Islands Portugal 32 40 N 16 45 W
Madras [see Chennai] India 13 04 N 80 16 E
Madrid [US Embassy] Spain 40 24 N 3 41 W
Magellan, Strait of Atlantic Ocean 54 00 S 71 00 W
Maghreb Algeria, Libya, 30 00 N 5 00 E
Mauritania,
Morocco, Tunisia
Mahe Island Seychelles 4 41 S 55 30 E
Maiz, Islas del (Corn Nicaragua 12 15 N 83 00 W
Islands)
Majorca Island (Isla de Spain 39 30 N 3 00 E
Mallorca)
Majuro [US Embassy] Marshall Islands 7 05 N 171 08 E
Makassar Strait Pacific Ocean 2 00 S 117 30 E
Malabo Equatorial 3 45 N 8 47 E
Shag Island Heard Island and 53 00 S 72 30 E
McDonald Islands
Shag Rocks South Georgia 53 33 S 42 02 W
and the South
Sandwich Islands
Shanghai [US Consulate China 31 14 N 121 28 E
General]
Shenyang [US Consulate China 41 48 N 123 27 E
General]
Shetland Islands United Kingdom 60 30 N 1 30 W
Shikoku [island] Japan 33 45 N 133 30 E
Shikotan [island] Russia [de 43 47 N 146 45 E
facto]
Siam Thailand 15 00 N 100 00 E
Siberia [region] Russia 60 00 N 100 00 E
Sibutu Passage Pacific Ocean 4 50 N 119 35 E
Sicily [island] Italy 37 30 N 14 00 E
Sicily, Strait of Atlantic Ocean 37 20 N 11 20 E
Sidra, Gulf of Atlantic Ocean 31 30 N 18 00 E
Sikkim [state] India 27 50 N 88 30 E
Sinai Peninsula Egypt 29 30 N 34 00 E
Singapore [US Embassy] Singapore 1 17 N 103 51 E
Singapore Strait Pacific Ocean 1 15 N 104 00 E
Sinkiang (Xinjiang) China 42 00 N 86 00 E
Sint Eustatius [island] Netherlands 17 29 N 62 58 W
Antilles
Sint Maarten [island] Netherlands 18 04 N 63 04 W
Antilles
Skagerrak [strait] Atlantic Ocean 57 45 N 9 00 E
Skopje [US Embassy] The Former 41 59 N 21 26 E
Yugoslav
Republic of
Macedonia
Society Islands (Iles de French Polynesia 17 00 S 150 00 W
la Societe)
Socotra [island] Yemen 12 30 N 54 00 E
Sofia [US Embassy] Bulgaria 42 41 N 23 19 E
Solomon Islands, Papua New Guinea 6 00 S 155 00 E
northern
Solomon Islands, Solomon Islands 8 00 S 159 00 E
southern
Solomon Sea Pacific Ocean 8 00 S 153 00 E
Songkhla Thailand 7 12 N 100 36 E
Sound, The (Oresund) Atlantic Ocean 55 50 N 12 40 E
South Atlantic Ocean Atlantic Ocean 30 00 S 15 00 W
South China Sea Pacific Ocean 10 00 N 113 00 E
South Georgia [island] South Georgia 54 15 S 36 45 W
and the South
Sandwich Islands
South Island New Zealand 43 00 S 171 00 E
South Korea South Korea 37 00 N 127 30 E
South Orkney Islands Antarctica 61 00 S 45 00 W
South Ossetia [region] Georgia 42 20 N 44 00 E
South Pacific Ocean Pacific Ocean 30 00 S 130 00 W
South Sandwich Islands South Georgia 57 45 S 26 30 W
and the South
Sandwich Islands
South Shetland Islands Antarctica 62 00 S 59 00 W
South Tyrol [region] Italy 46 30 N 10 30 E
South Vietnam Vietnam 12 00 N 108 00 E
South Yemen (People''s Yemen 14 00 N 48 00 E
Democratic Republic of
Yemen)
South-West Africa Namibia 22 00 S 17 00 E
Southern Grenadines Grenada 12 20 N 61 30 W
Southern Rhodesia Zimbabwe 20 00 S 30 00 E
Soviet Union Armenia,
Azerbaijan,
Belarus,
Estonia,
Georgia,
Kazakhstan,
Kyrgyzstan,
Latvia,
Lithuania,
Moldova, Russia,
Tajikistan,
Turkmenistan,
Ukraine,
Zanzibar [island] Tanzania 6 10 S 39 11 E
Zion, Mount Israel, Jordan 31 46 N 35 14 E
Zurich Switzerland 47 23 N 8 32 E
=====================================================================
End of the Project Gutenberg EBook of The 1999 CIA Factbook, by
United States. Central Intelligence Agency.
*** END OF THIS PROJECT GUTENBERG EBOOK THE 1999 CIA FACTBOOK ***
***** This file should be named 27676.txt or 27676.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/2/7/6/7/27676/
Produced by Al Haines
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless you comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclai','20a5beecafa68c8b11e7308c3f1ceb44d48977a711f099641937eb172fa6f231','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e390cc6b4da6cb58a00ff8d07a98ea3675059a93fa0a1b4d2ddc7271dc87e9f9',1999,'CG','Congo','communications',84,'mers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need, is critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
throughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','ff6aadf1ca76ae75dbf3fcf0cf4637f1104a2193f7af6914cb1e2171660db471','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15dbb4b62497e236465dbbf0438cc280b1526399d87c0e55abb6a39502c1471c',1999,'DE','Germany','communications',89,'Radio broadcast stations: AM 569, FM NA, shortwave 173
Radios: 216.5 million (1992 est.)
Television broadcast stations: 209 (China Central Television,
government-owned; in addition there are 31 provincial TV stations
and nearly 3,000 city TV stations) (1997)
Televisions: 300 million
Telephones: 210,000 (1993 est.)
Telephone system: fairly modern network centered in the city of','3e87cd53594ab9ebc6df77394cf210bf241a179b190777b3497fd9fc38afbb8c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7bf5a7b09980643dcd8eef77bfd3e83f6dd5c92379092d42b0ae22699e603e',1999,'AU','Australia','communications',108,'Telephones: NA
Telephone system:
domestic: NA
international: NA
note: external telephone and telex services are provided by Intelsat
satellite
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 500 (1992)
Television broadcast stations: NA (1997)
Televisions: 350 (1992)
Telephones: NA
Telephone system:
domestic: NA
international: telephone, telex, and facsimile communications with
Australia and elsewhere via satellite; 1 satellite earth station of
NA type
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 300 (1992 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 1.89 million (1986 est.)
Telephone system: modern system in many respects
domestic: nationwide microwave radio relay system; domestic
satellite system with 11 earth stations
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 463, FM 35, shortwave 45 (1998 est.)
Radios: NA
Television broadcast stations: 60 (includes seven low-power
stations) (1997)
Televisions: 5.5 million (1993 est.)
Communications--note: there are automatic weather relay stations
on many of the isles and reefs relaying data to the mainland
Telephones: 281,042 (1983 est.)
Telephone system: very good domestic telephone service
domestic: NA
international: connected to Central American Microwave System;
satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 71, FM 0, shortwave 13
Radios: NA
Television broadcast stations: 6 (in addition, there are 11
repeaters) (1997)
Televisions: 340,000 (1993 est.)
Telephones: 200,000 (1988 est.)
Telephone system: well-developed by African standards but
operating well below capacity
domestic: open-wire lines and microwave radio relay
international: satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean); 2 coaxial submarine cables
Radio broadcast stations: AM 71, FM 4, shortwave 13
Radios: NA
Television broadcast stations: 14 (1997)
Televisions: 810,000 (1993 est.)
Telephones: 1.216 million (1993 est.)
Telephone system:
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 14, FM 8, shortwave 0
Radios: 1.1 million
Television broadcast stations: 18 (in addition, there are 145
repeaters) (1997)
Televisions: 1.52 million (1992 est.)
Telephones: 229,000
Telephone system: among the world''s least developed telephone
systems
domestic: NA
international: satellite earth station--1 Intersputnik (Atlantic
Ocean region)
Radio broadcast stations: AM 150, FM 5, shortwave 1
Radios: 2.14 million (1993 est.)
Television broadcast stations: 58 (1997)
Televisions: 2.5 million (1993 est.)
Telephones: Greek Cypriot area: 367,000 (1996 est.); Turkish
Cypriot area: 80,000 (1996 est.)
Telephone system: excellent in both the Greek Cypriot and Turkish
Cypriot areas
domestic: open wire, fiber-optic cable, and microwave radio relay
international: tropospheric scatter; 3 coaxial and 5 fiber-optic
submarine cables; satellite earth stations--3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean), 2 Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AM 4, FM 36,
shortwave 1, Turkish Cypriot area: AM 2, FM 6, shortwave 0
Radios: Greek Cypriot area: 500,000 (1996 est.); Turkish Cypriot
area: 130,000 (1996 est.)
Television broadcast stations: Greek Cypriot area: 7 (in
addition, there are 35 low-power repeaters) (1997); Turkish Cypriot
area: 3 (in addition, there are 4 repeaters) (1997)
Televisions: Greek Cypriot area: 300,000 (1996 est.); Turkish
Cypriot area: 90,000 (1996 est.)
Telephones: 3,349,539 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth stations--2 Intersputnik (Atlantic and
Indian Ocean regions)
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: 67 (in addition, there are 35
low-power stations and about 51 low-power repeaters) (1997)
Televisions: NA
Telephones: 3.2 million (1995 est.); 822,000 cellular telephone
subscribers
Telephone system: excellent telephone and telegraph services
domestic: buried and submarine cables and microwave radio relay form
trunk network, four cellular radio communications systems
international: 18 submarine fiber-optic cables linking Denmark with
Norway, Sweden, Russia, Poland, Germany, Netherlands, UK, Faroe
Islands, Iceland, and Canada; satellite earth stations--6 Intelsat,
10 Eutelsat, 1 Orion, 1 Inmarsat (Blaavand-Atlantic-East); note--the
Nordic countries (Denmark, Finland, Iceland, Norway, and Sweden)
share the Danish earth station and the Eik, Norway, station for
world-wide Inmarsat access
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: NA
Television broadcast stations: 78 (of which 35 are low-power
stations; in addition, there are 51 low-power repeaters) (1997)
Televisions: 3 million (1996 est.)
Telephones: 7,200 (1986 est.)
Telephone system: telephone facilities in the city of Djibouti
are adequate as are the microwave radio relay connections to
outlying areas of the country
domestic: microwave radio relay network
international: submarine cable to Jiddah, Suez, Sicily, Marseilles,
Colombo, and Singapore; satellite earth stations--1 Intelsat (Indian
Ocean) and 1 Arabsat; Medarabtel regional microwave radio relay
telephone network
Radio broadcast stations: AM 1, FM 2, shortwave 0
Radios: 35,000
Television broadcast stations: 1 (in addition, there are 5
low-power repeaters) (1998)
Televisions: 17,000 (1998)
Telephone system:
international: submarine cables from India to UAE and Malaysia and
from Sri Lanka to Djibouti and Indonesia
Telephones: 1,276,600 (1993 est.)
Telephone system: domestic service fair, international service
good
domestic: interisland microwave system and HF radio police net;
domestic satellite communications system
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 618, FM 38, shortwave 0
Radios: 28.1 million (1992 est.)
Television broadcast stations: 41 (of which 18 are
government-owned and 23 are commercial) (1997)
Televisions: 11.5 million (1992 est.)
Telephones: 8,991,797 (1997 est.)
Telephone system:
domestic: 25 regional telecommunications authorities created in
1996; these authorities are responsible for implementing paging
services and cellular systems; microwave radio relay extends
throughout the country with the system centered in Tehran; system is
moving toward digitization and direct-dial capability; 255
long-distance circuits (1999 est.); 366 telephone exchanges (1995
est.); 204,400 microwave channels (1996 est.); 230,000 cellular
telephone subscribers (1997 est.); 3,930 pager subscribers (1995
est.)
international: 13,985 international circuits (1999 est.) with a plan
to reach 14,000 by March 1999; satellite earth stations--9 Intelsat
(with 50 terminals) and 4 Inmarsat; HF radio and microwave radio
relay to Turkey, Azerbaijan, Pakistan, Afghanistan, Turkmenistan,
Syria, Kuwait, Tajikistan, and Uzbekistan; submarine fiber-optic
cable to UAE with access to Fiber-Optic Link Around the Globe
(FLAG); Trans Asia Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to Turkmenistan with
expansion to Georgia and Azerbaijan; four Internet service providers
as of 1997 with the number increasing (service limited to electronic
mail to promote Iranian culture)
Radio broadcast stations: AM 72, FM 6, shortwave 5 (1998 est.)
Radios: 13 million (1999 est.)
Television broadcast stations: 28 (in addition, there are 450
low-power repeaters, all government controlled) (1997)
Televisions: 7 million (1999 est.)
Telephones: 632,000 (1987 est.)
Telephone system: reconstitution of damaged telecommunication
facilities began after the Gulf war; most damaged facilities have
been rebuilt
domestic: the network consists of coaxial cables and microwave radio
relay links
international: satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean), 1 Intersputnik (Atlantic Ocean region) and 1
Arabsat (inoperative); coaxial cable and microwave radio relay to
Jordan, Kuwait, Syria, and Turkey; Kuwait line is probably
nonoperational
Radio broadcast stations: AM 16, FM 1, shortwave 0
Radios: 3.7 million (1998 est.)
Television broadcast stations: 13 (government controlled) (1997)
Televisions: 1 million (1992 est.)
Telephones: 900,000 (1987 est.)
Telephone system: modern digital system using cable and microwave
radio relay
domestic: microwave radio relay
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave 0
Radios: 2.2 million (1991 est.)
Television broadcast stations: 10 (in addition, there are 36
low-power repeaters) (1997)
Televisions: 1.025 million (1990 est.)
Telephones: 2.6 million (1996)
Telephone system: most highly developed system in the Middle East
although not the largest
domestic: good system of coaxial cable and microwave radio relay
international: 3 submarine cables; satellite earth stations--3
Intelsat (2 Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations: AM 9, FM 45, shortwave 0
Radios: 2.25 million (1993 est.)
Television broadcast stations: 24 (in addition, there are 31
low-power repeaters) (1997)
Televisions: 1.5 million (1993 est.)
Telephones: 25.6 million (1996 est.)
Telephone system: modern, well-developed, fast; fully automated
telephone, telex, and data services
domestic: high-capacity cable and microwave radio relay trunks
international: satellite earth stations--3 Intelsat (with a total of
5 antennas--3 for Atlantic Ocean and 2 for Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and NA Eutelsat; 21 submarine cables
Radio broadcast stations: AM 135, FM 28 (repeaters 1,840),
shortwave 0
Radios: 45.7 million (1996 est.)
Television broadcast stations: 6,317 (consisting of 117 public
stations with two kW of power or more, about 5,300 low-power public
stations, and about 900 low-power private stations, mostly in local
service) (1997)
Televisions: 17 million (1996 est.)
Telephones: 350,000 (1997 est.)
Telephone system: fully automatic domestic telephone network
domestic: NA
international: satellite earth stations--2 Intelsat (Atlantic Ocean);
3 coaxial submarine cables
Radio broadcast stations: AM 1, FM 7, shortwave 0 (1997)
Radios: 1.973 million (1997)
Television broadcast stations: 7 (1997)
Televisions: 330,000 (1992 est.)
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: radio and meteorological station
Telephones: 64 million (1987 est.)
Telephone system: excellent domestic and international service
domestic: NA
international: satellite earth stations--5 Intelsat (4 Pacific Ocean
and 1 Indian Ocean), 1 Intersputnik (Indian Ocean region), and 1
Inmarsat (Pacific and Indian Ocean regions); submarine cables to
China, Philippines, Russia, and US (via Guam)
Radio broadcast stations: AM 318, FM 58, shortwave 0
Radios: 97 million (1993 est.)
Television broadcast stations: 7,549 (consisting of 6,995
non-government and non-commercial stations, of which 95 are main
stations of 1 kW or greater power and 6,900 are low-power stations,
and 554 commercial stations of which 113 are main stations and 441
are repeaters); note--in addition, US Forces are served by 3 TV
stations and 2 TV cable stations (1997)
Televisions: 100 million (1993 est.)
Telephones: 38,748 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave 0
Radios: 97,000 (1992 est.)
Television broadcast stations: 6 (in addition, there are 25
low-power repeaters) (1997)
Televisions: 47,000 (1992 est.)
Telephones: 1.7 million (1986 est.)
Telephone system: excellent international and domestic systems
domestic: NA
international: submarine cables to Australia and Fiji; satellite
earth stations--2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 64, FM 2, shortwave 0
Radios: 3.215 million (1992 est.)
Television broadcast stations: 41 (in addition, there are 52
medium-power repeaters and over 650 low-power repeaters) (1997)
Televisions: 1.53 million (1992 est.)
Telephones: 66,810 (1993 est.)
Telephone system: low-capacity microwave radio relay and wire
system being expanded; connected to Central American Microwave System
domestic: wire and microwave radio relay
international: satellite earth stations--1 Intersputnik (Atlantic
Ocean region) and 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 45, FM 0, shortwave 3
Radios: 1.037 million (1992 est.)
Television broadcast stations: 3 (in addition, there are seven
low-power repeaters) (1997)
Televisions: 260,000 (1992 est.)
Telephones: 1,087 (1983 est.)
Telephone system:
domestic: NA
international: radiotelephone service with Sydney (Australia)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 2,000 (1993 est.)
Television broadcast stations: 1 (local programming station; in
addition, there are two repeaters that bring in Australian programs
by satellite) (1998)
Televisions: 1,500 (1995 est.)
Telephones: 13,618 (1993 est.)
Telephone system:
domestic: NA
international: satellite earth stations--2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 3
Radios: 15,460 (1995 est.)
Television broadcast stations: 1 (on Saipan and one station
planned for Rota; in addition, two cable stations on Saipan provide
varied programming from satellite networks) (1997)
Televisions: 15,460 (1995 est.)
Telephones: 2.39 million (1994 est.); 470,000 cellular telephone
subscribers (1994)
Telephone system: high-quality domestic and international
telephone, telegraph, and telex services
domestic: NA domestic satellite earth stations
international: 2 buried coaxial cable systems; 4 coaxial submarine
cables; satellite earth stations--NA Eutelsat, NA Intelsat (Atlantic
Ocean), and 1 Inmarsat (Atlantic and Indian Ocean regions);
note--Norway shares the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Iceland, and Sweden)
Radio broadcast stations: AM 46, FM 493 (350 private and 143
government), shortwave 0
Radios: 3.3 million (1993 est.)
Television broadcast stations: 209 (1997)
Televisions: 1.5 million (1993 est.)
Telephones: 150,000 (1994 est.)
Telephone system: modern system consisting of open wire,
microwave, and radiotelephone communication stations; limited
coaxial cable
domestic: open wire, microwave, radiotelephone communications, and a
domestic satellite system with 8 earth stations
international: satellite earth stations--2 Intelsat (Indian Ocean)
and 1 Arabsat
Radio broadcast stations: AM 2, FM 4, shortwave 1
Radios: 1.043 million (1992 est.)
Television broadcast stations: 13 (in addition, there are 25
low-power repeaters) (1997)
Televisions: 1.195 million (1992 est.)
Telephone system:
international: several submarine cables with network nodal points on
Guam and Hawaii
Telephones: 2.828 million (1998)
Telephone system: the domestic system is mediocre, but improving;
service is adequate for government and business use, in part because
major businesses have established their own private systems; since
1988, the government has promoted investment in the national
telecommunications system on a priority basis, significantly
increasing network capacity; despite major improvements in trunk and
urban systems, telecommunication services are still not readily
available to the majority of the rural population
domestic: microwave radio relay, coaxial cable, fiber-optic cable,
cellular, and satellite
international: satellite earth stations--3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean); 3 operational international gateway exchanges
(1 at Karachi and 2 at Islamabad); microwave radio relay to
neighboring countries
Radio broadcast stations: AM 26, FM 3, shortwave 18 (1998 est.)
Radios: 10.2 million (1998 est.)
Television broadcast stations: 22 (in addition, there are seven
low-power repeaters) (1997)
Televisions: 2.08 million (1998 est.)
Telephones: 1,500 (1988 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: 9,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 1,600 (1993 est.)
Telephones: 273,000 (1991 est.)
Telephone system: domestic and international facilities well
developed
domestic: NA
international: 1 coaxial submarine cable; satellite earth stations--2
Intelsat (Atlantic Ocean); connected to the Central American
Microwave System
Radio broadcast stations: AM 91, FM 0, shortwave 0
Radios: 564,000 (1992 est.)
Television broadcast stations: 9 (in addition, there are 17
repeaters) (1997)
Televisions: 420,000 (1992 est.)
Telephones: 130 (1983 est.)
Telephone system:
domestic: radiotelephone communications between islands
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 4,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 61,600 (1990 est.)
Telephone system: fair system but in serious need of expansion
and better maintenance; a cellular system has been introduced as a
stopgap but the communications problems will not be solved without
substantial investment in the conventional telephone infrastructure;
e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communications stations, cellular system for short
range traffic
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 0, shortwave 0
Radios: 2.13 million (1993 est.)
Television broadcast stations: 8 (in addition, there is one
low-power repeater) (1997)
Televisions: 220,000 (1993 est.)','e3076f231bdd093ee04c97c4925b22b6d48201e8ea33470987d5e9bf86c95a9b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bb1122435022c6711a615756b31b875e76941f9d4651b6cbb4151c901e1814e',1999,'KM','Comoros','communications',121,'Telephones: 4,000 (1993 est.)
Telephone system: sparse system of microwave radio relay and HF
radiotelephone communication stations
domestic: HF radiotelephone communications and microwave radio relay
international: HF radiotelephone communications to Madagascar and
Reunion
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: 81,000 (1994)
Television broadcast stations: 0 (1998)
Televisions: 200 (1994
Telephones: 34,000 (1991 est.)
Telephone system:
domestic: barely adequate wire and microwave radio relay service in
and between urban areas; domestic satellite system with 14 earth
stations
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 10, FM 4, shortwave 0
Radios: 3.87 million (1992 est.)
Television broadcast stations: 18 (1997)
Televisions: 55,000 (1992 est.)','15f4a4067fb45cc6a3be908f45c331ce32c6371c2bbf7f94403bfd1c4c0ea004','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a95cacfa3a52d9dfa18012fb437e7e5752553c6720f2fe0f725160f1af278984',1999,'ET','Ethiopia','communications',128,'Telephones: 18,000 (1983 est.)
Telephone system: services barely adequate for government use;
key exchanges are in Brazzaville, Pointe-Noire, and Loubomo;
inter-city lines frequently out-of-order
domestic: primary network consists of microwave radio relay and
coaxial cable
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 8,500 (1993 est.)
Telephones: 11,000 (1982 est.)
Telephone system: domestic system poor but improving; provides
only minimal service
domestic: network consists of microwave radio relay, open wire, and
radiotelephone communications stations; expansion of microwave radio
relay in progress
international: satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean)
Radio broadcast stations: AM 2, FM 2, shortwave 1
Radios: 430,000 (1992 est.)
Television broadcast stations: 1 (in addition, there are two
repeaters) (1997)
Televisions: 11,000 (1992 est.)','9418702871ad25fcdb624a536b9ef56bb9f980bb63a26df625cd72f32ea7fe98','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7590d73203e1b7e2ce50523e128b8f331b04d5ad90b9004c0a4852ce31e4ce6d',1999,'NZ','New Zealand','communications',138,'Telephones: 4,180 (1994)
Telephone system:
domestic: the individual islands are connected by a combination of
satellite earth stations, microwave systems, and VHF and HF
radiotelephone; within the islands, service is provided by small
exchanges connected to subscribers by open wire, cable, and
fiber-optic cable
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 1
Radios: 13,000 (1994 est.)
Television broadcast stations: 2 (in addition, eight low-power
repeaters provide good coverage on the island of Rarotonga) (1997)
Televisions: 3,500 (1995 est.)','869d2042ac9815e31f97f97610a1569f4aed148cef49527be485fed6fecfe376','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c9be406b37069d9d50fb4867eafb56b5b036366443bf8c823e73a78491f01c1',1999,'TT','Trinidad and Tobago','communications',148,'Telephones: 14,613 (1993 est.)
Telephone system:
domestic: fully automatic network
international: microwave radio relay and SHF radiotelephone links to
Martinique and Guadeloupe; VHF and UHF radiotelephone links to Saint
Lucia
Radio broadcast stations: AM 3, FM 2, shortwave 0
Radios: 45,000 (1993 est.)
Television broadcast stations: 0 (there is one cable television
company) (1997)
Televisions: 5,200 (1993 est.)
Telephones: 190,000 (1987 est.)
Telephone system:
domestic: relatively efficient system based on islandwide microwave
radio relay network
international: 1 coaxial submarine cable; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 120, FM 0, shortwave 6
Radios: NA
Television broadcast stations: 25 (1997)
Televisions: 728,000 (1993 est.)
Telephones: 586,300 (1994 est.)
Telephone system:
domestic: facilities generally inadequate and unreliable
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 272, FM 0, shortwave 39
Radios: NA
Television broadcast stations: 15 (including one station on the
Galapagos Islands) (1997)
Televisions: 940,000 (1992 est.)
Telephones: 6,189 (1983 est.)
Telephone system:
domestic: islandwide, fully automatic telephone system; VHF/UHF
radiotelephone from Saint Vincent to the other islands of the
Grenadines
international: VHF/UHF radiotelephone from Saint Vincent to
Barbados; new SHF radiotelephone to Grenada and to Saint Lucia;
access to Intelsat earth station in Martinique through Saint Lucia
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 76,000 (1992 est.)
Television broadcast stations: 1 (in addition, there are three
repeaters) (1997)
Televisions: 20,600 (1992 est.)
Telephones: 7,500 (1988 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 76,000 (1992 est.)
Television broadcast stations: 6 (1997)
Televisions: 6,000 (1992 est.)
Telephones: 15,000 (1995 est.)
Telephone system:
domestic: automatic telephone system completely integrated into
Italian system
international: microwave radio relay and cable connections to
Italian network; no satellite earth stations
Radio broadcast stations: AM 0, FM 0, shortwave 0
Radios: 15,000 (1994 est.)
Television broadcast stations: 1 (San Marino residents also
receive broadcasts from Italy) (1997)
Televisions: 9,000 (1994 est.)
Telephones: 2,200 (1986 est.)
Telephone system:
domestic: minimal system
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 2, shortwave 0
Radios: 33,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: NA
Telephones: 1.46 million (1993)
Telephone system: modern system
domestic: extensive microwave radio relay and coaxial and
fiber-optic cable systems
international: microwave radio relay to Bahrain, Jordan, Kuwait,
Qatar, UAE, Yemen, and Sudan; coaxial cable to Kuwait and Jordan;
submarine cable to Djibouti, Egypt and Bahrain; satellite earth
stations--5 Intelsat (3 Atlantic Ocean and 2 Indian Ocean), 1
Arabsat, and 1 Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 43, FM 13, shortwave 0
Radios: 5 million (1993 est.)
Television broadcast stations: 117 (1997)
Televisions: 4.5 million (1993 est.)
Telephones: 81,988 (1995 est.)
Telephone system:
domestic: above-average urban system; microwave radio relay, coaxial
cable and fiber-optic cable in trunk system
international: 4 submarine cables; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 6, shortwave 1
Radios: 850,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 61,000 (1993 est.)
Telephones: 700,000
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: 27 (public or state-owned 1, private 26)
Radios: 2.015 million
Television broadcast stations: more than 771 (consisting of 86
strong stations, 685 low-power stations, and 20 repeaters in the
principal networks; there are also numerous local or private
stations in Serbia and Vojvodina) (1997)
Televisions: 1 million','594082f7eac3880947cf55f7fb463b664a8fa07666cc43562add1843b0806e08','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49916fda72ad094ba937423439494e32be719433863c0cf7fdabfe6c3fadcbb8',1999,'MX','Mexico','communications',158,'Telephones: 3.168 million (1996); 70,000 digital cellular
telephone subscribers (1998); 7,400 analog cellular telephone
subscribers (1997)
Telephone system: large system by Third World standards but
inadequate for present requirements and undergoing extensive
upgrading
domestic: principal centers at Alexandria, Cairo, Al Mansurah,
Ismailia, Suez, and Tanta are connected by coaxial cable and
microwave radio relay
international: satellite earth stations--2 Intelsat (Atlantic Ocean
and Indian Ocean), 1 Arabsat, and 1 Inmarsat; 5 coaxial submarine
cables; tropospheric scatter to Sudan; microwave radio relay to
Israel; participant in Medarabtel
Radio broadcast stations: AM 57, FM 14, shortwave 3 (1998 est.)
Radios: 16.45 million (1998 est.)
Television broadcast stations: 42 (in addition, there are nine
channels received from Europe by satellite) (1997)
Televisions: 5 million (1998 est.)
Telephones: 350,000 (1997 est.)
Telephone system:
domestic: nationwide microwave radio relay system
international: satellite earth station--1 Intelsat (Atlantic Ocean);
connected to Central American Microwave System
Radio broadcast stations: AM 18, FM 80, shortwave 2
Radios: 1.5 million (1997 est.)
Television broadcast stations: 5 (1997)
Televisions: 700,000 (1997 est.)
Telephones: 2,000 (1987 est.)
Telephone system: poor system with adequate government services
domestic: NA
international: international communications from Bata and Malabo to
African and European countries; satellite earth station--1 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: 4,000 (1992 est.)
Telephones: NA
Telephone system:
domestic: very inadequate; about 4 telephones per 100 families, most
of which are in Asmara; government is seeking international tenders
to improve the system
international: NA
Radio broadcast stations: AM 2, FM 0, shortwave 1
Radios: NA
Television broadcast stations: 1 (government controlled) (1997)
Televisions: NA
Telephones: 531,000 (1997)
Telephone system: the Ministry of Transportation and
Communications (MOTC) administers Estonia''s telephone system;
Internet services available throughout most of the country; about
150,000 unfilled subscriber requests
domestic: local--cellular phones services are growing and expanding
to develop rural networks under direction of the MOTC;
intercity--Estonia has a highly developed fiber-optic backbone
(double loop) system presently serving at least 16 major cities
(1998)
international: foreign investment in the form of joint business
ventures greatly improved Estonia''s telephone service; fiber-optic
cables to Finland, Sweden, Latvia, and Russia provide worldwide
packet switched service
Radio broadcast stations: 27 commercial broadcast stations, 1
government broadcast station (1997); note--by law 51% of shows must
be produced within the EU; equal air time must be given to all
candidates during elections by public and private stations
Radios: 1.12 million (1997 est.)
Television broadcast stations: 7 (1997); note--Ministry of Culture
administers television licensing; mainly Estonian, European, and
Russian programming; by law 51% of shows must be produced within the
EU; equal air time must be given to all candidates during elections
by public and private stations
Televisions: 1.132 million (1997 est.)
Telephones: 100,000 (1983 est.)
Telephone system: open wire and microwave radio relay system
adequate for government use
domestic: open wire and microwave radio relay
international: open wire to Sudan and Djibouti; microwave radio
relay to Kenya and Djibouti; satellite earth stations--3 Intelsat (1
Atlantic Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 5, FM 0, shortwave 1
Radios: 9 million (1998 est.)
Television broadcast stations: 25 (1998)
Televisions: 150,000 (1998 est.)','c413e7d6bfb7fc223108841c0c29d9f7e46f00fc3c4b3dddc5372be202d1e2cc','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a54337989d40f2a1b080e0f6caf7dfb955204975f117bbb1f33ecb4e3e5a18d',1999,'MZ','Mozambique','communications',169,'Communications--note: 1 meteorological station
Telephones: 34,000 (1994)
Telephone system: system is above average for Africa
domestic: open-wire lines, coaxial cables, microwave radio relay,
and tropospheric scatter links
international: submarine cable to Bahrain; satellite earth
stations--1 Intelsat (Indian Ocean) and 1 Intersputnik (Atlantic
Ocean region)
Radio broadcast stations: AM 17, FM 3, shortwave 0
Radios: 2.74 million (1994 est.)
Television broadcast stations: 1 (in addition, there are 36
repeaters) (1997)
Televisions: 280,000 (1994 est.)
Telephones: 43,000 (1985 est.)
Telephone system:
domestic: fair system of open-wire lines, microwave radio relay
links, and radiotelephone communications stations
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 10, FM 17, shortwave 0
Radios: 1.011 million (1995)
Television broadcast stations: 0 (1997 est.)
Televisions: NA
Telephones: 2,550,957 (1992 est.)
Telephone system: international service good
domestic: good intercity service provided on Peninsular Malaysia
mainly by microwave radio relay; adequate intercity microwave radio
relay network between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong and Singapore;
satellite earth stations--2 Intelsat (1 Indian Ocean and 1 Pacific
Ocean)
Radio broadcast stations: AM 28, FM 3, shortwave 0
Radios: 8.08 million (1992 est.)
Television broadcast stations: 27 (of which 26 are
government-owned and one is independent and has 15 high-power
repeater stations to relay its programs) (1997)
Televisions: 2 million (1993 est.)
Telephones: 450
Telephone system: small system administered by French Department
of Posts and Telecommunications
domestic: NA
international: microwave radio relay and HF radiotelephone
communications to Comoros and other international connections
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 30,000 (1994 est.)
Television broadcast stations: 3 (1997)
Televisions: 3,500 (1994 est.)
Telephones: 11,890,868 (1993 est.)
Telephone system: highly developed system with extensive
microwave radio relay links; privatized in December 1990; opened to
competition January 1997
domestic: adequate telephone service for business and government,
but the population is poorly served; domestic satellite system with
120 earth stations; extensive microwave radio relay network
international: satellite earth stations--5 Intelsat (4 Atlantic Ocean
and 1 Pacific Ocean); launched Solidaridad I satellite in November
1993 and Solidaridad II in October 1994, giving Mexico improved
access to South America, Central America and much of the US as well
as enhancing domestic communications; linked to Central American
Microwave System of trunk connections
Radio broadcast stations: AM 824 (1999 est.), FM 500 (1998 est.),
shortwave 19 (1999 est.)
Radios: 22.5 million (1992 est.)
Television broadcast stations: 236 (not including repeaters)
(1997)
Televisions: 13.1 million (1992 est.)
Telephones: 960
Telephone system:
domestic: islands interconnected by shortwave radiotelephone (used
mostly for government purposes)
international: satellite earth stations--4 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 1, shortwave 1
Radios: 17,000 (1993 est.)
Television broadcast stations: 2 (1997)
Televisions: 1,290 (1993 est.)
Telephones: 600,000 (1998 est.)
Telephone system: the Ministry of Information, Computers, and
Telecommunications controls telecommunications; the carrier is
Modtelecom
domestic: local--Chisinau has a fiber-optic loop and one cellular GSM
provider; the waiting list for telephones is long; local service
outside Chisinau is poor; intercity--Moldova''s two fiber-optic
segments form a synchronous digital hierarchy ring through Romania''s
system; an analog backbone system runs from south to north in Moldova
international: two fiber-optic segments provide connectivity to
Romania; worldwide service can be available to Moldova through this
infrastructure; additional analog lines are to Russia; Intelsat,
Eutelsat, and Intersputnik earth stations
Radio broadcast stations: AM 4, FM 8, shortwave NA (1999)
Radios: NA
Television broadcast stations: 1 national station, 3 private
stations, 15 small local stations outside Chisinau (1998)
Televisions: 93 televisions/100 people (1996)
Telephones: 53,180 (1994 est.)
Telephone system: automatic telephone system
domestic: NA
international: no satellite earth stations; connected by cable into
the French communications system
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: 33,000 (1994 est.)
Television broadcast stations: 5 (1997)
Televisions: 24,000 (1994 est.)
Telephones: 93,600 (1998)
Telephone system:
domestic: NA
international: satellite earth station--1 Intersputnik (Indian Ocean
Region)
Radio broadcast stations: AM 12, FM 1, shortwave 0
Radios: 220,000
Television broadcast stations: 1 (in addition, there are 18
provincial repeaters) (1997)
Televisions: 120,000 (1993 est.)
UNOMSIL United Nations Mission of Observers
in Sierra Leone
UNOMUR United Nations Observer Mission
Uganda-Rwanda
UNOSOM II United Nations Operation in Somalia
II
UNPREDEP United Nations Preventive
Deployment Force
UNPROFOR United Nations Protection Force
UNRISD United Nations Research Institute
for Social Development
UNRWA United Nations Relief and Works
Agency for Palestine Refugees in
the Near East
UNSMIH United Nations Support Mission in','28a1380787d066de519ddd6e0c4281439d33109993b13a68bead0b13f73f90a3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b504fb15f78461b41e53efa656b5be2a40aceec9e8253cf907205542b5043e0f',1999,'AR','Argentina','communications',175,'Telephones: 1,180 (1991 est.)
Telephone system:
domestic: government-operated radiotelephone and private VHF/CB
radiotelephone networks provide effective service to almost all
points on both islands
international: satellite earth station--1 Intelsat (Atlantic Ocean)
with links through London to other countries
Radio broadcast stations: 1 (government operated)
Radios: 1,000 (1992 est.)
Television broadcast stations: 2 (operated by the British Forces
Broadcasting Service) (1997)
Televisions: NA
Telephones: 22,500 (3,500 cellular telephone subscribers) (1996)
Telephone system: good international communications; good
domestic facilities
domestic: digitalization was to hve been completed in 1998
international: satellite earth stations--1 Orion; 1 fiber-optic
submarine cable linking the Faroe Islands with Denmark and Iceland
Radio broadcast stations: AM 1, FM 1 (repeaters 13), shortwave 0
Radios: 11,800 (1996 est.)
Television broadcast stations: 3 (in addition, there are 29
low-power repeaters; satellite relays of MTV Europe, BBC World, and
Scansat TV3 Eurosport are also available) (1997)
Televisions: 11,600 (1996 est.)
Telephones: 60,017 (1987 est.)
Telephone system: modern local, interisland, and international
(wire/radio integrated) public and special-purpose telephone,
telegraph, and teleprinter facilities; regional radio communications
center
domestic: NA
international: access to important cable link between US and Canada
and NZ and Australia; satellite earth station--1 Intelsat (Pacific
Ocean)
Radio broadcast stations: AM 7, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 0
Televisions: 12,000 (1992 est.)
Telephones: 2.5 million (1995 est.)
Telephone system: modern system with excellent service
domestic: cable, microwave radio relay, and an extensive cellular
net care for domestic needs
international: 1 submarine cable; satellite earth stations--access to
Intelsat transmission service via a Swedish satellite earth station,
1 Inmarsat (Atlantic and Indian Ocean regions); note--Finland shares
the Inmarsat earth station with the other Nordic countries (Denmark,
Iceland, Norway, and Sweden)
Radio broadcast stations: AM 6, FM 105, shortwave 0
Radios: 4.98 million (1991 est.)
Television broadcast stations: 120 (in addition, there are 431
low-power repeaters) (1997)
Televisions: 1.92 million (1995 est.)
Telephones: 35 million (1987 est.)
Telephone system: highly developed
domestic: extensive cable and microwave radio relay; extensive
introduction of fiber-optic cable; domestic satellite system
international: satellite earth stations--2 Intelsat (with total of 5
antennas--2 for Indian Ocean and 3 for Atlantic Ocean), NA Eutelsat,
1 Inmarsat (Atlantic Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41, FM 800 (mostly repeaters),
shortwave 0
Radios: 49 million (1993 est.)
Television broadcast stations: 310 (in addition, there are about
1,400 repeaters) (1997)
Televisions: 29.3 million (1993 est.)
Telephones: 31,000 (1990 est.)
Telephone system:
domestic: fair open wire and microwave radio relay system
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 7, shortwave 0
Radios: 79,000 (1992 est.)
Television broadcast stations: 3 (in addition, there are eight
low-power repeaters) (1997)
Televisions: 22,000 (1992 est.)','b145fcbff85ea845226318469959033b3a5ab86d62b9d31a9bb460f93497410e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d91249766a4c9bb783c2309c7e187b7262b1e532652c58db5686fcaecf7750',1999,'NR','Nauru','communications',187,'Telephones: 33,200 (1983 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 5, FM 2, shortwave 0
Radios: 116,000 (1992 est.)
Television broadcast stations: 7 (in addition, there are 17
low-power repeaters) (1997)
Televisions: 35,000 (1992 est.)
Telephones: 22,000 (1991 est.)
Telephone system:
domestic: adequate system of cable, microwave radio relay,
tropospheric scatter, radiotelephone communication stations, and a
domestic satellite system with 12 earth stations
international: satellite earth stations--3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 6, FM 6, shortwave 0
Radios: 250,000 (1993 est.)
Television broadcast stations: 4 (in addition, there are five
low-power repeaters) (1997)
Televisions: 40,000 (1993 est.)
Telephones: 1,400 (1984 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
note: Kiribati is being linked to the Pacific Ocean Cooperative
Telecommunications Network, which should improve telephone service
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 15,000 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 0 (1988)
Telephones: 1.4 million (1998 est.)
Telephone system:
domestic: system is being expanded with installation of fiber-optic
cable nationwide; access traditionally reserved for official and
business subscribers; public access is expected to increase
international: satellite earth stations--1 Intelsat (Indian Ocean)
and 1 Intersputnik (Indian Ocean Region); other international
connections through Moscow and Beijing
Radio broadcast stations: AM 27, FM 14, shortwave 3
Radios: 4.7 million
Television broadcast stations: 38
Televisions: 2 million
Telephones: 16.6 million (1993)
Telephone system: excellent domestic and international services
domestic: NA
international: fiber-optic submarine cable to China; satellite earth
stations--3 Intelsat (2 Pacific Ocean and 1 Indian Ocean) and 1
Inmarsat (Pacific Ocean region)
Radio broadcast stations: AM 79, FM 46, shortwave 0
Radios: 42 million (1993 est.)
Television broadcast stations: 121 (in addition, there are 850
relay stations and eight-channel American Forces Korea Network)
(1997)
Televisions: 9.3 million (1992 est.)
Telephones: 408,000 (1998)
Telephone system: the civil network suffered some damage as a
result of the Gulf war, but most of the telephone exchanges were
left intact and, by the end of 1994, domestic and international
telecommunications had been restored to normal operation; the
quality of service is excellent
domestic: new telephone exchanges provide a large capacity for new
subscribers; trunk traffic is carried by microwave radio relay,
coaxial cable, open wire and fiber-optic cable; a cellular telephone
system operates throughout Kuwait (with approximately 150,000
subscribers in 1996) and the country is well supplied with pay
telephones; approximately 15,000 Internet subscribers in 1996
international: coaxial cable and microwave radio relay to Saudi
Arabia; satellite earth stations--3 Intelsat (1 Atlantic Ocean, 2
Indian Ocean), 1 Inmarsat (Atlantic Ocean), and 1 Arabsat
Radio broadcast stations: AM 3, FM 0, shortwave 0
Radios: 720,000 (1992 est.)
Television broadcast stations: 13 (in addition, there are several
satellite channels) (1997)
Televisions: 800,000 (1993 est.)
Telephones: 356,000 (1996 est.)
Telephone system: poorly developed; about 100,000 unsatisfied
applications for household telephones
domestic: principally microwave radio relay; one cellular provider,
probably only limited to Bishkek region
international: connections with other CIS countries by landline or
microwave radio relay and with other countries by leased connections
with Moscow international gateway switch and by satellite; satellite
earth stations--1 Intersputnik and 1 Intelsat; connected
internationally by the Trans-Asia-Europe Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA, shortwave NA; note--one
state-run radio broadcast station
Radios: 825,000 (radio receiver systems with multiple speakers
for program diffusion 748,000)
Television broadcast stations: NA (repeater stations throughout
the country relay programs from Russia, Uzbekistan, Kazakhstan, and
Turkey) (1997)
Televisions: 875,000
Telephones: 28,000 (1998 est.)
Telephone system: service to general public is poor but
improving, with over 28,000 telephones currently in service and an
additional 48,000 expected by 2001; the government relies on a
radiotelephone network to communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station--1 Intersputnik (Indian Ocean
Region)
Radio broadcast stations: AM 9, FM 5, shortwave 4 (1998)
Radios: 580,000 (1995)
Television broadcast stations: 4 (1997)
Televisions: 32,000 (1993 est.)
Telephones: 710,848 (1997)
Telephone system: Lattelekom is 51% state owned, plans to
privatize in 2000 to satisfy EU concerns; 50,000 people are on the
waiting list to receive telephone service; Internet service is
available throughout Latvia
domestic: local--two cellular service providers; NMT-450 and GSM
standards provide service nationwide; over 75% of population
covered; intercity--two synchronous digital hierarchy fiber-optic
rings form the national backbone; 11 digital switching centers, 3
service centers
international: Latvia has international fiber-optic connectivity to
Belarus, Estonia, Lithuania, and an undersea fiber-optic cable to','984e59780ee3cfb424c562536efaf8ba7be42d0089179616d82de3be1b18a20b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17954aefbeccb350a3631b8b761d5dea3d8141b21cad00dd8703349170bfb90a',1999,'SN','Senegal','communications',196,'Telephones: 11,000 (1991 est.)
Telephone system:
domestic: adequate network of microwave radio relay and open wire
international: microwave radio relay links to Senegal and
Guinea-Bissau; satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 2, FM 5, shortwave 0
Radios: 180,000 (1993 est.)
Television broadcast stations: 1 (government owned) (1997)
Televisions: NA
Telephones: NA; 3.1% of Palestinian households have telephones
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM 0, shortwave 0
Radios: NA; note--95% of Palestinian households have radios (1992
est.)
Television broadcast stations: 2 (operated by the Palestinian
Broadcasting Corp.) (1997)
Televisions: NA; note--59% of Palestinian households have
televisions (1992 est.)
Telephones: 760,000 (1996 est.)
Telephone system:
domestic: local--T''bilisi and K''ut''aisi have cellular telephone
networks with about 10,000 customers total; urban areas 20
telephones/100 people; rural areas 4 phones/100 people; intercity--a
fiber-optic line connects T''bilisi to K''ut''aisi (Georgia''s second
largest city); nationwide pager service
international: Georgia and Russia are working on a fiber-optic line
between P''ot''i and Sochi (Russia); present international service is
available by microwave, land line, and satellite through the Moscow
switch; international electronic mail and telex service available
Radio broadcast stations: AM NA, FM NA, shortwave NA; note 2
national broadcast stations, 3 regional broadcast stations
Radios: NA
Television broadcast stations: 3
Televisions: NA
Telephones: 44 million
Telephone system: Germany has one of the world''s most
technologically advanced telecommunications systems; as a result of
intensive capital expenditures since reunification, the formerly
backward system of the eastern part of the country has been
modernized and integrated with that of the western part
domestic: the region which was formerly West Germany is served by an
extensive system of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable, microwave radio
relay, and a domestic satellite system; cellular telephone service
is widely available and includes roaming service to many foreign
countries; since the reunification of Germany, the telephone system
of the eastern region has been upgraded and enjoys all of the
advantages of the national system
international: satellite earth stations--14 Intelsat (12 Atlantic
Ocean and 2 Indian Ocean), 1 Eutelsat, 1 Inmarsat (Atlantic Ocean
region), 2 Intersputnik (1 Atlantic Ocean region and 1 Indian Ocean
region); 7 submarine cable connections; 2 HF radiotelephone
communication centers; tropospheric scatter links
Radio broadcast stations: AM 77, FM 1,621, shortwave 37, digital
audio broadcasting 130
Radios: 47.1 million (1998 est.)
Television broadcast stations: 9,513 (including repeaters)
Televisions: 51.4 million (1998 est.)
Telephones: 100,000 (1997 est.)
Telephone system: poor to fair system
domestic: primarily microwave radio relay
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 23, shortwave 0 (1997)
Radios: 12.5 million (1997 est.)
Television broadcast stations: 7 (in addition, there are eight
repeaters) (1997)
Televisions: 1.9 million (1997 est.)
Telephones: 19,356 (1994)
Telephone system: adequate, automatic domestic system and
adequate international facilities
domestic: automatic exchange facilities
international: radiotelephone; microwave radio relay; satellite
earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0
Radios: NA
Television broadcast stations: 1 (in addition, there are 3
low-power repeaters) (1997)
Televisions: NA','f6a8d04d005db3b6d2e218ebf7d0dfcd115927dd08c52e495181750e68f0962a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa0845ebcf7bd85ce55a7910a7382f4e4830657e8e36c6e632c7f90b1b2b0deb',1999,'GR','Greece','communications',204,'Telephones: 5,571,293 (1993 est.)
Telephone system: adequate, modern networks reach all areas;
microwave radio relay carries most traffic; extensive open-wire
network; submarine cables to off-shore islands
domestic: microwave radio relay, open wire, and submarine cable
international: tropospheric scatter; 8 submarine cables; satellite
earth stations--2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean), 1
Eutelsat, and 1 Inmarsat (Indian Ocean region)
Radio broadcast stations: AM 29, FM 17 (repeaters 20), shortwave 0
Radios: NA
Television broadcast stations: 64 (in addition, there are about
1,000 low-power repeaters and two stations in the US armed forces
network) (1997)
Televisions: 2.3 million (1993 est.)
Telephones: 19,600 (1995 est.)
Telephone system: adequate domestic and international service
provided by cables and microwave radio relay; totally digitalized in
1995
domestic: microwave radio relay
international: 2 coaxial submarine cables; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: 1 publicly-owned station and some local
radio and TV stations
Radios: 23,000 (1991 est.)
Television broadcast stations: 1 publicly-owned station and some
local low-power stations; in addition, there are three AFRTS (US Air
Force) stations which broadcast in the NTSC system (1997)
Televisions: 12,000 (1991 est.)
Telephones: 5,650 (1988 est.)
Telephone system: automatic, islandwide telephone system
domestic: interisland VHF and UHF radiotelephone links
international: new SHF radiotelephone links to Trinidad and Tobago
and Saint Vincent; VHF and UHF radio links to Trinidad
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 80,000 (1993 est.)
Television broadcast stations: 2 (1997)
Televisions: 30,000 (1993 est.)
Telephones: 64,916 (1984 est.)
Telephone system: domestic facilities inadequate
domestic: NA
international: satellite earth station--1 Intelsat (Atlantic Ocean);
microwave radio relay to Antigua and Barbuda, Dominica, and','66e908947ff1dcc8d1b6049de18e3137456451f3cb2f9eb27a2807cdf42ffd72','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5991c3a6a955339b46a43366a7751434d470089f95d6c6ff4207c1b2e8db089c',1999,'MQ','Martinique','communications',209,'Radio broadcast stations: AM 2, FM 8 (private stations licensed
to broadcast FM 30), shortwave 0
Radios: 100,000 (1993 est.)
Television broadcast stations: 5 (in addition, there are several
low-power repeaters) (1997)
Televisions: 150,000 (1993 est.)
Telephones: 74,317 (March 1997)
Telephone system:
domestic: NA
international: satellite earth stations--2 Intelsat (Pacific Ocean);
submarine cables to US and Japan
Radio broadcast stations: AM 3, FM 3, shortwave 0
Radios: 206,000 (1994)
Television broadcast stations: 5 (1997)
Televisions: 97,000 (1994 est.)
Friendly Islands Tonga 20 00 S 175 00 W
Frisian Islands Denmark, 53 35 N 6 40 E
Germany,','4753b9d57402662c50583beaafea4458fe0ea0bfdb17229917327e23d9819af0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b7c716cec0267aa2b847e9596bf22b48889459fccabf6398bf988ac89514169',1999,'GT','Guatemala','communications',218,'domestic: NA
international: connected to Central American Microwave System;
satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 91, FM 0, shortwave 15
Radios: 400,000 (1993 est.)
Television broadcast stations: 6 (in addition, there are 17
repeaters) (1997)
Televisions: 475,000 (1993 est.)
Telephones: 41,850 (1983 est.)
Telephone system:
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Telephones: 18,000 (1994 est.)
Telephone system: poor to fair system of open-wire lines, small
radiotelephone communication stations, and new microwave radio relay
system
domestic: microwave radio relay and radiotelephone communication
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 1, shortwave 0
Radios: 257,000 (1992 est.)
Television broadcast stations: 6 (1997)
Televisions: 65,000 (1993 est.)
Telephones: 13,120 (1997 est.)
Telephone system: small system
domestic: combination of microwave radio relay, open-wire lines,
radiotelephone, and cellular communications
international: NA
Radio broadcast stations: AM 2, FM 3, shortwave 0
Radios: 40,000 (1994 est.)
Television broadcast stations: 2 (1997)
Televisions: NA
Telephones: 33,000 (1987 est.)
Telephone system: fair system for long-distance calling
domestic: microwave radio relay network for trunk lines
international: tropospheric scatter to Trinidad; satellite earth
station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave 1
Radios: 398,000 (1992 est.)
Television broadcast stations: 1 public station; two private
stations relay US satellite services (1997)
Televisions: 32,000 (1992 est.)
Telephones: 50,000 (1990 est.)
Telephone system: domestic facilities barely adequate;
international facilities slightly better
domestic: NA
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 33, FM 0, shortwave 2
Radios: 320,000 (1992 est.)
Television broadcast stations: 2 (in addition, there is a cable
TV station) (1997)
Televisions: 32,000 (1992 est.)
Telephones: 2,000
Telephone system: automatic exchange
domestic: tied into Italian system
international: uses Italian system
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 1 (1996)
Televisions: NA
Telephones: 105,000 (1992 est.)
Telephone system: inadequate system
domestic: NA
international: satellite earth stations--2 Intelsat (Atlantic Ocean);
connected to Central American Microwave System
Radio broadcast stations: AM 176, FM 0, shortwave 7
Radios: 2.115 million (1992 est.)
Television broadcast stations: 11 (in addition, there are 17
repeaters) (1997)
Televisions: 400,000 (1992 est.)
Telephones: 4.47 million (1998)
Telephone system: modern facilities provide excellent domestic
and international services
domestic: microwave radio relay links and extensive fiber-optic
network
international: satellite earth stations--3 Intelsat (1 Pacific Ocean
and 2 Indian Ocean); coaxial cable to Guangzhou, China; access to 5
international submarine cables providing connections to ASEAN member
nations, Japan, Taiwan, Australia, Middle East, and Western Europe
Radio broadcast stations: AM 6, FM 6, shortwave 0
Radios: 3 million (1992 est.)
Television broadcast stations: 4 (in addition, there are two
repeaters) (1997)
Televisions: 1.75 million (1992 est.)
Telephones: 2.16 million (267,000 cellular telephone subscribers)
(1996)
Telephone system: 14,213 telex lines; automatic telephone network
based on microwave radio relay system; the average waiting time for
telephones is expected to drop to one year by the end of 1997 (down
from over 10 years in the early 1990s); note--the former state-owned
telecommunications firm MATAV--now privatized and managed by a
US/German consortium--has ambitious plans to upgrade the inadequate
system, including a contract with the German firm Siemens and the
Swedish firm Ericsson to provide 600,000 new telephone lines
domestic: microwave radio relay
international: satellite earth stations--1 Intelsat and 1
Intersputnik (Atlantic Ocean region)
Radio broadcast stations: AM 32, FM 15, shortwave 0
Radios: 6 million (1993 est.)
Television broadcast stations: 39 (in addition, there are
low-power stations) (1997)
Televisions: 4.38 million (1993 est.)
Telephones: 143,600 (1993 est.)
Telephone system: adequate domestic service
domestic: the trunk network consists of coaxial and fiber-optic
cables and microwave radio relay links
international: satellite earth stations--2 Intelsat (Atlantic Ocean),
1 Inmarsat (Atlantic and Indian Ocean regions); note--Iceland shares
the Inmarsat earth station with the other Nordic countries (Denmark,
Finland, Norway, and Sweden)
Radio broadcast stations: AM 5, FM 147 (transmitters and
repeaters), shortwave 0
Radios: 91,500 licensed (1993 est.)
Television broadcast stations: 14 (in addition, there are 156
low-power repeaters) (1997)
Televisions: 96,100 (1993 est.)
Telephones: 12 million (1996)
Telephone system: mediocre; local and long distance service
provided throughout all regions of the country, with services
primarily concentrated in the urban areas; major objective is to
continue to expand and modernize long-distance network in order to
keep pace with rapidly growing number of local subscriber lines;
steady improvement is taking place with the recent admission of
private and private-public investors, but demand for communication
services is also growing rapidly
domestic: local service is provided by microwave radio relay and
coaxial cable, with open wire and obsolete electromechanical and
manual switchboard systems still in use in rural areas; starting in
the 1980s, a substantial amount of digital switch gear has been
introduced for local- and long-distance service; long-distance
traffic is carried mostly by coaxial cable and low-capacity
microwave radio relay; since 1985, however, significant trunk
capacity has been added in the form of fiber-optic cable and a
domestic satellite system with 254 earth stations; cellular
telephone service in four metropolitan cities
international: satellite earth stations--8 Intelsat (Indian Ocean)
and 1 Inmarsat (Indian Ocean Region); four gateway exchanges
operating from Mumbai, New Delhi, Calcutta, and Chennai; submarine
cables to Malaysia, UAE, Singapore, and Japan
Radio broadcast stations: AM 153, FM 91, shortwave 62 (1998 est.)
Radios: 111 million (1998 est.)
Television broadcast stations: 562 (82 stations have 1 kW or
greater power and 480 stations have less than 1 kW of power) (1997)
Televisions: 50 million (1999 est.)','632edfac3d3bfdc9401f61f77d63efdba30bc367b666a9c4e31933c673539526','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbd9cf8d4871e48e77f1eb497f179c6143a7f4240e14ac10a1c8c8bf5e5d7fdb',1999,'FR','France','communications',230,'Telephones: 61,447 (1983 est.)
Telephone system:
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM 1, FM 1, shortwave 0
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Telephone system: 13 outgoing and 10 incoming commercial lines;
adequate telecommunications
domestic: 60-channel submarine cable, 22 DSN circuits by satellite,
Autodin with standard remote terminal, digital telephone switch,
Military Affiliated Radio System (MARS station), UHF/VHF air-ground
radio, a link to the Pacific Consolidated Telecommunications Network
(PCTN) satellite
international: NA
Radio broadcast stations: AM NA, FM 5 channels; also 1 local
volunteer FM radio station;, shortwave NA;
Television broadcast stations: commercial satellite television
system, with 16 channels (1997)
Telephones: 279,736 (1997)
Telephone system: highly developed, completely automated and
efficient system, mainly buried cables
domestic: nationwide cellular telephone system; buried cable
international: 3 channels leased on TAT-6 coaxial submarine cable
(Europe to North America)
Radio broadcast stations: AM 0, FM 6, shortwave 0
Radios: 230,000 (1993 est.)
Television broadcast stations: 5 (1997)
Televisions: 100,500 (1993 est.)
Telephones: 209,672 (1994 est.)
Telephone system: domestic facilities are adequate
domestic: NA
international: microwave radio relay to Guadeloupe, Dominica, and
Saint Lucia; satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave 0
Radios: 74,000 (1992 est.)
Television broadcast stations: 11 (in addition, there are nine
repeaters) (1997)
Televisions: 65,000 (1993 est.)
Telephones: 17,000 (1991 est.)
Telephone system: poor system of cable and open-wire lines, minor
microwave radio relay links, and radiotelephone communications
stations (improvements being made)
domestic: mostly cable and open-wire lines; a recently completed
domestic satellite telecommunications system links Nouakchott with
regional capitals
international: satellite earth stations--1 Intelsat (Atlantic Ocean)
and 2 Arabsat
Radio broadcast stations: AM 1, FM 2, shortwave 1 (1998 est.)
Radios: 1 million (1998 est.)
Television broadcast stations: 1 (1997)
Televisions: 50,000 (1995 est.)
Telephones: 3,650 (1994 est.)
Telephone system:
domestic: NA
international: radiotelephone communication with most countries in
the world; 1 earth station in French domestic satellite system
Radio broadcast stations: AM 1, FM 3, shortwave 0
Radios: 3,000 (1992 est.)
Television broadcast stations: 0 (there are, however, two
repeaters which rebroadcast programs from France, Canada, and the
US) (1997)
Televisions: 2,000 (1992 est.)','9ca366697d9675cb397e22bd890f590bbc2eb13992f7b0877107f7722b48fa04','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ed870ff282b2fa86afca58733f8b4d7b827ae17f7230bb7601c70043b2f25aa',1999,'CN','China','communications',238,'Telephones: 425,000 (1998)
Telephone system:
domestic: microwave radio relay, coaxial and fiber-optic cable, and
cellular; Jordan has two cellular telephone providers (with
approximately 50,000 subscribers in 1998), ten data service
providers, and four Internet service providers (with approximately
8,000 subscribers in 1998)
international: satellite earth stations--3 Intelsat, 1 Arabsat, and
29 land and maritime Inmarsat terminals (1996); coaxial cable,
fiber-optic cable, and microwave radio relay to Iraq, Saudi Arabia,
Syria, and Israel; building a Red Sea Fiber-Optic Link Around the
Globe (FLAG) fiber-optic submarine cable link and planning to update
links with Saudi Arabia and Israel to fiber-optic cable; 4,000
international circuits (1998 est.); participant in Medarabtel
Radio broadcast stations: AM 6, FM 7, shortwave 1 (1998 est.)
Radios: 1.1 million (1992 est.)
Television broadcast stations: 8 (in addition, there are
approximately 42 repeaters and 1 TV receive-only satellite link)
(1997)
Televisions: 350,000 (1992 est.)
Telephones: 2 million (1997)
Telephone system: service is poor
domestic: landline and microwave radio relay; AMPS standard cellular
systems are available in most of Kazakhstan
international: international traffic with other former Soviet
republics and China carried by landline and microwave radio relay
and with other countries by satellite and through 8 international
telecommunications circuits at the Moscow international gateway
switch; satellite earth stations--1 Intelsat and a new digital
satellite earth station established at Almaty; a third satellite
earth station at Atyrau provides teleconnectivity to the AT&T
network via Intelsat; cable connected by the Trans-Asia-Europe
Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: 4.088 million (with multiple speakers for program
diffusion 6.082 million)
Television broadcast stations: 20 (of which at least eight are
government stations and at least 12 are private stations--seven of
those are satellite TV relay stations) (1997)
Televisions: 4.75 million
Telephones: 383,676 (1997); 3,077 cellular telephone subscribers
(1998)
Telephone system:
domestic: primarily microwave radio relay
international: satellite earth stations--4 Intelsat
Radio broadcast stations: AM 24, FM 7, shortwave 2
Radios: 5 million
Television broadcast stations: 8 (of which six are
government-controlled and two are commercial) (1997)
Televisions: 500,000','fdc8ba3c793fb53599e60acecd3a0c5434bfd1b6d660d2363af75bab881e7213','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6455cc7294ccaea33e8f16b8ebc7f9b6ddefef3262d9b26b002c54437df9f8c',1999,'SE','Sweden','communications',247,'Radio broadcast stations: AM NA, FM NA, shortwave NA; note--there
are 25 stations of unknown type; 75% of commercial broadcasts must
be in the Latvian language; remainder mostly in Russian and European
languages
Radios: 1.4 million (1993 est.)
Television broadcast stations: 30 (origin of TV broadcasts must
be 40% Latvian and 40% other European languages)
Televisions: NA; note--almost 100% of the population have TV
access, 16% have VCRs, and 20% have cable or satellite dishes (1995)
Telephones: 150,000 (1990 est.)
Telephone system: telecommunications system severely damaged by
civil war; rebuilding well underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean) (erratic operations); coaxial cable to Syria;
microwave radio relay to Syria but inoperable beyond Syria to
Jordan; 3 submarine coaxial cables
Radio broadcast stations: AM 5, FM 3, shortwave 1
note: government is licensing a limited number of the more than 100
AM and FM stations operated sporadically by various factions that
sprang up during the civil war
Radios: 2.37 million (1992 est.)
Television broadcast stations: 28 (1997)
Televisions: 1.1 million (1993 est.)
Telephones: 12,000 (1991 est.)
Telephone system: rudimentary system
domestic: consists of a few landlines, a small microwave radio relay
system, and a minor radiotelephone communication system
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave 0
Radios: 66,000
Television broadcast stations: NA
Televisions: 11,000 (1992 est.)
Telephones: fewer than 25,000 (1998 est.)
Telephone system: telephone and telegraph service via microwave
radio relay network; main center is Monrovia
domestic: NA
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 10, shortwave 0
note: two of the FM radio stations are limited to a small area
Radios: 675,000 (1995 est.); note--10,000 windup radios were
distributed in the country prior to the 1997 election
Television broadcast stations: 1 (in addition, there are four
low-power repeaters; the station is located in Monrovia) (1997)
Televisions: 56,000 (1995 est.)','9d9c2575b262cc34afe38714dd4a7e05562f1e8f9dd1961e44e88258ae9746bd','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d49f695348b08e241f2f9db78d0dc7605e78e77d93e842e2e91f3484f88b9a5d',1999,'EG','Egypt','communications',257,'Telephones: 411,000 (1999 est.)
Telephone system: telecommunications system is being modernized;
cellular telephone system became operational in 1996
domestic: microwave radio relay, coaxial cable, cellular,
tropospheric scatter, and a domestic satellite system with 14 earth
stations
international: satellite earth stations--4 Intelsat, NA Arabsat, and
NA Intersputnik; submarine cables to France and Italy; microwave
radio relay to Tunisia and Egypt; tropospheric scatter to Greece;
participant in Medarabtel
Radio broadcast stations: AM 17, FM 3, shortwave 3 (1998 est.)
Radios: 1 million (1998 est.)
Television broadcast stations: 12 (in addition, there is one
low-power repeater) (1997)
Televisions: 550,000 (1998 est.)
Telephones: 22,857 (1996 est.)
Telephone system: automatic telephone system
domestic: NA
international: linked to Swiss networks by cable and microwave radio
relay
Radio broadcast stations: 1 broadcast station in Triesen
note: linked to Swiss networks
Radios: 12,134 (1996)
Television broadcast stations: NA (linked to Swiss networks)
(1997)
Televisions: 11,785 (1996)
Telephones: 1.08 million (1998)
Telephone system: the Ministry of Communications and Informatics,
Ministry of Defense, and Ministry of Internal Affairs oversee
Lithuania''s telecommunications; the national operator is Lietuvos
Telomas; Internet is available
domestic: local--three cellular service providers; NMT-450 and GSM
standards provide services nationwide; 80% of customers are on the
two GSM networks; 157,000 cellular customers; intercity--Lithuania is
close to completing its fiber-optic backbone consisting of two small
rings inside a larger ring
international: Lithuania has international fiber-optic connectivity
to Latvia, Poland, and an undersea fiber-optic cable to Sweden
Radio broadcast stations: AM 13, FM 26, shortwave 1
Radios: 1.42 million (1993 est.)
Television broadcast stations: 3
Televisions: NA; note--93% of the population have TV, 30% have
cable or satellite dish, and 16% own VCRs (1996)','3b5cf36d76d047954b1d1a588f783bc06c0e9b64afdd9eb073cde20a63c32819','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a55fa068d390fd0b48359393f51f11aac64cd29b5cbb6fc1992bcd5fdb6439eb',1999,'HK','Hong Kong','communications',267,'Telephones: 200,000 (1997 est.)
Telephone system: fairly modern communication facilities
maintained for domestic and international services
domestic: NA
international: HF radiotelephone communication facility; access to
international communications carriers provided via Hong Kong and
China; satellite earth station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 4, FM 3, shortwave 0
Radios: 135,000 (1992 est.)
Television broadcast stations: 0 (receives Hong Kong broadcasts)
(1997)
Televisions: 34,000 (1992 est.)
Telephones: 125,000
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 6, FM 2, shortwave 0
Radios: 350,000 (1992 est.)
Television broadcast stations: 136 (of which 22 are main stations
and 114 are low-power stations) (1997)
Televisions: 327,011 (1992 est.)','6ebb9caa7a4713b1c309cd01ee1a294eda549dd20bf87cb176641b2dd409deb5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34ac5bf8446a7852b8d4d54864dffc44f535e811eaebaf96a9f04c3e25fb72f9',1999,'TH','Thailand','communications',274,'Telephones: 8,523 (1992 est.)
Telephone system: minimal domestic and international facilities
domestic: inter-atoll communication primarily through HF
transceivers and VHF/UHF telephones
international: satellite earth station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 2, FM 1, shortwave 0
Radios: 28,284 (1992 est.)
Television broadcast stations: 1 (1997)
Televisions: 7,309 (1992 est.)','80c7f2b3e734d2c9602dc097167d8d0087723a73d11413280a81620076354446','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b63822ceae167de23b899b8407a81a56efbdde697d69aac330a6c4eaf53e362f',1999,'MT','Malta','communications',283,'Telephones: 191,876 (1992 est.)
Telephone system: automatic system satisfies normal requirements
domestic: submarine cable and microwave radio relay between islands
international: 2 submarine cables; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 4, shortwave 0
Radios: 189,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: 300,000 (1996 est.)
Telephones: 46,000 (1996)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 0 (receives broadcasts from the
UK) (1997)
Televisions: 24,450 (1996)
Telephones: 2,000 (1997 est.)
Telephone system: telex services
domestic: Majuro Atoll and Ebeye and Kwajalein islands have regular,
seven-digit, direct-dial telephones; other islands interconnected by
shortwave radiotelephone (used mostly for government purposes)
international: satellite earth stations--2 Intelsat (Pacific Ocean);
US Government satellite communications system on Kwajalein
Radio broadcast stations: AM 1, FM 2, shortwave 1
Radios: NA
Television broadcast stations: 3 (of which one is an independent
station and two are US military stations) (1997)
Televisions: NA','10d461d4f91cc51f5ebf3b18c9f426d5433df8a3ef06a281e01d0a18973b9fe0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d391fec7c07d341554303eeffe146cbfd5c0d1fefeacf2b67f648bbd05bebc',1999,'MG','Madagascar','communications',295,'Telephones: 107,000 (1993)
Telephone system: small system with good service
domestic: primarily microwave radio relay
international: satellite earth station--1 Intelsat (Indian Ocean);
new microwave link to Reunion; HF radiotelephone links to several
countries
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 399,000 (1993 est.)
Television broadcast stations: 2 (in addition, there are 11
repeaters) (1997)
Televisions: 242,000 (1993 est.)
Telephones: 219,000 (1995)
Telephone system: adequate system; principal center is Saint-Denis
domestic: modern open wire and microwave radio relay network
international: radiotelephone communication to Comoros, France,
Madagascar; new microwave route to Mauritius; satellite earth
station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 3, FM 13, shortwave 0
Radios: 158,000 (1994)
Television broadcast stations: 22 (in addition, there are 18
low-power repeaters) (1997)
Televisions: 116,181 (1992 est.)
Telephones: 2.6 million (1993 est.)
Telephone system:
domestic: poor service; 89% of telephone network is automatic; trunk
network is microwave radio relay; roughly 3,300 villages with no
service (February 1990 est.)
international: satellite earth station--1 Intelsat; new digital
international direct-dial exchanges are in Bucharest (1993 est.)
Radio broadcast stations: AM 12, FM 5, shortwave 0
note: in 1995, 135 local radio stations were registered
Radios: 4.64 million (1992 est.)
Television broadcast stations: 130 (in addition, there are about
400 low-power repeaters) (1997)
Televisions: 4.58 million (1992 est.)
Telephones: 23.8 million (1997 est.)
Telephone system: the telephone system has undergone significant
changes in the 1990''s; there are more than 1,000 companies licensed
to offer communication services; access to digital lines has
improved, particularly in urban centers; Internet and e-mail
services are improving; Russia has made progress toward building the
telecommunications infrastructure necessary for a market economy
domestic: cross country digital trunk lines run from St. Petersburg
to Khabarovsk, and from Moscow to Novorossiysk; the telephone
systems in 60 regional capitals have modern digital infrastructures;
cellular services, both analog and digital, are available in many
areas; in rural areas, the telephone services are still outdated,
inadequate, and low density
international: Russia is connected internationally by three undersea
fiber-optic cables; digital switches in several cities provide more
than 50,000 lines for international calls; satellite earth stations
provide access to Intelsat, Intersputnik, Eutelsat, Inmarsat, and
Orbita
Radio broadcast stations: AM NA, FM NA, shortwave NA; note--there
are about 1,050 (including AM, FM, and shortwave) radio broadcast
stations throughout the country
Radios: 50 million (1993 est.) (74.3 million radio receivers with
multiple speaker systems for program diffusion)
Television broadcast stations: 11,000 (1996 est.)
Televisions: 54.85 million (1992 est.)
Telephones: 6,400 (1983 est.)
Telephone system: telephone system primarily serves business and
Communications--note: important meteorological station
Telephones: 560,000 (1996 est.); 3,185 cellular telephone
subscribers (1998 est.)
Telephone system: the system is above the African average and is
continuing to be upgraded; key centers are Sfax, Sousse, Bizerte,
and Tunis; Internet access is available through two private service
providers licensed by the government
domestic: trunk facilities consist of open-wire lines, coaxial
cable, and microwave radio relay
international: 5 submarine cables; satellite earth stations--1
Intelsat (Atlantic Ocean) and 1 Arabsat with back-up control
station; coaxial cable and microwave radio relay to Algeria and
Libya; participant in Medarabtel
Radio broadcast stations: AM 7, FM 8, shortwave 1 (1998 est.)
Radios: 1.7 million (1998 est.)
Television broadcast stations: 19 (these are network stations;
there are some additional stations of low power) (1997)
Televisions: 650,000 (1998 est.)
Telephones: 17 million (in addition, there are 1.5 million
cellular telephone subscribers) (1997 est.)
Telephone system: fair domestic and international systems;
undergoing modernization and refurbishment programs
domestic: cable; AMPS standard cellular system in Ashkhabad with
plans for expansion
international: 12 satellite earth stations--Intelsat (Atlantic
Ocean), Eutelsat, and Inmarsat (Indian and Atlantic Ocean regions);
3 submarine fiber-optic cables (1996); connected internationally by
the Trans-Asia-Europe Fiber-Optic Line that became operational in
1998
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: there are 36 national broadcast stations, 108 regional
broadcast stations, and 1,058 local broadcast stations (1996)
Radios: 9.4 million (1992 est.)
Television broadcast stations: 69 (in addition, there are 476
low-power repeaters) (1997)
Televisions: 10.53 million (1993 est.)
Telephones: NA
Telephone system: poorly developed
domestic: NA
international: linked by cable and microwave radio relay to other
CIS republics and to other countries by leased connections to the
Moscow international gateway switch; a new telephone link from
Ashgabat to Iran has been established; a new exchange in Ashgabat
switches international traffic through Turkey via Intelsat;
satellite earth stations--1 Orbita and 1 Intelsat
Radio broadcast stations: 1 state-owned radio broadcast station
of NA type
Radios: NA
Television broadcast stations: 3 (much programming relayed from
Russia and Turkey) (1997)
Televisions: NA','2d537d414c18855728f66c22df4e679f1904952b716ab6670c7febea84321438','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee27894896c0148ea3a4ed5f0c66a395646bcf8ebb235de59103b4aadba8384',1999,'HN','Honduras','communications',304,'Telephones: 14,000 (1995 est.)
Telephone system: small system of wire, radiotelephone
communications, and microwave radio relay links concentrated in
southwestern area
domestic: wire, radiotelephone communications, and microwave radio
relay; domestic satellite system with 3 earth stations and 1 planned
international: satellite earth stations--2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean)
Radio broadcast stations: AM 15, FM 6, shortwave 0
Radios: 620,000 (1995 est.)
Television broadcast stations: 10 (in addition, there are seven
low-power repeaters) (1997)
Televisions: 105,000 (1995 est.)
Telephones: 405,100 (1995 est.)
Telephone system: average system limited by poor maintenance;
major expansion in progress
domestic: intercity traffic is carried by coaxial cable, microwave
radio relay, cellular network, and a domestic communications
satellite system with 20 earth stations
international: satellite earth stations--3 Intelsat (2 Atlantic Ocean
and 1 Indian Ocean); 1 coaxial submarine cable
Radio broadcast stations: AM 82, FM 32, shortwave 10 (1998 est.)
Radios: 17.2 million (1998 est.)
Television broadcast stations: 1 (government-controlled)
Televisions: 6.1 million (1998 est.)','8cf2638efdd9c793a90a751622e1663992276b326750a6e19ceff5fa8641ae90','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d618c868a73b2d0c03ed246d601cfa5476d045cc686bb0b56929199dbd3274ad',1999,'TO','Tonga','communications',311,'Telephones: 276 (1992 est.)
Telephone system:
domestic: single-line telephone system connects all villages on
island
international: NA
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1987 est.)
Radios: 1,000
Television broadcast stations: 1 (1997)
Televisions: 312 (1991 est.)','9bbd59862146d09c13d30ecc34344b017409682fb819de46eda83e10d7c82d33','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ebbef10eae130095109745bdeaa0b1f7c069ed2daab0cf2ae07ac6d865aa87',1999,'BR','Brazil','communications',319,'Telephones: 88,730 (1985 est.)
Telephone system: meager telephone service; principal switching
center is Asuncion
domestic: fair microwave radio relay network
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 40, FM 0, shortwave 7
Radios: 775,000 (1992 est.)
Television broadcast stations: 10 (1997)
Televisions: 370,000 (1992 est.)
Telephones: 779,306 (1990 est.)
Telephone system: adequate for most requirements
domestic: nationwide microwave radio relay system and a domestic
satellite system with 12 earth stations
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 273, FM 0, shortwave 144
Radios: 5.7 million (1992 est.)
Television broadcast stations: 13 (in addition, there are 112
repeaters) (1997)
Televisions: 2 million (1993 est.)
Telephones: 1.9 million (1997)
Telephone system: good international radiotelephone and submarine
cable services; domestic and interisland service adequate
domestic: domestic satellite system with 11 earth stations
international: submarine cables to Hong Kong, Guam, Singapore,
Taiwan, and Japan; satellite earth stations--3 Intelsat (1 Indian
Ocean and 2 Pacific Ocean)
Radio broadcast stations: AM 261, FM 55, shortwave 0
Radios: 9.03 million (1992 est.)
Television broadcast stations: 37 (includes six stations of the
US Armed Forces Radio and TV Service) (1997)
Televisions: 9.2 million (1998)
Telephones: 24
Telephone system: party line telephone service on the island
domestic: NA
international: radiotelephone
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 0 (1997)
Televisions: NA
Telephones: 8.2 million (1996)
Telephone system: underdeveloped and outmoded system; government
aims to have 10 million telephones in service by 2000; the process
of partial privatization of the state-owned telephone monopoly has
begun
domestic: cable, open wire, and microwave radio relay; 3 cellular
networks
international: satellite earth stations--2 Intelsat, NA Eutelsat, 2
Inmarsat (Atlantic and Indian Ocean regions), and 1 Intersputnik
(Atlantic Ocean region)
Radio broadcast stations: AM 27, FM 75, shortwave 1 (1994 est.)
Radios: 9.9 million registered (1996)
Television broadcast stations: 150 (1997)
Televisions: 9.4 million registered (1996)
Telephones: 3.7 million (1996 est.)
Telephone system:
domestic: generally adequate integrated network of coaxial cables,
open wire, microwave radio relay, and domestic satellite earth
stations
international: 6 submarine cables; satellite earth stations--3
Intelsat (2 Atlantic Ocean and 1 Indian Ocean), NA Eutelsat;
tropospheric scatter to Azores; note--an earth station for Inmarsat
(Atlantic Ocean region) is planned
Radio broadcast stations: AM 57, FM 66 (repeaters 22), shortwave 0
Radios: 2.2 million (1993 est.)
Television broadcast stations: 36 (in addition, there are 62
repeaters) (1997)
Televisions: 2,970,892 (1993 est.)
Telephones: 1.389 million (1996 est.)
Telephone system: modern system, integrated with that of the US
by high-capacity submarine cable and Intelsat with high-speed data
capability
domestic: digital telephone system with about 1 million lines (1990
est.); cellular telephone service
international: satellite earth station--1 Intelsat; submarine cable
to US
Radio broadcast stations: AM 50, FM 63, shortwave 0
note: there were 118 radio stations in 1995
Radios: 2.6 million (1994 est.)
Television broadcast stations: 18 (in addition, there are three
stations of the US Armed Forces Radio and Television Service) (1997)
Televisions: 973,000 (1994 est.)','c6917b91b268dbd90d7127b87d199021eb9bc4a2081c53648e5585784eb4867a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6a04fd7fc28a031dfe7497e3e195849d09b5c9f8c7c2843644a9a473ae2bf7c',1999,'SC','Seychelles','communications',327,'Telephones: 13,000 (1995 est.)
Telephone system:
domestic: radiotelephone communications between islands in the
archipelago
international: direct radiotelephone communications with adjacent
island countries and African coastal countries; satellite earth
station--1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave 0
Radios: 50,000 (1996 est.)
Television broadcast stations: 2 (in addition, there are 9
repeaters) (1997)
Televisions: 12,000 (1996 est.)
Telephones: 17,526 (1991 est.)
Telephone system: marginal telephone and telegraph service
domestic: national microwave radio relay system made unserviceable
by military activities
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave NA
Radios: 980,000 (1992 est.)
Television broadcast stations: 2 (1997)
Televisions: 45,000 (1992 est.)','9f0c882c69057324995011dc4ec8b8ae588e9a1c4588ea04c8df7b32b96d2383','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e31204199ac9b269933b6caccdc1088c47c00b41604dfdee9807be74f1fe088c',1999,'ID','Indonesia','communications',335,'Telephones: 1.4 million (1997 est.)
Telephone system: good domestic facilities; good international
service
domestic: NA
international: submarine cables to Malaysia (Sabah and Peninsular
Malaysia), Indonesia, and the Philippines; satellite earth
stations--2 Intelsat (1 Indian Ocean and 1 Pacific Ocean), and 1
Inmarsat (Pacific Ocean region)
Radio broadcast stations: AM 13, FM 4, shortwave 0
Radios: NA
Television broadcast stations: 4 (1997)
Televisions: 1.05 million (1992 est.)
Telephones: 1,362,178 (1992 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA; note--there
are 22 private broadcast stations and two public (state) broadcast
stations
Radios: 915,000 (1995 est.)
Television broadcast stations: 41 (1997)
Televisions: 1.2 million (1995 est.)
Telephones: 691,240 (1997 est.)
Telephone system:
domestic: 70% digital; full digitalization scheduled by 2000
international: NA
Radio broadcast stations: AM 6, FM 5, shortwave 0
note: there are more than 20 regional and local radio broadcast
stations
Radios: 596,100 (1993 est.)
Television broadcast stations: 23 (consisting of 20 network
stations and three private stations; there are also about 400
low-power repeaters) (1997)
Televisions: 454,400 (1993 est.)
Telephones: 5,000 (1991 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 4, FM 0, shortwave 0
Radios: 38,000 (1993 est.)
Television broadcast stations: 0 (1997)
Televisions: 2,000 (1992 est.)
Telephones: 9,000 (1991 est.)
Telephone system: the public telecommunications system was
completely destroyed or dismantled by the civil war factions; all
relief organizations depend on their own private systems
domestic: recently, local cellular telephone systems have been
established in Mogadishu and in several other population centers
international: international connections are available from
Mogadishu by satellite
Radio broadcast stations: AM NA, FM NA, shortwave 5
Radios: 300,000
Television broadcast stations: 1 (1997)
Televisions: 118,000 (1993 est.)
Telephones: 4.2 million (1997)
Telephone system: the system is the best developed, most modern,
and has the highest capacity in Africa
domestic: consists of carrier-equipped open-wire lines, coaxial
cables, microwave radio relay links, fiber-optic cable, and
radiotelephone communication stations; key centers are Bloemfontein,
Cape Town, Durban, Johannesburg, Port Elizabeth, and Pretoria
international: 1 submarine cable; satellite earth stations--3
Intelsat (1 Indian Ocean and 2 Atlantic Ocean)
Radio broadcast stations: AM 15, FM 164, shortwave 1
Radios: 7.5 million (1999 est.)
Television broadcast stations: 556 (includes 156 network stations
and 400 privately-owned low-power stations; in addition, there are
144 network repeaters) (1997)
Televisions: 7.5 million
Telephone system:
domestic: NA
international: coastal radiotelephone station at Grytviken
Ecuador EC EC ECU 218 EC
Egypt EG EG EGY 818 EG
El Salvador ES SV SLV 222 SV
Equatorial EK GQ GNQ 226 GQ','1a04188df582f107eac52f831048d2807397e460d0d0a88a26f7b2a8cfc5ec6a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7018f0e1c736c600984b423d59b885a318ef133df3f7d35e71a603c0e3829f4b',1999,'GI','Gibraltar','communications',343,'Telephones: 12.6 million (1990 est.)
Telephone system: generally adequate, modern facilities
domestic: NA
international: 22 coaxial submarine cables; satellite earth
stations--2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean), NA
Eutelsat, NA Inmarsat, and NA Marecs; tropospheric scatter to
adjacent countries
Radio broadcast stations: AM 190, FM 406 (repeaters 134),
shortwave 0
Radios: 12 million (1992 est.)
Television broadcast stations: 542 (382 network stations, 160
low-power stations, and one US Air Force Europe station) (1997)
Televisions: 15.7 million (1992 est.)','fd326967920efbb1297b2e261c0f364886675c0d07aed27fac6e7f05970aa472','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09c4c329b2bd01d164760243fbea452f3c77c069c6c013fb9116fd6e06aa0053',1999,'IN','India','communications',357,'Telephones: 352,681 (1997 est.); 114,888 cellular telephone
subscribers (1997 est.)
Telephone system: very inadequate domestic service, but expanding
with the entry of two wireless loop operators and privatization of
national telephone company; good international service
domestic: NA
international: submarine cables to Indonesia and Djibouti; satellite
earth stations--2 Intelsat (Indian Ocean)
Radio broadcast stations: AM 12, FM 5, shortwave 0
Radios: 3.6 million (1996 est.)
Television broadcast stations: 21 (19 network stations, two
low-power stations) (1997)
Televisions: 1.6 million (1996 est.)
Telephones: 77,215 (1983 est.)
Telephone system: large, well-equipped system by African
standards, but barely adequate and poorly maintained by modern
standards
domestic: consists of microwave radio relay, cable, radiotelephone
communications, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations--1 Intelsat (Atlantic Ocean)
and 1 Arabsat
Radio broadcast stations: AM 11, FM 1, shortwave 1 (1998 est.)
Radios: 5.75 million (1998 est.)
Television broadcast stations: 3 (1997)
Televisions: 250,000 (1998 est.)
Telephones: 43,522 (1992 est.)
Telephone system: international facilities good
domestic: microwave radio relay network
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 32, shortwave 1
Radios: 290,256 (1993 est.)
Television broadcast stations: 3 (in addition, there are seven
repeaters) (1997)
Televisions: 59,598 (1993 est.)
Telephones: NA
Telephone system:
domestic: local telephone service
international: satellite earth station--1 of NA type (for
communication with Norwegian mainland only)
Radio broadcast stations: AM 1, FM 1 (repeaters 2), shortwave 0
note: there are five meteorological/radio stations
Radios: NA
Television broadcast stations: NA
Televisions: NA
Telephones: NA; 45,000 cellular telephone subscribers (1993 est.)
Telephone system:
domestic: system consists of carrier-equipped, open-wire lines and
low-capacity, microwave radio relay
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 7, FM 6, shortwave 0
Radios: 200,000 (1998 est.)
Television broadcast stations: 2 (in addition, there are seven
repeaters) (1997)
Televisions: 20,000 (1998 est.)
Telephones: 13 million (1996 est.)
Telephone system: excellent domestic and international
facilities; automatic system
domestic: coaxial and multiconductor cable carry most voice traffic;
parallel microwave radio relay network carries some additional
telephone channels
international: 5 submarine coaxial cables; satellite earth
stations--1 Intelsat (Atlantic Ocean), 1 Eutelsat, and 1 Inmarsat
(Atlantic and Indian Ocean regions); note--Sweden shares the Inmarsat
earth station with the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations: AM 5, FM 360 (mostly repeaters),
shortwave 0
Radios: 7.272 million (1993 est.)
Television broadcast stations: 163 (1997)
Televisions: 3.5 million
Telephones: 5.24 million (1996 est.); 307,000 cellular telephone
subscribers (1994 est.)
Telephone system: excellent domestic and international services
domestic: extensive cable and microwave radio relay networks
international: satellite earth stations--2 Intelsat (Atlantic Ocean
and Indian Ocean)
Radio broadcast stations: AM 7, FM 50, shortwave 1 (1997)
Radios: 2.8 million (1996)
Television broadcast stations: 108 (1997)
Televisions: 2.647 million licenses (1996)
Telephones: 541,465 (1992 est.)
Telephone system: fair system currently undergoing significant
improvement and digital upgrades, including fiber-optic technology
domestic: coaxial cable and microwave radio relay network
international: satellite earth stations--1 Intelsat (Indian Ocean)
and 1 Intersputnik (Atlantic Ocean region); 1 submarine cable;
coaxial cable and microwave radio relay to Iraq, Jordan, Lebanon,
and Turkey; participant in Medarabtel
Radio broadcast stations: AM 9, FM 1, shortwave 0
Radios: 3.392 million (1992 est.)
Television broadcast stations: 54 (of which 36 are low-power
stations and repeaters) (1997)
Televisions: 700,000 (1993 est.)
Telephones: 11.526 million (1998 est.)
Telephone system:
domestic: extensive microwave radio relay trunk system on east and
west coasts
international: satellite earth stations--2 Intelsat (1 Pacific Ocean
and 1 Indian Ocean); submarine cables to Japan (Okinawa),
Philippines, Guam, Singapore, Hong Kong, Indonesia, Australia,
Middle East, and Western Europe
Radio broadcast stations: AM 158, FM 48, shortwave 21
Radios: 8.62 million
Television broadcast stations: 29 (in addition, there are two
repeaters) (1997)
Televisions: 10.8 million (1996 est.)
Telephones: 303,000 (1991 est.)
Telephone system: poorly developed and not well maintained; many
towns are not reached by the national network
domestic: cable and microwave radio relay
international: linked by cable and microwave radio relay to other
CIS republics, and by leased connections to the Moscow international
gateway switch; Dushanbe linked by Intelsat to international gateway
switch in Ankara (Turkey); satellite earth stations--1 Orbita and 2
Intelsat
Radio broadcast stations: 1 state-owned radio broadcast station
of NA type
Radios: NA
Television broadcast stations: 0 (there are, however, repeaters
that relay programs from Russia, Iran, and Turkey) (1997)
Televisions: NA
Telephones: 88,000 (1994)
Telephone system: fair system operating below capacity
domestic: open wire, microwave radio relay, tropospheric scatter
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 4, shortwave 0
Radios: 740,000 (1994 est.)
Television broadcast stations: 4 (1998)
Televisions: 60,000 (1994 est.)
Telephones: 1,553,200 (1994 est.)
Telephone system: service to general public adequate, but
investments in technological upgrades reduced by recession; bulk of
service to government activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel cable; domestic
satellite system being developed
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean)
Radio broadcast stations: AM 200 (in government-controlled
network), FM 100 (in government-controlled network), shortwave 0
Radios: 10.75 million (1992 est.)
Television broadcast stations: 5 (all in Bangkok; in addition,
there are 131 repeaters) (1997)
Televisions: 3.3 million (1993 est.)
Telephones: 47,000 (10,000 cellular telephone subscribers) (1998
est.)
Telephone system: fair system based on network of microwave radio
relay routes supplemented by open-wire lines and cellular system
domestic: microwave radio relay and open-wire lines for conventional
system; cellular system has capacity of 10,000 telephones
international: satellite earth stations--1 Intelsat (Atlantic Ocean)
and 1 Symphonie
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 795,000 (1992 est.)
Television broadcast stations: 3 (in addition, there are two
repeaters) (1997)
Televisions: 24,000 (1992 est.)
Telephones: NA
Telephone system:
domestic: radiotelephone service between islands
international: radiotelephone service to Western Samoa;
government-regulated telephone service (TeleTok), with three
satellite earth stations, established in 1997
Radio broadcast stations: AM NA, FM NA, shortwave NA
note: each atoll has a radio broadcast station of NA type that
broadcasts shipping and weather reports
Radios: 1,000 (1993 est.)
Television broadcast stations: NA (1997)
Televisions: NA
Telephones: 6,000 (1994 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: 66,000 (1993 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1994 est.)
Telephones: 170,000 (1992 est.)
Telephone system: excellent international service; good local
service
domestic: NA
international: satellite earth station--1 Intelsat (Atlantic Ocean);
tropospheric scatter to Barbados and Guyana
Radio broadcast stations: AM 1, FM 10, shortwave 0
Radios: 700,000 (1993 est.)
Television broadcast stations: 4 (1997)
Televisions: 400,000 (1992 est.)','5f96fac6d23e3ee0154f3d026c6771ff80142d5ae0e6d23c54bb16a29210c3f6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf4079c640154ffa191becc5e5d80f84b7739482739707fb3d82a0bb63333f97',1999,'TM','Turkmenistan','communications',367,'Telephones: 1,359 (1988 est.)
Telephone system: fair cable and radiotelephone services
domestic: NA
international: 2 submarine cables; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave 0
Radios: 7,000 (1992 est.)
Television broadcast stations: 0 (broadcasts from The Bahamas are
received; cable television is established) (1997)
Televisions: NA','0a98626165c0239e25def2f19526fd7d7e779d258c0d5d0996a3febd306ae878','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1f10a3ae88ce7d4a4db98f60f03dbe855fd130dc46d388e9adc1ee25a4b611f',1999,'TC','Turks and Caicos Islands','communications',372,'Telephones: 29.5 million (1987 est.)
Telephone system: technologically advanced domestic and
international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: 40 coaxial submarine cables; satellite earth
stations--10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1
Inmarsat (Atlantic Ocean region), and 1 Eutelsat; at least 8 large
international switching centers
Radio broadcast stations: AM 225, FM 525 (mostly repeaters),
shortwave 0
Radios: 70 million
Television broadcast stations: 78 (in addition, there are 869
repeaters) (1997)
Televisions: 20 million','6d745d7e10a0bf8e03e5b979d876636cdc3ab1f15973d0e2e6aa4d2e550c0c7e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1e586b82baba7dffc3a691129969b6cb207a17e14757988e3eae90e8abc9e15',1999,'ES','Spain','communications',380,'Telephones: 767,333 (1997)
Telephone system: some modern facilities
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network
international: satellite earth stations--2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 72, FM 0, shortwave 28
Radios: 1.89 million (1992 est.)
Television broadcast stations: 26 (in addition, there are ten
low-power repeaters for the Montevideo station) (1997)
Televisions: 1,131,065 (1996)
Telephones: 1.475 million (1998 est.)
Telephone system: poorly developed; ambitiously engaged in
telecommunications modernization
domestic: in 1998 there were six cellular networks operating in
Uzbekistan; 4 GSM, 1 D-AMPS, 1 AMPS standard
international: linked by landline or microwave radio relay with CIS
member states and to other countries by leased connection via the
Moscow international gateway switch; new Intelsat links to Tokyo
(Japan) and Ankara (Turkey) give Uzbekistan international access
independent of Russian facilities; satellite earth stations--NA
Orbita and NA Intelsat; Trans-Asia-Europe Fiber-Optic Line
Radio broadcast stations: AM NA, FM NA, shortwave NA; note--there
are 12 radio broadcast stations including one state-owned broadcast
station of NA type and four independent stations
Radios: 29,016,870
Television broadcast stations: 4 (in addition, there are two
repeater stations that relay Russian ORT programs and Kazakh,
Kyrgyz, and Tadzhik programs) (1997)
Televisions: 24,497,850
Telephones: 4,000 (1994 est.)
Telephone system:
domestic: NA
international: satellite earth station--1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: 49,000 (1994 est.)
Television broadcast stations: 1 (1997)
Televisions: 2,000 (1994 est.)','4ac9aac433961f69b73b56c5d40e8ce43bd748721ccbe8466bec9ab1dd5af2aa','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8acc5ce4ece1033e39ab8815e7e9545a65c240584a2470c34699f45c777a55e2',1999,'NC','New Caledonia','communications',394,'Telephones: 1.44 million (1987 est.)
Telephone system: modern and expanding
domestic: domestic satellite system with 3 earth stations
international: 3 submarine coaxial cables; satellite earth station--1
Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 181, FM 0, shortwave 26
Radios: 9.04 million (1992 est.)
Television broadcast stations: 66 (in addition, there are 45
repeaters) (1997)
Televisions: 3.3 million (1992 est.)
Telephones: 800,000 (1995 est.)
Telephone system: while Vietnam''s telecommunication sector lags
far behind other countries in Southeast Asia, Hanoi has made
considerable progress since 1991 in upgrading the system; Vietnam
has digitized all provincial switch boards, while fiber-optic and
microwave transmission systems have been extended from Hanoi, Da
Nang, and Ho Chi Minh City to all provinces; the density of
telephone receivers nationwide doubled from 1993 to 1995, but is
still far behind other countries in the region; Vietnam''s
telecommunications strategy aims to increase telephone density to 30
per 1,000 inhabitants by the year 2000 and authorities estimate that
approximately $2.7 billion will be spent on telecommunications
upgrades through the end of the decade
domestic: NA
international: satellite earth stations--2 Intersputnik (Indian Ocean
region)
Radio broadcast stations: AM NA, FM 228, shortwave 0
Radios: 7.215 million (1992 est.)
Television broadcast stations: NA
Televisions: 2.9 million (1992 est.)
Telephones: 60,000 (1990 est.)
Telephone system:
domestic: modern, uses fiber-optic cable and microwave radio relay
international: submarine cable and satellite communications;
satellite earth stations--NA
Radio broadcast stations: AM 4, FM 8, shortwave 0 (1988)
Radios: 105,000 (1994 est.)
Television broadcast stations: 2 (1997)
Televisions: 66,000 (1994 est.)
Telephone system: satellite communications; 1 DSN circuit off the
Overseas Telephone System (OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA, shortwave NA
note: Armed Forces Radio/Television Service (AFRTS) radio service
provided by satellite
Television broadcast stations: 0 (1997)
Telephones: 340 (1985 est.)
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA
Television broadcast stations: 2 (1997)
Televisions: NA
Telephones: NA; 3.1% of Palestinian households have telephones
Telephone system:
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian company PALTEL are
responsible for communication services in the West Bank
Radio broadcast stations: AM 1, FM 0, shortwave 0
Radios: NA; note--82% of Palestinian households have radios (1992
est.)
Television broadcast stations: NA
Televisions: NA; note--54% of Palestinian households have
televisions (1992 est.)
Telephones: 2,000
Telephone system: sparse and limited system
domestic: NA
international: tied into Morocco''s system by microwave radio relay,
tropospheric scatter, and satellite; satellite earth stations--2
Intelsat (Atlantic Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0, shortwave 0
Radios: NA
Television broadcast stations: NA
Televisions: NA
Telephones: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Telephones: 131,655 (1992 est.)
Telephone system: since unification in 1990, efforts have been
made to create a national telecommunications network
domestic: the network consists of microwave radio relay, cable, and
tropospheric scatter
international: satellite earth stations--3 Intelsat (2 Indian Ocean
and 1 Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2
Arabsat; microwave radio relay to Saudi Arabia and Djibouti
Radio broadcast stations: AM 4, FM 1, shortwave 0
Radios: 325,000 (1993 est.)
Television broadcast stations: 7 (in addition, there are several
low-power repeaters) (1997)
Televisions: 100,000 (1993 est.)
Telephones: 80,900 (1987 est.)
Telephone system: facilities are among the best in Sub-Saharan
Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities
international: satellite earth stations--2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcast stations: AM 11, FM 5, shortwave 0
Radios: 1,889,140
Television broadcast stations: 9 (1997)
Televisions: 215,000 (1995 est.)
Telephones: 301,000 (1990 est.)
Telephone system: system was once one of the best in Africa, but
now suffers from poor maintenance
domestic: consists of microwave radio relay links, open-wire lines,
and radiotelephone communication stations
international: satellite earth station--1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 18, shortwave 0
Radios: 890,000 (1992 est.)
Television broadcast stations: 16 (1997)
Televisions: 280,000 (1992 est.)
CBSS Council of the Baltic Sea States
CCC Customs Cooperation Council
CDB Caribbean Development Bank
CE Council of Europe
CEAO Communaute Economique de l''Afrique
de l''Ouest; see West African
Economic Community (CEAO)
CEEAC Communaute Economique des Etats de
l''Afrique Centrale; see Economic
Community of Central African States
(CEEAC)
CEI Central European Initiative
CEMA Council for Mutual Economic
Assistance; also known as CMEA or
Comecon
CEPGL Communaute Economique des Pays des
Grands Lacs; see Economic Community
of the Great Lakes Countries
(CEPGL)
CERN Conseil Europeen pour la Recherche
Nucleaire; see European
Organization for Nuclear Research
(CERN)
CG Contadora Group
c.i.f. cost, insurance, and freight
CIS Commonwealth of Independent States
CITES see Endangered Species
Climate Change United Nations Framework Convention
on Climate Change
Climate Change- Kyoto Protocol to the United
Kyoto Protocol Nations Framework Convention on
Climate Change
CMEA Council for Mutual Economic
Assistance (CEMA); also known as
Comecon
COCOM Coordinating Committee on Export
Controls
Comecon Council for Mutual Economic
Assistance (CEMA); also known as
CMEA
Comsat Communications Satellite
Corporation
CP Colombo Plan
CSCE Conference on Security and
Cooperation in Europe; see
Organization on Security and
Cooperation in Europe (OSCE)
CY calendar year
D DC developed country
Desertification United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in
Africa
DSN Defense Switched Network
DWT deadweight ton
E EADB East African Development Bank
EAPC Euro-Atlantic Partnership Council
EBRD European Bank for Reconstruction
and Development
EC European Community; see European
Union (EU)
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and
the Far East; see Economic and
Social Commission for Asia and the
Pacific (ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin
America; see Economic Commission
for Latin America and the Caribbean
(ECLAC)
ECLAC Economic Commission for Latin
America and the Caribbean
ECO Economic Cooperation Organization
ECOSOC Economic and Social Council
ECOWAS Economic Community of West African
States
ECSC European Coal and Steel Community;
see European Union (EU)
ECWA Economic Commission for Western
Asia; see Economic and Social
Commission for Western Asia (ESCWA)
EEC European Economic Community; see
European Union (EU)
EFTA European Free Trade Association
EIB European Investment Bank
EMU European Monetary Union
Endangered Convention on the International
Species Trade in Endangered Species of Wild
Flora and Fauna (CITES)
Entente Council of the Entente
Environmental Convention on the Prohibition of
Modification Military or Any Other Hostile Use
of Environmental Modification
Techniques
ESA European Space Agency
ESCAP Economic and Social Commission for
Asia and the Pacific
ESCWA Economic and Social Commission for
Western Asia
est. estimate
EU European Union
Euratom European Atomic Energy Community;
see European Community (EC)
Eutelsat European Telecommunications
Satellite Organization
Ex-Im Export-Import Bank of the United
States
F FAO Food and Agriculture Organization
FAX facsimile
f.o.b. free on board
FLS Front Line States
FRG Federal Republic of Germany (West
Germany); used for information
dated before 3 October 1990 or CY91
FSU former Soviet Union
FY fiscal year (FY93/94, for example,
began in calendar year 1993 and
ended in calendar year 1994)
FYROM The Former Yugoslav Republic of
Macedonia
FZ Franc Zone
G G-2 Group of 2
G-3 Group of 3
G-5 Group of 5
G-6 Group of 6 (not to be confused with
the Big Six)
G-7 Group of 7
G-8 Group of 8
G-9 Group of 9
G-10 Group of 10
G-11 Group of 11
G-15 Group of 15
G-19 Group of 19
G-24 Group of 24
G-30 Group of 30
G-33 Group of 33
G-77 Group of 77
GATT General Agreement on Tariffs and
Trade; subsumed by the World Trade
Organization (WTrO) on 1 January
1995
GCC Gulf Cooperation Council
GDP gross domestic product
GDR German Democratic Republic (East
Germany); used for information
dated before 3 October 1990 or CY91
GNP gross national product
GRT gross register ton
GWP gross world product
H Hazardous Wastes Basel Convention on the Control of
Transboundary Movements of
Hazardous Wastes and Their Disposal
HF high-frequency
I IADB Inter-American Development Bank
IAEA International Atomic Energy Agency
IBEC International Bank for Economic
Cooperation
IBRD International Bank for
Reconstruction and Development
(World Bank)
ICAO International Civil Aviation
Organization
ICC International Chamber of Commerce
ICEM Intergovernmental Committee for
European Migration; see
International Organization for
Migration (IOM)
ICFTU International Confederation of Free
Trade Unions; see World
Confederation of Labor (WCL)
ICJ International Court of Justice
ICM Intergovernmental Committee for
Migration; see International
Organization for Migration (IOM)
ICRC International Committee of the Red
Cross
ICRM International Red Cross and Red
Crescent Movement
IDA International Development
Association
IDB Islamic Development Bank
IEA International Energy Agency
IFAD International Fund for Agricultural
Development
IFC International Finance Corporation
IFCTU International Federation of
Christian Trade Unions
IFRCS International Federation of Red
Cross and Red Crescent Societies
IGAD Inter-Governmental Authority on
Development
IGADD Inter-Governmental Authority on
Drought and Development
IHO International Hydrographic
Organization
IIB International Investment Bank
ILO International Labor Organization
IMCO Intergovernmental Maritime
Consultative Organization; see
International Maritime Organization
(IMO)
IMF International Monetary Fund
IMO International Maritime Organization
Inmarsat International Mobile Satellite
Organization
InOC Indian Ocean Commission
Intelsat International Telecommunications
Satellite Organization
Interpol International Criminal Police
Organization
Intersputnik International Organization of Space
IOC International Olympic Committee
IOM International Organization for
Migration
ISO International Organization for
Standardization
ITU International Telecommunication
Union
K kHz kilohertz
km kilometer
kW kilowatt
kWh kilowatt hour
L LAES Latin American Economic System
LAIA Latin American Integration
Association
LAS League of Arab States; see Arab
League (AL)
Law of the Sea United Nations Convention on the
Law of the Sea (LOS)
LDC less developed country
LLDC least developed country
London see Marine Dumping
Convention
LORCS League of Red Cross and Red
Crescent Societies; see
International Federation of Red
Cross and Red Crescent Societies
(IFRCS)
LOS see Law of the Sea
M m meter
Marecs Maritime European Communications
Satellite
Marine Dumping Convention on the Prevention of
Marine Pollution by Dumping Wastes
and Other Matter
Marine Life Convention on Fishing and
Conservation Conservation of Living Resources of
the High Seas
MARPOL see Ship Pollution
Medarabtel Middle East Telecommunications
Project of the International
Telecommunications Union
Mercosur Mercado Comun del Cono Sur; see
Southern Cone Common Market
MHz megahertz
MINURSO United Nations Mission for the
Referendum in Western Sahara
MINUGUA United Nations Verification Mission
in Guatemala
MIPONUH United Nations Civilian Police
Mission in Haiti
MONUA United Nations Observer Mission in','6addd5f23ad51aa9cf45f03c5f613de1638be3a2e0fee88b4acb935472530d9f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7c9dbf54ba0f8c4d26440c5dd85e5c9a1020622cd29fbaa782cdcaa93273d98',1999,'AO','Angola','communications',398,'MTCR Missile Technology Control Regime
N NA not available
NACC North Atlantic Cooperation Council;
see Euro-Atlantic Partnership
Council (EAPC)
NAM Nonaligned Movement
NATO North Atlantic Treaty Organization
NC Nordic Council
NEA Nuclear Energy Agency
NEGL negligible
NIB Nordic Investment Bank
NIC newly industrializing country; see
newly industrializing economy (NIE)
NIE newly industrializing economy
nm nautical mile
NMT Nordic Mobile Telephone
NSG Nuclear Suppliers Group
Nuclear Test Ban Treaty Banning Nuclear Weapons
Tests in the Atmosphere, in Outer
Space, and Under Water
NZ New Zealand
O OAPEC Organization of Arab Petroleum
Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
ODA official development assistance
OECD Organization for Economic
Cooperation and Development
OECS Organization of Eastern Caribbean
States
OIC Organization of the Islamic
Conference
ONUMOZ see United Nations Operation in
Mozambique (UNOMOZ)
ONUSAL United Nations Observer Mission in','19b1e9958db02680653138a9b7a92b66189016e3d6e173bae334ce63dc61cc0c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12463c0c6e174b9c3e912f8a6001221228fe4bc4083b1fddd64a0274f5e333fd',1999,'SV','El Salvador','communications',399,'OOF other official flows
OPANAL Organismo para la Proscripcion de
las Armas Nucleares en la America
Latina y el Caribe; see Agency for
the Prohibition of Nuclear Weapons
in Latin America and the Caribbean
OPCW Organization for the Prohibition of
Chemical Weapons
OPEC Organization of Petroleum Exporting
Countries
OSCE Organization on Security and
Cooperation in Europe Ozone Layer
Protection Montreal Protocol on
Substances That Deplete the Ozone
Layer
P PCA Permanent Court of Arbitration
PDRY People''s Democratic Republic of
Yemen [Yemen (Aden) or South
Yemen]; used for information dated
before 22 May 1990 or CY91
PFP Partnership for Peace
R Ramsar see Wetlands
RG Rio Group
S SAARC South Asian Association for
Regional Cooperation
SACU Southern African Customs Union
SADC Southern African Development
Community
SADCC Southern African Development
Coordination Conference; see
Southern African Development
Community (SADC)
SELA Sistema Economico Latinoamericana;
see Latin American Economic System
(LAES)
SFRY Socialist Federal Republic of
Yugoslavia; dissolved 5 December
1991
SHF super-high-frequency
Ship Pollution Protocol of 1978 Relating to the
International Convention for the
Prevention of Pollution From Ships,
1973 (MARPOL)
Sparteca South Pacific Regional Trade and
Economic Cooperation Agreement
SPC South Pacific Commission
SPF South Pacific Forum
sq km square kilometer
sq mi square mile
T TAT Trans-Atlantic Telephone
Tropical Timber International Tropical Timber
83 Agreement, 1983
Tropical Timber International Tropical Timber
94 Agreement, 1994
U UAE United Arab Emirates
UDEAC Union Douaniere et Economique de
l''Afrique Centrale; see Central
African Customs and Economic Union
(UDEAC)
UEMOA Union economique et monetaire Ouest
africaine; see West African
Economic and Monetary Union (WAEMU)
UHF ultra-high-frequency
UK United Kingdom
UN United Nations
UNAMIR United Nations Assistance Mission
for Rwanda
UNAVEM III United Nations Angola Verification
Mission III
UNCRO United Nations Confidence
Restoration Operation in Croatia
UNCTAD United Nations Conference on Trade
and Development
UNDOF United Nations Disengagement
Observer Force
UNDP United Nations Development Program
UNEP United Nations Environment Program
UNESCO United Nations Educational,
Scientific, and Cultural
Organization
UNFICYP United Nations Peace-keeping Force
in Cyprus
UNFPA United Nations Fund for Population
Activities; see UN Population Fund
(UNFPA)
UNHCR United Nations High Commissioner
for Refugees
UNICEF United Nations Children''s Fund
UNIDO United Nations Industrial
Development Organization
UNIFIL United Nations Interim Force in','a9340b0bc7fbccf6e579a320f854c8484b3d194f9fd991f9bae9af4b204bf1f6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfdbd43265f3c4dd861307b0e1fd0a86c8a00f4878f79452c5c18f7bf7304a5e',1999,'LB','Lebanon','communications',400,'UNIKOM United Nations Iraq-Kuwait
Observation Mission
UNITAR United Nations Institute for
Training and Research
UNMIH United Nations Mission in Haiti
UNMIBH United Nations Mission in Bosnia
and Herzegovina
UNMOGIP United Nations Military Observer
Group in India and Pakistan
UNMOP United Nations Mission of Observers
in Prevlaka
UNMOT United Nations Mission of Observers
in Tajikistan
UNOMIG United Nations Observer Mission in','964c2515eabb863bc106ef324643827ec1f3206180ac7dbd1441ea7b9672da79','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36dbd440adc32dd35fab42fc8a386df2297cda8e2a8139c1046e83478f4c28db',1999,'HT','Haiti','communications',401,'UNTAC United Nations Transitional
Authority in Cambodia
UNTAES United Nations Transitional
Administration in Eastern Slavonia,
Baranja, and Western Sirmium
UNTSO United Nations Truce Supervision
Organization
UNU United Nations University
UPU Universal Postal Union
US United States
USSR Union of Soviet Socialist Republics
(Soviet Union); used for
information dated before 25
December 1991
USSR/EE Union of Soviet Socialist
Republics/Eastern Europe
V VHF very-high-frequency
W WADB West African Development Bank
WAEMU West African Economic and Monetary
Union
WCL World Confederation of Labor
WCO World Customs Organization; see
Customs Cooperation Council
Wetlands Convention on Wetlands of
International Importance Especially
As Waterfowl Habitat
WEU Western European Union
WFC World Food Council
WFP World Food Program
WFTU World Federation of Trade Unions
Whaling International Convention for the
Regulation of Whaling
WHO World Health Organization
WIPO World Intellectual Property
Organization
WMO World Meteorological Organization
WP Warsaw Pact
WTO see WToO for World Tourism
Organization or WTrO for World
Trade Organization
WToO World Tourism Organization
WTrO World Trade Organization
Y YAR Yemen Arab Republic [Yemen (Sanaa)
or North Yemen]; used for
information dated before 22 May
1990 or CY91
Z ZC Zangger Committee
=====================================================================
Appendix B: United Nations System
Transcriber''s note: this appeared to be an empty appendix,
possibly under development. It does not appear in later
editions of the Factbook.
=====================================================================
Appendix D: Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature--1 December 1959
entered into force--23 June 1961
objective--to ensure that Antarctica is used for peaceful purposes, such
as, for international cooperation in scientific research, and that it
does not become the scene or object of international discord
parties--(43) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria,
Canada, Chile, China, Colombia, Cuba, Czech Republic, Denmark, Ecuador,
Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy,
Japan, North Korea, South Korea, Netherlands, NZ, Norway, Papua New
Guinea, Peru, Poland, Romania, Russia, Slovakia, South Africa, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
note--abbreviated as Hazardous Wastes
opened for signature--22 March 1989
entered into force--5 May 1992
objective--to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and
toxicity of wastes generated and ensure their environmentally sound
management as closely as possible to the source of generation; and to
assist LDCs in environmentally sound management of the hazardous and
other wastes they generate
parties--(123) Antigua and Barbuda, Argentina, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burundi, Canada, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Ecuador, Egypt, El Salvador, Estonia, EU, Finland, France, The Gambia,
Germany, Greece, Guatemala, Guinea, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea,
Kuwait, Kyrgyzstan, Latvia, Lebanon, Liechtenstein, Luxembourg, The
Former Yugoslav Republic of Macedonia, Malawi, Malaysia, Maldives,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified--(3) Afghanistan,
Haiti, US
Biodiversity
see Convention on Biological Diversity
Convention on Biological Diversity
note--abbreviated as Biodiversity
opened for signature--5 June 1992
entered into force--29 December 1993
objective--to develop national strategies for the conservation and
sustainable use of biological diversity
parties--(175) Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified--(12) Afghanistan,
Azerbaijan, Kuwait, Liberia, Libya, Malta, Sao Tome and Principe,
Thailand, Tuvalu, UAE, US, former Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on
Climate Change
Convention on Fishing and Conservation of Living Resources of the High
Seas
note--abbreviated as Marine Life Conservation
opened for signature--29 April 1958
entered into force--20 March 1966
objective--to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that because of the development of modern technology some
of these resources are in danger of being overexploited
parties--(37) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso,
Cambodia, Colombia, Denmark, Dominican Republic, Fiji, Finland, France,
Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra
Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand,
Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela, former
Yugoslavia
countries that have signed, but not yet ratified--(21) Afghanistan,
Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland,
Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ,
Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution
note--abbreviated as Air Pollution
opened for signature--13 November 1979
entered into force--16 March 1983
objective--to protect the human environment against air pollution and to
gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties--(44) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic,
Denmark, EU, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK, US, former Yugoslavia
countries that have signed, but not yet ratified--(2) Holy See, San
Marino
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
note--abbreviated as Endangered Species
opened for signature--3 March 1973
entered into force--1 July 1975
objective--to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties--(137) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bangladesh, Barbados, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Guyana, Honduras, Hungary, India, Indonesia, Iran, Israel,
Italy, Japan, Jordan, Kenya, Kiribati, South Korea, Latvia, Liberia,
Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Zambia, Zimbabwe
countries that have signed, but not yet ratified--(3) Ireland, Kuwait,','9b7a2b58c461a7e8163aec87927400fd5248025f72cb16d409e5720505e387ae','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b0c5fb134c89f3ebf2be473446619e58ac49a9a39d2d0b229bf68fd3604a151',1999,'LS','Lesotho','communications',402,'Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention)
note--abbreviated as Marine Dumping
opened for signature--29 December 1972
entered into force--30 August 1975
objective--to control pollution of the sea by dumping and to encourage
regional agreements supplementary to the Convention
parties--(75) Afghanistan, Antigua and Barbuda, Argentina, Australia,
Barbados, Belarus, Belgium, Belize, Bosnia and Herzegovina, Brazil,
Canada, Cape Verde, Chile, China, Democratic Republic of the Congo,
Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Denmark, Dominican Republic,
Egypt, Finland, France, Gabon, Germany, Greece, Guatemala, Haiti,
Honduras, Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan,
Jordan, Kenya, Kiribati, Libya, Luxembourg, Malta, Mexico, Monaco,
Morocco, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Panama, Papua
New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia,
Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname,
Sweden, Switzerland, Tonga, Tunisia, Tuvalu, Ukraine, UAE, UK, US,
former Yugoslavia
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
note--abbreviated as Environmental Modification
opened for signature--10 December 1976
entered into force--5 October 1978
objective--to prohibit the military or other hostile use of
environmental modification techniques in order to further world peace
and trust among nations
parties--(64) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece,
Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea, South
Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ,
Niger, Norway, Pakistan, Papua New Guinea, Poland, Romania, Russia,
Saint Lucia, Sao Tome and Principe, Slovakia, Solomon Islands, Spain,
Sri Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK, US, Uruguay,
Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified--(17) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran,
Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal,
Sierra Leone, Syria, Turkey, Uganda
Convention on Wetlands of International Importance Especially as
Waterfowl Habitat (Ramsar)
note--abbreviated as Wetlands
opened for signature--2 February 1971
entered into force--21 December 1975
objective--to stem the progressive encroachment on and loss of wetlands
now and in the future, recognizing the fundamental ecological functions
of wetlands and their economic, cultural, scientific, and recreational
value
parties--(101) Albania, Algeria, Argentina, Armenia, Australia, Austria,
The Bahamas, Bahrain, Bangladesh, Belgium, Brazil, Bulgaria, Burkina
Faso, Canada, Chad, Chile, China, Democratic Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Czech Republic, Denmark, Ecuador,
Egypt, Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany,
Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Latvia, Liechtenstein, Lithuania, Malawi, Mali,
Malta, Mauritania, Mexico, Monaco, Mongolia, Morocco, Namibia,
Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Senegal, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname,
Sweden, Switzerland, Togo, Trinidad and Tobago, Tunisia, Turkey, UK,
US, Uruguay, Venezuela, Vietnam, former Yugoslavia, Zambia
Desertification
see United Nations Convention to Combat Desertification in those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note--abbreviated as Whaling
opened for signature--2 December 1946
entered into force--10 November 1948
objective--to protect all species of whales from overhunting; to
establish a system of international regulation for the whale fisheries
to ensure proper conservation and development of whale stocks; and to
safeguard for future generations the great natural resources
represented by whale stocks
parties--(51) Antigua and Barbuda, Argentina, Australia, Austria,
Belize, Brazil, Canada, Chile, China, Costa Rica, Denmark, Dominica,
Ecuador, Egypt, Finland, France, Germany, Grenada, Iceland, India,
Ireland, Italy, Jamaica, Japan, Kenya, South Korea, Mauritius, Mexico,
Monaco, Netherlands, NZ, Norway, Oman, Panama, Peru, Philippines,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Senegal, Seychelles, Solomon Islands, South Africa, Spain,
Sweden, Switzerland, UK, US, Uruguay, Venezuela
International Tropical Timber Agreement, 1983
note--abbreviated as Tropical Timber 83
opened for signature--18 November 1983
entered into force--1 April 1985; this agreement expired when the
International Tropical Timber Agreement, 1994, went into force
objective--to provide an effective framework for cooperation between
tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties--(54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras,
India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New
Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden,
Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement, 1994
note--abbreviated as Tropical Timber 94
opened for signature--26 January 1994
entered into force--1 January 1997
objective--to ensure that by the year 2000 exports of tropical timber
originate from sustainably managed sources; to establish a fund to
assist tropical timber producers in obtaining the resources necessary
to reach this objective
parties--(54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany,
Ghana, Greece, Guyana, Honduras, India, Indonesia, Italy, Japan, South
Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway,
Panama, Papua New Guinea, Peru, Philippines, Spain, Suriname, Sweden,
Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
countries that have signed, but not yet ratified--(2) Ireland, Portugal
Kyoto Protocol to the United Nations Framework Convention on Climate
Change
note--abbreviated as Climate Change-Kyoto Protocol
opened for signature--16 March 1998, but not yet in force
objective--to further reduce greenhouse gas emissions by enhancing the
national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties--(7) Antigua and Barbuda, El Salvador, Fiji, Maldives, Panama,
Trinidad and Tobago, Tuvalu
countries that have signed, but not yet ratified--(72) Argentina,
Australia, Austria, Belgium, Bolivia, Brazil, Bulgaria, Canada, Chile,
China, Cook Islands, Costa Rica, Croatia, Czech Republic, Denmark,
Ecuador, Estonia, EU, Finland, France, Germany, Greece, Guatemala,
Honduras, Indonesia, Ireland, Israel, Italy, Japan, South Korea,
Latvia, Liechtenstein, Lithuania, Luxembourg, Mali, Malta, Marshall
Islands, Mexico, Federated States of Micronesia, Monaco, Netherlands,
New Zealand, Nicaragua, Niger, Niue, Norway, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Seychelles, Slovakia,
Slovenia, Solomon Islands, Spain, Sweden, Switzerland, Thailand,
Turkmenistan, UK, US, Uruguay, Uzbekistan, Vietnam, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the
High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note--abbreviated as Ozone Layer Protection
opened for signature--16 September 1987
entered into force--1 January 1989
objective--to protect the ozone layer by controlling emissions of
substances that deplete it
parties--(168) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal (Portugal has also extended the protocol to Macau),
Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Seychelles,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, former
Yugoslavia, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
note--abbreviated as Ship Pollution
opened for signature--17 February 1978
entered into force--2 October 1983
objective--to preserve the marine environment through the complete
elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties--(100) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, The Bahamas, Barbados, Belgium, Belize, Brazil, Brunei,
Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Ecuador, Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan,
Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania,
Luxembourg, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Monaco, Morocco, Netherlands, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Peru, Poland, Portugal, Romania, Russia, Saint
Vincent and the Grenadines, Senegal, Seychelles, Singapore, Slovakia,
Slovenia, South Africa, Spain, Suriname, Sweden, Switzerland, Syria,
Togo, Tonga, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay,
Vanuatu, Venezuela, Vietnam, former Yugoslavia
Protocol on Environmental Protection to the Antarctic Treaty
note--abbreviated as Antarctic-Environmental Protocol
opened for signature--4 October 1991
entered into force--14 January 1998
objective--to enhance the protection of the Antarctic environment and
dependent and associated ecosystems
parties--(28) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile,
China, Ecuador, Finland, France, Germany, Greece, India, Italy, Japan,
South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South
Africa, Spain, Sweden, UK, US, Uruguay
countries that have signed, but not yet ratified--(15) Austria, Canada,
Colombia, Cuba, Czech Republic, Denmark, Guatemala, Hungary, North
Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey,','e62c2b0c889ef02157cf12707a192945571bd1f43469bd57ea67ba3654387aaa','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf431f6252c518bb903cb96e22190a25da9beb21e3d648814dbb135892a95fb8',1999,'UA','Ukraine','communications',403,'Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
note--abbreviated as Air Pollution-Nitrogen Oxides
opened for signature--31 October 1988
entered into force--14 February 1991
objective--to provide for the control or reduction of nitrogen oxides
and their transboundary fluxes
parties--(26) Austria, Belarus, Bulgaria, Canada, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified--(2) Belgium, Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
note--abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature--18 November 1991
entered into force--29 September 1997
objective--to provide for the control and reduction of emissions of
volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties--(17) Austria, Bulgaria, Czech Republic, Denmark, Finland,
France, Germany, Hungary, Italy, Liechtenstein, Luxembourg,
Netherlands, Norway, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified--(7) Belgium, Canada,
EU, Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
note--abbreviated as Air Pollution-Sulphur 94
opened for signature--14 June 1994
entered into force--5 August 1998
objective--to provide for a further reduction in sulfur emissions or
transboundary fluxes
parties--(21) Austria, Canada, Czech Republic, Denmark, EU, Finland,
France, Germany, Greece, Ireland, Italy, Liechtenstein, Luxembourg,
Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified--(7) Belgium, Bulgaria,
Croatia, Hungary, Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
note--abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature--24 June 1998, but not yet in force
objective--to provide for the control and reduction of emissions of
persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
partie--(1) Canada
countries that have signed, but not yet ratified--(35) Armenia, Austria,
Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, EU,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Latvia, Liechtenstein, Lithuania, Luxembourg, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Ukraine, UK, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
note--abbreviated as Air Pollution-Sulphur 85
opened for signature--8 July 1985
entered into force--2 September 1987
objective--to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties--(21) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water
note--abbreviated as Nuclear Test Ban
opened for signature--5 August 1963
entered into force--10 October 1963
objective--to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons,
including nuclear weapons
parties--(122) Afghanistan, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Bangladesh, Belarus, Belgium, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burma, Canada, Cape Verde, Central African Republic, Chad, Chile,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana,
Greece, Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South
Korea, Kuwait, Laos, Lebanon, Liberia, Libya, Luxembourg, Madagascar,
Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Mongolia,
Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Romania,
Russia, Rwanda, Samoa, San Marino, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK,
US, Uruguay, Venezuela, Yemen, former Yugoslavia, Zambia
countries that have signed, but not yet ratified--(12) Algeria, Burkina
Faso, Burundi, Cameroon, China, Ethiopia, Haiti, Mali, Paraguay,
Portugal, Somalia, Vietnam
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note--abbreviated as Law of the Sea
opened for signature--10 December 1982
entered into force--16 November 1994
objective--to set up a comprehensive new legal regime for the sea and
oceans; to include rules concerning environmental standards as well as
enforcement provisions dealing with pollution of the marine environment
parties--(130) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Barbados, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burma, Cameroon, Cape Verde, Chile, China, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica,
Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq,
Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait,
Laos, Lebanon, The Former Yugoslav Republic of Macedonia, Malaysia,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Monaco, Mongolia, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Philippines, Poland, Portugal, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda,
UK, Uruguay, Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified--(40) Afghanistan,
Bangladesh, Belarus, Bhutan, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Chad, Colombia, Republic of the Congo,
Denmark, Dominican Republic, El Salvador, Ethiopia, Hungary, Iran,
North Korea, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg,
Madagascar, Malawi, Maldives, Morocco, Nicaragua, Niger, Niue, Qatar,
Rwanda, Swaziland, Switzerland, Thailand, Tuvalu, Ukraine, UAE, Vanuatu
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in
Africa
note--abbreviated as Desertification
opened for signature--14 October 1994
entered into force--26 December 1996
objective--to combat desertification and mitigate the effects of drought
through national action programs that incorporate long-term strategies
supported by international cooperation and partnership arrangements
parties--(148) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Comoros, Democratic Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon,
The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan,
Panama, Paraguay, Peru, Portugal, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, South
Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Togo, Tonga, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, United Arab Emirates, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified--(9) Australia,
Colombia, Republic of the Congo, Croatia, Georgia, South Korea,
Philippines, US, Vanuatu
United Nations Framework Convention on Climate Change
note--abbreviated as Climate Change
opened for signature--9 May 1992
entered into force--21 March 1994
objective--to achieve stabilization of greenhouse gas concentrations in
the atmosphere at a low enough level to prevent dangerous anthropogenic
interference with the climate system
parties--(177) Albania, Algeria, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, EU,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, former Yugoslavia,
Zambia, Zimbabwe
countries that have signed, but not yet ratified--(7) Afghanistan,
Angola, Belarus, Liberia, Libya, Madagascar, Sao Tome and Principe
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
=====================================================================
Appendix E: Weights and Measures
Mathematical Notation
Mathematical Power Name
10^18 or 1,000,000,000,000,000,000 one quintillion
10^15 or 1,000,000,000,000,000 one quadrillion
10^12 or 1,000,000,000,000 one trillion
10^9 or 1,000,000,000 one billion
10^6 or 1,000,000 one million
10^3 or 1,000 one thousand
10^2 or 100 one hundred
10^1 or 10 ten
10^0 or 1 one
10^-1 or 0.1 one tenth
10^-2 or 0.01 one hundredth
10^-3 or 0.001 one thousandth
10^-6 or 0.000 001 one millionth
10^-9 or 0.000 000 001 one billionth
10^-12 or 0.000 000 000 001 one trillionth
10^-15 or 0.000 000 000 000 001 one quadrillionth
10^-18 or 0.000 000 000 000 000 001 one quintillionth
Metric Interrelationships
Prefix Symbol Length, weight, or capacity Area Volume
exa E 1018 1036 1054
peta P 1015 1030 1045
tera T 1012 1024 1036
giga G 109 1018 1027
mega M 106 1012 1018
hectokilo hk 105 1010 1015
myria ma 104 108 1012
kilo k 103 106 109
hecto h 102 104 106
basic unit -- 1 meter, 1 gram, 1 liter 1 meter2 1 meter3
deci d 10-1 10-2 10-3
centi c 10-2 10-4 10-6
milli m 10-3 10-6 10-9
decimilli dm 10-4 10-8 10-12
centimilli cm 10-5 10-10 10-15
micro u 10-6 10-12 10-18
nano n 10-9 10-18 10-27
pico p 10-12 10-24 10-36
femto f 10-15 10-30 10-45
atto a 10-18 10-36 10-54
Conversion Factors
To Convert From To Multiply by
acres ares 40.468 564 224
acres hectares 0.404 685 642 24
acres square feet 43,560
acres square kilometers 0.004 046 856 422 4
acres square meters 4,046.856 422 4
acres square miles (statute) 0.001 562 50
acres square yards 4,840
ares square meters 100
ares square yards 119.599
barrels, US beer gallons 31
barrels, US beer liters 117.347 77
barrels, US gallons (British) 34.97
petroleum
barrels, US gallons (US) 42
petroleum
barrels, US liters 158.987 29
petroleum
barrels, US proof gallons 40
spirits
barrels, US proof liters 151.416 47
spirits
bushels (US) bushels (British) 0.968 9
bushels (US) cubic feet 1.244 456
bushels (US) cubic inches 2,150.42
bushels (US) cubic meters 0.035 239 07
bushels (US) cubic yards 0.046 090 96
bushels (US) dekaliters 3.523 907
bushels (US) dry pints 64
bushels (US) dry quarts 32
bushels (US) liters 35.239 070 17
bushels (US) pecks 4
cables fathoms 120
cables meters 219.456
cables yards 240
carat milligrams 200
centimeters feet 0.032 808 40
centimeters inches 0.393 700 8
centimeters meters 0.01
centimeters yards 0.010 936 13
centimeters, cubic inches 0.061 023 744
cubic
centimeters, square feet 0.001 076 39
square
centimeters, square inches 0.155 000 31
square
centimeters, square meters 0.000 1
square
centimeters, square yards 0.000 119 599
square
chains, square ares 4.046 86
surveyor''s
chains, square square feet 4,356
surveyor''s
chains, feet 66
surveyor''s
chains, meters 20.116 8
surveyor''s
chains, rods 4
surveyor''s
cords of wood cubic feet 128
cords of wood cubic meters 3.624 556
cords of wood cubic yards 4.740 7
cups liquid ounces (US) 8
cups liters 0.236 588 2
degrees Celsius degrees Fahrenheit multiply by 1.8
and add 32
degrees degrees Celsius subtract 32 and
Fahrenheit divide by 1.8
dekaliters bushels 0.283 775 9
dekaliters cubic feet 0.353 146 7
dekaliters cubic inches 610.237 4
dekaliters dry pints 18.161 66
dekaliters dry quarts 9.080 829 8
dekaliters liters 10
dekaliters pecks 1.135 104
drams, avoirdupois ounces 0.062 55
avoirdupois
drams, grains 27.344
avoirdupois
drams, grams 1.771 845 2
avoirdupois
drams, troy grains 60
drams, troy grams 3.887 934 6
drams, troy scruples 3
drams, troy troy ounces 0.125
drams, liquid cubic inches 0.226
(US)
drams, liquid liquid drams (British) 1.041
(US)
drams, liquid liquid ounces 0.125
(US)
drams, liquid milliliters 3.696 69
(US)
drams, liquid minims 60
(US)
fathoms feet 6
fathoms meters 1.828 8
feet centimeters 30.48
feet inches 12
feet kilometers 0.000 304 8
feet meters 0.304 8
feet statute miles 0.000 189 39
feet yards 0.333 333 3
feet, cubic bushels 0.803 563 95
feet, cubic cubic decimeters 28.316 847
feet, cubic cubic inches 1,728
feet, cubic cubic meters 0.028 316 846 592
feet, cubic cubic yards 0.037 037 04
feet, cubic dry pints 51.428 09
feet, cubic dry quarts 25.714 05
feet, cubic gallons 7.480 519
feet, cubic gills 239.376 6
feet, cubic liquid ounces 957.506 5
feet, cubic liquid pints 59.844 16
feet, cubic liquid quarts 29.922 08
feet, cubic liters 28.316 846 592
feet, cubic pecks 3.214 256
feet, square acres 0.000 022 956 8
feet, square square centimeters 929.030 4
feet, square square decimeters 9.290 304
feet, square square inches 144
feet, square square meters 0.092 903 04
feet, square square yards 0.111 111 1
furlongs feet 660
furlongs inches 7,920
furlongs meters 201.168
furlongs statute miles 0.125
furlongs yards 220
gallons, liquid cubic feet 0.133 680 6
(US)
gallons, liquid cubic inches 231
(US)
gallons, liquid cubic meters 0.003 785 411 784
(US)
gallons, liquid cubic yards 0.004 951 13
(US)
gallons, liquid gills (US) 32
(US)
gallons, liquid liquid gallons (British) 0.832 67
(US)
gallons, liquid liquid ounces 128
(US)
gallons, liquid liquid pints 8
(US)
gallons, liquid liquid quarts 4
(US)
gallons, liquid liters 3.785 411 784
(US)
gallons, liquid milliliters 3,785.411 784
(US)
gallons, liquid minims 61,440
(US)
gills (US) centiliters 11.829 4
gills (US) cubic feet 0.004 177 517
gills (US) cubic inches 7.218 75
gills (US) gallons 0.031 25
gills (US) gills (British) 0.832 67
gills (US) liquid ounces 4
gills (US) liquid pints 0.25
gills (US) liquid quarts 0.125
gills (US) liters 0.118 294 118 25
gills (US) milliliters 118.294 118 25
gills (US) minims 1,920
grains avoirdupois drams 0.036 571 43
grains avoirdupois ounces 0.002 285 71
grains avoirdupois pounds 0.000 142 86
grains grams 0.064 798 91
grains kilograms 0.000 064 798 91
grains milligrams 64.798 910
grains pennyweights 0.042
grains scruples 0.05
grains troy drams 0.016 6
grains troy ounces 0.002 083 33
grains troy pounds 0.000 173 61
grams avoirdupois drams 0.564 383 39
grams avoirdupois ounces 0.035 273 961
grams avoirdupois pounds 0.002 204 622 6
grams grains 15.432 361
grams kilograms 0.001
grams milligrams 1,000
grams troy ounces 0.032 150 746 6
grams troy pounds 0.002 679 23
hands (height of centimeters 10.16
horse)
hands (height of inches 4
horse)
hectares acres 2.471 053 8
hectares square feet 107,639.1
hectares square kilometers 0.01
hectares square meters 10,000
hectares square miles 0.003 861 02
hectares square yards 11,959.90
hundredweights, avoirdupois pounds 112
long
hundredweights, kilograms 50.802 345
long
hundredweights, long tons 0.05
long
hundredweights, metric tons 0.050 802 345
long
hundredweights, short tons 0.056
long
hundredweights, avoirdupois pounds 100
short
hundredweights, kilograms 45.359 237
short
hundredweights, long tons 0.044 642 86
short
hundredweights, metric tons 0.045 359 237
short
hundredweights, short tons 0.05
short
inches centimeters 2.54
inches feet 0.083 333 33
inches meters 0.025 4
inches millimeters 25.4
inches yards 0.027 777 78
inches, cubic bushels 0.000 465 025
inches, cubic cubic centimeters 16.387 064
inches, cubic cubic feet 0.000 578 703 7
inches, cubic cubic meters 0.000 016 387 064
inches, cubic cubic yards 0.000 021 433 47
inches, cubic dry pints 0.029 761 6
inches, cubic dry quarts 0.014 880 8
inches, cubic gallons 0.004 329 0
inches, cubic gills 0.138 528 1
inches, cubic liquid ounces 0.554 112 6
inches, cubic liquid pints 0.034 632 03
inches, cubic liquid quarts 0.017 316 02
inches, cubic liters 0.016 387 064
inches, cubic milliliters 16.387 064
inches, cubic minims (US) 265.974 0
inches, cubic pecks 0.001 860 10
inches, square square centimeters 6.451 600
inches, square square feet 0.006 944 44
inches, square square meters 0.000 645 16
inches, square square yards 0.000 771 605
kilograms avoirdupois drams 564.383 4
kilograms avoirdupois ounces 35.273 962
kilograms avoirdupois pounds 2.204 622 622
kilograms grains 15,432.36
kilograms grams 1,000
kilograms long tons 0.000 984 2
kilograms metric tons 0.001
kilograms short hundredweights 0.022 046 23
kilograms short tons 0.001 102 31
kilograms troy ounces 32.150 75
kilograms troy pounds 2.679 229
kilometers meters 1,000
kilometers statute miles 0.621 371 192
kilometers, acres 247.105 38
square
kilometers, hectares 100
square
kilometers, square meters 1,000,000
square
kilometers, statute miles 0.386 102 16
square
knots (nautical kilometers/hour 1.852
mi/hr)
knots (nautical statute miles/hour 1.151
mi/hr)
leagues, nautical kilometers 5.556
leagues, nautical nautical miles 3
leagues, statute kilometers 4.828 032
leagues, statute statute miles 3
links, square square centimeters 404.686
surveyor''s
links, square square inches 62.726 4
surveyor''s
links, surveyor''s centimeters 20.116 8
links, surveyor''s chains 0.01
links, surveyor''s inches 7.92
liters bushels 0.028 377 59
liters cubic feet 0.035 314 67
liters cubic inches 61.023 74
liters cubic meters 0.001
liters cubic yards 0.001 307 95
liters dekaliters 0.1
liters dry pints 1.816 166
liters dry quarts 0.908 082 98
liters gallons 0.264 172 052
liters gills (US) 8.453 506
liters liquid ounces 33.814 02
liters liquid pints 2.113 376
liters liquid quarts 1.056 688 2
liters milliliters 1,000
liters pecks 0.113 510 4
meters centimeters 100
meters feet 3.280 839 895
meters inches 39.370 079
meters kilometers 0.001
meters millimeters 1,000
meters statute miles 0.000 621 371
meters yards 1.093 613 298
meters, cubic bushels 28.377 59
meters, cubic cubic feet 35.314 666 7
meters, cubic cubic inches 61,023.744
meters, cubic cubic yards 1.307 950 619
meters, cubic gallons 264.172 05
meters, cubic liters 1,000
meters, cubic pecks 113.510 4
meters, square acres 0.000 247 105 38
meters, square hectares 0.000 1
meters, square square centimeters 10,000
meters, square square feet 10.763 910 4
meters, square square inches 1,550.003 1
meters, square square yards 1.195 990 046
microns meters 0.000 001
microns inches 0.000 039 4
mils inches 0.001
mils millimeters 0.025 4
miles, nautical kilometers 1.852 0
miles, nautical statute miles 1.150 779 4
miles, statute centimeters 160,934.4
miles, statute feet 5,280
miles, statute furlongs 8
miles, statute inches 63,360
miles, statute kilometers 1.609 344
miles, statute meters 1,609.344
miles, statute rods 320
miles, statute yards 1,760
miles, square square kilometers 3.429 904
nautical
miles, square square statute miles 1.325
nautical
miles, square acres 640
statute
miles, square hectares 258.998 811 033 6
statute
miles, square sections 1
statute
miles, square square kilometers 2.589 988 110 336
statute
miles, square square nautical miles 0.755 miles
statute
miles, square square rods 102,400
statute
milligrams grains 0.015 432 358 35
milliliters cubic inches 0.061 023 744
milliliters gallons 0.000 264 17
milliliters gills (US) 0.008 453 5
milliliters liquid ounces 0.033 814 02
milliliters liquid pints 0.002 113 4
milliliters liquid quarts 0.001 056 7
milliliters liters 0.001
milliliters minims 16.230 73
millimeters inches 0.039 370 078 7
minims (US) cubic inches 0.003 759 77
minims (US) gills (US) 0.000 520 83
minims (US) liquid ounces 0.002 083 33
minims (US) milliliters 0.061 611 52
minims (US) minims (British) 1.041
ounces, avoirdupois drams 16
avoirdupois
ounces, avoirdupois pounds 0.062 5
avoirdupois
ounces','0cd9958ee7991f0da87a84e31cfe61b80d3a1e4d7144db69865429e1bc0a6012','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5035ae785db720421ee480a6f75c046e44c28399c40f1779e29d81d7b6478c17',1999,'UA','Ukraine','communications',404,', grains 437.5
avoirdupois
ounces, grams 28.349 523 125
avoirdupois
ounces, kilograms 0.028 349 523 125
avoirdupois
ounces, troy ounces 0.911 458 3
avoirdupois
ounces, troy pounds 0.075 954 86
avoirdupois
ounces, liquid cubic feet 0.001 044 38
(US)
ounces, liquid centiliters 2.957 35
(US)
ounces, liquid cubic inches 1.804 687 5
(US)
ounces, liquid gallons 0.007 812 5
(US)
ounces, liquid gills (US) 0.25
(US)
ounces, liquid liquid drams 8
(US)
ounces, liquid liquid ounces (British) 1.041
(US)
ounces, liquid liquid pints 0.062 5
(US)
ounces, liquid liquid quarts 0.031 25
(US)
ounces, liquid liters 0.029 573 53
(US)
ounces, liquid milliliters 29.573 529 6
(US)
ounces, liquid minims 480
(US)
ounces, troy avoirdupois drams 17.554 29
ounces, troy avoirdupois ounces 1.097 143
ounces, troy avoirdupois pounds 0.068 571 43
ounces, troy grains 480
ounces, troy grams 31.103 476 8
ounces, troy pennyweights 20
ounces, troy troy drams 8
ounces, troy troy pounds 0.083 333 3
paces (US) centimeters 76.2
paces (US) inches 30
pecks (US) bushels 0.25
pecks (US) cubic feet 0.311 114
pecks (US) cubic inches 537.605
pecks (US) cubic meters 0.008 809 77
pecks (US) cubic yards 0.011 522 74
pecks (US) dekaliters 0.880 976 75
pecks (US) dry pints 16
pecks (US) dry quarts 8
pecks (US) liters 8.809 767 5
pecks (US) pecks (British) 0.968 9
pennyweights grains 24
pennyweights grams 1.555 173 84
pennyweights troy ounces 0.05
pints, dry (US) bushels 0.015 625
pints, dry (US) cubic feet 0.019 444 63
pints, dry (US) cubic inches 33.600 312 5
pints, dry (US) dekaliters 0.055 061 05
pints, dry (US) dry pints (British) 0.968 9
pints, dry (US) dry quarts 0.5
pints, dry (US) liters 0.550 610 47
pints, liquid cubic feet 0.016 710 07
(US)
pints, liquid cubic inches 28.875
(US)
pints, liquid deciliters 4.731 76
(US)
pints, liquid gallons 0.125
(US)
pints, liquid gills (US) 4
(US)
pints, liquid liquid ounces 16
(US)
pints, liquid liquid pints (British) 0.832 67
(US)
pints, liquid liquid quarts 0.5
(US)
pints, liquid liters 0.473 176 473
(US)
pints, liquid milliliters 473.176 473
(US)
pints, liquid minims 7,680
(US)
points inches 0.013 837
(typographical)
points millimeters 0.351 459 8
(typographical)
pounds, avoirdupois drams 256
avoirdupois
pounds, avoirdupois ounces 16
avoirdupois
pounds, grains 7,000
avoirdupois
pounds, grams 453.592 37
avoirdupois
pounds, kilograms 0.453 592 37
avoirdupois
pounds, long tons 0.000 446 428 6
avoirdupois
pounds, metric tons 0.000 453 592 37
avoirdupois
pounds, quintals 0.004 535 92
avoirdupois
pounds, short tons 0.000 5
avoirdupois
pounds, troy ounces 14.583 33
avoirdupois
pounds, troy pounds 1.215 278
avoirdupois
pounds, troy avoirdupois drams 210.651 4
pounds, troy avoirdupois ounces 13.165 71
pounds, troy avoirdupois pounds 0.822 857 1
pounds, troy grains 5,760
pounds, troy grams 373.241 721 6
pounds, troy kilograms 0.373 241 721 6
pounds, troy pennyweights 240
pounds, troy troy ounces 12
quarts, dry (US) bushels 0.031 25
quarts, dry (US) cubic feet 0.038 889 25
quarts, dry (US) cubic inches 67.200 625
quarts, dry (US) dekaliters 0.110 122 1
quarts, dry (US) dry pints 2
quarts, dry (US) dry quarts (British) 0.968 9
quarts, dry (US) liters 1.101 221
quarts, dry (US) pecks 0.125
quarts, dry (US) pints, dry (US) 2
quarts, liquid cubic feet 0.033 420 14
(US)
quarts, liquid cubic inches 57.75
(US)
quarts, liquid deciliters 9.463 53
(US)
quarts, liquid gallons 0.25
(US)
quarts, liquid gills (US) 8
(US)
quarts, liquid liquid ounces 32
(US)
quarts, liquid liquid pints (US) 2
(US)
quarts, liquid liquid quarts (British) 0.832 67
(US)
quarts, liquid liters 0.946 352 946
(US)
quarts, liquid milliliters 946.352 946
(US)
quarts, liquid minims 15,360
(US)
quintals avoirdupois pounds 220.462 26
quintals kilograms 100
quintals metric tons 0.1
rods feet 16.5
rods meters 5.029 2
rods yards 5.5
rods, square acres 0.006 25
rods, square square meters 25.292 85
rods, square square yards 30.25
scruples grains 20
scruples grams 1.295 978 2
scruples troy drams 0.333
sections (US) square kilometers 2.589 988 1
sections (US) square statute miles 1
spans centimeters 22.86
spans inches 9
steres cubic meters 1
steres cubic yards 1.307 95
tablespoons milliliters 14.786 76
tablespoons teaspoons 3
teaspoons milliliters 4.928 922
teaspoons tablespoons 0.333 333
ton-miles, long metric ton-kilometers 1.635 169
ton-miles, short metric ton-kilometers 1.459 972
tons, gross cubic feet of permanently enclosed 100
register space
tons, gross cubic meters of permanently 2.831 684 7
register enclosed space
tons, long avoirdupois ounces 35,840
(deadweight)
tons, long avoirdupois pounds 2,240
(deadweight)
tons, long kilograms 1,016.046 909 8
(deadweight)
tons, long long hundredweights 20
(deadweight)
tons, long metric tons 1.016 046 908 8
(deadweight)
tons, long short hundredweights 22.4
(deadweight)
tons, long short tons 1.12
(deadweight)
tons, metric avoirdupois pounds 2,204.623
tons, metric kilograms 1,000
tons, metric long hundredweights 19.684 130 3
tons, metric long tons 0.984 206 5
tons, metric quintals 10
tons, metric short hundredweights 22.046 23
tons, metric short tons 1.102 311 3
tons, metric troy ounces 32,150.75
tons, net cubic feet of permanently enclosed 100
register space for cargo and passengers
tons, net cubic meters of permanently 2.831 684 7
register enclosed space for cargo and
passengers
tons, shipping cubic feet of permanently enclosed 42
cargo space
tons, shipping cubic meters of permanently 1.189 307 574
enclosed cargo space
tons, short avoirdupois pounds 2,000
tons, short kilograms 907.184 74
tons, short long hundredweights 17.857 14
tons, short long tons 0.892 857 1
tons, short metric tons 0.907 184 74
tons, short short hundredweights 20
townships (US) sections 36
townships (US) square kilometers 93.239 572
townships (US) square statute miles 36
miles, square acres 640
statute
miles, square hectares 258.998 811 033 6
statute
miles, square square feet 27,878,400
statute
miles, square square meters 2,589,988.110 336
statute
miles, square square yards 3,097,600
statute
yards centimeters 91.44
yards feet 3
yards inches 36
yards meters 0.914 4
yards miles 0.000 568 18
yards, cubic bushels 21.696 227
yards, cubic cubic feet 27
yards, cubic cubic inches 46,656
yards, cubic cubic meters 0.764 554 857 984
yards, cubic gallons 201.974 0
yards, cubic liters 764.554 857 984
yards, cubic pecks 86.784 91
yards, square acres 0.000 206 611 6
yards, square hectares 0.000 083 612 736
yards, square square centimeters 8,361.273 6
yards, square square feet 9
yards, square square inches 1,296
yards, square square meters 0.836 127 36
yards, square square miles 0.000 000 322 830
6
Note: At this time, only three countries--Burma, Liberia, and the
US--have not adopted the International System of Units (SI, or metric
system) as their official system of weights and measures. Although use
of the metric system has been sanctioned by law in the US since 1866,
it has been slow in displacing the American adaptation of the British
Imperial System known as the US Customary System. The US is the only
industrialized nation that does not mainly use the metric system in
its commercial and standards activities, but there is increasing
acceptance in science, medicine, government, and many sectors of
industry.
=====================================================================
Appendix F: Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special
Sovereignty, and Their Principal Administrative Divisions
(FIPS PUB 10-4) is maintained by the Office of the
Geographer and Global Issues (Department of State) and
published by the National Institute of Standards and
Technology (Department of Commerce). These two-character
alphabetic codes are included in the text of the Factbook in
the Data code entry under the Government category. FIPS 10-4
codes are intended for general use throughout the US
Government, especially in activities associated with the
mission of the Department of State and national defense
programs.
ISO 3166: Codes for the Representation of Names of Countries
(ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character
alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with
international organizations that have adopted that standard.
Except for the numeric codes, ISO 3166 codes have been
adopted in the US as FIPS 104-1: American National Standard
Codes for the Representation of Names of Countries,
Dependencies, and Areas of Special Sovereignty for
Information Interchange.
Internet: This is a provisional compilation that generally
agrees with the ISO 3166 two-character alphabetic codes.
Entity FIPS ISO ISO ISO Interne Comment
10-4 316 316 316 t
6 6 6
Afghanistan AF AF AFG 004 AF
Albania AL AL ALB 008 AL
Algeria AG DZ DZA 012 DZ
American AQ AS ASM 016 AS','de7f19351ee117958099f8ebf3c05fd3738c5f7bd9d093d3f43f8063d9bd0205','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4c49880c079544750e82a7d30ec6da19a9f3ecf0b3c8f6c817872887fc8f8ec',1999,'WS','Samoa','communications',405,'Andorra AN AD AND 020 AD
Angola AO AO AGO 024 AO
Anguilla AV AI AIA 660 AI
Antarctica AY AQ ATA 010 AQ ISO defines as the
territory south of 60
degrees south latitude
Antigua and AC AG ATG 028 AG
Barbuda
Argentina AR AR ARG 032 AR
Armenia AM AM ARM 051 AM
Aruba AA AW ABW 533 AW
Ashmore and AT -- -- -- -- ISO includes with
Cartier Australia
Australia AS AU AUS 036 AU ISO includes Ashmore
and Cartier
Islands,Coral Sea
Islands
Austria AU AT AUT 040 AT
Azerbaijan AJ AZ AZE 031 AZ
The Bahamas BF BS BHS 044 BS
Bahrain BA BH BHR 048 BH
Baker Island FQ -- -- -- -- ISO includes with the
US Minor Outlying
Islands
Bangladesh BG BD BGD 050 BD
Barbados BB BB BRB 052 BB
Bassas da BS -- -- -- -- ISO includes with the
India Miscellaneous (French)
Indian Ocean Islands
Belarus BO BY BLR 112 BY
Belgium BE BE BEL 056 BE
Belize BH BZ BLZ 084 BZ
Benin BN BJ BEN 204 BJ
Bermuda BD BM BMU 060 BM
Bhutan BT BT BTN 064 BT
Bolivia BL BO BOL 068 BO
Bosnia and BK BA BIH 070 BA
Herzegovina
Botswana BC BW BWA 072 BW
Bouvet Island BV BV BVT 074 BV
Brazil BR BR BRA 076 BR
British IO IO IOT 086 IO
Indian Ocean
Territory
British VI VG VGB 092 VG
Virgin
Islands
Brunei BX BN BRN 096 BN
Bulgaria BU BG BGR 100 BG
Burkina Faso UV BF BFA 854 BF
Burma BM MM MMR 104 MM ISO uses the name
Andorra AN AD AND 020 AD
Angola AO AO AGO 024 AO
Anguilla AV AI AIA 660 AI
Antarctica AY AQ ATA 010 AQ ISO defines as the territory
south of 60 degrees south
latitude
Antigua and AC AG ATG 028 AG
Barbuda
Argentina AR AR ARG 032 AR
Armenia AM AM ARM 051 AM
Aruba AA AW ABW 533 AW
Ashmore and AT -- -- -- -- ISO includes with Australia
Cartier
Australia AS AU AUS 036 AU ISO includes Ashmore and
Cartier Islands,Coral Sea
Islands
Austria AU AT AUT 040 AT
Azerbaijan AJ AZ AZE 031 AZ
The Bahamas BF BS BHS 044 BS
Bahrain BA BH BHR 048 BH
Baker Island FQ -- -- -- -- ISO includes with the US
Minor Outlying Islands
Bangladesh BG BD BGD 050 BD
Barbados BB BB BRB 052 BB
Bassas da BS -- -- -- -- ISO includes with the
India Miscellaneous (French)
Indian Ocean Islands
Belarus BO BY BLR 112 BY
Belgium BE BE BEL 056 BE
Belize BH BZ BLZ 084 BZ
Benin BN BJ BEN 204 BJ
Bermuda BD BM BMU 060 BM
Bhutan BT BT BTN 064 BT
Bolivia BL BO BOL 068 BO
Bosnia and BK BA BIH 070 BA
Herzegovina
Botswana BC BW BWA 072 BW
Bouvet Island BV BV BVT 074 BV
Brazil BR BR BRA 076 BR
British IO IO IOT 086 IO
Indian Ocean
Territory
British VI VG VGB 092 VG
Virgin
Islands
Brunei BX BN BRN 096 BN
Bulgaria BU BG BGR 100 BG
Burkina Faso UV BF BFA 854 BF
Burma BM MM MMR 104 MM ISO uses the name Myanmar
Burundi BY BI BDI 108 BI
Cambodia CB KH KHM 116 KH
Cameroon CM CM CMR 120 CM
Canada CA CA CAN 124 CA
Cape Verde CV CV CPV 132 CV
Cayman CJ KY CYM 136 KY
Islands
Central CT CF CAF 140 CF
African
Republic
Chad CD TD TCD 148 TD
Chile CI CL CHL 152 CL
China CH CN CHN 156 CN see also Taiwan
Christmas KT CX CXR 162 CX
Island
Clipperton IP -- -- -- -- ISO includes with French
Island Polynesia
Cocos CK CC CCK 166 CC
(Keeling)
Islands
Colombia CO CO COL 170 CO
Comoros CN KM COM 174 KM
Congo, CG ZR ZAR 180 ZR formerly Zaire
Democratic
Republic of
the
Congo, CF CG COG 178 CG
Republic of
the
Cook Islands CW CK COK 184 CK
Coral Sea CR -- -- -- -- ISO includes with Australia
Islands
Costa Rica CS CR CRI 188 CR
Cote d''Ivoire IV CI CIV 384 CI
Croatia HR HR HRV 191 HR
Cuba CU CU CUB 192 CU
Cyprus CY CY CYP 196 CY
Czech EZ CZ CZE 203 CZ
Republic
Denmark DA DK DNK 208 DK
Djibouti DJ DJ DJI 262 DJ
Dominica DO DM DMA 212 DM
Dominican DR DO DOM 214 DO
Republic
East Timor -- TP TMP 626 TP FIPS includes with Indonesia
Ecuador EC EC ECU 218 EC
Egypt EG EG EGY 818 EG
El Salvador ES SV SLV 222 SV
Equatorial EK GQ GNQ 226 GQ
Samos [island] Greece 37 48 N 26 44 E
Sanaa [US Embassy] Yemen 15 21 N 44 12 E
San Ambrosio, Isla Chile 26 21 S 79 52 W
San Andres y Colombia 13 00 N 81 30 W
Providencia,
Archipielago
San Bernardino Strait Pacific Ocean 12 32 N 124 10 E
San Felix, Isla Chile 26 17 S 80 05 W
San Jose [US Embassy] Costa Rica 9 56 N 84 05 W
San Juan Puerto Rico 18 28 N 66 07 W
San Marino San Marino 43 56 N 12 25 E
San Salvador [US El Salvador 13 42 N 89 12 W
Embassy]
Santa Cruz Bolivia 17 48 S 63 10 W
Santa Cruz Islands Solomon Islands 11 00 S 166 15 E
Santiago [US Embassy] Chile 33 27 S 70 40 W
Santo Antao [island] Cape Verde 17 05 N 25 10 W
Santo Domingo [US Dominican 18 28 N 69 54 W
Embassy] Republic
Sao Paulo [US Consulate Brazil 23 32 S 46 37 W
General]
Sao Pedro e Sao Paulo, Brazil 0 23 N 29 23 W
Penedos de [rocks]
Sao Tiago [island] Cape Verde 15 05 N 23 40 W
Sao Tome [island] Sao Tome and 0 12 N 6 39 E
Principe
Sapporo [US Consulate Japan 43 03 N 141 21 E
General]
Sapudi Strait Pacific Ocean 7 05 S 114 10 E
Sarajevo [US Embassy] Bosnia and 43 52 N 18 25 E
Herzegovina
Sarawak [state] Malaysia 2 30 N 113 30 E
Sardinia [island] Italy 40 00 N 9 00 E
Sargasso Sea Atlantic Ocean 30 00 N 55 00 W
Sark [island] Guernsey 49 26 N 2 21 W
Saxony [region] Germany 51 00 N 13 00 E
Schleswig-Holstein Germany 54 31 N 9 33 E
[region]
Scopus, Mount Israel, West 31 48 N 35 14 E
Bank
Scotia Sea Atlantic Ocean 56 00 S 40 00 W
Scotland [region] United Kingdom 57 00 N 4 00 W
Scott Island Antarctica 67 24 S 179 55 W
Senyavin Islands Federated States 6 55 N 158 00 E
of Micronesia
Seoul [US Embassy] South Korea 37 34 N 127 00 E
Serbia Serbia and 43 00 N 21 00 E','6803606526f9d6982f496883c065bfd9075a9424f043bbb515b7ffeac39f29b8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa2ee6f8e4803f1e762af0fad6ec399d85ddcaf4585022eb89faf872c117128a',1999,'MM','Myanmar','communications',406,'Burundi BY BI BDI 108 BI
Cambodia CB KH KHM 116 KH
Cameroon CM CM CMR 120 CM
Canada CA CA CAN 124 CA
Cape Verde CV CV CPV 132 CV
Cayman CJ KY CYM 136 KY
Islands
Central CT CF CAF 140 CF
African
Republic
Chad CD TD TCD 148 TD
Chile CI CL CHL 152 CL
China CH CN CHN 156 CN see also Taiwan
Christmas KT CX CXR 162 CX
Island
Clipperton IP -- -- -- -- ISO includes with
Island French Polynesia
Cocos CK CC CCK 166 CC
(Keeling)
Islands
Colombia CO CO COL 170 CO
Comoros CN KM COM 174 KM
Congo, CG ZR ZAR 180 ZR formerly Zaire
Democratic
Republic of
the
Congo, CF CG COG 178 CG
Republic of
the
Cook Islands CW CK COK 184 CK
Coral Sea CR -- -- -- -- ISO includes with
Islands Australia
Costa Rica CS CR CRI 188 CR
Cote d''Ivoire IV CI CIV 384 CI
Croatia HR HR HRV 191 HR
Cuba CU CU CUB 192 CU
Cyprus CY CY CYP 196 CY
Czech EZ CZ CZE 203 CZ
Republic
Denmark DA DK DNK 208 DK
Djibouti DJ DJ DJI 262 DJ
Dominica DO DM DMA 212 DM
Dominican DR DO DOM 214 DO
Republic
East Timor -- TP TMP 626 TP FIPS includes with','34bc0ec19ebe449a13ca330282be8a48b21a185fe5a699e17245ee3bce8d6221','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ecac8e0eb8e1da84234d3e1884b6cd9df9a9a4f11389bd6c141c1181ddc826f',1999,'GN','Guinea','communications',407,'Eritrea ER ER ERI 232 ER
Estonia EN EE EST 233 EE
Ethiopia ET ET ETH 231 ET
Europa Island EU -- -- -- -- ISO includes with the
Miscellaneous (French)
Indian Ocean Islands
Falkland FA FK FLK 238 FK
Islands
(Islas
Malvinas)
Faroe Islands FO FO FRO 234 FO
Fiji FJ FJ FJI 242 FJ
Finland FI FI FIN 246 FI
France FR FR FRA 250 FR
France, -- FX FXX 249 FX ISO limits to the
Metropolitan European part of
France, excluding
French Guiana, French
Polynesia, French
Southern and Antarctic
Lands, Guadeloupe,
Martinique, Mayotte,
New Caledonia, Reunion,
Saint Pierre and
Miquelon, Wallis and
Futuna
French Guiana FG GF GUF 254 GF
French FP PF PYF 258 PF ISO includes Clipperton
Polynesia Island
French FS TF ATF 260 -- FIPS 10-4 does not
Southern and include the French-
Antarctic claimed portion of
Lands Antarctica (Terre
Adelie)
Gabon GB GA GAB 266 GA
The Gambia GA GM GMB 270 GM
Gaza Strip GZ -- -- -- --
Georgia GG GE GEO 268 GE
Germany GM DE DEU 276 DE
Ghana GH GH GHA 288 GH
Gibraltar GI GI GIB 292 GI
Glorioso GO -- -- -- -- ISO includes with the
Islands Miscellaneous (French)
Indian Ocean Islands
Greece GR GR GRC 300 GR
Greenland GL GL GRL 304 GL
Grenada GJ GD GRD 308 GD
Guadeloupe GP GP GLP 312 GP
Guam GQ GU GUM 316 GU
Guatemala GT GT GTM 320 GT
Guernsey GK -- -- -- -- ISO includes with the
Paracel PF -- -- -- --
Islands
Paraguay PA PY PRY 600 PY
Peru PE PE PER 604 PE
Philippines RP PH PHL 608 PH
Pitcairn PC PN PCN 612 PN
Islands
Poland PL PL POL 616 PL
Portugal PO PT PRT 620 PT
Puerto Rico RQ PR PRI 630 PR
Qatar QA QA QAT 634 QA
Reunion RE RE REU 638 RE
Romania RO RO ROM 642 RO
Russia RS RU RUS 643 RU
Rwanda RW RW RWA 646 RW
Saint Helena SH SH SHN 654 SH
Saint Kitts SC KN KNA 659 KN
and Nevis
Saint Lucia ST LC LCA 662 LC
Saint Pierre SB PM SPM 666 PM
and Miquelon
Saint Vincent VC VC VCT 670 VC
and the
Grenadines
Samoa WS WS WSM 882 WS --
San Marino SM SM SMR 674 SM
Sao Tome and TP ST STP 678 ST
Principe
Saudi Arabia SA SA SAU 682 SA
Senegal SG SN SEN 686 SN
Serbia* SR -- -- -- -- see footnote at end of
table
Serbia and -- -- -- -- -- see footnote at end of
Montenegro* table
Seychelles SE SC SYC 690 SC
Sierra Leone SL SL SLE 694 SL
Singapore SN SG SGP 702 SG
Slovakia LO SK SVK 703 SK
Slovenia SI SI SVN 705 SI
Solomon BP SB SLB 090 SB
Islands
Somalia SO SO SOM 706 SO
South Africa SF ZA ZAF 710 ZA
South Georgia SX GS SGS 239 GS
and the South
Sandwich
Islands
Spain SP ES ESP 724 ES
Spratly PG -- -- -- --
Islands
Sri Lanka CE LK LKA 144 LK
Sudan SU SD SDN 736 SD
Suriname NS SR SUR 740 SR
Svalbard SV SJ SJM 744 SJ ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 SZ
Sweden SW SE SWE 752 SE
Switzerland SZ CH CHE 756 CH
Syria SY SY SYR 760 SY
Taiwan TW TW TWN 158 TW
Tajikistan TI TJ TJK 762 TJ
Tanzania TZ TZ TZA 834 TZ
Thailand TH TH THA 764 TH
Togo TO TG TGO 768 TG
Tokelau TL TK TKL 772 TK
Tonga TN TO TON 776 TO
Trinidad and TD TT TTO 780 TT
Tobago
Tromelin TE -- -- -- -- ISO includes with the
Island Miscellaneous (French)
Indian Ocean Islands
Tunisia TS TN TUN 788 TN
Turkey TU TR TUR 792 TR
Turkmenistan TX TM TKM 795 TM
Turks and TK TC TCA 796 TC
Caicos
Islands
Tuvalu TV TV TUV 798 TV
Uganda UG UG UGA 800 UG
Ukraine UP UA UKR 804 UA
United Arab TC AE ARE 784 AE
Emirates
United UK GB GBR 826 UK/GB ISO includes Guernsey,
Kingdom Isle of Man, Jersey
United States US US USA 840 US
United States -- UM UMI 581 UM ISO includes Baker
Minor Island, Howland Island,
Outlying Jarvis Island, Johnston
Islands Atoll, Kingman Reef,
Midway Islands, Palmyra
Atoll, Wake Island
Uruguay UY UY URY 858 UY
Uzbekistan UZ UZ UZB 860 UZ
Vanuatu NH VU VUT 548 VU
Venezuela VE VE VEN 862 UE
Vietnam VM VN VNM 704 VN
Virgin VQ VI VIR 850 VI
Islands
Virgin -- -- -- -- -- see British Virgin
Islands (UK) Islands
Virgin -- -- -- -- -- see Virgin Islands
Islands (US)
Wake Atoll WQ -- -- -- -- ISO includes with the
US Minor Outlying
Islands
Wallis and WF WF WLF 876 WF
Futuna
West Bank WE -- -- -- --
Western WI EH ESH 732 EH
Sahara
Western Samoa -- -- -- -- -- see Samoa
World -- -- -- -- -- the Factbook uses the W
data code from DIAM 65-
-18 Geopolitical Data
Elements and Related
Features, Data Standard
No. 3, December 1994,
published by the
Defense Intelligence
Agency
Yemen YM YE YEM 887 YE
Yugoslavia* -- YU YUG 891 YU see footnote at end of
table
Zaire -- -- -- -- -- see Democratic Republic
of the Congo
Zambia ZA ZM ZWB 894 ZM
Zimbabwe ZI ZW ZWE 716 ZW
Serbia and Montenegro have asserted the formation of a joint
independent state,but this entity has not been formally
recognized as a state by the US; the US view is that the
Socialist Federal Republic of Yugoslavia (SFRY) has
dissolved and that none of the successor republics
represents its continuation.
Appendix F: Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS PUB 10-4) is maintained
by the Office of the Geographer and Global Issues (Department of State)
and published by the National Institute of Standards and Technology
(Department of Commerce). These two-character alphabetic codes are
included in the text of the Factbook in the Data code entry under the
Government category. FIPS 10-4 codes are intended for general use
throughout the US Government, especially in activities associated with
the mission of the Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166)
is prepared by the International Organization for Standardization. ISO
3166 includes two- and three-character alphabetic codes and three-digit
numeric codes that may be needed for activities involving exchange of
data with international organizations that have adopted that standard.
Except for the numeric codes, ISO 3166 codes have been adopted in the
US as FIPS 104-1: American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of
Special Sovereignty for Information Interchange.
Internet: This is a provisional compilation that generally agrees with
the ISO 3166 two-character alphabetic codes.
Entity FIPS ISO ISO ISO Interne Comment
10-4 3166 3166 3166 t
Afghanistan AF AF AFG 004 AF
Albania AL AL ALB 008 AL
Algeria AG DZ DZA 012 DZ
American AQ AS ASM 016 AS
Eritrea ER ER ERI 232 ER
Estonia EN EE EST 233 EE
Ethiopia ET ET ETH 231 ET
Europa Island EU -- -- -- -- ISO includes with the
Miscellaneous (French)
Indian Ocean Islands
Falkland FA FK FLK 238 FK
Islands
(Islas
Malvinas)
Faroe Islands FO FO FRO 234 FO
Fiji FJ FJ FJI 242 FJ
Finland FI FI FIN 246 FI
France FR FR FRA 250 FR
France, -- FX FXX 249 FX ISO limits to the European
Metropolitan part of France, excluding
French Guiana, French
Polynesia, French Southern
and Antarctic Lands,
Guadeloupe, Martinique,
Mayotte, New Caledonia,
Reunion, Saint Pierre and
Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 GF
French FP PF PYF 258 PF ISO includes Clipperton
Polynesia Island
French FS TF ATF 260 -- FIPS 10-4 does not include
Southern and the French-claimed portion
Antarctic of Antarctica (Terre Adelie)
Lands
Gabon GB GA GAB 266 GA
The Gambia GA GM GMB 270 GM
Gaza Strip GZ -- -- -- --
Georgia GG GE GEO 268 GE
Germany GM DE DEU 276 DE
Ghana GH GH GHA 288 GH
Gibraltar GI GI GIB 292 GI
Glorioso GO -- -- -- -- ISO includes with the
Islands Miscellaneous (French)
Indian Ocean Islands
Greece GR GR GRC 300 GR
Greenland GL GL GRL 304 GL
Grenada GJ GD GRD 308 GD
Guadeloupe GP GP GLP 312 GP
Guam GQ GU GUM 316 GU
Guatemala GT GT GTM 320 GT
Guernsey GK -- -- -- -- ISO includes with the United
Kingdom
Guinea GV GN GIN 324 GN
Guinea-Bissau PU GW GNB 624 GW
Guyana GY GY GUY 328 GY
Haiti HA HT HTI 332 HT
Heard Island HM HM HMD 334 HM
and McDonald
Islands
Holy See VT VA VAT 336 VA
(Vatican
City)
Honduras HO HN HND 340 HN
Hong Kong HK HK HKG 344 HK
Howland HQ -- -- -- -- ISO includes with the US
Island Minor Outlying Islands
Hungary HU HU HUN 348 HU
Iceland IC IS ISL 352 IS
India IN IN IND 356 IN
Indonesia ID ID IDN 360 ID
Iran IR IR IRN 364 IR
Iraq IZ IQ IRQ 368 IQ
Ireland EI IE IRL 372 IE
Israel IS IL ISR 376 IL
Italy IT IT ITA 380 IT
Jamaica JM JM JAM 388 JM
Jan Mayen JN -- -- -- -- ISO includes with Svalbard
Japan JA JP JPN 392 JP
Jarvis Island DQ -- -- -- -- ISO includes with the US
Minor Outlying Islands
Jersey JE -- -- -- -- ISO includes with the United
Kingdom
Johnston JQ -- -- -- -- ISO includes with the US
Atoll Minor Outlying Islands
Jordan JO JO JOR 400 JO
Juan de Nova JU -- -- -- -- ISO includes with the
Island Miscellaneous (French)
Indian Ocean Islands
Kazakhstan KZ KZ KAZ 398 KZ
Kenya KE KE KEN 404 KE
Kingman Reef KQ -- -- -- -- ISO includes with the US
Minor Outlying Islands
Kiribati KR KI KIR 296 KI
Korea, North KN KP PRK 408 KP
Korea, South KS KR KOR 410 KR
Kuwait KU KW KWT 414 KW
Kyrgyzstan KG KG KGZ 417 KG
Laos LA LA LAO 418 LA
Latvia LG LV LVA 428 LV
Lebanon LE LB LBN 422 LB
Lesotho LT LS LSO 426 LS
Liberia LI LR LBR 430 LR
Libya LY LY LBY 434 LY
Liechtenstein LS LI LIE 438 LI
Lithuania LH LT LTU 440 LT
Luxembourg LU LU LUX 442 LU
Macau MC MO MAC 446 MO
Macedonia, MK MK MKD 807 MK
The Former
Yugoslav
Republic of
Madagascar MA MG MDG 450 MG
Malawi MI MW MWI 454 MW
Malaysia MY MY MYS 458 MY
Maldives MV MV MDV 462 MV
Mali ML ML MLI 466 ML
Malta MT MT MLT 470 MT
Man, Isle of IM -- -- -- -- ISO includes with the United
Kingdom
Marshall RM MH MHL 584 MH
Islands
Martinique MB MQ MTQ 474 MQ
Mauritania MR MR MRT 478 MR
Mauritius MP MU MUS 480 MU
Mayotte MF YT MYT 175 YT
Mexico MX MX MEX 484 MX
Micronesia, FM FSM 583 FM
Federated
States of
Midway MQ -- -- -- -- ISO includes with the US
Islands Minor Outlying Islands
Miscellaneous -- -- -- -- ISO includes Bassas da
(French) India, Europa Island,
Glorioso Islands, Juan de
Nova Island, Tromelin Island
Moldova MD MD MDA 498 MD
Monaco MN MC MCO 492 MC
Mongolia MG MN MNG 496 MN
Montenegro* MW -- -- -- -- see footnote at end of table
Montserrat MH MS MSR 500 MS
Morocco MO MA MAR 504 MA
Mozambique MZ MZ MOZ 508 MZ
Myanmar -- -- -- -- -- see Burma
Namibia WA NA NAM 516 NA
Nauru NR NR NRU 520 NR
Navassa BQ -- -- -- --
Island
Nepal NP NP NPL 524 NP
Netherlands NL NL NLD 528 NL
Netherlands NT AN ANT 530 AN
Antilles
New Caledonia NC NC NCL 540 NC
New Zealand NZ NZ NZL 554 NZ
Nicaragua NU NI NIC 558 NI
Niger NG NE NER 562 NE
Nigeria NI NG NGA 566 NG
Niue NE NU NIU 570 NU
Norfolk NF NF NFK 574 NF
Island
Northern CQ MP MNP 580 MP
Mariana
Islands
Norway NO NO NOR 578 NO
Oman MU OM OMN 512 OM
Pakistan PK PK PAK 586 PK
Palau PS PW PLW 585 PW
Palmyra Atoll LQ -- -- -- -- ISO includes with the US
Minor Outlying Islands
Panama PM PA PAN 591 PA
Papua New PP PG PNG 598 PG
Paracel PF -- -- -- --
Islands
Paraguay PA PY PRY 600 PY
Peru PE PE PER 604 PE
Philippines RP PH PHL 608 PH
Pitcairn PC PN PCN 612 PN
Islands
Poland PL PL POL 616 PL
Portugal PO PT PRT 620 PT
Puerto Rico RQ PR PRI 630 PR
Qatar QA QA QAT 634 QA
Reunion RE RE REU 638 RE
Romania RO RO ROM 642 RO
Russia RS RU RUS 643 RU
Rwanda RW RW RWA 646 RW
Saint Helena SH SH SHN 654 SH
Saint Kitts SC KN KNA 659 KN
and Nevis
Saint Lucia ST LC LCA 662 LC
Saint Pierre SB PM SPM 666 PM
and Miquelon
Saint Vincent VC VC VCT 670 VC
and the
Grenadines
Samoa WS WS WSM 882 WS --
San Marino SM SM SMR 674 SM
Sao Tome and TP ST STP 678 ST
Principe
Saudi Arabia SA SA SAU 682 SA
Senegal SG SN SEN 686 SN
Serbia* SR -- -- -- -- see footnote at end of table
Serbia and -- -- -- -- -- see footnote at end of table
Montenegro*
Seychelles SE SC SYC 690 SC
Sierra Leone SL SL SLE 694 SL
Singapore SN SG SGP 702 SG
Slovakia LO SK SVK 703 SK
Slovenia SI SI SVN 705 SI
Solomon BP SB SLB 090 SB
Islands
Somalia SO SO SOM 706 SO
South Africa SF ZA ZAF 710 ZA
South Georgia SX GS SGS 239 GS
and the South
Sandwich
Islands
Spain SP ES ESP 724 ES
Spratly PG -- -- -- --
Islands
Sri Lanka CE LK LKA 144 LK
Sudan SU SD SDN 736 SD
Suriname NS SR SUR 740 SR
Svalbard SV SJ SJM 744 SJ ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 SZ
Sweden SW SE SWE 752 SE
Switzerland SZ CH CHE 756 CH
Syria SY SY SYR 760 SY
Taiwan TW TW TWN 158 TW
Tajikistan TI TJ TJK 762 TJ
Tanzania TZ TZ TZA 834 TZ
Thailand TH TH THA 764 TH
Togo TO TG TGO 768 TG
Tokelau TL TK TKL 772 TK
Tonga TN TO TON 776 TO
Trinidad and TD TT TTO 780 TT
Tobago
Tromelin TE -- -- -- -- ISO includes with the
Island Miscellaneous (French)
Indian Ocean Islands
Tunisia TS TN TUN 788 TN
Turkey TU TR TUR 792 TR
Turkmenistan TX TM TKM 795 TM
Turks and TK TC TCA 796 TC
Caicos
Islands
Tuvalu TV TV TUV 798 TV
Uganda UG UG UGA 800 UG
Ukraine UP UA UKR 804 UA
United Arab TC AE ARE 784 AE
Emirates
United UK GB GBR 826 UK/GB ISO includes Guernsey, Isle
Kingdom of Man, Jersey
United States US US USA 840 US
United States -- UM UMI 581 UM ISO includes Baker Island,
Minor Howland Island, Jarvis
Outlying Island, Johnston Atoll,
Islands Kingman Reef, Midway
Islands, Palmyra Atoll, Wake
Island
Uruguay UY UY URY 858 UY
Uzbekistan UZ UZ UZB 860 UZ
Vanuatu NH VU VUT 548 VU
Venezuela VE VE VEN 862 UE
Vietnam VM VN VNM 704 VN
Virgin VQ VI VIR 850 VI
Islands
Virgin -- -- -- -- -- see British Virgin Islands
Islands (UK)
Virgin -- -- -- -- -- see Virgin Islands
Islands (US)
Wake Atoll WQ -- -- -- -- ISO includes with the US
Minor Outlying Islands
Wallis and WF WF WLF 876 WF
Futuna
West Bank WE -- -- -- --
Western WI EH ESH 732 EH
Sahara
Western Samoa -- -- -- -- -- see Samoa
World -- -- -- -- -- the Factbook uses the W data
code from DIAM 65--18
Geopolitical Data Elements
and Related Features, Data
Standard No. 3, December
1994, published by the
Defense Intelligence Agency
Yemen YM YE YEM 887 YE
Yugoslavia* -- YU YUG 891 YU see footnote at end of table
Zaire -- -- -- -- -- see Democratic Republic of
the Congo
Zambia ZA ZM ZWB 894 ZM
Zimbabwe ZI ZW ZWE 716 ZW
Serbia and Montenegro have asserted the formation of a joint
independent state, but this entity has not been formally
recognized as a state by the US; the US view is that the
Socialist Federal Republic of Yugoslavia (SFRY) has
dissolved and that none of the successor republics
represents its continuation.
Appendix G: Cross-Reference List of Hydrographic Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note--ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic
codes similar to the Federal Information Processing Standards (FIPS)
10-4 country codes. The names and limits of the following oceans and
seas are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies.
Principal Oceans and Seas of
the World With Hydrographic
Codes by Institution
IHO IHO ACIC DIAM
23-4th 23-3rd* M 49-1 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean -- -- -- --
North Atlantic Ocean 1 23 B 1A
South Atlantic Ocean 4 32 C 2A
Baltic Sea 2 1 B26 7B
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 --
Eastern Mediterranean 3.1.2 28 B -- 8E
Western Mediterranean 3.1.1 28 A -- 8W
Pacific Ocean -- -- -- --
North Pacific Ocean 7 57 D 3A
South Pacific Ocean 8 61 E 4A
South China and Eastern 6 49 and 48 D18 plus 3U plus
Archipelagic Seas others others
ARCTIC OCEAN 9 17 A 5A
East Siberian Sea 9.1 11 A6 5S
Laptev Sea 9.2 10 A5 5P
Kara Sea 9.3 9 A4 5K
Barents Sea 9.4 7 A2 5B
White Sea 9.5 8 A3 5W
North Greenland Sea 9.6 -- -- --
Norwegian Sea 9.7 6 B30 5N
Iceland Sea 9.8 -- -- --
Davis Strait 9.9 15 B2 1V
Hudson Strait 9.10 16 A A15 1U
Hudson Bay 9.11 16 A10 1H
Baffin Bay 9.12 14 A A12 1P
Lincoln Sea 9.13 17 A A13 5L
Northwest Passages (Northwest 9.14 14 A9 5T
Passage, Northwestern
Passages)
Beaufort Sea 9.15 13 A8 5U
Chukchi Sea 9.16 12 A7 5C
James Bay -- -- A11 --
Kane Basin -- -- A14 --
ATLANTIC OCEAN (see North -- -- -- --
Atlantic Ocean and South
Atlantic Ocean)
BALTIC SEA 2 1 B26 7B
Gulf of Bothnia 2.1 1 (a) B29 7T
Gulf of Finland 2.2 1 (b) B28 7F
Gulf of Riga 2.3 1 (c) B27 7H
The Sound 2.4 2 -- --
The Great Belt 2.5 2 -- --
The Little Belt 2.6 2 -- --
Kattegat 2.7 2 B25 7K
INDIAN OCEAN 5 45 F 6A
Mozambique Channel 5.1 45 A F1 6Z
Gulf of Suez 5.2 35 F5 6W
Gulf of Aqaba 5.3 36 -- 6Q
Red Sea 5.4 37 F4 6E
Gulf of Aden 5.5 38 F3 6D
Persian Gulf (Gulf of Iran) 5.6 41 F7 6P
Gulf of Oman 5.7 40 F6 6M
Arabian Sea 5.8 39 F2 6R
Laccadive Sea (Ladshadweep 5.9 42 F9 6L
Sea)
Gulf of Mannar 5.10 -- F8 --
Palk Strait and Palk Bay 5.11 -- -- --
Bay of Bengal 5.12 43 F10 6B
Andaman Sea (Burma Sea) 5.13 44 F11 6N
Strait of Malacca (Malacca 5.14 46 (a) F12 6C
Strait)
Great Australian Bight 5.15 62 F21 6G
Suez Canal -- -- -- 6U
MEDITERRANEAN REGION 3 -- -- --
Mediterranean Sea 3.1 28 B11 --
Mediterranean Sea, Western 3.1.1 28 A -- 8W
Basin
Strait of Gibraltar 3.1.1.1 28 (a) B7 8S
Alboran Sea 3.1.1.2 28 (b) -- 8Y
Balearic Sea (Balear Sea, 3.1.1.3 28 (c) B9 8J
Iberian Sea)
Ligurian Sea (Ligure Sea) 3.1.1.4 28 (d) B10 8L
Tyrrhenian Sea (Tirreno Sea) 3.1.1.5 28 (e) B12 8T
Mediterranean Sea, Eastern 3.1.2 28 B -- 8E
Basin
Adriatic Sea 3.1.2.1 28 (g) B14 8D
Strait of Sicily (Strait of 3.1.2.2 -- -- --
Sicilia)
Ionian Sea 3.1.2.3 28 (f) B13 8N
Aegean Sea 3.1.2.4 28 (h) B15 8G
Sea of Marmara 3.2 29 B16 8M
Black Sea 3.3 30 B17 8B
Sea of Azov 3.4 31 B18 8Z
Gulf of Lion (Gulf of Lions) -- -- B8 8X
Aral Sea -- -- -- 8R
Bosporus -- -- -- 8P
Caspian Sea -- -- -- 8C
Dardanelles -- -- -- 8U
NORTH ATLANTIC OCEAN 1 23 B 1A
Skagerrak 1.1 3 B24 1S
North Sea 1.2 4 B23 1N
Inner Seas off the West Coast 1.3 18 -- 1K
of Scotland
Irish Sea and Saint Georges 1.4 19 B22 1R, 1Q
Channel
Bristol Channel 1.5 20 B21 1C
Celtic Sea 1.6 21 A -- --
English Channel 1.7 21 B20 1E
Bay of Biscay 1.8 22 B19 1B
Canarias Sea 1.9 -- -- --
Gulf of Guinea 1.10 34 C4 1G
Caribbean Sea 1.11 27 B6 1X
Gulf of Mexico 1.12 26 B5 1M
Bay of Fundy 1.13 25 B4 1F
Gulf of Saint Lawrence 1.14 24 B3 1T
Labrador Sea 1.15 15 A -- 1L
Greenland Sea 1.16 5 A1 5G
Denmark Strait -- -- B1 1D
Lake Erie -- -- -- 9E
Lake Huron -- -- -- 9H
Lake Michigan -- -- -- 9M
Lake Ontario -- -- -- 9N
Lake Superior -- -- -- 9S
Panama Canal -- -- -- 1J
Saint Lawrence Seaway -- -- -- 9L
NORTH PACIFIC OCEAN 7 57 D 3A
Philippine Sea 7.1 56 D26 3P
Taiwan Strait (Formosa 7.2 -- D17 3F
Strait)
East China Sea (Tung Hai) 7.3 50 D13 3E
Yellow Sea (Huang Hai, Hwang 7.4 51 D14 3Y
Hai)
Bo Hai (Bo Sea, Gulf of 7.5 -- D16 3X
Chihli)
Liaodong Wan (Liaodong Gulf) 7.6 -- -- --
Inland Sea of Japan (Seto 7.7 53 -- 3N
Naikai)
Sea of Japan (Japan Sea) 7.8 52 D11 3J
Gulf of Tartary 7.9 -- D10 --
Sea of Okhotsk 7.10 54 D8 3Q
Bering Sea 7.11 55 D6 5D
Anadyrskiy Zaliv (Anadyrskiy 7.12 -- -- 5Y
Gulf)
Gulf of Alaska 7.13 58 D4 5F
Coastal Waters of Southeast 7.14 59 D3 5E
Alaska and British Columbia
Gulf of California 7.15 60 D2 3L
Gulf of Panama 7.16 -- D1 --
Amurskiy Liman -- -- D27 --
Bering Strait -- -- D7 5R
Bristol Bay -- -- D5 --
Korea Bay -- -- D15 3R
Korea Strait -- -- D12 --
Sakhalinskiy Zaliv -- -- D28 3B
Zaliv Shelikhova (Zaliv -- -- D9 3K
Shelekhova)
Luzon Strait -- -- -- 3I
Tatar Strait -- -- -- 3D
PACIFIC OCEAN (see North -- -- -- --
Pacific Ocean and South
Pacific Ocean)
SOUTH ATLANTIC OCEAN 4 32 C 2A
Rio de la Plata 4.1 33 C1 2R
Drake Passage -- -- C5 2D
Golfo San Matias -- -- C2 2M
Golfo San Jorge -- -- C3 2J
Scotia Sea -- -- C6 2S
Weddell Sea -- -- C7 2W
SOUTH CHINA AND EASTERN 6 49 and 48 D18 plus 3U plus
ARCHIPELAGIC SEAS others others
South China Sea (Nan Hai) 6.1 49 D18 3U
Gulf of Tonkin 6.2 -- D19 3G
Gulf of Thailand (Gulf of 6.3 47 D20 3T
Siam)
Natuna Sea 6.4 -- -- --
Singapore Strait 6.5 46 (b) -- 3Z
Sunda Strait 6.6 -- -- --
Java Sea (Jawa Sea) 6.7 48 (n) F13 4J
Makassar Strait (Makasar 6.8 48 (m) E1 4M
Strait)
Bali Sea 6.9 48 (l) F14 4L
Flores Sea 6.10 48 (j) F16 4F
Sumba Strait 6.11 -- -- --
Savu Sea (Sawu Sea) 6.12 48 (o) F15 6S
Timor Sea 6.13 48 (i) F19 6T
Joseph Bonaparte Gulf 6.14 -- F20 --
Gulf of Carpentaria 6.15 -- E4 4P
Arafura Sea 6.16 48 (h) E3 4U
Aru Sea 6.17 -- -- --
Banda Sea 6.18 48 (g) E2 4B
Teluk Bone (Gulf of Bone, 6.19 48 (k) F17 4E
Gulf of Boni)
Ceram Sea (Seram Sea) 6.20 48 (f) D25 4Q
Gulf of Berau 6.21 -- -- --
Halmahera Sea 6.22 48 (e) D24 3H
Molucca Sea (Molukka Sea, 6.23 48 (c) D23 3M
Maluku Sea)
Teluk Tomini (Gulf of Tomini) 6.24 48 (d) F18 3V
Sulawesi Sea 6.25 -- -- --
Mindanao Sea 6.26 -- -- --
Sulu Sea 6.27 48 (a) D21 3S
Celebes Sea -- 48 (b) D22 3C
SOUTH PACIFIC OCEAN 8 61 E 4A
Bismarck Sea 8.1 66 E6 4K
Solomon Sea 8.2 65 E7 4S
Torres Strait 8.3 -- E5 --
Coastal Waters of Great 8.4 -- -- --
Barrier Reefs
Coral Sea 8.5 64 E9 4C
Tasman Sea 8.6 63 E10 4T
Bass Strait 8.7 62 A F22 6F
Amundsen Sea -- -- E12 4D
Bellingshausen Sea -- -- E13 4G
Cook Strait -- -- E8 --
Ross Sea -- -- E11 4R
* The letters after the numbers are subdivisions, not footnotes.
=====================================================================
Appendix H: Cross-Reference List of Geographic Names
This list indicates where various geographic names--including
the location of all United States Foreign Service Posts,
alternate names of countries, former names, and political or
geographical portions of larger entities--can be found in The
World Factbook. Spellings are normally those approved by the
US Board on Geographic Names (BGN). Additional information
is included in brackets.
Name Entry in The Latitude Longitude
World Factbook (deg min)(deg min)
A Abidjan [US Embassy] Cote d''Ivoire 5 19 N 4 02 W
Abkhazia [region] Georgia 43 00 N 41 00 E
Abu Dhabi [US Embassy] United Arab 24 28 N 54 22 E
Emirates
Abu Musa [island] Iran 25 52 N 55 03 E
Abuja [US Embassy Branch Nigeria 9 12 N 7 11 E
Office]
Abyssinia Ethiopia 8 00 N 38 00 E
Acapulco Mexico 16 51 N 99 55 W
Accra [US Embassy] Ghana 5 33 N 0 13 W
Adamstown Pitcairn Islands 25 04 S 130 05 W
Adana [US Consulate] Turkey 37 01 N 35 18 E
Addis Ababa [US Embassy] Ethiopia 9 02 N 38 42 E
Adelie Land (Terre Antarctica 66 30 S 139 00 E
Adelie) [claimed by
France]
Aden Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States 57 44 N 134 20 W
(Alaska)
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Djibouti 11 30 N 43 00 E
Territory of the
(F.T.A.I.)
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (see Hagatna) Guam 13 28 N 144 45 E
Ajaccio France (Corsica) 41 55 N 8 44 E
Akmola (see Astana) Kazakhstan 51 10 N 71 30 E
Aland Islands Finland 60 15 N 20 00 E
Alaska United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Aldabra Islands (Groupe Seychelles 9 25 S 46 22 E
d''Aldabra)
Alderney [island] Guernsey 49 43 N 2 12 W
Aleutian Islands United States 52 00 N 176 00 W
(Alaska)
Alexander Archipelago United States 57 00 N 134 00 W
(Alaska)
Alexander Island Antarctica 71 00 S 70 00 W
Alexandria Egypt 31 12 N 29 54 E
Algiers [US Embassy] Algeria 36 47 N 2 03 E
Alhucemas, Penon de Spain 35 13 N 3 53 W
Alma-Ata (see Almaty) Kazakhstan 43 15 N 76 57 E
Almaty [US Embassy] Kazakhstan 43 15 N 76 57 E
Alofi Niue 19 01 S 169 55 E
Alphonse Island Seychelles 7 01 S 52 45 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands India 11 3','d4dda65460ebf03316d6bebf67a1c0a972586d199b7ef915581ee9bbb15f9d7c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d9aa4e8e5795177e86a18a8bf2e4bd5815e818e34644f846f075c873611741',1999,'GN','Guinea','communications',408,'0 N 72 30 E
Amirante Isles (Les Seychelles 6 00 S 53 10 E
Amirantes)
Amman [US Embassy] Jordan 31 57 N 35 56 E
Amsterdam [US Consulate Netherlands 52 22 N 4 54 E
General]
Amsterdam Island (Ile French Southern 37 52 S 77 32 E
Amsterdam) and Antarctic
Lands
Amundsen Sea Pacific Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Anatolia [region] Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella Andorra 42 30 N 1 30 E
Andros [island] Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat [ruins] Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan Sudan 15 00 N 30 00 E
Anjouan [island] Comoros 12 15 S 44 25 E
Ankara [US Embassy] Turkey 39 56 N 32 52 E
Annobon [island] Equatorial 1 25 S 5 36 E
Antananarivo [US Madagascar 18 52 S 47 30 E
Embassy]
Antigua [island] Antigua and 14 34 N 90 44 W
Barbuda
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp [European Belgium 51 13 N 4 25 E
Logistical Support
Office]
Aozou Strip Chad 22 00 N 18 00 E
Apia [US Embassy] Samoa 13 50 S 171 44 N
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Aqmola (see Astana) Kazakhstan 51 10 N 71 30 E
Arab, Shatt al [river] Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, 45 00 N 60 00 E
Biscay, Bay of Atlantic Ocean 44 00 N 4 00 W
Bishkek [US Embassy] Kyrgyzstan 42 54 N 74 36 E
Bishop Rock United Kingdom 49 52 N 6 27 W
Bismarck Archipelago Papua New Guinea 5 00 S 150 00 E
Bismarck Sea Pacific Ocean 4 00 S 148 00 E
Bissau [US Embassy] Guinea-Bissau 11 51 N 15 35 W
Bjornoya (Bear Island) Svalbard 74 26 N 19 5 E
Black Forest Germany 48 00 N 8 15 E
Black Rock South Georgia 53 39 S 41 48 W
and the South
Sandwich Islands
Black Sea Atlantic Ocean 43 00 N 35 00 E
Bloemfontein South Africa 29 12 S 26 07 E
Boa Vista [island] Cape Verde 16 05 N 22 50 W
Bogota [US Embassy] Colombia 4 36 N 74 05 W
Bohemia [region] Czech Republic 50 00 N 14 30 E
Bombay (see Mumbai) India 18 58 N 72 50 E
Bonaire [island] Netherlands 12 10 N 68 15 W
Antilles
Bonifacio, Strait of Atlantic Ocean 41 01 N 14 00 E
Bonin Islands Japan 27 00 N 140 10 E
Bonn [US Embassy] Germany 50 44 N 7 05 E
Bophuthatswana South Africa 26 30 S 25 30 E
Bora-Bora [island] French Polynesia 16 30 S 151 45 W
Bordeaux France 44 50 N 0 34 W
Borneo [island] Brunei, 0 30 N 114 00 E
Indonesia,
Cosmoledo Group (Atoll Seychelles 9 43 S 47 35 E
de Cosmoledo)
Cotonou [US Embassy] Benin 6 21 N 2 26 E
Courantyne River Guyana, Suriname 5 57 N 57 06 W
Crete [island] Greece 35 15 N 24 45 E
Crimea [region] Ukraine 45 00 N 34 00 E
Crimean Peninsula Ukraine 45 00 N 34 00 E
Crooked Island Passage Atlantic Ocean 22 55 N 74 35 W
Crozet Islands (Iles French Southern 46 30 S 51 00 E
Crozet) and Antarctic
Lands
Curacao [US Consulate Netherlands 12 11 N 69 00 W
General] Antilles
Cyclades [islands] Greece 37 00 N 25 10 E
Czechoslovakia Czech Republic, 49 00 N 18 00 E
Enderbury Island Kiribati 3 08 S 171 5 W
Enewetak Atoll (Eniwetok Marshall Islands 11 30 N 162 15 E
Atoll)
England [region] United Kingdom 52 30 N 1 30 W
English Channel Atlantic Ocean 50 20 N 1 00 W
Eniwetok Atoll (see Marshall Islands 11 30 N 162 15 E
Enewetak Atoll)
Eolie, Isole Italy 38 30 N 15 00 E
Epirus, Northern Albania, Greece 40 00 N 20 30 E
Espana Spain 40 00 N 4 00 W
Essequibo [region] Guyana 6 59 N 58 23 W
[claimed by Venezuela]
Etorofu (Iturup) Russia [de 44 55 N 147 40 E
[island] facto]
F Farquhar Group (Atoll de Seychelles 10 10 S 51 10 E
Farquhar)
Fernando de Noronha Brazil 3 51 S 32 25 W
Fernando Po [island] Equatorial 3 30 N 8 42 E
(see Bioko) Guinea
Finland, Gulf of Atlantic Ocean 60 00 N 27 00 E
Florence [US Consulate Italy 43 46 N 11 15 E
General]
Florida, Straits of Atlantic Ocean 25 00 N 79 45 W
former Soviet Union Armenia,
(FSU) Azerbaijan,
Belarus,
Estonia,
Georgia,
Kazakhstan,
Kyrgyzstan,
Latvia,
Lithuania,
Moldova, Russia,
Tajikistan,
Turkmenistan,
Ukraine,
Malacca, Strait of Indian Ocean 2 30 N 101 20 E
Malagasy Republic Madagascar 20 00 S 47 00 E
Male Maldives 4 10 N 73 31 E
Mallorca (Majorca) Spain 39 30 N 3 00 E
Malpelo, Isla de Colombia 4 00 N 90 30 W
Malta Channel Atlantic Ocean 56 44 N 26 53 E
Malvinas, Islas Falkland Islands 51 45 S 59 00 W
(Islas Malvinas)
Mamoutzou Mayotte 12 47 S 45 14 E
Managua [US Embassy] Nicaragua 12 09 N 86 17 W
Manama [US Embassy] Bahrain 26 13 N 50 35 E
Manaus [US Consular Brazil 3 08 S 60 01 W
Agency]
Manchukuo China 44 00 N 124 00 E
Manchuria China 44 00 N 124 00 E
Manila [US Embassy] Philippines 14 35 N 121 00 E
Manipa Strait Pacific Ocean 3 20 S 127 23 E
Mannar, Gulf of Indian Ocean 8 30 N 79 00 E
Manua Islands American Samoa 14 13 S 169 35 W
Maputo [US Embassy] Mozambique 25 58 S 32 35 E
Marcus Island (Minami- Japan 24 16 N 154 00 E
tori-shima)
Mariana Islands Guam, Northern 16 00 N 145 30 E
Mariana Islands
Marion Island South Africa 46 51 S 37 52 E
Marmara, Sea of Atlantic Ocean 40 40 N 28 15 E
Marquesas Islands (Iles French Polynesia 9 00 S 139 30 W
Marquises)
Marseille [US Consulate France 43 18 N 5 24 E
General]
Martin Vaz, Ilhas Brazil 20 30 S 28 51 W
Mas a Tierra (Robinson Chile 33 38 S 78 52 W
Crusoe Island)
Mascarene Islands Mauritius, 21 00 S 57 00 E
Reunion
Maseru [US Embassy] Lesotho 29 28 S 27 30 E
Matamoros [US Consulate] Mexico 25 53 N 97 30 W
Mata-Utu Wallis and 13 57 S 171 56 W
Futuna
Matsu [island] Taiwan 26 13 N 119 56 E
Matthew Island New Caledonia, 22 20 S 171 20 E
Riyadh [US Embassy] Saudi Arabia 24 38 N 46 43 E
Road Town British Virgin 18 27 N 64 37 W
Islands
Robinson Crusoe Island Chile 33 38 S 78 52 W
(Mas a Tierra)
Rocas, Atol das Brazil 3 51 S 33 49 W
Rockall [island] United Kingdom 57 35 N 13 48 W
Rodrigues [island] Mauritius 19 42 S 63 25 E
Rome [US Embassy, US Italy 41 54 N 12 29 E
Mission to the UN
Agencies for Food and
Agriculture (FODAG)]
Roncador Cay Colombia 13 32 N 80 03 W
Roosevelt Island Antarctica 79 30 S 162 00 W
Roseau Dominica 15 18 N 61 24 W
Ross Dependency [claimed Antarctica 80 00 S 180 00 E
by New Zealand]
Ross Island Antarctica 81 30 S 175 00 W
Ross Sea Antarctica 76 00 S 175 00 W
Rota [island] Northern Mariana 14 10 N 145 12 E
Islands
Rotuma [island] Fiji 12 30 S 177 30 E
Ryukyu Islands Japan 26 30 N 128 00 E
S Saba [island] Netherlands 17 38 N 63 10 W
Antilles
Sabah [state] Malaysia 5 20 N 117 10 E
Sable Island Canada 43 55 N 59 50 W
Safety Islands (Iles du French Guiana 5 20 N 52 37 W
Salut)
Sahel Burkina Faso, 15 00 N 8 00 W
Cape Verde,
Chad, The
Gambia, Guinea-
Bissau, Mali,
Mauritania,
Niger, Senegal
Saigon (see Ho Chi Minh Vietnam 10 45 N 106 40 E
City)
Saint Brandon (Cargados Mauritius 16 25 S 59 38 E
Carajos Shoals)
Saint Christopher Saint Kitts and 17 20 N 62 45 W
[island] Nevis
Saint Christopher and Saint Kitts and 17 20 N 62 45 W
Nevis Nevis
Saint-Denis Reunion 20 52 S 55 28 E
Saint George''s [US Grenada 12 03 N 61 45 W
Embassy]
Saint George''s Channel Atlantic Ocean 52 00 N 6 00 W
Saint Helier Jersey 49 12 N 2 37 W
Saint John''s Antigua and 17 06 N 61 51 W
Barbuda
Saint Lawrence, Gulf of Atlantic Ocean 48 00 N 62 00 W
Saint Lawrence Island United States 49 30 N 67 00 W
Saint Lawrence Seaway Atlantic Ocean 49 15 N 67 00 W
Saint Martin [island] Guadeloupe 18 04 N 63 04 W
Saint Martin (Sint Netherlands 18 04 N 63 04 W
Maarten) Antilles
Saint Paul Island Canada 47 12 N 60 09 W
Saint Paul Island United States 57 11 N 170 16 W
Saint Paul Island (Ile French Southern 38 43 S 77 29 E
Saint-Paul) and Antarctic
Lands
Saint Peter and Saint Brazil 0 23 N 29 23 W
Paul Rocks (Penedos de
Sao Pedro e Sao Paulo)
Saint Peter Port Guernsey 49 27 N 2 32 W
Saint Petersburg [US Russia 59 55 N 30 15 E
Consulate General]
Saint-Pierre Saint Pierre and 46 46 N 56 11 W
Miquelon
Saint Thomas [island] Virgin Islands 18 21 N 64 55 W
Saint Vincent Passage Atlantic Ocean 13 30 N 61 00 W
Saipan [island] Northern Mariana 15 12 N 145 45 E
Islands
Sakishima Islands Japan 24 30 N 124 00 E
Sakhalin Island (Ostrov Russia 51 00 N 143 00 E
Sakhalin)
Sala y Gomez, Isla Chile 26 28 S 105 00 W
Salisbury (see Harare) Zimbabwe 17 50 S 105 00 W
Salvador de Bahia [US Brazil 12 59 S 38 31 W
Consular Agency]
Salzburg Austria 47 48 N 13 02 E
Samar [island] Philippines 12 00 N 125 00 E
Samaria [region] West Bank 32 15 N 35 10 E
Samoa Islands American Samoa, 14 00 S 171 00 W
Spanish Morocco Morocco 32 00 N 7 00 W
Spanish North Africa Spain (Ceuta, 35 15 N 4 00 W
Islas
Chafarinas,
Melilla, Penon
de Alhucemas,
Penon de Velez
de la Gomera)
Spanish Sahara Western Sahara 24 30 N 13 00 W
Spice Islands (Moluccas) Indonesia 2 00 S 28 00 E
Spitsbergen [island] Svalbard 78 00 N 20 00 E
Stanley Falkland Islands 51 42 S 57 41 W
(Islas Malvinas)
Stockholm [US Embassy] Sweden 59 20 N 18 03 E
Strasbourg [US Consulate France 48 35 N 7 45 E
General]
Stuttgart Germany 48 46 N 9 11 E
Sucre Bolivia 19 02 S 65 17 W
Suez Canal Egypt 29 55 N 32 33 E
Suez, Gulf of Indian Ocean 28 10 N 33 27 E
Sulu Archipelago Philippines 6 00 N 121 00 E
Sulu Sea Pacific Ocean 8 00 N 120 00 E
Sumatra [island] Indonesia 0 00 N 102 00 E
Sumba [island] Indonesia 10 00 S 120 00 E
Sunda Islands (Soenda Indonesia, 2 00 S 110 00 E
Isles) Malaysia
Sunda Strait Indian Ocean 6 00 S 105 45 E
Surabaya [US Consulate Indonesia 7 15 S 112 45 E
General]
Surigao Strait Pacific Ocean 10 15 N 125 23 E
Surinam Suriname 4 00 N 56 00 W
Suva [US Embassy] Fiji 18 08 S 178 25 E
Sverdlovsk (see Russia 56 50 N 60 39 E
Yekaterinburg)
Swains Island American Samoa 11 3 S 171 15 W
Swan Islands Honduras 17 25 S 83 56 W
Sydney [US Consulate Australia 33 52 S 151 13 E
General]
T Tahiti [island] French Polynesia 17 37 S 149 27 W
Taipei Taiwan 25 03 N 121 30 E
Taiwan Strait Pacific Ocean 24 00 N 119 00 E
Tallinn [US Embassy] Estonia 59 25 N 24 45 E
Tanganyika Tanzania 6 00 S 35 00 E
Tangier Morocco 35 48 N 5 45 W
Tarawa [island] Kiribati 1 25 N 173 00 E
Tatar Strait Pacific Ocean 50 00 N 141 00 E
Tashkent [US Embassy] Uzbekistan 41 20 N 69 18 E
Tasmania [island] Australia 43 00 S 147 00 E
Tasman Sea Pacific Ocean 4 30 S 168 00 E
Taymyr Peninsula Russia 76 00 N 104 00 E
(Poluostrov Taymyr)
T''bilisi [US Embassy] Georgia 41 43 N 44 49 E
Tegucigalpa [US Embassy] Honduras 14 06 N 87 13 W
Tehran [US post not Iran 35 40 N 51 26 E
maintained;
representation by Swiss
Embassy]
Tel Aviv [US Embassy] Israel 32 05 N 34 48 E
Terre Adelie (Adelie Antarctica 66 30 S 139 00 E
Land) [claimed by
France]
Thailand, Gulf of Pacific Ocean 10 00 N 101 00 E
Thessaloniki [US Greece 40 38 N 22 56 E
Consulate General]
Thimphu Bhutan 27 28 N 89 39 E
Thuringia [region] Germany 51 00 N 11 00 E
Thurston Island Antarctica 72 20 S 99 00 W
Tiberias, Lake Israel 32 48 N 35 35 E
Tibet (Xizang) China 32 00 N 90 00 E
Tibilisi (see T''bilisi) Georgia 41 43 N 44 49 E
Tien Shan [mountains] China, 42 00 N 80 00 E','4ebe1ca5602395204eee512a564e75715238e44bd6a4944511462b5999aac63f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d6efcf2696cba957b776b29896e0579aeebb9834dfe73b0b1df1b81701ad7cd',1999,'GB','United Kingdom','communications',409,'Guinea GV GN GIN 324 GN
Guinea-Bissau PU GW GNB 624 GW
Guyana GY GY GUY 328 GY
Haiti HA HT HTI 332 HT
Heard Island HM HM HMD 334 HM
and McDonald
Islands
Holy See VT VA VAT 336 VA
(Vatican
City)
Honduras HO HN HND 340 HN
Hong Kong HK HK HKG 344 HK
Howland HQ -- -- -- -- ISO includes with the
Island US Minor Outlying
Islands
Hungary HU HU HUN 348 HU
Iceland IC IS ISL 352 IS
India IN IN IND 356 IN
Indonesia ID ID IDN 360 ID
Iran IR IR IRN 364 IR
Iraq IZ IQ IRQ 368 IQ
Ireland EI IE IRL 372 IE
Israel IS IL ISR 376 IL
Italy IT IT ITA 380 IT
Jamaica JM JM JAM 388 JM
Jan Mayen JN -- -- -- -- ISO includes with
Svalbard
Japan JA JP JPN 392 JP
Jarvis Island DQ -- -- -- -- ISO includes with the
US Minor Outlying
Islands
Jersey JE -- -- -- -- ISO includes with the
Johnston JQ -- -- -- -- ISO includes with the
Atoll US Minor Outlying
Islands
Jordan JO JO JOR 400 JO
Juan de Nova JU -- -- -- -- ISO includes with the
Island Miscellaneous (French)
Indian Ocean Islands
Kazakhstan KZ KZ KAZ 398 KZ
Kenya KE KE KEN 404 KE
Kingman Reef KQ -- -- -- -- ISO includes with the
US Minor Outlying
Islands
Kiribati KR KI KIR 296 KI
Korea, North KN KP PRK 408 KP
Korea, South KS KR KOR 410 KR
Kuwait KU KW KWT 414 KW
Kyrgyzstan KG KG KGZ 417 KG
Laos LA LA LAO 418 LA
Latvia LG LV LVA 428 LV
Lebanon LE LB LBN 422 LB
Lesotho LT LS LSO 426 LS
Liberia LI LR LBR 430 LR
Libya LY LY LBY 434 LY
Liechtenstein LS LI LIE 438 LI
Lithuania LH LT LTU 440 LT
Luxembourg LU LU LUX 442 LU
Macau MC MO MAC 446 MO
Macedonia, MK MK MKD 807 MK
The Former
Yugoslav
Republic of
Madagascar MA MG MDG 450 MG
Malawi MI MW MWI 454 MW
Malaysia MY MY MYS 458 MY
Maldives MV MV MDV 462 MV
Mali ML ML MLI 466 ML
Malta MT MT MLT 470 MT
Man, Isle of IM -- -- -- -- ISO includes with the
Marshall RM MH MHL 584 MH
Islands
Martinique MB MQ MTQ 474 MQ
Mauritania MR MR MRT 478 MR
Mauritius MP MU MUS 480 MU
Mayotte MF YT MYT 175 YT
Mexico MX MX MEX 484 MX
Micronesia, FM FSM 583 FM
Federated
States of
Midway MQ -- -- -- -- ISO includes with the
Islands US Minor Outlying
Islands
Miscellaneous -- -- -- -- ISO includes Bassas da
(French) India, Europa Island,
Glorioso Islands, Juan
de Nova Island,
Tromelin Island
Moldova MD MD MDA 498 MD
Monaco MN MC MCO 492 MC
Mongolia MG MN MNG 496 MN
Montenegro* MW -- -- -- -- see footnote at end of
table
Montserrat MH MS MSR 500 MS
Morocco MO MA MAR 504 MA
Mozambique MZ MZ MOZ 508 MZ
Myanmar -- -- -- -- -- see Burma
Namibia WA NA NAM 516 NA
Nauru NR NR NRU 520 NR
Navassa BQ -- -- -- --
Island
Nepal NP NP NPL 524 NP
Netherlands NL NL NLD 528 NL
Netherlands NT AN ANT 530 AN
Antilles
New Caledonia NC NC NCL 540 NC
New Zealand NZ NZ NZL 554 NZ
Nicaragua NU NI NIC 558 NI
Niger NG NE NER 562 NE
Nigeria NI NG NGA 566 NG
Niue NE NU NIU 570 NU
Norfolk NF NF NFK 574 NF
Island
Northern CQ MP MNP 580 MP
Mariana
Islands
Norway NO NO NOR 578 NO
Oman MU OM OMN 512 OM
Pakistan PK PK PAK 586 PK
Palau PS PW PLW 585 PW
Palmyra Atoll LQ -- -- -- -- ISO includes with the
US Minor Outlying
Islands
Panama PM PA PAN 591 PA
Papua New PP PG PNG 598 PG','0e8b91dc1380a05d1d20c62c75de2c447dc249522d8eaefd2ec9f175ef8c728e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f18b91f41eabe874a68c4ef30605bb38a1110a0450a1133c44c515d920766a6',1999,'UZ','Uzbekistan','communications',410,'Argun River China, Russia 53 20 N 121 28 E
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat [US Embassy] Kozakhstan 51 00 N 71 30 E
Ashkhabad (see Ashgabat) Turkmenistan 37 57 N 58 23 E
Asmara [US Embassy] Eritrea 15 20 N 38 53 E
Asmera (see Asmara) Eritrea 15 20 N 38 53 E
Assumption Island Seychelles 9 46 S 46 34 E
Astana (Akmola) Kazakhstan 51 10 N 71 30 E
Asuncion [US Embassy] Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana 19 40 N 145 24 E
Islands
Atacama [region] Chile 24 30 S 69 15 W
Athens [US Embassy] Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland [US Consulate New Zealand 36 52 S 174 46 E
General]
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (Iles French Polynesia 23 20 S 151 00 W
Tubuai)
Avarua Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir Pakistan 34 30 N 74 00 E
Azores [islands] Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
B Bab el Mandeb [strait] Indian Ocean 12 40 N 43 20 E
Babuyan Channel Pacific Ocean 18 44 N 121 40 E
Babuyan Islands Philippines 19 10 N 121 40 E
Baffin Bay Arctic Ocean 73 00 N 66 00 W
Baffin Island Canada 68 00 N 70 00 W
Baghdad [US Embassy Iraq 33 21 N 44 25 E
temporarily suspended;
US Interests Section
located in Poland''s
embassy in Baghdad]
Baki (see Baku) Azerbaijan 40 23 N 49 51 E
Baku [US Embassy] Azerbaijan 40 23 N 49 51 E
Baky (see Baku) Azerbaijan 40 23 N 49 51 E
Balabac Strait Pacific Ocean 7 35 N 117 00 E
Balearic Islands Spain 39 30 N 3 00 E
Balearic Sea (Iberian Atlantic Ocean 40 30 N 2 00 E
Sea)
Bali [island] Indonesia 8 20 S 115 00 E
Bali Sea Indian Ocean 7 45 S 115 30 E
Balintang Channel Pacific Ocean 19 49 N 121 40 E
Balintang Islands Philippines 19 55 N 122 10 E
Balkan Peninsula Albania, Bosnia 42 00 N 23 00 E
and Herzegovina,
Bulgaria,
Croatia, Greece,
Romania, Serbia
and Montenegro,
Slovenia, The
Former Yugoslav
Republic of
Macedonia,
Turkey (European
part)
Balleny Islands Antarctica 67 00 S 163 00 E
Balochistan [region] Pakistan 28 00 N 63 00 E
Baltic Sea Atlantic Ocean 57 00 N 19 00 E
Bamako [US Embassy] Mali 12 39 N 8 00 W
Banaba (Ocean Island) Kiribati 0 52 S 169 35 E
Bandar Seri Begawan [US Brunei 4 52 S 114 55 E
Embassy]
Banda Sea Pacific Ocean 5 00 S 128 00 E
Bangkok [US Embassy] Thailand 13 45 N 100 31 E
Bangui [US Embassy] Central African 4 22 N 18 35 E
Republic
Banjul [US Embassy] The Gambia 13 28 N 16 39 W
Banks Island Australia 10 12 S 142 16 E
Banks Island Canada 75 15 N 121 30 W
Banks Islands (Iles Vanuatu 14 00 S 167 30 E
Banks)
Barbuda [island] Antigua and 17 38 N 61 48 W
Barbuda
Barcelona [US Consulate Spain 41 23 N 2 11 E
General]
Barents Sea Arctic Ocean 74 00 N 36 00 E
Barranquilla Colombia 10 59 N 74 48 W
Bashi Channel Pacific Ocean 22 00 N 121 00 E
Basilan Strait Pacific Ocean 6 49 N 122 05 E
Basque Provinces Spain 43 00 N 2 30 W
Bass Strait Pacific Ocean 39 20 S 145 30 E
Basse-Terre Guadeloupe 16 00 N 61 44 W
Basseterre Saint Kitts and 17 18 N 62 43 W
Nevis
Bastia France (Corsica) 42 42 N 9 27 E
Basutoland Lesotho 29 30 S 28 30 E
Batan Islands Philippines 20 30 N 121 50 E
Bavaria (Bayern) Germany 48 30 N 11 30 E
Beagle Channel Atlantic Ocean 54 53 S 68 10 W
Bear Island (see Svalbard 74 26 N 19 5 E
Bjornoya)
Beaufort Sea Arctic Ocean 73 00 N 140 00 W
Bechuanaland Botswana 22 00 S 24 00 E
Beijing [US Embassy] China 39 56 N 116 24 E
Beirut [US Embassy] Lebanon 33 53 N 35 30 E
Belau (Palau Islands) Palau 7 30 N 134 30 E
Belem [US Consular Brazil 1 27 S 48 29 W
Agency]
Belep Islands (Iles New Caledonia 19 45 S 163 40 E
Belep)
Belfast [US Consulate United Kingdom 54 35 N 5 55 W
General]
Belgian Congo Democratic 0 00 N 25 00 E
Republic of the
Formosa [island] Taiwan 23 30 N 121 00 E
Formosa Strait (see Pacific Ocean 24 00 N 119 00 E
Taiwan Strait)
Fortaleza [US Consular Brazil 3 43 S 38 30 W
Agency]
Fort-de-France Martinique 14 36 N 61 05 W
Frankfurt am Main [US Germany 50 07 N 8 40 E
Consulate General]
Franz Josef Land Russia 81 00 N 55 00 E
[islands]
Freetown [US Embassy] Sierra Leone 8 30 N 13 15 W
French Cameroon Cameroon 6 00 N 12 00 E
French Guinea Guinea 11 00 N 10 00 W
French Indochina Cambodia, Laos, 15 00 N 107 00 E
Vietnam
French Morocco Morocco 32 00 N 5 00 W
French Somaliland Djibouti 11 30 N 43 00 W
French Sudan Mali 17 00 N 4 00 W
French Territory of the Djibouti 11 30 N 43 00 E
Afars and Issas
(F.T.A.I.)
French Togo Togo 8 00 N 1 10 E
French West Indies Guadeloupe, 16 30 N 62 00 W
Spanish Guinea Equatorial 2 00 N 10 00 E
United Arab Republic Egypt, Syria
(UAR)
Upper Volta Burkina Faso 13 00 N 2 00 W
Ural Mountains Kazakhstan, 60 00 N 60 00 E
Russia
Ussuri River China, Russia 48 28 N 135 02 E
V Vaduz Liechtenstein 47 09 N 9 31 E
Vakhan (Wakhan Corridor) Afghanistan 37 00 N 73 00 E
Valletta [US Embassy] Malta 35 54 N 14 31 E
Valley, The Anguilla 18 13 N 63 04 W
Vancouver [US Consulate Canada 49 16 N 123 07 W
General]
Vancouver Island Canada 49 45 N 126 00 W
Van Diemen Strait (Osumi Pacific Ocean 31 00 N 131 00 E
Strait)
Vatican City [US Holy See 41 54 N 12 27 E
Embassy]
Velez de la Gomera, Spain 35 11 N 4 18 W
Penon de
Venda South Africa 23 00 S 31 00 E
Verde Island Passage Pacific Ocean 13 34 N 120 51 E
Victoria Hong Kong 22 17 N 114 09 E
Victoria Seychelles 4 38 S 55 27 E
Vienna [US Embassy, US Austria 48 12 N 16 22 E
Mission to International
Organizations in Vienna
(UNVIE)]
Vientiane [US Embassy] Laos 17 58 N 102 36 E
Vilnius [US Embassy] Lithuania 54 41 N 25 19 E
Viti Levu [island] Fiji 18 00 S 178 00 E
Vladivostok [US Russia 43 10 N 131 56 E
Consulate General]
Volcano Islands Japan 25 00 N 141 00 E
Vostok Island Kiribati 10 06 S 152 23 W
Vrangelya, Ostrov Russia 71 14 N 179 36 W
(Wrangel Island)
W Wake Island Wake Atoll 19 17 N 166 36 E
Wakhan Corridor (see Afghanistan 37 00 N 73 00 E
Vakhan)
Wales [region] United Kingdom 52 30 N 3 30 W
Wallis Islands Wallis and 13 17 S 176 10 W
Futuna
Walvis Bay Namibia 22 59 S 14 31 E
Warsaw [US Embassy] Poland 52 15 N 21 00 E
Washington, DC [US United States 38 53 N 77 02 W
Mission to the
Organization of American
States (OAS)]
Weddell Sea Atlantic Ocean 72 00 S 45 00 W
Wellington [US Embassy] New Zealand 41 28 S 174 51 E
West Frisian Islands Netherlands 53 26 N 5 30 E
West Germany (Federal Germany 53 22 N 5 20 E
Republic of Germany)
West Island Cocos (Keeling) 12 10 S 96 55 E
Islands
West Korea Strait Pacific Ocean 34 40 N 129 00 E
(Western Channel)
West Pakistan Pakistan 30 00 N 70 00 E
West Siberian Plain Russia 60 00 N 75 00 E
Western Channel (West Pacific Ocean 34 40 N 129 00 E
Korea Strait)
Western Samoa Samoa 13 35 S 172 20 W
Wetar Strait Pacific Ocean 8 20 S 126 30 E
White Sea Arctic Ocean 65 30 N 38 00 E
Willemstad Netherlands 12 06 N 68 56 W
Antilles
Windhoek [US Embassy] Namibia 22 34 S 17 06 E
Windward Passage Atlantic Ocean 20 00 N 73 50 W
Wrangel Island (Ostrov Russia 71 14 N 179 36 W
Vrangelya)
Y Yalu River China, North 39 55 N 124 20 E
Korea
Yamoussoukro Cote d''Ivoire 6 49 N 5 17 W
Yangon (see Rangoon) Burma 16 47 N 96 10 E
Yaounde [US Embassy] Cameroon 3 52 N 11 31 E
Yap Islands Federated States 9 30 N 138 00 E
of Micronesia
Yaren Nauru 0 32 S 166 55 E
Yekaterinburg Russia 56 50 N 60 39 E
(Sverdlovsk) [US
Consulate General]
Yellow Sea Pacific Ocean 36 00 N 123 00 E
Yemen (Aden) [People''s Yemen 14 00 N 46 00 E
Democratic Republic of
Yemen]
Yemen Arab Republic Yemen 15 00 N 44 00 E
Yemen, North [Yemen Arab Yemen 15 00 N 44 00 E
Republic]
Yemen (Sanaa) [Yemen Yemen 15 00 N 44 00 E
Arab Republic]
Yemen, People''s Yemen 14 00 N 46 00 E
Democratic Republic of
Yemen, South [People''s Yemen 14 00 N 46 00 E
Democratic Republic of
Yemen]
Yerevan [US Embassy] Armenia 40 11 N 44 30 E
Youth, Isle of (Isla de Cuba 21 40 N 82 50 W
la Juventud)
Yucatan Peninsula Mexico 19 30 N 89 00 W
Yucatan Channel Atlantic Ocean 21 45 N 85 45 W
Yugoslavia Bosnia and
Herzegovina,
Croatia, The
Former Yugoslav
Republic of
Macedonia,
Serbia and
Montenegro,','0586ce4b55ad5a8fb20aca7e895c3a5ae438e2d880bd4ae0a9954d10e0d52a20','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6bd49daa2ce5082140faf3655243ce5b6028ef08ae1cb12113168339485d160',1999,'ME','Montenegro','communications',411,'Belize City [US Embassy] Belize 17 30 N 88 12 W
Belle Isle, Strait of Atlantic Ocean 51 35 N 56 30 W
Bellingshausen Sea Pacific Ocean 71 00 S 85 00 W
Belmopan Belize 17 15 N 88 46 W
Belorussia Belarus 53 00 N 28 00 E
Bengal, Bay of Indian Ocean 15 00 N 90 00 E
Bering Sea Pacific Ocean 60 00 N 175 00 W
Bering Island Russia 55 00 N 166 30 E
Bering Strait Pacific Ocean 65 30 N 169 00 W
Berkner Island Antarctica 79 30 S 49 30 W
Berlin [US Branch Germany 52 31 N 13 24 E
Office]
Berlin, East Germany 52 30 N 13 33 E
Berlin, West Germany 52 30 N 12 20 E
Bern [US Embassy] Switzerland 46 57 N 7 26 E
Bessarabia [region] Romania, 47 00 N 28 30 E
Moldova, Ukraine
Bhopal India 23 16 N 77 24 E
Biafra [region] Nigeria 5 30 N 7 30 E
Big Diomede Island Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos Guinea-Bissau 11 25 N 16 20 W
Bikini Atoll Marshall Islands 11 35 N 165 23 E
Bilbao Spain 43 15 N 2 58 W
Bioko [island] Equatorial 3 30 N 8 42 E
Kowloon Hong Kong 22 18 N 114 10 E
Kra, Isthmus of Burma, Thailand 10 20 N 99 00 E
Krakatoa [volcano] Indonesia 6 07 S 105 24 E
Krakow [US Consulate Poland 50 03 N 19 58 E
General]
Kuala Lumpur [US Malaysia 3 10 N 101 42 E
Embassy]
Kunashiri (Kunashir) Russia [de 44 20 N 146 00 E
[island] facto]
Kunlun Mountains China 36 00 N 84 00 E
Kuril Islands Russia [de 46 10 N 152 00 E
facto]
Kuwait [US Embassy] Kuwait 29 20 N 47 59 E
Kuznetsk Basin Russia 54 00 N 86 00 E
Kwajalein Atoll Marshall Islands 9 05 N 167 20 E
Kyushu [island] Japan 33 00 N 131 00 E
Kyyiv (see Kiev) Ukraine 50 26 N 30 31 E
L Labrador Canada 54 00 N 62 00 W
Laccadive Islands India 10 00 N 73 00 E
Laccadive Sea Indian Ocean 7 00 N 76 00 E
Lagos [US Embassy] Nigeria 6 27 N 3 24 E
Lahore [US Consulate Pakistan 31 35 N 74 18 E
General]
Lakshadweep (Laccadive India 10 00 N 73 00 E
Islands)
La Paz [US Embassy] Bolivia 16 30 S 68 09 W
La Perouse Strait Pacific Ocean 45 45 N 142 00 E
Laptev Sea Arctic Ocean 76 00 N 126 00 E
Las Palmas Spain 28 06 N 15 24 W
Lau Group Fiji 18 20 S 178 30 E
Lefkosa (see Nicosia) Cyprus 35 10 N 33 22 E
Leipzig [US Consulate Germany 51 19 N 12 20 E
General]
Lemnos [island] Greece 39 54 N 25 21 E
Leningrad (see Saint Russia 59 55 N 30 15 E
Petersburg)
Lesser Sunda Islands Indonesia 9 00 S 120 00 E
Lesvos [island] Greece 39 15 N 26 15 E
Leyte [island] Philippines 10 50 N 124 50 E
Liancourt Rocks [claimed South Korea 37 15 N 131 50 E
by Japan]
Libreville [US Embassy] Gabon 0 23 N 9 27 E
Ligurian Sea Atlantic Ocean 43 30 N 9 00 E
Lilongwe [US Embassy] Malawi 13 59 S 33 44 E
Lima [US Embassy] Peru 12 03 S 77 03 W
Lincoln Sea Arctic Ocean 83 00 N 56 00 W
Line Islands Jarvis Island, 0 05 N 157 00 W
Kingman Reef,
Kiribati,
Palmyra Atoll
Lisbon [US Embassy] Portugal 38 43 N 9 08 W
Ljubljana [US Embassy] Slovenia 46 03 N 14 31 E
Lobamba Swaziland 26 27 S 31 12 E
Lombok Strait Indian Ocean 8 30 S 115 50 E
Lome [US Embassy] Togo 6 08 N 1 13 E
London [US Embassy] United Kingdom 51 30 N 0 10 W
Longyearbyen Svalbard 78 13 N 15 33 E
Lord Howe Island Australia 31 30 S 159 00 E
Louisiade Archipelago Papua New Guinea 11 00 S 153 00 E
Loyalty Islands (Iles New Caledonia 21 00 S 167 00 E
Loyaute)
Luanda [US Embassy] Angola 8 48 S 13 14 E
Lubumbashi Democratic 11 40 S 27 28 E
Republic of the
Monterrey Mexico 25 40 N 100 19 W
Montevideo [US Embassy] Uruguay 34 53 S 56 11 W
Montreal [US Consulate Canada 45 31 N 73 34 W
General, US Mission to
the International Civil
Aviation Organization
(ICAO)]
Moravia [region] Czech Republic 49 30 N 17 00 E
Moravian Gate Czech Republic 49 35 N 17 50 E
Moroni Comoros 11 41 S 43 16 E
Mortlock Islands (Nomoi Federated States 5 30 N 153 40 E
Islands) of Micronesia
Moscow [US Embassy] Russia 55 45 N 37 35 E
Mount Pinatubo Philippines 15 08 N 120 21 E
Mozambique Channel Indian Ocean 19 00 S 41 00 E
Mumbai [US Consulate India 18 58 N 72 50 E
General]
Munich [US Consulate Germany 48 09 N 11 35 E
General]
Musandam Peninsula Oman, United 26 18 N 56 24 E
Arab Emirates
Muscat [US Embassy] Oman 23 37 N 58 35 E
Muscat and Oman Oman 21 00 N 57 00 E
Myanma, Myanmar Burma 22 00 N 98 00 E
N Nagorno-Karabakh Azerbaijan 40 00 N 46 40 E
[region]
Nagoya [US Consulate] Japan 35 10 N 136 55 E
Naha [US Consulate Japan 26 13 N 127 40 E
General]
Nairobi [US Embassy] Kenya 1 17 S 36 49 E
Nampo-shoto [islands] Japan 30 00 N 140 00 E
Naples [US Consulate Italy 40 50 N 14 15 E
General]
Nassau [US Embassy] The Bahamas 25 05 N 77 21 W
Natuna Besar Islands Indonesia 3 30 N 102 30 E
Naxcivan [region] Azerbaijan 39 20 N 45 20 E
N''Djamena [US Embassy] Chad 12 07 N 15 03 E
Negev [region] Israel 30 30 N 34 55 E
Negros [island] Philippines 10 00 N 123 00 E
Netherlands East Indies Indonesia 5 00 S 120 00 E
Netherlands Guiana Suriname 4 00 N 56 00 W
Nevis [island] Saint Kitts and 17 09 N 62 35 W
Nevis
New Britain [island] Papua New Guinea 6 00 S 150 00 E
New Delhi [US Embassy] India 28 36 N 77 12 E
New Guinea Indonesia, Papua 5 00 S 140 00 E
New Guinea
New Hebrides Vanuatu 16 00 S 167 00 E
New Siberian Islands Russia 75 00 N 142 00 E
New Territories Hong Kong 22 24 N 114 10 E
New York, New York [US United States 40 43 N 74 01 W
Mission to the United
Nations (USUN)]
Newfoundland [island] Canada 52 00 N 56 00 W
Niamey [US Embassy] Niger 13 31 N 2 07 E
Nicobar Islands India 8 00 N 93 30 E
Nicosia [US Embassy] Cyprus 35 10 N 33 22 E
Nightingale Island Saint Helena 37 25 S 12 30 W
Nomoi Islands (Mortlock Federated States 5 30 N 153 40 E
Islands) of Micronesia
North Atlantic Ocean Atlantic Ocean 30 00 N 45 00 W
North Channel Atlantic Ocean 55 10 N 5 40 W
North Frisian Islands Denmark, Germany 54 50 N 8 12 E
North Island New Zealand 39 00 S 176 00 E
North Korea North Korea 40 00 N 127 00 E
North Pacific Ocean Pacific Ocean 30 00 N 165 00 W
North Sea Atlantic Ocean 56 00 N 4 00 E
North Vietnam Vietnam 23 00 N 106 00 E
North Yemen (Yemen Arab Yemen 15 00 N 44 00 E
Republic)
Northeast Providence Atlantic Ocean 25 40 N 77 09 W
Channel
Northern Epirus Albania, Greece 40 00 N 20 30 E
Northern Grenadines Saint Vincent 12 45 N 61 15 W
and the
Grenadines
Northern Ireland United Kingdom 54 40 N 6 45 W
Northern Rhodesia Zambia 15 00 S 30 00 E
Northwest Passages Arctic Ocean 74 40 N 100 00 W
Norwegian Sea Atlantic Ocean 66 00 N 6 00 E
Nouakchott [US Embassy] Mauritania 18 06 N 15 57 W
Noumea New Caledonia 22 16 S 166 27 E
Novaya Zemlya [islands] Russia 74 00 N 57 00 E
Nubia Sudan 20 30 N 33 00 E
Nuku''alofa Tonga 21 08 S 175 12 W
Nuevo Laredo [US Mexico 27 30 N 99 31 W
Consulate]
Nuuk (Godthab) Greenland 64 11 N 51 44 W
Nyasaland Malawi 13 30 S 34 00 E
O Oahu United States 21 30 N 158 00 W
Ocean Island (Banaba) Kiribati 0 52 S 169 35 E
Ocean Island (Kure United States 28 25 N 178 20 W
Island)
Ogaden [region] Ethiopia, 7 00 N 46 00 E
Serrana Bank Colombia 14 25 N 80 16 W
Serranilla Bank Colombia 15 51 N 79 46 W
Settlement, The Christmas Island 18 44 N 64 19 W
Severnaya Zemlya Russia 79 30 N 98 00 E
(Northland) [island
group]
Shaba [region] Democratic 8 00 S 27 00 E
Republic of the','ddf5f5ff86256d8801ea90a7b4ea986cf2a87337953e115ae6b7459a262331a5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('020fd05b547506e72ea920bdb41f617a784f515f1791863bd4eb0cb308b19512',1999,'UG','Uganda','communications',412,'British Guiana Guyana 5 00 N 59 00 W
British Honduras Belize 17 15 N 88 45 W
British Solomon Islands Solomon Islands 8 00 S 159 00 E
British Somaliland Somalia 10 00 N 49 00 E
Brussels [US Embassy, US Belgium 50 50 N 4 20 E
Mission to European
Union (USEU), US Mission
to the North Atlantic
Treaty Organization
(USNATO)]
Bubiyan [island] Kuwait 29 47 N 48 10 E
Bucharest [US Embassy] Romania 44 26 N 26 06 E
Budapest [US Embassy] Hungary 47 30 N 19 05 E
Buenos Aires [US Argentina 34 36 S 58 27 W
Embassy]
Bujumbura [US Embassy] Burundi 3 23 S 29 22 E
Burnt Pine Norfolk Island 29 02 S 167 56 E
Byelorussia Belarus 53 00 N 28 00 E
C Cabinda [province] Angola 5 33 S 12 12 E
Cabot Strait Atlantic Ocean 47 20 N 59 30 W
Caicos Islands Turks and Caicos 21 56 N 71 58 W
Islands
Cairo [US Embassy] Egypt 30 03 N 31 15 E
Calcutta [US Consulate India 22 32 N 88 22 E
General]
Calgary [US Consulate Canada 51 03 N 114 05 W
General]
California, Gulf of Pacific Ocean 28 00 N 112 00 W
Campbell Island New Zealand 52 33 S 169 09 E
Canal Zone Panama 9 00 N 79 45 W
Canary Islands Spain 28 00 N 15 30 W
Canberra [US Embassy] Australia 35 17 S 149 08 E
Canton (Guangzhou) China 23 06 N 113 16 E
Canton Island (Kanton Kiribati 2 49 S 171 40 W
Island)
Cape Town [US Consulate South Africa 33 55 S 18 22 E
General]
Caracas [US Embassy] Venezuela 10 30 N 66 56 W
Cargados Carajos Shoals Mauritius 16 25 S 59 38 E
Caroline Islands Federated States 7 30 N 148 00 E
of Micronesia,','ce9069ec902e5450dbca11ab381e706b55b1c141b609cb59d275c1628aa11453','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9e6d31a95f1578f7ad4ad6f9961173cdeaf50627cbe0e51578d22e4fcfeda99',1999,'PW','Palau','communications',413,'Caribbean Sea Atlantic Ocean 15 00 N 73 00 W
Carpentaria, Gulf of Pacific Ocean 14 00 S 139 00 E
Casablanca [US Consulate Morocco 33 39 N 7 35 W
General]
Castries Saint Lucia 14 01 N 61 00 W
Catalonia [region] Spain 42 00 N 2 00 E
Cato Island Australia 23 15 S 155 32 E
Caucasus [region] Russia 42 00 N 45 00 E
Cayenne French Guiana 4 56 N 52 20 W
Cebu [US Consular Philippines 10 18 N 123 54 E
Agency]
Celebes [island] Indonesia 2 00 S 121 00 E
Celebes Sea Pacific Ocean 3 00 N 122 00 E
Celtic Sea Atlantic Ocean 51 00 N 6 30 W
Central African Empire Central African 7 00 N 21 00 E
Republic
Ceuta Spain 35 53 N 5 19 W
Ceylon Sri Lanka 7 00 N 81 00 E
Chafarinas, Islas Spain 35 12 N 2 26 W
Chagos Archipelago (Oil British Indian 6 00 S 71 30 E
Islands) Ocean Territory
Channel Islands Guernsey, Jersey 49 20 N 2 20 W
Charlotte Amalie Virgin Islands 18 21 N 64 56 W
Chatham Islands New Zealand 44 00 S 176 30 W
Chechnya (Chechnia) Russia 43 15 N 45 40 E
Cheju-do [island] Korea, South 33 20 N 126 30 E
Cheju Strait Pacific Ocean 34 00 N 126 30 E
Chengdu [US Consulate China 39 39 N 104 04 E
General]
Chennai (Madras) [US India 13 04 N 80 16 E
Consulate General]
Chesterfield Islands New Caledonia 19 52 S 158 15 E
(Iles Chesterfield)
Chiang Mai [US Consulate Thailand 18 47 N 98 59 E
General]
Chihli, Gulf of (see Bo Pacific Ocean 38 30 N 120 00 E
Hai)
China, People''s Republic China 35 00 N 105 00 E
of
China, Republic of Taiwan 23 30 N 105 00 E
Chisinau [US Embassy] Moldova 47 00 N 28 50 E
Choiseul [island] Solomon Islands 7 05 S 121 00 E
Christmas Island [Indian Australia 10 25 S 105 39 E
Ocean]
Christmas Island Kiribati 1 52 N 157 20 W
(Kiritimati) [Pacific
Ocean]
Chukchi Sea Arctic Ocean 69 00 N 171 00 W
Ciskei South Africa 33 00 S 27 00 E
Ciudad Juarez [US Mexico 31 44 N 106 29 W
Consulate General]
Cluj-Napoca [US Branch Romania 46 47 N 23 36 E
Office]
Cochin China [region] Vietnam 11 00 N 107 00 E
Coco, Isla del Costa Rica 5 32 N 87 04 W
Cocos Islands Cocos (Keeling) 12 30 S 96 50 E
Islands
Colombo [US Embassy] Sri Lanka 6 56 N 79 51 E
Colon, Archipielago de Ecuador 0 00 N 90 30 W
(Galapagos Islands)
Commander Islands Russia 55 00 N 167 00 E
(Komandorskiye Ostrova)
Conakry [US Embassy] Guinea 9 31 N 13 43 W
Congo (Leopoldville) Democratic 15 00 S 30 00 E
Republic of the','41d6eae254399fa13dba2d166d6a5296df7b0a592f7c3c64d4621a8eb9236b0a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('423ba1e0c3ae195ddf36601b769def99c4b59d7d5c9ee246cffcb5c7df36ed04',1999,'SK','Slovakia','communications',414,'D Dahomey Benin 9 30 N 2 15 E
Daito Islands Japan 43 00 N 17 00 E
Dakar [US Embassy] Senegal 14 40 N 17 26 W
Dalmatia [region] Croatia 43 00 N 17 00 E
Daman (Damao) India 20 10 N 73 00 E
Damascus [US Embassy] Syria 33 30 N 36 18 E
Danger Islands (see Cook Islands 10 53 S 165 49 W
Pukapuka Atoll)
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies Virgin Islands 18 20 N 64 50 W
Danzig (Gdansk) Poland 54 23 N 18 40 E
Dao Bach Long Vi Vietnam 20 08 N 107 44 E
[island]
Dardanelles [strait] Atlantic Ocean 40 15 N 26 25 E
Dar es Salaam [US Tanzania 6 48 S 39 17 E
Embassy]
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, 32 30 N 35 30 E
West Bank
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Desolation Islands French Southern 49 30 S 69 30 E
(Isles Kerguelen) and Antarctic
Lands
Devils Island (Ile du French Guiana 5 17 N 52 35 W
Diable)
Devon Island Canada 76 00 N 87 00 W
Dhahran [US Consulate Saudi Arabia 26 18 N 50 08 E
General]
Dhaka [US Embassy] Bangladesh 23 43 N 90 25 E
Dhofar [region] Oman 17 00 N 54 10 E
Diego Garcia [island] British Indian 7 20 S 72 25 E
Ocean Territory
Diego Ramirez [islands] Chile 56 30 S 68 43 W
Diomede Islands Russia [Big 65 47 N 169 00 W
Diomede], United
States [Little
Diomede]
Diu India 20 42 N 70 59 E
Djibouti [US Embassy] Djibouti 11 30 N 43 15 E
Dnieper [river] Belarus, Russia, 46 30 N 32 18 E
(Dnyapro, Dnepr, Dnipro) Ukraine
Dniester [river] Moldova, Ukraine 46 18 N 30 17 E
(Nistru, Dnister)
Dodecanese [islands] Greece 36 00 N 27 05 E
Dodoma Tanzania 6 11 S 35 45 E
Doha [US Embassy] Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala Cameroon 4 03 N 9 42 E
Douglas Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean 60 00 S 60 00 W
Dubai [US Consulate United Arab 25 18 N 55 18 E
General] Emirates
Dubayy (see Dubai) United Arab 25 18 N 55 18 E
Emirates
Dublin [US Embassy] Ireland 53 20 N 6 15 W
Durban [US Consulate South Africa 29 55 S 30 56 E
General]
Dushanbe [US Embassy] Tajikistan 38 35 N 68 48 E
Dutch Antilles Netherlands 52 05 N 4 18 E
Antilles
Dutch East Indies Indonesia 5 00 S 120 00 E
Dutch Guiana Suriname 4 00 N 56 00 W
Dutch West Indies Netherlands 52 05 N 4 18 E
Antilles
Dzungarian Gate China, 45 25 N 82 25 E','024a59800f2b9f68d5e0fb6778360fb9c862f3100d155a00fcf4d3a01afd2cb7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a46e030273c3d451d8a0a34d689863697508ad22dab1dec7f8bc632850943f8',1999,'KZ','Kazakhstan','communications',415,'E East China Sea Pacific Ocean 30 00 N 126 00 E
East Frisian Islands Germany 53 44 N 7 25 E
East Germany (German Germany 52 00 N 13 00 E
Democratic Republic)
East Korea Strait Pacific Ocean 34 00 N 129 00 E
(Eastern Channel or
Tsushima Strait)
East Pakistan Bangladesh 24 00 N 90 00 E
East Siberian Sea Arctic Ocean 74 00 N 166 00 E
East Timor (Portuguese Indonesia 9 00 S 126 00 E
Timor)
Easter Island (Isla de Chile 27 07 S 109 22 W
Pascua)
Eastern Channel (East Pacific Ocean 34 00 N 129 00 E
Korea Strait or Tsushima
Strait)
Eastern Samoa American Samoa 14 20 S 170 00 W
Edinburgh [US Consulate United Kingdom 55 57 N 3 13 W
General]
Eire Ireland 53 00 N 8 00 W
Elba [island] Italy 42 46 N 10 17 E
Ellef Ringnes Island Canada 78 00 N 103 00 W
Ellesmere Island Canada 81 00 N 80 00 W
Ellice Islands Tuvalu 8 00 S 178 00 E
Elobey, Islas de Equatorial 0 59 N 9 33 E','6d112c1622a7adeb42e8bb8a0c5a2958e8178557966d3cd30a1a680cc6b8d1f2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816716c81e5e5bee60a52008160807a87f7f9b2a9457836b456874acd3ef5655',1999,'NL','Netherlands','communications',416,'Frunze (see Bishkek) Kyrgyzstan 42 54 N 74 36 E
Fukuoka [US Consulate] Japan 33 35 N 130 24 E
Funafuti Tuvalu 8 30 S 179 12 E
Fundy, Bay of Atlantic Ocean 45 00 N 66 00 W
Futuna Islands (Hoorn Wallis and 14 19 S 178 05 W
Islands/Iles de Horne) Futuna
G Gaborone [US Embassy] Botswana 24 45 S 25 55 E
Galapagos Islands Ecuador 0 00 N 90 30 W
(Archipielago de Colon)
Galilee [region] Israel 32 54 N 35 20 E
Galleons Passage Atlantic Ocean 11 00 N 60 55 W
Gambier Islands (Iles French Polynesia 23 09 S 134 58 W
Gambier)
Gaspar Strait Pacific Ocean 3 00 S 107 00 E
Geneva [US Consular Switzerland 46 12 N 6 10 E
Agency, US Mission to
European Office of the
UN and Other
International
Organizations]
Genoa Italy 44 25 N 8 57 E
George Town Malaysia 5 26 N 100 16 E
George Town The Bahamas 23 30 N 75 46 W
George Town Cayman Islands 19 20 N 81 23 W
Georgetown The Gambia 13 30 N 14 47 W
Georgetown [US Embassy] Guyana 6 48 N 58 10 W
German Democratic Germany 52 00 N 13 00 E
Republic (East Germany)
German Southwest Africa Namibia 22 00 S 17 00 E
Germany, Federal Germany 51 00 N 9 00 E
Republic of
Gibraltar Gibraltar 36 11 N 5 22 W
Gibraltar, Strait of Atlantic Ocean 35 57 N 5 36 W
Gidi Pass Egypt 30 13 N 33 09 E
Gilbert Islands Kiribati 1 25 N 173 00 E
Goa [state] India 14 20 N 74 00 E
Godthab (Nuuk) Greenland 64 11 N 51 44 W
Gold Coast Ghana 8 00 N 2 00 W
Golan Heights [region] Syria 33 00 N 35 45 E
Good Hope, Cape of South Africa 34 24 S 18 30 E
Goteborg Sweden 57 43 N 11 58 E
Gotland [island] Sweden 57 30 N 18 33 E
Gough Island Saint Helena 40 10 S 9 45 W
Grand Banks Atlantic Ocean 47 06 N 55 48 W
Grand Cayman [island] Cayman Islands 19 20 N 81 20 W
Grand Turk Turks and Caicos 21 28 N 71 08 W
Islands
Great Australian Bight Indian Ocean 35 00 S 130 00 E
Great Belt (Store Baelt) Atlantic Ocean 55 30 N 11 00 E
Great Bitter Lake Egypt 30 20 N 32 23 E
Great Britain [island] United Kingdom 54 00 N 2 00 W
Great Channel Indian Ocean 6 25 N 94 20 E
Greater Sunda Islands Brunei, 2 00 S 110 00 E
Indonesia,','e2d5b7424328f9330341b7ada1eff7aa472ecbe53c5cac1aa85e8b3175c69e0e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1883a1dc2886599d3a35a3377898fbe136c0c6fef5b334b41c594ade6a7cd025',1999,'SO','Somalia','communications',417,'Hudson Bay Arctic Ocean 60 00 N 86 00 W
Hudson Strait Arctic Ocean 62 00 N 71 00 W
Hunter Island New Caledonia, 22 24 S 172 06 E
Italian Somaliland Somalia 10 00 N 49 00 E
Iturup (see Etorofu) Russia [de 44 55 N 147 40 E
facto]
Ivory Coast Cote d''Ivoire 8 00 N 5 00 W
Iwo Jima [island] Japan 24 47 N 141 20 E
J Jakarta [US Embassy] Indonesia 6 10 S 106 48 E
Jamestown Saint Helena 15 56 S 5 44 W
Jammu India 32 42 N 74 52 E
Jammu and Kashmir India, Pakistan 34 00 N 76 00 E
[region]
Japan, Sea of Pacific Ocean 40 00 N 135 00 E
Jars, Plain of Laos 19 27 N 103 10 E
Java [island] Indonesia 7 30 S 110 00 E
Java Sea Pacific Ocean 5 00 S 110 00 E
Jeddah (see Jiddah) Saudi Arabia 21 30 N 39 12 E
Jerusalem [US Consulate Israel, West 31 47 N 35 14 E
General] Bank
Jiddah [US Consulate Saudi Arabia 21 30 N 39 12 E
General]
Johannesburg [US South Africa 26 15 S 28 00 E
Consulate General]
Juan de Fuca, Strait of Pacific Ocean 48 18 N 124 00 W
Juan Fernandez, Isla de Chile 33 00 S 80 00 W
Jubal, Strait of Indian Ocean 27 40 N 33 55 E
Judaea [region] Israel, West 31 35 N 35 00 E
Bank
Jutland [region] Denmark 56 00 N 9 15 E
Juventud, Isla de la Cuba 21 40 N 82 50 W
(Isle of Youth)
K Kabul [US Embassy now Afghanistan 34 31 N 69 12 E
closed]
Kaduna Nigeria 10 33 N 7 27 E
Kailas Range China, India 30 00 N 82 00 E
Kalimantan [region] Indonesia 0 00 N 115 00 E
Kamaran [island] Yemen 15 21 N 42 34 E
Kamchatka Peninsula Russia 56 00 N 160 00 E
(Poluostrov Kamchatka)
Kampala [US Embassy] Uganda 0 19 N 32 25 E
Kampuchea Cambodia 13 00 N 105 00 E
Kanton Island Kiribati 2 49 S 171 40 W
Karachi [US Consulate Pakistan 24 52 N 67 03 E
General]
Kara Sea Arctic Ocean 76 00 N 80 00 E
Karakoram Pass China, India 35 30 N 77 50 E
Karelian Isthmus Russia 60 25 N 30 00 E
Karimata Strait Pacific Ocean 2 05 S 108 40 E
Kashmir [region] India, Pakistan 34 00 N 76 00 E
Katanga [region] Democratic 10 00 S 26 00 E
Republic of the
Oil Islands (Chagos British Indian 6 00 S 71 30 E
Archipelago) Ocean Territory
Okhotsk, Sea of Pacific Ocean 53 00 N 150 00 E
Okinawa [island group] Japan 26 30 N 128 00 E
Oman, Gulf of Indian Ocean 24 30 N 58 30 E
Ombai Strait Pacific Ocean 8 30 S 125 00 E
Oran Algeria 35 43 N 0 43 W
Oranjestad Aruba 12 33 N 70 06 W
Oresund (The Sound) Atlantic Ocean 55 50 N 12 40 E
Orkney Islands United Kingdom 59 00 N 3 00 W
Osaka-Kobe [US Consulate Japan 34 40 N 135 30 E
General]
Oslo [US Embassy] Norway 59 55 N 10 45 E
Osumi Strait (Van Diemen Pacific Ocean 31 00 N 131 00 E
Strait)
Otranto, Strait of Atlantic Ocean 40 00 N 19 00 E
Ottawa [US Embassy] Canada 45 20 N 73 58 W
Ouagadougou [US Embassy] Burkina Faso 12 22 N 1 31 W
Outer Mongolia Mongolia 46 00 N 105 00 E
P Pacific Islands, Trust Marshall 10 00 N 155 00 E
Territory of the Islands,
Federated States
of Micronesia,
Northern Mariana
Islands, Palau
Pagan [island] Northern Mariana 18 8 N 145 47 E
Islands
Pago Pago American Samoa 14 16 S 170 42 W
Palawan [island] Philippines 9 30 N 118 30 E
Palermo Italy 38 07 N 13 21 E
Palestine Israel, West 32 00 N 35 15 E
Bank
Palikir Federated States 6 55 N 158 08 E
of Micronesia
Palk Strait Indian Ocean 10 00 N 79 45 E
Pamirs [mountains] China, 38 00 N 73 00 E','3c69c1aa477d045cfffd3662e64eb708cda2a0f3ba0e81ae0a0582a00b002206','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ea76b5046a9d0dc3cb592287ca9089253fbf8afa3d13497887f26c1b1289a27',1999,'VU','Vanuatu','communications',418,'I Iberian Peninsula Portugal, Spain 40 00 N 5 00 W
Inaccessible Island Saint Helena 37 17 S 12 40 W
Indochina Cambodia, Laos, 15 00 N 107 00 E
Vietnam
Inland Sea Japan 34 20 N 133 30 E
Inner Mongolia (Nei China 42 00 N 113 00 E
Mongol)
Ionian Islands Greece 38 30 N 20 30 E
Ionian Sea Atlantic Ocean 38 30 N 18 00 E
Irian Jaya [province] Indonesia 5 00 S 138 00 E
Irish Sea Atlantic Ocean 53 30 N 5 20 W
Iron Gate Romania, Serbia 44 41 N 22 31 E
and Montenegro
Islamabad [US Embassy] Pakistan 33 42 N 73 10 E
Islas Malvinas Falkland Islands 51 45 S 59 00 W
(Islas Malvinas)
Istanbul [US Consulate Turkey 41 01 N 28 58 E
General]
Istrian Peninsula Croatia, 45 00 N 14 00 E
Mazatlan Mexico 23 13 N 106 25 W
Mbabane [US Embassy] Swaziland 26 18 S 31 06 E
McDonald Islands Heard Island and 53 06 S 73 30 E
McDonald Islands
Mecca Saudi Arabia 21 27 N 39 49 E
Medan [US Consulate Indonesia 3 35 N 98 40 E
General]
Mediterranean Sea Atlantic Ocean 36 00 N 15 00 E
Melbourne [US Consulate Australia 37 49 S 144 58 E
General]
Melilla Spain 35 19 N 2 58 W
Merida [US Consulate] Mexico 20 58 N 89 37 W
Mesopotamia Iraq 33 00 N 44 00 E
Messina, Strait of Atlantic Ocean 38 15 N 15 35 E
Mexico [US Embassy] Mexico 19 24 N 99 09 W
Mexico, Gulf of Atlantic Ocean 25 00 N 90 00 W
Milan [US Consulate Italy 45 28 N 9 12 E
General]
Minami-tori-shima Japan 24 16 N 154 00 E
(Marcus Island)
Mindanao [island] Philippines 8 00 N 125 00 E
Mindoro [island] Philippines 12 50 N 121 05 E
Mindoro Strait Pacific Ocean 12 20 N 120 40 E
Minicoy Island India 8 17 N 73 02 E
Minsk [US Embassy] Belarus 53 54 N 27 34 E
Minorca Island (Isla de Spain 40 00 N 4 00 E
Menorca)
Mitla Pass Egypt 30 02 N 32 54 E
Mogadishu Somalia 2 04 N 45 22 E
Moldavia [region] Moldova, Romania 47 00 N 29 00 E
Moluccas (Spice Islands) Indonesia 2 00 S 28 00 E
Mombasa Kenya 4 03 S 39 40 E
Mona Passage Atlantic Ocean 18 30 N 67 45 W
Monaco Monaco 43 44 N 7 25 E
Monrovia [US Embassy] Liberia 6 18 N 10 47 W
Montenegro Serbia and 42 30 N 19 00 E','58b76f78d536c7b3982d2853163e3d1c3149587bc68334314b732df15fef1c06','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('218a0c0c51a1bbcbe382f30bfe67ca20706aa0647a16bff145c2b2e140166ff5',1999,'SI','Slovenia','communications',419,'Italian East Africa Eritrea, 8 00 N 38 00 E
Ethiopia,
Z Zagreb [US Embassy] Croatia 45 48 N 15 58 E
Zaire Democratic 15 00 S 30 00 E
Republic of the','55d01af41442cea666b1228855fd6367876d9e0076728e13f57116df00cac0a7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8da11ff4b5c79aac56f797a8df8dca39b30dbf208a8173dbb87aaddcdee362',1999,'PK','Pakistan','communications',420,'Kiel Canal (Nord-Ostsee Atlantic Ocean 53 53 N 9 08 E
Kanal)
Kiev [US Embassy] Ukraine 50 26 N 30 31 E
Kigali [US Embassy] Rwanda 1 57 S 30 04 E
Kingston [US Embassy] Jamaica 18 00 N 76 48 W
Kingston Norfolk Island 29 03 S 167 58 E
Kingstown Saint Vincent 13 09 N 61 14 W
and the
Grenadines
Kinshasa [US Embassy] Democratic 4 18 S 15 18 E
Republic of the
Peking (see Beijing) China 39 56 N 116 24 E
Pelagian Islands (Isole Italy 35 40 N 12 40 E
Pelagie)
Peleliu (Beliliou) Palau 7 01 N 134 15 E
[island]
Pemba Island Tanzania 7 31 S 39 25 E
Penang Island Malaysia 5 23 N 100 15 E
Pentland Firth Atlantic Ocean 58 44 N 3 13 W
Perim [island] Yemen 12 39 N 43 25 E
Perouse Strait, La Pacific Ocean 44 45 N 142 00 E
Persia Iran 32 00 N 53 00 E
Persian Gulf Indian Ocean 27 00 N 51 00 E
Perth [US Consulate Australia 31 56 S 115 50 E
General]
Pescadores [islands] Taiwan 23 30 N 119 30 E
Peshawar [US Consulate] Pakistan 34 01 N 71 33 E
Peter I Island Antarctica 68 48 S 90 35 W
Philip Island Norfolk Island 29 08 S 167 57 E
Philippine Sea Pacific Ocean 20 00 N 134 00 E
Phnom Penh [US Embassy] Cambodia 11 33 N 104 55 E
Phoenix Islands Kiribati 3 30 S 172 00 W
Pines, Isle of (Isla de Cuba 21 40 N 82 50 W
la Juventud)
Pleasant Island Nauru 0 32 S 166 55 E
Plymouth Montserrat 16 44 N 62 14 W
Ponape (Pohnpei) Federated States 6 55 N 158 15 E
[island] of Micronesia
Ponta Delgada [US Portugal 37 44 N 25 40 W
Consulate]
Port-au-Prince [US Haiti 18 32 N 72 20 W
Embassy]
Port Louis [US Embassy] Mauritius 20 10 S 57 30 E
Port Moresby [US Papua New Guinea 9 30 S 147 10 E
Embassy]
Porto Alegre [US Brazil 30 04 S 51 11 W
Consulate]
Port-of-Spain [US Trinidad and 10 39 N 61 31 W
Embassy] Tobago
Porto-Novo Benin 6 29 N 2 37 E
Portuguese East Africa Mozambique 18 15 S 35 00 E
Portuguese Guinea Guinea-Bissau 12 00 N 15 00 W
Portuguese Timor (East Indonesia 9 00 S 126 00 E
Timor)
Port-Vila Vanuatu 17 44 S 168 19 E
Poznan Poland 52 25 N 16 55 E
Prague [US Embassy] Czech Republic 40 55 N 21 00 E
Praia [US Embassy] Cape Verde 14 55 N 23 31 W
Pretoria [US Embassy] South Africa 25 45 S 28 10 E
Prevlaka peninsula Croatia 42 24 N 18 31 E
Pribilof Islands United States 57 00 N 170 00 W
Prince Edward Island Canada 46 20 N 63 20 W
Prince Edward Islands South Africa 46 35 S 38 00 E
Prince Patrick Island Canada 76 30 N 119 00 W
Principe [island] Sao Tome and 1 38 N 7 25 E
Principe
Prussia [region] Germany, Poland, 53 00 N 14 00 E
Russia
Pukapuka Atoll Cook Islands 10 53 S 165 49 W
Pusan [US Consulate] South Korea 35 06 N 129 03 E
P''yongyang North Korea 39 01 N 125 45 E
Q Quebec [US Consulate Canada 52 00 N 72 00 W
General]
Queen Charlotte Islands Canada 53 00 N 132 00 W
Queen Elizabeth Islands Canada 78 00 N 95 00 W
Queen Maud Land [claimed Antarctica 73 30 S 12 00 E
by Norway]
Quemoy [island] Taiwan 24 27 N 118 23 E
Quito [US Embassy] Ecuador 0 13 S 78 30 W
R Rabat [US Embassy] Morocco 34 02 N 6 51 W
Ralik Chain Marshall Islands 8 00 N 167 00 E
Rangoon [US Embassy] Burma 16 47 N 96 10 E
Ratak Chain Marshall Islands 9 00 N 171 00 E
Recife [US Consulate] Brazil 8 03 S 34 54 W
Redonda [island] Antigua and 16 55 N 62 19 W
Barbuda
Red Sea Indian Ocean 20 00 N 38 00 E
Revillagigedo Island United States 55 35 N 131 06 W
Revillagigedo Islands Mexico 19 00 N 112 45 W
Reykjavik [US Embassy] Iceland 19 00 N 111 30 W
Rhodes [island] Greece 36 10 N 28 00 E
Rhodesia Zimbabwe 20 00 S 30 00 E
Rhodesia, Northern Zambia 15 00 S 30 00 E
Rhodesia, Southern Zimbabwe 20 00 S 30 00 E
Riga [US Embassy] Latvia 56 57 N 24 06 E
Rio de Janeiro [US Brazil 22 54 S 43 14 W
Consulate General]
Rio de Oro Western Sahara 23 45 N 15 45 W
Rio Muni Equatorial 1 30 N 10 00 E','7052564b961a7929af355304a1a4e067f8028761d7ca8a1498684bbb917cc421','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc64a746f0d0ddb22a96fb5ba6b283bb4d1e0ce63a9ed45ef034d35811a9ed3f',1999,'TJ','Tajikistan','communications',421,'Pampas [region] Argentina 35 00 N 63 00 W
Panama [US Embassy] Panama 8 58 N 79 32 W
Panama Canal Panama 9 00 N 79 45 W
Panama, Gulf of Pacific Ocean 8 00 N 79 30 W
Panay [island] Philippines 11 15 N 122 30 E
Pantelleria, Isola di Italy 36 47 N 12 00 E
Papeete French Polynesia 17 32 S 149 34 W
Paramaribo [US Embassy] Suriname 5 50 N 55 10 W
Parece Vela [island] Japan 20 20 N 136 00 E
Paris [US Embassy, US France 48 52 N 2 20 E
Mission to the
Organization for
Economic Cooperation and
Development (OECD), US
Observer Mission to the
UN Educational,
Scientific, and Cultural
Organization (UNESCO)]
Pascua, Isla de (Easter Chile 27 07 S 109 22 W
Island)
Passion, Ile de la Clipperton 10 17 N 109 13 W
Island
Pashtunistan [region] Afghanistan, 32 00 N 69 00 E','b36390ae6e93c43fe06b8f4a7ed1273a214e432be58bb3f1e7c5393ae509380e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6969289e8866179c9ab5830348d4d2c808a04a73550d7fc53fa5825cb8c9aa59',1999,'KG','Kyrgyzstan','communications',422,'Tierra del Fuego Argentina, Chile 54 00 S 69 00 W
Tijuana [US Consulate Mexico 32 32 N 117 01 W
General]
Timor [island] Indonesia 9 00 S 125 00 E
Timor Sea Pacific Ocean 11 00 S 128 00 E
Tinian [island] Northern Mariana 15 00 N 145 38 E
Islands
Tiran, Strait of Indian Ocean 28 00 N 34 27 E
Tirane [US Embassy] Albania 41 20 N 19 50 E
Tirol [region] Austria, Italy 47 00 N 11 00 E
Tobago [island] Trinidad and 11 15 N 60 40 W
Tobago
Tokyo [US Embassy] Japan 35 42 N 139 46 E
Tonkin, Gulf of Pacific Ocean 20 00 N 108 00 E
Toronto [US Consulate Canada 43 39 N 79 23 W
General]
Torres Strait Pacific Ocean 10 25 S 142 10 E
Torshavn Faroe Islands 62 01 N 6 46 W
Toshkent (see Tashkent) Uzbekistan 41 20 N 69 18 E
Transjordan Jordan 31 00 N 36 00 E
Transkei South Africa 32 15 S 28 15 E
Transylvania [region] Romania 46 30 N 24 00 E
Trindade, Ilha de Brazil 20 31 S 29 20 W
Tripoli Lebanon 34 26 N 35 51 E
Tripoli [US post not Libya 32 54 N 13 11 E
maintained;
representation by
Belgian Embassy]
Tristan da Cunha Group Saint Helena 37 04 S 12 19 W
Trobriand Islands Papua New Guinea 8 38 S 151 04 E
Trucial Coast United Arab 24 00 N 54 00 E
Emirates
Trucial Oman United Arab 24 00 N 54 00 E
Emirates
Trucial States United Arab 24 00 N 54 00 E
Emirates
Truk Islands Federated States 7 25 N 151 47 E
of Micronesia
Tsugaru Strait Pacific Ocean 41 35 N 141 00 E
Tuamotu Islands (Iles French Polynesia 19 00 S 142 00 W
Tuamotu)
Tubuai Islands (Iles French Polynesia 23 00 S 150 00 W
Tubuai)
Tunb al Kubra [island] Iran 26 14 N 55 19 E
Tunb as Sughra [island] Iran 26 14 N 55 09 E
Tunis [US Embassy] Tunisia 36 48 N 10 11 E
Turin Italy 45 04 N 7 40 E
Turkish Straits Atlantic Ocean 40 40 N 28 00 E
Turkmeniya Turkmenistan 40 00 N 60 00 E
Turks Island Passage Atlantic Ocean 21 40 N 71 00 W
Tuscany [region] Italy 43 25 N 11 00 E
Tutuila [island] American Samoa 14 18 S 170 42 W
Tyrol, South [region] Italy 46 30 N 10 30 E
Tyrrhenian Sea Atlantic Ocean 40 00 N 12 00 E
U Udorn (Udon Thani) [US Thailand 17 26 N 102 46 E
Consulate]
Ulaanbaatar [US Embassy] Mongolia 47 55 N 106 53 E
Ullung-do [island] South Korea 37 29 N 130 52 E
Unimak Pass [strait] Pacific Ocean 54 20 N 164 50 W
Union of Soviet Armenia,
Socialist Republics Azerbaijan,
(USSR) Belarus,
Estonia,
Georgia,
Kazakhstan,
Kyrgyzstan,
Latvia,
Lithuania,
Moldova, Russia,
Tajikistan,
Turkmenistan,
Ukraine,','518bc2eed479e6927938f1db6f21a593109760bd0a60202e2f21c18f462c4ced','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

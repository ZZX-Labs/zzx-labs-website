SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('173ed54a89300b7e37f41bed87e9fac20aafdd5b943b971e93be05659000ee2e',1999,'EH','Western Sahara','geography',9,'Location
Geographic coordinates
Map references
Area
total
land
water
Area— comparative
Land boundaries
total
border countries
Coastline
Maritime claims
contiguous zone
continental shelf
exclusive economic zone
exclusive fishing zone
extended fishing zone
territorial sea
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
permanent pastures
forests and woodland
other
Irrigated land
Natural hazards
Environment— current issues
Environment— international agreements
party to
signed, but not ratified
Geography— note
Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area - comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1 ,561 km,
Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains in
south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: 81%
Irrigated land: NAsqkm
Natural hazards: hot, dry, dust/sand-laden sirocco
wind can occur during winter and spring; widespread
harmattan haze exists 60% of time, often severely
restricting visibility
Environment - current issues: sparse water and
arable land
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Map references: World, Time Zones
Area:
total: 510.072 million sq km
land: 148.94 million sq km
water: 361 .132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is
land
Area - comparative: land area about 1 5 times the
size of the US
Land boundaries: the land boundaries in the world
total 251 ,480.24 km (not counting shared boundaries
twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most, but can
vary
continental shell: 200-m depth claimed by most or to
depth of exploitation; others claim 200 nm or to the
edge of the continental margin
exclusive fishing zone: 200 nm claimed by most, but
can vary
exclusive economic zone: 200 nm claimed by most,
but can vary
territorial sea: 1 2 nm claimed by most, but can vary
note: boundary situations with neighboring states
prevent many countries from extending their fishing or
economic zones to a full 200 nm; 43 nations and other
areas that are landlocked include Afghanistan, Andorra,
Armenia, Austria, Azerbaijan, Belarus, Bhutan, Bolivia,
Botswana, Burkina Faso, Burundi, Central African
Republic, Chad, Czech Republic, Ethiopia, Holy See
(Vatican City), Hungary, Kazakhstan, Kyrgyzstan,
Laos, Lesotho, Liechtenstein, Luxembourg, Malawi,
Mali, Moldova, Mongolia, Nepal, Niger, Paraguay,
Rwanda, San Marino, Slovakia, Swaziland,
Switzerland, Tajikistan, The Former Yugoslav Republic
of Macedonia, Turkmenistan, Uganda, Uzbekistan,
West Bank, Zambia, Zimbabwe
Climate: two large areas of polar climates separated
by two rather narrow temperate zones from a wide
equatorial band of tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,848 m
Natural resources: the rapid using up of
nonrenewable mineral resources, the depletion of
forest areas and wetlands, the extinction of animal
and plant species, and the deterioration in air and
water quality (especially in Eastern Europe, the former
USSR, and China) pose serious long-term problems
that governments and peoples are only beginning to
address
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 26%
forests and woodland: 32%
other: 31% (1993 est.)
Irrigated land: 2,481 ,250 sq km (1993 est.)
Natural hazards: large areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
Environment - current issues: large areas subject
to overpopulation, industrial disasters, pollution (air,
water, acid rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
Environment - international agreements: selected
international environmental agreements are included
under the Environment - international agreements
entry for each country and in the Selected
International Environmental Agreements appendix','a4039687534ff893536ac2622b873549c251c5f2fd5323adbce8cf4c4ce521ae','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da3ec68fa0499bda9cd0c37d4af637a4c01e54b297c6a916e554e3153589b0ab',1999,'AL','Albania','geography',23,'Location: Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and
Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,750 sq km
land: 27,400 sq km
water: 1 ,350 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, The Former
Yugoslav Republic of Macedonia 151 km, Serbia and
Montenegro 287 km (1 1 4 km with Serbia, 1 73 km with
Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: mild temperate; cool, cloudy, wet winters;
hot, clear, dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains
along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, timber, nickel
Land use:
arable land: 21%
permanent crops: 5%
permanent pastures: 15%
forests and woodland: 38%
other: 21% (1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis
occur along southwestern coast
Environment - current issues: deforestation; soil
erosion; water pollution from industrial and domestic
effluents
Environment - international agreements:
party to: Biodiversity, Climate Change, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)
Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381 ,740 sq km
land: 2,381 ,740 sq km
water: 0 sq km
Area - comparative: slightly less than 3.5 times the
size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1 ,376 km,
Mauritania 463 km, Morocco 1 ,559 km, Niger 956 km,
Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: 12 nm
Climate: arid to semiarid; mild, wet winters with hot,
dry summers along coast; drier with cold winters and
hot summers on high plateau; sirocco is a hot, dust/
sand-laden wind especially common in summer
Terrain: mostly high plateau and desert; some
mountains; narrow, discontinuous coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to
severe earthquakes; mud slides
Algeria (continued)
Environment - current issues: soil erosion from
overgrazing and other poor farming practices;
desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer runoff;
inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography - note: second-largest country in Africa
(after Sudan)','df9c3a34c515874d2522ce00b98e1bf45874ed45f3caaf54e2610c4c196f8706','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a50834e4246d43e5c5aed47f8703e2bf34ba1bbe18d81b35db6a2ec8bd44536',1999,'AS','American Samoa','geography',32,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
wafer: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine, moderated by southeast
trade winds; annual rainfall averages 124 inches;
rainy season from November to April, dry season from
May to October; little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and
limited coastal plains, two coral atolls (Rose Island,
Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 5%
permanent crops: 1 0%
permanent pastures: 0%
forests and woodland: 70%
other: 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December
to March
Environment - current issues: limited natural fresh
water resources; the water division of the government
has spent substantial funds in the past few years to
improve water catchments and pipelines
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: Pago Pago has one of the best
natural deepwater harbors in the South Pacific Ocean,
sheltered by shape from rough seas and protected by
peripheral mountains from high winds; strategic
location in the South Pacific Ocean
Location: Southwestern Europe, between France
and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 450 sq km
land: 450 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 125 km
border countries: France 60 km, Spain 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm,
dry summers
Terrain: rugged mountains dissected by narrow
valleys
Elevation extremes:
lowest point: Riu Valira 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 22%
other: 20% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: snowslides, avalanches
Environment - current issues: deforestation;
overgrazing of mountain meadows contributes to soil
erosion
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
9
Andorra (continued)
Geography - note: landlocked','a494c051f3e00091edcc199ae4216ed2c2666f502ef92c21f4e787be6043061e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ad540171fb7657861efe6cf39019d7dbbac49e714567c6716500722e4444ccb',1999,'AO','Angola','geography',39,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Democratic
Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1 ,246,700 sq km
land: 1 ,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo
2,51 1 km of which 220 km is the boundary of
discontiguous Cabinda Province, Republic of the
Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to October)
and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore,
phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment - current issues: the overuse of
pastures and subsequent soil erosion attributable to
population pressures; desertification; deforestation of
tropical rain forest, in response to both international
demand for tropical timber and to domestic use as
fuel, resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers
and dams; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography - note: Cabinda is separated from rest
of country by the Democratic Republic of the Congo','0cbf0d6fdda62d8f6276dfd857ab9e963993b4fef6e1ea8e407a5ead72b43e73','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95e87ab7e4872301a8519e6830682bd8a39a4fa5af96ad5f9a18394f4ef80d6f',1999,'AI','Anguilla','geography',48,'Location: Caribbean, island in the Caribbean Sea,
east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the
Caribbean
Area:
total: 91 sq km
land: 91 sq km
water: 0 sq km
Area - comparative: about half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly rock with sparse scrub oak, few
trees, some commercial salt ponds)
Irrigated land: NAsqkm
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Environment - current issues: supplies of potable
water sometimes cannot meet increasing demand
largely because of poor distribution system
Environment - international agreements:
party to: NA
signed, but not ratified: NA
13
Anguilla (continued)','7fb04b80ff79475a2a5e6399c13f6734801ef9dcec72d38ec72595dfae889724','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c45f0daaa7cb7618c4714f034928ad08bcfcc0f3dc865afe141bba0aee1453c1',1999,'AQ','Antarctica','geography',53,'Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72
million sq km ice-covered) (est.)
note: second-smallest continent (after Australia)
Area - comparative: slightly less than 1 .5 times the
size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none, but see entry on
International disputes
Climate: severe low temperatures vary with latitude,
elevation, and distance from the ocean; East
Antarctica is colder than West Antarctica because of
its higher elevation; Antarctic Peninsula has the most
moderate climate; higher temperatures occur in
January along the coast and average slightly below
freezing
Terrain: about 98% thick continental ice sheet and
2% barren rock, with average elevations between
2,000 and 4,000 meters; mountain ranges up to about
5,000 meters; ice-free coastal areas include parts of
southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo
Sound; glaciers form ice shelves along about half of
the coastline, and floating ice shelves constitute 1 1 %
of the area of the continent
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Vinson Massif 5,140 m
Natural resources: none presently exploited; iron
ore, chromium, copper, gold, nickel, platinum and
other minerals, and coal and hydrocarbons have been
found in small, uncommercial quantities
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km (1993)
Natural hazards: katabatic (gravity-driven) winds
blow coastward from the high interior; frequent
blizzards form near the foot of the plateau; cyclonic
storms form over the ocean and move clockwise along
the coast; volcanism on Deception Island and isolated
areas of West Antarctica; other seismic activity rare
and weak
Environment - current issues: in 1998, NASA
satellite data showed that the antarctic ozone hole
was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased
ultraviolet light coming through the hole damages the
DNA of icefish, an antarctic fish lacking hemoglobin;
ozone depletion earlier was shown to harm one-celled
antarctic marine plants
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: the coldest, windiest, highest,
and driest continent; during summer, more solar
radiation reaches the surface at the South Pole than is
received at the Equator in an equivalent period; mostly
uninhabitable','d25202cf3538a88baf884c79880291ae56bb51e807661d1b4a1d23cbb5d1f462','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cacaabddca624b9c174ee6683ac767f62159ab3499ad11cd6ab1e9498a3f7046',1999,'GP','Guadeloupe','geography',70,'Location: body of water mostly north of the Arctic
Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Greenland Sea,
Hudson Bay, Hudson Strait, Kara Sea, Laptev Sea,
Northwest Passage, and other tributary water bodies
Area - comparative: slightly less than 1 .5 times the
size of the US; smallest of the world''s four oceans
(after Pacific Ocean, Atlantic Ocean, and Indian
Ocean)
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature ranges;
winters characterized by continuous darkness, cold
and stable weather conditions, and clear skies;
summers characterized by continuous daylight, damp
and foggy weather, and weak cyclones with rain or
snow
Terrain: central surface covered by a perennial
drifting polar icepack that averages about 3 meters in
thickness, although pressure ridges may be three
times that size; clockwise drift pattern in the Beaufort
Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait
(between Greenland and Iceland); the icepack is
surrounded by open seas during the summer, but
more than doubles in size during the winter and
extends to the encircling landmasses; the ocean floor
is about 50% continental shelf (highest percentage of
any ocean) with the remainder a central basin
interrupted by three submarine ridges (Alpha
Cordillera, Nansen Cordillera, and Lomonsov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs calved
from glaciers in western Greenland and extreme
northeastern Canada; permafrost in islands; virtually
icelocked from October to June; ships subject to
superstructure icing from October to May
Environment - current issues: endangered marine
species include walruses and whales; fragile
ecosystem slow to change and slow to recover from
disruptions or damage
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: major chokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean
via the Bering Strait); strategic location between North
America and Russia; shortest marine link between the
extremes of eastern and western Russia; floating
research stations operated by the US and Russia;
maximum snow cover in March or April about 20 to 50
centimeters over the frozen ocean; snow cover lasts
about 10 months','8ab1125d98d057b52c4db1c052974acc49dd6f31a8878a40ecd314ad82abb9a1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27d89658c2c18702254aa594689d5a7d52c76bb97a228b07529c844ec34cc19b',1999,'AR','Argentina','geography',74,'Location: Southern South America, bordering the
South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area ■ comparative: slightly less than three-tenths
the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1 ,224 km,
Chile 5,150 km, Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate; arid in southeast;
subantarctic in southwest
Terrain: rich plains of the Pampas in northern half,
flat to rolling plateau of Patagonia in south, rugged
Andes along western border
Elevation extremes:
lowest point: Salinas Chicas -40 m (located on
Peninsula Valdes)
highest point: Cerro Aconcagua 6,962 m
Natural resources: fertile plains of the pampas,
lead, zinc, tin, copper, iron ore, manganese,
petroleum, uranium
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 52%
forests and woodland: 19%
other: 19% (1993 est.)
Irrigated land: 17,000 sq km (1 993 est.)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earthquakes;
pamperos are violent windstorms that can strike the
Pampas and northeast; heavy flooding
Environment - current issues: erosion results from
inadequate flood controls and improper land use
practices; irrigated soil degradation; desertification; air
pollution in Buenos Aires and other major cities; water
pollution in urban areas; rivers becoming polluted due
to increased pesticide and fertilizer use
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: second-largest country in South
America (after Brazil); strategic location relative to sea
lanes between South Atlantic and South Pacific
Oceans (Strait of Magellan, Beagle Channel, Drake
Passage)
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area - comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1 ,880 km, Bolivia 750 km,
Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical; substantial rainfall in the
eastern portions, becoming semiarid in the far west
Terrain: grassy plains and wooded hills east of Rio
Paraguay; Gran Chaco region west of Rio Paraguay
mostly low, marshy plain near the river, and dry forest
and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana
46 m
highest point: Cerro San Rafael 850 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 55%
forests and woodland: 32%
other: 7% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: local flooding in southeast (early
September to June); poorly drained plains may
become boggy (early October to June)
Environment - current issues: deforestation (an
estimated 2 million hectares of forest land have been
lost from 1958-85); water pollution; inadequate means
for waste disposal present health risks for many urban
residents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: landlocked; lies between
Argentina, Bolivia, and Brazil','a0aefa22d2b1cf181ac765f818e46e0ecfd2fe9aa62655a4e93d9512c009c2d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86729e4861cb6b16b441a933b5a3ad4b0bb239d1842c7b169604b79da53c7f80',1999,'AM','Armenia','geography',78,'Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent
States
Area:
total: 29,800 sq km
land: 28,400 sq km
wafer; 1 ,400 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 1 ,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia 164
km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
22
Armenia (continued)
Terrain: Armenian Highland with mountains; little
forest land; fast flowing rivers; good soil in Aras River
valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper,
molybdenum, zinc, alumina
Land use:
arable land: 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 15%
other: 41% (1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes;
droughts
Environment - current issues: soil pollution from
toxic chemicals such as DDT; energy blockade, the
result of conflict with Azerbaijan, has led to
deforestation when citizens scavenged for firewood;
pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its
use as a source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear power
plant without adequate (IAEA-recommended) safety
and backup systems
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Nuclear Test Ban, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked','5f6e63752ca0dc896244c8098072a7543ccdb2339199bfe929d401c5671a6cbb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd25000b7fdef9311ca3c64256150b49f62088c09c217e3ebbeae81cb3a0ece',1999,'GE','Georgia','geography',89,'Location: Southeastern Asia, islands in the Indian
Ocean, northwest of Australia
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East
Islets) and Cartier Island
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0 sq km (1 993)
Natural hazards: surrounded by shoals and reefs
that can pose maritime hazards
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
26
Ashmore and Cartier Islands
(continued)
Geography - note: Ashmore Reef National Nature
Reserve established in August 1983
Location: body of water between Africa, Europe,
Antarctica, and the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: World
Area:
fofa/:82.217 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea,
Davis Strait, Denmark Strait, Drake Passage, Gulf of
Mexico, Mediterranean Sea, North Sea, Norwegian
Sea, Scotia Sea, Weddell Sea, and other tributary
water bodies
Area - comparative: slightly less than nine times the
size of the US; second-largest of the world''s four
oceans (after the Pacific Ocean, but larger than Indian
Ocean or Arctic Ocean)
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off
the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and Baltic Sea from
October to June; clockwise warm-water gyre (broad,
circular system of currents) in the northern Atlantic,
counterclockwise warm-water gyre in the southern
Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin
Elevation extremes:
lowest point: Milwaukee Deep in the Puerto Rico
Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis Strait,
Denmark Strait, and the northwestern Atlantic Ocean
from February to August and have been spotted as far
south as Bermuda and the Madeira Islands; icebergs
from Antarctica occur in the extreme southern Atlantic
Ocean; ships subject to superstructure icing in
extreme northern Atlantic from October to May and
extreme southern Atlantic from May to October;
persistent fog can be a maritime hazard from May to
September
Environment - current issues: endangered marine
species include the manatee, seals, sea lions, turtles,
and whales; drift net fishing is hastening the decline of
fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern
Brazil, and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake Maracaibo,
Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North
Sea, and Mediterranean Sea
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: major chokepoints include the
Dardanelles, Strait of Gibraltar, access to the Panama
and Suez Canals; strategic straits include the Strait of
Dover, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic
Ocean and South Atlantic Ocean','30de9b937deeb4cb45ce30c7d2b4653b8b9f2a6eb4268494c60a061495036a74','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d74f20aa8bf40d282269722b485666ae204d5b383bfa4674496ea1aa401e515b',1999,'AU','Australia','geography',91,'Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total: 7,686,850 sq km
land: 7,61 7,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area - comparative: slightly smaller than the US
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciusko 2,229 m
Natural resources: bauxite, coal, iron ore, copper,
tin, silver, uranium, nickel, tungsten, mineral sands,
lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 54%
forests and woodland: 19%
other: 21% (1993 est.)
Irrigated land: 21,070 sq km (1993 est.)
Natural hazards: cyclones along the coast; severe
droughts
Environment - current issues: soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
Geography - note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; regular, tropical,
invigorating, sea breeze known as "the Doctor" occurs
along the west coast in the summer
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total: 83,858 sq km
land: 82,738 sq km
wafer: 1,120 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,562 km
border countries: Czech Republic 362 km, Germany
784 km, Hungary 366 km, Italy 430 km, Liechtenstein
35 km, Slovakia 91 km, Slovenia 330 km, Switzerland
164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; continental, cloudy; cold winters
with frequent rain in lowlands and snow in mountains;
cool summers with occasional showers
Terrain: in the west and south mostly mountains
(Alps); along the eastern and northern margins mostly
30
Austria (continued)
flat or gently sloping
Elevation extremes:
lowest point: Neusiedler See 1 1 5 m
highest point: Grossglockner 3,797 m
Natural resources: iron ore, oil, timber, magnesite,
lead, coal, lignite, copper, hydropower
Land use:
arable land: 17%
permanent crops: 1%
permanent pastures: 23%
forests and woodland: 39%
other: 20% (1996 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: some forest
degradation caused by air and soil pollution; soil
pollution results from the use of agricultural
chemicals; air pollution results from emissions by
coal- and oil-fired power stations and industrial plants
and from trucks transiting Austria between northern
and southern Europe
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategic location at
the crossroads of central Europe with many easily
traversable Alpine passes and valleys; major river is
the Danube; population is concentrated on eastern
lowlands because of steep slopes, poor soils, and low
temperatures elsewhere
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
wafer 0 sq km
note: includes numerous small islands and reefs
scattered over a sea area of about 1 million sq km,
with the Willis Islets the most important
Area - comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0 sq km (1993)
Natural hazards: occasional, tropical cyclones
Environment - current issues: no permanent fresh
water resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: important nesting area for birds
and turtles
Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
wafer: 0 sq km
Area - comparative: about 0.7 times the size of The
Mall in Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September
to mid-May) with hot, dry summers (May to
September)
Terrain: low hill
Elevation extremes:
lowest point: unnamed location 1 9 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental
Modification
Geography - note: urban; landlocked; enclave of
Rome, Italy; world''s smallest state; outside the
Vatican City, 13 buildings in Rome and Castel
Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
tofa/: 1 .6 sq km
land: 1 .6 sq km
water: 0 sq km
Area - comparative: about three times the size of
The Mall in Washington, DC
Land boundaries: Okm
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed
central area
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until
late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 5%
other: 95%
Irrigated land: 0 sq km (1 998)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: almost totally covered with
grasses, prostrate vines, and low-growing shrubs;
small area of trees in the center; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife
F People
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and
Tinian
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1 ,482 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by northeast
trade winds, little seasonal temperature variation; dry
season December to June, rainy season July to
October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands are
volcanic
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 21%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: 60%
Irrigated land: NA sq km
Natural hazards: active volcanoes on Pagan and
Agrihan; typhoons (especially August to November)
364
Northern Mariana Islands (continued)
Environment - current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered species
conflicts with development
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: strategic location in the North
Pacific Ocean','db3466dbc08c3bcf23679694f7b45e8fac2965c66fe0e26eeb80640a18c28dd5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46b5de4539a408dacc354ce4c7d16269983381bbe49840c37f017ba62b277c7',1999,'AZ','Azerbaijan','geography',100,'Location: Southwestern Asia, bordering the Caspian
Sea, between Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent
States
Area:
total: 86,600 sq km
/and:86,100sqkm
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous
Republic and the Nagorno-Karabakh region; the
region''s autonomy was abolished by Azerbaijani
Supreme Soviet on 26 November 1991
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper)
566 km, Armenia (with Azerbaijan-Naxcivan exclave)
221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km,
Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km,
est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks
Lowland) (much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag Yaylasi
(Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian
Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore,
nonferrous metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 1 1 %
other: 41% (1993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas
threatened by rising levels of the Caspian Sea
Environment - current issues: local scientists
consider the Abseron Yasaqligi (Apsheron Peninsula)
(including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the
world because of severe air, water, and soil pollution;
soil pollution results from the use of DDT as a
pesticide and also from toxic defoliants used in the
production of cotton
Environment - international agreements:
party to: Climate Change, Desertification, Ozone
Layer Protection
signed, but not ratified: Biodiversity
Geography - note: landlocked
Location: Caribbean, chain of islands in the North
Atlantic Ocean, southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by warm waters
of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Natural resources: salt, aragonite, timber
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 32%
other: Q7% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes and other tropical
storms that cause extensive flood and wind damage
Environment - current issues: coral reef decay;
solid waste disposal
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
35
Bahamas, The (continued)
Species, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location adjacent to US
and Cuba; extensive island chain','235f441e2cbce017352e7db345c57e72ba3df827d7c25e4e63cc01bc5b926900','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed08d275d8cc6762cb69d18073a6999560ccb5c63eab28bb1a75fa192a7a2415',1999,'BH','Bahrain','geography',113,'Location: Middle East, archipelago in the Persian
Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 620 sq km
land: 620 sq km
water: 0 sq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: extending to boundaries to be
determined
territorial sea: 12 nm
Climate: arid; mild, pleasant winters; very hot, humid
summers
Terrain: mostly low desert plain rising gently to low
central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 0%
other: 92% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: periodic droughts; dust storms
Environment - current issues: desertification
resulting from the degradation of limited arable land,
periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills and other
37
Bahrain (continued)
discharges from large tankers, oil refineries, and
distribution stations; no natural fresh water resources
so that groundwater and sea water are the only
sources for all water needs
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: close to primary Middle Eastern
petroleum sources; strategic location in Persian Gulf
which much of Western world''s petroleum must transit
to reach open ocean','dc037d18913bfa918156ea35d6f9ac285075c2ebefa6aee68ac4e7746fb77840','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18377d5f0f399e69c86ece04b2177c14960a951253b1ab2a105b0ef96bf2a0c',1999,'BB','Barbados','geography',129,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, northeast of
Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references: Central America and the
Caribbean
Area:
total : 430 sq km
land: 430 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland
region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 37%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 12%
other: 46% (1 993 est.)
Irrigated land: NA sq km
Natural hazards: infrequent hurricanes; periodic
landslides
Environment - current issues: pollution of coastal
waters from waste disposal by ships; soil erosion;
illegal solid waste disposal threatens contamination of
aquifers
Environment - international agreements:
party to: Climate Change, Desertification,
42
Barbados (continued)
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Biodiversity
Geography - note: easternmost Caribbean island','484e9842ba1e41254f042669c6cb4fd6c91f1db26ff326d9ee1c50b1cc52605e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d446c56d25bde7f953fe3bb19c2b743dc8426b364e41489157a11ace63dddb54',1999,'MZ','Mozambique','geography',139,'Location: Southern Africa, islands in the southern
Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Geographic coordinates: 21 30 S, 39 50 E
Map references: Africa
Area:
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
Area - comparative: about one-third the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical
Terrain: a volcanic rock 2.4 m high
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all rock)
Irrigated land: 0 sq km (1993)
Natural hazards: maritime hazard since it is usually
under water during high tide and surrounded by reefs;
subject to periodic cyclones
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total: 2,170 sq km
land: 2,1 70 sq km
water: 0 sq km
Area - comparative: slightly more than 12 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; rainy season (November to
May)
Terrain: volcanic islands, interiors vary from steep
mountains to low hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Natural resources: NEGL
Land use:
arable land: 35%
permanent crops: 1 0%
permanent pastures: 7%
forests and woodland: 1 8%
other: 30% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones possible during rainy
season (December to April); Le Kartala on Grand
Comore is an active volcano
Environment - current issues: soil degradation
and erosion results from crop cultivation on slopes
without proper terracing; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: important location at northern
end of Mozambique Channel
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
total: 2,345,41 Osq km
land: 2,267,600 sq km
water: 77,81 Osq km
Area - comparative: slightly less than one-fourth the
size of the US
Land boundaries:
total: 10,271 km
border countries: Angola 2,511 km, Burundi 233 km,
Central African Republic 1 ,577 km, Republic of the
Congo 2,410 km, Rwanda 217 km, Sudan 628 km,
Uganda 765 km, Zambia 1 ,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
territorial sea: 12nm
Climate: tropical; hot and humid in equatorial river
basin; cooler and drier in southern highlands; cooler
and wetter in eastern highlands; north of Equator - wet
season April to October, dry season December to
February; south of Equator - wet season November to
March, dry season April to October
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema
(Mount Stanley) 5,110 m
Natural resources: cobalt, copper, cadmium,
petroleum, industrial and gem diamonds, gold, silver,
zinc, manganese, tin, germanium, uranium, radium,
bauxite, iron ore, coal, hydropower potential, timber
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 77%
other: 13% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: periodic droughts in south;
volcanic activity
Environment - current issues: poaching threatens
wildlife populations; water pollution; deforestation;
refugees who arrived in mid-1994 were responsible
for significant deforestation, soil erosion, and wildlife
poaching in the eastern part of the country (most of
those refugees were repatriated in November and
December 1996)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Geography ■ note: straddles Equator; very narrow
strip of land that controls the lower Congo river and is
only outlet to South Atlantic Ocean; dense tropical rain
forest in central river basin and eastern highlands
Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from northern
Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 375 sq km
land: 375 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; hot, humid, rainy season
during northeastern monsoon (November to May); dry
season is cooler (May to November)
Terrain: generally undulating, with deep ravines and
ancient volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: cyclones during rainy season
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: part of Comoro Archipelago','094d47fd0b78c4571d297574a6db577ef750f585066e2551b6baed3cc3be9cd0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e50b005ceb4e207f05452ba7f9151bde5b5a586cf9bb6366080c54248dae6d6',1999,'BY','Belarus','geography',147,'Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Commonwealth of Independent
States
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area ■ comparative: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km,
Poland 605 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small
quantities of oil and natural gas
Land use:
arable land: 29%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 34%
other: 21% (1993 est.)
Irrigated land: 1 ,000 sq km (1 993 est.)
Natural hazards: NA
Environment - current issues: soil pollution from
pesticide use; southern part of the country
contaminated with fallout from 1986 nuclear reactor
accident at Chomobyl1 in northern Ukraine
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Biodiversity, Environmental
Modification, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the
Sea
Geography - note: landlocked','bc887173fbda6f03a246bd7344025f4cfd1d83e16116bf5fb1fd0436834ab199','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d78121f0d486d9fefab6c72605c8ccda299779899042d58416cc7345d55854e',1999,'DE','Germany','geography',157,'Location: Western Europe, bordering the North Sea,
between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total: 30,510 sq km
land: 30,230 sq km
wafer; 280 sq km
Area - comparative: about the size of Maryland
Land boundaries:
total: 1 ,385 km
border countries: France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
Coastline: 64 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors
(extends about 68 km from coast)
territorial sea: 12 nm
Climate: temperate; mild winters, cool summers;
rainy, humid, cloudy
Terrain: flat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest in
southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21%
other: 34%
Irrigated land: 10 sq km including Luxembourg
(1993 est.)
Natural hazards: flooding is a threat in areas of
reclaimed coastal land, protected from the sea by
concrete dikes
Environment - current issues: the environment is
exposed to intense pressures from human activities:
urbanization, dense transportation network, industry,
intense animal breeding and crop cultivation; air and
water pollution also have repercussions for
neighboring countries; uncertainties regarding federal
and regional responsibilities (now resolved) have
impeded progress in tackling environmental
challenges
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed , but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol
Geography - note: crossroads of Western Europe;
majority of West European capitals within 1 ,000 km of
Brussels which is the seat of both the EU and NATO
Location: Central Europe, bordering the Baltic Sea
and the North Sea, between the Netherlands and
Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total: 356,910 sq km
land: 349,520 sq km
water: 7,390 sq km
183
Germany (continued)
note: includes the formerly separate Federal Republic
of Germany, the German Democratic Republic, and
Berlin, following formal unification on 3 October 1990
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 3,621 km
border countries: Austria 784 km, Belgium 167 km,
Czech Republic 646 km, Denmark 68 km, France 451
km, Luxembourg 138 km, Netherlands 577 km,
Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12nm
Climate: temperate and marine; cool, cloudy, wet
winters and summers; occasional warm, tropical
foehn wind; high relative humidity
Terrain: lowlands in north, uplands in center,
Bavarian Alps in south
Elevation extremes:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,962 m
Natural resources: iron ore, coal, potash, timber,
lignite, uranium, copper, natural gas, salt, nickel
Land use:
arable land: 33%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 31 %
other: 20% (1993 est.)
Irrigated land: 4,750 sq km (1993 est.)
Natural hazards: flooding
Environment - current issues: emissions from
coal-burning utilities and industries and lead
emissions from vehicle exhausts (the result of
continued use of leaded fuels) contribute to air
pollution; acid rain, resulting from sulfur dioxide
emissions, is damaging forests; pollution in the Baltic
Sea from raw sewage and industrial effluents from
rivers in eastern Germany; hazardous waste disposal
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location on North
European Plain and along the entrance to the Baltic
Sea
Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area - comparative: slightly larger than Vermont
Land boundaries:
total: 748 km
border countries: Albania 151 km, Bulgaria 148 km,
Greece 228 km, Serbia and Montenegro 221 km (all
with Serbia)
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and autumns and
relatively cold winters with heavy snowfall
Terrain: mountainous territory covered with deep
basins and valleys; three large lakes, each divided by
a frontier line; country bisected by the Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Golem Korab (Majae Korabit) 2,753 m
Natural resources: chromium, lead, zinc,
manganese, tungsten, nickel, low-grade iron ore,
asbestos, sulfur, timber
Land use:
arable land: 24%
permanent crops: 2%
permanent pastures: 25%
forests and woodland: 39%
other 10% (1993 est.)
Irrigated land: 830 sq km (1993 est.)
Natural hazards: high seismic risks
Environment - current issues: air pollution from
metallurgical plants
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Macedonia, The Former Yugoslav Republic of (continued)
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; major transportation
corridor from Western and Central Europe to Aegean
Sea and Southern Europe to Western Europe
f People
Population: 2,022,604 (July 1999 est.)
note: the Macedonian Government census of July
1994 put the population at 1.94 million, but ethnic
allocations were likely undercounted
Age structure:
0-14years: 23% (male 243,190; female 228,491)
15-64 years: 67% (male 680,692; female 673,923)
65 years and over: 1 0% (male 88, 1 1 6; female
108,192) (1999 est.)
Population growth rate: 0.64% (1999 est.)
Birth rate: 15.21 births/1,000 population (1999 est.)
Death rate: 8.03 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.83 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.08 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 18.68 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.05 years
male: 70.93 years
female: 75.34 years (1 999 est.)
Total fertility rate: 2 children born/woman (1999
est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 66%, Albanian 23%,
Turkish 4%, Serb 2%, Gypsies 3%, other 2%
Religions: Eastern Orthodox 67%, Muslim 30%,
other 3%
Languages: Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy: NA
j) Government
Country name:
conventional long form: The Former Yugoslav
Republic of Macedonia
conventional short form: none
local long form: Republika Makedonija
local short form: Makedonija
abbreviation: FYROM
Data code: MK
Government type: emerging democracy
Capital: Skopje
Administrative divisions: 34 counties (opstinas,
singular - opstina) Berovo, Bitola, Brod, Debar,
Delcevo, Gevgelija, Gostivar, Kavadarci, Kicevo,
Kocani, Kratovo, Kriva Palanka, Krusevo, Kumanovo,
Murgasevo, Negotino, Ohrid, Prilep, Probistip,
Radovis, Resen, Skopje-Centar, Skopje-Cair,
Skopje-Karpos, Skopje-Kisela Voda, Skopje-Gazi
Baba, Stip, Struga, Strumica, Sveti Nikole, Tetovo,
Titov Veles, Valandovo, Vinica
note: in September 1996, the Macedonian Assembly
passed legislation changing the territorial division of
the country; names of the 123 new municipalities are
not yet available
Independence: 17 September 1991 (from
Yugoslavia)
National holiday: 8 September
Constitution: adopted 1 7 November 1991, effective
20 November 1991
Legal system: based on civil law system; judicial
review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Kiro GLIGOROV (since 27
January 1991)
head of government: Prime Minister Ljubco
GEORGIEVSKI (since 30 November 1998)
cabinet: Council of Ministers elected by the majority
vote of all the deputies in the Assembly; note - cabinet
formed by the government coalition parties
VMRO-DPMNE, DA, and DPA
elections: president elected by popular vote for a
five-year term; election last held 16 October 1994
(next to be held NA October 1 999)
election results: Kiro GLIGOROV elected president;
percent of vote - Kiro GLIGOROV 78.4%
Legislative branch: unicameral Assembly or
Sobranje (120 seats - 85 members are elected by
popular vote; 35 members come from lists of
candidates submitted by parties based on the
percentage that parties gain from the overall vote; all
serve four-year terms)
elections: last held 1 8 October and 1 November 1 998
(next to be held NA 2002)
election results: percent of vote by party - NA; seats
by party - VMRO 49, SDSM 27, PDP 14, DA 13, DPA
1 1 , LDP 4, Socialists 1 , Roma Party 1
Judicial branch: Constitutional Court, judges are
elected by the Judicial Council; Judicial Court of the
Republic, judges are elected by the Judicial Council
Political parties and leaders: Social-Democratic
Alliance of Macedonia or SDSM (former Communist
Party) [Branko CRVENKOVSKI, president]; Party for
Democratic Prosperity or PDP [Abdurahman ALITI,
president]; Liberal Democratic Party or LDP [Petar
GOSEV]; Socialist Party of Macedonia or SP
[Ljubislav IVANOV-ZINGO, president]; Internal
Macedonian Revolutionary Organization - Democratic
Party for Macedonian National Unity or
VMRO-DPMNE [Ljubcho GEORGIEVSKI, president];
Democratic Party for Albanians or DPA [Arben
XHAFERI, president]; Democratic Alternative or DA
[Vasil TUPURKOVSKI, president]; Movement for All
Macedonian Action or MAAK [Straso ANGELOVSKI];
Democratic Party of Serbs or DPSM [leader NA];
Democratic Party of Turks [leader NA]; Party for
Democratic Action [Slavic MUSLIM]; Party for the
Complete Emancipation of Romas or PCER [Bajram
BORNT]; Democratic Party of Macedonia or DPM
[Tomislav STOJANOVSKlj; Democratic Progressive
Party of Romas [leader NA]; Civic Liberal Party [leader
NA]; Worker Party [leader NA]; Movement for
Renewal in Macedonia or VMRO [leader NA]; Alliance
of Communists [leader NA]; Communist Party [leader
NA]; Alliance of Romas [leader NA]; Republican Party
for National Unity [leader NA]; Party for Democratic
Action-True Path [leader NA]; Social Democratic
Party of Macedonia or SDPM [leader NA]; League of
Democracy [leader NA]; Social Christian Party of
Macedonia [leader NA]; Party of Pensioners of
Macedonia [leader NA]
International organization participation: BIS
(pending member), CCC, CE, CEI, EAPC, EBRD,
ECE, FAO, IAEA, IBRD, ICAO, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user),
Interpol, IOC, ISO, ITU, OSCE, PFP, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO,
WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Ljubica Z. ACEVSKA
chancery: 3050 K Street, NW, Suite 21 0, Washington,
DC 20007
telephone: [1] (202) 337 3063
FAX: [1] (202) 337-3093
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador Christopher Robert
HILL
embassy: Bui. Ilindenska bb, 91000 Skopje
mailing address: American Embassy Skopje,
Department of State, Washington, DC 20521-7120
(pouch)
telephone: [389] (91)116-1 80
FAX: [389] (91)117-103
Flag description: a rising yellow sun with eight rays
extending to the edges of the red field','243e8cbcad2498f905d4b3afcfa5274177e47821f551a45b6934d954f3ca189a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56db986a2e637899dea83ee729edff1dbfe09722a49ab09531aeb90b49781a65',1999,'BJ','Benin','geography',167,'Location: Western Africa, bordering the North
Atlantic Ocean, between Nigeria and Togo
Geographic coordinates: 9 30 N, 215 E
Map references: Africa
Area:
total: 112,620 sq km
land: 11 0,620 sq km
water: 2,000 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 1 ,989 km
border countries: Burkina Faso 306 km, Niger 266
km, Nigeria 773 km, Togo 644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: mostly flat to undulating plain; some hills
and low mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
52
Benin (continued)
highest point: Mont Sokbaro 658 m
Natural resources: small offshore oil deposits,
limestone, marble, timber
Land use:
arable land: 13%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 31 %
other: 48% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan wind
may affect north in winter
Environment - current issues: recent droughts
have severely affected marginal agriculture in north;
inadequate supplies of potable water; poaching
threatens wildlife populations; deforestation;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: no natural harbors','fe38f3611a0205f1b7fde2e5d57983a005817ff21172082a609064060769b199','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0c4f3903bf7ca088cfb13a83fbc029e86f5db919d49258c84ef32cfc139a819',1999,'BR','Brazil','geography',189,'Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area:
total: 1,098,580 sq km
land: 1 ,084,390 sq km
water: 14,190 sq km
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km,
Chile 861 km, Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical to
cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, lowland plains of the Amazon
Basin
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petroleum, zinc,
tungsten, antimony, silver, iron, lead, gold, timber
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 24%
forests and woodland: 53%
other: 21% (1993 est.)
Irrigated land: 1 ,750 sq km (1 993 est.)
Natural hazards: cold, thin air of high plateau is
obstacle to efficient fuel combustion, as well as to
physical activity by those unaccustomed to it from
birth; flooding in the northeast (March-April)
Environment - current issues: the clearing of land
for agricultural purposes and the international demand
for tropical timber are contributing to deforestation;
soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture);
desertification; loss of biodiversity; industrial pollution
of water supplies used for drinking and irrigation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: Climate Change-Kyoto
Protocol, Environmental Modification, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection
Geography - note: landlocked; shares control of
Lago Titicaca, world''s highest navigable lake
(elevation 3,805 m), with Peru
Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
total: 51 ,233 sq km
land: 51 ,233 sq km
water: 0 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,459 km
border countries: Croatia 932 km, Serbia and
Montenegro 527 km (31 2 km with Serbia, 21 5 km with
Montenegro)
Coastline: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese,
forests, copper, chromium, lead, zinc
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent and destructive
earthquakes
Environment - current issues: air pollution from
metallurgical plants; sites for disposing of urban waste
are limited; widespread casualties, water shortages,
and destruction of infrastructure because of the
1992-95 civil strife
Environment - international agreements:
party to: Air Pollution, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: within Bosnia and Herzegovina''s
recognized borders, the country is divided into a joint
Muslim/Croat Federation (about 51% of the territory)
and the Bosnian Serb-led Republika Srpska [RS]
(about 49% of the territory); the region called
Herzegovina is contiguous to Croatia and traditionally
has been settled by an ethnic Croat majority
Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
water: 15, 000 sq km
Area ■ comparative: slightly smaller than Texas
Land boundaries:
tofa/:4,013 km
border countries: Namibia 1,360 km, South Africa
1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling tableland;
Kalahari Desert in southwest
Elevation extremes:
lowest point: junction of the Limpopo and Shashe
Rivers 513 m
highest point: Tsodilo Hills 1,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 47%
other: 6% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: periodic droughts; seasonal
August winds blow from the west, carrying sand and
dust across the country, which can obscure visibility
Environment - current issues: overgrazing;
desertification; limited fresh water resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; population
concentrated in eastern part of the country
Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references: South America
Area:
total: 8,51 1 ,965 sq km
land: 8,456,510 sq km
wafer: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha,
Atol das Rocas, llha da Trindade, llhas Martin Vaz,
and Penedos de Sao Pedro e Sao Paulo
Area - comparative: slightly smaller than the US
Land boundaries:
total: 14,691 km
border countries: Argentina 1,224 km, Bolivia 3,400
km, Colombia 1 ,643 km, French Guiana 673 km,
Guyana 1,119 km, Paraguay 1 ,290 km, Peru 1,560
km, Suriname 597 km, Uruguay 985 km, Venezuela
2,200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
ferr/for/a/sea:12nm
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some
plains, hills, mountains, and narrow coastal belt
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore,
manganese, nickel, phosphates, platinum, tin,
uranium, petroleum, hydropower, timber
Land use:
arable land: 5%
permanent crops: 1 %
permanent pastures: 22%
forests and woodland: 58%
other: 14% (1993 est.)
66
Brazil (continued)
Irrigated land: 28,000 sq km (1993 est.)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment - current issues: deforestation in
Amazon Basin destroys the habitat and endangers
the existence of a multitude of plant and animal
species indigenous to the area; air and water pollution
in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by
improper mining activities
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: largest country in South
America; shares common boundaries with every
South American country except Chile and Ecuador
Location: Southern Asia, archipelago in the Indian
Ocean, about one-half the way from Africa to','f88d937d0646f6a9b84dee05b9665c8d14cbad3235035f9e2256da507990f403','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81931c97625036e21bfc303bd55628fbdd8035109681d60a8ece47a71447a891',1999,'ID','Indonesia','geography',199,'Geographic coordinates: 6 00 S, 71 30 E
Map references: World
Area:
total: 60 sq km
land: 60 sq km
water: 0 sq km
note: includes the entire Chagos Archipelago
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical marine; hot, humid, moderated by
trade winds
Terrain: flat and low (up to four meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 15
m
Natural resources: coconuts, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: NA%
other: NA%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: archipelago of 2,300 islands;
Diego Garcia, largest and southernmost island,
occupies strategic location in central Indian Ocean;
island is site of joint US-UK military facility
Location: Southeastern Asia, archipelago between
the Indian Ocean and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
tofa/: 1 ,91 9,440 sq km
land: 1 ,826,440 sq km
water: 93,000 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 2,602 km
border countries: Malaysia 1,782 km, Papua New
Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: mostly coastal lowlands; larger islands have
interior mountains
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas,
nickel, timber, bauxite, copper, fertile soils, coal, gold,
silver
Land use:
arable land: 10%
permanent crops: 7%
permanent pastures: 7%
forests and woodland: 62%
other: 14% (1993 est.)
Irrigated land: 45,970 sq km (1993 est.)
Natural hazards: occasional floods, severe
droughts, tsunamis, earthquakes, volcanoes
Environment - current issues: deforestation; water
pollution from industrial wastes, sewage; air pollution
in urban areas; smoke and haze from forest fires
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertication,
Endangered Species, Hazardous Wastes, Law of the
Sea, NuclearTest Ban, Ozone Layer Protection, Ship
Pollution, T ropical Timber 83, T ropical Timber 94,
Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: archipelago of 17,000 islands
(6,000 inhabited); straddles Equator; strategic
location astride or along major sea lanes from Indian
Ocean to Pacific Ocean
Location: Middle East, bordering the Gulf of Oman,
the Persian Gulf, and the Caspian Sea, between Iraq
and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
total: 1 .648 million sq km
land: 1 .636 million sq km
water: 12,000 sq km
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35
km, Azerbaijan-proper 432 km, Azerbaijan-Naxcivan
exclave 179 km, Iraq 1,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km
note: Iran also borders the Caspian Sea (740 km)
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements, or
median lines in the Persian Gulf
territorial sea: 12 nm
Climate: mostly arid or semiarid, subtropical along
Caspian coast
Terrain: rugged, mountainous rim; high, central
basin with deserts, mountains; small, discontinuous
plains along both coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Qo\\\\eh-ye Damavand 5,671 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 27%
forests and woodland: 7%
other: 55% (1993 est.)
Irrigated land: 94,000 sq km (1993 est.)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes along western
border and in the northeast
Environment - current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution
in the Persian Gulf; inadequate supplies of potable
water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Life Conservation
Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
land: 432,162 sq km
water: 4,91 Osq km
Area - comparative: slightly more than twice the
size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km,
Kuwait 242 km, Saudi Arabia 814 km, Syria 605 km,
Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
Climate: mostly desert; mild to cool winters with dry,
hot, cloudless summers; northern mountainous
233
Iraq (continued)
regions along Iranian and Turkish borders experience
cold winters with occasionally heavy snows that melt
in early spring, sometimes causing extensive flooding
in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Gundah Zhur 3,608 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
other: 79% (1993 est.)
Irrigated land: 25,500 sq km (1993 est.)
Natural hazards: dust storms, sandstorms, floods
Environment - current issues: government water
control projects have drained most of the inhabited
marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable
population of Shi''a Muslims, who have inhabited these
areas for thousands of years, has been displaced;
furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water;
development of Tigris-Euphrates Rivers system
contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation
(salination) and erosion; desertification
Environment - international agreements:
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Location: Western Europe, occupying five-sixths of
the island of Ireland in the North Atlantic Ocean, west
of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
water: 1 ,390 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain
surrounded by rugged hills and low mountains; sea
cliffs on west coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Carrauntoohill 1 ,041 m
Natural resources: zinc, lead, natural gas, barite,
copper, gypsum, limestone, dolomite, peat, silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 68%
forests and woodland: 5%
other: 14% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: water pollution,
especially of lakes, from agricultural runoff
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Biodiversity, Climate
Change, Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Endangered Species, Marine Life Conservation,
Tropical Timber 94
Geography - note: strategic location on major air
and sea routes between North America and northern
Europe; over 40% of the population resides within 97
km of Dublin
Location: Southeastern Asia, peninsula and
northern one-third of the island of Borneo, bordering
Indonesia and the South China Sea, south of Vietnam
Geographic coordinates: 2 30 N, 1 12 30 E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water: 1 ,200 sq km
Area - comparative: slightly largerthan New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1 ,782 km,
Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km,
East Malaysia 2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation; specified boundary in the South China
Sea
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper,
iron ore, natural gas, bauxite
Land use:
arable land: 3%
permanent crops: 1 2%
permanent pastures: 0%
forests and woodland: 68%
other: 17% {1993 est.)
Irrigated land: 2,941 sq km (1998 est.)
Natural hazards: flooding, landslides
Environment - current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location along Strait of
Malacca and southern South China Sea
Location: Oceania, island group in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km
note: includes Pohnpei (Ponape), Truk (Chuuk)
Islands, Yap Islands, and Kosrae
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; heavy year-round rainfall,
especially in the eastern islands; located on southern
edge of the typhoon belt with occasionally severe
damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls; volcanic
outcroppings on Pohnpei, Kosrae, and Truk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Totolom 791 m
Natural resources: forests, marine products,
deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: typhoons (June to December)
323
Micronesia, Federated States of (continued)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed , but not ratified: Climate Change-Kyoto
Protocol
Geography - note: four major island groups totaling
607 islands
Location: Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east of
Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
land: 298,170 sq km
wafer 1 ,830 sq km
Area - comparative: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: irregular polygon extending up to 100
nm from coastline as defined by 1 898 treaty; since late
1970s has also claimed polygonal-shaped area in
South China Sea up to 285 nm in breadth
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May to
October)
Terrain: mostly mountains with narrow to extensive
coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 1 2%
permanent pastures: 4%
forests and woodland: 46%
other: 19% (1993 est.)
Irrigated land: 15,800 sq km (1993 est.)
Natural hazards: astride typhoon belt, usually
affected by 1 5 and struck by five to six cyclonic storms
per year; landslides; active volcanoes; destructive
earthquakes; tsunamis
Environment - current issues: uncontrolled
deforestation in watershed areas; soil erosion; air and
water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish
breeding grounds
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
Location: Oceania, islands in the South Pacific
Ocean, about one-half of the way from Peru to New
Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total: 47 sqkm
land: 47 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: tropical, hot, humid; modified by southeast
trade winds; rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline
with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc
have been discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: typhoons (especially November to
March)
Environment - current issues: deforestation (only
a small portion of the original forest remains because
of burning and clearing for settlement)
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Singapore (continued)
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: focal point for Southeast Asian
sea routes','f3f729dcc05d28c568b78ab0f01f3c9b915a5107c6d26c9d780bd9d49414675e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54e38264edaab957dfc317e57ab234a13399be5d10407a029cf35b9258dbb08c',1999,'IO','British Indian Ocean Territory','geography',210,'Location: Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the
Caribbean
Area:
total: 150 sq km
land: 150 sq km
water: 0 sq km
note: includes the island of Anegada
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volcanic islands
steep, hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 7%
permanent pastures: 33%
forests and woodland: 7%
other: 33% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms
(July to October)
Environment - current issues: limited natural fresh
water resources (except for a few seasonal streams
and springs on Tortola, most of the islands'' water
supply comes from wells and rainwater catchment)
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: strong ties to nearby US Virgin
Islands and Puerto Rico
Location: Southeastern Europe, bordering the Black
Sea, between Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
fofa/; 1 1 0,91 0 sq km
land: 11 0,550 sq km
water: 360 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,808 km
border countries: Greece 494 km, The Former
Yugoslav Republic of Macedonia 148 km, Romania
608 km, Serbia and Montenegro 318 km (all with
Serbia), Turkey 240 km
Coastline: 354 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; cold, damp winters; hot, dry
summers
Terrain: mostly mountains with lowlands in north and
southeast
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc, coal,
timber, arable land
Land use:
arable land: 37%
permanent crops: 2%
permanent pastures: 16%
forests and woodland: 35%
other: 10% (1993 est.)
Irrigated land: 12,370 sq km (1993 est.)
Natural hazards: earthquakes, landslides
Environment - current issues: air pollution from
industrial emissions; rivers polluted from raw sewage,
heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical
plants and industrial wastes
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
Geography - note: strategic location near Turkish
Straits; controls key land routes from Europe to Middle
East and Asia
Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area - comparative: slightly larger than Colorado
Land boundaries:
total: 3,192 km
border countries: Benin 306 km, Ghana 548 km, Cote
d''Ivoire 584 km, Mali 1 ,000 km, Niger 628 km, Togo
126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers
Terrain: mostly flat to dissected, undulating plains;
hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone, marble;
small deposits of gold, antimony, copper, nickel,
bauxite, lead, phosphates, zinc, silver
Land use:
arable /and: 13%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 50%
other: 15% (1993 est.)
Irrigated land: 200 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: recent droughts and
desertification severely affecting agricultural activities,
population distribution, and the economy;
overgrazing; soil degradation; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed , but not ratified: Law of the Sea, Nuclear Test
Ban
Geography - note: landlocked','3a38ff4d186c130d88a83ded3025193350fc4e11a8cb1f08a0c65926d5908a22','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05ca82907c02b7afd00a0746d611402605aafdbf637e13cf7860980913f6e0bd',1999,'NG','Nigeria','geography',221,'Location: Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between
Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km, China 2,185
km, India 1 ,463 km, Laos 235 km, Thailand 1 ,800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; cloudy, rainy, hot, humid
summers (southwest monsoon, June to September);
less cloudy, scant rainfall, mild temperatures, lower
humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged
highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony,
zinc, copper, tungsten, lead, coal, some marble,
limestone, precious stones, natural gas
Land use:
arable land: 15%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 49%
other: 34% (1993 est.)
Irrigated land: 10,680 sq km (1993 est.)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment - current issues: deforestation;
industrial pollution of air, soil, and water; inadequate
sanitation and water treatment contribute to disease
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near major
Indian Ocean shipping lanes
Location: Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total: 923,770 sq km
land: 910,770 sq km
water: 13,000 sq km
Area - comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1 ,690 km,
Chad 87 km, Niger 1 ,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: varies; equatorial in south, tropical in
center, arid in north
Terrain: southern lowlands merge into central hills
and plateaus; mountains in southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: petroleum, tin, columbite, iron
ore, coal, limestone, lead, zinc, natural gas
Land use:
arable land: 33%
permanent crops: 3%
permanent pastures: 44%
forests and woodland: 12%
other: 8% (1993 est.)
Irrigated land: 9,570 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: soil degradation;
rapid deforestation; desertification; recent droughts in
north severely affecting marginal agricultural activities
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements','3b111304410bf1d36246439f7f0f007fb428de2c0438be8aa89af9c5f645bcb2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94608040c45ed38ce4d69d982a2410d59a68560215bde5bdd5caa1e2751b7096',1999,'BI','Burundi','geography',225,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo
233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable
altitude variation (772 m to 2,760 m); average annual
80
Burundi (continued)
temperature varies with altitude from 23 to 1 7 degrees
centigrade but is generally moderate as the average
altitude is about 1 ,700 m; average annual rainfall is
about 1 50 cm; wet seasons from February to May and
September to November, and dry seasons from June
to August and December to January
Terrain: hilly and mountainous, dropping to a plateau
in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,670 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum (not yet
exploited), vanadium
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
other: 8% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides
Environment - current issues: soil erosion as a
result of overgrazing and the expansion of agriculture
into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test
Ban
Geography - note: landlocked; straddles crest of the
Nile-Congo watershed
Location: Southeastern Asia, bordering the Gulf of
Thailand, between Thailand, Vietnam, and Laos
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 1 81 ,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area - comparative: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km,
Vietnam 1 ,228 km
Coastline: 443 km
Maritime claims:
contiguous zone : 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, monsoon season (May to
November); dry season (December to April); little
seasonal temperature variation
Terrain: mostly low, flat plains; mountains in
southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: timber, gemstones, some iron
ore, manganese, phosphates, hydropower potential
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 920 sq km (1993 est.)
Natural hazards: monsoonal rains (June to
November); flooding; occasional droughts
Environment - current issues: illegal logging
82
Cambodia (continued)
activities throughout the country and strip mining for
gems in the western region along the border with
Thailand are resulting in habitat loss and declining
biodiversity (in particular, destruction of mangrove
swamps threatens natural fisheries); soil erosion; in
rural areas, a majority of the population does not have
access to potable water; toxic waste delivery from
Taiwan sparked unrest in Kampong Saom
(Sihanoukville) in December 1998
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine Life
Conservation, Ship Pollution, Tropical Timber 94
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography - note: a land of paddies and forests
dominated by the Mekong River and Tonle Sap
Location: Western Africa, bordering the Bight of
Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 4,591 km
border countries: Central African Republic 797 km,
Chad 1 ,094 km, Republic of the Congo 523 km,
Equatorial Guinea 189 km, Gabon 298 km, Nigeria
1,690 km
Coastline: 402 km
Maritime claims:
territorial sea: 50 nm
Climate: varies with terrain, from tropical along coast
to semiarid and hot in north
Terrain: diverse, with coastal plain in southwest,
dissected plateau in center, mountains in west, plains
in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore,
timber, hydropower
Land use:
arable land: 13%
permanent crops: 2%
permanent pastures: 4%
forests and woodland: 78%
other: 3% (1993 est.)
Irrigated land: 210 sq km (1993 est.)
Natural hazards: recent volcanic activity with
release of poisonous gases
Environment - current issues: water-borne
diseases are prevalent; deforestation; overgrazing;
desertification; poaching; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, T ropical Timber 83, T ropical
Timber 94
signed, but not ratified: Nuclear Test Ban
Geography - note: sometimes referred to as the
hinge of Africa','dfde53a239834ec7b85d6798f1d3ff8c49e9736cbd614388fcf4ac08f58f6487','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('772f79cd699583563f3cfe6faa3497ecb3eb3779f09dd1a8769813cab0ad92db',1999,'CA','Canada','geography',233,'Location: Northern North America, bordering the
North Atlantic Ocean and North Pacific Ocean, north
of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
total: 9,976,140 sq km
land: 9,220,970 sq km
wafer: 755,1 70 sq km
Area - comparative: slightly larger than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km
with Alaska)
Coastline: 243,791 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: varies from temperate in south to subarctic
and arctic in north
Terrain: mostly plains with mountains in west and
lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,950 m
Natural resources: nickel, zinc, copper, gold, lead,
molybdenum, potash, silver, fish, timber, wildlife, coal,
petroleum, natural gas
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 38% (1993 est.)
Irrigated land: 7,100 sq km (1993 est.)
Natural hazards: continuous permafrost in north is a
serious obstacle to development; cyclonic storms
form east of the Rocky Mountains, a result of the
mixing of air masses from the Arctic, Pacific, and
North American interior, and produce most of the
country''s rain and snow
Environment - current issues: air pollution and
resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters
becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea,
Marine Life Conservation
Geography ■ note: second-largest country in world
(after Russia); strategic location between Russia and
US via north polar route; nearly 90% of the population
is concentrated within 160 km of the US/Canada
border
Location: Western Africa, group of islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: World
Area:
total: 4,030 sq km
land: 4,030 sq km
water: 0 sq km
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; warm, dry summer; precipitation
meager and very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo
Island)
Natural resources: salt, basalt rock, pozzuolana (a
siliceous volcanic ash used to produce hydraulic
cement), limestone, kaolin, fish
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 0%
other: 83% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: prolonged droughts; harmattan
wind can obscure visibility; volcanically and
seismically active
Environment - current issues: overgrazing of
livestock and improper land use such as the
cultivation of crops on steep slopes has led to soil
89
Cape Verde (continued)
erosion; demand for wood used as fuel has resulted in
deforestation; desertification; environmental damage
has threatened several species of birds and reptiles;
overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Nuclear Test Ban
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location 500 km from
west coast of Africa near major north-south sea
routes; important communications station; important
sea and air refueling site','7104a2c146cddf05cd95b2ae481fdde00d7dc1ec8b2da8108783d4cf124251d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45cf130b9f8a555e984b3dec9cc77c64ef57b5aa06617022512870c6443cbc92',1999,'HN','Honduras','geography',255,'Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,980 sq km
land: 622,980 sq km
water: 0 sq km
Area ■ comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1 ,1 97 km,
Democratic Republic of the Congo 1 ,577 km,
Republic of the Congo 467 km, Sudan 1 ,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet
summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1,420 m
Natural resources: diamonds, uranium, timber,
gold, oil
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment - current issues: tap water is not
potable; poaching has diminished its reputation as
one of the last great wildlife refuges; desertification;
deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost the precise
center of Africa
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1 .284 million sq km
land: 1 ,259,200 sq km
water: 24,800 sq km
Area - comparative: slightly more than three times
the size of California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1 ,094 km, Central
African Republic 1,197 km, Libya 1,055 km, Niger
1 ,175 km, Nigeria 87 km, Sudan 1 ,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north,
mountains in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but
exploration under way), uranium, natron, kaolin, fish
(Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment - current issues: inadequate
supplies of potable water; improper waste disposal in
rural areas contributes to soil and water pollution;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography - note: landlocked; Lake Chad is the
most significant water body in the Sahel
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Nicaragua and
bordering the North Pacific Ocean, between El
Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30 W
Map references: Central America and the
Caribbean
Area:
total: 112,090 sq km
land: 1 1 1 ,890 sq km
water: 200 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,520 km
border countries: Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural extension of territory or to
200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical in lowlands, temperate in
mountains
Terrain: mostly mountains in interior, narrow coastal
plains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper,
lead, zinc, iron ore, antimony, coal, fish
Land use:
arable land: 15%
permanent crops: 3%
permanent pastures: 14%
forests and woodland: 54%
other: 14% (1993 est.)
Irrigated land: 740 sq km (1993 est.)
214
Honduras (continued)
Natural hazards: frequent, but generally mild,
earthquakes; damaging hurricanes and floods along
Caribbean coast
Environment - current issues: urban population
expanding; deforestation results from logging and the
clearing of land for agricultural purposes; further land
degradation and soil erosion hastened by
uncontrolled development and improper land use
practices such as farming of marginal lands; mining
activities polluting Lago de Yojoa (the country''s
largest source of fresh water) as well as several rivers
and streams with heavy metals; severe Hurricane
Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
f . T . . . ; . '';"''.:pTo p;i"e
Population: 5,997,327 (July 1999 est.)
Age structure:
0-14 years: 41% (male 1,262,190; female 1,217,752)
15-64 years: 55% (male 1 ,643,550; female
1,665,666)
65 years and over: 4% (male 98,71 5; female
109,454) (1999 est.)
Population growth rate: 2.24% (1999 est.)
Birth rate: 30.98 births/1 ,000 population (1 999 est.)
Death rate: 7.14 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .46 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 40.84 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.68 years
male: 63.1 6 years
female: 66.27 years (1999 est.)
Total fertility rate: 3.97 children born/woman (1999
est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 72.7%
male: 72.6%
female: 72.7% (1995 est.)','5fcbc3baf3c02d61edc4e36cd69bc85a82982422e1d06ac3a25f16aeec9cfd6c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b36423cf03843c131cfd47e8d62cd80b6548df233e0dd730f1fe66d84d2f9f18',1999,'CL','Chile','geography',257,'Location: Southern South America, bordering the
South Atlantic Ocean and South Pacific Ocean,
between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla
Sala y Gomez
Area - comparative: slightly smaller than twice the
size of Montana
Land boundaries:
total: Q, 171 km
border countries: Argentina 5,150 km, Bolivia 861 km,
Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
97
Chile (continued)
Climate: temperate; desert in north; cool and damp
in south
Terrain: low coastal mountains; fertile central valley;
rugged Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 18%
forests and woodland: 22%
other: 55% (1993 est.)
Irrigated land: 12,650 sq km (1993 est.)
Natural hazards: severe earthquakes; active
volcanism; tsunamis
Environment - current issues: air pollution from
industrial and vehicle emissions; water pollution from
raw sewage; deforestation contributing to loss of
biodiversity; soil erosion; desertification
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage);
Atacama Desert is one of world''s driest regions','632e7f8e38180aa68cd4f98f24dcf34d491e2d3cc227a328b74a9c964904e33f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('000974864bf7d0d97022fea579654bfd954cf7099272dbe1e186b0bd321b75d5',1999,'CN','China','geography',266,'Location: Eastern Asia, bordering the East China
Sea, Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
Area - comparative: slightly smaller than the US
Land boundaries:
total: 22,143.34 km
border countries: Afghanistan 76 km, Bhutan 470 km,
Burma 2,185 km, Hong Kong 30 km, India 3,380 km,
Kazakhstan 1,533 km, North Korea 1,416 km,
Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km,
Mongolia 4,673 km, Nepal 1,236 km, Pakistan 523
km, Russia (northeast) 3,605 km, Russia (northwest)
40 km, Tajikistan 414 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
territorial sea: 12 nm
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts in
west; plains, deltas, and hills in east
Elevation extremes:
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,848 m
Natural resources: coal, iron ore, petroleum, natural
gas, mercury, tin, tungsten, antimony, manganese,
molybdenum, vanadium, magnetite, aluminum, lead,
zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 43%
forests and woodland: 14%
other: 33% (1 993 est.)
Irrigated land: 498,720 sq km (1993 est.)
Natural hazards: frequent typhoons (about five per
year along southern and eastern coasts); damaging
floods; tsunamis; earthquakes; droughts
Environment - current issues: air pollution
(greenhouse gases, sulfur dioxide particulates) from
reliance on coal, produces acid rain; water shortages,
particularly in the north; water pollution from untreated
wastes; deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and
economic development; desertification; trade in
endangered species
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
100
China (continued)
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed , but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: world''s fourth-largest country
(after Russia, Canada, and US)
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
total: 1 .565 million sq km
land: 1 .565 million sq km
water: 0 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
tola/: 8,1 14 km
border countries: China 4,673 km, Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
? 19° 200 km
0 100 200 mi
the converting of virgin land to agricultural production
have increased soil erosion from wind and rain;
desertification; mining activities have also had a
deleterious effect on the environment
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; strategic location
between China and Russia
Location: Southeastern Asia, group of reefs and
islands in the South China Sea, about two-thirds of the
way from southern Vietnam to the southern','3a46b240353abd4bde0f2b5da75c4fcdb257584154abcd74053f67018c2f6ab8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85806f5631988a7635b7409782889fed21141f1815eb372cac53e47aa576c69f',1999,'FR','France','geography',281,'Location: Southeastern Asia, group of islands in. the
Indian Ocean, south of Indonesia, about one-half of
the way from Australia to Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
total: 14 sq km
land: 14 sq km
wafer: 0 sq km
note: includes the two main islands of West Island and
Home Island
Area - comparative: about 24 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: pleasant, modified by the southeast trade
wind for about nine months of the year; moderate
rainfall
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones may occur in the early
months of the year
Environment - current issues: fresh water
resources are limited to rainwater accumulations in
natural underground reservoirs
Environment ■ international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: two coral atolls thickly covered
with coconut palms and other vegetation
Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12, 173 sqkm
water: Osq km
note: includes the two main islands of East and West
Falkland and about 200 small islands
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 nm
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: cold marine; strong westerly winds, cloudy,
humid; rain occurs on more than half of days in year;
occasional snow all year, except in January and
February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy,
undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 99%
forests and woodland: 0%
other: 1% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: strong winds persist throughout
the year
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: deeply indented coast provides
good natural harbors; short growing season
Location: Western Europe, bordering the Bay of
Biscay and English Channel, between Belgium and
Spain southeast of the UK; bordering the
Mediterranean Sea, between Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
total: 547,030 sq km
land: 545,630 sq km
wafer: 1 ,400 sq km
note: includes only metropolitan France, but excludes
the overseas administrative divisions
Area - comparative: slightly less than twice the size
of Colorado
Land boundaries:
total: 2,892.4 km
border countries: Andorra 60 km, Belgium 620 km,
Germany 451 km, Italy 488 km, Luxembourg 73 km,
Monaco 4.4 km, Spain 623 km, Switzerland 573 km
Coastline: 3,427 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm (does not apply to
the Mediterranean)
territorial sea: 12 nm
Climate: generally cool winters and mild summers,
but mild winters and hot summers along the
Mediterranean
Terrain: mostly flat plains or gently rolling hills in
north and west; remainder is mountainous, especially
Pyrenees in south, Alps in east
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, fish,
timber, zinc, potash
Land use:
arable land: 33%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 27%
other 18% (1993 est.)
Irrigated land: 16,300 sq km (1995 est.)
Natural hazards: flooding; avalanches
Environment - current issues: some forest
damage from acid rain; air pollution from industrial and
vehicle emissions; water pollution from urban wastes,
agricultural runoff
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: largest West European nation;
occasional strong, cold, dry, north-to-northwesterly
wind known as mistral
Location: south of Africa, islands in the southern
Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note - French Southern and
Antarctic Lands includes lie Amsterdam, lie
Saint-Paul, lies Crozet, and lies Kerguelen in the
southern Indian Ocean, along with the
French-claimed sector of Antarctica, “Adelie Land";
the US does not recognize the French claim to "Adelie
Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,781 sq km
land: 7,781 sq km
wafer: 0 sq km
note: includes lie Amsterdam, lie Saint-Paul, lies
Crozet and lies Kerguelen; excludes "Adelie Land"
claim of about 500,000 sq km in Antarctica that is not
recognized by the US
Area - comparative: slightly less than 1 .3 times the
size of Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 nm from lies
Kerguelen only
territorial sea: 12 nm
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on lie Kerguelen 1 ,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: lie Amsterdam and lie
Saint-Paul are extinct volcanoes
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: remote location in the southern
Indian Ocean
Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
tofa/: 1 31 ,940 sq km
land: 130,800 sq km
wafer: 1,140 sq km
Area - comparative: slightly smaller than Alabama
Land boundaries:
tofa/: 1 ,21 0 km
border countries: Albania 282 km, Bulgaria 494 km,
Turkey 206 km, The Former Yugoslav Republic of
Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 6 nm
Climate: temperate; mild, wet winters; hot, dry
summers
Terrain: mostly mountains with ranges extending
into sea as peninsulas or chains of islands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: bauxite, lignite, magnesite,
petroleum, marble
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 41 %
forests and woodland: 20%
other: 12% (1993 est.)
Irrigated land: 13,140 sq km (1993 est.)
Natural hazards: severe earthquakes
Environment - current issues: air pollution; water
pollution
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol
Geography - note: strategic location dominating the
Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an
archipelago of about 2,000 islands
Location: Northern Africa, bordering the
Mediterranean Sea, between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: 12 nm
Climate: temperate in north with mild, rainy winters
and hot, dry summers; desert in south
Terrain: mountains in north; hot, dry central plain;
semiarid south merges into the Sahara
Elevation extremes:
lowest point: Shaft al Gharsah -17 m
highest point: Jabal ash Shanabi 1,544 m
Natural resources: petroleum, phosphates, iron
ore, lead, zinc, salt
Land use:
arable land: 19%
permanent crops: 13%
permanent pastures: 20%
forests and woodland: 4%
other: 44% (1993 est.)
Irrigated land: 3,850 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: toxic and
hazardous waste disposal is ineffective and presents
human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location in central
Mediterranean
Location: southwestern Asia (that part west of the
Bosporus is sometimes included with Europe),
bordering the Black Sea, between Bulgaria and
Georgia, and bordering the Aegean Sea and the
Mediterranean Sea, between Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
wafer 9,820 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km,
Bulgaria 240 km, Georgia 252 km, Greece 206 km,
Iran 499 km, Iraq 331 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only: to the
maritime boundary agreed upon with the former
USSR
territorial sea: 6 nm in the Aegean Sea; 1 2 nm in Black
Sea and in Mediterranean Sea
Climate: temperate; hot, dry summers with mild, wet
winters; harsher in interior
Terrain: mostly mountains; narrow coastal plain;
high central plateau (Anatolia)
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal, chromium,
mercury, copper, borate, sulfur, iron ore
Land use:
arable land: 32%
permanent crops: 4%
permanent pastures: 16%
forests and woodland: 26%
other: 22% (1993 est.)
Irrigated land: 36,740 sq km (1993 est.)
Natural hazards: very severe earthquakes,
especially in northern Turkey, along an arc extending
from the Sea of Marmara to Lake Van
Environment - current issues: water pollution from
dumping of chemicals and detergents; air pollution,
particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
Environment - international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Hazardous Wastes, NuclearTest Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Environmental Modification
Geography - note: strategic location controlling the
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean Seas
Location: Central Asia, bordering the Caspian Sea,
between Iran and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent
States
Area:
total: 488, 100 sq km
land: 488, 100 sq km
water: 0 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km,
Kazakhstan 379 km, Uzbekistan 1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea (1 ,768
km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising
to mountains in the south; low mountains along border
with Iran; borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadina Akchanaya -81 m (note -
Sarygamysh Koli is a lake in north eastern
Turkmenistan whose water levels fluctuate widely; at
its shallowest, its level is -1 10 m; it is presently at -60
m, 20 m above Vpadina Akchanaya)
highest point: Ayrybaba 3,1 39 m
Natural resources: petroleum, natural gas, coal,
sulfur, salt
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 63%
forests and woodland: 8%
other: 26% (1993 est.)
Irrigated land: 13,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with agricultural chemicals,
pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of
a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish
the Aral Sea; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
land: 241 ,590 sq km
wafer: 3,230 sq km
note: includes Rockall and Shetland Islands
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
continental shelf: as defined in continental shelf
orders or in accordance with agreed upon boundaries
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current; more
than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains; level
to rolling plains in east and southeast
Elevation extremes:
lowest point: Fenland -4 m
highest point: Ben Nevis 1 ,343 m
Natural resources: coal, petroleum, natural gas, tin,
limestone, iron ore, salt, clay, chalk, gypsum, lead,
silica
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 10%
other: (1993 est.)
Irrigated land: 1 ,080 sq km (1 993 est.)
Natural hazards: NA
Environment - current issues: sulfur dioxide
emissions from power plants contribute to air
pollution; some rivers polluted by agricultural wastes;
and coastal waters polluted because of large-scale
disposal of sewage at sea
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Ait Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: lies near vital North Atlantic sea
lanes; only 35 km from France and now linked by
tunnel under the English Channel; because of heavily
indented coastline, no location is more than 125 km
from tidal waters
505
United Kingdom (continued)
Location: North America, bordering both the North
Atlantic Ocean and the North Pacific Ocean, between
Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,629,091 sq km
land: 9,158,960 sq km
wafer: 470,131 sq km
note: includes only the 50 states and District of
Columbia
Area - comparative: about one-half the size of
Russia; about three-tenths the size of Africa; about
one-half the size of South America (or slightly larger
than Brazil); slightly larger than China; about two and
one-half times the size of Western Europe
Land boundaries:
total: 12,248 km
border countries: Canada 8,893 km (including 2,477
km with Alaska), Cuba 29 km (US Naval Base at
Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 19,924 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate, but tropical in Hawaii and
Florida, arctic in Alaska, semiarid in the great plains
west of the Mississippi River, and arid in the Great
Basin of the southwest; low winter temperatures in the
northwest are ameliorated occasionally in January
and February by warm Chinook winds from the eastern
slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills
and low mountains in east; rugged mountains and
broad river valleys in Alaska; rugged, volcanic
topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite, gold,
iron, mercury, nickel, potash, silver, tungsten, zinc,
petroleum, natural gas, timber
Land use:
arable land: 19%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 30%
other: 26% (1993 est.)
Irrigated land: 207,000 sq km (1993 est.)
Natural hazards: tsunamis, volcanoes, and
earthquake activity around Pacific Basin; hurricanes
along the Atlantic and Gulf of Mexico coasts;
tornadoes in the midwest and southeast; mud slides in
California; forest fires in the west; flooding; permafrost
in northern Alaska, a major impediment to
development
Environment - current issues: air pollution
resulting in acid rain in both the US and Canada; the
US is the largest single emitter of carbon dioxide from
the burning of fossil fuels; water pollution from runoff
of pesticides and fertilizers; very limited natural fresh
water resources in much of the western part of the
country require careful management; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
508
United States (continued)
Antarctic-Environmental Protocol, Antarctic Treaty,
Climate Change, Endangered Species,
Environmental Modification, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes
Geography - note: world''s third-largest country
(after Russia and Canada)
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the
northwest quarter of the Dead Sea, but excludes Mt.
Scopus; East Jerusalem and Jerusalem No Man''s
Land are also included only as a means of depicting
the entire area occupied by Israel in 1967
Area - comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation
vary with altitude, warm to hot summers, cool to mild
winters
Terrain: mostly rugged dissected upland, some
vegetation in west, but barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1 ,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 32%
forests and woodland: 1 %
other: 40%
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: adequacy of fresh
water supply; sewage treatment
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; highlands are main
recharge area for Israel''s coastal aquifers; there are
216 Israeli settlements and civilian land use sites in
the West Bank and 29 in East Jerusalem (August
1998 est.)','0d916b5c219dcc50abe325aa30bf4d9935f0ddb69af3721c8447398971f8ce4d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1cba3b6aed323356efacb1b25542a78531be051ccd6cc2600fc32327ceeaf6d',1999,'CO','Colombia','geography',292,'Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America, Central America
and the Caribbean
Area:
total: 1,138,910 sq km
land: 1 ,038,700 sq km
water: 1 00,21 Osq km
note: includes Isla de Malpelo, Roncador Cay,
Serrana Bank, and Serranilla Bank
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 7,408 km
border countries: Brazil 1,643 km, Ecuador 590 km,
Panama 225 km, Peru 2,900 km, Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1 ,760 km,
North Pacific Ocean 1 ,448 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands, high
Andes Mountains, eastern lowland plains
106
Colombia (continued)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado del Huila 5,750 m
Natural resources: petroleum, natural gas, coal,
iron ore, nickel, gold, copper, emeralds
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 48%
other: 8% (1993 est.)
Irrigated land: 5,300 sq km (1993 est.)
Natural hazards: highlands subject to volcanic
eruptions; occasional earthquakes; periodic droughts
Environment - current issues: deforestation; soil
damage from overuse of pesticides; air pollution,
especially in Bogota, from vehicle emissions
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Antarctic-Environmental
Protocol, Desertification, Law of the Sea, Marine
Dumping
Geography - note: only South American country
with coastlines on both North Pacific Ocean and
Caribbean Sea
Location: Southern Africa, group of islands in the
Mozambique Channel, about two-thirds of the way
between northern Madagascar and northern','634bdbf636f681c57098dd587550dd57fc2b73144d629f4586bbe61e7d93abe2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7e20b7678803553c36a16734ab12c5eaf8ecc0b522aa2a918cbed5e0157b7d',1999,'CG','Congo','geography',307,'Location: Western Africa, bordering the South
Atlantic Ocean, between Angola and Gabon
Geographic coordinates: 1 00 S, 15 00 E
Map references: Africa
Area:
total: 342,000 sq km
land: 341 ,500 sq km
water: 500 sq km
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km,
Central African Republic 467 km, Democratic
Republic of the Congo 2,41 0 km, Gabon 1 ,903 km
Coastline: 169 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (March to June); dry
season (June to October); constantly high
temperatures and humidity; particularly enervating
climate astride the Equator
Terrain: coastal plain, southern basin, central
plateau, northern basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead,
zinc, uranium, copper, phosphates, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 29%
forests and woodland: 62%
other: 9% (1993 est,)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: seasonal flooding
Environment - current issues: air pollution from
vehicle emissions; water pollution from the dumping of
raw sewage; tap water is not potable; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Ozone Layer Protection, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Desertification, Law of the
Sea
Geography - note: about 70% of the population
lives in Brazzaville, Pointe-Noire, or along the railroad
between them','eefc1b170fe72c55405a39725d4cb71f2ae510792d44a304ec03475c5b42a2d3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90e8aaf718ef1de7ff0e53af641b0bd60ae9c41a766584718963c7e7dcd3b608',1999,'CK','Cook Islands','geography',311,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total: 240 sq km
land: 240 sq km
water: 0 sq km
Area - comparative: 1 .3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land: 9%
115
Cook Islands (continued)
permanent crops: 1 3%
permanent pastures: NA%
forests and woodland: NA%
other: 78% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (November to March)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertication,
Law of the Sea
signed, but not ratified: Climate Change-Kyoto
Protocol
Geographic coordinates: 0 22 S, 160 03 W
Map references: Oceania
Area:
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; scant rainfall, constant wind,
burning sun
Terrain: sandy, coral island surrounded by a narrow
fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 7 m
Natural resources: guano (deposits worked until
late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
249
Jarvis Island (continued)
Geography - note: sparse bunch grass, prostrate
vines, and low-growing shrubs; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife','d68a7b1b2e55d89a3893cae8aadc59c4a7419d32b3df0aa014e260998ff25bce','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de0fb79eaf386195d2950e2d009d20eee195309700f896af4c0b765e13fc3c9e',1999,'CR','Costa Rica','geography',319,'Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area:
total: 51, 100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; dry season (December to April);
rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 46%
forests and woodland: 31%
other: 12% (1993 est.)
Irrigated land: 1,200 sq km (1993 est.)
Natural hazards: occasional earthquakes,
hurricanes along Atlantic coast; frequent flooding of
lowlands at onset of rainy season; active volcanoes
Environment - current issues: deforestation,
largely a result of the clearing of land for cattle
ranching; soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Location: Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total: 322,460 sq km
land: 31 8,000 sq km
water: 4,460 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 3, U0 km
border countries: Burkina Faso 584 km, Ghana 668
km, Guinea 610 km, Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, semiarid in far north;
three seasons - warm and dry (November to March),
hot and dry (March to May), hot and wet (June to
October)
Terrain: mostly flat to undulating plains; mountains in
northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum, diamonds,
manganese, iron ore, cobalt, bauxite, copper
Land use:
arable land: 8%
permanent crops: 4%
permanent pastures: 41 %
forests and woodland: 22%
other: 25% (1993 est.)
Irrigated land: 680 sq km (1993 est.)
Natural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment - current issues: deforestation (most
of the country''s forests - once the largest in West
Africa - have been cleared by the timber industry);
water pollution from sewage and industrial and
agricultural effluents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements','9f9ed017f35df1990fd8c429369419a6d67cca133fe89bb033ea7f2b46635029','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0806f54046ec7688d36a779a92a7cfaea5cca59c980c8152611fcc041522eb51',1999,'HR','Croatia','geography',326,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Herzegovina and
Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total: 20,256 sq km
land: 20,256 sq km
water: 0 sq km
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Area - comparative: slightly smaller than New People','99a4bdc656ef4b10c30b90608c96401ba49237bb0141e829504e8a2dfcacae20','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaae0c65b271b186f40ca892fd52c8f82e7ab8d76b4602a771815c5df6f0a47b',1999,'SI','Slovenia','geography',327,'Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,538 sq km
land: 56,41 Osq km
water: 128 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 2,197 km
border countries: Bosnia and Herzegovina 932 km,
Hungary 329 km, Serbia and Montenegro 266 km
(241 km with Serbia; 25 km with Montenegro),
Slovenia 670 km
Coastline: 5,790 km (mainland 1 ,778 km, islands
4,012 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: Mediterranean and continental; continental
climate predominant with hot summers and cold
winters; mild winters, dry summers along coast
Terrain: geographically diverse; flat plains along
Hungarian border, low mountains and highlands near
Adriatic coast, coastline, and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, natural asphalt, silica,
mica, clays, salt
Land use:
arable land: 21%
permanent crops: 2%
permanent pastures: 20%
122
Croatia (continued)
forests and woodland: 38%
other: 19% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: frequent and destructive
earthquakes
Environment - current issues: air pollution (from
metallurgical plants) and resulting acid rain is
damaging the forests; coastal pollution from industrial
and domestic waste; widespread casualties and
destruction of infrastructure in border areas affected
by civil strife
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol, Desertification
Geography - note: controls most land routes from
Western Europe to Aegean Sea and Turkish Straits','030bae2555bac9bc71847d9ba4133374245272bc8507b49f3d6bc8af7fa32ed4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfbac4874d8495151c2604d435dc000998d714f50bb68d0bfa2b3592d3e96611',1999,'CU','Cuba','geography',336,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 110,860 sq km
land: 110,860 sq km
water. 0 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay
29 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains, with rugged hills
and mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper,
manganese, salt, timber, silica, petroleum
Land use:
arable land: 24%
permanent crops: 7%
permanent pastures: 27%
forests and woodland: 24%
other: 18% (1993 est.)
Irrigated land: 9,100 sq km (1993 est.)
Natural hazards: the east coast is subject to
hurricanes from August to October (in general, the
country averages about one hurricane every other
year); droughts are common
Environment - current issues: pollution of Havana
Bay; overhunting threatens wildlife populations;
deforestation
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Marine Life Conservation
Geography - note: largest country in Caribbean','950ab14366092ffa1d56f95ceacb74a4f118845dcfe66647d782f7f87c043959','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30ec4cb87302adf6da23faedb33f7f03c32a9f6bebb5a7b5fcfd86ae972e1538',1999,'CY','Cyprus','geography',344,'Location: Middle East, island in the Mediterranean
Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (note - of which 3,355 sq km are in
the Turkish Cypriot area)
land: 9,240 sq km
wafer 10 sq km
Area - comparative: about 0.6 times the size of
Connecticut
Land boundaries: 0 km
Coastline: 648 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: temperate, Mediterranean with hot, dry
summers and cool, wet winters
Terrain: central plain with mountains to north and
south; scattered but significant plains along southern
coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1 ,952 m
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, marble, clay earth pigment
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 0%
forests and woodland: 1 3%
other: 70% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: moderate earthquake activity
Environment - current issues: water resource
problems (no natural reservoir catchments, seasonal
disparity in rainfall; sea water intrusion to island''s
'' largest aquifer; increased salination in the north);
water pollution from sewage and industrial wastes;
coastal degradation; loss of wildlife habitats from
urbanization
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants','c15ff36f0cbac25ef1192c0e5ed476506e7b832be022984090ab07ec54357607','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76f69f044e8e4f07f286dab32c4e41acf17b2b074e6700f2ae360ca6d0442ec',1999,'PL','Poland','geography',354,'Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,703 sq km
land: 78,645 sq km
water: 58 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1 ,881 km
border countries: Austria 362 km, Germany 646 km,
Poland 658 km, Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of rolling
plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very hilly
country
Elevation extremes:
lowest point: Elbe River 115 m
highest point: Snezka 1,602 m
Natural resources: hard coal, soft coal, kaolin, clay,
graphite
Land use:
arable land: 41%
permanent crops: 2%
permanent pastures: 11%
forests and woodland: 34%
other: 12% (1993 est.)
Irrigated land: 240 sq km (1993 est.)
Natural hazards: flooding
Environment - current issues: air and water
pollution in areas of northwest Bohemia and in
northern Moravia around Ostrava present health risks;
acid rain damaging forests
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategically located
astride some of oldest and most significant land routes
in Europe; Moravian Gate is a traditional military
corridor between the North European Plain and the
Danube in central Europe
Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
total: 31 2,683 sq km
land: 304,510 sq km
wafer: 8,173 sq km
Area - comparative: slightly smaller than New','4f51adcf2fcd1f1453d7f54a4b65ae030a3767a999ba66b12d1b57c17fb99498','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d55bc85cd6b5f253d36d021c5b63ec23dadb645e2610df0bf557c5023d2655a',1999,'DK','Denmark','geography',363,'Location: Northern Europe, bordering the Baltic Sea
and the North Sea, on a peninsula north of Germany
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea
and the rest of metropolitan Denmark, but excludes
the Faroe Islands and Greenland
Area - comparative: slightly less than twice the size
of Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
contiguous zone: 4 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: temperate; humid and overcast; mild, windy
winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Ejer Bavnehoj 173 m
133
Denmark (continued)
Natural resources: petroleum, natural gas, fish,
salt, limestone, stone, gravel and sand
Land use:
arable land: 60%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 1 0%
other: 25% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: flooding is a threat in some areas
of the country (e.g., parts of Jutland, along the
southern coast of the island of Lolland) that are
protected from the sea by a system of dikes
Environment - current issues: air pollution,
principally from vehicle and power plant emissions;
nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from
animal wastes and pesticides
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea
Geography - note: controls Danish Straits
(Skagerrak and Kattegat) linking Baltic and North
Seas; about one-quarter of the population lives in
Copenhagen
Location: Eastern Africa, bordering the Gulf of Aden
and the Red Sea, between Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area:
total: 22,000 sq km
land: 21,980 sq km
water: 20 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 508 km
border countries: Eritrea 1 13 km, Ethiopia 337 km,
Somalia 58 km
Coastline: 314 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by
central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 9%
forests and woodland: 0%
other: 91% (1993 est.)
Irrigated land: NA sq km
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
Environment - current issues: inadequate
supplies of potable water; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near world''s
busiest shipping lanes and close to Arabian oilfields;
terminus of rail traffic into Ethiopia; mostly wasteland
Location: Oceania, island group in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','7e7255ce56f6a784d604aa6c431e6951f6be6d1490b6ce34671d90df7e150ae7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c0ee7511a239ae54418fd45abd50ad26daf7c7ac2b7b386bcb0c423747850fb',1999,'DM','Dominica','geography',367,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, about one-half of
the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 15 25 N, 61 20 W
Map references: Central America and the
Caribbean
Area:
total: 750 sq km
land: 750 sq km
water: 0 sq km
Area - comparative: slightly more than four times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by northeast trade
winds; heavy rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
permanent pastures: 3%
forests and woodland: 67%
other: 8% (1993 est.)
Irrigated land: NA sq km
Natural hazards: flash floods are a constant threat;
destructive hurricanes can be expected during the late
summer months
Environment -current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Whaling
signed, but not ratified: none of the selected
agreements','16197b1f73de1549007b06d821fa8a4adccabc7fbd849db5288c0ded813bb3c4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d417b2c1281f5a6905ea0e44342ab7c5b470b9992fa2c07d9895f8bfead187f3',1999,'EC','Ecuador','geography',379,'Location: Western South America, bordering the
Pacific Ocean at the Equator, between Colombia and','6f81f4caf710e1a80364348cc3688b4555fbaf0835db1d4b6e3deaaf7c758e31','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b2b1c660c39075f05f92b547afd50201a659d317f92ea2e531b516af0834316',1999,'PE','Peru','geography',380,'Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area - comparative: slightly smaller than Nevada
Land boundaries:
total: 2,01 0 km
border countries: Colombia 590 km, Peru 1 ,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf: claims continental shelf between
mainland and Galapagos Islands
territorial sea: 200 nm
Climate: tropical along coast becoming cooler inland
Terrain: coastal plain (costa), inter-Andean central
highlands (sierra), and flat to rolling eastern jungle
(oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish, timber
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 1 8%
forests and woodland: 56%
other: 15% (1993 est.)
Irrigated land: 5,560 sq km (1993 est.)
Natural hazards: frequent earthquakes, landslides,
volcanic activity; periodic droughts
Environment - current issues: deforestation; soil
erosion; desertification; water pollution; pollution from
oil production wastes
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: Cotopaxi in Andes is highest
active volcano in world','ff2407947968657c14fb1dc314d8c44d6f7dc1f233767839b4a67932d5211497','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8d8808d50dadada72db954274393978e6abf5964951cbfdfac46cba1a3c5d00',1999,'EG','Egypt','geography',388,'Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza
Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total: 1 ,001 ,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area - comparative: slightly more than three times
the size of New Mexico
Land boundaries:
total: 2,689 km
border countries: Gaza Strip 1 1 km, Israel 255 km,
Libya 1 , 1 50 km, Sudan 1 ,273 km
Coastline: 2,450 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry summers with moderate
winters
Terrain: vast desert plateau interrupted by Nile
valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, manganese, limestone, gypsum, talc,
asbestos, lead, zinc
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1993 est.)
Irrigated land: 32,460 sq km (1993 est.)
Natural hazards: periodic droughts; frequent
earthquakes, flash floods, landslides, volcanic activity;
hot, driving windstorm called khamsin occurs in
spring; dust storms, sandstorms
Environment - current issues: agricultural land
being lost to urbanization and windblown sands;
increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs,
beaches, and marine habitats; other water pollution
from agricultural pesticides, raw sewage, and
industrial effluents; very limited natural fresh water
resources away from the Nile which is the only
perennial water source; rapid growth in population
overstraining natural resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: controls Sinai Peninsula, only
land bridge between Africa and remainder of Eastern
Hemisphere; controls Suez Canal, shortest sea link
between Indian Ocean and Mediterranean Sea; size,
and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics
Location: Middle America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area:
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: smallest Central American
country and only one without a coastline on Caribbean
Sea
total: 21 ,040 sq km
land: 20,720 sq km','592952d7f5241ba2d0924bf65b09999eed0854f8dd9154d2a303b93f45658133','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f181a6592141da1be792e1cb0c594b2e3073aa5e19dd5d9847f9a1588ae1160',1999,'GN','Guinea','geography',403,'Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
tofa/: 121 ,320 sq km
land: 121,320 sq km
water: 0 sq km
Area - comparative: slightly larger than
Pennsylvania
Land boundaries:
total: 1 ,630 km
border countries: Djibouti 113 km, Ethiopia 912 km,
Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea
1,151 km, islands in Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to 61 cm
of rainfall annually); semiarid in western hills and
lowlands; rainfall heaviest during June-September
except on coastal desert
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on the
east to a coastal desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-rolling plains
Elevation extremes:
lowest point: near Kulul within the Denakil depression
-75 m
highest point: Soira 3,01 8 m
Natural resources: gold, potash, zinc, copper, salt,
probably oil and natural gas (currently under
exploration), fish
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 48%
forests and woodland: 20%
other: 19% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts
Environment - current issues: deforestation;
desertification; soil erosion; overgrazing; loss of
infrastructure from civil warfare
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species
signed, but not ratified: none of the selected
agreements
Geography - note: strategic geopolitical position
along world''s busiest shipping lanes; Eritrea retained
the entire coastline of Ethiopia along the Red Sea
upon de jure independence from Ethiopia on 27 April
1993
Location: Southeastern Asia, group of islands
including the eastern half of the island of New Guinea
between the Coral Sea and the South Pacific Ocean,
east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; northwest monsoon (December to
March), southeast monsoon (May to October); slight
seasonal temperature variation
Terrain: mostly mountains with coastal lowlands and
rolling foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas,
timber, oil, fisheries
Land use:
arable land: 0.1%
permanent crops: 1%
permanent pastures: 0%
forests and woodland: 92,9%
other: 6% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism; situated along
the Pacific "Rim of Fire"; the country is subject to
frequent and sometimes severe earthquakes; mud
slides
Environment - current issues: rainforest subjectto
deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol
Geography - note: shares island of New Guinea
with Indonesia; one of world''s largest swamps along
southwest coast
Location: Southeastern Asia, group of small islands
and reefs in the South China Sea, about one-third of
the way from central Vietnam to the northern','9d58f1dbcd71078d373a9ea8d1f55f1df5e988db34db6828d20a065dfc183295','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e34ed728ff7abe400f9bfa6c5abe0b081c896a09c3100c71ab14dc22b725d5',1999,'EE','Estonia','geography',406,'Location: Eastern Europe, bordering the Baltic Sea
and Gulf of Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,21 1 sq km
wafer: 2,01 5 sq km
note: includes 1 ,520 islands in the Baltic Sea
Area - comparative: slightly smaller than New
Hampshire and Vermont combined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia 294 km
Coastline: 3,794 km
Maritime claims:
exclusive economic zone: limits fixed in coordination
with neighboring states
territorial sea: 12 nm
Climate: maritime, wet, moderate winters, cool
summers
Terrain: marshy, lowlands
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: shale oil (kukersite), peat,
153
Estonia (continued)
phosphorite, amber, Cambrian blue clay, limestone,
dolomite
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 44%
other: 20% (1996 est.)
Irrigated land: 1 1 0 sq km (1 993 est.)
Natural hazards: flooding occurs frequently in the
spring
Environment - current issues: air heavily polluted
with sulfur dioxide from oil-shale burning power plants
in northeast; contamination of soil and groundwater
with petroleum products, chemicals at former Soviet
military bases; Estonia has more than 1 ,400 natural
and manmade lakes, the smaller of which in
agricultural areas are heavily affected by organic
waste; coastal sea water is polluted in many locations
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ship Pollution, Ozone
Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol','1ebef5f46ae69c10f3bd398cea95455108032dbab0952f49e37e7b2831c12237','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914088f8703ee2f5e33c1116fb9e4ce91e225fe0c6b1940d9eca34d39afea070',1999,'ET','Ethiopia','geography',414,'Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,1 19,683 sq km
water: 7,444 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,31 1 km
border countries: Djibouti 337 km, Eritrea 912 km,
Kenya 830 km, Somalia 1 ,626 km, Sudan 1 ,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central mountain range
divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum,
copper, potash, natural gas
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 25%
other: 22% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic eruptions;
frequent droughts
Environment - current issues: deforestation;
overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection
signed, but not ratified: Environmental Modification,
Law of the Sea, Nuclear Test Ban
Geography - note: landlocked - entire coastline
along the Red Sea was lost with the de jure
independence of Eritrea on 24 May 1993
Location: Northern South America, bordering the
North Atlantic Ocean, between Suriname and
Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area:
total: 21 4,970 sq km
land: 196,850 sq km
wafer: 18,120 sq km
Area - comparative: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1 ,1 19 km, Suriname 600 km,
Venezuela 743 km
Coastline: 459 km
Maritime claims:
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid, moderated by
northeast trade winds; two rainy seasons (May to
mid-August, mid-November to mid-January)
Terrain: mostly rolling highlands; low coastal plain;
savanna in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 84%
other: 8% (1 993 est.)
Irrigated land: 1,300 sq km (1993 est.)
Natural hazards: flash floods are a constant threat
during rainy seasons
Environment - current issues: water pollution from
sewage and agricultural and industrial chemicals;
deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none of the selected
agreements','4bf016c6891b56188ad7a13dea77c50d4f172e9ba9188180ca2b2137c46bc99e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f515ba5c62011e1d87b9809fd09ce47482eb3c3de3107a072b30a1f816326b26',1999,'DJ','Djibouti','geography',422,'Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from southern
Madagascar to southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
land: 28 sq km
water: 0 sq km
Area - comparative: about 0.16 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: negligible
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: wildlife sanctuary','ad6d79b50a9a251b80672f1ae3a3ec412a17bcb1e232dd96a760917e279a9467','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c21b44647708af0aa440afca9f0855f68085068ce2af8566d01ef6d5c8388d48',1999,'FO','Faroe Islands','geography',425,'Location: Northern Europe, island group between
the Norwegian Sea and the north Atlantic Ocean,
about one-half of the way from Iceland to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total: 1 ,399 sq km
land: 1 ,399 sq km
water: 0 sq km (some lakes and streams)
Area - comparative: eight times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along
most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (1996)
Irrigated land: 0 sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: archipelago of 17 inhabited
islands and one uninhabited island, and a few
uninhabited islets; strategically located along
160
Faroe Islands (continued)
important sea lanes in northeastern Atlantic;
precipitous terrain limits habitation to small coastal
lowlands','f80a18312cdc6cc15cc161005fd44a5feaf07cb4d6cfb46bb3a11de8ad85bdce','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8d23a4a96f58ee53467986d00e88e198883431536bc5d7c627ea30f84e18fbe',1999,'NZ','New Zealand','geography',432,'Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total: 18,270 sq km
land: 1 8,270 sq km
wafer: 0 sq km
Area - comparative: slightly smaller than New
Location: Oceania, islands in the South Pacific
Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,670 sq-km
wafer: 10 sq km
note: includes Antipodes Islands, Auckland Islands,
Bounty Islands, Campbell Island, Chatham Islands,
and Kermadec Islands
Area - comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some
large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
352
New Zealand (continued)
highest point: Mount Cook 3,764 m
Natural resources: natural gas, iron ore, sand, coal,
timber, hydropower, gold, limestone
Land use:
arable land: 9%
permanent crops: 5%
permanent pastures: 50%
forests and woodland: 28%
other: 8% (1993 est.)
Irrigated land: 2,850 sq km (1993 est.)
Natural hazards: earthquakes are common, though
usually not severe; volcanic activity
Environment - current issues: deforestation; soil
erosion; native flora and fauna hard-hit by species
introduced from outside
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: about 80% of the population
lives in cities
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
land: 718 sq km
wafer: 30 sq km
Area - comparative: four times the size of
Washington, DC
Land boundaries: Okm
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by trade winds; warm
season (December to May), cool season (May to
December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have limestone
overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island 1,033
m
Natural resources: fish, fertile soil
Land use:
arable land: 24%
permanent crops: 43%
permanent pastures: 6%
forests and woodland: 1 1 %
other: 16% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo''ou
Environment - current issues: deforestation
results as more and more land is being cleared for
agriculture and settlement; some damage to coral
reefs from starfish and indiscriminate coral and shell
collectors; overhunting threatens native sea turtle
populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: archipelago of 170 islands (36
inhabited)
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
northeast of Venezuela
Geographic coordinates: 11 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 5,130 sq km
land: 5,130 sq km
water: 0 sq km
Area - comparative: slightly smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 15%
permanent crops: 9%
permanent pastures: 2%
forests and woodland: 46%
other: 28% (1993 est.)
Irrigated land: 220 sq km (1993 est.)
Natural hazards: outside usual path of hurricanes
and other tropical storms
Environment - current issues: water pollution from
agricultural chemicals, industrial wastes, and raw
sewage; oil pollution of beaches; deforestation; soil
erosion
483
Trinidad and Tobago (continued)
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 15 52 S, 54 25 E
Map references: Africa
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area - comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: sandy
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (scattered bushes)
Irrigated land: 0 sq km (1 993)
Natural hazards: NA
Environment ■ current issues: NA
Environment ■ international agreements:
party to: NA
signed, but not ratified: NA
Geography ■ note: climatologically important
location for forecasting cyclones; wildlife sanctuary
485
Tromelin Island (continued)
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes lie Uvea (Wallis Island), lie Futuna
(Futuna Island), lie Alofi, and 20 islets
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,500-3,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 5%
permanent crops: 20%
permanent pastures: NA%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: deforestation (only
small portions of the original forests remain) largely as
a result of the continued use of wood as the main fuel
source; as a consequence of cutting down the forests,
525
Wallis and Futuna (continued)
the mountainous terrain of Futuna is particularly prone
to erosion; there are no permanent settlements on
Alofi because of the lack of natural fresh water
resources
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: both island groups have fringing
reefs','e27b122e5b9814399b6ae81ede1d79a7be7b0bd86f8873f96806177e9d2932b0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b041dc7d18ff56bcab9f32c9298a986d51d114ec8e445b85bb842bf4345b066',1999,'JE','Jersey','geography',433,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation; rectilinear shelf claim added
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper,
offshore oil potential
Land use:
arable land: 10%
permanent crops: 4%
permanent pastures: 10%
forests and woodland: 65%
of/rer: 11% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: cyclonic storms can occur from
November to January
Environment - current issues: deforestation; soil
erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertication, Endangered
Species, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: includes 332 islands of which
approximately 1 10 are inhabited
Land boundaries:
total: 1 ,006 km
border countries: Egypt 255 km, Gaza Strip 51 km,
Jordan 238 km, Lebanon 79 km, Syria 76 km, West
Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
Climate: temperate; hot and dry in southern and
eastern desert areas
Terrain: Negev desert in the south; low coastal plain;
central mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1 ,208 m
Natural resources: copper, phosphates, bromide,
potash, clay, sand, sulfur, asphalt, manganese, small
amounts of natural gas and crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
other: 66% (1993 est.)
Irrigated land: 1 ,800 sq km (1 993 est.)
Natural hazards: sandstorms may occur during
spring and summer
Environment - current issues: limited arable land
and natural fresh water resources pose serious
constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers,
and pesticides
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: there are 21 6 Israeli settlements
and civilian land use sites in the West Bank, 42 in the
Israeli-occupied Golan Heights, 24 in the Gaza Strip,
and 29 in East Jerusalem (August 1998 est.)
Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
total: 116 sq km
land: 1 16 sq km
water: 0 sq km
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills
along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: agricultural land
Land use:
arable land: 66%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 34%
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: largest and southernmost of
Channel Islands; about 30% of population
concentrated in Saint Helier
SAINT
t HELIER
Goreyr
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Hawaii to the Marshall
Islands
Geographic coordinates: 16 45 N, 169 30 W
Map references: Oceania
Area:
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
Area - comparative: about 4.7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but generally dry; consistent
northeast trade winds with little seasonal temperature
variation
Terrain: mostly flat
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: NA; guano deposits worked until
depletion about 1890
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: no natural fresh
water resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: strategic location in the North
251
Johnston Atoll (continued)
Pacific Ocean; Johnston Island and Sand Island are
natural islands, which have been expanded by coral
dredging; North Island (Akau) and East Island (Hikina)
are manmade islands formed from coral dredging;
closed to the public; former US nuclear weapons test
site; site of Johnston Atoll Chemical Agent Disposal
System (JACADS); some low-growing vegetation
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
tote/: 89,21 3 sq km
land: 88,884 sq km
water: 329 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
tote/: 1 ,619 km
border countries: Iraq 181 km, Israel 238 km, Saudi
Arabia 728 km, Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland area
in west; Great Rift Valley separates East and West
Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,754 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 9%
forests and woodland: 1%
other: 85% (1993 est.)
Irrigated land: 630 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
252
Jordan (continued)
Test Ban, Ozone Layer Protection, Wetlands
signed , but not ratified: none of the selected
agreements
Land boundaries:
total: 464 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 92% (1 993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: sudden cloudbursts are common
from October to April; they bring inordinate amounts of
rain which can damage roads and houses;
sandstorms and dust storms occur throughout the
year, but are most common between March and
August
Environment - current issues: limited natural fresh
water resources; some of world''s largest and most
sophisticated desalination facilities provide much of
the water; air and water pollution; desertification
Environment - international agreements:
party to: Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered
Species, Marine Dumping
Geography - note: strategic location at head of
Persian Gulf
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds;
hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1,628 m
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 2%
forests and woodland: 39%
other: 49% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons most frequent from
November to March
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Land boundaries:
total: 1 ,334 km
border countries: Austria 330 km, Croatia 670 km,
Italy 232 km, Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and cold
winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an
alpine mountain region adjacent to Italy and Austria,
mixed mountain and valleys with numerous rivers to
the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Jr\\g\\av 2,864 m
Natural resources: lignite coal, lead, zinc, mercury,
uranium, silver
Land use:
arable land: 12%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 54%
other: 7% (1996 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: flooding and earthquakes
Environment - current issues: Sava River polluted
with domestic and industrial waste; pollution of coastal
waters with heavy metals and toxic chemicals; forest
Population: 1 ,970,570 (July 1 999 est.)
Age structure:
0-14 years: 16% (male 163,816; female 155,509)
15-64 years: 70% (male 693,382; female 687,060)
65 years and over: 14% (male 99,121 ; female
171,682) (1999 est.)
Population growth rate: -0.04% (1999 est.)
Birth rate: 8.97 births/1,000 population (1999 est.)
Death rate: 9.62 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.23 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 0.94 male(s)/female (1 999 est.)
Infant mortality rate: 5.28 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.36 years
male: 71 .71 years
female: 79.21 years (1999 est.)
Total fertility rate: 1 .23 children born/woman (1 999
est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 91%, Croat 3%, Serb 2%,
439
Slovenia (continued)
Muslim 1%, other 3%
Religions: Roman Catholic 70.8% (including 2%
Uniate), Lutheran 1%, Muslim 1%, atheist 4.3%, other
22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%,
other 3%
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa
430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emlembe 1 ,862 m
Natural resources: asbestos, coal, clay, cassiterite,
hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 62%
forests and woodland: 7%
other: 20% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: limited supplies of
potable water; wildlife populations being depleted
because of excessive hunting; overgrazing; soil
degradation; soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the
Sea
Geography - note: landlocked; almost completely
surrounded by South Africa','cb5763508fabdd676c996b4c189aa4cbb756b7692a6efc01a34510357e2b09ba','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8f19f92b87a4dccfc1eadd77c3773bdd6138b180ba221053326a492988d73a0',1999,'FI','Finland','geography',443,'Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total: 337,030 sq km
land: 305,470 sq km
water: 31 ,560 sq km
164
Finland (continued)
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 2,628 km
border countries: Norway 729 km, Sweden 586 km,
Russia 1,313 km
Coastline: 1 ,1 26 km (excludes islands and coastal
indentations)
Maritime claims:
contiguous zone: 6 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 nm
territorial sea: 1 2 nm (in the Gulf of Finland - 3 nm)
Climate: cold temperate; potentially subarctic, but
comparatively mild because of moderating influence
of the North Atlantic Current, Baltic Sea, and more
than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed
with lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1 ,328 m
Natural resources: timber, copper, zinc, iron ore,
silver
Land use:
arable land: 8%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: 76%
other: 16% (1993 est.)
Irrigated land: 640 sq km (1993 est,)
Natural hazards: NA
Environment - current issues: air pollution from
manufacturing and power plants contributing to acid
rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife
populations
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: long boundary with Russia;
Helsinki is northernmost national capital on European
continent; population concentrated on small
southwestern coastal plain','c4663f05d606905d5663c8614f2f634797f557bfec9fa2578aaca52dc0a32def','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a1d5d2394dd8f9d8a43935aa71c51f79bdc28191211f1aa5214b1c708dec36d',1999,'WF','Wallis and Futuna','geography',458,'Location: Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: 91 ,000 sq km
land: 89,150 sq km
water: 1 ,850 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to hills and
small mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de I''lnini 851 m
Natural resources: bauxite, timber, gold (widely
scattered), cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 83%
other: 17% (1993 est.)
Irrigated land: 20 sq km (1993 est, )
Natural hazards: high frequency of heavy showers
and severe thunderstorms; flooding
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed [ but not ratified: NA
Geography - note: mostly an unsettled wilderness
Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','66e41f6b7c1980c9e05e22583b076e5aba81e2d77a8c8d10627fc64dc56d4ba2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('432d73a77495fb10948ed6ac91a38a6d2781ad5ebb6d746fac4b449d843fa16a',1999,'KI','Kiribati','geography',461,'Location: Oceania, archipelago in the South Pacific
Ocean, about one-half of the way from South America
to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,1 67 sq km (1 1 8 islands and atolls)
land: 3,660 sq km
wafer 507 sq km
Area - comparative: slightly less than one-third the
size of Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt
Land use:
arable land: 1%
permanent crops: 6%
permanent pastures: 5%
forests and woodland: 31 %
of/rer: 57% { 1 993 est.)
Irrigated land: NA sq km
Natural hazards: occasional cyclonic storms in
January
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: includes five archipelagoes;
Makatea in French Polynesia is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and Nauru','9262c608b43b6a14d8623b865c8a5eab0104787c102cd47761cd841aabff735a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e55c0edc95a89f8b7cf0d671071c591e0130522eeca84f86877c45365660ba15',1999,'GA','Gabon','geography',468,'Location: Western Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the Congo
and Equatorial Guinea
Geographic coordinates: 1 00 S, 1 1 45 E
Map references: Africa
Area:
total: 267,670 sq km
land: 257,670 sq km
wafer: 10,000 sq km
Area - comparative: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km, Republic of the
Congo 1 ,903 km, Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna
in east and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1 ,575 m
Natural resources: petroleum, manganese,
uranium, gold, timber, iron ore
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 8%
forests and woodland: 77%
other: 3% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation;
poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area:
total: 1 1 ,300 sq km
land: 10,000 sq km
water: 1 ,300 sq km
Area - comparative: slightly less than twice the size
of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (June to
November); cooler, dry season (November to May)
Terrain: flood plain of the Gambia River flanked by
some low hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 28%
other: 45% (1993 est.)
Irrigated land: 150 sq km (1993 est.)
Natural hazards: rainfall has dropped by 30% in the
last 30 years
Environment ■ current issues: deforestation;
desertification; water-borne diseases prevalent
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: almost an enclave of Senegal;
smallest country on the continent of Africa
Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
wafer; 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 1 1 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current
status subject to the Israeli-Palestinian Interim
Agreement - permanent status to be determined
through further negotiation
Climate: temperate, mild winters, dry and warm to
hot summers
Terrain: flat to rolling, sand- and dune-covered
coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 1 1 %
other: 26% (1993 est.)
Irrigated land: 120 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: desertification;
salination of fresh water; sewage treatment
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: there are 24 Israeli settlements
and civilian land use sites in the Gaza Strip (August
1998 est.)','98a5040441d6e5956c1b95d071d9fa5f38f9f3f4daf8c0a1bf1b74411e07c048','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35448fa771fe80e3dd5962b536687a19009e1e79c828b8d37020e59423762100',1999,'GH','Ghana','geography',479,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 238,540 sq km
land: 230,020 sq km
water: 8,520 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire
668 km, Togo 877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; warm and comparatively dry along
southeast coast; hot and humid in southwest; hot and
dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rubber
Land use:
arable land: 12%
permanent crops: 7%
permanent pastures: 22%
forests and woodland: 35%
other: 24% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: dry, dusty, harmattan winds occur
from January to March; droughts
Environment - current issues: recent drought in
186
Ghana (continued)
north severely affecting agricultural activities;
deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
Environment - international agreements:
patty to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: Marine Life Conservation
Geography - note: Lake Volta is the world''s largest
artificial lake; northeasterly harmattan wind (January
to March)','c6891192015aab2731b959801d707850a6359c6ab41b3c87fac7bc78bec26454','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ef3bdc9f7457c91f0fcab26722a5eb8cfcee6d5bbf4f7ce3ba424b7b4af2496',1999,'GI','Gibraltar','geography',486,'Location: Southwestern Europe, bordering the Strait
of Gibraltar, which links the Mediterranean Sea and
the North Atlantic Ocean, on the southern coast of','33c1cc0af5273f567a1547f931f3b180aa2e3f71430e8868679985dd2a449049','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d8e095d71c35e2a1e7ca8a141a3947490928f73fc07a79465c6a6d2b60acaac',1999,'ES','Spain','geography',487,'Geographic coordinates: 36 1 1 N, 5 22 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries:
total: 1 .2 km
border countries: Spain 1.2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
Climate: Mediterranean with mild winters and warm
summers
Terrain: a narrow coastal lowland borders the Rock
of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment ■ current issues: limited natural
freshwater resources; large concrete or natural rock
water catchments collect rain water
Environment - international agreements:
party to: NA
188
Gibraltar (continued)
signed, but not ratified: NA
Geography - note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea
Location: Southern Africa, group of islands in the
Indian Ocean, northwest of Madagascar
Geographic coordinates: 1 1 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
wafer: 0 sq km
note: includes lie Glorieuse, lie du Lys, Verte Rocks,
Wreck Rock, and South Rock
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment - current issues: NA
conventional shod form: Glorioso Islands
local long form: none
local shod form: lies Glorieuses
Data code: GO
Dependency status: possession of France;
administered by a high commissioner of the Republic,
resident in Reunion
Legal system: NA
Diplomatic representation in the US: none
(possession of France)
Diplomatic representation from the US: none
(possession of France)
Flag description: the flag of France is used
Location: Southwestern Europe, bordering the Bay
of Biscay, Mediterranean Sea, North Atlantic Ocean,
and Pyrenees Mountains, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total: 504,750 sq km
land: 499,400 sq km
water: 5,350 sq km
note: includes Balearic Islands, Canary Islands, and
five places of sovereignty (plazas de soberania) on
and off the coast of Morocco - Ceuta, Melilla, Islas
Chafarinas, Penon de Alhucemas, and Penon de
Velez de la Gomera
Area - comparative: slightly more than twice the
size of Oregon
Land boundaries:
total: 1,919.1 km
border countries: Andorra 65 km, France 623 km,
Gibraltar 1 .2 km, Portugal 1,214 km, Morocco (Ceuta)
6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
exclusive economic zone: 200 nm (applies only to the
Atlantic Ocean)
territorial sea: 12 nm
Climate: temperate; clear, hot summers in interior,
more moderate and cloudy along coast; cloudy, cold
winters in interior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary
Islands 3,71 8 m
Natural resources: coal, lignite, iron ore, uranium,
mercury, pyrites, fluorspar, gypsum, zinc, lead,
tungsten, copper, kaolin, potash, hydropower
Land use:
arable land: 30%
permanent crops: 9%
permanent pastures: 21 %
forests and woodland: 32%
other: 8% (1993 est.)
Irrigated land: 34,530 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: pollution of the
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Desertification
Geography - note: strategic location along
approaches to Strait of Gibraltar','c62fabc9b95a295616c55038728d408d78c6028be63425129f7eebb5be9fd589','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c33fe4ae20cc88156cc9a6506c466f85c61316fd23777c17029b5c7d3677443',1999,'GL','Greenland','geography',495,'Location: Northern North America, island between
the Arctic Ocean and the North Atlantic Ocean,
northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
total: 2, 175,600 sq km
land: 2,1 75,600 sq km (341,600 sq km ice-free,
1 ,834,000 sq km ice-covered) (est.)
Area - comparative: slightly more than three times
the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: arctic to subarctic; cool summers, cold
winters
Terrain: flat to gradually sloping icecap covers all but
a narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
193
Natural resources: zinc, lead, iron ore, coal,
molybdenum, gold, platinum, uranium, fish, seals,
whales
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 0%
other: 99% (1993 est.)
Irrigated land: NA sq km
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment - current issues: protection of the
arctic environment; preservation of their traditional
way of life, including whaling; note - Greenland
participates actively in Inuit Circumpolar Conference
(ICC)
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: dominates North Atlantic Ocean
between North America and Europe; sparse
population confined to small settlements along coast','dfeec6fe6f36440fc1c5ce03a8a62c23cf8565aae332c6a8a0243cb5734c5d62','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22ba600d759f89e2daf34d45538e481590a2da4a008bfc3ba0ae1efd230af28',1999,'GD','Grenada','geography',501,'Location: Caribbean, island between the Caribbean
Sea and Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the
Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater
harbors
Land use:
arable land: 15%
permanent crops: 1 8%
permanent pastures: 3%
forests and woodland: 9%
other: 55% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment • current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer
Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
Location: Caribbean, islands in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,234 m
Natural resources: NEGL
Land use:
arable land: 10%
permanent crops: 1 8%
permanent pastures: 5%
forests and woodland: 36%
other: 31% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes; Soufriere volcano on
the island of Saint Vincent is a constant threat
Environment - current issues: pollution of coastal
waters and shorelines from discharges by pleasure
yachts and other effluents; in some areas, pollution is
severe enough to make swimming prohibitive
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada','ffdbd3401985dd2303d521e021c60b85fbc2746cd333ecdfa8a213fb765b811e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d9b3a9115e17fc61200bf0eb7d45562d4e66777d9c601884f0e3e19fff457ef',1999,'GU','Guam','geography',510,'Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
total: 541 .3 sq km
land: 541 .3 sq km
wafer: 0 sq km
Area - comparative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; generally warm and humid,
moderated by northeast trade winds; dry season from
January to June, rainy season from July to December;
little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source of
most fresh water), with steep coastal cliffs and narrow
coastal plains in north, low-rising hills in center,
mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped),
tourism (especially from Japan)
Land use:
arable land: 11%
permanent crops: 11%
permanent pastures: 15%
forests and woodland: 1 8%
other: 45% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: frequent squalls during rainy
season; relatively rare, but potentially very destructive
typhoons (especially in August)
Environment - current issues: extirpation of native
bird population by the rapid proliferation of the brown
tree snake, an exotic species
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: largest and southernmost island
in the Mariana Islands archipelago; strategic location
in western North Pacific Ocean
Location: Middle America, bordering the Caribbean
Sea, between Honduras and Belize and bordering the
North Pacific Ocean, between El Salvador and Mexico
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the
Caribbean
Area:
total: 108, 890 sq km
land: 108,'' 430 sq km
water: 460 sq km
Area - comparative: slightly smaller than
Tennessee
Land boundaries:
total: 1 ,687 km
border countries: Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid in lowlands; cooler in
highlands
Terrain: mostly mountains with narrow coastal plains
and rolling limestone plateau (Peten)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel, rare woods,
fish, chicle
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 24%
forests and woodland: 54%
other: 5% (1993 est.)
Irrigated land: 1 ,250 sq km (1993 est.)
Natural hazards: numerous volcanoes in
200
Guatemala (continued)
mountains, with occasional violent earthquakes;
Caribbean coast subject to hurricanes and other
tropical storms
Environment - current issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertication, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol
Geography - note: no natural harbors on west coast','8bd71241370b5499ae7b7c3351d734525d44578e4396dfe29f36e41ea0b1ffa1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f301356cd44261530dabf95ce00414b544a13d47300ef84dca9d75ccdd57f2b',1999,'GG','Guernsey','geography',524,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra
Leone
Geographic coordinates: 1 1 00 N, 10 00 W
Map references: Africa
Area:
total: 245,860 sq km
land: 245,860 sq km
water: 0 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Guinea-Bissau 386 km, Cote
d''Ivoire 61 0 km, Liberia 563 km, Mali 858 km, Senegal
330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally hot and humid; monsoonal-type
rainy season (June to November) with southwesterly
winds; dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 59%
other: 17% (1993 est.)
Irrigated land: 930 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment - current issues: deforestation;
inadequate supplies of potable water; desertification;
soil contamination and erosion; overfishing,
overpopulation in forest region
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements','161e2b66d7bff02b09f31975c646c3cac313699ea1913e1d7d00c8ba9819e545','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caf035fc623b2a8ab2f22170789df72eb526bce07d8e0299bf49d9e622bfa50a',1999,'HT','Haiti','geography',536,'Location: Caribbean, western one-third of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
wafer: 190 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 275 km
border countries: Dominican Republic 275 km
Coastline: 1,771km
Maritime claims:
contiguous zone: 24 nm
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; semiarid where mountains in east
cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: none
Land use:
arable land: 20%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 5%
other: 44% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding and earthquakes;
periodic droughts
Environment - current issues: extensive
deforestation (much of the remaining forested land is
being cleared for agriculture and used as fuel); soil
erosion; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation
signed, but not ratified: Hazardous Wastes, Nuclear
Test Ban
Geography - note: shares island of Hispaniola with
Dominican Republic (western one-third is Haiti,
eastern two-thirds is the Dominican Republic)
Location: Southern Africa, islands in the Indian
Ocean, about two-thirds of the way from Madagascar
to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
total: 412 sq km
land: 41 2 sq km
water: 0 sq km
Area - comparative: slightly more than 2 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: antarctic
Terrain: Heard Island - bleak and mountainous, with
a quiescent volcano; McDonald Islands - small and
rocky
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1 993)
Natural hazards: Heard Island is dominated by a
dormant volcano called Big Ben
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: primarily used for research
stations
212','de9464c9a49124dc060da3bec834de64c9cf8ebc88d69d81f7f5fe72f39849a0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ff08fb637c9eb2461e9a1ae7c73ecf2c899d5758ccbe6d23320f4f2a93df5b',1999,'NI','Nicaragua','geography',547,'Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1 ,092 sq km
land: 1 ,042 sq km
water: 50 sq km
Area - comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
Climate: tropical monsoon; cool and humid in winter,
hot and rainy from spring through summer, warm and
sunny in fall
Terrain: hilly to mountainous with steep slopes;
lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: la\\ Mo Shan 958 m
Natural resources: outstanding deepwater harbor,
feldspar
Land use:
arable land: 6%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 20%
other: 72% (1997 est.)
Irrigated land: 20 sq km (1997 est.)
Natural hazards: occasional typhoons
Environment - current issues: air and water
pollution from rapid urbanization
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: more than 200 islands
Location: Oceania, island in the North Pacific
Ocean, about one-half of the way from Hawaii to','28ac420ff136a2f38a5a9e7ad9af802026234117ae49e5820b52c1bea96132d1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc28b746b5d4572474516df7bf63458498b398c7700c2372c6717933ece617de',1999,'HU','Hungary','geography',555,'Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 2,009 km
border countries: Austria 366 km, Croatia 329 km,
Romania 443 km, Serbia and Montenegro 1 51 km (all
with Serbia), Slovakia 515 km, Slovenia 102 km,
Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters;
warm summers
Terrain: mostly flat to rolling plains; hills and low
mountains on the Slovakian border
Elevation extremes:
lowest point: Tisza River 78 m
arable land: 51%
permanent crops: 2%
permanent pastures: 1 3%
forests and woodland: 19%
other: 15% (1993 est.)
Irrigated land: 2,060 sq km (1993 est.)
Environment - current issues: the approximation
of Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution with
environmental requirements for EU accession will
require large investments, estimated by the
Government of Hungary at $4 billion over six years;
the 1997 budget allocated $9.7 million for this
purpose; the 1998 budget allocated S1 1 .3 million; the
Central Environmental Fund, which collects monies
from product charges, environmental fines, and
mining taxes, provided approximately $76.2 million in
1 997 and is expected to provide $1 09.5 million in 1 998
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol, Law of the Sea
Geography - note: landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine and
Mediterranean basin','ba0e68ba1f418dd94f1841d4c3bcc37c9ca2fa98af01ffeae26e04e2740bdadd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d13208166f45f040d1dacff12573797a43c475deca4b844039f58d20264a6e2f',1999,'IS','Iceland','geography',565,'Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,988 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by North Atlantic
Current; mild, windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain
peaks, icefields; coast deeply indented by bays and
fiords
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,119 m
Natural resources: fish, hydropower, geothermal
power, diatomite
222
Iceland (continued)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 1 %
other: 76% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: earthquakes and volcanic activity
Environment - current issues: water pollution from
fertilizer runoff; inadequate wastewater treatment
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Environmental Modification,
Marine Life Conservation
Geography - note: strategic location between
Greenland and Europe; westernmost European
country; more land covered by glaciers than in all of
continental Europe
Location: Southern Asia, bordering the Arabian Sea
and the Bay of Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total: 3,287,590 sq km
land: 2,973,190 sq km
wafer; 31 4,400 sq km
Area - comparative: slightly more than one-third the
size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan 605
km, Burma 1,463 km, China 3,380 km, Nepal 1,690
km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical monsoon in south to
temperate in north
Terrain: upland plain (Deccan Plateau) in south, flat
to rolling plain along the Ganges, deserts in west,
Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves in
the world), iron ore, manganese, mica, bauxite,
titanium ore, chromite, natural gas, diamonds,
petroleum, limestone
Land use:
arable land: 56%
permanent crops: 1%
permanent pastures: 4%
forests and woodland: 23%
offer: 16% (1993 est.)
Irrigated land: 480,000 sq km (1993 est.)
Natural hazards: droughts, flash floods, severe
thunderstorms common; earthquakes
Environment - current issues: deforestation; soil
erosion; overgrazing; desertification; air pollution from
industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural
pesticides; tap water is not potable throughout the
country; huge and rapidly growing population is
overstraining natural resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed , but not ratified: none of the selected
agreements
Geography - note: dominates South Asian
subcontinent; near important Indian Ocean trade
routes','95da471304b35d2e911e85c7bfcff083ec66d03b00074233a206150b65e9568b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('759ba060ffd66f44de8821b3a60fb4f9e5f4951082d657e4e914ef9ba5579963',1999,'IL','Israel','geography',577,'Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area - comparative: slightly smaller than New','067af7be49194c421341f892c0a622582ee8969d2538391daaba8afc786d62d4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bf55ac3e97bf600d4956cbad576ceb0f37a0333df25c810d9674485061cddb7',1999,'TN','Tunisia','geography',579,'Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total: 301 ,230 sq km
land: 294,020 sq km
wafer 7,210 sq km
note: includes Sardinia and Sicily
Area - comparative: slightly larger than Arizona
Land boundaries:
total: 1 ,932.2 km
border countries: Austria 430 km, France 488 km,
Holy See (Vatican City) 3.2 km, San Marino 39 km,
Slovenia 232 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: predominantly Mediterranean; Alpine in far
north; hot, dry in south
Terrain: mostly rugged and mountainous; some
plains, coastal lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) 4,807 m
Natural resources: mercury, potash, marble, sulfur,
dwindling natural gas and crude oil reserves, fish, coal
Land use:
arable land: 31%
permanent crops: 10%
permanent pastures: 15%
forests and woodland: 23%
other: 21% (1993 est.)
Irrigated land: 27,100 sq km (1993 est.)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic
eruptions, flooding; land subsidence in Venice
Environment - current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal
and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes;
inadequate industrial waste treatment and disposal
facilities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location dominating
central Mediterranean as well as southern sea and air
approaches to Western Europe','83e85958c89219446ff6eca1036ebb03755648eca6a0ce2ee1dea9e232da12fe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9daf26a6605a1c7bc45adf8dd330051a9fc9c8e0e291728adbd857218f016d36',1999,'JM','Jamaica','geography',586,'Location: Caribbean, island in the Caribbean Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area:
total: 10,990 sq km
land: 10, 830 sq km
water: 160 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: Okm
Coastline: 1,022 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 14%
permanent crops: 6%
permanent pastures: 24%
forests and woodland: 17%
other: 39% (1993 est.)
Irrigated land: 350 sq km (1993 est.)
Natural hazards: hurricanes (especially July to
November)
Environment - current issues: deforestation;
coastal waters polluted by industrial waste, sewage,
and oil spills; damage to coral reefs; air pollution in
Kingston results from vehicle emissions
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location between
Cayman Trench and Jamaica Channel, the main sea
lanes for Panama Canal','112e30b3e96899bf0da1b9b9e98ac1b247e2bf19aa0480e3bb1868527be95644','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91fa59fff1df1d60d26c8842d33548ddfbc3afa816f7c91baf514aa335a2f958',1999,'NO','Norway','geography',592,'Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of the
Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu
Islands (Nansei-shoto), and Volcano Islands
(Kazan-retto)
Area - comparative: slightly smaller than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm; between 3 nm and 1 2 nm in the
international straits - La Perouse or Soya, Tsugaru,
Osumi, and Eastern and Western Channels of the
Korea or Tsushima Strait
Climate: varies from tropical in south to cool
temperate in north
Terrain: mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources,
fish
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 67%
other: 19% (1993 est.)
Irrigated land: 27,820 sq km (1993 est.)
Natural hazards: many dormant and some active
volcanoes; about 1 ,500 seismic occurrences (mostly
tremors) every year; tsunamis
Environment - current issues: air pollution from
power plant emissions results in acid rain; acidification
of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest
consumers of fish and tropical timber, contributing to
the depletion of these resources in Asia and
elsewhere
Environment ■ international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertication,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropica! Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location in northeast
Asia
Location: Oceania, island in the South Pacific
Ocean, about one-half of the way from Hawaii to the
Location: Northern Europe, bordering the North Sea
and the North Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
wafer: 16,360 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 2,515 km
border countries: Finland 729 km, Sweden 1 ,61 9 km,
Russia 167 km
Coastline: 21 ,925 km (includes mainland 3,41 9 km,
large islands 2,413 km, long fjords, numerous small
islands, and minor indentations 16,093 km)
Maritime claims:
contiguous zone: 10 nm
continental shell: 200 nm
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: temperate along coast, modified by North
Atlantic Current; colder interior; rainy year-round on
west coast
Terrain: glaciated; mostly high plateaus and rugged
mountains broken by fertile valleys; small, scattered
plains; coastline deeply indented by fjords; arctic
tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Glittertinden 2,472 m
Natural resources: petroleum, copper, natural gas,
pyrites, nickel, iron ore, zinc, lead, fish, timber,
hydropower
Land use:
arable land: 3%
permanent crops: NA%
permanent pastures: 0%
forests and woodland: 27%
other 70% (1993 est.)
Irrigated land: 970 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution; acid
rain damaging forests and adversely affecting lakes,
threatening fish stocks; air pollution from vehicle
emissions
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: about two-thirds mountains;
some 50,000 islands off its much indented coastline;
strategic location adjacent to sea lanes and air routes
in North Atlantic; one of most rugged and longest
coastlines in world; Norway is the only NATO member
having a land boundary with Russia
Location: Middle East, bordering the Arabian Sea,
Gulf of Oman, and Persian Gulf, between Yemen and
UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total: 21 2,460 sq km
land: 21 2,460 sq km
water: 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 1 ,374 km
border countries: Saudi Arabia 676 km, UAE 410 km,
Yemen 288 km
Coastline: 2,092 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: dry desert; hot, humid along coast; hot, dry
interior; strong southwest summer monsoon (May to
September) in far south
Terrain: vast central desert plain, rugged mountains
in north and south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: NA%
other: 95% (1993 est.)
Irrigated land: 580 sq km (1993 est.)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic
droughts
short-sea passenger 22, vehicle carrier 36
note: the government has created an internal register,
the Norwegian International Ship register (NIS), as a
subset of the Norwegian register; ships on the NIS
enjoy many benefits of flags of convenience and do
not have to be crewed by Norwegians (1998 est.)
Airports: 103 (1998 est.)
Airports - with paved runways:
total: 66
over 3,047 m: 1
2,438 to 3,047 m: 11
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 29 (1998 est.)
Airports - with unpaved runways:
total: 37
914 to 1,523 m: 5
under 914 m: 32 (1998 est.)
Heliports: 1 (1998 est.)
Location: body of water between Antarctica, Asia,
Australia, and the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: World
Area:
total: 165.384 million sq km
note: includes Bali Sea, Bellingshausen Sea, Bering
Sea, Bering Strait, Coral Sea, East China Sea, Flores
Sea, Gulf of Alaska, Gulf of Tonkin, Java Sea,
Philippine Sea, Ross Sea, Savu Sea, Sea of Japan,
Sea of Okhotsk, South China Sea, Tasman Sea,
Timor Sea, and other tributary water bodies
Area - comparative: about 1 8 times the size of the
US; the largest ocean (followed by the Atlantic Ocean,
the Indian Ocean, and the Arctic Ocean); covers about
one-third of the global surface; larger than the total
land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems and
resultant wind patterns exhibit remarkable uniformity
in the south and east; trade winds and westerly winds
are well-developed patterns, modified by seasonal
fluctuations; tropical cyclones (hurricanes) may form
south of Mexico from June to October and affect
Mexico and Central America; continental influences
cause climatic uniformity to be much less pronounced
in the eastern and western regions at the same
latitude in the North Pacific Ocean; the western Pacific
is monsoonal - a rainy season occurs during the
summer months, when moisture-laden winds blow
from the ocean over the land, and a dry season during
the winter months, when dry winds blow from the
Asian landmass back to the ocean; tropical cyclones
(typhoons) may strike southeast and east Asia from
May to December
Terrain: surface currents in the northern Pacific are
dominated by a clockwise, warm-water gyre (broad
circular system of currents) and in the southern Pacific
by a counterclockwise, cool-water gyre; in the
370
Pacific Ocean (continued)
northern Pacific, sea ice forms in the Bering Sea and
Sea of Okhotsk in winter; in the southern Pacific, sea
ice from Antarctica reaches its northernmost extent in
October; the ocean floor in the eastern Pacific is
dominated by the East Pacific Rise, while the western
Pacific is dissected by deep trenches, including the
Mariana Trench, which is the world''s deepest
Elevation extremes:
lowest point: Challenger Deep in the Mariana Trench
-10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic
nodules, sand and gravel aggregates, placer
deposits, fish
Natural hazards: surrounded by a zone of violent
volcanic and earthquake activity sometimes referred
to as the "Pacific Ring of Fire"; subject to tropical
cyclones (typhoons) in southeast and east Asia from
May to December (most frequent from July to
October); tropical cyclones (hurricanes) may form
south of Mexico and strike Central America and
Mexico from June to October (most common in
August and September); southern shipping lanes
subject to icebergs from Antarctica; cyclical El Nino
phenomenon occurs off the coast of Peru, when the
trade winds slacken and the warm Equatorial
countercurrent moves south, killing the plankton that
is the primary food source for anchovies;
consequently, the anchovies move to better feeding
grounds, causing resident marine birds to starve by
the thousands because of the loss of their food
source; ships subject to superstructure icing in
extreme north from October to May and in extreme
south from May to October; persistent fog in the
northern Pacific can be a maritime hazard from June
to December
Environment - current issues: endangered marine
species include the dugong, sea lion, sea otter, seals,
turtles, and whales; oil pollution in Philippine Sea and
South China Sea
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: the major chokepoints are the
Bering Strait, Panama Canal, Luzon Strait, and the
Singapore Strait; the Equator divides the Pacific
Ocean into the North Pacific Ocean and the South
Pacific Ocean; dotted with low coral islands and
rugged volcanic islands in the southwestern Pacific
Ocean
Location: Southern Asia, bordering the Arabian Sea,
between India on the east and Iran and Afghanistan
on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area - comparative: slightly less than twice the size
of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km, China 523
km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in north
and northwest; Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt, Godwin-Austen) 8,61 1 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coal, iron
ore, copper, salt, limestone
Land use:
arable land: 27%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 5%
other: 61% (1993 est.)
Irrigated land: 1 71 , 1 00 sq km (1 993 est.)
371
Pakistan (continued)
Natural hazards: frequent earthquakes, occasionally
severe especially in north and west; flooding along the
Indus after heavy rains (July and August)
Environment - current issues: water pollution from
raw sewage, industrial wastes, and agricultural runoff;
limited natural fresh water resources; a majority of the
population does not have access to potable water;
deforestation; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: controls Khyber Pass and Bolan
Pass, traditional invasion routes between Central Asia
and the Indian Subcontinent
Location: Oceania, group of islands in the North
Pacific Ocean, southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total: 458 sq km
land: 458 sq km
water: 0 sq km
Area - comparative: slightly more than 2.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 nm
extended fishing zone: 200 nm
territorial sea: 3 nm
Climate: wet season May to November; hot and
humid
Terrain: varying geologically from the high,
mountainous main island of Babelthuap to low, coral
islands usually fringed by large barrier reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests, minerals (especially
gold), marine products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment - current issues: inadequate facilities
for disposal of solid waste; threats to the marine
ecosystem from sand and coral dredging, illegal
fishing practices, and overfishing
Environment - international agreements:
party to: Biodiversity, Law of the Sea
signed, but not ratified: none of the selected
agreements
Geography - note: includes World War II
battleground of Beliliou (Peleliu) and world-famous
rock islands; archipelago of six island groups totaling
over 200 islands in the Caroline chain','6b17c84b4766c30e468ea7674bedfb6e976beb983b43684b02ed3f760e54259f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7156391e082a86c098ba96044c41c921fbfd2646d6d0775829d1a4e1f02f4aab',1999,'JO','Jordan','geography',604,'Location: Southern Africa, island in the Mozambique
Channel, about one-third of the way between
Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
Area - comparative: about seven times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth the of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other
fertilizers
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: 10%
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed , but not ratified: NA
Geography - note: wildlife sanctuary','324494a430867d06db600570e9994ef7c7444cd8676aa852f90aa243d8e9610c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa14380e2b2f02d899287b5d928b74e10300427d188d56b8c3511d85a7796a8a',1999,'KZ','Kazakhstan','geography',606,'Location: Central Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references: Commonwealth of Independent
States
Area:
total: 2,717,300 sq km
land: 2,669,800 sq km
water: 47,500 sq km
Area - comparative: slightly less than four times the
size of Texas
Land boundaries:
total: 12,012 km
border countries: China 1 ,533 km, Kyrgyzstan 1 ,051
km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked)
note: Kazakhstan borders the Aral Sea, now split into
two bodies of water (1 ,070 km), and the Caspian Sea
(1,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers,
arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western Siberia to
oases and desert in Central Asia
Elevation extremes:
lowest point: Vpadina Kaundy -132 m
6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use:
arable land: 12%
permanent crops: 11%
permanent pastures: 57%
forests and woodland: 4%
other: 16% (1996 est.)
Irrigated land: 22,000 sq km (1996 est.)
Natural hazards: earthquakes in the south,
mudslides around Almaty
Environment - current issues: radioactive or toxic
chemical sites associated with its former defense
industries and test ranges are found throughout the
country and pose health risks for humans and
animals; industrial pollution is severe in some cities;
because the two main rivers which flowed into the Aral
Sea have been diverted for irrigation, it is drying up
and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are
then picked up by the wind and blown into noxious
dust storms; pollution in the Caspian Sea; soil
pollution from overuse of agricultural chemicals and
salination from faulty irrigation practices
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
wafer; 13, 400 sq km
Area - comparative: slightly more than twice the
size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to arid in
interior
Terrain: low plains rise to central highlands bisected
by Great Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: gold, limestone, soda ash, salt
barites, rubies, fluorspar, garnets, wildlife
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 37%
forests and woodland: 30%
other: 25% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring drought in northern and
eastern regions; flooding during rainy seasons
Environment - current issues: water pollution from
258
Kenya (continued)
urban and industrial wastes; degradation of water
quality from increased use of pesticides and fertilizers;
deforestation; soil erosion; desertification; poaching
Environment - international agreements:
party to; Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the Kenyan Highlands comprise
one of the most successful agricultural production
regions in Africa; glaciers on Mt. Kenya; unique
physiography supports abundant and varied wildlife of
scientific and economic value
Location: Oceania, reef in the North Pacific Ocean,
about one-half of the way from Hawaii to American','15c153c854e5ea43930710d5079d93a29aa535a4e9e8f1e7e31d473a16900e78','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5fb4e453590b16fcf6de43e68b1e7375f7bcbdde35dee6d39427eb409dad4a1',1999,'WS','Samoa','geography',613,'Geographic coordinates: 6 24 N, 162 24 W
Map references: Oceania
Area:
total: 1 sq km
land: 1 sq km
wafer: 0 sq km
Area - comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderated by prevailing winds
Terrain: low and nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1996)
Natural hazards: wet or awash most of the time,
maximum elevation of about 1 meter makes Kingman
Reef a maritime hazard
Environment - current issues: none
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: barren coral atoll with deep
interior lagoon; closed to the public
Location: Oceania, group of islands in the Pacific
Ocean, straddling the equator, about one-half of the
way from Hawaii to Australia; note - on 1 January
1995, Kiribati unilaterally moved the International
Date Line from the middle of the country to include its
easternmost islands and make it the same day
throughout the country
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total: 7 M sq km
land: 71 7 sq km
water: 0 sq km
note: includes three island groups - Gilbert Islands,
Line Islands, Phoenix Islands
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine, hot and humid, moderated
by trade winds
Terrain: mostly low-lying coral atolls surrounded by
extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production
discontinued in 1979)
Land use:
arable land: NA%
permanent crops: 51 %
permanent pastures: NA%
forests and woodland: 3%
other: 46% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons can occur any time, but
Kiribati (continued)
usually November to March; occasional tornadoes
Environment - current issues: heavy pollution in
lagoon of south Tarawa atoll due to heavy migration
mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertication,
Endangered Species, Marine Dumping, Ozone Layer
Protection
signed , but not ratified: none of the selected
agreements
Geography - note: 20 of the 33 islands are
inhabited; Banaba (Ocean Island) in Kiribati is one of
the three great phosphate rock islands in the Pacific
Ocean - the others are Makatea in French Polynesia
and Nauru
Location: Eastern Asia, northern half of the Korean
Peninsula bordering the Korea Bay and the Sea of
Japan, between China and South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area:
total: 120,540 sq km
land: 1 20,41 Osq km
water: 130 sq km
Area - comparative: slightly smaller than
Mississippi
Land boundaries:
total: 1 ,673 km
border countries: China 1,416 km, South Korea 238
km, Russia 19 km
Coastline: 2,495 km
Korea, North (continued)
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
note: military boundary line 50 nm in the Sea of Japan
and the exclusive economic zone limit in the Yellow
Sea where all foreign vessels and aircraft without
permission are banned
Climate: temperate with rainfall concentrated in
summer
Terrain: mostly hills and mountains separated by
deep, narrow valleys; coastal plains wide in west,
discontinuous in east
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten, zinc,
graphite, magnesite, iron ore, copper, gold, pyrites,
salt, fluorspar, hydropower
Land use:
arable land: 14%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 61 %
other 23% (1993 est.)
Irrigated land: 14,600 sq km (1993 est.)
Natural hazards: late spring droughts often followed
by severe flooding; occasional typhoons during the
early fall
Environment - current issues: localized air
pollution attributable to inadequate industrial controls;
water pollution; inadequate supplies of potable water
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea
Geography - note: strategic location bordering
China, South Korea, and Russia; mountainous interior
is isolated, nearly inaccessible, and sparsely
populated
Location: Eastern Asia, southern half of the Korean
Peninsula bordering the Sea of Japan and the Yellow
Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area - comparative: slightly larger than Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm; between 3 nm and 12 nm in the
Korea Strait
Climate: temperate, with rainfall heavier in summer
than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower
Land use:
arable land: 19%
permanent crops: 2%
permanent pastures: 1%
forests and woodland: 65%
other 13% (1993 est.)
Irrigated land: 1 3,350 sq km (1 993 est.)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity common in
southwest
Environment - current issues: air pollution in large
cities; water pollution from the discharge of sewage
and industrial effluents; driftnet fishing
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
Location: Southern Europe, an enclave in central','57d90bbdee2b4a336423fa670aefdb9d697127272cf454d437c9b363d3c78986','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0b67937e01ca5f2e9f76ea43e87b145833cc40f87c8a45a9e966766f0c5e4d3',1999,'KW','Kuwait','geography',622,'Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area - comparative: slightly smaller than New','1d33f8e537ae7e8b208d44343102de6c6f8aa9429dbd960b8764d739dc820ba9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('060cd2c9e278a2b0f768877c5b75dc48b3c9ad426caaf7534db921676bd5115b',1999,'KG','Kyrgyzstan','geography',624,'Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent
States
Area:
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakhstan 1 ,051
km, Tajikistan 870 km, Uzbekistan 1 ,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan;
subtropical in southwest (Fergana Valley); temperate
in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys
and basins encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydroelectric
potential; significant deposits of gold and rare earth
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other: 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural
growth walnut forest
Irrigated land: 9,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution;
many people get their water directly from
contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil
salinity from faulty irrigation practices
Environment - international agreements:
party to: Biodiversity, Desertification, Hazardous
Wastes
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','4ccc907c25ab03789e4c10e388843808056565bfd7f8a5ad0676f6c2442e3233','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d868113676131b7c8b4fb0d874ead2e46616e9dddfc9352946405fdf5703d60a',1999,'LV','Latvia','geography',632,'Location: Eastern Europe, bordering the Baltic Sea,
between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,589 sq km
land: 64,589 sq km
water: 0 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 1,150 km
border countries: Belarus 141 km, Estonia 339 km,
Lithuania 453 km, Russia 217 km
Coastline: 531 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkains 312 m
Natural resources: minimal; amber, peat,
limestone, dolomite
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 46%
other: 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: air and water
pollution because of a lack of waste conversion
equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with
chemicals and petroleum products at military bases
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol','3eaff4f23ec41ff75d14d32efc1c0824b6450a1565b4c72c2512b437b9e32914','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('265e1f66b793966850c9724d86d13c83a6ead44238cab0bc350c73dd65088603',1999,'LB','Lebanon','geography',641,'Location: Middle East, bordering the Mediterranean
Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
277
Lebanon (continued)
Area:
total: 10,400 sq km
land: 10, 230 sq km
water: 170 sq km
Area - comparative: about 0.7 times the size of
Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters
with hot, dry summers; Lebanon mountains
experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley)
separates Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt,
water-surplus state in a water-deficit region
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 1 %
forests and woodland: 8%
other: 61% (1993 est.)
irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation; soil
erosion; desertification; air pollution in Beirut from
vehicular traffic and the burning of industrial wastes;
pollution of coastal waters from raw sewage and oil
spills
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation
Geography - note: Nahr al Litani only major river in
Near East not crossing an international boundary;
rugged terrain historically helped isolate, protect, and
develop numerous factional groups based on religion,
clan, and ethnicity','139eb851d7d4fc1de939d7f6ddfaef00eb80a8ec8f98db904461697dd9a12ea7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a5afc3eb49d0ba8acde1b5678edd6f4984fab1cdbd314e38866c0af71e6e62c',1999,'LS','Lesotho','geography',649,'Location: Southern Africa, an enclave of South
Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,350 sq km
land: 30,350 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers
Terrain: mostly highland with plateaus, hills, and
mountains
Elevation extremes:
lowest point: junction of the Orange and Makhaleng
Rivers 1 ,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing
land, some diamonds and other minerals
Land use:
arable land: 11%
permanent crops: NA%
permanent pastures: 66%
forests and woodland: NA%
other: 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: population pressure
forcing settlement in marginal areas results in
overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Marine Life Conservation, Ozone
Layer Protection
signed, but not ratified: Endangered Species, Law of
the Sea, Marine Dumping
Geography - note: landlocked; surrounded by','a0a9dc3064cf0c2a6a14abf8a4851aba45feff7a7d4371e9cad1c906c3917a03','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c39807729032e234cc09bf7d02bc17c10d7c9e1a2d7e1f39018c675356ba885',1999,'ZA','South Africa','geography',658,'Location: Western Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Sierra
Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 1 1 1 ,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716
km, Sierra Leone 306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot
days and cool to cold nights; wet, cloudy summers
with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to
rolling plateau and low mountains in northeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1 ,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 1 8%
offer: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow
from the Sahara (December to March)
Environment - current issues: tropical rain forest
subject to deforestation; soil erosion; loss of
biodiversity; pollution of coastal waters from oil
residue and raw sewage
Environment - international agreements:
party to: Desertification, Endangered Species,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Climate Change,
Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation','17ada235b8956b96b9472b6085d167be9961aaf3a950ec7f860892d15c35a991','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56869fa9bc38bc884d248fa36d4a432084962fc74fc9bff95b32b02b300faa61',1999,'LY','Libya','geography',659,'Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total: 1 ,759,540 sq km
land: 1 ,759,540 sq km
water: 0 sq km
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 4,383 km
border countries: Algeria 982 km, Chad 1 ,055 km,
Egypt 1,150 km, Niger 354 km, Sudan 383 km,
Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 12 nm
note: Gulf of Sidra closing line - 32 degrees 30
minutes north
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 91% (1993 est.)
Irrigated land: 4,700 sq km (1993 est.)
Natural hazards: hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring and
fall; dust storms, sandstorms
Environment - current issues: desertification; very
limited natural fresh water resources; the Great
284
Libya (continued)
Manmade River Project, the largest water
development scheme in the world, is being built to
bring water from large aquifers under the Sahara to
coastal cities
Environment - international agreements:
party to: Desertification, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection
signed, but not ratified: Biodiversity, Climate Change,
Law of the Sea','821b3dc5596982ad03e8ba56967467d6aa200002f01c40a25b91717459843808','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f55eef262591128e6018df433025f72c9bee2a3a85f057609e96969ed8050bf',1999,'CH','Switzerland','geography',667,'Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
total: 160 sq km
land: 160 sq km
water: 0 sq km
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 35 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources: hydroelectric potential
Land use:
arable land: 24%
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 35%
other: 25% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Endangered Species, hazardous
Wastes, Ozone Layer Protection, Wetlands
286
Liechtenstein (continued)
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Law of the Sea
Geography - note: along with Uzbekistan, one of
only two doubly landlocked countries in the world;
variety of microclimatic variations based on elevation
Location: Eastern Europe, bordering the Baltic Sea,
between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total: 65,200 sq km
land: 65,200 sq km
water: 0 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims:
territorial sea: 12 nm
Climate: transitional, between maritime and
continental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile
soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines/Kalnas 292 m
Natural resources: peat
Land use:
arable land: 35%
permanent crops: 12%
permanent pastures: 7%
forests and woodland: 31%
other: 15% (1993 est.)
Irrigated land: 430 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with petroleum products and
chemicals at military bases
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Location: Central Europe, east of France, north of','9985e71354a932ba7a0f2f12fd44a438d98738034c24a035ff6668f67c8d4ac2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d371bde4ed020647ff257378d23eae06660a58e8a45740f188e63ad234f436bf',1999,'MV','Maldives','geography',691,'Location: Southern Asia, group of atolls in the Indian
Ocean, south-southwest of India
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area:
total: 300 sq km
land: 300 sq km
water: 0 sq km
Area - comparative: about 1 .7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; dry, northeast
monsoon (November to March); rainy, southwest
monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili island in
the Addu Atoll 2.4 m
Natural resources: fish
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 3%
other: 84% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: low level of islands makes them
very sensitive to sea level rise
Environment - current issues: depletion of
freshwater aquifers threatens water supplies
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
"<0
Change-Kyoto Protocol, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: 1,190 coral islands grouped into
26 atolls; archipelago of strategic location astride and
along major sea lanes in Indian Ocean','9ac68ae7fd714aa8bdd6045c5e900ef0cb736608ef8490c57374b28f2284c170','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('290019f2b917e3c2d8fde4bb3785a47f8624216342de85391aeb0c21690f7f45',1999,'ML','Mali','geography',698,'Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area:
total: 1 .24 million sq km
land: 1 .22 million sq km
water: 20,000 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 7,243 km
border countries: Algeria 1 ,376 km, Burkina Faso
1,000 km, Guinea 858 km, Cote d''Ivoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry February to
June; rainy, humid, and mild June to November; cool
and dry November to February
Terrain: mostly flat to rolling northern plains covered
by sand; savanna in south, rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1 ,1 55 m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, bauxite, iron ore, manganese, tin,
and copper deposits are known but not exploited
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 6%
other: 67% (1993 est.)
Irrigated land: 780 sq km (1993 est.)
Natural hazards: hot, dust-laden harmattan haze
common during dry seasons; recurring droughts
Environment - current issues: deforestation; soil
erosion; desertification; inadequate supplies of
potable water; poaching
305
Mali (continued)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: landlocked','ec444c2ad41784930dd94195b45bc56ceeacc7f76f5098d75f55b85258526fa4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a6c7504e693f561bf0b30d41485a941c623f0aa48e181fb1577ced9187fc43',1999,'MT','Malta','geography',712,'Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 588 sq km
land: 588 sq km
water: 0 sq km
Area - comparative: slightly more than three times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 113 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
Climate: cool summers and mild winters; humid;
overcast about half the time
Terrain: hills in north and south bisected by central
valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: Snaefell 620 m
Natural resources: lead, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 32%
other: 0%
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: one small islet, the Calf of Man,
lies to the southwest, and is a bird sanctuary
309
Man, Isle of (continued)','a8164ebceb791ca94bf965e35474c4246a13c13edf2bc17c1199e02623d6fe30','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af6d43b0a763a604adfe80c906f43f2d0cdf3c7425a2cec79d95d7d0614013b8',1999,'MH','Marshall Islands','geography',714,'Location: Oceania, group of atolls and reefs in the
North Pacific Ocean, about one-half of the way from
Hawaii to Papua New Guinea
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
Area:
fota/:181.3sq km
land: 181.3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, and
Kwajalein
Area - comparative: about the size of Washington,
DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: wet season from May to November; hot and
humid; islands border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine
products, deep seabed minerals
Land use:
arable land: NA%
permanent crops: 60%
permanent pastures: NA%
forests and woodland: NA%
other: 40%
Irrigated land: NA sq km
Natural hazards: occasional typhoons
Environment - current issues: inadequate
supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertication,
Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: two archipelagic island chains of
30 atolls and 1 ,1 52 islands; Bikini and Enewetak are
former US nuclear test sites; Kwajalein, the famous
World War II battleground, is now used as a US
missile test range','7a29bbee8ee6a6a2f634a8ee7fef5b6b4461b45a3329134fa98b48db8cd4041f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2e53849a16e4cbb16a9a76e1f8fbde72cb9a55a9140d062cec40c1a607c2024',1999,'MQ','Martinique','geography',722,'Location: Caribbean, island in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 1,100 sq km
land: 1 ,060 sq km
water: 40 sq km
Area - comparative: slightly more than six times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; rainy
season (June to October); vulnerable to devastating
cyclones (hurricanes) every eight years on average;
average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline;
dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Natural resources: coastal scenery and beaches,
cultivable land
Land use:
arable land: 8%
permanent crops: 8%
permanent pastures: 17%
forests and woodland: 44%
other: 23% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: hurricanes, flooding, and volcanic
activity (an average of one major natural disaster
every five years)
Environment ■ current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre
and the Miquelon groups
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: cold and wet, with much mist and fog;
spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: 4%
other: 83% (1993 est.)
Irrigated land: NA sq km
Natural hazards: persistent fog throughout the year
can be a maritime hazard
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: vegetation scanty','9e4359a0a8b2cb016fa89f67286d99918eacc5005bfd202166008e98dcccace9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84a2431fc6eba96721ee7adf7f9b8757911c4f9b53adc8480614d12b46c0af5e',1999,'MU','Mauritius','geography',732,'Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total: 1 ,860 sq km
land: 1 ,850 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area - comparative: almost 1 1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, modified by southeast trade winds;
warm, dry winter (May to November); hot, wet, humid
summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling centra! plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use:
arable land: 49%
permanent crops: 3%
permanent pastures: 3%
forests and woodland: 22%
other: 23% (1 993 est.)
Irrigated land: 170 sq km (1993 est.)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs that may pose
maritime hazards
Environment - current issues: water pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements','cb89ecad52229a6204197c9ba96d039d96060a9f40942e92aa52b9da15372b6a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ce4d6a7e88473e28a48ac1cb0b95d03538bf63a1a280f43b3d1e0ddf9fb6210',1999,'MX','Mexico','geography',746,'Location: Middle America, bordering the Caribbean
Sea and the Gulf of Mexico, between Belize and the
US and bordering the North Pacific Ocean, between
Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total: 1 ,972,550 sq km
land: 1 ,923,040 sq km
water: 49,51 Osq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km,
US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal plains;
high plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold,
lead, zinc, natural gas, timber
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 26%
other: 22% (1 993 est.)
Irrigated land: 61 ,000 sq km (1993 est.)
Natural hazards: tsunamis along the Pacific coast,
volcanoes and destructive earthquakes in the center
and south, and hurricanes on the Gulf of Mexico and
Caribbean coasts
Environment - current issues: natural fresh water
resources scarce and polluted in north, inaccessible
and poor quality in center and extreme southeast; raw
sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion;
desertification; serious air pollution in the national
capital and urban centers along US-Mexico border
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: strategic location on southern
border of US
Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic
658 km, Germany 456 km, Lithuania 91 km, Russia
(Kaliningrad Oblast) 206 km, Slovakia 444 km,
Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international
treaties
territorial sea: 12 nm
Climate: temperate with cold, cloudy, moderately
severe winters with frequent precipitation; mild
summers with frequent showers and thundershowers
Terrain: mostly flat plain; mountains along southern
border
Elevation extremes:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas,
silver, lead, salt
Land use:
arable land: 47%
permanent crops: 1%
permanent pastures: 13%
forests and woodland: 29%
of/rer; 10% (1993 est.)
Irrigated land: 1,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: situation has
improved since 1989 due to decline in heavy industry
and increased environmental concern by
postcommunist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions from coal-fired power plants, and
the resulting acid rain has caused forest damage;
water pollution from industrial and municipal sources
is also a problem, as is disposal of hazardous wastes
Environment - international agreements:
party to: Air Pollution, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Climate Change-Kyoto Protocol
Geography - note: historically, an area of conflict
because of flat terrain and the lack of natural barriers
on the North European Plain','3a648bfd8232eb3ef5f88387e1430c2558b03bc987ee85c1cc277bd25442e280','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('618f9a553a1c46891bdbfd53177839edda1d4b3ea2582710596c7dfa7054d012',1999,'US','United States','geography',754,'Location: Western Europe, bordering the
Mediterranean Sea, on the southern coast of France,
near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total: 1 .95 sq km
land: 1 .95 sq km
water: 0 sq km
Area - comparative: about three times the size of
The Mall in Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean with mild, wet winters and
hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 1 00% (urban area) •
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: second smallest independent
state in world (after Holy See); almost entirely urban','49856f0721f09ad935eb47747248fd9e727159eac28ae149ded23feeb493f6a0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22cd95403edf925191f76f8c09732e6da2b23e063e505a5fde283b5c43d4e425',1999,'MS','Montserrat','geography',765,'Location: Caribbean, island in the Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the
Caribbean
Area:
total: 100 sq km
land: 100 sq km
water: 0 sq km
Area - comparative: about 0.6 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; little daily or seasonal temperature
variation
Terrain: volcanic islands, mostly mountainous, with
small coastal lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chances Peak 914 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
permanent pastures: 1 0%
forests and woodland: 40%
other: 30% (1993 est.)
Irrigated land: NA sq km
Natural hazards: severe hurricanes (June to
November); volcanic eruptions (full-scale eruptions of
the Soufriere Hills volcano occurred during 1996-97)
Environment - current issues: land erosion occurs
on slopes that have been cleared for cultivation
Environment - international agreements:
party to: NA
signed, but not ratified: NA','f05fb11d2056062c564f22886b6c01cbcab54b20aa667073461e543989dd332d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f37d80673ac98fb94db0d9be1213a6afd291a861027e50e9ab527931551070d',1999,'PT','Portugal','geography',772,'Location: Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between
Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
total: 446,550 sq km
land: 446,300 sq km
wafer: 250 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 2, 017. 9 km
border countries: Algeria 1,559 km, Western Sahara
443 km, Spain (Ceuta) 6.3 km, Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: Mediterranean, becoming more extreme in
the interior
Terrain: northern coast and interior are mountainous
with large areas of bordering plateaus, intermontane
valleys, and rich coastal plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use:
arable land: 21%
permanent crops: 1%
permanent pastures: 47%
forests and woodland: 20%
other: 11% (1993 est.)
Irrigated land: 12,580 sq km (1993 est.)
Natural hazards: northern mountains geologically
unstable and subject to earthquakes; periodic
droughts
Environment - current issues: land degradation/
desertification (soil erosion resulting from farming of
marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal
waters
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography - note: strategic location along Strait of','c49c5b8a5dc8824f79cce88f4a3225306fca2ec93dba93fe834640cf658486ba','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('115f01cb53520ed4b0367e32ac2af2e9aac0e1c825f5f7f4d77171ec68d4e942',1999,'NA','Namibia','geography',779,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total: 825,41 8 sq km
land: 825,41 8 sq km
water: 0 sq km
Area - comparative: slightly more than half the size
of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1 ,376 km, Botswana 1 ,360
km, South Africa 855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, lead, tin, lithium, cadmium, zinc, salt, vanadium,
natural gas, fish; suspected deposits of oil, natural
gas, coal, iron ore
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 22%
other: 31% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: prolonged periods of drought
Environment - current issues: very limited natural
fresh water resources; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements','b5cb5ded3b2279836cdb67c84efd71fe52819c51dd69d25636885906e1fcbff2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('218c5058f495cc7b93f2f0b63f6c5ff4e4df36f593592b122d4ff718c7cc81c0',1999,'NR','Nauru','geography',794,'Location: Caribbean, island in the Caribbean Sea,
about one-fourth of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
Area:
total: 5.2 sq km
land: 5.2 sq km
water: 0 sq km
Area - comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15
meters high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side 77
m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 0%
forests and woodland: 0%
other: 90%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: strategic location 160 km south
of the US Naval Base at Guantanamo Bay, Cuba;
mostly exposed rock, but enough grassland to support
goat herds; dense stands of fig-like trees, scattered
cactus','9484e4e031ba8d24bfb952a8cf481b0735ca8d9a3b88ff788d7935a4c3c1d163','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('586b0979f6b7b21f1d19745ec1cdba29472ecf6c0e395af9062cd0bf9e75155f',1999,'NP','Nepal','geography',795,'Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
Area - comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1 ,236 km, India 1 ,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Terai or flat river plain of the Ganges in
south, central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,848 m
Natural resources: quartz, water, timber,
hydropower potential, scenic beauty, small deposits of
lignite, copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
permanent pastures: 15%
forests and woodland: 42%
other: 26% (1993 est.)
Irrigated land: 8,500 sq km (1993 est.)
Natural hazards: severe thunderstorms, flooding,
landslides, drought, and famine depending on the
timing, intensity, and duration of the summer
monsoons
Environment - current issues: the almost total
dependence on wood for fuel and cutting down trees
to expand agricultural land without replanting has
resulted in widespread deforestation; soil erosion;
water pollution (use of contaminated water presents
human health risks)
ft
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life
Conservation
Geography - note: landlocked; strategic location
between China and India; contains eight of world''s 1 0
highest peaks','b8b068ad1c4d692f679efde3937af4359a506964e9697436d2cdedc63c1d77c6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60e5f692c70990067de2c52e246434b421a2cfed2fa238168d8ad5b75967c784',1999,'BE','Belgium','geography',801,'Location: Western Europe, bordering the North Sea,
between Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41 ,532 sq km
land: 33,889 sq km
wafer: 7,643 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; marine; cool summers and mild
winters
Terrain: mostly coastal lowland and reclaimed land
(polders); some hills in southeast
Elevation extremes:
lowest point: Prins Alexanderpolder -7 m
highest point: Vaalserberg 321 m
Natural resources: natural gas, petroleum, fertile
soil
Land use:
arable land: 25%
permanent crops: 3%
permanent pastures: 25%
forests and woodland: 8%
other: 39% (1996 est.)
Irrigated land: 6,000 sq km (1996 est.)
Natural hazards: the extensive system of dikes and
dams protects nearly one-half of the total area from
being flooded
Environment - current issues: water pollution in
the form of heavy metals, organic compounds, and
nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Biodiversity, Climate
Change-Kyoto Protocol
Geography - note: located at mouths of three major
European rivers (Rhine, Maas or Meuse, and
Schelde)','36f2d485277346f8f9e8311f45ab08a2d710bf2a971c659bc22222b3d430047c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc6d59727f644f3eae7e1e3094e4851c06a2a15b4e65ec4e78e91b458570c0f8',1999,'NL','Netherlands','geography',808,'Location: Caribbean, two island groups in the
Caribbean Sea - one includes Curacao and Bonaire
north of Venezuela and the other is east of the Virgin
Islands
Geographic coordinates: 12 15 N, 68 45 W
Map references: Central America and the
Caribbean
Area:
total: 960 sq km
land: 960 sq km
wafer 0 sq km
note: includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part of the island
of Saint Martin)
Area - comparative: more than five times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Guadeloupe (Saint Martin) 10.2 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea: 12 nm
Climate: tropical; ameliorated by northeast trade
winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao only), salt
(Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 90% (1993 est.)
Irrigated land: NA sq km
348
Netherlands Antilles (continued)
Natural hazards: Curacao and Bonaire are south of
Caribbean hurricane belt and are rarely threatened;
Sint Maarten, Saba, and Sint Eustatius are subject to
hurricanes from July to October
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed , but not ratified: NA','37237491d00c1ea921d3c8269f4f43fa6dc6397f8c5f93ca119cf4838e3fb8b5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fede3751376a2b5942b011c2ca21c8e67acb898681a09243fc4ed04fbd2b8e17',1999,'NC','New Caledonia','geography',815,'Location: Oceania, islands in the South Pacific
Ocean, east of Australia
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
tofa/:19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area - comparative: slightly smaller than New','9551319ba58630cf3117205bdf920bdd66a0bcc1322385d8c2a0b991490dac11','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c6e31c87f10b70c2ea3ce7684e44136388fe5b3dd45db25147c4021c50e197',1999,'NE','Niger','geography',823,'Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1 .267 million sq km
land: 1 ,266,700 sq km
water: 300 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1,175 km, Libya 354 km,
Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; flat to roiling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Greboun 1 ,944 m
Natural resources: uranium, coal, iron ore, tin,
phosphates, gold, petroleum
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 2%
of/rer: 88% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus, giraffe,
and lion) threatened because of poaching and habitat
destruction
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Law of the Sea
Geography - note: landlocked','b3d853dad0aa67bc28a2543162fe89b603a8028b92d8d53b3770c380bd7e3999','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2127f673aefc36a0fd4aad8a245c2c0dcbc81253f7df7d2ce7bce3e5ca527884',1999,'NU','Niue','geography',831,'Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau
settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 4%
forests and woodland: 1 9%
other: 50% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons
Environment - current issues: traditional methods
of burning brush and trees to clear land for agriculture
have threatened soil supplies which are not naturally
very abundant
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification
signed, but not ratified: Climate Change-Kyoto
361
Niue (continued)
Protocol, Law of the Sea
Geography - note: one of world''s largest coral
islands','1e0be5fe881d70d7f24946e682da83cc6cafa7b942f427b48f781a3cb90e32de','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f2573fcda0b192e546c27cb377bae2fce9856b2d0d64394dda4085d022e81c0',1999,'NF','Norfolk Island','geography',835,'Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area - comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 25%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (especially May to July)
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA','b31da12fd94ee9b62cccaf9c06087f744e11a03f709068f78eeb120e2a0774fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fccb5c1fad5368184a964a1997102e783843ef9c4bd9141d23c4dfe142555ee',1999,'PA','Panama','geography',846,'Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
water: 2,21 Osq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330
km
Coastline: 2,490 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy; prolonged rainy
season (May to January), short dry season (January
to May)
Terrain: interior mostly steep, rugged mountains and
dissected, upland plains; coastal areas largely plains
and rolling hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests,
shrimp
Land use:
arable land: 7%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 44%
other: 27% (1993 est.)
Irrigated land: 320 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution from
agricultural runoff threatens fishery resources;
deforestation of tropical rain forest; land degradation
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location on eastern end
of isthmus forming land bridge connecting North and
South America; controls Panama Canal that links
North Atlantic Ocean via Caribbean Sea with North
Pacific Ocean','0de6ecc27f43ba81c9a6c53dbb1fec84c76e72844426567f95ec1dce791e1e88','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3667164e72b66c5a404ccfa6638a78fb5f0cc3c000a217dc031df32d761b0640',1999,'PH','Philippines','geography',854,'Geographic coordinates: 16 30 N, 1 12 00 E
Map references: Southeast Asia
Area:
total: NA sq km
land: NA sq km
water: 0 sq km
Area - comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: typhoons
Environment - current issues: NA
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Location: Central South America, northeast of
Geographic coordinates: 8 38 N, 1 1 1 55 E
Map references: Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea
mounts scattered over an area of nearly 410,000 sq
km of the central South China Sea
Area - comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4
m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1 993)
Natural hazards: typhoons; serious maritime hazard
because of numerous reefs and shoals
Environment - current issues: NA
Environment - international agreements:
party to: none of the selected agreements
signed , but not ratified: none of the selected
agreements
Geography - note: strategically located near several
primary shipping lanes in the central South China Sea;
includes numerous small islands, atolls, shoals, and
coral reefs','fc21ec6cb88d6f99ca80031f7a43b0a4f0e3ce72076d3da3808b14fb6a08b15c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a58ae24fe8d05bea8bcd42f40407b82c7a1e88c2047b2a4de1fb3d9e555040',1999,'PR','Puerto Rico','geography',867,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, east of the
Geographic coordinates: 1 8 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area:
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical, tempered by easterly trade
winds, relatively low humidity, little seasonal
temperature variation; rainy season May to November
Terrain: mostly hilly to rugged and mountainous with
little level land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 1 5%
permanent crops: 6%
permanent pastures: 26%
forests and woodland: 6%
other: 47% (1993 est.)
Irrigated land: NA sq km
Natural hazards : several hurricanes in recent years;
frequent and severe droughts and floods; occasional
earthquakes
Environment - current issues: lack of natural
freshwater resources
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: important location along the
Anegada Passage - a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural, deepwater harbors in the Caribbean
Location: Oceania, atoll in the North Pacific Ocean,
about two-thirds of the way from Hawaii to the','31182351a2888ddf752092869b85a9c2859706a2361b663d2190f045995a20b8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9944b6da08477ebfd9c1030cff56cd5c905468425892ad88ee21875ec521e273',1999,'DO','Dominican Republic','geography',868,'Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area:
total: 9,104 sq km
land: 8,959 sq km
water: 145 sq km
Area - comparative: slightly less than three times
the size of Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine, mild; little seasonal
temperature variation
Terrain: mostly mountains, with coastal plain belt in
north; mountains precipitous to sea on west coast;
sandy beaches along most coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1 ,338 m
Natural resources: some copper and nickel;
potential for onshore and offshore oil
Land use:
arable land: 4%
permanent crops: 5%
permanent pastures: 26%
forests and woodland: 16%
other: 49% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: periodic droughts; hurricanes
Environment - current issues: erosion; occasional
drought causing water shortages
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: important location along the
Mona Passage - a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best natural
harbors in the Caribbean; many small rivers and high
central mountains ensure land is well watered; south
coast relatively dry; fertile coastal plain belt in north','610eb3792d4ab83419c8a39d66d55350199540be8ec742e49c2d8590441677ce','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b97d8dcc4393cea7dc5bd45560325e6bdb5da25527730902f34900c821f68e4',1999,'QA','Qatar','geography',869,'Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
Area:
total: 1 1 ,437 sq km
land: 1 1 ,437 sq km
water: 0 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; humid and sultry in summer
Terrain: mostly flat and barren desert covered with
loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 103 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1%
permanent crops: NA%
permanent pastures: 5%
forests and woodland: NA%
other: 94% (1993 est.)
Irrigated land: 80 sq km (1993 est.)
Natural hazards: haze, dust storms, sandstorms
common
Environment - current issues: limited natural fresh
water resources are increasing dependence on
large-scale desalination facilities
Environment - international agreements:
party to: Biodiversity, Climate Change, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: strategic location in central
Persian Gulf near major petroleum deposits
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
total: 2,51 Osq km
land: 2,500 sq km
wafer: 1 0sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 201 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but temperature moderates with
elevation; cool and dry from May to November, hot
and rainy from November to April
Terrain: mostly rugged and mountainous; fertile
lowlands along coast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land
Land use:
arable land: 17%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 35%
other: 41% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: periodic, devastating cyclones
(December to April); Piton de la Fournaise on the
southeastern coast is an active volcano
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA','9a38b18cbae700140bba84a90a36c2f9687f4bcb56baae3907219b6157f05c3e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117c1fa93f608f1a611536c903a6dbb69f24b260a6152524eed8d9924d91df84',1999,'RO','Romania','geography',877,'Location: Southeastern Europe, bordering the Black
Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km,
Moldova 450 km, Serbia and Montenegro 476 km (all
with Serbia), Ukraine (north) 362 km, Ukraine (east)
169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Plain of Moldavia on the east by the
Carpathian Mountains and separated from the
Walachian Plain on the south by the Transylvanian
Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining),
timber, natural gas, coal, iron ore, salt
Land use:
arable land: 41%
permanent crops: 3%
permanent pastures: 21 %
forests and woodland: 29%
other: 6% (1 993 est.)
Irrigated land: 31 ,020 sq km (1 993 est.)
Natural hazards: earthquakes most severe in south
and southwest; geologic structure and climate
promote landslides
Environment - current issues: soil erosion and
degradation; water pollution; air pollution in south from
industrial effluents; contamination of Danube delta
wetlands
Environment ■ international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: controls most easily traversable
land route between the Balkans, Moldova, and','59c4b7d8b5dd9044bf897f57c026cfe98aa3b446dbf14ddcd19fd83268cc3034','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fe79ae6efdadb959ed741a91fa9d9e6c7235050afce9280a38f1f70a7c3fca0',1999,'UA','Ukraine','geography',887,'Location: Northern Asia (that part west of the Urals
is sometimes included with Europe), bordering the
Arctic Ocean, between Europe and the North Pacific
Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area:
tofa/: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
Area - comparative: slightly less than 1 .8 times the
size of the US
Land boundaries:
tofa/: 1 9,91 7 km
border countries: Azerbaijan 284 km, Belarus 959 km,
China (southeast) 3,605 km, China (south) 40 km,
Estonia 294 km, Finland 1 ,31 3 km, Georgia 723 km,
Kazakhstan 6,846 km, North Korea 1 9 km, Latvia 21 7
km, Lithuania (Kaliningrad Oblast) 227 km, Mongolia
3,441 km, Norway 167 km, Poland (Kaliningrad
Oblast) 206 km, Ukraine 1 ,576 km
Coastline: 37,653 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: ranges from steppes in the south through
humid continental in much of European Russia;
subarctic in Siberia to tundra climate in the polar north;
winters vary from cool along Black Sea coast to frigid
in Siberia; summers vary from warm in the steppes to
cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast
coniferous forest and tundra in Siberia; uplands and
mountains along southern border regions
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Mount El''brus 5,633 m
Natural resources: wide natural resource base
including major deposits of oil, natural gas, coal, and
many strategic minerals, timber
note: formidable obstacles of climate, terrain, and
distance hinder exploitation of natural resources
Land use:
arable land: 8%
permanent crops: 0%
permanent pastures: 4%
forests and woodland: 46%
other: 42% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: permafrost over much of Siberia is
a major impediment to development; volcanic activity
in the Kuril Islands; volcanoes and earthquakes on the
Kamchatka Peninsula
403
Russia (continued)
Environment - current issues: air pollution from
heavy industry, emissions of coal-fired electric plants,
and transportation in major cities; industrial,
municipal, and agricultural pollution of inland
waterways and sea coasts; deforestation; soil erosion;
soil contamination from improper application of
agricultural chemicals; scattered areas of sometimes
intense radioactive contamination
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
Geography - note: largest country in the world in
terms of area but unfavorably located in relation to
major sea lanes of the world; despite its size, much of
the country lacks proper soils and climates (either too
cold or too dry) for agriculture
Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,340 sq km
land: 24,950 sq km
water: 1 ,390 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Democratic
Republic of the Congo 217 km, Tanzania 21 7 km,
Uganda 169 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to
April, November to January); mild in mountains with
frost and snow possible
Terrain: mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), methane, hydropower
Land use:
arable land: 35%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 22%
other: 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic
Birunga mountains are in the northwest along the
border with Democratic Republic of the Congo
Environment - current issues: deforestation
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion; widespread
poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban
signed, but not ratified: Law of the Sea
Geography - note: landlocked; predominantly rural
population
Location: islands in the South Atlantic Ocean, about
mid-way between South America and Africa
Geographic coordinates: 15 56 S, 5 42 W
Map references: Africa
Area:
total: 410 sq km
land: 410 sq km
water: 0 sq km
note: includes Ascension, Gough Island, Inaccessible
Island, Nightingale Islands, and Tristan da Cunha
Island
Area - comparative: slightly more than two times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 60 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: Saint Helena - tropical; marine; mild,
tempered by trade winds; Tristan da Cunha -
temperate; marine, mild, tempered by trade winds
(tends to be cooler than Saint Helena)
Terrain: Saint Helena - rugged, volcanic; small
scattered plateaus and plains
note: the other islands of the group have a volcanic
origin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da
Cunha 2,060 m
Natural resources: fish
Land use:
arable land: 6%
permanent crops: NA%
permanent pastures: 6%
forests and woodland: 6%
other: 82% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism on Tristan da
Cunha
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: Napoleon Bonaparte''s place of
exile and burial (his remains were taken to Paris in
1840); harbors at least 40 species of plants unknown
anywhere else in the world; Ascension is a breeding
ground for sea turtles and sooty terns
Location: Caribbean, islands in the Caribbean Sea,
about one-third of the way from Puerto Rico to
Location: Eastern Europe, bordering the Black Sea,
between Poland and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent
States
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km,
Moldova 939 km, Poland 428 km, Romania (south)
169 km, Romania (west) 362 km, Russia 1,576 km,
Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate continental; Mediterranean only
on the southern Crimean coast; precipitation
disproportionately distributed, highest in west and
north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland;
summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found only in
the west (the Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber
Land use:
arable land: 58%
permanent crops: 2%
permanent pastures: 13%
forests and woodland: 18%
other: 9% (1 993 est.)
Irrigated land: 26,050 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: inadequate
supplies of potable water; air and water pollution;
deforestation; radiation contamination in the northeast
from 1 986 accident at Chornobyl1 Nuclear Power Plant
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic Treaty,
Biodiversity, Climate Change, Environmental
Modification, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Law of the Sea
Geography - note: strategic position at the
crossroads between Europe and Asia; second-largest
country in Europe','841fa980b8121cd75f54457e342ba55f9298bcf46f7a3b894e1952794b9d1ad8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3f29fa1e53594332f2b21ebccb4de0f33ae8866923ebedb37ceea0429c4febd',1999,'TT','Trinidad and Tobago','geography',888,'Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the
Caribbean
Area:
total: 269 sq km
land: 269 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: subtropical tempered by constant sea
breezes; little seasonal temperature variation; rainy
season (May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: NEGL
Land use:
arable land: 22%
permanent crops: 1 7%
permanent pastures: 3%
forests and woodland: 17%
other: At % (1993 est.)
irrigated land: NAsqkm
Natural hazards: hurricanes (July to October)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements','cc6002415cab6b05136ddc893133cfc72e68851eac5fce0afa695fdcd494cac6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029f50822eb8dead5b542604ce788b85fff7669dd2d4573018abf8bceb11866b',1999,'LC','Saint Lucia','geography',896,'Location: Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 1 3 53 N, 60 68 W
Map references: Central America and the
Caribbean
Area:
total: 620 sq km
land: 610 sq km
wafer: 10 sq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims: 200 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, moderated by northeast trade
winds; dry season from January to April, rainy season
from May to August
Terrain: volcanic and mountainous with some broad,
fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geothermal
potential
Land use:
arable land: 8%
permanent crops: 21 %
permanent pastures: 5%
forests and woodland: 1 3%
other: 53% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes and volcanic activity
Environment - current issues: deforestation; soil
erosion, particularly in the northern region
412
Saint Lucia (continued)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol','faeca3295ba8a86b938550c1a0a6b3b60aa2d437c800255bffdbb0ee3eaf6934','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4a7fd7b2535d911b73fc69fdff43f1b7f143f83cd6b7ec8c7daa49081eee9c2',1999,'IT','Italy','geography',904,'Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total: 60 sq km
land: 60 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters; warm,
sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 749 m
Natural resources: building stone
Land use:
arable land: 17%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 83% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Nuclear Test
Ban
signed, but not ratified: Air Pollution
Geography - note: landlocked; smallest
independent state in Europe after the Holy See and
Monaco; dominated by the Apennines
Location: Western Africa, islands in the Gulf of
Guinea, straddling the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
total: 1 ,000 sq km
land: 1 ,000 sq km
water: 0 sq km
Area - comparative: more than five times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; one rainy season
(October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish
Land use:
arable land: 2%
permanent crops: 36%
permanent pastures: 1 %
forests and woodland: NA%
other: 61% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation; soil
erosion and exhaustion
Environment - international agreements:
party to: Desertification, Environmental Modification,
Law of the Sea
signed, but not ratified: Biodiversity, Climate Change
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total: 41 ,290 sq km
land: 39,770 sq km
water: 1 ,520 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,852 km
border countries: Austria 164 km, France 573 km,
Italy 740 km, Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with altitude; cold,
cloudy, rainy/snowy winters; cool to warm, cloudy,
humid summers with occasional showers
Terrain: mostly mountains (Alps in south, Jura in
northwest) with a central plateau of rolling hills, plains,
and large lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber,
salt
Land use:
arable land: 10%
permanent crops: 2%
permanent pastures: 28%
forests and woodland: 32%
other: 28% (1993 est.)
Irrigated land: 250 sq km (1993 est.)
Natural hazards: avalanches, landslides, flash
floods
Environment - current issues: air pollution from
vehicle emissions and open-air burning; acid rain;
water pollution from increased use of agricultural
fertilizers; loss of biodiversity
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea
Geography - note: landlocked; crossroads of
northern and southern Europe; along with
southeastern France and northern Italy, contains the
highest elevations in Europe
Location: Middle East, bordering the Mediterranean
Sea, between Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1 ,295 sq km of Israeli-occupied territory
Area - comparative: slightly larger than North
Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan
375 km, Lebanon 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 nm
territorial sea: 35 nm
Climate: mostly desert; hot, dry, sunny summers
(June to August) and mild, rainy winters (December to
February) along coast; cold weather with snow or
sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau;
narrow coastal plain; mountains in west
Elevation extremes:
lowest point: unnamed location near Lake Tiberias
-200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phosphates, chrome
and manganese ores, asphalt, iron ore, rock salt,
marble, gypsum
Land use:
arable land: 28%
permanent crops: 4%
permanent pastures: 43%
forests and woodland: 3%
other: 22% (1993 est.)
Irrigated land: 9,060 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation;
overgrazing; soil erosion; desertification; water
pollution from dumping of raw sewage and wastes
from petroleum refining; inadequate supplies of
potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, NuclearTest Ban,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Environmental Modification
Geography - note: there are 42 Israeli settlements
and civilian land use sites in the Israeli-occupied
Golan Heights (August 1998 est.)','9faccc0c4cf009d128e5c629a3c354b70a556a73e85a84b52aa7fa7e1aa47e2c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('637771dd99c513301bb27cff53106669381b87daec3c7c149462951fb211f67e',1999,'SA','Saudi Arabia','geography',913,'Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1 ,960,582 sq km
land: 1 ,960,582 sq km
water: 0 sq km
Area - comparative: slightly more than one-fifth the
size of the US
Land boundaries:
tofa/:4,415 km
border countries: Iraq 814 km, Jordan 728 km, Kuwait
222 km, Oman 676 km, Qatar 60 km, UAE 457 km,
Yemen 1,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
territorial sea: 12 nm
Climate: harsh, dry desert with great extremes of
temperature
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore,
gold, copper
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1%
other: 41% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: desertification;
depletion of underground water resources; the lack of
perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil spills
Environment - international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: extensive coastlines on Persian
Gulf and Red Sea provide great leverage on shipping
(especially crude oil) through Persian Gulf and Suez
Canal
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and','7cebf5939f79e427394b3128cb0d8b22cfd721d041b6c069837056678eba44ba','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d74a247dcd87d7a1350038e22c687ae25e64d60ade67aa2318233d7c1bb921f',1999,'MR','Mauritania','geography',920,'Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
total: 196,190 sq km
land: 192,000 sq km
wafer; 4, 190 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330
km, Guinea-Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; rainy season (May to
November) has strong southeast winds; dry season
(December to April) dominated by hot, dry, harmattan
wind
Terrain: generally low, rolling, plains rising to
foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha
581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 54%
other: 18% (1993 est.)
Irrigated land: 710 sq km (1993 est.)
Natural hazards: lowlands seasonally flooded;
periodic droughts
Environment - current issues: wildlife populations
threatened by poaching; deforestation; overgrazing;
soil erosion; desertification; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography - note: The Gambia is almost an
enclave of Senegal','1574ea43170d1827a8be663c49d2ce4c04cd67d3918b30331b9e1ecc13695c38','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('268dc794d31866fb55b313ed199ce8e87d3c895292f85df07917c16f8771b8be',1999,'ME','Montenegro','geography',926,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and
Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km (Serbia 88,412 sq km;
Montenegro 13,938 sq km)
land: 102,136 sq km (Serbia 88,412 sq km;
Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro 214 sq
km)
Area - comparative: slightly smaller than Kentucky
(Serbia is slightly larger than Maine; Montenegro is
slightly smaller than Connecticut)
Land boundaries:
total: 2,246 km
border countries: Albania 287 km (1 1 4 km with
Serbia, 173 km with Montenegro), Bosnia and
Herzegovina 527 km (31 2 km with Serbia, 21 5 km with
Montenegro), Bulgaria 318 km (with Serbia), Croatia
(north) 241 km (with Serbia), Croatia (south) 25 km
(with Montenegro), Hungary 151 km (with Serbia),
The Former Yugoslav Republic of Macedonia 221 km
(with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and
Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia 0
km)
Maritime claims: NA
427
Serbia and Montenegro (continued)
Climate: in the north, continental climate (cold winter
and hot, humid summers with well distributed rainfall);
central portion, continental and Mediterranean
climate; to the south, Adriatic climate along the coast,
hot, dry summers and autumns and relatively cold
winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the
southeast, ancient mountains and hills; to the
southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper,
lead, zinc, nickel, gold, pyrite, chrome
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: destructive earthquakes
Environment - current issues: pollution of coastal
waters from sewage outlets, especially in
tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava
which flows into the Danube
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: controls one of the major land
routes from Western Europe to Turkey and the Near
East; strategic location along the Adriatic coast','4f3dc0d8c3afb0ab19f9e9cda7b1d5612e49e1e2b4bc5c08662d3edca4d80ba2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38485a28c7392a44b517368ad995074b2c77cf3cf3f37d87e53b0171cd25b032',1999,'SC','Seychelles','geography',931,'Location: Eastern Africa, group of islands in the
Indian Ocean, northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area ■ comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; humid; cooler season
during southeast monsoon (late May to September);
warmer season during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow coastal strip,
rocky, hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2%
permanent crops: 13%
permanent pastures: NA%
forests and woodland: 11%
other: 74% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; short droughts possible
Environment - current issues: water supply
depends on catchments to collect rain water
Environment - international agreements:
parly to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: 40 granitic and about 50
coralline islands','460f55d46fc02d2d6096ed1eeae7ca725227d83fdd0115374dc3a6d1875304ad','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3284cf8143a68799ce71b1396abc283cd2ec6fadbf1b08e01735845b148674af',1999,'SL','Sierra Leone','geography',939,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71 ,740 sq km
land: 7 1,620 sq km
water: 120 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; hot, humid; summer rainy season
(May to December); winter dry season (December to
April)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite,
iron ore, gold, chromite
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 31 %
forests and woodland: 28%
other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds
blow from the Sahara (November to May);
sandstorms, dust storms
Environment - current issues: rapid population
growth pressuring the environment; overharvesting of
timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting
natural resources; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 647.5 sq km
land: 637.5 sq km
wafer; 10 sq km
Area - comparative: slightly more than 3.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive fishing zone: within and beyond territorial
sea, as defined in treaties and practice
territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no pronounced
rainy or dry seasons; thunderstorms occur on 40% of
all days (67% of days in April)
Terrain: lowland; gently undulating central plateau
contains water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 1 66 m
Natural resources: fish, deepwater ports
Land use:
arable land: 2%
permanent crops: 6%
permanent pastures: NA%
forests and woodland: 5%
other: 87% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: industrial pollution;
limited natural fresh water resources; limited land
availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','e7fc6e22b1cee5e0d52a3b805aa301cacc50984731b06628c53213e279c83cb8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('017a56d496dc4902cbc8e006af4b383b8061f840109cd1aaa8c352485338b684',1999,'SK','Slovakia','geography',946,'Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area - comparative: about twice the size of New
Hampshire
Land boundaries:
total: 1 ,355 km
border countries: Austria 91 km, Czech Republic 215
km, Hungary 515 km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovka 2,655 m
Natural resources: brown coal and lignite; small
amounts of iron ore, copper and manganese ore; salt
Land use:
arable land: 31%
forests and woodland: 41 %
other: 8% (1 993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: air pollution from
metallurgical plants presents human health risks; acid
rain damaging forests
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked
Location: Southeastern Europe, eastern Alps
damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid
rain
bordering the Adriatic Sea, between Austria and','f1b8b7412244a7b2a7d5f30a8f584a954acfc728e701c49ffbe9aa431aef266a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78a02ec486bdbc96f3af583f41ee47e278dad3e71abdeb1a85fecfb28a182fa1',1999,'SB','Solomon Islands','geography',956,'Location: Oceania, group of islands in the South
Pacific Ocean, east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area:
total: 28,450 sq km
land: 27,540 sq km
water: 91 Osq km
Area - comparative: slightly smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; few extremes of
temperature and weather
Terrain: mostly rugged mountains with some low
coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite,
phosphates, lead, zinc, nickel
Land use:
arable land: 1%
permanent crops: 1%
441
Solomon Islands (continued)
permanent pastures: 1 %
forests and woodland: 88%
other: 9% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons, but they are rarely
destructive; geologically active region with frequent
earth tremors; volcanic activity
Environment - current issues: deforestation; soil
erosion; much of the surrounding coral reefs are dead
or dying
Environment - international agreements:
party to: Biodiversity, Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol','9aa14b0edf2053458d51263198bcdfd4f4af8e00c200be197ea559edc1faaa12','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5547d09b2665154adb16c0a657fab66386ad1b8f1da069636d63ec14c1b48d5c',1999,'SO','Somalia','geography',962,'Location: Eastern Africa, bordering the Gulf of Aden
and the Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area:
total: 637,660 sq km
land: 627,340 sq km
wafer: 10,320 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1 ,626 km,
Kenya 682 km
Coastline: 3,025 km
Maritime claims:
territorial sea: 200 nm
Climate: principally desert; December to February -
northeast monsoon, moderate temperatures in north
and very hot in south; May to October - southwest
monsoon, torrid in the north and hot in the south,
irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to
hills in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely unexploited
reserves of iron ore, tin, gypsum, bauxite, copper, salt
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 69%
forests and woodland: 26%
other: 3% (1993 est.)
Irrigated land: 1 ,800 sq km (1 993 est.)
Natural hazards: recurring droughts; frequent dust
storms over eastern plains in summer
Environment - current issues: famine; use of
contaminated water contributes to human health
443
Somalia (continued)
problems; deforestation; overgrazing; soil erosion;
desertification
Environment - international agreements:
party to: Endangered Species, Law of the Sea
signed, but not ratified: Marne Dumping, Nuclear
Test Ban
Geography - note: strategic location on Horn of
Africa along southern approaches to Bab el Mandeb
and route through Red Sea and Suez Canal
Location: Southern Africa, at the southern tip of the
continent of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island
and Prince Edward Island)
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 4,750 km
border countries: Botswana 1 ,840 km, Lesotho 909
km, Mozambique 491 km, Namibia 855 km,
Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly semiarid; subtropical along east
coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by rugged hills
and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal,
iron ore, manganese, nickel, phosphates, tin,
uranium, gem diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 67%
forests and woodland: 7%
South Africa (continued)
other: 15% (1993 est.)
Irrigated land: 12,700 sq km (1993 est.)
Natural hazards: prolonged droughts
Environment - current issues: lack of important
arterial rivers or lakes requires extensive water
conservation and control measures; growth in water
usage threatens to outpace supply; pollution of rivers
from agricultural runoff and urban discharge; air
pollution resulting in acid rain; soil erosion;
desertification
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: South Africa completely
surrounds Lesotho and almost completely surrounds
Swaziland
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 4,066 sq km
land: 4,066 sq km
water: 0 sq km
note: includes Shag Rocks, Clerke Rocks, Bird Island
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NAkm
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: variable, with mostly westerly winds
throughout the year interspersed with periods of calm;
nearly all precipitation falls as snow
Terrain: most of the islands, rising steeply from the
sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered
mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget 2,91 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (largely covered by permanent ice and
snow with some sparse vegetation consisting of
grass, moss, and lichen)
Irrigated land: 0sqkm(1993)
Natural hazards: the South Sandwich Islands have
prevailing weather conditions that generally make
them difficult to approach by ship; they are also
subject to active volcanism
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: the north coast of South Georgia
has several large bays, which provide good
anchorage; reindeer, introduced early in this century,
live on South Georgia','63fc751f97d0bded46898746647cde122d42ae4ffc9f2277e3275b38100b9879','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f3de3ff82632bef01f2fd1306d61f7f26e75a3ec9496b5715f244030dc09114',1999,'LK','Sri Lanka','geography',972,'Location: Southern Asia, island in the Indian Ocean,
south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; northeast monsoon
(December to March); southwest monsoon (June to
October)
Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral
sands, gems, phosphates, clay
Land use:
arable land: 14%
permanent crops: 15%
permanent pastures: 7%
forests and woodland: 32%
other: 32% (1993 est.)
Irrigated land: 5,500 sq km (1993 est.)
Natural hazards: occasional cyclones and
tornadoes
Environment - current issues: deforestation; soil
erosion; wildlife populations threatened by poaching;
coastal degradation from mining activities and
452
Sri Lanka (continued)
increased pollution; freshwater resources being
polluted by industrial wastes and sewage runoff
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location near major
Indian Ocean sea lanes','df6615079d9dfa9e267384cc538d2e2e5364d73eb95fd082dc61580b3874d285','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac0f1c9a7fbb1ddf9583d98210a5dbe6574979ee8c0bedee9277f6e0f5a9923',1999,'SR','Suriname','geography',985,'Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana and','c0a0885b01b1a745b37f8ab18e10fdb72d8d2d07eb19f2951d3d194c03e6aa71','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5656d9ceed7582c9882429258fd4c65b465cff533eed22f8a71a81c124bf2c9',1999,'GY','Guyana','geography',986,'Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total: 163,270 sq km
land: 161 ,470 sq km
water: 1 ,800 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1,707 km
border countries: Brazil 597 km, French Guiana 510
km, Guyana 600 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with
swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain -2
m
highest point: Wilhelmina Gebergte 1 ,286 m
Natural resources: timber, hydropower, fish, kaolin,
shrimp, bauxite, gold, and small amounts of nickel,
copper, platinum, iron ore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 0%
forests and woodland: 96%
other: 4% (1993 est.)
Irrigated land: 600 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation as
timber is cut for export; pollution of inland waterways
by small-scale mining activities
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: mostly tropical rain forest; great
diversity of flora and fauna that, for the most part, is
increasingly threatened by new development;
relatively small population, most of which lives along
the coast
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
fofa/:17,360sq km
land: 17,200 sq km
water: 1 60 sq km
Area - comparative: slightly smaller than New','de0be2f4945eef83bcab203caed5cf51d4acd99303366d4b44f378f4e1ec5738','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1511b756266369bafe471e06b06b3d51f065f547de203377fe490e26deb4a1',1999,'TJ','Tajikistan','geography',991,'Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent
States
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1 ,206 km, China 41 4
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamir and Alay mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower
potential, some petroleum, uranium, mercury, brown
coal, lead, zinc, antimony, tungsten
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: inadequate
sanitation facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides; part of the
basin of the shrinking Aral Sea suffers from severe
overutilization ot available water for irrigation and
associated pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,090 sq km
land: 886,040 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and
Zanzibar
Area - comparative: slightly larger than twice the
size of California
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda 217
km, Uganda 396 km, Zambia 338 km
Coastline: 1 ,424 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin, phosphates,
iron ore, coal, diamonds, gemstones, gold, natural
gas, nickel
Land use:
arable land: 3%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 38%
other: 18% (1993 est.)
Irrigated land: 1 ,500 sq km (1993 est.)
Natural hazards: the tsetse fly; flooding on the
central plateau during the rainy season; drought
Environment - current issues: soil degradation;
deforestation; desertification; destruction of coral
reefs threatens marine habitats; recent droughts
affected marginal agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: Kilimanjaro is highest point in
Africa','5194e01105b29effd24d71ced1f975ef72d4885e692ff3076d2642580db322bb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc004771639fd39c07a7a417a60076ae725cd22253ec22ebd0b2132ca3be492d',1999,'TH','Thailand','geography',999,'Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 51 1 ,770 sq km
water: 2,230 sq km
Area - comparative: slightly more than twice the
size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1,800 km, Cambodia 803
km, Laos 1 ,754 km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool northeast
475
Thailand (continued)
monsoon (November to mid-March); southern
isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite
Land use:
arable land: 34%
permanent crops: 6%
permanent pastures: 2%
forests and woodland: 26%
other: 32% (1993 est.)
Irrigated land: 44,000 sq km (1993 est.)
Natural hazards: land subsidence in Bangkok area
resulting from the depletion of the water table;
droughts
Environment - current issues: air pollution from
vehicle emissions; water pollution from organic and
factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Environment - international agreements:
party to: Climate Change, Endangered Species,
Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol, Law of the Sea
Geography - note: controls only land route from
Asia to Malaysia and Singapore','a4d7d789b9d69f7983a893d6a0b4dc1513ea6170ffc3255f38222b610391b325','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ff2847333672b4743f5a123d74f8d5ef6448863b390d0af69e26ddd67f49b19',1999,'TK','Tokelau','geography',1014,'Location: Oceania, group of three islands in the
South Pacific Ocean, about one-half of the way from
Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
tofa/:10sq km
land: 10 sq km
water: 0 sq km
Area - comparative: about 1 7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds (April to
November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies in Pacific typhoon belt
Environment - current issues: very limited natural
resources and overcrowding are contributing to
emigration to New Zealand
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Location: Oceania, archipelago in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','473ca4e3c3c31cc92ad81e839a639612ced7f92aeb1abcf539caeb347691f620','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad33474e16ec9e28d086e9bd2311f13b20c42a78cf27fb9035d852b03c542fe1',1999,'AF','Afghanistan','geography',1021,'Location: Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
wafer: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; moderated by trade winds;
sunny and relatively dry
Terrain: low, flat limestone; extensive marshes and
mangrove swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 98% (1993 est.)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes
Environment - current issues: limited natural fresh
water resources, private cisterns collect rainwater
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: 30 islands (eight inhabited)','a25d3ee6f099b14f5f39048469136b7e414d187b3ba01352de2c045585904eee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca596bad8a7167916d5cf54c5bffd7cb06078518e763c5bdbe29fb90aa936ae6',1999,'TV','Tuvalu','geography',1023,'Location: Oceania, island group consisting of nine
coral atolls in the South Pacific Ocean, about one-half
of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area - comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by easterly trade winds
(March to November); westerly gales and heavy rain
(November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: severe tropical storms are usually
rare, but, in 1997, there were three cyclones
Environment - current issues: since there are no
streams or rivers and groundwater is not potable, all
water needs must be met by catchment systems with
storage facilities; beachhead erosion because of the
use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel;
damage to coral reefs from the spread of the Crown of
Thorns starfish; T uvalu is very concerned about global
increases in greenhouse gas emissions and their
effect on rising sea levels, which threaten the
country''s underground water table
Environment - international agreements:
party to: Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Biodiversity, Law of the Sea
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of the Congo
765 km, Kenya 933 km, Rwanda 169 km, Sudan 435
km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley
5,110 m
Natural resources: copper, cobalt, limestone, salt
Land use:
arable land: 25%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 28%
other: 29% (1993 est.)
Irrigated land: 90 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: draining of wetlands
for agricultural use; deforestation; overgrazing; soil
erosion; poaching is widespread
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
497
Uganda (continued)
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Environmental Modification
Geography - note: landlocked','7f4fedfe3447502f2d115aaa433eb51d1866c0e7895ce2d6cb12c9296d7281ca','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b1da4e02a7e1dcc708da51402f8e40124123654167d7206c3417810964a8bdf',1999,'IE','Ireland','geography',1039,'Location: Western Europe, islands including the
northern one-sixth of the island of Ireland between the
North Atlantic Ocean and the North Sea, northwest of','c787d283c2e22a1f57631ee037062bbb59858683c4c126a28ad13dd81380700a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9240713bff2be6804f67eee3baa53c3ccd69301eb237aec195c0128786fb0ff3',1999,'UY','Uruguay','geography',1046,'Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent
States
Area:
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km, Kazakhstan
2,203 km, Kyrgyzstan 1,099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km
note: Uzbekistan includes the southern portion of the
Aral Sea with a 420 km shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with
dunes; broad, flat intensely irrigated river valleys
along course of Amu Darya, Sirdaryo (Syr Darya), and
Zarafshon; Fergana Valley in east surrounded by
mountainous Tajikistan and Kyrgyzstan; shrinking
Aral Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead and zinc, tungsten,
molybdenum
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 3%
other: 41% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: drying up of the Aral
Sea is resulting in growing concentrations of chemical
pesticides and natural salts; these substances are
then blown from the increasingly exposed lake bed
and contribute to desertification; water pollution from
industrial wastes and the heavy use of fertilizers and
pesticides is the cause of many human health
disorders; increasing soil salination; soil
contamination from agricultural chemicals, including
DDT
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: along with Liechtenstein, one of
the only two doubly landlocked countries in the world •','bf1227f71637c42e571f4738fcfe74ade886186d715a2cae8099a63b02800ab8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c4bfb4faadb2f5de277c70bc169452a01e031abcf23e927941c60f6a377a4e6',1999,'VU','Vanuatu','geography',1049,'Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way from
Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 14,760 sq km
land: 14,760 sq km
water: 0 sq km
note: includes more than 80 islands
Area - comparative: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by southeast trade
winds
Terrain: mostly mountains of volcanic origin; narrow
coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1 ,877 m
Natural resources: manqanese, hardwood forests,
fish
Land use:
arable land: 2%
permanent crops: 10%
permanent pastures: 2%
forests and woodland: 75%
other: 11% (1993 est.)
Irrigated land: NA sq km
Natural hazards: tropical cyclones or typhoons
(January to April); volcanism causes minor
earthquakes
Environment - current issues: a majority of the
population does not have access to a potable and
reliable supply of water; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Desertification, Law of the
Sea
Location: Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America, Central America
and the Caribbean
Area:
total: 91 2,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area - comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
contiguous zone: 15 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: Andes Mountains and Maracaibo Lowlands
in northwest; central plains (llanos); Guiana Highlands
in southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources: petroleum, natural gas, iron ore,
gold, bauxite, other minerals, hydropower, diamonds
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 34%
other: 41% (1993 est.)
Irrigated land: 1 ,900 sq km (1993 est.)
Natural hazards: subject to floods, rockslides, mud
slides; periodic droughts
Environment - current issues: sewage pollution of
Lago de Valencia; oil and urban pollution of Lago de
Maracaibo; deforestation; soil degradation; urban and
industrial pollution, especially along the Caribbean
coast
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography - note: on major sea and air routes
linking North and South America
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east of','549736560a6c6af3504db94156f604bd2bf54fe76bcf82b821a2539eee70ea55','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9650dbb6e30d036eb7410ddb2016b9f88e1a5c544d681726cc22a3552bd736c4',1999,'MP','Northern Mariana Islands','geography',1061,'Geographic coordinates: 19 17 N, 166 36 E
Map references: Oceania
Area:
tote/; 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: atoll of three coral islands built up on an
underwater volcano; central lagoon is former crater,
islands are part of the rim
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1998)
Natural hazards: occasional typhoons
Environment - current issues: NA
Environment - international agreements:
party to: NA
signed, but not ratified: NA
Geography - note: strategic location in the North
Pacific Ocean; emergency landing location for
transpacific flights','15dcad284348e48cd5c83f7cc0511a8a8fe9722adafc1d0875cceeabbe1d2761','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb26af86c364bc5ce0495e009b37e0cf3dbe292d47c69e66e6d401794c19e8c9',1999,'YE','Yemen','geography',1063,'Location: Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and Saudi
Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen
Arab Republic (YAR or North Yemen), and the former
People''s Democratic Republic of Yemen (PDRY or
South Yemen)
Area - comparative: slightly larger than twice the
size of Wyoming
Land boundaries:
total: 1 ,746 km
border countries: Oman 288 km, Saudi Arabia 1 ,458
km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nm in the
South
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal plain backed by flat-topped
hills and rugged mountains; dissected upland desert
plains in center slope into the desert interior of the
Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble, small deposits of coal, gold, lead, nickel, and
copper, fertile soil in west
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 30%
forests and woodland: 4%
other: 63% (1993 est.)
Irrigated land: 3,600 sq km (1993 est.)
Natural hazards: sandstorms and dust storms in
summer
Environment - current issues: very limited natural
fresh water resources; inadequate supplies of potable
water; overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Bab el
Mandeb, the strait linking the Red Sea and the Gulf of
Aden, one of world''s most active shipping lanes','0ce005a6a64ec2cde63a5411b5d366e366849bb68f00219797e03fc3082cfc29','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f9e7a5e3b76e8d23326ffbc15fad1898bf0c5bdb0d9f218710994dbb619c08',1999,'ZM','Zambia','geography',1072,'Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area:
total: 752,61 Osq km
land: 740,720 sq km
water: 1 1 ,890 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km, Democratic
Republic of the Congo 1 ,930 km, Malawi 837 km,
Mozambique 41 9 km, Namibia 233 km, Tanzania 338
km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season
(October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills
2,301 m
Natural resources: copper, cobalt, zinc, lead, coal,
emeralds, gold, silver, uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 40%
forests and woodland: 39%
other: 14% (1993 est.)
Irrigated land: 460 sq km (1993 est.)
Natural hazards: tropical storms (November to
April)
Environment - current issues: air pollution and
resulting acid rain in the mineral extraction and
refining region; poaching seriously threatens
rhinoceros and elephant populations; deforestation;
534
Zambia (continued)
soil erosion; desertification; lack of adequate water
treatment presents human health risks
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked','156bfd059019641444f19dfc0b68224e84fec5ef48e235f4fe32802ffdca99d6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc6e8b3cebc4e310f6af93b9ef347623a11855e6ff347da6cc8b45734f1b11d2',1999,'ZW','Zimbabwe','geography',1076,'Location: Southern Africa, northeast of Botswana
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total: 390,580 sq km
land: 386,670 sq km
water: 3,91 Osq km
Area - comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique
1,231 km, South Africa 225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes:
lowest point: junction of the Runde and Save rivers
162 m
textiles, fertilizer
Industrial production growth rate: 3.5% (1996)
Electricity - production: 7.84 billion kWh (1996)
Electricity - production by source:
fossil fuel: 0.51%
hydro: 99.49%
nuclear: 0%
other: 0% (1996)
Electricity - consumption: 6.393 billion kWh (1 996)
Electricity - exports: 1 .47 billion kWh (1 996)
Electricity - imports: 23 million kWh (1996)
Agriculture - products: corn, sorghum, rice,
peanuts, sunflower seed, tobacco, cotton, sugarcane,
cassava (tapioca); cattle, goats, pigs, poultry, beef,
pork, poultry meat, milk, eggs, hides
Exports: $905 million (f.o.b., 1998 est.)
Exports - commodities: copper, cobalt, zinc, lead,
tobacco
Exports - partners: Japan, South Africa, US, Saudi
Arabia, India, Thailand, Malaysia (1997)
Imports: $1.1 billion (f.o.b., 1998 est.)
Imports - commodities: machinery, transportation
equipment, foodstuffs, fuels, petroleum products,
electricity, fertilizer
Imports - partners: South Africa 48%, Saudi Arabia,
UK, Zimbabwe (1997)
Debt -external: $7.1 billion (1997 est.)
Economic aid - recipient: $1,991 billion (1995)
Currency: 1 Zambian kwacha (ZK) = 100 ngwee
Exchange rates: Zambian kwacha (ZK) per US$1 -
1,428 (October 1998), 1,333.81 (1997), 1,203.71
(1996), 857.23 (1995), 669.37 (1994)
Fiscal year: calendar year','485a50ffc43ea59a8d13969360db8b6f5537af40b90bcd3435cd385291336ebc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db696834b0b5376602962c32766cc756aafa0beec83deb535bc5318a50c2075',1999,'ZW','Zimbabwe','geography',7,'Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, talc,
barites, sulfur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush
mountains; flooding
Environment--current issues: soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification
Environment--international agreements:
party to: Desertification, Endangered Species, Environmental
Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Geography--note: landlocked
Location: Southeastern Europe, bordering the Adriatic Sea and
Ionian Sea, between Greece and Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,750 sq km
land: 27,400 sq km
water: 1,350 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, The Former Yugoslav Republic of
Macedonia 151 km, Serbia and Montenegro 287 km (114 km with Serbia,
173 km with Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: mild temperate; cool, cloudy, wet winters; hot, clear,
dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Natural resources: petroleum, natural gas, coal, chromium,
copper, timber, nickel
Land use:
arable land: 21%
permanent crops: 5%
permanent pastures: 15%
forests and woodland: 38%
other: 21% (1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis occur along
southwestern coast
Environment--current issues: deforestation; soil erosion; water
pollution from industrial and domestic effluents
Environment--international agreements:
party to: Biodiversity, Climate Change, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: strategic location along Strait of Otranto (links
Adriatic Sea to Ionian Sea and Mediterranean Sea)
Location: Northern Africa, bordering the Mediterranean Sea,
between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
Area--comparative: slightly less than 3.5 times the size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km, Mauritania 463 km,
Morocco 1,559 km, Niger 956 km, Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: 12 nm
Climate: arid to semiarid; mild, wet winters with hot, dry
summers along coast; drier with cold winters and hot summers on high
plateau; sirocco is a hot, dust/sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to severe earthquakes;
mud slides
Environment--current issues: soil erosion from overgrazing and
other poor farming practices; desertification; dumping of raw
sewage, petroleum refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters; Mediterranean
Sea, in particular, becoming polluted from oil wastes, soil erosion,
and fertilizer runoff; inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography--note: second-largest country in Africa (after Sudan)','35a27c2beb8fb408f86c02f950e9d8ac832e9ea8835f663c4f397f6b0af177fe','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1159ef5bfddfe96c597af7c0c44cab04028f587fbea18192001d517f5c5b3f94',1999,'LY','Libya','geography',15,'Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area--comparative: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine, moderated by southeast trade winds;
annual rainfall averages 124 inches; rainy season from November to
April, dry season from May to October; little seasonal temperature
variation
Terrain: five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 5%
permanent crops: 10%
permanent pastures: 0%
forests and woodland: 70%
other: 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December to March
Environment--current issues: limited natural fresh water
resources; the water division of the government has spent
substantial funds in the past few years to improve water catchments
and pipelines
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: Pago Pago has one of the best natural deepwater
harbors in the South Pacific Ocean, sheltered by shape from rough
seas and protected by peripheral mountains from high winds;
strategic location in the South Pacific Ocean
Location: Southwestern Europe, between France and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 450 sq km
land: 450 sq km
water: 0 sq km
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries:
total: 125 km
border countries: France 60 km, Spain 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm, dry summers
Terrain: rugged mountains dissected by narrow valleys
Elevation extremes:
lowest point: Riu Valira 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water, timber, iron ore,
lead
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 22%
other: 20% (1993 est.)
Irrigated land: NA sq km
Natural hazards: snowslides, avalanches
Environment--current issues: deforestation; overgrazing of
mountain meadows contributes to soil erosion
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: landlocked
Location: Southern Africa, bordering the South Atlantic Ocean,
between Namibia and Democratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area--comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo 2,511 km of which
220 km is the boundary of discontiguous Cabinda Province, Republic
of the Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: semiarid in south and along coast to Luanda; north has
cool, dry season (May to October) and hot, rainy season (November to
April)
Terrain: narrow coastal plain rises abruptly to vast interior
plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates,
copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes periodic flooding
on the plateau
Environment--current issues: the overuse of pastures and
subsequent soil erosion attributable to population pressures;
desertification; deforestation of tropical rain forest, in response
to both international demand for tropical timber and to domestic use
as fuel, resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers and dams;
inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography--note: Cabinda is separated from rest of country by the
Democratic Republic of the Congo
Location: Caribbean, island in the Caribbean Sea, east of Puerto
Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the Caribbean
Area:
total: 91 sq km
land: 91 sq km
water: 0 sq km
Area--comparative: about half the size of Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; moderated by northeast trade winds
Terrain: flat and low-lying island of coral and limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly rock with sparse scrub oak, few trees, some
commercial salt ponds)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes and other tropical storms
(July to October)
Environment--current issues: supplies of potable water sometimes
cannot meet increasing demand largely because of poor distribution
system
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: continent mostly south of the Antarctic Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72 million sq km
ice-covered) (est.)
note: second-smallest continent (after Australia)
Area--comparative: slightly less than 1.5 times the size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none, but see entry on International disputes
Climate: severe low temperatures vary with latitude, elevation,
and distance from the ocean; East Antarctica is colder than West
Antarctica because of its higher elevation; Antarctic Peninsula has
the most moderate climate; higher temperatures occur in January
along the coast and average slightly below freezing
Terrain: about 98% thick continental ice sheet and 2% barren
rock, with average elevations between 2,000 and 4,000 meters;
mountain ranges up to about 5,000 meters; ice-free coastal areas
include parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Vinson Massif 5,140 m
Natural resources: none presently exploited; iron ore, chromium,
copper, gold, nickel, platinum and other minerals, and coal and
hydrocarbons have been found in small, uncommercial quantities
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km (1993)
Natural hazards: katabatic (gravity-driven) winds blow coastward
from the high interior; frequent blizzards form near the foot of the
plateau; cyclonic storms form over the ocean and move clockwise
along the coast; volcanism on Deception Island and isolated areas of
West Antarctica; other seismic activity rare and weak
Environment--current issues: in 1998, NASA satellite data showed
that the antarctic ozone hole was the largest on record, covering 27
million square kilometers; researchers in 1997 found that increased
ultraviolet light coming through the hole damages the DNA of
icefish, an antarctic fish lacking hemoglobin; ozone depletion
earlier was shown to harm one-celled antarctic marine plants
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: the coldest, windiest, highest, and driest
continent; during summer, more solar radiation reaches the surface
at the South Pole than is received at the Equator in an equivalent
period; mostly uninhabitable
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the Caribbean
Area:
total: 440 sq km
land: 440 sq km
water: 0 sq km
note: includes Redonda
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature variation
Terrain: mostly low-lying limestone and coral islands, with some
higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters tourism
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 11%
other: 62% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms (July to
October); periodic droughts
Environment--current issues: water management?a major concern
because of limited natural fresh water resources--is further hampered
by the clearing of trees to increase crop production, causing
rainfall to run off quickly
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Location: body of water mostly north of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea, Chukchi Sea,
East Siberian Sea, Greenland Sea, Hudson Bay, Hudson Strait, Kara
Sea, Laptev Sea, Northwest Passage, and other tributary water bodies
Area--comparative: slightly less than 1.5 times the size of the
US; smallest of the world''s four oceans (after Pacific Ocean,
Atlantic Ocean, and Indian Ocean)
Coastline: 45,389 km
Climate: polar climate characterized by persistent cold and
relatively narrow annual temperature ranges; winters characterized
by continuous darkness, cold and stable weather conditions, and
clear skies; summers characterized by continuous daylight, damp and
foggy weather, and weak cyclones with rain or snow
Terrain: central surface covered by a perennial drifting polar
icepack that averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line movement from the
New Siberian Islands (Russia) to Denmark Strait (between Greenland
and Iceland); the icepack is surrounded by open seas during the
summer, but more than doubles in size during the winter and extends
to the encircling landmasses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonsov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates, placer deposits,
polymetallic nodules, oil and gas fields, fish, marine mammals
(seals and whales)
Natural hazards: ice islands occasionally break away from
northern Ellesmere Island; icebergs calved from glaciers in western
Greenland and extreme northeastern Canada; permafrost in islands;
virtually icelocked from October to June; ships subject to
superstructure icing from October to May
Environment--current issues: endangered marine species include
walruses and whales; fragile ecosystem slow to change and slow to
recover from disruptions or damage
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: major chokepoint is the southern Chukchi Sea
(northern access to the Pacific Ocean via the Bering Strait);
strategic location between North America and Russia; shortest marine
link between the extremes of eastern and western Russia; floating
research stations operated by the US and Russia; maximum snow cover
in March or April about 20 to 50 centimeters over the frozen ocean;
snow cover lasts about 10 months
Location: Southern South America, bordering the South Atlantic
Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area--comparative: slightly less than three-tenths the size of the
US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1,224 km, Chile 5,150 km,
Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate; arid in southeast; subantarctic in
southwest
Terrain: rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
Elevation extremes:
lowest point: Salinas Chicas -40 m (located on Peninsula Valdes)
highest point: Cerro Aconcagua 6,962 m
Natural resources: fertile plains of the pampas, lead, zinc, tin,
copper, iron ore, manganese, petroleum, uranium
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 52%
forests and woodland: 19%
other: 19% (1993 est.)
Irrigated land: 17,000 sq km (1993 est.)
Natural hazards: San Miguel de Tucuman and Mendoza areas in the
Andes subject to earthquakes; pamperos are violent windstorms that
can strike the Pampas and northeast; heavy flooding
Environment--current issues: erosion results from inadequate flood
controls and improper land use practices; irrigated soil
degradation; desertification; air pollution in Buenos Aires and
other major cities; water pollution in urban areas; rivers becoming
polluted due to increased pesticide and fertilizer use
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Geography--note: second-largest country in South America (after
Brazil); strategic location relative to sea lanes between South
Atlantic and South Pacific Oceans (Strait of Magellan, Beagle
Channel, Drake Passage)
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent States
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km, Azerbaijan-Naxcivan
exclave 221 km, Georgia 164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold winters
Terrain: Armenian Highland with mountains; little forest land;
fast flowing rivers; good soil in Aras River valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper, molybdenum,
zinc, alumina
Land use:
arable land: 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 15%
other: 41% (1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes; droughts
Environment--current issues: soil pollution from toxic chemicals
such as DDT; energy blockade, the result of conflict with
Azerbaijan, has led to deforestation when citizens scavenged for
firewood; pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its use as a
source for hydropower, threatens drinking water supplies; restart of
Metsamor nuclear power plant without adequate (IAEA-recommended)
safety and backup systems
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Nuclear Test Ban, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Geography--note: landlocked','b624911b717eabe2a48e54f94208a7f21f30ee15fe6bcb05948f5e564820e18d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c75bab238c70815066f581e5c1493899116a7742a80456538176b2696b8a67f',1999,'AM','Armenia','geography',31,'Location: Caribbean, island in the Caribbean Sea, north of
Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the Caribbean
Area:
total: 193 sq km
land: 193 sq km
water: 0 sq km
Area--comparative: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: NEGL; white sandy beaches
Land use:
arable land: 11%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 89% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies outside the Caribbean hurricane belt
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Southeastern Asia, islands in the Indian Ocean,
northwest of Australia
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East Islets) and
Cartier Island
Area--comparative: about eight times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0 sq km (1993)
Natural hazards: surrounded by shoals and reefs that can pose
maritime hazards
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: Ashmore Reef National Nature Reserve established
in August 1983
Location: body of water between Africa, Europe, Antarctica, and
the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: World
Area:
total: 82.217 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea, Davis Strait,
Denmark Strait, Drake Passage, Gulf of Mexico, Mediterranean Sea,
North Sea, Norwegian Sea, Scotia Sea, Weddell Sea, and other
tributary water bodies
Area--comparative: slightly less than nine times the size of the
US; second-largest of the world''s four oceans (after the Pacific
Ocean, but larger than Indian Ocean or Arctic Ocean)
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off the coast of
Africa near Cape Verde and move westward into the Caribbean Sea;
hurricanes can occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and Baltic Sea from October to June; clockwise
warm-water gyre (broad, circular system of currents) in the northern
Atlantic, counterclockwise warm-water gyre in the southern Atlantic;
the ocean floor is dominated by the Mid-Atlantic Ridge, a rugged
north-south centerline for the entire Atlantic basin
Elevation extremes:
lowest point: Puerto Rico Trench -8,605 m
highest point: in the Milwaukee Deep at sea level 0 m
Natural resources: oil and gas fields, fish, marine mammals
(seals and whales), sand and gravel aggregates, placer deposits,
polymetallic nodules, precious stones
Natural hazards: icebergs common in Davis Strait, Denmark Strait,
and the northwestern Atlantic Ocean from February to August and have
been spotted as far south as Bermuda and the Madeira Islands;
icebergs from Antarctica occur in the extreme southern Atlantic
Ocean; ships subject to superstructure icing in extreme northern
Atlantic from October to May and extreme southern Atlantic from May
to October; persistent fog can be a maritime hazard from May to
September
Environment--current issues: endangered marine species include the
manatee, seals, sea lions, turtles, and whales; drift net fishing is
hastening the decline of fish stocks and contributing to
international disputes; municipal sludge pollution off eastern US,
southern Brazil, and eastern Argentina; oil pollution in Caribbean
Sea, Gulf of Mexico, Lake Maracaibo, Mediterranean Sea, and North
Sea; industrial waste and municipal sewage pollution in Baltic Sea,
North Sea, and Mediterranean Sea
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: major chokepoints include the Dardanelles, Strait
of Gibraltar, access to the Panama and Suez Canals; strategic
straits include the Strait of Dover, Straits of Florida, Mona
Passage, The Sound (Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic Ocean and South
Atlantic Ocean
Location: Oceania, continent between the Indian Ocean and the
South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total: 7,686,850 sq km
land: 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie Island
Area--comparative: slightly smaller than the US
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally arid to semiarid; temperate in south and east;
tropical in north
Terrain: mostly low plateau with deserts; fertile plain in
southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciusko 2,229 m
Natural resources: bauxite, coal, iron ore, copper, tin, silver,
uranium, nickel, tungsten, mineral sands, lead, zinc, diamonds,
natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 54%
forests and woodland: 19%
other: 21% (1993 est.)
Irrigated land: 21,070 sq km (1993 est.)
Natural hazards: cyclones along the coast; severe droughts
Environment--current issues: soil erosion from overgrazing,
industrial development, urbanization, and poor farming practices;
soil salinity rising due to the use of poor quality water;
desertification; clearing for agricultural purposes threatens the
natural habitat of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral reef in the
world, is threatened by increased shipping and its popularity as a
tourist site; limited natural fresh water resources
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto Protocol,
Desertification
Geography--note: world''s smallest continent but sixth-largest
country; population concentrated along the eastern and southeastern
coasts; regular, tropical, invigorating, sea breeze known as "the
Doctor" occurs along the west coast in the summer
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total: 83,858 sq km
land: 82,738 sq km
water: 1,120 sq km
Area--comparative: slightly smaller than Maine
Land boundaries:
total: 2,562 km
border countries: Czech Republic 362 km, Germany 784 km, Hungary 366
km, Italy 430 km, Liechtenstein 35 km, Slovakia 91 km, Slovenia 330
km, Switzerland 164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; continental, cloudy; cold winters with
frequent rain in lowlands and snow in mountains; cool summers with
occasional showers
Terrain: in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
Elevation extremes:
lowest point: Neusiedler See 115 m
highest point: Grossglockner 3,797 m
Natural resources: iron ore, oil, timber, magnesite, lead, coal,
lignite, copper, hydropower
Land use:
arable land: 17%
permanent crops: 1%
permanent pastures: 23%
forests and woodland: 39%
other: 20% (1996 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: some forest degradation caused by air
and soil pollution; soil pollution results from the use of
agricultural chemicals; air pollution results from emissions by
coal- and oil-fired power stations and industrial plants and from
trucks transiting Austria between northern and southern Europe
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Geography--note: landlocked; strategic location at the crossroads
of central Europe with many easily traversable Alpine passes and
valleys; major river is the Danube; population is concentrated on
eastern lowlands because of steep slopes, poor soils, and low
temperatures elsewhere
Location: Southwestern Asia, bordering the Caspian Sea, between
Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent States
Area:
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Area--comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper) 566 km, Armenia
(with Azerbaijan-Naxcivan exclave) 221 km, Georgia 322 km, Iran
(with Azerbaijan-proper) 432 km, Iran (with Azerbaijan-Naxcivan
exclave) 179 km, Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km, est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore, nonferrous
metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 11%
other: 41% (1993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas threatened by
rising levels of the Caspian Sea
Environment--current issues: local scientists consider the Abseron
Yasaqligi (Apsheron Peninsula) (including Baku and Sumqayit) and the
Caspian Sea to be the ecologically most devastated area in the world
because of severe air, water, and soil pollution; soil pollution
results from the use of DDT as a pesticide and also from toxic
defoliants used in the production of cotton
Environment--international agreements:
party to: Climate Change, Desertification, Ozone Layer Protection
signed, but not ratified: Biodiversity
Geography--note: landlocked
Location: Caribbean, chain of islands in the North Atlantic
Ocean, southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area--comparative: slightly smaller than Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by warm waters of Gulf Stream
Terrain: long, flat coral formations with some low rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Natural resources: salt, aragonite, timber
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 32%
other: 67% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and other tropical storms that cause
extensive flood and wind damage
Environment--current issues: coral reef decay; solid waste disposal
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: strategic location adjacent to US and Cuba;
extensive island chain
Location: Middle East, archipelago in the Persian Gulf, east of','c0d37540555d345eded1433f246103edd0f1d180c835a735c21b2c9387cf92c9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ba8c5394cb6258022bf620c86d14be3e59f2ffce379962d86b00e6c758eb598',1999,'SA','Saudi Arabia','geography',33,'Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 620 sq km
land: 620 sq km
water: 0 sq km
Area--comparative: 3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: extending to boundaries to be determined
territorial sea: 12 nm
Climate: arid; mild, pleasant winters; very hot, humid summers
Terrain: mostly low desert plain rising gently to low central
escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and nonassociated natural gas,
fish
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 0%
other: 92% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: periodic droughts; dust storms
Environment--current issues: desertification resulting from the
degradation of limited arable land, periods of drought, and dust
storms; coastal degradation (damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills and other discharges from
large tankers, oil refineries, and distribution stations; no natural
fresh water resources so that groundwater and sea water are the only
sources for all water needs
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: close to primary Middle Eastern petroleum
sources; strategic location in Persian Gulf which much of Western
world''s petroleum must transit to reach open ocean
Location: Oceania, atoll in the North Pacific Ocean, about
one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area:
total: 1.4 sq km
land: 1.4 sq km
water: 0 sq km
Area--comparative: about 2.5 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind, burning sun
Terrain: low, nearly level coral island surrounded by a narrow
fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until 1891)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: the narrow fringing reef surrounding the island
can be a maritime hazard
Environment--current issues: no natural fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: treeless, sparse, and scattered vegetation
consisting of grasses, prostrate vines, and low growing shrubs;
primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife
Location: Southern Asia, bordering the Bay of Bengal, between
Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
Area--comparative: slightly smaller than Wisconsin
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: up to the outer limits of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; cool, dry winter (October to March); hot,
humid summer (March to June); cool, rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1,230 m
Natural resources: natural gas, arable land, timber
Land use:
arable land: 73%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 15%
other: 5% (1993 est.)
Irrigated land: 31,000 sq km (1993 est.)
Natural hazards: droughts, cyclones; much of the country
routinely flooded during the summer monsoon season
Environment--current issues: many people are landless and forced
to live on and cultivate flood-prone land; limited access to potable
water; water-borne diseases prevalent; water pollution especially of
fishing areas results from the use of commercial pesticides;
intermittent water shortages because of falling water tables in the
northern and central parts of the country; soil degradation;
deforestation; severe overpopulation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references: Central America and the Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 37%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 12%
other: 46% (1993 est.)
Irrigated land: NA sq km
Natural hazards: infrequent hurricanes; periodic landslides
Environment--current issues: pollution of coastal waters from
waste disposal by ships; soil erosion; illegal solid waste disposal
threatens contamination of aquifers
Environment--international agreements:
party to: Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Biodiversity
Geography--note: easternmost Caribbean island
Location: Southern Africa, islands in the southern Mozambique
Channel, about one-half of the way from Madagascar to Mozambique
Geographic coordinates: 21 30 S, 39 50 E
Map references: Africa
Area:
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
Area--comparative: about one-third the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: a volcanic rock 2.4 m high
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all rock)
Irrigated land: 0 sq km (1993)
Natural hazards: maritime hazard since it is usually under water
during high tide and surrounded by reefs; subject to periodic
cyclones
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Commonwealth of Independent States
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area--comparative: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km, Poland 605 km,
Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers; transitional
between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small quantities of
oil and natural gas
Land use:
arable land: 29%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 34%
other: 21% (1993 est.)
Irrigated land: 1,000 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: soil pollution from pesticide use;
southern part of the country contaminated with fallout from 1986
nuclear reactor accident at Chornobyl'' in northern Ukraine
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Biodiversity, Environmental Modification,
Marine Dumping, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the Sea
Geography--note: landlocked
Location: Western Europe, bordering the North Sea, between France
and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total: 30,510 sq km
land: 30,230 sq km
water: 280 sq km
Area--comparative: about the size of Maryland
Land boundaries:
total: 1,385 km
border countries: France 620 km, Germany 167 km, Luxembourg 148 km,
Netherlands 450 km
Coastline: 64 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors (extends about 68
km from coast)
territorial sea: 12 nm
Climate: temperate; mild winters, cool summers; rainy, humid,
cloudy
Terrain: flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21%
other: 34%
Irrigated land: 10 sq km including Luxembourg (1993 est.)
Natural hazards: flooding is a threat in areas of reclaimed
coastal land, protected from the sea by concrete dikes
Environment--current issues: the environment is exposed to intense
pressures from human activities: urbanization, dense transportation
network, industry, intense animal breeding and crop cultivation; air
and water pollution also have repercussions for neighboring
countries; uncertainties regarding federal and regional
responsibilities (now resolved) have impeded progress in tackling
environmental challenges
Environment--international agreements:
party to: Air Pollution, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94,
Air Pollution-Volatile Organic Compounds, Climate Change-Kyoto
Protocol
Geography--note: crossroads of Western Europe; majority of West
European capitals within 1,000 km of Brussels which is the seat of
both the EU and NATO
Location: Middle America, bordering the Caribbean Sea, between
Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the Caribbean
Area:
total: 22,960 sq km
land: 22,800 sq km
water: 160 sq km
Area--comparative: slightly smaller than Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm in the north, 3 nm in the south; note--from
the mouth of the Sarstoon River to Ranguana Cay, Belize''s
territorial sea is 3 nm; according to Belize''s Maritime Areas Act,
1992, the purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial differences
with Guatemala
Climate: tropical; very hot and humid; rainy season (May to
February)
Terrain: flat, swampy coastal plain; low mountains in south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1,160 m
Natural resources: arable land potential, timber, fish
Land use:
arable land: 2%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 92%
other: 3% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent, devastating hurricanes (September to
December) and coastal flooding (especially in south)
Environment--current issues: deforestation; water pollution from
sewage, industrial effluents, agricultural runoff; Hurricane Mitch
damage
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertication, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Marine Dumping, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: national capital moved 80 km inland from Belize
City to Belmopan because of hurricanes; only country in Central
America without a coastline on the North Pacific Ocean
Location: Western Africa, bordering the North Atlantic Ocean,
between Nigeria and Togo
Geographic coordinates: 9 30 N, 2 15 E
Map references: Africa
Area:
total: 112,620 sq km
land: 110,620 sq km
water: 2,000 sq km
Area--comparative: slightly smaller than Pennsylvania
Land boundaries:
total: 1,989 km
border countries: Burkina Faso 306 km, Niger 266 km, Nigeria 773 km,
Togo 644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid in south; semiarid in north
Terrain: mostly flat to undulating plain; some hills and low
mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Sokbaro 658 m
Natural resources: small offshore oil deposits, limestone,
marble, timber
Land use:
arable land: 13%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 31%
other: 48% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan wind may affect north
in winter
Environment--current issues: recent droughts have severely
affected marginal agriculture in north; inadequate supplies of
potable water; poaching threatens wildlife populations;
deforestation; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: no natural harbors
Location: North America, group of islands in the North Atlantic
Ocean, east of North Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total: 50 sq km
land: 50 sq km
water: 0 sq km
Area--comparative: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: subtropical; mild, humid; gales, strong winds common in
winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone, pleasant climate fostering tourism
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (1997 est.)
note: developed (55%) and rural/open space (39%) comprise 94% of
Bermudian land area
Irrigated land: NA sq km
Natural hazards: hurricanes (June to November)
Environment--current issues: asbestos disposal; water pollution;
preservation of open space
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: consists of about 360 small coral islands with
ample rainfall, but no rivers or freshwater lakes; some land,
reclaimed and otherwise, was leased by US Government from 1941 to
1995
Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area--comparative: about half the size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern plains; cool winters and
hot summers in central valleys; severe winters and cool summers in
Himalayas
Terrain: mostly mountainous with some fertile valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower, gypsum, calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 66%
other: 26% (1993 est.)
Irrigated land: 340 sq km (1993 est.)
Natural hazards: violent storms coming down from the Himalayas
are the source of the country''s name which translates as Land of the
Thunder Dragon; frequent landslides during the rainy season
Environment--current issues: soil erosion; limited access to
potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Nuclear Test Ban
signed, but not ratified: Law of the Sea
Geography--note: landlocked; strategic location between China and
India; controls several key Himalayan mountain passes
Location: Central South America, southwest of Brazil
Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area:
total: 1,098,580 sq km
land: 1,084,390 sq km
water: 14,190 sq km
Area--comparative: slightly less than three times the size of
Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km, Chile 861 km,
Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical to cold and
semiarid
Terrain: rugged Andes Mountains with a highland plateau
(Altiplano), hills, lowland plains of the Amazon Basin
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petroleum, zinc, tungsten,
antimony, silver, iron, lead, gold, timber
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 24%
forests and woodland: 53%
other: 21% (1993 est.)
Irrigated land: 1,750 sq km (1993 est.)
Natural hazards: cold, thin air of high plateau is obstacle to
efficient fuel combustion, as well as to physical activity by those
unaccustomed to it from birth; flooding in the northeast
(March-April)
Environment--current issues: the clearing of land for agricultural
purposes and the international demand for tropical timber are
contributing to deforestation; soil erosion from overgrazing and
poor cultivation methods (including slash-and-burn agriculture);
desertification; loss of biodiversity; industrial pollution of water
supplies used for drinking and irrigation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Climate Change-Kyoto Protocol,
Environmental Modification, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection
Geography--note: landlocked; shares control of Lago Titicaca,
world''s highest navigable lake (elevation 3,805 m), with Peru
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
Area:
total: 11,437 sq km
land: 11,437 sq km
water: 0 sq km
Area--comparative: slightly smaller than Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; humid and sultry in summer
Terrain: mostly flat and barren desert covered with loose sand
and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 103 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1%
permanent crops: NA%
permanent pastures: 5%
forests and woodland: NA%
other: 94% (1993 est.)
Irrigated land: 80 sq km (1993 est.)
Natural hazards: haze, dust storms, sandstorms common
Environment--current issues: limited natural fresh water resources
are increasing dependence on large-scale desalination facilities
Environment--international agreements:
party to: Biodiversity, Climate Change, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: Law of the Sea
Geography--note: strategic location in central Persian Gulf near
major petroleum deposits
Location: Southern Africa, island in the Indian Ocean, east of','05aa983cf803ea6a8fe3e6054a2117b5338de411f943ce99517988a4bf501306','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcfa991218e5923b6ad5fe0e75e0e7f268a708de054f30d4a1425bbca40d9f7c',1999,'HR','Croatia','geography',48,'Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
total: 51,233 sq km
land: 51,233 sq km
water: 0 sq km
Area--comparative: slightly smaller than West Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and Montenegro 527 km (312
km with Serbia, 215 km with Montenegro)
Coastline: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of high elevation
have short, cool summers and long, severe winters; mild, rainy
winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese, forests,
copper, chromium, lead, zinc
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent and destructive earthquakes
Environment--current issues: air pollution from metallurgical
plants; sites for disposing of urban waste are limited; widespread
casualties, water shortages, and destruction of infrastructure
because of the 1992-95 civil strife
Environment--international agreements:
party to: Air Pollution, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: within Bosnia and Herzegovina''s recognized
borders, the country is divided into a joint Muslim/Croat Federation
(about 51% of the territory) and the Bosnian Serb-led Republika
Herzegovina is contiguous to Croatia and traditionally has been
settled by an ethnic Croat majority
Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 4,013 km
border countries: Namibia 1,360 km, South Africa 1,840 km, Zimbabwe
813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
Elevation extremes:
lowest point: junction of the Limpopo and Shashe Rivers 513 m
highest point: Tsodilo Hills 1,489 m
Natural resources: diamonds, copper, nickel, salt, soda ash,
potash, coal, iron ore, silver
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 47%
other: 6% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: periodic droughts; seasonal August winds blow
from the west, carrying sand and dust across the country, which can
obscure visibility
Environment--current issues: overgrazing; desertification; limited
fresh water resources
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: landlocked; population concentrated in eastern
part of the country
Location: Southern Africa, island in the South Atlantic Ocean,
south-southwest of the Cape of Good Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 58 sq km
land: 58 sq km
water: 0 sq km
Area--comparative: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; maximum elevation about 800 m; coast is mostly
inaccessible
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 780 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all ice)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: covered by glacial ice
Location: Eastern South America, bordering the Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references: South America
Area:
total: 8,511,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao
Paulo
Area--comparative: slightly smaller than the US
Land boundaries:
total: 14,691 km
border countries: Argentina 1,224 km, Bolivia 3,400 km, Colombia
1,643 km, French Guiana 673 km, Guyana 1,119 km, Paraguay 1,290 km,
Peru 1,560 km, Suriname 597 km, Uruguay 985 km, Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some plains,
hills, mountains, and narrow coastal belt
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore, manganese, nickel,
phosphates, platinum, tin, uranium, petroleum, hydropower, timber
Land use:
arable land: 5%
permanent crops: 1%
permanent pastures: 22%
forests and woodland: 58%
other: 14% (1993 est.)
Irrigated land: 28,000 sq km (1993 est.)
Natural hazards: recurring droughts in northeast; floods and
occasional frost in south
Environment--current issues: deforestation in Amazon Basin
destroys the habitat and endangers the existence of a multitude of
plant and animal species indigenous to the area; air and water
pollution in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by improper
mining activities
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: largest country in South America; shares common
boundaries with every South American country except Chile and Ecuador
Location: Southern Asia, archipelago in the Indian Ocean, about
one-half the way from Africa to Indonesia
Geographic coordinates: 6 00 S, 71 30 E
Map references: World
Area:
total: 60 sq km
land: 60 sq km
water: 0 sq km
note: includes the entire Chagos Archipelago
Area--comparative: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical marine; hot, humid, moderated by trade winds
Terrain: flat and low (up to four meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 15 m
Natural resources: coconuts, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: NA%
other: NA%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: archipelago of 2,300 islands; Diego Garcia,
largest and southernmost island, occupies strategic location in
central Indian Ocean; island is site of joint US-UK military facility
Location: Caribbean, between the Caribbean Sea and the North
Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the Caribbean
Area:
total: 150 sq km
land: 150 sq km
water: 0 sq km
note: includes the island of Anegada
Area--comparative: about 0.9 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical; humid; temperatures moderated by trade winds
Terrain: coral islands relatively flat; volcanic islands steep,
hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 7%
permanent pastures: 33%
forests and woodland: 7%
other: 33% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms (July to October)
Environment--current issues: limited natural fresh water resources
(except for a few seasonal streams and springs on Tortola, most of
the islands'' water supply comes from wells and rainwater catchment)
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strong ties to nearby US Virgin Islands and','402ad5dc8236f8796dea878a405b375ba264fd9ee97f01705e6643c54270f511','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bfe247b8b8a4d509a492c85bc1868003dc5a2c637bfd7201f7f601ed3248e0a',1999,'PR','Puerto Rico','geography',65,'Location: Southeastern Asia, bordering the South China Sea and
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the Caribbean
Area:
total: 100 sq km
land: 100 sq km
water: 0 sq km
Area--comparative: about 0.6 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; little daily or seasonal temperature variation
Terrain: volcanic islands, mostly mountainous, with small coastal
lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chances Peak 914 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
permanent pastures: 10%
forests and woodland: 40%
other: 30% (1993 est.)
Irrigated land: NA sq km
Natural hazards: severe hurricanes (June to November); volcanic
eruptions (full-scale eruptions of the Soufriere Hills volcano
occurred during 1996-97)
Environment--current issues: land erosion occurs on slopes that
have been cleared for cultivation
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Northern Africa, bordering the North Atlantic Ocean and
the Mediterranean Sea, between Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 2,017.9 km
border countries: Algeria 1,559 km, Western Sahara 443 km, Spain
(Ceuta) 6.3 km, Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: Mediterranean, becoming more extreme in the interior
Terrain: northern coast and interior are mountainous with large
areas of bordering plateaus, intermontane valleys, and rich coastal
plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore, manganese, lead, zinc,
fish, salt
Land use:
arable land: 21%
permanent crops: 1%
permanent pastures: 47%
forests and woodland: 20%
other: 11% (1993 est.)
Irrigated land: 12,580 sq km (1993 est.)
Natural hazards: northern mountains geologically unstable and
subject to earthquakes; periodic droughts
Environment--current issues: land degradation/desertification
(soil erosion resulting from farming of marginal areas, overgrazing,
destruction of vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal waters
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification, Law of the Sea
Geography--note: strategic location along Strait of Gibraltar
Location: Southern Africa, bordering the Mozambique Channel,
between South Africa and Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area--comparative: slightly less than twice the size of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South Africa 491 km, Swaziland
105 km, Tanzania 756 km, Zambia 419 km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center, high
plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 18%
other: 22% (1993 est.)
Irrigated land: 1,180 sq km (1993 est.)
Natural hazards: severe droughts and floods occur in central and
southern provinces; devastating cyclones
Environment--current issues: a long civil war and recurrent
drought in the hinterlands have resulted in increased migration of
the population to urban and coastal areas with adverse environmental
consequences; desertification; pollution of surface and coastal
waters
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Location: Southern Africa, bordering the South Atlantic Ocean,
between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total: 825,418 sq km
land: 825,418 sq km
water: 0 sq km
Area--comparative: slightly more than half the size of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1,376 km, Botswana 1,360 km, South Africa
855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium, gold, lead, tin,
lithium, cadmium, zinc, salt, vanadium, natural gas, fish; suspected
deposits of oil, natural gas, coal, iron ore
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 22%
other: 31% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: prolonged periods of drought
Environment--current issues: very limited natural fresh water
resources; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected agreements
Location: Oceania, island in the South Pacific Ocean, south of
the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area--comparative: about 0.1 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; monsoonal; rainy season (November to February)
Terrain: sandy beach rises to fertile ring around raised coral
reefs with phosphate plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim 61 m
Natural resources: phosphates
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: periodic droughts
Environment--current issues: limited natural fresh water
resources, roof storage tanks collect rainwater; intensive phosphate
mining during the past 90 years--mainly by a UK, Australia, and New
Zealand consortium--has left the central 90% of Nauru a wasteland and
threatens limited remaining land resources
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Marine Dumping
signed, but not ratified: none of the selected agreements
Geography--note: Nauru is one of the three great phosphate rock
islands in the Pacific Ocean--the others are Banaba (Ocean Island) in
Kiribati and Makatea in French Polynesia; only 53 km south of Equator
Location: Caribbean, island in the Caribbean Sea, about
one-fourth of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the Caribbean
Area:
total: 5.2 sq km
land: 5.2 sq km
water: 0 sq km
Area--comparative: about nine times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to undulating;
ringed by vertical white cliffs (9 to 15 meters high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side 77 m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 10%
forests and woodland: 0%
other: 90%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strategic location 160 km south of the US Naval
Base at Guantanamo Bay, Cuba; mostly exposed rock, but enough
grassland to support goat herds; dense stands of fig-like trees,
scattered cactus
Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
Area--comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1,236 km, India 1,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe winters in north to
subtropical summers and mild winters in south
Terrain: Terai or flat river plain of the Ganges in south,
central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,848 m
Natural resources: quartz, water, timber, hydropower potential,
scenic beauty, small deposits of lignite, copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
permanent pastures: 15%
forests and woodland: 42%
other: 26% (1993 est.)
Irrigated land: 8,500 sq km (1993 est.)
Natural hazards: severe thunderstorms, flooding, landslides,
drought, and famine depending on the timing, intensity, and duration
of the summer monsoons
Environment--current issues: the almost total dependence on wood
for fuel and cutting down trees to expand agricultural land without
replanting has resulted in widespread deforestation; soil erosion;
water pollution (use of contaminated water presents human health
risks)
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life Conservation
Geography--note: landlocked; strategic location between China and
India; contains eight of world''s 10 highest peaks
Location: Western Europe, bordering the North Sea, between
Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41,532 sq km
land: 33,889 sq km
water: 7,643 sq km
Area--comparative: slightly less than twice the size of New Jersey
Land boundaries:
total: 1,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; marine; cool summers and mild winters
Terrain: mostly coastal lowland and reclaimed land (polders);
some hills in southeast
Elevation extremes:
lowest point: Prins Alexanderpolder -7 m
highest point: Vaalserberg 321 m
Natural resources: natural gas, petroleum, fertile soil
Land use:
arable land: 25%
permanent crops: 3%
permanent pastures: 25%
forests and woodland: 8%
other: 39% (1996 est.)
Irrigated land: 6,000 sq km (1996 est.)
Natural hazards: the extensive system of dikes and dams protects
nearly one-half of the total area from being flooded
Environment--current issues: water pollution in the form of heavy
metals, organic compounds, and nutrients such as nitrates and
phosphates; air pollution from vehicles and refining activities;
acid rain
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change-Kyoto Protocol
Geography--note: located at mouths of three major European rivers
(Rhine, Maas or Meuse, and Schelde)
Location: Caribbean, two island groups in the Caribbean Sea--one
includes Curacao and Bonaire north of Venezuela and the other is
east of the Virgin Islands
Geographic coordinates: 12 15 N, 68 45 W
Map references: Central America and the Caribbean
Area:
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint Eustatius, and Sint
Maarten (Dutch part of the island of Saint Martin)
Area--comparative: more than five times the size of Washington, DC
Land boundaries:
total: 10.2 km
border countries: Guadeloupe (Saint Martin) 10.2 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
Climate: tropical; ameliorated by northeast trade winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao only), salt (Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 90% (1993 est.)
Irrigated land: NA sq km
Natural hazards: Curacao and Bonaire are south of Caribbean
hurricane belt and are rarely threatened; Sint Maarten, Saba, and
Sint Eustatius are subject to hurricanes from July to October
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Oceania, islands in the South Pacific Ocean, east of
Location: Southern South America, bordering the South Atlantic
Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area--comparative: slightly smaller than the state of Washington
Land boundaries:
total: 1,564 km
border countries: Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 200 nm; overflight and navigation guaranteed beyond
12 nm
Climate: warm temperate; freezing temperatures almost unknown
Terrain: mostly rolling plains and low hills; fertile coastal
lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: fertile soil, hydropower, minor minerals,
fisheries
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 77%
forests and woodland: 6%
other: 10% (1997 est.)
Irrigated land: 7,700 sq km (1997 est.)
Natural hazards: seasonally high winds (the pampero is a chilly
and occasional violent wind which blows north from the Argentine
pampas), droughts, floods; because of the absence of mountains,
which act as weather barriers, all locations are particularly
vulnerable to rapid changes in weather fronts
Environment--current issues: working with Brazil to monitor and
minimize transboundary pollution caused by Brazilian power plant
near border; water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine
Dumping, Marine Life Conservation','a0421f5f1c5494b07fbf0ca6f3890a6991fcb5f49e039f7666cff3c1a24f3db9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bc15d0d2d956a005016adb4474f54c00e521559285b1c64cc6de7280d48e873',1999,'MY','Malaysia','geography',66,'Geographic coordinates: 4 30 N, 114 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
Area--comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
exclusive economic zone: 200 nm or to median line
territorial sea: 12 nm
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east; hilly
lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 85%
other: 12% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: typhoons, earthquakes, and severe flooding are
very rare
Environment--current issues: seasonal smoke/haze resulting from
forest fires in Indonesia
Environment--international agreements:
party to: Endangered Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: close to vital sea lanes through South China Sea
linking Indian and Pacific Oceans; two parts physically separated by
Malaysia; almost an enclave of Malaysia
Location: Southeastern Europe, bordering the Black Sea, between
Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
total: 110,910 sq km
land: 110,550 sq km
water: 360 sq km
Area--comparative: slightly larger than Tennessee
Land boundaries:
total: 1,808 km
border countries: Greece 494 km, The Former Yugoslav Republic of
Macedonia 148 km, Romania 608 km, Serbia and Montenegro 318 km (all
with Serbia), Turkey 240 km
Coastline: 354 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; cold, damp winters; hot, dry summers
Terrain: mostly mountains with lowlands in north and southeast
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc, coal, timber,
arable land
Land use:
arable land: 37%
permanent crops: 2%
permanent pastures: 16%
forests and woodland: 35%
other: 10% (1993 est.)
Irrigated land: 12,370 sq km (1993 est.)
Natural hazards: earthquakes, landslides
Environment--current issues: air pollution from industrial
emissions; rivers polluted from raw sewage, heavy metals,
detergents; deforestation; forest damage from air pollution and
resulting acid rain; soil contamination from heavy metals from
metallurgical plants and industrial wastes
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Climate Change-Kyoto Protocol
Geography--note: strategic location near Turkish Straits; controls
key land routes from Europe to Middle East and Asia
Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area--comparative: slightly larger than Colorado
Land boundaries:
total: 3,192 km
border countries: Benin 306 km, Ghana 548 km, Cote d''Ivoire 584 km,
Mali 1,000 km, Niger 628 km, Togo 126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet summers
Terrain: mostly flat to dissected, undulating plains; hills in
west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone, marble; small deposits
of gold, antimony, copper, nickel, bauxite, lead, phosphates, zinc,
silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 50%
other: 15% (1993 est.)
Irrigated land: 200 sq km (1993 est.)
Natural hazards: recurring droughts
Environment--current issues: recent droughts and desertification
severely affecting agricultural activities, population distribution,
and the economy; overgrazing; soil degradation; deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Marine Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Geography--note: landlocked
Location: Southeastern Asia, bordering the Andaman Sea and the
Bay of Bengal, between Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km, China 2,185 km, India 1,463 km,
Laos 235 km, Thailand 1,800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; cloudy, rainy, hot, humid summers
(southwest monsoon, June to September); less cloudy, scant rainfall,
mild temperatures, lower humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony, zinc,
copper, tungsten, lead, coal, some marble, limestone, precious
stones, natural gas
Land use:
arable land: 15%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 49%
other: 34% (1993 est.)
Irrigated land: 10,680 sq km (1993 est.)
Natural hazards: destructive earthquakes and cyclones; flooding
and landslides common during rainy season (June to September);
periodic droughts
Environment--current issues: deforestation; industrial pollution
of air, soil, and water; inadequate sanitation and water treatment
contribute to disease
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Geography--note: strategic location near major Indian Ocean
shipping lanes
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo 233 km, Rwanda
290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable altitude
variation (772 m to 2,760 m); average annual temperature varies with
altitude from 23 to 17 degrees centigrade but is generally moderate
as the average altitude is about 1,700 m; average annual rainfall is
about 150 cm; wet seasons from February to May and September to
November, and dry seasons from June to August and December to January
Terrain: hilly and mountainous, dropping to a plateau in east,
some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,670 m
Natural resources: nickel, uranium, rare earth oxides, peat,
cobalt, copper, platinum (not yet exploited), vanadium
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
other: 8% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides
Environment--current issues: soil erosion as a result of
overgrazing and the expansion of agriculture into marginal lands;
deforestation (little forested land remains because of uncontrolled
cutting of trees for fuel); habitat loss threatens wildlife
populations
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Geography--note: landlocked; straddles crest of the Nile-Congo
watershed
Location: Southeastern Asia, bordering the Gulf of Thailand,
between Thailand, Vietnam, and Laos
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area--comparative: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, monsoon season (May to November); dry
season (December to April); little seasonal temperature variation
Terrain: mostly low, flat plains; mountains in southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: timber, gemstones, some iron ore, manganese,
phosphates, hydropower potential
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 11%
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 920 sq km (1993 est.)
Natural hazards: monsoonal rains (June to November); flooding;
occasional droughts
Environment--current issues: illegal logging activities throughout
the country and strip mining for gems in the western region along
the border with Thailand are resulting in habitat loss and declining
biodiversity (in particular, destruction of mangrove swamps
threatens natural fisheries); soil erosion; in rural areas, a
majority of the population does not have access to potable water;
toxic waste delivery from Taiwan sparked unrest in Kampong Saom
(Sihanoukville) in December 1998
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Marine Life Conservation, Ship Pollution, Tropical Timber 94
signed, but not ratified: Law of the Sea, Marine Dumping
Geography--note: a land of paddies and forests dominated by the
Mekong River and Tonle Sap
Location: Western Africa, bordering the Bight of Biafra, between
Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 4,591 km
border countries: Central African Republic 797 km, Chad 1,094 km,
Republic of the Congo 523 km, Equatorial Guinea 189 km, Gabon 298
km, Nigeria 1,690 km
Coastline: 402 km
Maritime claims:
territorial sea: 50 nm
Climate: varies with terrain, from tropical along coast to
semiarid and hot in north
Terrain: diverse, with coastal plain in southwest, dissected
plateau in center, mountains in west, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore, timber,
hydropower
Land use:
arable land: 13%
permanent crops: 2%
permanent pastures: 4%
forests and woodland: 78%
other: 3% (1993 est.)
Irrigated land: 210 sq km (1993 est.)
Natural hazards: recent volcanic activity with release of
poisonous gases
Environment--current issues: water-borne diseases are prevalent;
deforestation; overgrazing; desertification; poaching; overfishing
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Nuclear Test Ban
Geography--note: sometimes referred to as the hinge of Africa
Location: Northern North America, bordering the North Atlantic
Ocean and North Pacific Ocean, north of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
total: 9,976,140 sq km
land: 9,220,970 sq km
water: 755,170 sq km
Area--comparative: slightly larger than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km with Alaska)
Coastline: 243,791 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: varies from temperate in south to subarctic and arctic
in north
Terrain: mostly plains with mountains in west and lowlands in
southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,950 m
Natural resources: nickel, zinc, copper, gold, lead, molybdenum,
potash, silver, fish, timber, wildlife, coal, petroleum, natural gas
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 38% (1993 est.)
Irrigated land: 7,100 sq km (1993 est.)
Natural hazards: continuous permafrost in north is a serious
obstacle to development; cyclonic storms form east of the Rocky
Mountains, a result of the mixing of air masses from the Arctic,
Pacific, and North American interior, and produce most of the
country''s rain and snow
Environment--current issues: air pollution and resulting acid rain
severely affecting lakes and damaging forests; metal smelting,
coal-burning utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters becoming
contaminated due to agricultural, industrial, mining, and forestry
activities
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85,
Air Pollution-Sulphur 94, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Climate Change-Kyoto Protocol, Law
of the Sea, Marine Life Conservation
Geography--note: second-largest country in world (after Russia);
strategic location between Russia and US via north polar route;
nearly 90% of the population is concentrated within 160 km of the
US/Canada border
Location: Western Africa, group of islands in the North Atlantic
Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: World
Area:
total: 4,030 sq km
land: 4,030 sq km
water: 0 sq km
Area--comparative: slightly larger than Rhode Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; warm, dry summer; precipitation meager and
very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo Island)
Natural resources: salt, basalt rock, pozzuolana (a siliceous
volcanic ash used to produce hydraulic cement), limestone, kaolin,
fish
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 0%
other: 83% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: prolonged droughts; harmattan wind can obscure
visibility; volcanically and seismically active
Environment--current issues: overgrazing of livestock and improper
land use such as the cultivation of crops on steep slopes has led to
soil erosion; demand for wood used as fuel has resulted in
deforestation; desertification; environmental damage has threatened
several species of birds and reptiles; overfishing
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Law of the Sea, Marine Dumping, Nuclear
Test Ban
signed, but not ratified: none of the selected agreements
Geography--note: strategic location 500 km from west coast of
Africa near major north-south sea routes; important communications
station; important sea and air refueling site
Location: Caribbean, island group in Caribbean Sea, nearly
one-half of the way from Cuba to Honduras
Geographic coordinates: 19 30 N, 80 30 W
Map references: Central America and the Caribbean
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area--comparative: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; warm, rainy summers (May to October)
and cool, relatively dry winters (November to April)
Terrain: low-lying limestone base surrounded by coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that foster tourism
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 23%
other: 69% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes (July to November)
Environment--current issues: no natural fresh water resources;
drinking water supplies must be met by rainwater catchment
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: important location between Cuba and Central
America
Location: Central Africa, north of Democratic Republic of the
Location: Southeastern Asia, group of small islands and reefs in
the South China Sea, about one-third of the way from central Vietnam
to the northern Philippines
Geographic coordinates: 16 30 N, 112 00 E
Map references: Southeast Asia
Area:
total: NA sq km
land: NA sq km
water: 0 sq km
Area--comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: typhoons
Environment--current issues: NA
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Location: Central South America, northeast of Argentina
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area--comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1,880 km, Bolivia 750 km, Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical; substantial rainfall in the eastern
portions, becoming semiarid in the far west
Terrain: grassy plains and wooded hills east of Rio Paraguay;
Gran Chaco region west of Rio Paraguay mostly low, marshy plain near
the river, and dry forest and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana 46 m
highest point: Cerro San Rafael 850 m
Natural resources: hydropower, timber, iron ore, manganese,
limestone
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 55%
forests and woodland: 32%
other: 7% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: local flooding in southeast (early September to
June); poorly drained plains may become boggy (early October to June)
Environment--current issues: deforestation (an estimated 2 million
hectares of forest land have been lost from 1958-85); water
pollution; inadequate means for waste disposal present health risks
for many urban residents
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Geography--note: landlocked; lies between Argentina, Bolivia, and','a82ef1e789d65ce25043d9f64dba860267074386755bcd077a92d980ec174c80','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e02e86bff4dec791fbac254d375e603856619f5757dbde6b8c11b3ebf13b82',1999,'CG','Congo','geography',77,'Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,980 sq km
land: 622,980 sq km
water: 0 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1,197 km, Democratic
Republic of the Congo 1,577 km, Republic of the Congo 467 km, Sudan
1,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet summers
Terrain: vast, flat to rolling, monotonous plateau; scattered
hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1,420 m
Natural resources: diamonds, uranium, timber, gold, oil
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds affect northern
areas; floods are common
Environment--current issues: tap water is not potable; poaching
has diminished its reputation as one of the last great wildlife
refuges; desertification; deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography--note: landlocked; almost the precise center of Africa
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
Area--comparative: slightly more than three times the size of
California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central African Republic 1,197
km, Libya 1,055 km, Niger 1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north, mountains
in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but exploration under
way), uranium, natron, kaolin, fish (Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds occur in north;
periodic droughts; locust plagues
Environment--current issues: inadequate supplies of potable water;
improper waste disposal in rural areas contributes to soil and water
pollution; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
Geography--note: landlocked; Lake Chad is the most significant
water body in the Sahel
Location: Southern South America, bordering the South Atlantic
Ocean and South Pacific Ocean, between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla Sala y Gomez
Area--comparative: slightly smaller than twice the size of Montana
Land boundaries:
total: 6,171 km
border countries: Argentina 5,150 km, Bolivia 861 km, Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; desert in north; cool and damp in south
Terrain: low coastal mountains; fertile central valley; rugged
Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: copper, timber, iron ore, nitrates, precious
metals, molybdenum
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 18%
forests and woodland: 22%
other: 55% (1993 est.)
Irrigated land: 12,650 sq km (1993 est.)
Natural hazards: severe earthquakes; active volcanism; tsunamis
Environment--current issues: air pollution from industrial and
vehicle emissions; water pollution from raw sewage; deforestation
contributing to loss of biodiversity; soil erosion; desertification
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: strategic location relative to sea lanes between
Atlantic and Pacific Oceans (Strait of Magellan, Beagle Channel,
Drake Passage); Atacama Desert is one of world''s driest regions
Location: Eastern Asia, bordering the East China Sea, Korea Bay,
Yellow Sea, and South China Sea, between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
Area--comparative: slightly smaller than the US
Land boundaries:
total: 22,143.34 km
border countries: Afghanistan 76 km, Bhutan 470 km, Burma 2,185 km,
Hong Kong 30 km, India 3,380 km, Kazakhstan 1,533 km, North Korea
1,416 km, Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km, Mongolia
4,673 km, Nepal 1,236 km, Pakistan 523 km, Russia (northeast) 3,605
km, Russia (northwest) 40 km, Tajikistan 414 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
territorial sea: 12 nm
Climate: extremely diverse; tropical in south to subarctic in
north
Terrain: mostly mountains, high plateaus, deserts in west;
plains, deltas, and hills in east
Elevation extremes:
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,848 m
Natural resources: coal, iron ore, petroleum, natural gas,
mercury, tin, tungsten, antimony, manganese, molybdenum, vanadium,
magnetite, aluminum, lead, zinc, uranium, hydropower potential
(world''s largest)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 43%
forests and woodland: 14%
other: 33% (1993 est.)
Irrigated land: 498,720 sq km (1993 est.)
Natural hazards: frequent typhoons (about five per year along
southern and eastern coasts); damaging floods; tsunamis;
earthquakes; droughts
Environment--current issues: air pollution (greenhouse gases,
sulfur dioxide particulates) from reliance on coal, produces acid
rain; water shortages, particularly in the north; water pollution
from untreated wastes; deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and economic
development; desertification; trade in endangered species
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Geography--note: world''s fourth-largest country (after Russia,
Canada, and US)
Location: islands in the South Atlantic Ocean, about mid-way
between South America and Africa
Geographic coordinates: 15 56 S, 5 42 W
Map references: Africa
Area:
total: 410 sq km
land: 410 sq km
water: 0 sq km
note: includes Ascension, Gough Island, Inaccessible Island,
Nightingale Island, and Tristan da Cunha Island
Area--comparative: slightly more than two times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 60 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: Saint Helena--tropical; marine; mild, tempered by trade
winds; Tristan da Cunha--temperate; marine, mild, tempered by trade
winds (tends to be cooler than Saint Helena)
Terrain: Saint Helena--rugged, volcanic; small scattered plateaus
and plains
note: the other islands of the group have a volcanic origin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da Cunha 2,060 m
Natural resources: fish
Land use:
arable land: 6%
permanent crops: NA%
permanent pastures: 6%
forests and woodland: 6%
other: 82% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism on Tristan da Cunha
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: Napoleon Bonaparte''s place of exile and burial
(his remains were taken to Paris in 1840); harbors at least 40
species of plants unknown anywhere else in the world; Ascension is a
breeding ground for sea turtles and sooty terns
Location: Caribbean, islands in the Caribbean Sea, about
one-third of the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the Caribbean
Area:
total: 269 sq km
land: 269 sq km
water: 0 sq km
Area--comparative: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: subtropical tempered by constant sea breezes; little
seasonal temperature variation; rainy season (May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: NEGL
Land use:
arable land: 22%
permanent crops: 17%
permanent pastures: 3%
forests and woodland: 17%
other: 41% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes (July to October)
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected agreements
Location: Caribbean, island between the Caribbean Sea and North
Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 13 53 N, 60 68 W
Map references: Central America and the Caribbean
Area:
total: 620 sq km
land: 610 sq km
water: 10 sq km
Area--comparative: 3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims: 200 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, moderated by northeast trade winds; dry season
from January to April, rainy season from May to August
Terrain: volcanic and mountainous with some broad, fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches, minerals (pumice),
mineral springs, geothermal potential
Land use:
arable land: 8%
permanent crops: 21%
permanent pastures: 5%
forests and woodland: 13%
other: 53% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes and volcanic activity
Environment--current issues: deforestation; soil erosion,
particularly in the northern region
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Northern North America, islands in the North Atlantic
Ocean, south of Newfoundland (Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre and the
Miquelon groups
Area--comparative: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: cold and wet, with much mist and fog; spring and autumn
are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: 4%
other: 83% (1993 est.)
Irrigated land: NA sq km
Natural hazards: persistent fog throughout the year can be a
maritime hazard
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: vegetation scanty
Location: Eastern Europe, bordering the Black Sea, between Poland
and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent States
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km, Moldova 939 km,
Poland 428 km, Romania (south) 169 km, Romania (west) 362 km, Russia
1,576 km, Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate continental; Mediterranean only on the
southern Crimean coast; precipitation disproportionately
distributed, highest in west and north, lesser in east and
southeast; winters vary from cool along the Black Sea to cold
farther inland; summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese, natural gas, oil,
salt, sulfur, graphite, titanium, magnesium, kaolin, nickel,
mercury, timber
Land use:
arable land: 58%
permanent crops: 2%
permanent pastures: 13%
forests and woodland: 18%
other: 9% (1993 est.)
Irrigated land: 26,050 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: inadequate supplies of potable water;
air and water pollution; deforestation; radiation contamination in
the northeast from 1986 accident at Chornobyl'' Nuclear Power Plant
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Marine Dumping, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Law of the Sea
Geography--note: strategic position at the crossroads between
Europe and Asia; second-largest country in Europe
Location: Middle East, bordering the Gulf of Oman and the Persian
Gulf, between Oman and Saudi Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area--comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 410 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling sand
dunes of vast desert wasteland; mountains in east
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 2%
forests and woodland: 0%
other: 98% (1993 est.)
Irrigated land: 50 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment--current issues: lack of natural freshwater resources
being overcome by desalination plants; desertification; beach
pollution from oil spills
Environment--international agreements:
party to: Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer Protection
signed, but not ratified: Biodiversity, Law of the Sea
Geography--note: strategic location along southern approaches to
Strait of Hormuz, a vital transit point for world crude oil
Location: Western Europe, islands including the northern
one-sixth of the island of Ireland between the North Atlantic Ocean
and the North Sea, northwest of France
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
land: 241,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
Area--comparative: slightly smaller than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
continental shelf: as defined in continental shelf orders or in
accordance with agreed upon boundaries
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by prevailing southwest winds over
the North Atlantic Current; more than one-half of the days are
overcast
Terrain: mostly rugged hills and low mountains; level to rolling
plains in east and southeast
Elevation extremes:
lowest point: Fenland -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, natural gas, tin, limestone,
iron ore, salt, clay, chalk, gypsum, lead, silica
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 10%
other: 19% (1993 est.)
Irrigated land: 1,080 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: sulfur dioxide emissions from power
plants contribute to air pollution; some rivers polluted by
agricultural wastes; and coastal waters polluted because of
large-scale disposal of sewage at sea
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: lies near vital North Atlantic sea lanes; only 35
km from France and now linked by tunnel under the English Channel;
because of heavily indented coastline, no location is more than 125
km from tidal waters','1f105bd1976a007d4a290fa2be6aa2140179eac29011a19d60600e68ec081b2f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1938f344d7110c12d2db89b856d9aeed7306793b55e07e4f263859c2d88c6dda',1999,'ID','Indonesia','geography',93,'Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
total: 135 sq km
land: 135 sq km
water: 0 sq km
Area--comparative: about 0.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims:
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; heat and humidity moderated by trade winds
Terrain: steep cliffs along coast rise abruptly to central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: the narrow fringing reef surrounding the island
can be a maritime hazard
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: located along major sea lanes of Indian Ocean
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 647.5 sq km
land: 637.5 sq km
water: 10 sq km
Area--comparative: slightly more than 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive fishing zone: within and beyond territorial sea, as
defined in treaties and practice
territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no pronounced rainy or dry
seasons; thunderstorms occur on 40% of all days (67% of days in
April)
Terrain: lowland; gently undulating central plateau contains
water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish, deepwater ports
Land use:
arable land: 2%
permanent crops: 6%
permanent pastures: NA%
forests and woodland: 5%
other: 87% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: industrial pollution; limited natural
fresh water resources; limited land availability presents waste
disposal problems; seasonal smoke/haze resulting from forest fires
in Indonesia
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: focal point for Southeast Asian sea routes
Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area--comparative: about twice the size of New Hampshire
Land boundaries:
total: 1,355 km
border countries: Austria 91 km, Czech Republic 215 km, Hungary 515
km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy, humid winters
Terrain: rugged mountains in the central and northern part and
lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovka 2,655 m
Natural resources: brown coal and lignite; small amounts of iron
ore, copper and manganese ore; salt
Land use:
arable land: 31%
permanent crops: 3%
permanent pastures: 17%
forests and woodland: 41%
other: 8% (1993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: air pollution from metallurgical
plants presents human health risks; acid rain damaging forests
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Geography--note: landlocked
Location: Southeastern Europe, eastern Alps bordering the
Adriatic Sea, between Austria and Croatia
Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total: 20,256 sq km
land: 20,256 sq km
water: 0 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries:
total: 1,334 km
border countries: Austria 330 km, Croatia 670 km, Italy 232 km,
Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast, continental climate
with mild to hot summers and cold winters in the plateaus and
valleys to the east
Terrain: a short coastal strip on the Adriatic, an alpine
mountain region adjacent to Italy and Austria, mixed mountain and
valleys with numerous rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc, mercury, uranium,
silver
Land use:
arable land: 12%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 54%
other: 7% (1996 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: flooding and earthquakes
Environment--current issues: Sava River polluted with domestic and
industrial waste; pollution of coastal waters with heavy metals and
toxic chemicals; forest damage near Koper from air pollution
(originating at metallurgical and chemical plants) and resulting
acid rain
Environment--international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94, Biodiversity,
Climate Change, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Location: Oceania, group of islands in the South Pacific Ocean,
east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area:
total: 28,450 sq km
land: 27,540 sq km
water: 910 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; few extremes of temperature and weather
Terrain: mostly rugged mountains with some low coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite, phosphates,
lead, zinc, nickel
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 88%
other: 9% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons, but they are rarely destructive;
geologically active region with frequent earth tremors; volcanic
activity
Environment--current issues: deforestation; soil erosion; much of
the surrounding coral reefs are dead or dying
Environment--international agreements:
party to: Biodiversity, Climate Change, Environmental Modification,
Law of the Sea, Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Eastern Africa, bordering the Gulf of Aden and the
Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area:
total: 637,660 sq km
land: 627,340 sq km
water: 10,320 sq km
Area--comparative: slightly smaller than Texas
Land boundaries:
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1,626 km, Kenya 682 km
Coastline: 3,025 km
Maritime claims:
territorial sea: 200 nm
Climate: principally desert; December to February--northeast
monsoon, moderate temperatures in north and very hot in south; May
to October--southwest monsoon, torrid in the north and hot in the
south, irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to hills in
north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely unexploited reserves of
iron ore, tin, gypsum, bauxite, copper, salt
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 69%
forests and woodland: 26%
other: 3% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: recurring droughts; frequent dust storms over
eastern plains in summer
Environment--current issues: famine; use of contaminated water
contributes to human health problems; deforestation; overgrazing;
soil erosion; desertification
Environment--international agreements:
party to: Endangered Species, Law of the Sea
signed, but not ratified: Marine Dumping, Nuclear Test Ban
Geography--note: strategic location on Horn of Africa along
southern approaches to Bab el Mandeb and route through Red Sea and
Suez Canal
Location: Southern Africa, at the southern tip of the continent
of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island and Prince
Edward Island)
Area--comparative: slightly less than twice the size of Texas
Land boundaries:
total: 4,750 km
border countries: Botswana 1,840 km, Lesotho 909 km, Mozambique 491
km, Namibia 855 km, Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly semiarid; subtropical along east coast; sunny
days, cool nights
Terrain: vast interior plateau rimmed by rugged hills and narrow
coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal, iron ore,
manganese, nickel, phosphates, tin, uranium, gem diamonds, platinum,
copper, vanadium, salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 67%
forests and woodland: 7%
other: 15% (1993 est.)
Irrigated land: 12,700 sq km (1993 est.)
Natural hazards: prolonged droughts
Environment--current issues: lack of important arterial rivers or
lakes requires extensive water conservation and control measures;
growth in water usage threatens to outpace supply; pollution of
rivers from agricultural runoff and urban discharge; air pollution
resulting in acid rain; soil erosion; desertification
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: South Africa completely surrounds Lesotho and
almost completely surrounds Swaziland
Location: Southern South America, islands in the South Atlantic
Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 4,066 sq km
land: 4,066 sq km
water: 0 sq km
note: includes Shag Rocks, Clerke Rocks, Bird Island
Area--comparative: slightly larger than Rhode Island
Land boundaries: 0 km
Coastline: NA km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: variable, with mostly westerly winds throughout the year
interspersed with periods of calm; nearly all precipitation falls as
snow
Terrain: most of the islands, rising steeply from the sea, are
rugged and mountainous; South Georgia is largely barren and has
steep, glacier-covered mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget 2,915 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (largely covered by permanent ice and snow with some
sparse vegetation consisting of grass, moss, and lichen)
Irrigated land: 0 sq km (1993)
Natural hazards: the South Sandwich Islands have prevailing
weather conditions that generally make them difficult to approach by
ship; they are also subject to active volcanism
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: the north coast of South Georgia has several
large bays, which provide good anchorage; reindeer, introduced early
in this century, live on South Georgia
Location: Southwestern Europe, bordering the Bay of Biscay,
Mediterranean Sea, North Atlantic Ocean, and Pyrenees Mountains,
southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total: 504,750 sq km
land: 499,400 sq km
water: 5,350 sq km
note: includes Balearic Islands, Canary Islands, and five places of
sovereignty (plazas de soberania) on and off the coast of
Morocco--Ceuta, Melilla, Islas Chafarinas, Penon de Alhucemas, and
Penon de Velez de la Gomera
Area--comparative: slightly more than twice the size of Oregon
Land boundaries:
total: 1,919.1 km
border countries: Andorra 65 km, France 623 km, Gibraltar 1.2 km,
Portugal 1,214 km, Morocco (Ceuta) 6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
exclusive economic zone: 200 nm (applies only to the Atlantic Ocean)
territorial sea: 12 nm
Climate: temperate; clear, hot summers in interior, more moderate
and cloudy along coast; cloudy, cold winters in interior, partly
cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded by rugged
hills; Pyrenees in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary Islands 3,718 m
Natural resources: coal, lignite, iron ore, uranium, mercury,
pyrites, fluorspar, gypsum, zinc, lead, tungsten, copper, kaolin,
potash, hydropower
Land use:
arable land: 30%
permanent crops: 9%
permanent pastures: 21%
forests and woodland: 32%
other: 8% (1993 est.)
Irrigated land: 34,530 sq km (1993 est.)
Natural hazards: periodic droughts
Environment--current issues: pollution of the Mediterranean Sea
from raw sewage and effluents from the offshore production of oil
and gas; water quality and quantity nationwide; air pollution;
deforestation; desertification
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Desertification
Geography--note: strategic location along approaches to Strait of','2ee9cd661df39472224a02c4bf2572e00e1681e8e9b7805d4a0938a189007ae7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4c0a2b10e221df58cb9d24325ebdfc8c59bedfd04dedba90b80cf671cbe38e',1999,'AU','Australia','geography',113,'Location: Middle America, atoll in the North Pacific Ocean, 1,120
km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references: World
Area:
total: 7 sq km
land: 7 sq km
water: 0 sq km
Area--comparative: about 12 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims:
territorial sea: 12 nm
Climate: tropical, humid, average temperature 20-32 degrees C,
rains May-October
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all coral)
Irrigated land: 0 sq km (1993)
Natural hazards: subject to tornadoes
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: reef about 8 km in circumference
Location: Southeastern Asia, group of islands in the Indian
Ocean, south of Indonesia, about one-half of the way from Australia
to Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
total: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and Home Island
Area--comparative: about 24 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: pleasant, modified by the southeast trade wind for about
nine months of the year; moderate rainfall
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones may occur in the early months of the
year
Environment--current issues: fresh water resources are limited to
rainwater accumulations in natural underground reservoirs
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: two coral atolls thickly covered with coconut
palms and other vegetation
Location: Northern South America, bordering the Caribbean Sea,
between Panama and Venezuela, and bordering the North Pacific Ocean,
between Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America, Central America and the Caribbean
Area:
total: 1,138,910 sq km
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay, Serrana Bank, and
Serranilla Bank
Area--comparative: slightly less than three times the size of
Montana
Land boundaries:
total: 7,408 km
border countries: Brazil 1,643 km, Ecuador 590 km, Panama 225 km,
Peru 2,900 km, Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760 km, North Pacific Ocean
1,448 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast and eastern plains; cooler in
highlands
Terrain: flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado del Huila 5,750 m
Natural resources: petroleum, natural gas, coal, iron ore,
nickel, gold, copper, emeralds
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 48%
other: 8% (1993 est.)
Irrigated land: 5,300 sq km (1993 est.)
Natural hazards: highlands subject to volcanic eruptions;
occasional earthquakes; periodic droughts
Environment--current issues: deforestation; soil damage from
overuse of pesticides; air pollution, especially in Bogota, from
vehicle emissions
Environment--international agreements:
party to: Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Antarctic-Environmental Protocol,
Desertification, Law of the Sea, Marine Dumping
Geography--note: only South American country with coastlines on
both North Pacific Ocean and Caribbean Sea
Location: Southern Africa, group of islands in the Mozambique
Channel, about two-thirds of the way between northern Madagascar and
northern Mozambique
Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total: 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Area--comparative: slightly more than 12 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; rainy season (November to May)
Terrain: volcanic islands, interiors vary from steep mountains to
low hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Natural resources: NEGL
Land use:
arable land: 35%
permanent crops: 10%
permanent pastures: 7%
forests and woodland: 18%
other: 30% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones possible during rainy season (December
to April); Le Kartala on Grand Comore is an active volcano
Environment--current issues: soil degradation and erosion results
from crop cultivation on slopes without proper terracing;
deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: important location at northern end of Mozambique
Channel
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs scattered over a sea
area of about 1 million sq km, with the Willis Islets the most
important
Area--comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0 sq km (1993)
Natural hazards: occasional, tropical cyclones
Environment--current issues: no permanent fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: important nesting area for birds and turtles
Location: Middle America, bordering both the Caribbean Sea and
the North Pacific Ocean, between Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the Caribbean
Area:
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area--comparative: slightly smaller than West Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; dry season (December to April); rainy season
(May to November)
Terrain: coastal plains separated by rugged mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 46%
forests and woodland: 31%
other: 12% (1993 est.)
Irrigated land: 1,200 sq km (1993 est.)
Natural hazards: occasional earthquakes, hurricanes along
Atlantic coast; frequent flooding of lowlands at onset of rainy
season; active volcanoes
Environment--current issues: deforestation, largely a result of
the clearing of land for cattle ranching; soil erosion
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Location: Western Africa, bordering the North Atlantic Ocean,
between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
Area--comparative: slightly larger than New Mexico
Land boundaries:
total: 3,110 km
border countries: Burkina Faso 584 km, Ghana 668 km, Guinea 610 km,
Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, semiarid in far north; three
seasons--warm and dry (November to March), hot and dry (March to
May), hot and wet (June to October)
Terrain: mostly flat to undulating plains; mountains in northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum, diamonds, manganese, iron ore,
cobalt, bauxite, copper
Land use:
arable land: 8%
permanent crops: 4%
permanent pastures: 41%
forests and woodland: 22%
other: 25% (1993 est.)
Irrigated land: 680 sq km (1993 est.)
Natural hazards: coast has heavy surf and no natural harbors;
during the rainy season torrential flooding is possible
Environment--current issues: deforestation (most of the country''s
forests--once the largest in West Africa--have been cleared by the
timber industry); water pollution from sewage and industrial and
agricultural effluents
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Location: Southeastern Europe, bordering the Adriatic Sea,
between Bosnia and Herzegovina and Slovenia
Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,538 sq km
land: 56,410 sq km
water: 128 sq km
Area--comparative: slightly smaller than West Virginia
Land boundaries:
total: 2,197 km
border countries: Bosnia and Herzegovina 932 km, Hungary 329 km,
Serbia and Montenegro 266 km (241 km with Serbia; 25 km with
Montenegro), Slovenia 670 km
Coastline: 5,790 km (mainland 1,778 km, islands 4,012 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: Mediterranean and continental; continental climate
predominant with hot summers and cold winters; mild winters, dry
summers along coast
Terrain: geographically diverse; flat plains along Hungarian
border, low mountains and highlands near Adriatic coast, coastline,
and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1,830 m
Natural resources: oil, some coal, bauxite, low-grade iron ore,
calcium, natural asphalt, silica, mica, clays, salt
Land use:
arable land: 21%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 38%
other: 19% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: frequent and destructive earthquakes
Environment--current issues: air pollution (from metallurgical
plants) and resulting acid rain is damaging the forests; coastal
pollution from industrial and domestic waste; widespread casualties
and destruction of infrastructure in border areas affected by civil
strife
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Climate Change-Kyoto Protocol,
Desertification
Geography--note: controls most land routes from Western Europe to
Aegean Sea and Turkish Straits
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the Caribbean
Area:
total: 110,860 sq km
land: 110,860 sq km
water: 0 sq km
Area--comparative: slightly smaller than Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay 29 km
note: Guantanamo Naval Base is leased by the US and thus remains
part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; dry season (November
to April); rainy season (May to October)
Terrain: mostly flat to rolling plains, with rugged hills and
mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper, manganese,
salt, timber, silica, petroleum
Land use:
arable land: 24%
permanent crops: 7%
permanent pastures: 27%
forests and woodland: 24%
other: 18% (1993 est.)
Irrigated land: 9,100 sq km (1993 est.)
Natural hazards: the east coast is subject to hurricanes from
August to October (in general, the country averages about one
hurricane every other year); droughts are common
Environment--current issues: pollution of Havana Bay; overhunting
threatens wildlife populations; deforestation
Environment--international agreements:
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental Protocol, Marine
Life Conservation
Geography--note: largest country in Caribbean
Location: Middle East, island in the Mediterranean Sea, south of
Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (note--of which 3,355 sq km are in the Turkish
Cypriot area)
land: 9,240 sq km
water: 10 sq km
Area--comparative: about 0.6 times the size of Connecticut
Land boundaries: 0 km
Coastline: 648 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: temperate, Mediterranean with hot, dry summers and cool,
wet winters
Terrain: central plain with mountains to north and south;
scattered but significant plains along southern coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1,952 m
Natural resources: copper, pyrites, asbestos, gypsum, timber,
salt, marble, clay earth pigment
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 0%
forests and woodland: 13%
other: 70% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: moderate earthquake activity
Environment--current issues: water resource problems (no natural
reservoir catchments, seasonal disparity in rainfall; sea water
intrusion to island''s largest aquifer; increased salination in the
north); water pollution from sewage and industrial wastes; coastal
degradation; loss of wildlife habitats from urbanization
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,703 sq km
land: 78,645 sq km
water: 58 sq km
Area--comparative: slightly smaller than South Carolina
Land boundaries:
total: 1,881 km
border countries: Austria 362 km, Germany 646 km, Poland 658 km,
Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy, humid winters
Terrain: Bohemia in the west consists of rolling plains, hills,
and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
Elevation extremes:
lowest point: Elbe River 115 m
highest point: Snezka 1,602 m
Natural resources: hard coal, soft coal, kaolin, clay, graphite
Land use:
arable land: 41%
permanent crops: 2%
permanent pastures: 11%
forests and woodland: 34%
other: 12% (1993 est.)
Irrigated land: 240 sq km (1993 est.)
Natural hazards: flooding
Environment--current issues: air and water pollution in areas of
northwest Bohemia and in northern Moravia around Ostrava present
health risks; acid rain damaging forests
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Geography--note: landlocked; strategically located astride some of
oldest and most significant land routes in Europe; Moravian Gate is
a traditional military corridor between the North European Plain and
the Danube in central Europe
Location: Northern Europe, bordering the Baltic Sea and the North
Sea, on a peninsula north of Germany
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea and the rest
of metropolitan Denmark, but excludes the Faroe Islands and Greenland
Area--comparative: slightly less than twice the size of
Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
contiguous zone: 4 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: temperate; humid and overcast; mild, windy winters and
cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Ejer Bavnehoj 173 m
Natural resources: petroleum, natural gas, fish, salt, limestone,
stone, gravel and sand
Land use:
arable land: 60%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 10%
other: 25% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: flooding is a threat in some areas of the
country (e.g., parts of Jutland, along the southern coast of the
island of Lolland) that are protected from the sea by a system of
dikes
Environment--current issues: air pollution, principally from
vehicle and power plant emissions; nitrogen and phosphorus pollution
of the North Sea; drinking and surface water becoming polluted from
animal wastes and pesticides
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol, Law of the Sea
Geography--note: controls Danish Straits (Skagerrak and Kattegat)
linking Baltic and North Seas; about one-quarter of the population
lives in Copenhagen
Location: Eastern Africa, bordering the Gulf of Aden and the Red
Sea, between Eritrea and Somalia
Geographic coordinates: 11 30 N, 43 00 E
Map references: Africa
Area:
total: 22,000 sq km
land: 21,980 sq km
water: 20 sq km
Area--comparative: slightly smaller than Massachusetts
Land boundaries:
total: 508 km
border countries: Eritrea 113 km, Ethiopia 337 km, Somalia 58 km
Coastline: 314 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 9%
forests and woodland: 0%
other: 91% (1993 est.)
Irrigated land: NA sq km
Natural hazards: earthquakes; droughts; occasional cyclonic
disturbances from the Indian Ocean bring heavy rains and flash floods
Environment--current issues: inadequate supplies of potable water;
desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: strategic location near world''s busiest shipping
lanes and close to Arabian oilfields; terminus of rail traffic into
Ethiopia; mostly wasteland
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, about one-half of the way from Puerto Rico to
Geographic coordinates: 30 00 S, 80 00 E
Map references: World
Area:
total: 73.6 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of Bengal, Great
Australian Bight, Gulf of Aden, Gulf of Oman, Mozambique Channel,
Persian Gulf, Red Sea, Strait of Malacca, and other tributary water
bodies
Area--comparative: slightly less than eight times the size of the
US; third-largest ocean (after the Pacific Ocean and Atlantic Ocean,
but larger than the Arctic Ocean)
Coastline: 66,526 km
Climate: northeast monsoon (December to April), southwest monsoon
(June to October); tropical cyclones occur during May/June and
October/November in the northern Indian Ocean and January/February
in the southern Indian Ocean
Terrain: surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
Elevation extremes:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, shrimp, sand and
gravel aggregates, placer deposits, polymetallic nodules
Natural hazards: ships subject to superstructure icing in extreme
south near Antarctica from May to October
Environment--current issues: endangered marine species include the
dugong, seals, turtles, and whales; oil pollution in the Arabian
Sea, Persian Gulf, and Red Sea
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: major chokepoints include Bab el Mandeb, Strait
of Hormuz, Strait of Malacca, southern access to the Suez Canal, and
the Lombok Strait
Location: Southeastern Asia, archipelago between the Indian Ocean
and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
total: 1,919,440 sq km
land: 1,826,440 sq km
water: 93,000 sq km
Area--comparative: slightly less than three times the size of Texas
Land boundaries:
total: 2,602 km
border countries: Malaysia 1,782 km, Papua New Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in highlands
Terrain: mostly coastal lowlands; larger island','e0b5dbb934bbc0bb430ed59e3d57463e01c0c0342a39943f6ac2cea310c5ef7a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b25d4b4c68112c3f8ad80f7ef63e54fa0447e6febaa98b94f74eb1654196db9',1999,'AU','Australia','geography',114,'s have interior
mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas, nickel, timber,
bauxite, copper, fertile soils, coal, gold, silver
Land use:
arable land: 10%
permanent crops: 7%
permanent pastures: 7%
forests and woodland: 62%
other: 14% (1993 est.)
Irrigated land: 45,970 sq km (1993 est.)
Natural hazards: occasional floods, severe droughts, tsunamis,
earthquakes, volcanoes
Environment--current issues: deforestation; water pollution from
industrial wastes, sewage; air pollution in urban areas; smoke and
haze from forest fires
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertication, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Geography--note: archipelago of 17,000 islands (6,000 inhabited);
straddles Equator; strategic location astride or along major sea
lanes from Indian Ocean to Pacific Ocean
Location: Middle East, bordering the Gulf of Oman, the Persian
Gulf, and the Caspian Sea, between Iraq and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
total: 1.648 million sq km
land: 1.636 million sq km
water: 12,000 sq km
Area--comparative: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35 km,
Azerbaijan-proper 432 km, Azerbaijan-Naxcivan exclave 179 km, Iraq
1,458 km, Pakistan 909 km, Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km
note: Iran also borders the Caspian Sea (740 km)
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements, or median lines in
the Persian Gulf
territorial sea: 12 nm
Climate: mostly arid or semiarid, subtropical along Caspian coast
Terrain: rugged, mountainous rim; high, central basin with
deserts, mountains; small, discontinuous plains along both coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Qolleh-ye Damavand 5,671 m
Natural resources: petroleum, natural gas, coal, chromium,
copper, iron ore, lead, manganese, zinc, sulfur
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 27%
forests and woodland: 7%
other: 55% (1993 est.)
Irrigated land: 94,000 sq km (1993 est.)
Natural hazards: periodic droughts, floods; dust storms,
sandstorms; earthquakes along western border and in the northeast
Environment--current issues: air pollution, especially in urban
areas, from vehicle emissions, refinery operations, and industrial
effluents; deforestation; overgrazing; desertification; oil
pollution in the Persian Gulf; inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Environmental Modification, Law of the
Sea, Marine Life Conservation
Location: Middle East, bordering the Persian Gulf, between Iran
and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
land: 432,162 sq km
water: 4,910 sq km
Area--comparative: slightly more than twice the size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km, Kuwait 242 km, Saudi
Arabia 814 km, Syria 605 km, Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
Climate: mostly desert; mild to cool winters with dry, hot,
cloudless summers; northern mountainous regions along Iranian and
Turkish borders experience cold winters with occasionally heavy
snows that melt in early spring, sometimes causing extensive
flooding in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along Iranian border
in south with large flooded areas; mountains along borders with Iran
and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Gundah Zhur 3,608 m
Natural resources: petroleum, natural gas, phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
other: 79% (1993 est.)
Irrigated land: 25,500 sq km (1993 est.)
Natural hazards: dust storms, sandstorms, floods
Environment--current issues: government water control projects
have drained most of the inhabited marsh areas east of An Nasiriyah
by drying up or diverting the feeder streams and rivers; a once
sizable population of Shi''a Muslims, who have inhabited these areas
for thousands of years, has been displaced; furthermore, the
destruction of the natural habitat poses serious threats to the
area''s wildlife populations; inadequate supplies of potable water;
development of Tigris-Euphrates Rivers system contingent upon
agreements with upstream riparian Turkey; air and water pollution;
soil degradation (salination) and erosion; desertification
Environment--international agreements:
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Location: Western Europe, occupying five-sixths of the island of
Ireland in the North Atlantic Ocean, west of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
water: 1,390 sq km
Area--comparative: slightly larger than West Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate maritime; modified by North Atlantic Current;
mild winters, cool summers; consistently humid; overcast about half
the time
Terrain: mostly level to rolling interior plain surrounded by
rugged hills and low mountains; sea cliffs on west coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Carrauntoohill 1,041 m
Natural resources: zinc, lead, natural gas, barite, copper,
gypsum, limestone, dolomite, peat, silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 68%
forests and woodland: 5%
other: 14% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: water pollution, especially of lakes,
from agricultural runoff
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Endangered Species,
Marine Life Conservation, Tropical Timber 94
Geography--note: strategic location on major air and sea routes
between North America and northern Europe; over 40% of the
population resides within 97 km of Dublin
Location: Middle East, bordering the Mediterranean Sea, between
Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries:
total: 1,006 km
border countries: Egypt 255 km, Gaza Strip 51 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
Climate: temperate; hot and dry in southern and eastern desert
areas
Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: copper, phosphates, bromide, potash, clay,
sand, sulfur, asphalt, manganese, small amounts of natural gas and
crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
other: 66% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during spring and summer
Environment--current issues: limited arable land and natural fresh
water resources pose serious constraints; desertification; air
pollution from industrial and vehicle emissions; groundwater
pollution from industrial and domestic waste, chemical fertilizers,
and pesticides
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Geography--note: there are 216 Israeli settlements and civilian
land use sites in the West Bank, 42 in the Israeli-occupied Golan
Heights, 24 in the Gaza Strip, and 29 in East Jerusalem (August 1998
est.)
Location: Southern Europe, a peninsula extending into the central
Mediterranean Sea, northeast of Tunisia
Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total: 301,230 sq km
land: 294,020 sq km
water: 7,210 sq km
note: includes Sardinia and Sicily
Area--comparative: slightly larger than Arizona
Land boundaries:
total: 1,932.2 km
border countries: Austria 430 km, France 488 km, Holy See (Vatican
City) 3.2 km, San Marino 39 km, Slovenia 232 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: predominantly Mediterranean; Alpine in far north; hot,
dry in south
Terrain: mostly rugged and mountainous; some plains, coastal
lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) 4,807 m
Natural resources: mercury, potash, marble, sulfur, dwindling
natural gas and crude oil reserves, fish, coal
Land use:
arable land: 31%
permanent crops: 10%
permanent pastures: 15%
forests and woodland: 23%
other: 21% (1993 est.)
Irrigated land: 27,100 sq km (1993 est.)
Natural hazards: regional risks include landslides, mudflows,
avalanches, earthquakes, volcanic eruptions, flooding; land
subsidence in Venice
Environment--current issues: air pollution from industrial
emissions such as sulfur dioxide; coastal and inland rivers polluted
from industrial and agricultural effluents; acid rain damaging
lakes; inadequate industrial waste treatment and disposal facilities
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: strategic location dominating central
Mediterranean as well as southern sea and air approaches to Western
Europe
Location: Caribbean, island in the Caribbean Sea, south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the Caribbean
Area:
total: 10,990 sq km
land: 10,830 sq km
water: 160 sq km
Area--comparative: slightly smaller than Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow, discontinuous coastal
plain
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 14%
permanent crops: 6%
permanent pastures: 24%
forests and woodland: 17%
other: 39% (1993 est.)
Irrigated land: 350 sq km (1993 est.)
Natural hazards: hurricanes (especially July to November)
Environment--current issues: deforestation; coastal waters
polluted by industrial waste, sewage, and oil spills; damage to
coral reefs; air pollution in Kingston results from vehicle emissions
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: strategic location between Cayman Trench and
Jamaica Channel, the main sea lanes for Panama Canal
Location: Northern Europe, island between the Greenland Sea and
the Norwegian Sea, northeast of Iceland
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: 0 sq km
Area--comparative: slightly more than twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 10 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: arctic maritime with frequent storms and persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg 2,277 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: dominated by the volcano Haakon VII
Toppen/Beerenberg; volcanic activity resumed in 1970
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: barren volcanic island with some moss and grass
Location: Eastern Asia, island chain between the North Pacific
Ocean and the Sea of Japan, east of the Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto), Daito-shoto,
Minami-jima, Okino-tori-shima, Ryukyu Islands (Nansei-shoto), and
Volcano Islands (Kazan-retto)
Area--comparative: slightly smaller than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm; between 3 nm and 12 nm in the international
straits--La Perouse or Soya, Tsugaru, Osumi, and Eastern and Western
Channels of the Korea or Tsushima Strait
Climate: varies from tropical in south to cool temperate in north
Terrain: mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources, fish
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 67%
other: 19% (1993 est.)
Irrigated land: 27,820 sq km (1993 est.)
Natural hazards: many dormant and some active volcanoes; about
1,500 seismic occurrences (mostly tremors) every year; tsunamis
Environment--current issues: air pollution from power plant
emissions results in acid rain; acidification of lakes and
reservoirs degrading water quality and threatening aquatic life;
Japan is one of the largest consumers of fish and tropical timber,
contributing to the depletion of these resources in Asia and
elsewhere
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertication, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: strategic location in northeast Asia
Location: Oceania, island in the South Pacific Ocean, about
one-half of the way from Hawaii to the Cook Islands
Geographic coordinates: 0 22 S, 160 03 W
Map references: Oceania
Area:
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
Area--comparative: about eight times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; scant rainfall, constant wind, burning sun
Terrain: sandy, coral island surrounded by a narrow fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 7 m
Natural resources: guano (deposits worked until late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: the narrow fringing reef surrounding the island
can be a maritime hazard
Environment--current issues: no natural fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: sparse bunch grass, prostrate vines, and
low-growing shrubs; primarily a nesting, roosting, and foraging
habitat for seabirds, shorebirds, and marine wildlife
Location: Western Europe, island in the English Channel,
northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
total: 116 sq km
land: 116 sq km
water: 0 sq km
Area--comparative: about 0.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills along north
coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: agricultural land
Land use:
arable land: 66%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 34%
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: largest and southernmost of Channel Islands;
about 30% of population concentrated in Saint Helier
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds; hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1,628 m
Natural resources: nickel, chrome, iron, cobalt, manganese,
silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 12%
forests and woodland: 39%
other: 49% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons most frequent from November to March
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Oceania, islands in the South Pacific Ocean, southeast
of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,670 sq km
water: 10 sq km
note: includes Antipodes Islands, Auckland Islands, Bounty Islands,
Campbell Island, Chatham Islands, and Kermadec Islands
Area--comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Natural resources: natural gas, iron ore, sand, coal, timber,
hydropower, gold, limestone
Land use:
arable land: 9%
permanent crops: 5%
permanent pastures: 50%
forests and woodland: 28%
other: 8% (1993 est.)
Irrigated land: 2,850 sq km (1993 est.)
Natural hazards: earthquakes are common, though usually not
severe; volcanic activity
Environment--current issues: deforestation; soil erosion; native
flora and fauna hard-hit by species introduced from outside
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol, Marine Life
Conservation
Geography--note: about 80% of the population lives in cities
Location: Middle America, bordering both the Caribbean Sea and
the North Pacific Ocean, between Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the Caribbean
Area:
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area--comparative: slightly smaller than the state of New York
Land boundaries:
total: 1,231 km
border countries: Costa Rica 309 km, Honduras 922 km
Coastline: 910 km
Maritime claims:
contiguous zone: 25-nm security zone
continental shelf: natural prolongation
territorial sea: 200 nm
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten, lead, zinc,
timber, fish
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 27%
other: 17% (1993 est.)
Irrigated land: 880 sq km (1993 est.)
Natural hazards: destructive earthquakes, volcanoes, landslides,
and occasionally severe hurricanes
Environment--current issues: deforestation; soil erosion; water
pollution; Hurricane Mitch damage
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol,
Environmental Modification, Law of the Sea
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area--comparative: about 0.2 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical, mild, little seasonal temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 25%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (especially May to July)
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Oceania, islands in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and Tinian
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 1,482 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by northeast trade winds,
little seasonal temperature variation; dry season December to June,
rainy season July to October
Terrain: southern islands are limestone with level terraces and
fringing coral reefs; northern islands are volcanic
Elevation extremes:
lowest point','2e0bd07acf8e876dbc6547e9a516d5a066c900d2323722abdeeda4725636825b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b41c1831bf966e0717cf420d885b2c6cae1fa5b5b32ef08020f9aa8752f206',1999,'AU','Australia','geography',115,': Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 21%
permanent crops: 0%
permanent pastures: 19%
forests and woodland: 0%
other: 60%
Irrigated land: NA sq km
Natural hazards: active volcanoes on Pagan and Agrihan; typhoons
(especially August to November)
Environment--current issues: contamination of groundwater on
Saipan may contribute to disease; clean-up of landfill; protection
of endangered species conflicts with development
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strategic location in the North Pacific Ocean
Location: Northern Europe, bordering the North Sea and the North
Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
water: 16,360 sq km
Area--comparative: slightly larger than New Mexico
Land boundaries:
total: 2,515 km
border countries: Finland 729 km, Sweden 1,619 km, Russia 167 km
Coastline: 21,925 km (includes mainland 3,419 km, large islands
2,413 km, long fjords, numerous small islands, and minor
indentations 16,093 km)
Maritime claims:
contiguous zone: 10 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: temperate along coast, modified by North Atlantic
Current; colder interior; rainy year-round on west coast
Terrain: glaciated; mostly high plateaus and rugged mountains
broken by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Glittertinden 2,472 m
Natural resources: petroleum, copper, natural gas, pyrites,
nickel, iron ore, zinc, lead, fish, timber, hydropower
Land use:
arable land: 3%
permanent crops: NA%
permanent pastures: 0%
forests and woodland: 27%
other: 70% (1993 est.)
Irrigated land: 970 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: water pollution; acid rain damaging
forests and adversely affecting lakes, threatening fish stocks; air
pollution from vehicle emissions
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: about two-thirds mountains; some 50,000 islands
off its much indented coastline; strategic location adjacent to sea
lanes and air routes in North Atlantic; one of most rugged and
longest coastlines in world; Norway is the only NATO member having a
land boundary with Russia
Location: Middle East, bordering the Arabian Sea, Gulf of Oman,
and Persian Gulf, between Yemen and UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Area--comparative: slightly smaller than Kansas
Land boundaries:
total: 1,374 km
border countries: Saudi Arabia 676 km, UAE 410 km, Yemen 288 km
Coastline: 2,092 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: dry desert; hot, humid along coast; hot, dry interior;
strong southwest summer monsoon (May to September) in far south
Terrain: vast central desert plain, rugged mountains in north and
south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper, asbestos, some marble,
limestone, chromium, gypsum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: NA%
other: 95% (1993 est.)
Irrigated land: 580 sq km (1993 est.)
Natural hazards: summer winds often raise large sandstorms and
dust storms in interior; periodic droughts
Environment--current issues: rising soil salinity; beach pollution
from oil spills; very limited natural fresh water resources
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: strategic location with small foothold on
Musandam Peninsula adjacent to Strait of Hormuz, a vital transit
point for world crude oil
Location: body of water between Antarctica, Asia, Australia, and
the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: World
Area:
total: 165.384 million sq km
note: includes Bali Sea, Bellingshausen Sea, Bering Sea, Bering
Strait, Coral Sea, East China Sea, Flores Sea, Gulf of Alaska, Gulf
of Tonkin, Java Sea, Philippine Sea, Ross Sea, Savu Sea, Sea of
Japan, Sea of Okhotsk, South China Sea, Tasman Sea, Timor Sea, and
other tributary water bodies
Area--comparative: about 18 times the size of the US; the largest
ocean (followed by the Atlantic Ocean, the Indian Ocean, and the
Arctic Ocean); covers about one-third of the global surface; larger
than the total land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems and resultant wind
patterns exhibit remarkable uniformity in the south and east; trade
winds and westerly winds are well-developed patterns, modified by
seasonal fluctuations; tropical cyclones (hurricanes) may form south
of Mexico from June to October and affect Mexico and Central
America; continental influences cause climatic uniformity to be much
less pronounced in the eastern and western regions at the same
latitude in the North Pacific Ocean; the western Pacific is
monsoonal--a rainy season occurs during the summer months, when
moisture-laden winds blow from the ocean over the land, and a dry
season during the winter months, when dry winds blow from the Asian
landmass back to the ocean; tropical cyclones (typhoons) may strike
southeast and east Asia from May to December
Terrain: surface currents in the northern Pacific are dominated
by a clockwise, warm-water gyre (broad circular system of currents)
and in the southern Pacific by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the Mariana
Trench, which is the world''s deepest
Elevation extremes:
lowest point: Challenger Deep in the Mariana Trench -10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic nodules, sand
and gravel aggregates, placer deposits, fish
Natural hazards: surrounded by a zone of violent volcanic and
earthquake activity sometimes referred to as the "Pacific Ring of
Fire"; subject to tropical cyclones (typhoons) in southeast and east
Asia from May to December (most frequent from July to October);
tropical cyclones (hurricanes) may form south of Mexico and strike
Central America and Mexico from June to October (most common in
August and September); southern shipping lanes subject to icebergs
from Antarctica; cyclical El Nino phenomenon occurs off the coast of
Peru, when the trade winds slacken and the warm Equatorial
countercurrent moves south, killing the plankton that is the primary
food source for anchovies; consequently, the anchovies move to
better feeding grounds, causing resident marine birds to starve by
the thousands because of the loss of their food source; ships
subject to superstructure icing in extreme north from October to May
and in extreme south from May to October; persistent fog in the
northern Pacific can be a maritime hazard from June to December
Environment--current issues: endangered marine species include the
dugong, sea lion, sea otter, seals, turtles, and whales; oil
pollution in Philippine Sea and South China Sea
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: the major chokepoints are the Bering Strait,
Panama Canal, Luzon Strait, and the Singapore Strait; the Equator
divides the Pacific Ocean into the North Pacific Ocean and the South
Pacific Ocean; dotted with low coral islands and rugged volcanic
islands in the southwestern Pacific Ocean
Location: Southern Asia, bordering the Arabian Sea, between India
on the east and Iran and Afghanistan on the west and China in the
north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area--comparative: slightly less than twice the size of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km, China 523 km, India 2,912
km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly hot, dry desert; temperate in northwest; arctic
in north
Terrain: flat Indus plain in east; mountains in north and
northwest; Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas reserves, limited
petroleum, poor quality coal, iron ore, copper, salt, limestone
Land use:
arable land: 27%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 5%
other: 61% (1993 est.)
Irrigated land: 171,100 sq km (1993 est.)
Natural hazards: frequent earthquakes, occasionally severe
especially in north and west; flooding along the Indus after heavy
rains (July and August)
Environment--current issues: water pollution from raw sewage,
industrial wastes, and agricultural runoff; limited natural fresh
water resources; a majority of the population does not have access
to potable water; deforestation; soil erosion; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Marine Life Conservation
Geography--note: controls Khyber Pass and Bolan Pass, traditional
invasion routes between Central Asia and the Indian Subcontinent
Location: Oceania, group of islands in the North Pacific Ocean,
southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total: 458 sq km
land: 458 sq km
water: 0 sq km
Area--comparative: slightly more than 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 12 nm
extended fishing zone: 200 nm
territorial sea: 3 nm
Climate: wet season May to November; hot and humid
Terrain: varying geologically from the high, mountainous main
island of Babelthuap to low, coral islands usually fringed by large
barrier reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests, minerals (especially gold), marine
products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment--current issues: inadequate facilities for disposal of
solid waste; threats to the marine ecosystem from sand and coral
dredging, illegal fishing practices, and overfishing
Environment--international agreements:
party to: Biodiversity, Law of the Sea
signed, but not ratified: none of the selected agreements
Geography--note: includes World War II battleground of Beliliou
(Peleliu) and world-famous rock islands; archipelago of six island
groups totaling over 200 islands in the Caroline chain
Location: Oceania, atoll in the North Pacific Ocean, about
one-half of the way from Hawaii to American Samoa
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
total: 11.9 sq km
land: 11.9 sq km
water: 0 sq km
Area--comparative: about 20 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial, hot, and very rainy
Terrain: very low
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 100%
other: 0%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: about 50 islets covered with dense vegetation,
coconut trees, and balsa-like trees up to 30 meters tall
Location: Middle America, bordering both the Caribbean Sea and
the North Pacific Ocean, between Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
water: 2,210 sq km
Area--comparative: slightly smaller than South Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330 km
Coastline: 2,490 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy; prolonged rainy season
(May to January), short dry season (January to May)
Terrain: interior mostly steep, rugged mountains and dissected,
upland plains; coastal areas largely plains and rolling hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests, shrimp
Land use:
arable land: 7%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 44%
other: 27% (1993 est.)
Irrigated land: 320 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: water pollution from agricultural
runoff threatens fishery resources; deforestation of tropical rain
forest; land degradation
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography--note: strategic location on eastern end of isthmus
forming land bridge connecting North and South America; controls
Panama Canal that links North Atlantic Ocean via Caribbean Sea with
North Pacific Ocean
Location: Southeastern Asia, group of islands including the
eastern half of the island of New Guinea between the Coral Sea and
the South Pacific Ocean, east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; northwest monsoon (December to March),
southeast monsoon (May to October); slight seasonal temperature
variation
Terrain: mostly mountains with coastal lowlands and rolling
foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas, timber,
oil, fisheries
Land use:
arable land: 0.1%
permanent crops: 1%
permanent pastures: 0%
forests and woodland: 92.9%
other: 6% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism; situated along the Pacific
"Rim of Fire"; the country is subject to frequent and sometimes
severe earthquakes; mud slides
Environment--current issues: rain forest subject to deforestation
as a result of growing commercial demand for tropical timber;
pollution from mining projects; severe drought
Environment--international agreements:
party to: Antarctic Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
Geography--note: shares island of New Guinea with Indonesia; one
of world''s largest swamps along southwest coast
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area--comparative: 0.1 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by easterly trade winds (March to
November); westerly gales and heavy rain (November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: severe tropical storms are usually rare, but, in
1997, there were three cyclones
Environment--current issues: since there are no streams or rivers
and groundwater is not potable, all water needs must be met by
catchment systems with storage facilities; beachhead erosion because
of the use of sand for building materials; excessive clearance of
forest undergrowth for use as fuel; damage to coral reefs from the
spread of the Crown of Thorns starfish; Tuvalu is very concerned
about global increases in greenhouse gas emissions and their effect
on rising sea levels, which threaten the country''s underground water
table
Environment--international agreements:
party to: Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Marine Dumping, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Biodiversity, Law of the Sea
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
Area--comparative: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of the Congo 765 km, Kenya 933
km, Rwanda 169 km, Sudan 435 km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry seasons (December
to February, June to August); semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley 5,110 m
Natural resources: copper, cobalt, limestone, salt
Land use:
arable land: 25%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 28%
other: 29% (1993 est.)
Irrigated land: 90 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: draining of wetlands for agricultural
use; deforestation; overgrazing; soil erosion; poaching is widespread
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Environmental Modification
Geography--note: landlocked','de4438b0ed0939eea3002aeae88f2bbd8c8117a286d8217066313f2557b80614','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dfe539e73c944b5ab2d15a0b98a4a3ce249b34dd81ee31bbff93734c9cb5c31',1999,'KM','Comoros','geography',125,'Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Area--comparative: slightly less than one-fourth the size of the US
Land boundaries:
total: 10,271 km
border countries: Angola 2,511 km, Burundi 233 km, Central African
Republic 1,577 km, Republic of the Congo 2,410 km, Rwanda 217 km,
Sudan 628 km, Uganda 765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
territorial sea: 12 nm
Climate: tropical; hot and humid in equatorial river basin;
cooler and drier in southern highlands; cooler and wetter in eastern
highlands; north of Equator--wet season April to October, dry season
December to February; south of Equator--wet season November to March,
dry season April to October
Terrain: vast central basin is a low-lying plateau; mountains in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema (Mount Stanley) 5,110
m
Natural resources: cobalt, copper, cadmium, petroleum, industrial
and gem diamonds, gold, silver, zinc, manganese, tin, germanium,
uranium, radium, bauxite, iron ore, coal, hydropower potential,
timber
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 77%
other: 13% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: periodic droughts in south; volcanic activity
Environment--current issues: poaching threatens wildlife
populations; water pollution; deforestation; refugees who arrived in
mid-1994 were responsible for significant deforestation, soil
erosion, and wildlife poaching in the eastern part of the country
(most of those refugees were repatriated in November and December
1996)
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Geography--note: straddles Equator; very narrow strip of land that
controls the lower Congo river and is only outlet to South Atlantic
Ocean; dense tropical rain forest in central river basin and eastern
highlands
Location: Western Africa, bordering the South Atlantic Ocean,
between Angola and Gabon
Geographic coordinates: 1 00 S, 15 00 E
Map references: Africa
Area:
total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
Area--comparative: slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km, Central African
Republic 467 km, Democratic Republic of the Congo 2,410 km, Gabon
1,903 km
Coastline: 169 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (March to June); dry season (June
to October); constantly high temperatures and humidity; particularly
enervating climate astride the Equator
Terrain: coastal plain, southern basin, central plateau, northern
basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead, zinc,
uranium, copper, phosphates, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 29%
forests and woodland: 62%
other: 9% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: seasonal flooding
Environment--current issues: air pollution from vehicle emissions;
water pollution from the dumping of raw sewage; tap water is not
potable; deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species, Ozone
Layer Protection, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Desertification, Law of the Sea
Geography--note: about 70% of the population lives in Brazzaville,
Pointe-Noire, or along the railroad between them','7007c3c760f4112bedd7bf799a1fe3b2e40e928f7d3c5d44d46410c86f9450fd','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('097941f0996bae709d515f40b487168168e3f1ae038680f932ec66ca1739b35f',1999,'ET','Ethiopia','geography',133,'Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total: 240 sq km
land: 240 sq km
water: 0 sq km
Area--comparative: 1.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly islands in
south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land: 9%
permanent crops: 13%
permanent pastures: NA%
forests and woodland: NA%
other: 78% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (November to March)
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertication, Law of the Sea
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Southern Europe, islands in the Mediterranean Sea,
south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
total: 320 sq km
land: 320 sq km
water: 0 sq km
Area--comparative: slightly less than twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
Climate: Mediterranean with mild, rainy winters and hot, dry
summers
Terrain: mostly low, rocky, flat to dissected plains; many
coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Ta''Dmejrek 253 m (near Dingli)
Natural resources: limestone, salt
Land use:
arable land: 38%
permanent crops: 3%
permanent pastures: NA%
forests and woodland: NA%
other: 59% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: very limited natural fresh water
resources; increasing reliance on desalination
Environment--international agreements:
party to: Air Pollution, Climate Change, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Biodiversity, Climate Change-Kyoto Protocol
Geography--note: the country comprises an archipelago, with only
the three largest islands (Malta, Ghawdex or Gozo, and Kemmuna or
Comino) being inhabited; numerous bays provide good harbors','80fe406665b16f9f8f3fb1f02f8802d90c9859e600022d5665d342f7901abcd1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('824ad5094a0cfe89001266b0953e3bcd1983791a50922b8b0a1b3f14e47b457f',1999,'TT','Trinidad and Tobago','geography',142,'Geographic coordinates: 15 25 N, 61 20 W
Map references: Central America and the Caribbean
Area:
total: 750 sq km
land: 750 sq km
water: 0 sq km
Area--comparative: slightly more than four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by northeast trade winds; heavy
rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
permanent pastures: 3%
forests and woodland: 67%
other: 8% (1993 est.)
Irrigated land: NA sq km
Natural hazards: flash floods are a constant threat; destructive
hurricanes can be expected during the late summer months
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
Location: Caribbean, eastern two-thirds of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
east of Haiti
Geographic coordinates: 19 00 N, 70 40 W
Map references: Central America and the Caribbean
Area:
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area--comparative: slightly more than twice the size of New
Hampshire
Land boundaries:
total: 275 km
border countries: Haiti 275 km
Coastline: 1,288 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
Climate: tropical maritime; little seasonal temperature
variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile valleys
interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 43%
forests and woodland: 12%
other: 15% (1993 est.)
Irrigated land: 2,300 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane belt and
subject to severe storms from June to October; occasional flooding;
periodic droughts
Environment--current issues: water shortages; soil eroding into
the sea damages coral reefs; deforestation; Hurricane Georges damage
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Marine Dumping, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography--note: shares island of Hispaniola with Haiti (eastern
two-thirds is the Dominican Republic, western one-third is Haiti)
Location: Western South America, bordering the Pacific Ocean at
the Equator, between Colombia and Peru
Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area--comparative: slightly smaller than Nevada
Land boundaries:
total: 2,010 km
border countries: Colombia 590 km, Peru 1,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf: claims continental shelf between mainland and
Galapagos Islands
territorial sea: 200 nm
Climate: tropical along coast becoming cooler inland
Terrain: coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish, timber
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 18%
forests and woodland: 56%
other: 15% (1993 est.)
Irrigated land: 5,560 sq km (1993 est.)
Natural hazards: frequent earthquakes, landslides, volcanic
activity; periodic droughts
Environment--current issues: deforestation; soil erosion;
desertification; water pollution; pollution from oil production
wastes
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: Cotopaxi in Andes is highest active volcano in
world
Location: Northern Africa, bordering the Mediterranean Sea,
between Libya and the Gaza Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total: 1,001,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area--comparative: slightly more than three times the size of New
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the Caribbean
Area:
total: 1,100 sq km
land: 1,060 sq km
water: 40 sq km
Area--comparative: slightly more than six times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; rainy season (June
to October); vulnerable to devastating cyclones (hurricanes) every
eight years on average; average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline; dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Natural resources: coastal scenery and beaches, cultivable land
Land use:
arable land: 8%
permanent crops: 8%
permanent pastures: 17%
forests and woodland: 44%
other: 23% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: hurricanes, flooding, and volcanic activity (an
average of one major natural disaster every five years)
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area--comparative: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; little seasonal temperature variation; rainy
season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,234 m
Natural resources: NEGL
Land use:
arable land: 10%
permanent crops: 18%
permanent pastures: 5%
forests and woodland: 36%
other: 31% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes; Soufriere volcano on the island of
Saint Vincent is a constant threat
Environment--current issues: pollution of coastal waters and
shorelines from discharges by pleasure yachts and other effluents;
in some areas, pollution is severe enough to make swimming
prohibitive
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: the administration of the islands of the
Grenadines group is divided between Saint Vincent and the Grenadines
and Grenada
Location: Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total: 2,860 sq km
land: 2,850 sq km
water: 10 sq km
Area--comparative: slightly smaller than Rhode Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (October to March), dry season
(May to October)
Terrain: narrow coastal plain with volcanic, rocky, rugged
mountains in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1,857 m
Natural resources: hardwood forests, fish
Land use:
arable land: 19%
permanent crops: 24%
permanent pastures: 0%
forests and woodland: 47%
other: 10%
Irrigated land: NA sq km
Natural hazards: occasional typhoons; active volcanism
Environment--current issues: soil erosion
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Southern Europe, an enclave in central Italy
Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total: 60 sq km
land: 60 sq km
water: 0 sq km
Area--comparative: about 0.3 times the size of Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters; warm, sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 749 m
Natural resources: building stone
Land use:
arable land: 17%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 83% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Nuclear Test Ban
signed, but not ratified: Air Pollution
Geography--note: landlocked; smallest independent state in Europe
after the Holy See and Monaco; dominated by the Apennines
Location: Western Africa, islands in the Gulf of Guinea,
straddling the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
total: 1,000 sq km
land: 1,000 sq km
water: 0 sq km
Area--comparative: more than five times the size of Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; one rainy season (October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish
Land use:
arable land: 2%
permanent crops: 36%
permanent pastures: 1%
forests and woodland: NA%
other: 61% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: deforestation; soil erosion and
exhaustion
Environment--international agreements:
party to: Desertification, Environmental Modification, Law of the Sea
signed, but not ratified: Biodiversity, Climate Change
Location: Middle East, bordering the Persian Gulf and the Red
Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1,960,582 sq km
land: 1,960,582 sq km
water: 0 sq km
Area--comparative: slightly more than one-fifth the size of the US
Land boundaries:
total: 4,415 km
border countries: Iraq 814 km, Jordan 728 km, Kuwait 222 km, Oman
676 km, Qatar 60 km, UAE 457 km, Yemen 1,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
territorial sea: 12 nm
Climate: harsh, dry desert with great extremes of temperature
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore, gold, copper
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1%
other: 41% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment--current issues: desertification; depletion of
underground water resources; the lack of perennial rivers or
permanent water bodies has prompted the development of extensive
seawater desalination facilities; coastal pollution from oil spills
Environment--international agreements:
party to: Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: extensive coastlines on Persian Gulf and Red Sea
provide great leverage on shipping (especially crude oil) through
Persian Gulf and Suez Canal
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea-Bissau and Mauritania
Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
total: 196,190 sq km
land: 192,000 sq km
water: 4,190 sq km
Area--comparative: slightly smaller than South Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330 km, Guinea-Bissau
338 km, Mali 419 km, Mauritania 813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; rainy season (May to November) has
strong southeast winds; dry season (December to April) dominated by
hot, dry, harmattan wind
Terrain: generally low, rolling, plains rising to foothills in
southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha 581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 54%
other: 18% (1993 est.)
Irrigated land: 710 sq km (1993 est.)
Natural hazards: lowlands seasonally flooded; periodic droughts
Environment--current issues: wildlife populations threatened by
poaching; deforestation; overgrazing; soil erosion; desertification;
overfishing
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Marine Dumping
Geography--note: The Gambia is almost an enclave of Senegal
Location: Southeastern Europe, bordering the Adriatic Sea,
between Albania and Bosnia and Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km (Serbia 88,412 sq km; Montenegro 13,938 sq km)
land: 102,136 sq km (Serbia 88,412 sq km; Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro 214 sq km)
Area--comparative: slightly smaller than Kentucky (Serbia is
slightly larger than Maine; Montenegro is slightly smaller than
Connecticut)
Land boundaries:
total: 2,246 km
border countries: Albania 287 km (114 km with Serbia, 173 km with
Montenegro), Bosnia and Herzegovina 527 km (312 km with Serbia, 215
km with Montenegro), Bulgaria 318 km (with Serbia), Croatia (north)
241 km (with Serbia), Croatia (south) 25 km (with Montenegro),
Hungary 151 km (with Serbia), The Former Yugoslav Republic of
Macedonia 221 km (with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia 0 km)
Maritime claims: NA
Climate: in the north, continental climate (cold winter and hot,
humid summers with well distributed rainfall); central portion,
continental and Mediterranean climate; to the south, Adriatic
climate along the coast, hot, dry summers and autumns and relatively
cold winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile plains; to
the east, limestone ranges and basins; to the southeast, ancient
mountains and hills; to the southwest, extremely high shoreline with
no islands off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper, lead, zinc,
nickel, gold, pyrite, chrome
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: destructive earthquakes
Environment--current issues: pollution of coastal waters from
sewage outlets, especially in tourist-related areas such as Kotor;
air pollution around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava which flows
into the Danube
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: controls one of the major land routes from
Western Europe to Turkey and the Near East; strategic location along
the Adriatic coast
Location: Eastern Africa, group of islands in the Indian Ocean,
northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; humid; cooler season during southeast
monsoon (late May to September); warmer season during northwest
monsoon (March to May)
Terrain: Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2%
permanent crops: 13%
permanent pastures: NA%
forests and woodland: 11%
other: 74% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies outside the cyclone belt, so severe storms
are rare; short droughts possible
Environment--current issues: water supply depends on catchments to
collect rain water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: 40 granitic and about 50 coralline islands','64b29ff2b6de9526ccb7ab74bd18eb066bc9b3325712e2006acbc0318b309b55','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e73082afe20fcffedb5cc7133c0928a79aaaf22be0c9f468a0fc28e73689231',1999,'MX','Mexico','geography',153,'Land boundaries:
total: 2,689 km
border countries: Gaza Strip 11 km, Israel 255 km, Libya 1,150 km,
Sudan 1,273 km
Coastline: 2,450 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry summers with moderate winters
Terrain: vast desert plateau interrupted by Nile valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
manganese, limestone, gypsum, talc, asbestos, lead, zinc
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1993 est.)
Irrigated land: 32,460 sq km (1993 est.)
Natural hazards: periodic droughts; frequent earthquakes, flash
floods, landslides, volcanic activity; hot, driving windstorm called
khamsin occurs in spring; dust storms, sandstorms
Environment--current issues: agricultural land being lost to
urbanization and windblown sands; increasing soil salination below
Aswan High Dam; desertification; oil pollution threatening coral
reefs, beaches, and marine habitats; other water pollution from
agricultural pesticides, raw sewage, and industrial effluents; very
limited natural fresh water resources away from the Nile which is
the only perennial water source; rapid growth in population
overstraining natural resources
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: controls Sinai Peninsula, only land bridge
between Africa and remainder of Eastern Hemisphere; controls Suez
Canal, shortest sea link between Indian Ocean and Mediterranean Sea;
size, and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics
Location: Middle America, bordering the North Pacific Ocean,
between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the Caribbean
Area:
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
Area--comparative: slightly smaller than Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342 km
Coastline: 307 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (May to October); dry season
(November to April)
Terrain: mostly mountains with narrow coastal belt and central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geothermal power, petroleum
Land use:
arable land: 27%
permanent crops: 8%
permanent pastures: 29%
forests and woodland: 5%
other: 31% (1993 est.)
Irrigated land: 1,200 sq km (1993 est.)
Natural hazards: known as the Land of Volcanoes; frequent and
sometimes very destructive earthquakes and volcanic activity
Environment--current issues: deforestation; soil erosion; water
pollution; contamination of soils from disposal of toxic wastes;
Hurricane Mitch damage
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: Law of the Sea
Geography--note: smallest Central American country and only one
without a coastline on Caribbean Sea
Location: Western Africa, bordering the Bight of Biafra, between
Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,050 sq km
land: 28,050 sq km
water: 0 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands are
volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, timber, small unexploited deposits
of gold, manganese, uranium
Land use:
arable land: 5%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 46%
other: 41% (1993 est.)
Irrigated land: NA sq km
Natural hazards: violent windstorms, flash floods
Environment--current issues: tap water is not potable;
desertification
Environment--international agreements:
party to: Biodiversity, Desertification, Endangered Species, Law of
the Sea, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: insular and continental regions rather widely
separated
Location: Eastern Africa, bordering the Red Sea, between Djibouti
and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area--comparative: slightly larger than Pennsylvania
Land boundaries:
total: 1,630 km
border countries: Djibouti 113 km, Ethiopia 912 km, Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea 1,151 km, islands
in Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast; cooler and
wetter in the central highlands (up to 61 cm of rainfall annually);
semiarid in western hills and lowlands; rainfall heaviest during
June-September except on coastal desert
Terrain: dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
Elevation extremes:
lowest point: near Kulul within the Denakil depression -75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc, copper, salt, probably oil
and natural gas (currently under exploration), fish
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 48%
forests and woodland: 20%
other: 19% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts
Environment--current issues: deforestation; desertification; soil
erosion; overgrazing; loss of infrastructure from civil warfare
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species
signed, but not ratified: none of the selected agreements
Geography--note: strategic geopolitical position along world''s
busiest shipping lanes; Eritrea retained the entire coastline of
Ethiopia along the Red Sea upon de jure independence from Ethiopia
on 27 April 1993
Location: Eastern Europe, bordering the Baltic Sea and Gulf of
Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,211 sq km
water: 2,015 sq km
note: includes 1,520 islands in the Baltic Sea
Area--comparative: slightly smaller than New Hampshire and Vermont
combined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia 294 km
Coastline: 3,794 km
Maritime claims:
exclusive economic zone: limits fixed in coordination with
neighboring states
territorial sea: 12 nm
Climate: maritime, wet, moderate winters, cool summers
Terrain: marshy, lowlands
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: shale oil (kukersite), peat, phosphorite,
amber, cambrian blue clay, limestone, dolomite
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 11%
forests and woodland: 44%
other: 20% (1996 est.)
Irrigated land: 110 sq km (1993 est.)
Natural hazards: flooding occurs frequently in the spring
Environment--current issues: air heavily polluted with sulfur
dioxide from oil-shale burning power plants in northeast;
contamination of soil and groundwater with petroleum products,
chemicals at former Soviet military bases; Estonia has more than
1,400 natural and manmade lakes, the smaller of which in
agricultural areas are heavily affected by organic waste; coastal
sea water is polluted in many locations
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Ship Pollution, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Area--comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,311 km
border countries: Djibouti 337 km, Eritrea 912 km, Kenya 830 km,
Somalia 1,626 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide topographic-induced variation
Terrain: high plateau with central mountain range divided by
Great Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum, copper,
potash, natural gas
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 25%
other: 22% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: geologically active Great Rift Valley
susceptible to earthquakes, volcanic eruptions; frequent droughts
Environment--current issues: deforestation; overgrazing; soil
erosion; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the
Sea, Nuclear Test Ban
Geography--note: landlocked?entire coastline along the Red Sea was
lost with the de jure independence of Eritrea on 24 May 1993
Location: Southern Africa, island in the Mozambique Channel,
about one-half of the way from southern Madagascar to southern','326d2f2ed36d8def622ed010ac13996d397f475d12af9f4c88dd7da51a173da2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0051e10abd6a69d71f3ecd25806d62937e349147fcf5dad9b6712ad4192d9c18',1999,'MZ','Mozambique','geography',163,'Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
land: 28 sq km
water: 0 sq km
Area--comparative: about 0.16 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: negligible
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: wildlife sanctuary
Location: Southern South America, islands in the South Atlantic
Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West Falkland and
about 200 small islands
Area--comparative: slightly smaller than Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 nm
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: cold marine; strong westerly winds, cloudy, humid; rain
occurs on more than half of days in year; occasional snow all year,
except in January and February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy, undulating
plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 99%
forests and woodland: 0%
other: 1% (1993 est.)
Irrigated land: NA sq km
Natural hazards: strong winds persist throughout the year
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: deeply indented coast provides good natural
harbors; short growing season
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total: 587,040 sq km
land: 581,540 sq km
water: 5,500 sq km
Area--comparative: slightly less than twice the size of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or 100 nm from the 2,500-m deep isobath
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, temperate inland, arid in south
Terrain: narrow coastal plain, high plateau and mountains in
center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal, bauxite, salt,
quartz, tar sands, semiprecious stones, mica, fish
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 41%
forests and woodland: 40%
other: 14% (1993 est.)
Irrigated land: 10,870 sq km (1993 est.)
Natural hazards: periodic cyclones
Environment--current issues: soil erosion results from
deforestation and overgrazing; desertification; surface water
contaminated with raw sewage and other organic wastes; several
species of flora and fauna unique to the island are endangered
Environment--international agreements:
party to: Biodiversity, Desertification, Endangered Species, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the Sea
Geography--note: world''s fourth-largest island; strategic location
along Mozambique Channel
Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area:
total: 118,480 sq km
land: 94,080 sq km
water: 24,400 sq km
Area--comparative: slightly smaller than Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1,569 km, Tanzania 475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; rainy season (November to May); dry season
(May to November)
Terrain: narrow elongated plateau with rolling plains, rounded
hills, some mountains
Elevation extremes:
lowest point: junction of the Shire River and international boundary
with Mozambique 37 m
highest point: Sapitwa 3,002 m
Natural resources: limestone, unexploited deposits of uranium,
coal, and bauxite
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 20%
forests and woodland: 39%
other: 23% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: deforestation; land degradation;
water pollution from agricultural runoff, sewage, industrial wastes;
siltation of spawning grounds endangers fish populations
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography--note: landlocked
Location: Southeastern Asia, peninsula and northern one-third of
the island of Borneo, bordering Indonesia and the South China Sea,
south of Vietnam
Geographic coordinates: 2 30 N, 112 30 E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water: 1,200 sq km
Area--comparative: slightly larger than New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1,782 km, Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km, East Malaysia
2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation;
specified boundary in the South China Sea
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; annual southwest (April to October) and
northeast (October to February) monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper, iron ore,
natural gas, bauxite
Land use:
arable land: 3%
permanent crops: 12%
permanent pastures: 0%
forests and woodland: 68%
other: 17% (1993 est.)
Irrigated land: 2,941 sq km (1998 est.)
Natural hazards: flooding, landslides
Environment--current issues: air pollution from industrial and
vehicular emissions; water pollution from raw sewage; deforestation;
smoke/haze from Indonesian forest fires
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Geography--note: strategic location along Strait of Malacca and
southern South China Sea
Location: Southern Asia, group of atolls in the Indian Ocean,
south-southwest of India
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area:
total: 300 sq km
land: 300 sq km
water: 0 sq km
Area--comparative: about 1.7 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims: measured from claimed archipelagic baselines
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; dry, northeast monsoon (November
to March); rainy, southwest monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili island in the Addu
Atoll 2.4 m
Natural resources: fish
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 3%
other: 84% (1993 est.)
Irrigated land: NA sq km
Natural hazards: low level of islands makes them very sensitive
to sea level rise
Environment--current issues: depletion of freshwater aquifers
threatens water supplies
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography--note: 1,190 coral islands grouped into 26 atolls;
archipelago of strategic location astride and along major sea lanes
in Indian Ocean
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 375 sq km
land: 375 sq km
water: 0 sq km
Area--comparative: slightly more than twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; hot, humid, rainy season during
northeastern monsoon (November to May); dry season is cooler (May to
November)
Terrain: generally undulating, with deep ravines and ancient
volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: cyclones during rainy season
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: part of Comoro Archipelago
Location: Middle America, bordering the Caribbean Sea and the
Gulf of Mexico, between Belize and the US and bordering the North
Pacific Ocean, between Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,510 sq km
Area--comparative: slightly less than three times the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km, US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal plains; high
plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold, lead, zinc,
natural gas, timber
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 26%
other: 22% (1993 est.)
Irrigated land: 61,000 sq km (1993 est.)
Natural hazards: tsunamis along the Pacific coast, volcanoes and
destructive earthquakes in the center and south, and hurricanes on
the Gulf of Mexico and Caribbean coasts
Environment--current issues: natural fresh water resources scarce
and polluted in north, inaccessible and poor quality in center and
extreme southeast; raw sewage and industrial effluents polluting
rivers in urban areas; deforestation; widespread erosion;
desertification; serious air pollution in the national capital and
urban centers along US-Mexico border
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: strategic location on southern border of US
Location: Oceania, island group in the North Pacific Ocean, about
three-quarters of the way from Hawaii to Indonesia
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km
note: includes Pohnpei (Ponape), Truk (Chuuk) Islands, Yap Islands,
and Kosrae
Area--comparative: four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; heavy year-round rainfall, especially in the
eastern islands; located on southern edge of the typhoon belt with
occasionally severe damage
Terrain: islands vary geologically from high mountainous islands
to low, coral atolls; volcanic outcroppings on Pohnpei, Kosrae, and
Truk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Totolom 791 m
Natural resources: forests, marine products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: four major island groups totaling 607 islands
Location: Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references: Oceania
Area:
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit Island
Area--comparative: about nine times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 15 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical, but moderated by prevailing easterly winds
Terrain: low, nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 4 m
Natural resources: wildlife, terrestrial and aquatic
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: a coral atoll managed as a national wildlife
refuge and open to the public for wildlife-related recreation in the
form of wildlife observation and photography, sport fishing,
snorkeling, and scuba diving
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent States
Area:
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
Area--comparative: slightly larger than Maryland
Land boundaries:
total: 1,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black Sea
Elevation extremes:
lowest point: Nistru River 2 m
highest point: Mount Balaneshty 430 m
Natural resources: lignite, phosphorites, gypsum
Land use:
arable land: 53%
permanent crops: 14%
permanent pastures: 13%
forests and woodland: 13%
other: 7% (1993 est.)
Irrigated land: 3,110 sq km (1993 est.)
Natural hazards: landslides (57 cases in 1998)
Environment--current issues: heavy use of agricultural chemicals,
including banned pesticides such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poor farming methods
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Air Pollution-Persistent Organic Pollutants
Geography--note: landlocked
Location: Western Europe, bordering the Mediterranean Sea, on the
southern coast of France, near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Area--comparative: about three times the size of The Mall in
Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean with mild, wet winters and hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: second smallest independent state in world (after
Holy See); almost entirely urban
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
total: 1.565 million sq km
land: 1.565 million sq km
water: 0 sq km
Area--comparative: slightly smaller than Alaska
Land boundaries:
total: 8,114 km
border countries: China 4,673 km, Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; continental (large daily and seasonal
temperature ranges)
Terrain: vast semidesert and desert plains; mountains in west and
southwest; Gobi Desert in southeast
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Tavan Bogd Uul 4,374 m
Natural resources: oil, coal, copper, molybdenum, tungsten,
phosphates, tin, nickel, zinc, wolfram, fluorspar, gold
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 80%
forests and woodland: 9%
other: 10% (1993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: dust storms can occur in the spring; grassland
fires
Environment--current issues: limited natural fresh water
resources; policies of the former communist regime promoting rapid
urbanization and industrial growth have raised concerns about their
negative effects on the environment; the burning of soft coal and
the concentration of factories in Ulaanbaatar have severely polluted
the air; deforestation, overgrazing, the converting of virgin land
to agricultural production have increased soil erosion from wind and
rain; desertification; mining activities have also had a deleterious
effect on the environment
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: landlocked; strategic location between China and
Russia
Location: Caribbean, island in the Caribbean Sea, southeast of','09548460d41e7a85efd1b26e0fe251349c6a4da564e253b7ac6bc9e9b664ac07','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec3aaa71d944f598b94ecc0ab3589dccbd37b7361c65eb118c6cac71b8f28931',1999,'AR','Argentina','geography',179,'Location: Northern Europe, island group between the Norwegian Sea
and the north Atlantic Ocean, about one-half of the way from Iceland
to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total: 1,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
Area--comparative: eight times the size of Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: mild winters, cool summers; usually overcast; foggy,
windy
Terrain: rugged, rocky, some low peaks; cliffs along most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (1996)
Irrigated land: 0 sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: archipelago of 17 inhabited islands and one
uninhabited island, and a few uninhabited islets; strategically
located along important sea lanes in northeastern Atlantic;
precipitous terrain limits habitation to small coastal lowlands
Location: Oceania, island group in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: 200-m depth or to the depth of exploitation;
rectilinear shelf claim added
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; only slight seasonal temperature
variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper, offshore oil
potential
Land use:
arable land: 10%
permanent crops: 4%
permanent pastures: 10%
forests and woodland: 65%
other: 11% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: cyclonic storms can occur from November to
January
Environment--current issues: deforestation; soil erosion
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertication, Endangered Species, Law of the Sea, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected agreements
Geography--note: includes 332 islands of which approximately 110
are inhabited
Location: Northern Europe, bordering the Baltic Sea, Gulf of
Bothnia, and Gulf of Finland, between Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total: 337,030 sq km
land: 305,470 sq km
water: 31,560 sq km
Area--comparative: slightly smaller than Montana
Land boundaries:
total: 2,628 km
border countries: Norway 729 km, Sweden 586 km, Russia 1,313 km
Coastline: 1,126 km (excludes islands and coastal indentations)
Maritime claims:
contiguous zone: 6 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive fishing zone: 12 nm
territorial sea: 12 nm (in the Gulf of Finland--3 nm)
Climate: cold temperate; potentially subarctic, but comparatively
mild because of moderating influence of the North Atlantic Current,
Baltic Sea, and more than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed with
lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1,328 m
Natural resources: timber, copper, zinc, iron ore, silver
Land use:
arable land: 8%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: 76%
other: 16% (1993 est.)
Irrigated land: 640 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: air pollution from manufacturing and
power plants contributing to acid rain; water pollution from
industrial wastes, agricultural chemicals; habitat loss threatens
wildlife populations
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: long boundary with Russia; Helsinki is
northernmost national capital on European continent; population
concentrated on small southwestern coastal plain
Location: Western Europe, bordering the Bay of Biscay and English
Channel, between Belgium and Spain southeast of the UK; bordering
the Mediterranean Sea, between Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
total: 547,030 sq km
land: 545,630 sq km
water: 1,400 sq km
note: includes only metropolitan France, but excludes the overseas
administrative divisions
Area--comparative: slightly less than twice the size of Colorado
Land boundaries:
total: 2,892.4 km
border countries: Andorra 60 km, Belgium 620 km, Germany 451 km,
Italy 488 km, Luxembourg 73 km, Monaco 4.4 km, Spain 623 km,
Switzerland 573 km
Coastline: 3,427 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm (does not apply to the Mediterranean)
territorial sea: 12 nm
Climate: generally cool winters and mild summers, but mild
winters and hot summers along the Mediterranean
Terrain: mostly flat plains or gently rolling hills in north and
west; remainder is mountainous, especially Pyrenees in south, Alps
in east
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, fish, timber, zinc,
potash
Land use:
arable land: 33%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 27%
other: 18% (1993 est.)
Irrigated land: 16,300 sq km (1995 est.)
Natural hazards: flooding; avalanches
Environment--current issues: some forest damage from acid rain;
air pollution from industrial and vehicle emissions; water pollution
from urban wastes, agricultural runoff
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: largest West European nation; occasional strong,
cold, dry, north-to-northwesterly wind known as mistral
Location: Northern South America, bordering the North Atlantic
Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: 91,000 sq km
land: 89,150 sq km
water: 1,850 sq km
Area--comparative: slightly smaller than Indiana
Land boundaries:
total: 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; little seasonal temperature
variation
Terrain: low-lying coastal plains rising to hills and small
mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de l''Inini 851 m
Natural resources: bauxite, timber, gold (widely scattered),
cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 83%
other: 17% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: high frequency of heavy showers and severe
thunderstorms; flooding
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: mostly an unsettled wilderness
Location: Oceania, archipelago in the South Pacific Ocean, about
one-half of the way from South America to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,167 sq km (118 islands and atolls)
land: 3,660 sq km
water: 507 sq km
Area--comparative: slightly less than one-third the size of
Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt
Land use:
arable land: 1%
permanent crops: 6%
permanent pastures: 5%
forests and woodland: 31%
other: 57% (1993 est.)
Irrigated land: NA sq km
Natural hazards: occasional cyclonic storms in January
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: includes five archipelagoes; Makatea in French
Polynesia is one of the three great phosphate rock islands in the
Pacific Ocean--the others are Banaba (Ocean Island) in Kiribati and','437243386b693b6f4d37a21400a0ef5ed3f156648d7c5b880fbc7b76ba262a42','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c8ec5425fcdcfe2fe15fa4cd557e9779118591b608616266a4c52f5874ab9e9',1999,'NR','Nauru','geography',191,'Location: south of Africa, islands in the southern Indian Ocean,
about equidistant between Africa, Antarctica, and Australia;
note--French Southern and Antarctic Lands includes Ile Amsterdam, Ile
Saint-Paul, Iles Crozet, and Iles Kerguelen in the southern Indian
Ocean, along with the French-claimed sector of Antarctica, "Adelie
Land"; the US does not recognize the French claim to "Adelie Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,781 sq km
land: 7,781 sq km
water: 0 sq km
note: includes Ile Amsterdam, Ile Saint-Paul, Iles Crozet and Iles
Kerguelen; excludes "Adelie Land" claim of about 500,000 sq km in
Antarctica that is not recognized by the US
Area--comparative: slightly less than 1.3 times the size of
Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 nm from Iles Kerguelen only
territorial sea: 12 nm
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on Ile Kerguelen 1,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: Ile Amsterdam and Ile Saint-Paul are extinct
volcanoes
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: remote location in the southern Indian Ocean
Location: Western Africa, bordering the Atlantic Ocean at the
Equator, between Republic of the Congo and Equatorial Guinea
Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area:
total: 267,670 sq km
land: 257,670 sq km
water: 10,000 sq km
Area--comparative: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km, Republic of the Congo 1,903 km,
Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna in east
and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, manganese, uranium, gold, timber,
iron ore
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 18%
forests and woodland: 77%
other: 3% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: deforestation; poaching
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Location: Western Africa, bordering the North Atlantic Ocean and
Location: Eastern Asia, northern half of the Korean Peninsula
bordering the Korea Bay and the Sea of Japan, between China and
South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area:
total: 120,540 sq km
land: 120,410 sq km
water: 130 sq km
Area--comparative: slightly smaller than Mississippi
Land boundaries:
total: 1,673 km
border countries: China 1,416 km, South Korea 238 km, Russia 19 km
Coastline: 2,495 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
note: military boundary line 50 nm in the Sea of Japan and the
exclusive economic zone limit in the Yellow Sea where all foreign
vessels and aircraft without permission are banned
Climate: temperate with rainfall concentrated in summer
Terrain: mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten, zinc, graphite,
magnesite, iron ore, copper, gold, pyrites, salt, fluorspar,
hydropower
Land use:
arable land: 14%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 61%
other: 23% (1993 est.)
Irrigated land: 14,600 sq km (1993 est.)
Natural hazards: late spring droughts often followed by severe
flooding; occasional typhoons during the early fall
Environment--current issues: localized air pollution attributable
to inadequate industrial controls; water pollution; inadequate
supplies of potable water
Environment--international agreements:
party to: Antarctic Treaty, Biodiversity, Climate Change,
Environmental Modification, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental Protocol, Law of
the Sea
Geography--note: strategic location bordering China, South Korea,
and Russia; mountainous interior is isolated, nearly inaccessible,
and sparsely populated
Location: Eastern Asia, southern half of the Korean Peninsula
bordering the Sea of Japan and the Yellow Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area--comparative: slightly larger than Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm; between 3 nm and 12 nm in the Korea Strait
Climate: temperate, with rainfall heavier in summer than winter
Terrain: mostly hills and mountains; wide coastal plains in west
and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1,950 m
Natural resources: coal, tungsten, graphite, molybdenum, lead,
hydropower
Land use:
arable land: 19%
permanent crops: 2%
permanent pastures: 1%
forests and woodland: 65%
other: 13% (1993 est.)
Irrigated land: 13,350 sq km (1993 est.)
Natural hazards: occasional typhoons bring high winds and floods;
low-level seismic activity common in southwest
Environment--current issues: air pollution in large cities; water
pollution from the discharge of sewage and industrial effluents;
driftnet fishing
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol,
Desertification
Location: Middle East, bordering the Persian Gulf, between Iraq
and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries:
total: 464 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short, cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 92% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: sudden cloudbursts are common from October to
April; they bring inordinate amounts of rain which can damage roads
and houses; sandstorms and dust storms occur throughout the year,
but are most common between March and August
Environment--current issues: limited natural fresh water
resources; some of world''s largest and most sophisticated
desalination facilities provide much of the water; air and water
pollution; desertification
Environment--international agreements:
party to: Climate Change, Desertification, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered Species, Marine
Dumping
Geography--note: strategic location at head of Persian Gulf
Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent States
Area:
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Area--comparative: slightly smaller than South Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakhstan 1,051 km, Tajikistan 870
km, Uzbekistan 1,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan; subtropical
in southwest (Fergana Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys and basins
encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydroelectric potential; significant
deposits of gold and rare earth metals; locally exploitable coal,
oil, and natural gas; other deposits of nepheline, mercury, bismuth,
lead, and zinc
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other: 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural growth walnut forest
Irrigated land: 9,000 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: water pollution; many people get
their water directly from contaminated streams and wells; as a
result, water-borne diseases are prevalent; increasing soil salinity
from faulty irrigation practices
Environment--international agreements:
party to: Biodiversity, Desertification, Hazardous Wastes
signed, but not ratified: none of the selected agreements
Geography--note: landlocked
Location: Southeastern Asia, northeast of Thailand, west of
Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area--comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km, China 423 km,
Thailand 1,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to November); dry
season (December to April)
Terrain: mostly rugged mountains; some plains and plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum, tin, gold,
gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 40% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
note: rainy season irrigation--2,169 sq km; dry season irrigation--750
sq km (1998 est.)
Natural hazards: floods, droughts, and blight
Environment--current issues: unexploded ordnance; deforestation;
soil erosion; a majority of the population does not have access to
potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: landlocked
Location: Eastern Europe, bordering the Baltic Sea, between
Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,589 sq km
land: 64,589 sq km
water: 0 sq km
Area--comparative: slightly larger than West Virginia
Land boundaries:
total: 1,150 km
border countries: Belarus 141 km, Estonia 339 km, Lithuania 453 km,
Russia 217 km
Coastline: 531 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Natural resources: minimal; amber, peat, limestone, dolomite
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 46%
other: 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: air and water pollution because of a
lack of waste conversion equipment; Gulf of Riga and Daugava River
heavily polluted; contamination of soil and groundwater with
chemicals and petroleum products at military bases
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol','08bf4a490f2934f1f7a0d817f592834ccb211031f10b94f56f643d2cdb92cfc9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c69601d608d3cd66fc740721791d22e31ac6315ebf71e411db667ccd2efebcd',1999,'SN','Senegal','geography',192,'Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area:
total: 11,300 sq km
land: 10,000 sq km
water: 1,300 sq km
Area--comparative: slightly less than twice the size of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (June to November); cooler,
dry season (November to May)
Terrain: flood plain of the Gambia River flanked by some low hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 28%
other: 45% (1993 est.)
Irrigated land: 150 sq km (1993 est.)
Natural hazards: rainfall has dropped by 30% in the last 30 years
Environment--current issues: deforestation; desertification;
water-borne diseases prevalent
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: almost an enclave of Senegal; smallest country on
the continent of Africa
Location: Middle East, bordering the Mediterranean Sea, between
Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area--comparative: slightly more than twice the size of
Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current status subject to
the Israeli-Palestinian Interim Agreement--permanent status to be
determined through further negotiation
Climate: temperate, mild winters, dry and warm to hot summers
Terrain: flat to rolling, sand- and dune-covered coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 11%
other: 26% (1993 est.)
Irrigated land: 120 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: desertification; salination of fresh
water; sewage treatment
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: there are 24 Israeli settlements and civilian
land use sites in the Gaza Strip (August 1998 est.)
Location: Southwestern Asia, bordering the Black Sea, between
Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent States
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area--comparative: slightly smaller than South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on Black Sea coast
Terrain: largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek) 5,048 m
Natural resources: forests, hydropower, manganese deposits, iron
ore, copper, minor coal and oil deposits; coastal climate and soils
allow for important tea and citrus growth
Land use:
arable land: 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other: 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: earthquakes
Environment--current issues: air pollution, particularly in
Rust''avi; heavy pollution of Mtkvari River and the Black Sea;
inadequate supplies of potable water; soil pollution from toxic
chemicals
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Desertification
Location: Central Europe, bordering the Baltic Sea and the North
Sea, between the Netherlands and Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total: 356,910 sq km
land: 349,520 sq km
water: 7,390 sq km
note: includes the formerly separate Federal Republic of Germany,
the German Democratic Republic, and Berlin, following formal
unification on 3 October 1990
Area--comparative: slightly smaller than Montana
Land boundaries:
total: 3,621 km
border countries: Austria 784 km, Belgium 167 km, Czech Republic 646
km, Denmark 68 km, France 451 km, Luxembourg 138 km, Netherlands 577
km, Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate and marine; cool, cloudy, wet winters and
summers; occasional warm, tropical foehn wind; high relative humidity
Terrain: lowlands in north, uplands in center, Bavarian Alps in
south
Elevation extremes:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,962 m
Natural resources: iron ore, coal, potash, timber, lignite,
uranium, copper, natural gas, salt, nickel
Land use:
arable land: 33%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 31%
other: 20% (1993 est.)
Irrigated land: 4,750 sq km (1993 est.)
Natural hazards: flooding
Environment--current issues: emissions from coal-burning utilities
and industries and lead emissions from vehicle exhausts (the result
of continued use of leaded fuels) contribute to air pollution; acid
rain, resulting from sulfur dioxide emissions, is damaging forests;
pollution in the Baltic Sea from raw sewage and industrial effluents
from rivers in eastern Germany; hazardous waste disposal
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: strategic location on North European Plain and
along the entrance to the Baltic Sea
Location: Western Africa, bordering the Gulf of Guinea, between
Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 238,540 sq km
land: 230,020 sq km
water: 8,520 sq km
Area--comparative: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire 668 km, Togo
877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; warm and comparatively dry along southeast
coast; hot and humid in southwest; hot and dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial diamonds, bauxite,
manganese, fish, rubber
Land use:
arable land: 12%
permanent crops: 7%
permanent pastures: 22%
forests and woodland: 35%
other: 24% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: dry, dusty, harmattan winds occur from January
to March; droughts
Environment--current issues: recent drought in north severely
affecting agricultural activities; deforestation; overgrazing; soil
erosion; poaching and habitat destruction threatens wildlife
populations; water pollution; inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Marine Life Conservation
Geography--note: Lake Volta is the world''s largest artificial
lake; northeasterly harmattan wind (January to March)
Location: Southwestern Europe, bordering the Strait of Gibraltar,
which links the Mediterranean Sea and the North Atlantic Ocean, on
the southern coast of Spain
Geographic coordinates: 36 11 N, 5 22 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area--comparative: about 11 times the size of The Mall in
Washington, DC
Land boundaries:
total: 1.2 km
border countries: Spain 1.2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
Climate: Mediterranean with mild winters and warm summers
Terrain: a narrow coastal lowland borders the Rock of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: limited natural freshwater resources;
large concrete or natural rock water catchments collect rain water
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strategic location on Strait of Gibraltar that
links the North Atlantic Ocean and Mediterranean Sea
Location: Southern Africa, group of islands in the Indian Ocean,
northwest of Madagascar
Geographic coordinates: 11 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ile Glorieuse, Ile du Lys, Verte Rocks, Wreck Rock,
and South Rock
Area--comparative: about eight times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment--current issues: NA
Location: Southern Europe, bordering the Aegean Sea, Ionian Sea,
and the Mediterranean Sea, between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
total: 131,940 sq km
land: 130,800 sq km
water: 1,140 sq km
Area--comparative: slightly smaller than Alabama
Land boundaries:
total: 1,210 km
border countries: Albania 282 km, Bulgaria 494 km, Turkey 206 km,
The Former Yugoslav Republic of Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 6 nm
Climate: temperate; mild, wet winters; hot, dry summers
Terrain: mostly mountains with ranges extending into sea as
peninsulas or chains of islands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: bauxite, lignite, magnesite, petroleum, marble
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 41%
forests and woodland: 20%
other: 12% (1993 est.)
Irrigated land: 13,140 sq km (1993 est.)
Natural hazards: severe earthquakes
Environment--current issues: air pollution; water pollution
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Climate
Change-Kyoto Protocol
Geography--note: strategic location dominating the Aegean Sea and
southern approach to Turkish Straits; a peninsular country,
possessing an archipelago of about 2,000 islands','6c55aa3969b5eb70907636f666cba1b9118895e8898f7e126140b724284e3730','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63c8bce60f68b77d748a476f266db4b6020c53bc8b5913fd55d2441a7bcb617b',1999,'GR','Greece','geography',208,'Location: Northern North America, island between the Arctic Ocean
and the North Atlantic Ocean, northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
total: 2,175,600 sq km
land: 2,175,600 sq km (341,600 sq km ice-free, 1,834,000 sq km
ice-covered) (est.)
Area--comparative: slightly more than three times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: arctic to subarctic; cool summers, cold winters
Terrain: flat to gradually sloping icecap covers all but a
narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: zinc, lead, iron ore, coal, molybdenum, gold,
platinum, uranium, fish, seals, whales
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1%
forests and woodland: 0%
other: 99% (1993 est.)
Irrigated land: NA sq km
Natural hazards: continuous permafrost over northern two-thirds
of the island
Environment--current issues: protection of the arctic environment;
preservation of their traditional way of life, including whaling;
note--Greenland participates actively in Inuit Circumpolar Conference
(ICC)
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: dominates North Atlantic Ocean between North
America and Europe; sparse population confined to small settlements
along coast
Location: Caribbean, island between the Caribbean Sea and
Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area--comparative: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater harbors
Land use:
arable land: 15%
permanent crops: 18%
permanent pastures: 3%
forests and woodland: 9%
other: 55% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies on edge of hurricane belt; hurricane season
lasts from June to November
Environment--current issues: NA
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: the administration of the islands of the
Grenadines group is divided between Saint Vincent and the Grenadines
and Grenada
Location: Caribbean, islands in the eastern Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the Caribbean
Area:
total: 1,780 sq km
land: 1,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited islands,
including Basse-Terre, Grande-Terre, Marie-Galante, La Desirade,
Iles des Saintes, Saint Barthelemy, and part of Saint Martin
Area--comparative: 10 times the size of Washington, DC
Land boundaries:
total: 10.2 km
border countries: Netherlands Antilles (Sint Maarten) 10.2 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical tempered by trade winds; moderately high
humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,467 m
Natural resources: cultivable land, beaches and climate that
foster tourism
Land use:
arable land: 14%
permanent crops: 4%
permanent pastures: 14%
forests and woodland: 39%
other: 29% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: hurricanes (June to October); Soufriere is an
active volcano
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA','cf15d1df1768da4c3d1624b6a6402ff5f06bf7ff641bd35f2c15129b4744a16f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66989b431ce38029e0c08638d416d0104f974ee23a9b2de376fac90d027065ae',1999,'MQ','Martinique','geography',213,'Location: Oceania, island in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
total: 541.3 sq km
land: 541.3 sq km
water: 0 sq km
Area--comparative: three times the size of Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; generally warm and humid, moderated by
northeast trade winds; dry season from January to June, rainy season
from July to December; little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs; relatively
flat coralline limestone plateau (source of most fresh water), with
steep coastal cliffs and narrow coastal plains in north, low-rising
hills in center, mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped), tourism
(especially from Japan)
Land use:
arable land: 11%
permanent crops: 11%
permanent pastures: 15%
forests and woodland: 18%
other: 45% (1993 est.)
Irrigated land: NA sq km
Natural hazards: frequent squalls during rainy season; relatively
rare, but potentially very destructive typhoons (especially in
August)
Environment--current issues: extirpation of native bird population
by the rapid proliferation of the brown tree snake, an exotic species
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: largest and southernmost island in the Mariana
Islands archipelago; strategic location in western North Pacific
Ocean
Location: Middle America, bordering the Caribbean Sea, between
Honduras and Belize and bordering the North Pacific Ocean, between
El Salvador and Mexico
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the Caribbean
Area:
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
Area--comparative: slightly smaller than Tennessee
Land boundaries:
total: 1,687 km
border countries: Belize 266 km, El Salvador 203 km, Honduras 256
km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid in lowlands; cooler in highlands
Terrain: mostly mountains with narrow coastal plains and rolling
limestone plateau (Peten)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,211 m
Natural resources: petroleum, nickel, rare woods, fish, chicle
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 24%
forests and woodland: 54%
other: 5% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
Natural hazards: numerous volcanoes in mountains, with occasional
violent earthquakes; Caribbean coast subject to hurricanes and other
tropical storms
Environment--current issues: deforestation; soil erosion; water
pollution; Hurricane Mitch damage
Environment--international agreements:
party to: Antarctic Treaty, Biodiversity, Climate Change,
Desertication, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
Geography--note: no natural harbors on west coast','da48c1d99678b09783717c53a593f9fb4fe40658f60c436a37db41a7700978fe','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69992cec5bdf0a5b40b34e78b0f051a60737b4d816b06c6f5012fe3de05b720',1999,'GT','Guatemala','geography',222,'Location: Western Europe, islands in the English Channel,
northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 194 sq km
land: 194 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and some other
smaller islands
Area--comparative: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
Climate: temperate with mild winters and cool summers; about 50%
of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: large, deepwater harbor at Saint Peter Port
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea-Bissau and Sierra Leone
Geographic coordinates: 11 00 N, 10 00 W
Map references: Africa
Area:
total: 245,860 sq km
land: 245,860 sq km
water: 0 sq km
Area--comparative: slightly smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Guinea-Bissau 386 km, Cote d''Ivoire 610 km,
Liberia 563 km, Mali 858 km, Senegal 330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally hot and humid; monsoonal-type rainy season
(June to November) with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to mountainous
interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: bauxite, iron ore, diamonds, gold, uranium,
hydropower, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 59%
other: 17% (1993 est.)
Irrigated land: 930 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze may reduce
visibility during dry season
Environment--current issues: deforestation; inadequate supplies of
potable water; desertification; soil contamination and erosion;
overfishing, overpopulation in forest region
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected agreements
Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total: 36,120 sq km
land: 28,000 sq km
water: 8,120 sq km
Area--comparative: slightly less than three times the size of
Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; generally hot and humid; monsoonal-type rainy
season (June to November) with southwesterly winds; dry season
(December to May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast corner of the
country 300 m
Natural resources: fish, timber, phosphates, bauxite, unexploited
deposits of petroleum
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 38%
forests and woodland: 38%
other: 12% (1993 est.)
Irrigated land: 17 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze may reduce
visibility during dry season; brush fires
Environment--current issues: deforestation; soil erosion;
overgrazing; overfishing
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected agreements
Location: Northern South America, bordering the North Atlantic
Ocean, between Suriname and Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area:
total: 214,970 sq km
land: 196,850 sq km
water: 18,120 sq km
Area--comparative: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1,119 km, Suriname 600 km, Venezuela 743 km
Coastline: 459 km
Maritime claims:
continental shelf: 200 nm or to the outer edge of the continental
margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid, moderated by northeast trade
winds; two rainy seasons (May to mid-August, mid-November to
mid-January)
Terrain: mostly rolling highlands; low coastal plain; savanna in
south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds, hardwood timber,
shrimp, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 84%
other: 8% (1993 est.)
Irrigated land: 1,300 sq km (1993 est.)
Natural hazards: flash floods are a constant threat during rainy
seasons
Environment--current issues: water pollution from sewage and
agricultural and industrial chemicals; deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: none of the selected agreements
Location: Caribbean, western one-third of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 275 km
border countries: Dominican Republic 275 km
Coastline: 1,771 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; semiarid where mountains in east cut off trade
winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: none
Land use:
arable land: 20%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 5%
other: 44% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane belt and
subject to severe storms from June to October; occasional flooding
and earthquakes; periodic droughts
Environment--current issues: extensive deforestation (much of the
remaining forested land is being cleared for agriculture and used as
fuel); soil erosion; inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Marine Dumping, Marine Life Conservation
signed, but not ratified: Hazardous Wastes, Nuclear Test Ban
Geography--note: shares island of Hispaniola with Dominican
Republic (western one-third is Haiti, eastern two-thirds is the
Dominican Republic)
Location: Southern Africa, islands in the Indian Ocean, about
two-thirds of the way from Madagascar to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
total: 412 sq km
land: 412 sq km
water: 0 sq km
Area--comparative: slightly more than 2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: antarctic
Terrain: Heard Island--bleak and mountainous, with a quiescent
volcano; McDonald Islands--small and rocky
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: Heard Island is dominated by a dormant volcano
called Big Ben
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: primarily used for research stations
Location: Southern Europe, an enclave of Rome (Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area--comparative: about 0.7 times the size of The Mall in
Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September to mid-May)
with hot, dry summers (May to September)
Terrain: low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental Modification
Geography--note: urban; landlocked; enclave of Rome, Italy;
world''s smallest state; outside the Vatican City, 13 buildings in
Rome and Castel Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
Location: Middle America, bordering the Caribbean Sea, between
Guatemala and Nicaragua and bordering the North Pacific Ocean,
between El Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30 W
Map references: Central America and the Caribbean
Area:
total: 112,090 sq km
land: 111,890 sq km
water: 200 sq km
Area--comparative: slightly larger than Tennessee
Land boundaries:
total: 1,520 km
border countries: Guatemala 256 km, El Salvador 342 km, Nicaragua
922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural extension of territory or to 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical in lowlands, temperate in mountains
Terrain: mostly mountains in interior, narrow coastal plains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper, lead, zinc, iron
ore, antimony, coal, fish
Land use:
arable land: 15%
permanent crops: 3%
permanent pastures: 14%
forests and woodland: 54%
other: 14% (1993 est.)
Irrigated land: 740 sq km (1993 est.)
Natural hazards: frequent, but generally mild, earthquakes;
damaging hurricanes and floods along Caribbean coast
Environment--current issues: urban population expanding;
deforestation results from logging and the clearing of land for
agricultural purposes; further land degradation and soil erosion
hastened by uncontrolled development and improper land use practices
such as farming of marginal lands; mining activities polluting Lago
de Yojoa (the country''s largest source of fresh water) as well as
several rivers and streams with heavy metals; severe Hurricane Mitch
damage
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Location: Eastern Asia, bordering the South China Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Area--comparative: six times the size of Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
Climate: tropical monsoon; cool and humid in winter, hot and
rainy from spring through summer, warm and sunny in fall
Terrain: hilly to mountainous with steep slopes; lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor, feldspar
Land use:
arable land: 6%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 20%
other: 72% (1997 est.)
Irrigated land: 20 sq km (1997 est.)
Natural hazards: occasional typhoons
Environment--current issues: air and water pollution from rapid
urbanization
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: more than 200 islands
Location: Oceania, island in the North Pacific Ocean, about
one-half of the way from Hawaii to Australia
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
total: 1.6 sq km
land: 1.6 sq km
water: 0 sq km
Area--comparative: about three times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind, burning sun
Terrain: low-lying, nearly level, sandy, coral island surrounded
by a narrow fringing reef; depressed central area
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 5%
other: 95%
Irrigated land: 0 sq km (1998)
Natural hazards: the narrow fringing reef surrounding the island
can be a maritime hazard
Environment--current issues: no natural fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: almost totally covered with grasses, prostrate
vines, and low-growing shrubs; small area of trees in the center;
primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife
Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area--comparative: slightly smaller than Indiana
Land boundaries:
total: 2,009 km
border countries: Austria 366 km, Croatia 329 km, Romania 443 km,
Serbia and Montenegro 151 km (all with Serbia), Slovakia 515 km,
Slovenia 102 km, Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters; warm summers
Terrain: mostly flat to rolling plains; hills and low mountains
on the Slovakian border
Elevation extremes:
lowest point: Tisza River 78 m
highest point: Kekes 1,014 m
Natural resources: bauxite, coal, natural gas, fertile soils
Land use:
arable land: 51%
permanent crops: 2%
permanent pastures: 13%
forests and woodland: 19%
other: 15% (1993 est.)
Irrigated land: 2,060 sq km (1993 est.)
Environment--current issues: the approximation of Hungary''s
standards in waste management, energy efficiency, and air, soil, and
water pollution with environmental requirements for EU accession
will require large investments, estimated by the Government of
Hungary at $4 billion over six years; the 1997 budget allocated $9.7
million for this purpose; the 1998 budget allocated $11.3 million;
the Central Environmental Fund, which collects monies from product
charges, environmental fines, and mining taxes, provided
approximately $76.2 million in 1997 and is expected to provide
$109.5 million in 1998
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94, Antarctic-Environmental
Protocol, Law of the Sea
Geography--note: landlocked; strategic location astride main land
routes between Western Europe and Balkan Peninsula as well as
between Ukraine and Mediterranean basin
Location: Northern Europe, island between the Greenland Sea and
the North Atlantic Ocean, northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area--comparative: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,988 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by North Atlantic Current; mild,
windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain peaks,
icefields; coast deeply indented by bays and fiords
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,119 m
Natural resources: fish, hydropower, geothermal power, diatomite
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 1%
other: 76% (1993 est.)
Irrigated land: NA sq km
Natural hazards: earthquakes and volcanic activity
Environment--current issues: water pollution from fertilizer
runoff; inadequate wastewater treatment
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Environmental Modification, Marine Life Conservation
Geography--note: strategic location between Greenland and Europe;
westernmost European country; more land covered by glaciers than in
all of continental Europe
Location: Southern Asia, bordering the Arabian Sea and the Bay of
Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total: 3,287,590 sq km
land: 2,973,190 sq km
water: 314,400 sq km
Area--comparative: slightly more than one-third the size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan 605 km, Burma 1,463
km, China 3,380 km, Nepal 1,690 km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical monsoon in south to temperate in
north
Terrain: upland plain (Deccan Plateau) in south, flat to rolling
plain along the Ganges, deserts in west, Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves in the world),
iron ore, manganese, mica, bauxite, titanium ore, chromite, natural
gas, diamonds, petroleum, limestone
Land use:
arable land: 56%
permanent crops: 1%
permanent pastures: 4%
forests and woodland: 23%
other: 16% (1993 est.)
Irrigated land: 480,000 sq km (1993 est.)
Natural hazards: droughts, flash floods, severe thunderstorms
common; earthquakes
Environment--current issues: deforestation; soil erosion;
overgrazing; desertification; air pollution from industrial
effluents and vehicle emissions; water pollution from raw sewage and
runoff of agricultural pesticides; tap water is not potable
throughout the country; huge and rapidly growing population is
overstraining natural resources
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography--note: dominates South Asian subcontinent; near
important Indian Ocean trade routes
Location: body of water between Africa, Antarctica, Asia, and','dca9bcf3e1f975ca921e966b8468291842ad14a721963f9a19fb5ca696621b80','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ce8f63abd623f28cd35fb7850bf8405163e054a6f964528c9d0e99df69e83bf',1999,'FR','France','geography',234,'Location: Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Hawaii to the Marshall Islands
Geographic coordinates: 16 45 N, 169 30 W
Map references: Oceania
Area:
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
Area--comparative: about 4.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but generally dry; consistent northeast trade
winds with little seasonal temperature variation
Terrain: mostly flat
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: NA; guano deposits worked until depletion
about 1890
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: NA
Environment--current issues: no natural fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strategic location in the North Pacific Ocean;
Johnston Island and Sand Island are natural islands, which have been
expanded by coral dredging; North Island (Akau) and East Island
(Hikina) are manmade islands formed from coral dredging; closed to
the public; former US nuclear weapons test site; site of Johnston
Atoll Chemical Agent Disposal System (JACADS); some low-growing
vegetation
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
total: 89,213 sq km
land: 88,884 sq km
water: 329 sq km
Area--comparative: slightly smaller than Indiana
Land boundaries:
total: 1,619 km
border countries: Iraq 181 km, Israel 238 km, Saudi Arabia 728 km,
Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
Climate: mostly arid desert; rainy season in west (November to
April)
Terrain: mostly desert plateau in east, highland area in west;
Great Rift Valley separates East and West Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,754 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 9%
forests and woodland: 1%
other: 85% (1993 est.)
Irrigated land: 630 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: limited natural fresh water
resources; deforestation; overgrazing; soil erosion; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected agreements
Location: Eastern Asia, bordering the South China Sea and China
Geographic coordinates: 22 10 N, 113 33 E
Map references: Southeast Asia
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area--comparative: about 0.1 times the size of Washington, DC
Land boundaries:
total: 0.34 km
border countries: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 174 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1998 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: Ozone Layer Protection (extended from Portugal)
signed, but not ratified: NA
Geography--note: essentially urban; one causeway and two bridges
connect the two islands of Coloane and Taipa to the peninsula on
mainland
Location: Northern Africa, bordering the North Atlantic Ocean,
between Senegal and Western Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1,030,700 sq km
land: 1,030,400 sq km
water: 300 sq km
Area--comparative: slightly larger than three times the size of
New Mexico
Land boundaries:
total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km, Senegal 813 km,
Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara; some central
hills
Elevation extremes:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper, phosphate
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 38%
forests and woodland: 4%
other: 58% (1993 est.)
Irrigated land: 490 sq km (1993 est.)
Natural hazards: hot, dry, dust/sand-laden sirocco wind blows
primarily in March and April; periodic droughts
Environment--current issues: overgrazing, deforestation, and soil
erosion aggravated by drought are contributing to desertification;
very limited natural fresh water resources away from the Senegal
which is the only perennial river
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: most of the population concentrated in the cities
of Nouakchott and Nouadhibou and along the Senegal River in the
southern part of the country
Location: Southern Africa, island in the Indian Ocean, east of
Location: Caribbean, islands in the Caribbean Sea, north of','a9a0fc43914941d324cbdf6cdc771955cef4d3b534e7e0d78ef56e975d87b95c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c45345025131a816abf2adacddcdc3431da143511e1e42291b22a5772fd89436',1999,'CN','China','geography',242,'Location: Southern Africa, island in the Mozambique Channel,
about one-third of the way between Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
Area--comparative: about seven times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth the of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other fertilizers
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: 10%
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: wildlife sanctuary
Location: Central Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references: Commonwealth of Independent States
Area:
total: 2,717,300 sq km
land: 2,669,800 sq km
water: 47,500 sq km
Area--comparative: slightly less than four times the size of Texas
Land boundaries:
total: 12,012 km
border countries: China 1,533 km, Kyrgyzstan 1,051 km, Russia 6,846
km, Turkmenistan 379 km, Uzbekistan 2,203 km
Coastline: 0 km (landlocked)
note: Kazakhstan borders the Aral Sea, now split into two bodies of
water (1,070 km), and the Caspian Sea (1,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers, arid and
semiarid
Terrain: extends from the Volga to the Altai Mountains and from
the plains in western Siberia to oases and desert in Central Asia
Elevation extremes:
lowest point: Vpadina Kaundy -132 m
highest point: Zhengis Shingy (Pik Khan-Tengri) 6,995 m
Natural resources: major deposits of petroleum, natural gas,
coal, iron ore, manganese, chrome ore, nickel, cobalt, copper,
molybdenum, lead, zinc, bauxite, gold, uranium
Land use:
arable land: 12%
permanent crops: 11%
permanent pastures: 57%
forests and woodland: 4%
other: 16% (1996 est.)
Irrigated land: 22,000 sq km (1996 est.)
Natural hazards: earthquakes in the south, mudslides around Almaty
Environment--current issues: radioactive or toxic chemical sites
associated with its former defense industries and test ranges are
found throughout the country and pose health risks for humans and
animals; industrial pollution is severe in some cities; because the
two main rivers which flowed into the Aral Sea have been diverted
for irrigation, it is drying up and leaving behind a harmful layer
of chemical pesticides and natural salts; these substances are then
picked up by the wind and blown into noxious dust storms; pollution
in the Caspian Sea; soil pollution from overuse of agricultural
chemicals and salination from faulty irrigation practices
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: landlocked
Location: Eastern Africa, bordering the Indian Ocean, between
Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Area--comparative: slightly more than twice the size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km, Sudan 232 km,
Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to arid in interior
Terrain: low plains rise to central highlands bisected by Great
Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: gold, limestone, soda ash, salt barites,
rubies, fluorspar, garnets, wildlife
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 37%
forests and woodland: 30%
other: 25% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring drought in northern and eastern
regions; flooding during rainy seasons
Environment--current issues: water pollution from urban and
industrial wastes; degradation of water quality from increased use
of pesticides and fertilizers; deforestation; soil erosion;
desertification; poaching
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the selected agreements
Geography--note: the Kenyan Highlands comprise one of the most
successful agricultural production regions in Africa; glaciers on
Mt. Kenya; unique physiography supports abundant and varied wildlife
of scientific and economic value
Location: Oceania, reef in the North Pacific Ocean, about
one-half of the way from Hawaii to American Samoa
Geographic coordinates: 6 24 N, 162 24 W
Map references: Oceania
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area--comparative: about 1.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderated by prevailing winds
Terrain: low and nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1996)
Natural hazards: wet or awash most of the time, maximum elevation
of about 1 meter makes Kingman Reef a maritime hazard
Environment--current issues: none
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: barren coral atoll with deep interior lagoon;
closed to the public
Location: Oceania, group of islands in the Pacific Ocean,
straddling the equator, about one-half of the way from Hawaii to
Australia; note--on 1 January 1995, Kiribati unilaterally moved the
International Date Line from the middle of the country to include
its easternmost islands and make it the same day throughout the
country
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total: 717 sq km
land: 717 sq km
water: 0 sq km
note: includes three island groups--Gilbert Islands, Line Islands,
Phoenix Islands
Area--comparative: four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine, hot and humid, moderated by trade winds
Terrain: mostly low-lying coral atolls surrounded by extensive
reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production discontinued in 1979)
Land use:
arable land: NA%
permanent crops: 51%
permanent pastures: NA%
forests and woodland: 3%
other: 46% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons can occur any time, but usually
November to March; occasional tornadoes
Environment--current issues: heavy pollution in lagoon of south
Tarawa atoll due to heavy migration mixed with traditional practices
such as lagoon latrines and open-pit dumping; ground water at risk
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertication, Endangered
Species, Marine Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: 20 of the 33 islands are inhabited; Banaba (Ocean
Island) in Kiribati is one of the three great phosphate rock islands
in the Pacific Ocean--the others are Makatea in French Polynesia and','d9a4f6be08d7f082c926b66c7fea9d9a2e4e51a310f773ed28a055ef1dba8ade','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f26e9d48eef4ff1ad4b2d2e079b17425bc6e474606598c7d441af1e8fc54901',1999,'SE','Sweden','geography',252,'Location: Middle East, bordering the Mediterranean Sea, between
Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area--comparative: about 0.7 times the size of Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers; Lebanon mountains experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt, water-surplus state
in a water-deficit region
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 1%
forests and woodland: 8%
other: 61% (1993 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment--current issues: deforestation; soil erosion;
desertification; air pollution in Beirut from vehicular traffic and
the burning of industrial wastes; pollution of coastal waters from
raw sewage and oil spills
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Environmental Modification, Marine
Dumping, Marine Life Conservation
Geography--note: Nahr al Litani only major river in Near East not
crossing an international boundary; rugged terrain historically
helped isolate, protect, and develop numerous factional groups based
on religion, clan, and ethnicity
Location: Southern Africa, an enclave of South Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,350 sq km
land: 30,350 sq km
water: 0 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot, wet summers
Terrain: mostly highland with plateaus, hills, and mountains
Elevation extremes:
lowest point: junction of the Orange and Makhaleng Rivers 1,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing land, some
diamonds and other minerals
Land use:
arable land: 11%
permanent crops: NA%
permanent pastures: 66%
forests and woodland: NA%
other: 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: periodic droughts
Environment--current issues: population pressure forcing
settlement in marginal areas results in overgrazing, severe soil
erosion, and soil exhaustion; desertification; Highlands Water
Project controls, stores, and redirects water to South Africa
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Marine Life
Conservation, Ozone Layer Protection
signed, but not ratified: Endangered Species, Law of the Sea, Marine
Dumping
Geography--note: landlocked; surrounded by South Africa
Location: Western Africa, bordering the North Atlantic Ocean,
between Cote d''Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area--comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716 km, Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot days and cool
to cold nights; wet, cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 18%
other: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow from the Sahara
(December to March)
Environment--current issues: tropical rain forest subject to
deforestation; soil erosion; loss of biodiversity; pollution of
coastal waters from oil residue and raw sewage
Environment--international agreements:
party to: Desertification, Endangered Species, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: Biodiversity, Climate Change,
Environmental Modification, Law of the Sea, Marine Dumping, Marine
Life Conservation
Location: Northern Africa, bordering the Mediterranean Sea,
between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
Area--comparative: slightly larger than Alaska
Land boundaries:
total: 4,383 km
border countries: Algeria 982 km, Chad 1,055 km, Egypt 1,150 km,
Niger 354 km, Sudan 383 km, Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 12 nm
note: Gulf of Sidra closing line--32 degrees 30 minutes north
Climate: Mediterranean along coast; dry, extreme desert interior
Terrain: mostly barren, flat to undulating plains, plateaus,
depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 91% (1993 est.)
Irrigated land: 4,700 sq km (1993 est.)
Natural hazards: hot, dry, dust-laden ghibli is a southern wind
lasting one to four days in spring and fall; dust storms, sandstorms
Environment--current issues: desertification; very limited natural
fresh water resources; the Great Manmade River Project, the largest
water development scheme in the world, is being built to bring water
from large aquifers under the Sahara to coastal cities
Environment--international agreements:
party to: Desertification, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: Biodiversity, Climate Change, Law of the
Sea','91fa9a28a79eb0ff908f85a5a0bef8a67d1bd31ac0bee43599a06d2f501d7b0b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3c70f40f353721421bb44d7c1d159edf675c60ff9f5166a414488d23a98c8f',1999,'EG','Egypt','geography',261,'Location: Central Europe, between Austria and Switzerland
Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
total: 160 sq km
land: 160 sq km
water: 0 sq km
Area--comparative: about 0.9 times the size of Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 35 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with frequent snow or
rain; cool to moderately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine Valley in western
third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources: hydroelectric potential
Land use:
arable land: 24%
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 35%
other: 25% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Ozone Layer Protection,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Law of the Sea
Geography--note: along with Uzbekistan, one of only two doubly
landlocked countries in the world; variety of microclimatic
variations based on elevation
Location: Eastern Europe, bordering the Baltic Sea, between
Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total: 65,200 sq km
land: 65,200 sq km
water: 0 sq km
Area--comparative: slightly larger than West Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km, Poland 91 km,
Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims:
territorial sea: 12 nm
Climate: transitional, between maritime and continental; wet,
moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines/Kalnas 292 m
Natural resources: peat
Land use:
arable land: 35%
permanent crops: 12%
permanent pastures: 7%
forests and woodland: 31%
other: 15% (1993 est.)
Irrigated land: 430 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: contamination of soil and groundwater
with petroleum products and chemicals at military bases
Environment--international agreements:
party to: Biodiversity, Climate Change, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Location: Western Europe, between France and Germany
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area--comparative: slightly smaller than Rhode Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km, Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters, cool summers
Terrain: mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle floodplain in the southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Burgplatz 559 m
Natural resources: iron ore (no longer exploited)
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21%
other: 34%
Irrigated land: 10 sq km (including Belgium (1993 est.)
Natural hazards: NA
Environment--current issues: air and water pollution in urban areas
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol, Environmental
Modification, Law of the Sea
Geography--note: landlocked','9fcd716ce36f0cad6cafbba9075d140d5c688422d6894efab6c7feb0a750e6c9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9b4823652c600aebd445b04a7c513a8236a9aa40de1e37fdb765f32b174f9d0',1999,'HK','Hong Kong','geography',271,'Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area--comparative: slightly larger than Vermont
Land boundaries:
total: 748 km
border countries: Albania 151 km, Bulgaria 148 km, Greece 228 km,
Serbia and Montenegro 221 km (all with Serbia)
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and autumns and relatively cold
winters with heavy snowfall
Terrain: mountainous territory covered with deep basins and
valleys; three large lakes, each divided by a frontier line; country
bisected by the Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Golem Korab (Majae Korabit) 2,753 m
Natural resources: chromium, lead, zinc, manganese, tungsten,
nickel, low-grade iron ore, asbestos, sulfur, timber
Land use:
arable land: 24%
permanent crops: 2%
permanent pastures: 25%
forests and woodland: 39%
other: 10% (1993 est.)
Irrigated land: 830 sq km (1993 est.)
Natural hazards: high seismic risks
Environment--current issues: air pollution from metallurgical
plants
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: landlocked; major transportation corridor from
Western and Central Europe to Aegean Sea and Southern Europe to
Western Europe
Location: Southern Africa, island in the Indian Ocean, east of','ebcbc4cd443d4c75b10d109354eb38cbdc5e520f2cdfd9737f3822e92252d948','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f7dccb0c3a983bb5689daea37ac0c15aa04610cf78ded4491470c323595c26',1999,'TH','Thailand','geography',278,'Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area:
total: 1.24 million sq km
land: 1.22 million sq km
water: 20,000 sq km
Area--comparative: slightly less than twice the size of Texas
Land boundaries:
total: 7,243 km
border countries: Algeria 1,376 km, Burkina Faso 1,000 km, Guinea
858 km, Cote d''Ivoire 532 km, Mauritania 2,237 km, Niger 821 km,
Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry February to June;
rainy, humid, and mild June to November; cool and dry November to
February
Terrain: mostly flat to rolling northern plains covered by sand;
savanna in south, rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates, kaolin, salt, limestone,
uranium, bauxite, iron ore, manganese, tin, and copper deposits are
known but not exploited
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 6%
other: 67% (1993 est.)
Irrigated land: 780 sq km (1993 est.)
Natural hazards: hot, dust-laden harmattan haze common during dry
seasons; recurring droughts
Environment--current issues: deforestation; soil erosion;
desertification; inadequate supplies of potable water; poaching
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Geography--note: landlocked','8a689a9fa3ea6b3a6323c12d1bd9a2380c3da0541676de0d529747fe1e59fdb9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('245a45cd11261cb8e984e0b845fe9b17396d41faa0882990f413836dd04fa790',1999,'MT','Malta','geography',287,'Location: Western Europe, island in the Irish Sea, between Great
Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 588 sq km
land: 588 sq km
water: 0 sq km
Area--comparative: slightly more than three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 113 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
Climate: cool summers and mild winters; humid; overcast about
half the time
Terrain: hills in north and south bisected by central valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: Snaefell 620 m
Natural resources: lead, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 32%
other: 0%
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: one small islet, the Calf of Man, lies to the
southwest, and is a bird sanctuary
Location: Oceania, group of atolls and reefs in the North Pacific
Ocean, about one-half of the way from Hawaii to Papua New Guinea
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
Area:
total: 181.3 sq km
land: 181.3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, and Kwajalein
Area--comparative: about the size of Washington, DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: wet season from May to November; hot and humid; islands
border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine products, deep
seabed minerals
Land use:
arable land: NA%
permanent crops: 60%
permanent pastures: NA%
forests and woodland: NA%
other: 40%
Irrigated land: NA sq km
Natural hazards: occasional typhoons
Environment--current issues: inadequate supplies of potable water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertication, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: two archipelagic island chains of 30 atolls and
1,152 islands; Bikini and Enewetak are former US nuclear test sites;
Kwajalein, the famous World War II battleground, is now used as a US
missile test range
Location: Caribbean, island in the Caribbean Sea, north of','eb00ba1513a9e6987d3b7181a2d195aa633ce071b94407800de8299066682504','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ecb6cae62f2acce92fa09053b2cfe70b6778aad7a8c19ea831e51348e8d0159',1999,'MG','Madagascar','geography',289,'Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total: 1,860 sq km
land: 1,850 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos Shoals (Saint
Brandon), and Rodrigues
Area--comparative: almost 11 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, modified by southeast trade winds; warm, dry
winter (May to November); hot, wet, humid summer (November to May)
Terrain: small coastal plain rising to discontinuous mountains
encircling central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use:
arable land: 49%
permanent crops: 3%
permanent pastures: 3%
forests and woodland: 22%
other: 23% (1993 est.)
Irrigated land: 170 sq km (1993 est.)
Natural hazards: cyclones (November to April); almost completely
surrounded by reefs that may pose maritime hazards
Environment--current issues: water pollution
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected agreements
Location: Southern Africa, island in the Mozambique Channel,
about one-half of the way from northern Madagascar to northern
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
total: 2,510 sq km
land: 2,500 sq km
water: 10 sq km
Area--comparative: slightly smaller than Rhode Island
Land boundaries: 0 km
Coastline: 201 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but temperature moderates with elevation; cool
and dry from May to November, hot and rainy from November to April
Terrain: mostly rugged and mountainous; fertile lowlands along
coast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land
Land use:
arable land: 17%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 35%
other: 41% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: periodic, devastating cyclones (December to
April); Piton de la Fournaise on the southeastern coast is an active
volcano
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Southeastern Europe, bordering the Black Sea, between
Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Area--comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km, Moldova 450 km,
Serbia and Montenegro 476 km (all with Serbia), Ukraine (north) 362
km, Ukraine (east) 169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; cold, cloudy winters with frequent snow and
fog; sunny summers with frequent showers and thunderstorms
Terrain: central Transylvanian Basin is separated from the Plain
of Moldavia on the east by the Carpathian Mountains and separated
from the Walachian Plain on the south by the Transylvanian Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining), timber,
natural gas, coal, iron ore, salt
Land use:
arable land: 41%
permanent crops: 3%
permanent pastures: 21%
forests and woodland: 29%
other: 6% (1993 est.)
Irrigated land: 31,020 sq km (1993 est.)
Natural hazards: earthquakes most severe in south and southwest;
geologic structure and climate promote landslides
Environment--current issues: soil erosion and degradation; water
pollution; air pollution in south from industrial effluents;
contamination of Danube delta wetlands
Environment--international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol
Geography--note: controls most easily traversable land route
between the Balkans, Moldova, and Ukraine
Location: Northern Asia (that part west of the Urals is sometimes
included with Europe), bordering the Arctic Ocean, between Europe
and the North Pacific Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area:
total: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
Area--comparative: slightly less than 1.8 times the size of the US
Land boundaries:
total: 19,917 km
border countries: Azerbaijan 284 km, Belarus 959 km, China
(southeast) 3,605 km, China (south) 40 km, Estonia 294 km, Finland
1,313 km, Georgia 723 km, Kazakhstan 6,846 km, North Korea 19 km,
Latvia 217 km, Lithuania (Kaliningrad Oblast) 227 km, Mongolia 3,441
km, Norway 167 km, Poland (Kaliningrad Oblast) 206 km, Ukraine 1,576
km
Coastline: 37,653 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: ranges from steppes in the south through humid
continental in much of European Russia; subarctic in Siberia to
tundra climate in the polar north; winters vary from cool along
Black Sea coast to frigid in Siberia; summers vary from warm in the
steppes to cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast
coniferous forest and tundra in Siberia; uplands and mountains along
southern border regions
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Mount El''brus 5,633 m
Natural resources: wide natural resource base including major
deposits of oil, natural gas, coal, and many strategic minerals,
timber
note: formidable obstacles of climate, terrain, and distance hinder
exploitation of natural resources
Land use:
arable land: 8%
permanent crops: 0%
permanent pastures: 4%
forests and woodland: 46%
other: 42% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: permafrost over much of Siberia is a major
impediment to development; volcanic activity in the Kuril Islands;
volcanoes and earthquakes on the Kamchatka Peninsula
Environment--current issues: air pollution from heavy industry,
emissions of coal-fired electric plants, and transportation in major
cities; industrial, municipal, and agricultural pollution of inland
waterways and sea coasts; deforestation; soil erosion; soil
contamination from improper application of agricultural chemicals;
scattered areas of sometimes intense radioactive contamination
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
Geography--note: largest country in the world in terms of area but
unfavorably located in relation to major sea lanes of the world;
despite its size, much of the country lacks proper soils and
climates (either too cold or too dry) for agriculture
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,340 sq km
land: 24,950 sq km
water: 1,390 sq km
Area--comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Democratic Republic of the Congo
217 km, Tanzania 217 km, Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to April,
November to January); mild in mountains with frost and snow possible
Terrain: mostly grassy uplands and hills; relief is mountainous
with altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore), wolframite
(tungsten ore), methane, hydropower
Land use:
arable land: 35%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 22%
other: 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic Birunga
mountains are in the northwest along the border with Democratic
Republic of the Congo
Environment--current issues: deforestation results from
uncontrolled cutting of trees for fuel; overgrazing; soil
exhaustion; soil erosion; widespread poaching
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban
signed, but not ratified: Law of the Sea
Geography--note: landlocked; predominantly rural population
Geographic coordinates: 15 52 S, 54 25 E
Map references: Africa
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area--comparative: about 1.7 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: sandy
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (scattered bushes)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: climatologically important location for
forecasting cyclones; wildlife sanctuary
Location: Northern Africa, bordering the Mediterranean Sea,
between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area--comparative: slightly larger than Georgia
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: 12 nm
Climate: temperate in north with mild, rainy winters and hot, dry
summers; desert in south
Terrain: mountains in north; hot, dry central plain; semiarid
south merges into the Sahara
Elevation extremes:
lowest point: Shatt al Gharsah -17 m
highest point: Jabal ash Shanabi 1,544 m
Natural resources: petroleum, phosphates, iron ore, lead, zinc,
salt
Land use:
arable land: 19%
permanent crops: 13%
permanent pastures: 20%
forests and woodland: 4%
other: 44% (1993 est.)
Irrigated land: 3,850 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: toxic and hazardous waste disposal is
ineffective and presents human health risks; water pollution from
raw sewage; limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography--note: strategic location in central Mediterranean
Location: southwestern Asia (that part west of the Bosporus is
sometimes included with Europe), bordering the Black Sea, between
Bulgaria and Georgia, and bordering the Aegean Sea and the
Mediterranean Sea, between Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area--comparative: slightly larger than Texas
Land boundaries:
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km, Bulgaria 240 km,
Georgia 252 km, Greece 206 km, Iran 499 km, Iraq 331 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only: to the maritime boundary
agreed upon with the former USSR
territorial sea: 6 nm in the Aegean Sea; 12 nm in Black Sea and in
Mediterranean Sea
Climate: temperate; hot, dry summers with mild, wet winters;
harsher in interior
Terrain: mostly mountains; narrow coastal plain; high central
plateau (Anatolia)
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal, chromium, mercury, copper,
borate, sulfur, iron ore
Land use:
arable land: 32%
permanent crops: 4%
permanent pastures: 16%
forests and woodland: 26%
other: 22% (1993 est.)
Irrigated land: 36,740 sq km (1993 est.)
Natural hazards: very severe earthquakes, especially in northern
Turkey, along an arc extending from the Sea of Marmara to Lake Van
Environment--current issues: water pollution from dumping of
chemicals and detergents; air pollution, particularly in urban
areas; deforestation; concern for oil spills from increasing
Bosporus ship traffic
Environment--international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Hazardous Wastes, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental Protocol,
Environmental Modification
Geography--note: strategic location controlling the Turkish
Straits (Bosporus, Sea of Marmara, Dardanelles) that link Black and
Aegean Seas
Location: Central Asia, bordering the Caspian Sea, between Iran
and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent States
Area:
total: 488,100 sq km
land: 488,100 sq km
water: 0 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km, Kazakhstan 379
km, Uzbekistan 1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea (1,768 km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadina Akchanaya -81 m (note--Sarygamysh Koli is a
lake in north eastern Turkmenistan whose water levels fluctuate
widely; at its shallowest, its level is -110 m; it is presently at
-60 m, 20 m above Vpadina Akchanaya)
highest point: Ayrybaba 3,139 m
Natural resources: petroleum, natural gas, coal, sulfur, salt
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 63%
forests and woodland: 8%
other: 26% (1993 est.)
Irrigated land: 13,000 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: contamination of soil and groundwater
with agricultural chemicals, pesticides; salination, water-logging
of soil due to poor irrigation methods; Caspian Sea pollution;
diversion of a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish the
Aral Sea; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: landlocked','f968cbcfd9c8c2e2fd43ab4f198e464486877535318d0ba80c299cf24eb31bc2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('277318f56db140ab90d2f420d09cba53a5e4409bb1b838cce473beeb0946a08c',1999,'HN','Honduras','geography',300,'Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1.267 million sq km
land: 1,266,700 sq km
water: 300 sq km
Area--comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km, Burkina Faso 628 km,
Chad 1,175 km, Libya 354 km, Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in extreme south
Terrain: predominately desert plains and sand dunes; flat to
rolling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Greboun 1,944 m
Natural resources: uranium, coal, iron ore, tin, phosphates,
gold, petroleum
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 2%
other: 88% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring droughts
Environment--current issues: overgrazing; soil erosion;
deforestation; desertification; wildlife populations (such as
elephant, hippopotamus, giraffe, and lion) threatened because of
poaching and habitat destruction
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Law of the
Sea
Geography--note: landlocked
Location: Western Africa, bordering the Gulf of Guinea, between
Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total: 923,770 sq km
land: 910,770 sq km
water: 13,000 sq km
Area--comparative: slightly more than twice the size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1,690 km, Chad 87 km, Niger
1,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: varies; equatorial in south, tropical in center, arid in
north
Terrain: southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: petroleum, tin, columbite, iron ore, coal,
limestone, lead, zinc, natural gas
Land use:
arable land: 33%
permanent crops: 3%
permanent pastures: 44%
forests and woodland: 12%
other: 8% (1993 est.)
Irrigated land: 9,570 sq km (1993 est.)
Natural hazards: periodic droughts
Environment--current issues: soil degradation; rapid
deforestation; desertification; recent droughts in north severely
affecting marginal agricultural activities
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Location: Oceania, island in the South Pacific Ocean, east of','78aaab2e14c5b7716fced8acd83f2cea095512aa817e6743c848af19d29a524c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37cb0398fc413081afe27297934b0cdfeba3c9118d70cd6d9b082836fd5f33f4',1999,'TO','Tonga','geography',307,'Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area--comparative: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 4%
forests and woodland: 19%
other: 50% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons
Environment--current issues: traditional methods of burning brush
and trees to clear land for agriculture have threatened soil
supplies which are not naturally very abundant
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification
signed, but not ratified: Climate Change-Kyoto Protocol, Law of the
Sea
Geography--note: one of world''s largest coral islands
Location: Oceania, island in the South Pacific Ocean, east of','795bd14cba829e2b1baf668c67ea8040c8675b4ec6740ec57b3f9963dd6e2562','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7941fdb8e9a8e93fd7059dbd16d7fde79eb4b21b7ef0b40c3d727ab72620000c',1999,'BR','Brazil','geography',323,'Location: Western South America, bordering the South Pacific
Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area:
total: 1,285,220 sq km
land: 1.28 million sq km
water: 5,220 sq km
Area--comparative: slightly smaller than Alaska
Land boundaries:
total: 6,940 km
border countries: Bolivia 900 km, Brazil 1,560 km, Chile 160 km,
Colombia 2,900 km, Ecuador 1,420 km
Coastline: 2,414 km
Maritime claims:
continental shelf: 200 nm
territorial sea: 200 nm
Climate: varies from tropical in east to dry desert in west
Terrain: western coastal plain (costa), high and rugged Andes in
center (sierra), eastern lowland jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum, timber, fish,
iron ore, coal, phosphate, potash
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 21%
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 12,800 sq km (1993 est.)
Natural hazards: earthquakes, tsunamis, flooding, landslides,
mild volcanic activity
Environment--current issues: deforestation; overgrazing of the
slopes of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers and
coastal waters from municipal and mining wastes
Environment--international agreements:
party to: Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: shares control of Lago Titicaca, world''s highest
navigable lake, with Bolivia
Location: Southeastern Asia, archipelago between the Philippine
Sea and the South China Sea, east of Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
land: 298,170 sq km
water: 1,830 sq km
Area--comparative: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims: measured from claimed archipelagic baselines
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: irregular polygon extending up to 100 nm from
coastline as defined by 1898 treaty; since late 1970s has also
claimed polygonal-shaped area in South China Sea up to 285 nm in
breadth
Climate: tropical marine; northeast monsoon (November to April);
southwest monsoon (May to October)
Terrain: mostly mountains with narrow to extensive coastal
lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel, cobalt, silver,
gold, salt, copper
Land use:
arable land: 19%
permanent crops: 12%
permanent pastures: 4%
forests and woodland: 46%
other: 19% (1993 est.)
Irrigated land: 15,800 sq km (1993 est.)
Natural hazards: astride typhoon belt, usually affected by 15 and
struck by five to six cyclonic storms per year; landslides; active
volcanoes; destructive earthquakes; tsunamis
Environment--current issues: uncontrolled deforestation in
watershed areas; soil erosion; air and water pollution in Manila;
increasing pollution of coastal mangrove swamps which are important
fish breeding grounds
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto Protocol,
Desertification
Location: Oceania, islands in the South Pacific Ocean, about
one-half of the way from Peru to New Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total: 47 sq km
land: 47 sq km
water: 0 sq km
Area--comparative: about 0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: tropical, hot, humid; modified by southeast trade winds;
rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc have been
discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (especially November to March)
Environment--current issues: deforestation (only a small portion
of the original forest remains because of burning and clearing for
settlement)
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
total: 312,683 sq km
land: 304,510 sq km
water: 8,173 sq km
Area--comparative: slightly smaller than New Mexico
Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic 658 km, Germany 456
km, Lithuania 91 km, Russia (Kaliningrad Oblast) 206 km, Slovakia
444 km, Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international treaties
territorial sea: 12 nm
Climate: temperate with cold, cloudy, moderately severe winters
with frequent precipitation; mild summers with frequent showers and
thundershowers
Terrain: mostly flat plain; mountains along southern border
Elevation extremes:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas, silver,
lead, salt
Land use:
arable land: 47%
permanent crops: 1%
permanent pastures: 13%
forests and woodland: 29%
other: 10% (1993 est.)
Irrigated land: 1,000 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: situation has improved since 1989 due
to decline in heavy industry and increased environmental concern by
postcommunist governments; air pollution nonetheless remains serious
because of sulfur dioxide emissions from coal-fired power plants,
and the resulting acid rain has caused forest damage; water
pollution from industrial and municipal sources is also a problem,
as is disposal of hazardous wastes
Environment--international agreements:
party to: Air Pollution, Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
Geography--note: historically, an area of conflict because of flat
terrain and the lack of natural barriers on the North European Plain
Location: Southwestern Europe, bordering the North Atlantic
Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total: 92,391 sq km
land: 91,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area--comparative: slightly smaller than Indiana
Land boundaries:
total: 1,214 km
border countries: Spain 1,214 km
Coastline: 1,793 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime temperate; cool and rainy in north, warmer and
drier in south
Terrain: mountainous north of the Tagus River, rolling plains in
south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on Ilha do Pico in
the Azores 2,351 m
Natural resources: fish, forests (cork), tungsten, iron ore,
uranium ore, marble
Land use:
arable land: 26%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 36%
other: 20% (1993 est.)
Irrigated land: 6,300 sq km (1993 est.)
Natural hazards: Azores subject to severe earthquakes
Environment--current issues: soil erosion; air pollution caused by
industrial and vehicle emissions; water pollution, especially in
coastal areas
Environment--international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Wetlands
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Climate
Change-Kyoto Protocol, Environmental Modification, Nuclear Test Ban,
Tropical Timber 94
Geography--note: Azores and Madeira Islands occupy strategic
locations along western sea approaches to Strait of Gibraltar
Location: Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, east of the Dominican Republic
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the Caribbean
Area:
total: 9,104 sq km
land: 8,959 sq km
water: 145 sq km
Area--comparative: slightly less than three times the size of
Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine, mild; little seasonal temperature
variation
Terrain: mostly mountains, with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1,338 m
Natural resources: some copper and nickel; potential for onshore
and offshore oil
Land use:
arable land: 4%
permanent crops: 5%
permanent pastures: 26%
forests and woodland: 16%
other: 49% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: periodic droughts; hurricanes
Environment--current issues: erosion; occasional drought causing
water shortages
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: important location along the Mona Passage?a key
shipping lane to the Panama Canal; San Juan is one of the biggest
and best natural harbors in the Caribbean; many small rivers and
high central mountains ensure land is well watered; south coast
relatively dry; fertile coastal plain belt in north
Location: Middle East, peninsula bordering the Persian Gulf and','6633dcd688677741065edc3a94129c04b23c90ec8aac6d1f3130e4b0d480993c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3d3aca74897967cbae94075637291ae58338dac034b4e5fd60be15a22ee6662',1999,'SC','Seychelles','geography',332,'Location: Western Africa, bordering the North Atlantic Ocean,
between Guinea and Liberia
Geographic coordinates: 8 30 N, 11 30 W
Map references: Africa
Area:
total: 71,740 sq km
land: 71,620 sq km
water: 120 sq km
Area--comparative: slightly smaller than South Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the depth of exploitation
Climate: tropical; hot, humid; summer rainy season (May to
December); winter dry season (December to April)
Terrain: coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite, iron ore,
gold, chromite
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 31%
forests and woodland: 28%
other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds blow from the
Sahara (November to May); sandstorms, dust storms
Environment--current issues: rapid population growth pressuring
the environment; overharvesting of timber, expansion of cattle
grazing, and slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting natural
resources; overfishing
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Marine Life Conservation, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Location: Southeastern Asia, islands between Malaysia and','172d7eddfe1f4abddebc80dea9ab92d690afa6c3b5498a1b0e1665520ee6634c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('652323db7614a139986b852bc349235f6a44357cd1a368f53552c8be9b7502b8',1999,'GI','Gibraltar','geography',347,'Location: Southeastern Asia, group of reefs and islands in the
South China Sea, about two-thirds of the way from southern Vietnam
to the southern Philippines
Geographic coordinates: 8 38 N, 111 55 E
Map references: Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea mounts
scattered over an area of nearly 410,000 sq km of the central South
China Sea
Area--comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4 m
Natural resources: fish, guano, undetermined oil and natural gas
potential
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: typhoons; serious maritime hazard because of
numerous reefs and shoals
Environment--current issues: NA
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: strategically located near several primary
shipping lanes in the central South China Sea; includes numerous
small islands, atolls, shoals, and coral reefs
Location: Southern Asia, island in the Indian Ocean, south of','ecdb2fb6aae0b7e2dd149c27cf319104ea2f31d6dc083ca2e77161689798c1a7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b37d375e445d74ad30c8c1d8f3d000badb236a2cafa30cfbf04c30fa3355a66',1999,'IN','India','geography',348,'Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
Area--comparative: slightly larger than West Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; northeast monsoon (December to March);
southwest monsoon (June to October)
Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral sands, gems,
phosphates, clay
Land use:
arable land: 14%
permanent crops: 15%
permanent pastures: 7%
forests and woodland: 32%
other: 32% (1993 est.)
Irrigated land: 5,500 sq km (1993 est.)
Natural hazards: occasional cyclones and tornadoes
Environment--current issues: deforestation; soil erosion; wildlife
populations threatened by poaching; coastal degradation from mining
activities and increased pollution; freshwater resources being
polluted by industrial wastes and sewage runoff
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Marine Life Conservation
Geography--note: strategic location near major Indian Ocean sea
lanes
Location: Northern Africa, bordering the Red Sea, between Egypt
and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
Area--comparative: slightly more than one-quarter the size of the
US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1,165 km, Chad 1,360 km,
Democratic Republic of the Congo 628 km, Egypt 1,273 km, Eritrea 605
km, Ethiopia 1,606 km, Kenya 232 km, Libya 383 km, Uganda 435 km
Coastline: 853 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: tropical in south; arid desert in north; rainy season
(April to October)
Terrain: generally flat, featureless plain; mountains in east and
west
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of iron ore, copper,
chromium ore, zinc, tungsten, mica, silver, gold
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 19%
other: 30% (1993 est.)
Irrigated land: 19,460 sq km (1993 est.)
Natural hazards: dust storms
Environment--current issues: inadequate supplies of potable water;
wildlife populations threatened by excessive hunting; soil erosion;
desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: largest country in Africa; dominated by the Nile
and its tributaries
Location: Northern South America, bordering the North Atlantic
Ocean, between French Guiana and Guyana
Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total: 163,270 sq km
land: 161,470 sq km
water: 1,800 sq km
Area--comparative: slightly larger than Georgia
Land boundaries:
total: 1,707 km
border countries: Brazil 597 km, French Guiana 510 km, Guyana 600 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain -2 m
highest point: Wilhelmina Gebergte 1,286 m
Natural resources: timber, hydropower, fish, kaolin, shrimp,
bauxite, gold, and small amounts of nickel, copper, platinum, iron
ore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 0%
forests and woodland: 96%
other: 4% (1993 est.)
Irrigated land: 600 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: deforestation as timber is cut for
export; pollution of inland waterways by small-scale mining
activities
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species, Law of
the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Geography--note: mostly tropical rain forest; great diversity of
flora and fauna that, for the most part, is increasingly threatened
by new development; relatively small population, most of which lives
along the coast
Location: Northern Europe, islands between the Arctic Ocean,
Barents Sea, Greenland Sea, and Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total: 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear Island)
Area--comparative: slightly smaller than West Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing zone: 200 nm unilaterally claimed by Norway but
not recognized by Russia
territorial sea: 4 nm
Climate: arctic, tempered by warm North Atlantic Current; cool
summers, cold winters; North Atlantic Current flows along west and
north coasts of Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land ice covered;
west coast clear of ice about one-half of the year; fjords along
west and north coasts
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, copper, iron ore, phosphate, zinc,
wildlife, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (no trees and the only bushes are crowberry and
cloudberry)
Irrigated land: NA sq km
Natural hazards: ice floes often block up the entrance to
Bellsund (a transit point for coal export) on the west coast and
occasionally make parts of the northeastern coast inaccessible to
maritime traffic
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: northernmost part of the Kingdom of Norway;
consists of nine main islands; glaciers and snowfields cover 60% of
the total area
Location: Southern Africa, between Mozambique and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total: 17,360 sq km
land: 17,200 sq km
water: 160 sq km
Area--comparative: slightly smaller than New Jersey
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa 430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some moderately sloping
plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emlembe 1,862 m
Natural resources: asbestos, coal, clay, cassiterite, hydropower,
forests, small gold and diamond deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 62%
forests and woodland: 7%
other: 20% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: limited supplies of potable water;
wildlife populations being depleted because of excessive hunting;
overgrazing; soil degradation; soil erosion
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species, Nuclear
Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the Sea
Geography--note: landlocked; almost completely surrounded by South
Africa
Location: Northern Europe, bordering the Baltic Sea, Gulf of
Bothnia, Kattegat, and Skagerrak, between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
land: 410,928 sq km
water: 39,036 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: agreed boundaries or midlines
territorial sea: 12 nm (adjustments made to return a portion of
straits to high seas)
Climate: temperate in south with cold, cloudy winters and cool,
partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands; mountains in west
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,111 m
Natural resources: zinc, iron ore, lead, copper, silver, timber,
uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1%
forests and woodland: 68%
other: 24% (1993 est.)
Irrigated land: 1,150 sq km (1993 est.)
Natural hazards: ice floes in the surrounding waters, especially
in the Gulf of Bothnia, can interfere with maritime traffic
Environment--current issues: acid rain damaging soils and lakes;
pollution of the North Sea and the Baltic Sea
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Climate Change-Kyoto Protocol
Geography--note: strategic location along Danish Straits linking
Baltic and North Seas
Location: Central Europe, east of France, north of Italy
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total: 41,290 sq km
land: 39,770 sq km
water: 1,520 sq km
Area--comparative: slightly less than twice the size of New Jersey
Land boundaries:
total: 1,852 km
border countries: Austria 164 km, France 573 km, Italy 740 km,
Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with altitude; cold, cloudy,
rainy/snowy winters; cool to warm, cloudy, humid summers with
occasional showers
Terrain: mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber, salt
Land use:
arable land: 10%
permanent crops: 2%
permanent pastures: 28%
forests and woodland: 32%
other: 28% (1993 est.)
Irrigated land: 250 sq km (1993 est.)
Natural hazards: avalanches, landslides, flash floods
Environment--current issues: air pollution from vehicle emissions
and open-air burning; acid rain; water pollution from increased use
of agricultural fertilizers; loss of biodiversity
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Antarctic-Environmental Protocol, Climate Change-Kyoto
Protocol, Law of the Sea
Geography--note: landlocked; crossroads of northern and southern
Europe; along with southeastern France and northern Italy, contains
the highest elevations in Europe
Location: Middle East, bordering the Mediterranean Sea, between
Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1,295 sq km of Israeli-occupied territory
Area--comparative: slightly larger than North Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan 375 km, Lebanon
375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 nm
territorial sea: 35 nm
Climate: mostly desert; hot, dry, sunny summers (June to August)
and mild, rainy winters (December to February) along coast; cold
weather with snow or sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau; narrow coastal
plain; mountains in west
Elevation extremes:
lowest point: unnamed location near Lake Tiberias -200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phosphates, chrome and manganese
ores, asphalt, iron ore, rock salt, marble, gypsum
Land use:
arable land: 28%
permanent crops: 4%
permanent pastures: 43%
forests and woodland: 3%
other: 22% (1993 est.)
Irrigated land: 9,060 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment--current issues: deforestation; overgrazing; soil
erosion; desertification; water pollution from dumping of raw sewage
and wastes from petroleum refining; inadequate supplies of potable
water
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Environmental Modification
Geography--note: there are 42 Israeli settlements and civilian
land use sites in the Israeli-occupied Golan Heights (August 1998
est.)
Location: Eastern Asia, islands bordering the East China Sea,
Philippine Sea, South China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area--comparative: slightly smaller than Maryland and Delaware
combined
Land boundaries: 0 km
Coastline: 1,448 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; rainy season during southwest monsoon
(June to August); cloudiness is persistent and extensive all year
Terrain: eastern two-thirds mostly rugged mountains; flat to
gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
Natural resources: small deposits of coal, natural gas,
limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 5%
forests and woodland: 55%
other: 15%
Irrigated land: NA sq km
Natural hazards: earthquakes and typhoons
Environment--current issues: air pollution; water pollution from
industrial emissions, raw sewage; contamination of drinking water
supplies; trade in endangered species; low-level radioactive waste
disposal
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent States
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area--comparative: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km, China 414 km, Kyrgyzstan 870
km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild winters;
semiarid to polar in Pamir Mountains
Terrain: Pamir and Alay mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower potential, some
petroleum, uranium, mercury, brown coal, lead, zinc, antimony,
tungsten
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: inadequate sanitation facilities;
increasing levels of soil salinity; industrial pollution; excessive
pesticides; part of the basin of the shrinking Aral Sea suffers from
severe overutilization of available water for irrigation and
associated pollution
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Geography--note: landlocked
Location: Eastern Africa, bordering the Indian Ocean, between
Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,090 sq km
land: 886,040 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and Zanzibar
Area--comparative: slightly larger than twice the size of
California
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km, Malawi 475 km,
Mozambique 756 km, Rwanda 217 km, Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to temperate in
highlands
Terrain: plains along coast; central plateau; highlands in north,
south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin, phosphates, iron ore, coal,
diamonds, gemstones, gold, natural gas, nickel
Land use:
arable land: 3%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 38%
other: 18% (1993 est.)
Irrigated land: 1,500 sq km (1993 est.)
Natural hazards: the tsetse fly; flooding on the central plateau
during the rainy season; drought
Environment--current issues: soil degradation; deforestation;
desertification; destruction of coral reefs threatens marine
habitats; recent droughts affected marginal agriculture
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: Kilimanjaro is highest point in Africa
Location: Southeastern Asia, bordering the Andaman Sea and the
Gulf of Thailand, southeast of Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
Area--comparative: slightly more than twice the size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1,800 km, Cambodia 803 km, Laos 1,754 km,
Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, warm, cloudy southwest monsoon (mid-May
to September); dry, cool northeast monsoon (November to mid-March);
southern isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east; mountains
elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas, tungsten, tantalum,
timber, lead, fish, gypsum, lignite, fluorite
Land use:
arable land: 34%
permanent crops: 6%
permanent pastures: 2%
forests and woodland: 26%
other: 32% (1993 est.)
Irrigated land: 44,000 sq km (1993 est.)
Natural hazards: land subsidence in Bangkok area resulting from
the depletion of the water table; droughts
Environment--current issues: air pollution from vehicle emissions;
water pollution from organic and factory wastes; deforestation; soil
erosion; wildlife populations threatened by illegal hunting
Environment--international agreements:
party to: Climate Change, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Climate Change-Kyoto
Protocol, Law of the Sea
Geography--note: controls only land route from Asia to Malaysia
and Singapore
Location: Western Africa, bordering the Bight of Benin, between
Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total: 56,790 sq km
land: 54,390 sq km
water: 2,400 sq km
Area--comparative: slightly smaller than West Virginia
Land boundaries:
total: 1,647 km
border countries: Benin 644 km, Burkina Faso 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: tropical; hot, humid in south; semiarid in north
Terrain: gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Agou 986 m
Natural resources: phosphates, limestone, marble
Land use:
arable land: 38%
permanent crops: 7%
permanent pastures: 4%
forests and woodland: 17%
other: 34% (1993 est.)
Irrigated land: 70 sq km (1993 est.)
Natural hazards: hot, dry harmattan wind can reduce visibility in
north during winter; periodic droughts
Environment--current issues: deforestation attributable to
slash-and-burn agriculture and the use of wood for fuel; recent
droughts affecting agriculture
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Location: Oceania, group of three islands in the South Pacific
Ocean, about one-half of the way from Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
total: 10 sq km
land: 10 sq km
water: 0 sq km
Area--comparative: about 17 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds (April to November)
Terrain: low-lying coral atolls enclosing large lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NA sq km
Natural hazards: lies in Pacific typhoon belt
Environment--current issues: very limited natural resources and
overcrowding are contributing to emigration to New Zealand
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Location: Oceania, archipelago in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
land: 718 sq km
water: 30 sq km
Area--comparative: four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by trade winds; warm season (December
to May), cool season (May to December)
Terrain: most islands have limestone base formed from uplifted
coral formation; others have limestone overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island 1,033 m
Natural resources: fish, fertile soil
Land use:
arable land: 24%
permanent crops: 43%
permanent pastures: 6%
forests and woodland: 11%
other: 16% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones (October to April); earthquakes and
volcanic activity on Fonuafo''ou
Environment--cur','3fc0a1df12dcbd1a65db4e42e0b3f072a1e92bd198652ecdc248480c767ed734','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('035eadb592ecde49efa9b4284b97658eeba6543405e4ff36e305618f2a2df594',1999,'IN','India','geography',349,'rent issues: deforestation results as more and
more land is being cleared for agriculture and settlement; some
damage to coral reefs from starfish and indiscriminate coral and
shell collectors; overhunting threatens native sea turtle populations
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Law of the
Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected agreements
Geography--note: archipelago of 170 islands (36 inhabited)
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, northeast of Venezuela
Geographic coordinates: 11 00 N, 61 00 W
Map references: Central America and the Caribbean
Area:
total: 5,130 sq km
land: 5,130 sq km
water: 0 sq km
Area--comparative: slightly smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer edge of the continental
margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 15%
permanent crops: 9%
permanent pastures: 2%
forests and woodland: 46%
other: 28% (1993 est.)
Irrigated land: 220 sq km (1993 est.)
Natural hazards: outside usual path of hurricanes and other
tropical storms
Environment--current issues: water pollution from agricultural
chemicals, industrial wastes, and raw sewage; oil pollution of
beaches; deforestation; soil erosion
Environment--international agreements:
party to: Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected agreements
Location: Southern Africa, island in the Indian Ocean, east of','3e900ae51e9fad3a91e830c6a17ad1ed1ca16e15abd99fa8bf3d072895e4faec','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fab838d07a51f6be0f73766ae04115a2131659948c6c217ad4b72563a324c05',1999,'TM','Turkmenistan','geography',363,'Location: Caribbean, two island groups in the North Atlantic
Ocean, southeast of The Bahamas
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area--comparative: 2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; moderated by trade winds; sunny and
relatively dry
Terrain: low, flat limestone; extensive marshes and mangrove
swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 98% (1993 est.)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes
Environment--current issues: limited natural fresh water
resources, private cisterns collect rainwater
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: 30 islands (eight inhabited)
Location: Oceania, island group consisting of nine coral atolls
in the South Pacific Ocean, about one-half of the way from Hawaii to','1568770b88935cad85a347ae438d2b555567dfdbdc402005e455de9e0335431b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e01b8164227a9e0d98d96edf6029389de1a44924ae09d9f24b4ba3f59474b3',1999,'TC','Turks and Caicos Islands','geography',377,'Location: North America, bordering both the North Atlantic Ocean
and the North Pacific Ocean, between Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,629,091 sq km
land: 9,158,960 sq km
water: 470,131 sq km
note: includes only the 50 states and District of Columbia
Area--comparative: about one-half the size of Russia; about
three-tenths the size of Africa; about one-half the size of South
America (or slightly larger than Brazil); slightly larger than
China; about two and one-half times the size of Western Europe
Land boundaries:
total: 12,248 km
border countries: Canada 8,893 km (including 2,477 km with Alaska),
Cuba 29 km (US Naval Base at Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base is leased by the US and thus remains
part of Cuba
Coastline: 19,924 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate, but tropical in Hawaii and Florida,
arctic in Alaska, semiarid in the great plains west of the
Mississippi River, and arid in the Great Basin of the southwest; low
winter temperatures in the northwest are ameliorated occasionally in
January and February by warm chinook winds from the eastern slopes
of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead, molybdenum, phosphates,
uranium, bauxite, gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, petroleum, natural gas, timber
Land use:
arable land: 19%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 30%
other: 26% (1993 est.)
Irrigated land: 207,000 sq km (1993 est.)
Natural hazards: tsunamis, volcanoes, and earthquake activity
around Pacific Basin; hurricanes along the Atlantic and Gulf of
Mexico coasts; tornadoes in the midwest and southeast; mud slides in
California; forest fires in the west; flooding; permafrost in
northern Alaska, a major impediment to development
Environment--current issues: air pollution resulting in acid rain
in both the US and Canada; the US is the largest single emitter of
carbon dioxide from the burning of fossil fuels; water pollution
from runoff of pesticides and fertilizers; very limited natural
fresh water resources in much of the western part of the country
require careful management; desertification
Environment--international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Antarctic-Environmental Protocol, Antarctic Treaty, Climate Change,
Endangered Species, Environmental Modification, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent Organic
Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Desertification, Hazardous Wastes
Geography--note: world''s third-largest country (after Russia and
Canada)','a196b266114f129592307f66caecb0e5431f05006ed437c3aabd65751f9aacce','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f57bb9cf9a5d35082632d57d7a116672f2d58007e956a247055f13b3b8d258f2',1999,'ES','Spain','geography',384,'Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent States
Area:
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area--comparative: slightly larger than California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km, Kazakhstan 2,203 km,
Kyrgyzstan 1,099 km, Tajikistan 1,161 km, Turkmenistan 1,621 km
Coastline: 0 km
note: Uzbekistan includes the southern portion of the Aral Sea with
a 420 km shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot summers, mild
winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Sirdaryo (Syr Darya), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal, gold, uranium,
silver, copper, lead and zinc, tungsten, molybdenum
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 3%
other: 41% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: NA
Environment--current issues: drying up of the Aral Sea is
resulting in growing concentrations of chemical pesticides and
natural salts; these substances are then blown from the increasingly
exposed lake bed and contribute to desertification; water pollution
from industrial wastes and the heavy use of fertilizers and
pesticides is the cause of many human health disorders; increasing
soil salination; soil contamination from agricultural chemicals,
including DDT
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: along with Liechtenstein, one of the only two
doubly landlocked countries in the world
Location: Oceania, group of islands in the South Pacific Ocean,
about three-quarters of the way from Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 14,760 sq km
land: 14,760 sq km
water: 0 sq km
note: includes more than 80 islands
Area--comparative: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed archipelagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by southeast trade winds
Terrain: mostly mountains of volcanic origin; narrow coastal
plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1,877 m
Natural resources: manganese, hardwood forests, fish
Land use:
arable land: 2%
permanent crops: 10%
permanent pastures: 2%
forests and woodland: 75%
other: 11% (1993 est.)
Irrigated land: NA sq km
Natural hazards: tropical cyclones or typhoons (January to
April); volcanism causes minor earthquakes
Environment--current issues: a majority of the population does not
have access to a potable and reliable supply of water; deforestation
Environment--international agreements:
party to: Biodiversity, Climate Change, Endangered Species, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Desertification, Law of the Sea','27f6036dcd5c4b3854e9ac8be573d9b7b3d75df0bd19379fd6bb3dacb97cec87','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa1c82a2c1db76da95e309deb7c447a7e176fbfc049a73ffa1f75a97e92b37ce',1999,'NC','New Caledonia','geography',388,'Location: Northern South America, bordering the Caribbean Sea and
the North Atlantic Ocean, between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America, Central America and the Caribbean
Area:
total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area--comparative: slightly more than twice the size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050 km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
contiguous zone: 15 nm
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in highlands
Terrain: Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources: petroleum, natural gas, iron ore, gold,
bauxite, other minerals, hydropower, diamonds
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 34%
other: 41% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: subject to floods, rockslides, mud slides;
periodic droughts
Environment--current issues: sewage pollution of Lago de Valencia;
oil and urban pollution of Lago de Maracaibo; deforestation; soil
degradation; urban and industrial pollution, especially along the
Caribbean coast
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography--note: on major sea and air routes linking North and
South America
Location: Southeastern Asia, bordering the Gulf of Thailand, Gulf
of Tonkin, and South China Sea, alongside China, Laos, and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area--comparative: slightly larger than New Mexico
Land boundaries:
total: 4,639 km
border countries: Cambodia 1,228 km, China 1,281 km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical in south; monsoonal in north with hot, rainy
season (mid-May to mid-September) and warm, dry season (mid-October
to mid-March)
Terrain: low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Natural resources: phosphates, coal, manganese, bauxite,
chromate, offshore oil and gas deposits, forests
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 1%
forests and woodland: 30%
other: 48% (1993 est.)
Irrigated land: 18,600 sq km (1993 est.)
Natural hazards: occasional typhoons (May to January) with
extensive flooding
Environment--current issues: logging and slash-and-burn
agricultural practices contribute to deforestation and soil
degradation; water pollution and overfishing threaten marine life
populations; groundwater contamination limits potable water supply;
growing urban industrialization and population migration are rapidly
degrading environment in Hanoi and Ho Chi Minh City
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol, Nuclear
Test Ban
Location: Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the Caribbean
Area:
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area--comparative: twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical, tempered by easterly trade winds,
relatively low humidity, little seasonal temperature variation;
rainy season May to November
Terrain: mostly hilly to rugged and mountainous with little level
land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 15%
permanent crops: 6%
permanent pastures: 26%
forests and woodland: 6%
other: 47% (1993 est.)
Irrigated land: NA sq km
Natural hazards: several hurricanes in recent years; frequent and
severe droughts and floods; occasional earthquakes
Environment--current issues: lack of natural freshwater resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: important location along the Anegada Passage?a
key shipping lane for the Panama Canal; Saint Thomas has one of the
best natural, deepwater harbors in the Caribbean
Location: Oceania, atoll in the North Pacific Ocean, about
two-thirds of the way from Hawaii to the Northern Mariana Islands
Geographic coordinates: 19 17 N, 166 36 E
Map references: Oceania
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area--comparative: about 11 times the size of The Mall in
Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: atoll of three coral islands built up on an underwater
volcano; central lagoon is former crater, islands are part of the rim
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards: occasional typhoons
Environment--current issues: NA
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: strategic location in the North Pacific Ocean;
emergency landing location for transpacific flights
Location: Oceania, islands in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes Ile Uvea (Wallis Island), Ile Futuna (Futuna Island),
Ile Alofi, and 20 islets
Area--comparative: 1.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (November to April); cool,
dry season (May to October); rains 2,500-3,000 mm per year (80%
humidity); average temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 5%
permanent crops: 20%
permanent pastures: NA%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: deforestation (only small portions of
the original forests remain) largely as a result of the continued
use of wood as the main fuel source; as a consequence of cutting
down the forests, the mountainous terrain of Futuna is particularly
prone to erosion; there are no permanent settlements on Alofi
because of the lack of natural fresh water resources
Environment--international agreements:
party to: NA
signed, but not ratified: NA
Geography--note: both island groups have fringing reefs
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the northwest quarter
of the Dead Sea, but excludes Mt. Scopus; East Jerusalem and
Jerusalem No Man''s Land are also included only as a means of
depicting the entire area occupied by Israel in 1967
Area--comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation vary with
altitude, warm to hot summers, cool to mild winters
Terrain: mostly rugged dissected upland, some vegetation in west,
but barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 32%
forests and woodland: 1%
other: 40%
Irrigated land: NA sq km
Natural hazards: NA
Environment--current issues: adequacy of fresh water supply;
sewage treatment
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography--note: landlocked; highlands are main recharge area for
Israel''s coastal aquifers; there are 216 Israeli settlements and
civilian land use sites in the West Bank and 29 in East Jerusalem
(August 1998 est.)
Location: Northern Africa, bordering the North Atlantic Ocean,
between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area--comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1,561 km, Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 19%
forests and woodland: 0%
other: 81%
Irrigated land: NA sq km
Natural hazards: hot, dry, dust/sand-laden sirocco wind can occur
during winter and spring; widespread harmattan haze exists 60% of
time, often severely restricting visibility
Environment--current issues: sparse water and arable land
Environment--international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Map references: World, Time Zones
Area:
total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is land
Area--comparative: land area about 15 times the size of the US
Land boundaries: the land boundaries in the world total
251,480.24 km (not counting shared boundaries twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most, but can vary
continental shelf: 200-m depth claimed by most or to depth of
exploitation; others claim 200 nm or to the edge of the continental
margin
exclusive fishing zone: 200 nm claimed by most, but can vary
exclusive economic zone: 200 nm claimed by most, but can vary
territorial sea: 12 nm claimed by most, but can vary
note: boundary situations with neighboring states prevent many
countries from extending their fishing or economic zones to a full
200 nm; 43 nations and other areas that are landlocked include
Afghanistan, Andorra, Armenia, Austria, Azerbaijan, Belarus, Bhutan,
Bolivia, Botswana, Burkina Faso, Burundi, Central African Republic,
Chad, Czech Republic, Ethiopia, Holy See (Vatican City), Hungary,
Kazakhstan, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Luxembourg,
Malawi, Mali, Moldova, Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Slovakia, Swaziland, Switzerland, Tajikistan, The Former
Yugoslav Republic of Macedonia, Turkmenistan, Uganda, Uzbekistan,
West Bank, Zambia, Zimbabwe
Climate: two large areas of polar climates separated by two
rather narrow temperate zones from a wide equatorial band of
tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana Trench at 10,924
m in the Pacific Ocean
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,848 m
Natural resources: the rapid using up of nonrenewable mineral
resources, the depletion of forest areas and wetlands, the
extinction of animal and plant species, and the deterioration in air
and water quality (especially in Eastern Europe, the former USSR,
and China) pose serious long-term problems that governments and
peoples are only beginning to address
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 26%
forests and woodland: 32%
other: 31% (1993 est.)
Irrigated land: 2,481,250 sq km (1993 est.)
Natural hazards: large areas subject to severe weather (tropical
cyclones), natural disasters (earthquakes, landslides, tsunamis,
volcanic eruptions)
Environment--current issues: large areas subject to
overpopulation, industrial disasters, pollution (air, water, acid
rain, toxic substances), loss of vegetation (overgrazing,
deforestation, desertification), loss of wildlife, soil degradation,
soil depletion, erosion
Environment--international agreements: selected international
environmental agreements are included under the
Environment--international agreements entry for each country and in
the Selected International Environmental Agreements appendix
Location: Middle East, bordering the Arabian Sea, Gulf of Aden,
and Red Sea, between Oman and Saudi Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen Arab Republic (YAR
or North Yemen), and the former People''s Democratic Republic of
Yemen (PDRY or South Yemen)
Area--comparative: slightly larger than twice the size of Wyoming
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi Arabia 1,458 km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nm in the South
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly desert; hot and humid along west coast; temperate
in western mountains affected by seasonal monsoon; extraordinarily
hot, dry, harsh desert in east
Terrain: narrow coastal plain backed by flat-topped hills and
rugged mountains; dissected upland desert plains in center slope
into the desert interior of the Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt, marble, small
deposits of coal, gold, lead, nickel, and copper, fertile soil in
west
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 30%
forests and woodland: 4%
other: 63% (1993 est.)
Irrigated land: 3,600 sq km (1993 est.)
Natural hazards: sandstorms and dust storms in summer
Environment--current issues: very limited natural fresh water
resources; inadequate supplies of potable water; overgrazing; soil
erosion; desertification
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: strategic location on Bab el Mandeb, the strait
linking the Red Sea and the Gulf of Aden, one of world''s most active
shipping lanes
Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area:
total: 752,610 sq km
land: 740,720 sq km
water: 11,890 sq km
Area--comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km, Democratic Republic of the Congo
1,930 km, Malawi 837 km, Mozambique 419 km, Namibia 233 km, Tanzania
338 km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season (October to
April)
Terrain: mostly high plateau with some hills and mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills 2,301 m
Natural resources: copper, cobalt, zinc, lead, coal, emeralds,
gold, silver, uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 40%
forests and woodland: 39%
other: 14% (1993 est.)
Irrigated land: 460 sq km (1993 est.)
Natural hazards: tropical storms (November to April)
Environment--current issues: air pollution and resulting acid rain
in the mineral extraction and refining region; poaching seriously
threatens rhinoceros and elephant populations; deforestation; soil
erosion; desertification; lack of adequate water treatment presents
human health risks
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Geography--note: landlocked
Location: Southern Africa, northeast of Botswana
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total: 390,580 sq km
land: 386,670 sq km
water: 3,910 sq km
Area--comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique 1,231 km, South Africa
225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy season (November
to March)
Terrain: mostly high plateau with higher central plateau (high
veld); mountains in east
Elevation extremes:
lowest point: junction of the Runde and Save rivers 162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos, gold, nickel,
copper, iron ore, vanadium, lithium, tin, platinum group metals
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 23%
other: 57% (1993 est.)
Irrigated land: 1,930 sq km (1993 est.)
Natural hazards: recurring droughts; floods and severe storms are
rare
Environment--current issues: deforestation; soil erosion; land
degradation; air and water pollution; the black rhinoceros herd--once
the largest concentration of the species in the world--has been
significantly reduced by poaching
Environment--international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography--note: landlocked','2d10b8e700ffa30c0c35674f8eed025284c65ac0c57426d634a3a128a0d8e630','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

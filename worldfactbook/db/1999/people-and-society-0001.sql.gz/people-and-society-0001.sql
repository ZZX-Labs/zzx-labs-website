SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('326eaeded72ad7b87d2bd9575aa9208e0690bbbce0b1800498617a6ec330da3a',1999,'EH','Western Sahara','people-and-society',10,'Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People - note
Population: 239,333 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.34% (1999 est.)
Birth rate: 45.42 births/1,000 population (1999 est.)
Death rate: 16.58 deaths/1,000 population (1999
est.)
Net migration rate: -5.41 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 136.67 deaths/1,000 live
births (1999 est.)
Life expectancy at birth:
total population: 49.1 years
male: 47.98 years
female: 50.57 years (1999 est.)
Total fertility rate: 6.7 children born/woman (1999
est.)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: NA
Population: 5,995,544,836 (July 1999 est.)
Age structure:
0-14 years: 30% (male 934,816,288; female
884,097,095)
530
World (continued)
15-64 years: 63% (male 1 ,905,701 ,066; female
1,861,265,079)
65 years and over: 7% (male 1 79,094,601 ; female
230,570,707) (1999 est.)
Population growth rate: 1.3% (1999 est.)
Birth rate: 22 births/1 ,000 population (1999 est.)
Death rate: 9 deaths/1,000 population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/fema!e
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 56 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63 years
male: 61 years
female: 65 years (1999 est.)
Total fertility rate: 2.8 children born/woman (1 999
est.)','baee488e68ebcf12e036323892ea7d6fb4dbcf201a998a03ac329c6ba1303078','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28f766fb9a0f712df145ac17cba37b3e71d15a4e454f1f10f9e0b5a23f384145',1999,'AF','Afghanistan','people-and-society',17,'Population: 25,824,882 (July 1999 est.)
Age structure:
0-14 years: 43% (male 5,640,841 ; female 5,422,460)
15-64 years: 54% (male 7,273,681 ; female
6,776,750)
65 years and over: 3% (male 374,666; female
336,484) (1999 est.)
Population growth rate: 3.95% (1 999 est.)
note: this rate reflects the continued return of refugees
Birth rate: 41 ,93 births/1 ,000 population (1 999 est.)
Death rate: 17,02 deaths/1,000 population (1999
est.)
Net migration rate: 14.62 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 140.55 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 47.33 years
male: 47.82 years
female: 46.82 years (1 999 est.)
Total fertility rate: 5.94 children born/woman (1 999
est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek
6%, Hazara 19%, minor ethnic groups (Aimaks,
Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
Turkmen) 11%, 30 minor languages (primarily Balochi
and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31 .5%
male: 47.2%
female: 15% (1995 est.)
Population: 16,863 (July 1999 est.)
Age structure:
0-14 years: 32% (male 2,777; female 2,697)
15-64 years: 63% (male 5,619; female 5,085)
65 years and over: 5% (male 305; female 380) (1 999
est.)
Population growth rate: 3.65% (1999 est.)
Birth rate: 26.39 births/1,000 population (1999 est.)
Death rate: 4.86 deaths/1 ,000 population (1 999 est.)
Net migration rate: 15 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 .07 male(s)/female (1999 est.)
Infant mortality rate: 21.11 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.35 years
male: 70.4 years
female: 74.4 years (1999 est.)
Total fertility rate: 3.28 children born/woman (1999
est.)
Nationality:
noun: none
adjective: none
Ethnic groups: black
Religions: Baptist 41.2%, Methodist 18.9%,
Anglican 18.3%, Seventh-Day Adventist 1 .7%, other
19.9% (1980)
Languages: English (official)
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)','4138018532f7adcada039e09b0870a00073708036f39d2e42e4907df1f47b474','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b66d1845d2c48a5b851fdc64c9aeb1a41ad6bc56128a60d9af04ceecef1484ea',1999,'AL','Albania','people-and-society',24,'Population: 3,364,571 (July 1999 est.)
Age structure:
0-14 years: 33% (male 568,642; female 530,088)
15-64 years: 61 % (male 957,561 ; female 1 ,1 05,870)
65 years and over: 6% (male 84,280; female
118,130) (1999 est.)
Population growth rate: 1 .05% (1 999 est.)
Birth rate: 20.74 births/1,000 population (1999 est.)
Death rate: 7.35 deaths/1 ,000 population (1 999 est.)
Net migration rate: -2.93 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.87 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 42.9 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69 years
male: 65.92 years
female: 72.33 years (1 999 est.)
Total fertility rate: 2.5 children born/woman (1999
est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2%
(Vlachs, Gypsies, Serbs, and Bulgarians) (1989 est.)
note: in 1 989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: all mosques and churches were closed in 1967
and religious observances prohibited; in November
1990, Albania began allowing private religious
practice
Languages: Albanian (Tosk is the official dialect),
Greek
Literacy:
definition: age 9 and over can read and write
total population: 93%
male: NA%
female: NA% (1997 est.)
3
Albania (continued)
Population: 31,133,486 (July 1999 est.)
Age structure:
0-14 years: 37% (male 5,911,910; female 5,696,538)
15-64 years: 59% (male 9,255,702; female
9,063,954)
65 years and over: 4% (male 559,570; female
645,812) (1999 est.) •
Population growth rate: 2.1% (1999 est.)
Birth rate: 27 births/1 ,000 population (1999 est.)
Death rate: 5.52 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.49 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 43.82 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.24 years
male: 68.07 years
female: 70.46 years (1999 est.)
Total fertility rate: 3.27 children born/woman (1999
est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1%
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 61 .6%
male: 73.9%
female: 49% (1995 est.)','01da3074c72178ac1287bf620aa18cee83f1ad74f26c09116afa1c3a11ed669c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('299fc6b038596b30e856062deee31163304ba8847a3f76d093fce5d5fe10ab86',1999,'AS','American Samoa','people-and-society',33,'Population: 63,786 (July 1999 est.)
Age structure:
0-14 years: 39% (male 12,840; female 12,074)
15-64 years: 56% (male 17,933; female 18,035)
65 years and over: 5% (male 1 ,494; female 1 ,41 0)
(1999 est.)
Population growth rate: 2.64% (1999 est.)
Birth rate: 26,53 births/1,000 population (1999 est.)
Death rate: 4,04 deaths/1 ,000 population (1 999 est.)
Net migration rate: 3.92 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 mate(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1 .06 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 10.19 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.46 years
male: 71.23 years
female: 79.95 years (1999 est.)
Total fertility rate: 3.66 children born/woman (1999
est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions: Christian Congregationalist 50%, Roman
Catholic 20%, Protestant denominations and other
30%
Languages: Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
Population: 65,939 (July 1999 est.)
Age structure:
0-14 years: 14% (male 4,880; female 4,527)
15-64 years: 73% (male 25,81 1 ; female 22,444)
65 years and over: 1 3% (male 4,1 96; female 4,081 )
(1999 est.)
Population growth rate: 2.24% (1999 est.)
Birth rate: 1 0.27 births/1 ,000 population (1 999 est.)
Death rate: 5.46 deaths/1 ,000 population (1 999 est.)
Net migration rate: 17.61 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1 .06 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1 .12 male(s)/female (1999 est.)
Infant mortality rate: 4.08 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 83.46 years
male: 80.55 years
female: 86.55 years (1999 est.)
Total fertility rate: 1 .25 children born/woman (1 999
est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 61%, Andorran 30%,
French 6%, other 3%
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy: NA','6c157ce31778256c2845e4288b57e5a12967a73625c796278b3aebc8fc1efbef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fef9aa57ec0b6547f124a35a90d0ab7e7771ec4efdb74901191b65de6829c7f',1999,'AO','Angola','people-and-society',40,'Population: 11,177,537 (July 1999 est.)
Age structure:
0-14 years: 45% (male 2,545,006; female 2,473,732)
15-64 years: 52% (male 2,938,178; female
2,909,844)
65 years and over: 3% (male 143,074; female
167,703) (1999 est.)
Population growth rate: 2.84% (1999 est.)
Birth rate: 43.1 1 births/1 ,000 population (1999 est.)
Death rate: 16.35 deaths/1,000 population (1999
est.)
Net migration rate: 1 .6 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 129.19 deaths/1,000 live
births (1999 est.)
Life expectancy at birth:
total population: 48.39 years
male: 46.08 years
female: 50.82 years (1999 est.)
Total fertility rate: 6.12 children born/woman (1999
est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 13%, mestico (mixed European and Native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (1998 est.)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1998 est.)
11
Angola (continued)','653a9a04258fbe51eb5f9ac988909c9a77abd0f640609b20c052a4d89c1d6901','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50e5ece5bc9c41ebbe0fcf197609b410f12c86e075f980a36421e67d102df917',1999,'AI','Anguilla','people-and-society',49,'Population: 11,510 (July 1999 est.)
Age structure:
0-14 years: 27% (male 1 ,581 ; female 1 ,529)
15-64 years: 66% (male 3,874; female 3,695)
65 years and over: 7% (male 366; female 465) (1 999
est.)
Population growth rate: 3.16% (1999 est.)
Birth rate: 16.68 births/1,000 population (1999 est.)
Death rate: 5.3 deaths/1,000 population (1999 est.)
Net migration rate: 20.24 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 18.72 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77. 71 years
male: 74.72 years
female: 80.78 years (1999 est.)
Total fertility rate: 1 .95 children born/woman (1 999
est.)
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)','f41094904281853328a0dd3077015d12b811518c46394a33c75ea3580805d594','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d3b106c904e2539eab3b663d91046b58d75666e31529c885157335d3dd5f5e',1999,'AQ','Antarctica','people-and-society',54,'Population: no indigenous inhabitants, but there are
seasonally staffed research stations
note: approximately 29 nations, all signatory to the
Antarctic Treaty, send personnel to perform seasonal
(summer) and year-round research on the continent
and in its surrounding oceans; the population of
persons doing and supporting science on the
continent and its nearby islands south of 60 degrees
south latitude (the region covered by the Antarctic
T reaty) varies from approximately 4,000 in summer to
1 ,000 in winter; in addition, approximately 1 ,000
personnel including ship''s crew and scientists doing
onboard research are present in the waters of the
treaty region; Summer (January) population - 3,687
total; Argentina 302, Australia 201 , Belgium 1 3, Brazil
80, Bulgaria 16, Chile 352, China 70, Finland 11,
France 100, Germany 51, India 60, Italy 106, Japan
136, South Korea 14, Netherlands 10, NZ60, Norway
40, Peru 28, Poland 70, Russia 254, South Africa 80,
Spain 43, Sweden 20, UK 192, US 1,378 (1998-99);
Winter (July) population - 964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France
33, Germany 9, India 25, Japan 40, South Korea 14,
NZ 10, Poland 20, Russia 102, South Africa 10, UK
39, US 248 (1998-99); year-round stations - 42 total;
Argentina 6, Australia 4, Brazil 1 , Chile 4, China 2,
Finland 1 , France 1 , Germany 1 , India 1 , Italy 1 , Japan
1 , South Korea 1 , NZ 1 , Norway 1 , Poland 1 , Russia
15
Antarctica (continued)
6, South Africa 1 , Spain 1 , Ukraine 1 , UK 2, US 3,
Uruguay 1 (1 998-99); Summer-only stations - 32 total;
Argentina 3, Australia 4, Bulgaria 1 , Chile 7, Germany
1 , India 1 , Japan 3, NZ 1 , Peru 1 , Russia 3, Sweden
2, UK 5 (1998-99) in addition, during the austral
summer some nations have numerous occupied
locations such as tent camps, summer-long
temporary facilities, and mobile traverses in support of
research','6f32366ddfb70de9b55148d347f7c5de00f87c95125db067fabc1be6bb9e1dc7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d918c84e9cf31dbc38f32eb9907a8ab94a23872ae02b6c102e336fa8dad4168',1999,'AG','Antigua and Barbuda','people-and-society',62,'Population: 64,246 (July 1999 est.)
Age structure:
0-14years: 26% (male 8,414; female 8,137)
15-64 years: 69% (male 21 ,936; female 22,227)
65 years and over: 5% (male 1 ,504; female 2,028)
(1999 est.)
Population growth rate: 0.36% (1999 est.)
Birth rate: 1 6.22 births/1 ,000 population (1 999 est.)
Death rate: 5.76 deaths/1 ,000 population (1 999 est.)
Net migration rate: -6.9 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 maie(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 20.69 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .46 years
male: 69.06 years
female: 73.98 years (1999 est.)
Total fertility rate: 1.72 children born/woman (1999
est.)
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Anglican (predominant), other Protestant
sects, some Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 89%
male: 90%
female: 88% (1960 est.)','dc382bc915666a76ffd673ebbf36333d1b24ddbcc49872ac75ffa4cc9661a187','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bf222d3a2e52d188c1a65d630e4e59fa4a79be79e0a727f2172ca669b024b2b',1999,'AR','Argentina','people-and-society',75,'Population: 36,737,664 (July 1999 est.)
Age structure:
0-14 years: 27% (male 5,124,087; female 4,932,060)
15-64 years: 62% (male 1 1 ,457,399; female
11,469,346)
65 years and over: 1 1 % (male 1 ,553,1 58; female
2,201,614) (1999 est.)
Population growth rate: 1.29% (1999 est.)
Birth rate: 19.91 births/1,000 population (1999 est.)
Death rate: 7.64 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.65 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 1 8.41 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.76 years
male: 71. 13 years
female: 78.56 years (1999 est.)
Total fertility rate: 2.66 children born/woman (1999
est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white 85%, mestizo, Amerindian, or
other nonwhite groups 15%
Religions: nominally Roman Catholic 90% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 6%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
female: 96.2% (1 995 est.)
Population: 5,434,095 (July 1999 est.)
Age structure:
0-14 years: 39% (male 1,086,107; female 1 ,049,833)
15-64 years: 56% (male 1,528,127; female
1,517,213)
65 years and over: 5% (male 1 1 6,761 ; female
136,054) (1999 est.)
Population growth rate: 2.65% (1999 est.)
Birth rate: 31 .87 births/1 ,000 population (1 999 est.)
Death rate: 5.23 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.09 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 36.35 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.43 years
male: 70.47 years
female: 74.49 years (1999 est.)
Total fertility rate: 4.22 children born/woman (1999
est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%, white plus Amerindian 5%
Religions: Roman Catholic 90%, Mennonite and
other Protestant denominations
Languages: Spanish (official), Guarani
Literacy:
definition: age 1 5 and over can read and write
total population: 92. 1 %
male: 93.5%
female: 90.6% (1995 est.)
Population: 26,624,582 (July 1999 est.)
Age structure:
0-14 years: 35% (male 4,786,048; female 4,637,280)
15-64 years: 60% (male 8,045,747; female
7,939,760)
65 years and over: 5% (male 557,252; female
658,495) (1999 est.)
Population growth rate: 1 .93% (1 999 est.)
Birth rate: 26.09 births/1,000 population (1999 est.)
Death rate: 5.7 deaths/1,000 population (1999 est.)
Net migration rate: -1.13 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 38.97 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.38 years
male: 68.08 years
female: 72.78 years (1 999 est.)
Total fertility rate: 3.23 children born/woman (1999
est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 15 and over can read and write
total population: 88.7%
male: 94.5%
female: 83% (1 995 est.)','f34343f8d786d563d4731aa1b0da65dea04a3adc543bbcee5935e2cc649b2a21','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88cc45f20bdcb840bf1fcca16cad7580c8c92ffa7603fbb3589ab656fa354268',1999,'AM','Armenia','people-and-society',79,'Population: 3,409,234 (July 1999 est.)
Age structure:
0-14 years: 25% (male 442,1 17; female 425,561 )
15-64 years: 66% (male 1 ,1 00,334; female
1,148,595)
65 years and over: 9% (male 122,170; female
170,457) (1999 est.)
Population growth rate: -0.38% (1999 est.)
Birth rate: 1 3.53 births/1 ,000 population (1 999 est.)
Death rate: 9.03 deaths/1 ,000 population (1 999 est.)
Net migration rate: -8.26 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (1 999 est.)
Infant mortality rate: 41 .12 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.56 years
male: 62.21 years
female: 71 .1 3 years (1 999 est.)
Total fertility rate: 1 .68 children born/woman (1 999
est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)','e32852f5ca509c625af7944b28011ffb311b14af9ef224d77429daf0f6348789','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eadbcf4707ca8f7985accba13dc90fadd1d4ac51e5bb5f88998075f88e1f6f3',1999,'GE','Georgia','people-and-society',87,'Population: 68,675 (July 1999 est.)
Age structure:
0-14years:22% (male 7,724; female 7,106)
15-64 years: 69% (male 22,723; female 24,747)
65 years and over: 9% (male 2,623; female 3,752)
(1999 est.)
Population growth rate: 0.55% (1999 est.)
Birth rate: 1 3.28 births/1 ,000 population (1 999 est.)
Death rate: 6.48 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1.31 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.09 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0,93 male(s)/female (1999 est.)
Infant mortality rate: 7.84 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.04 years
male: 73.33 years
female: 80.94 years (1999 est.)
Total fertility rate: 1 .8 children born/woman (1 999
est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic groups: mixed white/Caribbean Amerindian
80%
Religions: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy: NA
Population: no indigenous inhabitants
note: there are only seasonal caretakers
Population: 5,066,499 (July 1999 est.)
Age structure:
0-14 years: 21% (male 544,055; female 522,491)
15-64 years: 67% (male 1 ,628,993; female
1,753,527)
65 years and over: 12% (male 236,124; female
381,309) (1999 est.)
Population growth rate: -0.74% (1999 est.)
Birth rate: 1 1 .64 births/1 ,000 population (1 999 est.)
Death rate: 14.3 deaths/1 ,000 population (1999 est.)
Net migration rate: -4.69 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.91 male(s)/female (1999 est.)
infant mortality rate: 52.01 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.63 years
male: 61.13 years
female: 68.32 years (1999 est.)
Total fertility rate: 1 .53 children born/woman (1 999
est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%,
Russian 6.3%, Azeri 5.7%, Ossetian 3%, Abkhaz
1 .8%, other 5%
Religions: Christian Orthodox 75% (Georgian
Orthodox 65%, Russian Orthodox 10%), Muslim 1 1 %,
Armenian Apostolic 8%, unknown 6%
Languages: Georgian 71% (official), Russian 9%,
Armenian 7%, Azeri 6%, other 7%
note: Abkhaz (official in Abkhazia)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est.)','5fd63832bf1a714b39875cc84b6b7ddc1b8e5baa1c1c1b1bf0e76c26818882c1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e17e514f1169404f89adeedc347af22e81b1d73f056b1f52830e47d61517f149',1999,'AU','Australia','people-and-society',92,'Population: 18,783,551 (July 1999 est.)
Age structure:
0-14 years: 21% (male 2,023,569; female 1,926,901)
15-64 years: 66% (male 6,317,045; female
6,172,735)
65 years and over: 1 3% (male 1 ,022,485; female
1,320,816) (1999 est.)
Population growth rate: 0.9% (1999 est.)
Birth rate: 13.21 births/1 ,000 population (1999 est.)
Death rate: 6.9 deaths/1,000 population (1999 est.)
Net migration rate: 2.66 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 5.11 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 80. 1 4 years
28
Australia (continued)
male: 77.22 years
female: 83.23 years (1999 est.)
Total fertility rate: 1.81 children born/woman (1999
est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 11%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)
Population: 8,139,299 (July 1999 est.)
Age structure:
0-14 years: 1 7% (male 702,261 ; female 666,31 0)
15-64 years: 68% (male 2,792,484; female
2,713,397)
65 years and over: 15% (male 478,071 ; female
786,776) (1999 est.)
Population growth rate: 0.09% (1999 est.)
Birth rate: 9.62 births/1,000 population (1999 est.)
Death rate: 10.04 deaths/1 ,000 population (1999
est.)
Net migration rate: 1 .32 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0,61 male(s)/fema!e
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 5.1 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.48 years
male: 74.31 years
female: 80.82 years (1999 est.)
Total fertility rate: 1 .37 children born/woman (1 999
est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 99.4%, Croatian 0.3%,
Slovene 0.2%, other 0.1%
Religions: Roman Catholic 78%, Protestant 5%,
other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 974 est.)
male: NA%
female: NA%
Population: uninhabited
104
Clipperton Island (continued)
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station
Population: 870 (July 1999 est.)
Population growth rate: 1 .15% (1 999 est.)
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, various other languages
Population: 69,398 (July 1999 est.)
Age structure:
0-14 years: 24% (male 8,459; female 8,197)
15-64 years: 74% (male 24,651 ; female 26,949)
65 years and over: 2% (male 550; female 592) (1 999
est.)
Population growth rate: 3.99% (1999 est.)
Birth rate: 22.19 births/1 ,000 population (1999 est.)
Death rate: 2.42 deaths/1 ,000 population (1 999 est.)
Net migration rate: 20.14 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 6.8 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.36 years
male: 72.19 years
female: 78.72 years (1999 est.)
Total fertility rate: 1 .86 children born/woman (1999
est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 96% (1980 est.)','af2683fd09e79206d47add6aa7d9cd2ade88024ee35f7732bc2b890dcdd4022e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c97b41c1ec0dac4271946542c70789c4a7e622aa629a3e29cdf98c6e5ebe95a',1999,'AZ','Azerbaijan','people-and-society',101,'Population: 7,908,224 (July 1999 est.)
Age structure:
0-14 years: 32% (male 1 ,292,018; female 1 ,240,745)
15-64 years: 61% (male 2,361 ,792; female
2,496,721)
65 years and over: 7% (male 202,755; female
314,193) (1999 est.)
Population growth rate: 0.63% (1999 est.)
Birth rate: 21 .58 births/1 ,000 population (1 999 est.)
Death rate: 9.5 deaths/1 ,000 population (1999 est.)
Net migration rate: -5.76 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 82.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63.08 years
male: 58.76 years
female: 67.63 years (1 999 est.)
Total fertility rate: 2.67 children born/woman (1999
est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani Peoples
3.2%, Russian 2.5%, Armenian 2%, other 2.3% (1998
est.)
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
lower
Languages: Azeri 89%, Russian 3%, Armenian 2%,
other 6% (1995 est.)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 283,705 (July 1999 est.)
Age structure:
0-14 years: 27% (male 39,271 ; female 38,740)
15-64 years: 67% (male 92,830; female 96,814)
65 years and over: 6% (male 6,696; female 9,354)
(1999 est.)
Population growth rate: 1 .36% (1 999 est.)
Birth rate: 20.58 births/1 ,000 population (1999 est.)
Death rate: 5.43 deaths/1 ,000 population (1999 est.)
Net migration rate: -1 .55 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 1 8.38 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.25 years
male: 70.94 years
female: 77 .64 years (1999 est.)
Total fertility rate: 2.31 children born/woman (1999
est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 15%
Religions: Baptist 32%, Anglican 20%, Roman
Catholic 1 9%, Methodist 6%, Church of God 6%, other
Protestant 12%, none or unknown 3%, other 2%
Languages: English, Creole (among Haitian
immigrants)
Literacy:
definition: age 1 5 and over can read and write
total population: 98.2%
male: 98.5%
female: 98% (1995 est.)','6d30e7383a49e3c66ceec2a2c15ba372f0bf05f3c057389c82eafd4dda56e958','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61e00ef6ab78cb49e54cb54df7645800e8948ab37ca87b982fca65e21fa5797d',1999,'BH','Bahrain','people-and-society',114,'Population: 629,090 (July 1999 est.)
note: includes 227,801 non-nationals (July 1999 est.)
Age structure:
0-14 years: 31% (male 97,316; female 94,708)
15-64 years: 67% (male 249,594; female 1 69,337)
65 years and over: 2% (male 9,241 ; female 8,894)
(1999 est.)
Population growth rate: 2% (1999 est.)
Birth rate: 21 .86 births/1 ,000 population (1 999 est.)
Death rate: 3.24 deaths/1 ,000 population (1999 est.)
Net migration rate: 1 .42 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .47 male(s)/female
65 years and over: 1 .04 male(s)/female
total population: 1.3 male(s)/female (1999 est.)
Infant mortality rate: 14.81 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.32 years
male: 72.75 years
female: 77.96 years (1999 est.)
Total fertility rate: 2.97 children born/woman (1999
est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 13%, other
Arab 10%, Iranian 8%, other 6%
Religions: Shi''a Muslim 75%, Sunni Muslim 25%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 1 5 and over can read and write
total population: 85.2%
male: 89.1%
female: 79.4% (1995 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; a cemetery and remnants of structures
from early settlement are located near the middle of
the west coast; visited annually by US Fish and
Wildlife Service','2ff53f8b260585dbdfcf19e5d50648ad581d30be8144efde67f49b4c772b9c4c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71591e5010d58a1807d0c819fc8a4c5be7d382c04561d1e13c0ed80bae45e3c0',1999,'BD','Bangladesh','people-and-society',122,'Population: 1 27,1 1 7,967 (July 1 999 est.)
Age structure:
0-14 years: 38% (male 24,516,722; female
23,346,904)
15-64 years: 59% (male 38,441 ,064; female
36,586,743)
65 years and over: 3% (male 2,303,61 3; female
1,922,921) (1999 est.)
Population growth rate: 1.59% (1999 est.)
Birth rate: 25.2 births/1,000 population (1999 est.)
Death rate: 8.5 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.79 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1 .2 male(s)/female
total population: 1 .06 male(s)/female (1999 est.)
Infant mortality rate: 69.68 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 60.6 years
male: 60.73 years
female: 60.46 years (1999 est.)
Total fertility rate: 2.86 children born/woman (1999
est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladesh
Ethnic groups: Bengali 98%, Biharis 250,000,
tribals less than 1 million
Religions: Muslim 88.3%, Hindu 10.5%, other 1 .2%
Languages: Bangla (official), English
Literacy:
definition: age 15 and over can read and write
total population: 38. 1 %
male: 49.4%
female: 26.1% (1995 est.)','0215fbaee21bb003a6a1b442fd8044caa9900ecdae13eb01f0cc5143ce8d9542','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b0727f78b4e00a9fb6927af7f97d5982f4d745dca893f549e4adcaa480bf0c',1999,'BB','Barbados','people-and-society',130,'Population: 259,191 (July 1 999 est.)
Age structure:
0-14 years: 23% (male 30,1 32; female 29,359)
15-64 years: 67% (male 85,437; female 88,131)
65 years and over: 10% (male 9,862; female 16,270)
(1999 est.)
Population growth rate: 0.04% (1999 est.)
Birth rate: 14.46 births/1,000 population (1999 est.)
Death rate: 8.1 6 deaths/1 ,000 population (1 999 est.)
Net migration rate: -5.86 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 16.74 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.98 years
male: 72.22 years
female: 77. 81 years (1999 est.)
Total fertility rate: 1 .83 children born/woman (1 999
est.)
Nationality:
noun: Barbadian(s)
adjective: Barbadian
Ethnic groups: black 80%, white 4%, other 16%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97.4%
male: 98%
female: 96. 8% (1995 est.)','c0ba28127d03b694a2fc805bf3609129d51e74aa61ec82a1e103629996f7524a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa03bb71791ec30370afda9548b39dc4ae8208b4529d769ced15328984c593b2',1999,'MZ','Mozambique','people-and-society',140,'Population: uninhabited
44
Bassas da India (continued)
Population: 562,723 (July 1 999 est.)
Age structure:
0- 14 years: 43% (male 1 20,397; female 1 1 9,945)
15-64 years: 54% (male 1 50,851 ; female 1 54,990)
65 years and over: 3% (male 7,878; female 8,662)
(1999 est.)
Population growth rate: 3.1 1% (1999 est.)
Birth rate: 40.29 births/1 ,000 population (1999 est.)
Death rate: 9.23 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 81 .63 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 60.85 years
male: 58.39 years
female: 63.38 years (1999 est.)
Total fertility rate: 5.43 children born/woman (1999
est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 1 4%
Languages: Arabic (official), French (official),
Comoran (a blend of Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
total population: 57.3%
male: 64.2%
female: 50.4% (1995 est.)
Population: 50,481 ,305 (July 1 999 est.)
Age structure:
0-14 years: 48% (male 12,200,532; female
12,136,372)
15-64 years: 49% (male 12,135,901 ; female
12,692,057)
65 years and over: 3% (male 564,084; female
752,359) (1999 est.)
Population growth rate: 2.96% (1999 est.)
Birth rate: 46.37 births/1,000 population (1999 est.)
Death rate: 14.99 deaths/1,000 population (1999
est.)
Net migration rate: -1.78 migrant(s)/1 ,000
population (1999 est.)
note: in 1994, about a million refugees fled into Zaire
(now called the Democratic Republic of the Congo or
DROC), to escape the fighting between the Hutus and
the Tutsis in Rwanda and Burundi; the outbreak of
widespread fighting in the DROC between rebels and
government forces in October 1996 spurred about
875,000 refugees to return to Rwanda in late 1996
and early 1997; additionally, the DROC is host to
200,000 Angolan, 110,000 Burundi, 100,000
Sudanese, and 15,000 Ugandan refugees; renewed
fighting in the DROC in August 1998 resulted in more
internal displacement and refugee outflows
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0,75 male(s)/female
total population: 0.97 male(s)/female (1 999 est.)
Infant mortality rate: 99.45 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 49.44 years
male: 47.28 years
female: 51 .67 years (1999 est.)
Total fertility rate: 6.45 children born/woman
(1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and traditional beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 1 5 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 77.3%
male: 86.6%
female: 67.7% (1995 est.)
Population: 149,336 (July 1999 est.)
Age structure:
0-14 years: 47% (male 34,838; female 34,798)
15-64 years: 52% (male 42,073; female 35,068)
65 years and over: 1 % (male 1 ,257; female 1 ,302)
(1999 est.)
Population growth rate: 5% (1999 est.)
Birth rate: 46.12 births/1,000 population (1999 est.)
Death rate: 8.9 deaths/1 ,000 population (1999 est.)
Net migration rate: 12.73 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .2 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1 .1 male(s)/female (1999 est.)
Infant mortality rate: 69.06 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 60.02 years
male: 57.61 years
female: 62.51 years (1999 est.)
Total fertility rate: 6.41 children born/woman (1999
est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 99%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
Literacy: NA
Population: 1 9,1 24,335 (July 1 999 est.)
note: the 1997 Mozambican census reported a
population of 16,542,800; other estimates range as
low as 16.9 million
Age structure:
0-14 years: 45% (male 4,236,545; female 4,325,586)
15-64 years: 53% (male 4,941 ,048; female
5,181,282)
65 years and over: 2% (male 182,857; female
257,017) (1999 est.)
Population growth rate: 2.54% (1999 est.)
Birth rate: 42.75 births/1 ,000 population (1999 est.)
Death rate: 17.31 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 1 17.56 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 45.89 years
male: 44.73 years
female: 47.09 years (1 999 est.)
Total fertility rate: 5.88 children born/woman (1999
est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
337
Mozambique (continued)
(Shangaan, Chokwe, Manyika, Sena, Makua, and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 40.1%
male: 57.7%
female: 23.3% (1995 est.)
j Government
Country name:
conventional long form: Republic of Mozambique
conventional short form: Mozambique
local long form: Republica de Mocambique
local short form: Mocambique
Data code: MZ
Government type: republic
Capital: Maputo
Administrative divisions: 1 0 provinces (provincias,
singular - provincia); Cabo Delgado, Gaza,
Inhambane, Manica, Maputo, Nampula, Niassa,
Sofala, Tete, Zambezia
Independence: 25 June 1975 (from Portugal)
National holiday: Independence Day, 25 June
(1975)
Constitution: 30 November 1990
Legal system: based on Portuguese civil law
system and customary law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Joaquim Alberto CHISSANO
(since 6 November 1986); note - before being
popularly elected, CHISSANO was elected president
by Frelimo''s Central Committee 4 November 1986
(reelected by the Committee 30 July 1989)
head of government: Prime Minister Pascoal
MOCUMBI (since NA December 1994)
cabinet: Cabinet
elections: president elected by popular vote for a
five-year term; election last held 27 October 1994
(next to be held NA October 1999); prime minister
appointed by the president
election results: Joaquim Alberto CHISSANO elected
president; percent of vote - Joaquim CHISSANO
53.3%, Afonso DHLAKAMA 33.3%
Legislative branch: unicameral Assembly of the
Republic or Assembleia da Republica (250 seats;
members are directly elected by popular vote on a
secret ballot to serve five-year terms)
elections: last held 27-29 October 1994 (next to be
held NA October 1999)
election results: percent of vote by party - Frelimo
44.33%, Renamo 33.78%, DU 5.15%, other 16.74%;
seats by party - Frelimo 129, Renamo 112, DU 9
Judicial branch: Supreme Court, judges appointed
by the president and judges elected by the Assembly
Political parties and leaders: Front for the
Liberation of Mozambique (Frente de Liberatacao de
Mocambique) or Frelimo [Joaquim Alberto
CHISSANO, chairman]; Mozambique National
Resistance (Resistencia Nacional Mocambicana) or
Renamo [Afonso DHLAKAMA, president]; Democratic
Union or DU [Antonio PALANGE, general secretary];
note - the DU may have broken up into the three
parlies that composed it - Liberal and Democratic
Party of Mozambique, National Democratic Party, and
National Party of Mozambique
International organization participation: ACP,
AfDB, C, CCC, ECA, FAO, G-77, IBRD, ICAO, ICFTU,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO (pending
member), ILO, IMF, IMO, Inmarsat, Intelsat, Interpol,
IOC, IOM (observer), ISO (correspondent), ITU, NAM,
OAU, OIC, SADC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Marcos Geraldo
NAMASHULUA
chancery: Suite 570, 1990 M Street NW, Washington,
DC 20036
telephone: It] (202) 293-7146
FAX: [1] (202) 835-0245
Diplomatic representation from the US:
chief of mission: Ambassador Bryan Dean CURRAN
embassy: Avenida Kenneth Kuanda 193, Maputo
mailing address: P. O. Box 783, Maputo
telephone: [258] (1 ) 492797
FAX: [258] (1)490114
Flag description: three equal horizontal bands of
green (top), black, and yellow with a red isosceles
triangle based on the hoist side; the black band is
edged in white; centered in the triangle is a yellow
five-pointed star bearing a crossed rifle and hoe in
black superimposed on an open white book
Population: 22,113,250 (July 1999 est.)
Age structure:
0-14 years: 22% (male 2,51 5,398; female 2,338,506)
15-64 years: 70% (male 7,825,953; female
7,574,836)
65 years and over: 8% (male 989,040; female
869,51 7) (1999 est.)
Population growth rate: 0.93% (1999 est.)
Birth rate: 14.63 births/1,000 population (1999 est.)
Death rate: 5.32 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.02 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 1.14 male(s)/female
total population: 1 .05 male(s)/female (1999 est.)
Infant mortality rate: 6.01 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.49 years
mate: 74.38 years
female: 80.85 years (1999 est.)
Total fertility rate: 1 .77 children born/woman (1 999
est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
Literacy:
definition: age 15 and over can read and write
total population: 94% (1998 est.)
male: 93% (1980 est.)
female: 79% (1980 est.)','065e2484499a40efbc6bd7c17bbe8232beff3fa57792218be23874147b1870fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90e2d4045ea237ce36b6193a1220a0017b99ac19bd13affae75b90b6dca597e3',1999,'BY','Belarus','people-and-society',148,'Population: 10,401 ,784 (July 1999 est.)
Age structure:
0-14 years: 19% (male 1 ,027,974; female 985,342)
15-64 years: 67% (male 3,390,552; female
3,591,245)
65 years and over: 1 4% (male 463,369; female
943,302) (1999 est.)
Population growth rate: -0.09% (1999 est.)
Birth rate: 9.7 births/1,000 population (1999 est.)
Death rate: 13.71 deaths/1,000 population (1999
est.)
Net migration rate: 3.13 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.49 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 1 4.39 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.1 3 years
male: 62.04 years
female: 74.52 years (1999 est.)
Total fertility rate: 1 .32 children born/woman (1 999
est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Byelorussian 77.9%, Russian
13.2%, Polish 4.1%, Ukrainian 2.9%, other 1.9%
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Byelorussian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
45
Belarus (continued)
male: 99%
female: 97% (1989 est.)','b8c3da26494742f7d3b926c9d2dab7d1d4c621f46ad1c5ecf9c549c760dd4ec8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d62d763e8ede5ed69d807d47a096ca62e5d7d96f495b25290283f3f4b5f25127',1999,'DE','Germany','people-and-society',158,'Population: 10,182,034 (July 1999 est.)
Age structure:
0-14 years: 17% (male 895,987; female 853,494)
15-64 years: 66% (male 3,389,572; female
3,318,266)
65 years and over: 17% (male 703,933; female
1,020,782) (1999 est.)
Population growth rate: 0.06% (1999 est.)
Birth rate: 9.98 births/1,000 population (1999 est.)
Death rate: 1 0.43 deaths/1 ,000 population ( 1 999
est.)
Net migration rate: 1.01 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 ma!e(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 maie(s)/female (1999 est.)
Infant mortality rate: 6.17 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.53 years
male: 74.31 years
female: 80.9 years (1999 est.)
Total fertility rate: 1.49 children born/woman (1999
est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 55%, Walloon 33%, mixed
or other 12%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Flemish 56%, French 32%, German
1%, legally bilingual 11%
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 82,087,361 (July 1999 est.)
Age structure:
0-14 years: 15% (male 6,495,882; female 6,172,359)
15-64 years: 69% (male 28,687,267; female
27,526,698)
65 years and over: 1 6% (male 4,990,090; female
8,215,065) (1999 est.)
Population growth rate: 0.01% (1999 est.)
Birth rate: 8.68 births/1,000 population (1999 est.)
Death rate: 10.76 deaths/1 ,000 population (1999
est.)
Net migration rate: 2.12 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 ma!e(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 5.14 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77 .17 years
male: 74.01 years
female: 80.5 years (1999 est.)
Total fertility rate: 1 .26 children born/woman (1 999
est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, Turkish 2.4%,
Italians 0.7%, Greeks 0.4%, Poles 0.4%, other 4.6%
(made up largely of people fleeing the war in the
former Yugoslavia)
Religions: Protestant 38%, Roman Catholic 34%,
Muslim 1 .7%, unaffiliated or other 26.3%
Languages: German
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1977 est.)
male: NA%
female: NA%
Population: 429,080 (July 1999 est.)
Age structure:
0-14 years: 1 8% (male 39,701 ; female 37,998)
15-64 years: 67% (male 146,336; female 140,717)
65 years and over: 1 5% (male 26,201 ; female
38,127) (1999 est.)
Population growth rate: 0.88% (1999 est.)
Birth rate: 1 0.35 births/1 ,000 population (1 999 est.)
Death rate: 9.32 deaths/1 ,000 population (1 999 est.)
Net migration rate: 7.78 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.69 male(s)/fema!e
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 4.99 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.65 years
male: 74.58 years
female: 80.83 years (1999 est.)
Total fertility rate: 1 .57 children born/woman (1 999
est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, and European
(guest and worker residents)
Religions: Roman Catholic 97%, Protestant and
Jewish 3%
Languages: Luxembourgian, German, French,
English
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)
Population: 437,312 (July 1999 est.)
Age structure:
0-14 years: 24% (male 54,456; female 50,91 2)
15-64 years: 69% (male 142,575; female 158,132)
65 years and over: 7% (male 12,547; female 18,690)
(1999 est.)
Population growth rate: 1.86% (1999 est.)
Birth rate: 12.5 births/1,000 population (1999 est.)
Death rate: 3.48 deaths/1 ,000 population (1 999 est.)
Net migration rate: 9.59 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 4.23 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 81 .88 years
male: 78.79 years
female: 85. 1 3 years (1 999 est.)
Total fertility rate: 1 .27 children born/woman (1 999
est.)
Nationality:
noun: Macanese (singular and plural)
adjective: Macau
Ethnic groups: Chinese 95%, Portuguese 3%, other
2%
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1 997 est.)
Languages: Portuguese, Chinese (Cantonese)
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 93%
female: 86% (1981 est.)
Population: 14,873,387 (July 1999 est.)
Age structure:
0-14 years: 45% (male 3,356,104; female 3,279,056)
15-64 years: 52% (male 3,841,248; female
3,908,209)
65 years and over: 3% (male 234,549; female
254,221) (1999 est.)
Population growth rate: 2.8% (1999 est.)
Birth rate: 41 ,52 births/1,000 population (1999 est.)
Death rate: 1 3.56 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 89.1 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 53.24 years
male: 52.01 years
female: 54.51 years (1 999 est.)
Total fertility rate: 5.7 children born/woman (1999
est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-lndonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-lndonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka, Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
male: 88%
female: 73% (1990 est.)','69dd8e8dc3dd72851d4894a63e6bd471bc4a8bd282f4703e0c04694b9912b626','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c6835456d4e64a74b55c32d26b8c23ec210b14d88f6dd1a6beb111e2922fd54',1999,'BZ','Belize','people-and-society',161,'Population: 235,789 (July 1999 est.)
Age structure:
0-14 years: 42% (male 49,991 ; female 48,074)
15-64 years: 55% (male 65,507; female 63,796)
65 years and over: 3% (male 4,1 29; female 4,292)
(1999 est.)
Population growth rate: 2.42% (1999 est.)
Birth rate: 30.22 births/1,000 population (1999 est.)
Death rate: 5.39 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.67 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .03 male(s)/female (1999 est.)
Infant mortality rate: 31 .57 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.2 years
male: 67.23 years
female: 71 .26 years (1999 est.)
Total fertility rate: 3.74 children born/woman (1999
est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 44%, Creole 30%, Maya
1 1 %, Garifuna 7%, other 8%
Religions: Roman Catholic 62%, Protestant 30%
(Anglican 12%, Methodist 6%, Mennonite 4%,
Seventh-Day Adventist 3%, Pentecostal 2%,
Jehovah''s Witnesses 1%, other 2%), none 2%, other
6% (1980)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib)
Literacy:
definition: age 14 and over has ever attended school
total population: 70,3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as
75%','08c09a44c379ab15309cd170e69e421ff3bba4362815ea0705204f3ee56cc32b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eedff58cd8ae238138011e48820730e8d1fd9a4b2dd81854417188a04a22397',1999,'BJ','Benin','people-and-society',168,'Population: 6,305,567 (July 1999 est.)
Age structure:
0-14 years: 48% (male 1 ,51 0,703; female 1 ,501 ,437)
15-64 years: 50% (male 1 ,51 1,114; female
1,637,155)
65 years and over: 2% (male 62,459; female 82,699)
(1999 est.)
Population growth rate: 3.3% (1999 est.)
Birth rate: 45.37 births/1 ,000 population (1999 est.)
Death rate: 1 2.4 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.96 male(s)/female (1 999 est.)
Infant mortality rate: 97.76 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54.08 years
male: 51 .98 years
female: 56.24 years (1 999 est.)
Total fertility rate: 6.4 children born/woman (1999
est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 70%, Muslim 15%,
Christian 15%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 15 and over can read and write
total population: 37%
male : 48.7%
female: 25.8% (1995 est.)','0f0fb4040195087a1bef5ac746b7f4b9a5d1b7a84ab49b207ffbb9e85b3a484b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96a3924e3b1670d252bbcbad5a5d2c38dee1c15265e93ffda05acca231fb7422',1999,'BM','Bermuda','people-and-society',176,'Population: 62,472 (July 1999 est.)
Age structure:
0-14 years: 20% (male 6,174; female 6,023)
15-64 years: 70% (male 21 ,479; female 22,041 )
65 years and over: 1 0% (male 2,897; female 3,858)
(1999 est.)
Population growth rate: 0.72% (1999 est.)
Birth rate: 1 1 .83 births/1 ,000 population (1 999 est.)
Death rate: 7.27 deaths/1 ,000 population (1 999 est.)
Net migration rate: 2.67 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 9.27 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.97 years
male: 75.1 9 years
female: 78.83 years (1 999 est.)
Total fertility rate: 1.71 children born/woman (1999
est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 61%, white and other 39%
Religions: Anglican 28%, Roman Catholic 15%,
African Methodist Episcopal (Zion) 12%, Seventh-Day
Adventist 6%, Methodist 5%, other 34% (1991)
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1970 est.)','15fb3422dd3bbd3a6e605698bca80c19581ac051249ea7dd230312fa61e0b478','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16843dc782834bcd21f668cf92714887faeaf271a873d0ee848ca255fcffebc4',1999,'BT','Bhutan','people-and-society',183,'Population: 1 ,951 ,965 (July 1 999 est.)
note: other estimates range as low as 600,000
Age structure:
0-14 years: 40% (male 405,745; female 376,738)
15-64 years: 56% (male 561 ,754; female 530,420)
65 years and over: 4% (male 39,251 ; female 38,057)
(1999 est.)
Population growth rate: 2.25% (1999 est.)
Birth rate: 36.76 births/1 ,000 population (1999 est.)
Death rate: 1 4.26 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 1 09.33 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 52.75 years
male: 53. 19 years
female: 52.29 years (1999 est.)
Total fertility rate: 5.16 children born/woman (1999
est.)
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%,
indigenous or migrant tribes 15%
Religions: Lamaistic Buddhism 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.2%
male: 56.2%
female: 28.1% (1995 est.)
People - note: refugee issue over the presence in
Nepal of approximately 91 ,000 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps','08b135846d79cc8de86a2c229e82880d5fe63be9949843d5662de5b325f7b84f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dccd5c178dbb9aa19129604ba068e5f84e5af71f951f28a6ec37d904cf34601b',1999,'BR','Brazil','people-and-society',190,'Population: 7,982,850 (July 1999 est.)
Age structure:
0-14 years: 39% (male 1 ,573,391 ; female 1 ,540,123)
15-64 years: 56% (male 2,199,077; female
2,307,490)
65 years and over: 5% (male 1 64,21 3; female
198,556) (1999 est.)
Population growth rate: 1 .96% (1999 est.)
Birth rate: 30.72 births/1 ,000 population (1999 est.)
Death rate: 9.61 deaths/1 ,000 population (1999 est.)
Net migration rate: -1.5 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 62.02 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 61 .43 years
male: 58.51 years
female: 64.51 years (1 999 est.)
Total fertility rate: 3.93 children born/woman (1999
est.)
Nationality:
noun: Bolivian(s)
58
Bolivia (continued)
adjective: Bolivian
Ethnic groups: Quechua 30%, Aymara 25%,
mestizo (mixed white and Amerindian ancestry) 30%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 83. 1%
male: 90.5%
female: 76% (1995 est.)
Population: 3,482,495 (July 1999 est.)
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing
Age structure:
0-14 years: 17% (male 310,430; female 294,298)
15-64 years: 71 % (male 1 ,221 ,791 ; female
1,240,097)
65 years and over: 1 2% (male 1 66,876; female
249,003) (1999 est.)
Population growth rate: 3.2% (1999 est.)
Birth rate: 9.36 births/1 ,000 population (1999 est.)
Death rate: 10.81 deaths/1,000 population (1999
est.)
Net migration rate: 33.42 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.95 male(s)/female (1 999 est.)
Infant mortality rate: 24.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.98 years
male: 62.55 years
female: 71 .71 years (1999 est.)
Total fertility rate: 1 .21 children born/woman (1 999
est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 40%, Muslim 38%, Croat 22%
(est.); note - the Croats claim they now make up only
17% of the total population
Religions: Muslim 40%, Orthodox 31%, Catholic
15%, Protestant 4%, other 10%
Languages: Croatian, Serbian, Bosnian
Literacy: NA
Population: 1,464,167 (July 1999 est.)
Age structure:
0-14 years: 42% (male 310,578; female 303,495)
15-64 years: 54% (male 379,836; female 416,073)
65 years and over: 4% (male 20,224; female 33,961 )
(1999 est.)
Population growth rate: 1 .05% (1999 est.)
Birth rate: 31 .46 births/1,000 population (1999 est.)
Death rate: 21 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 ,02 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.6 ma!e(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 59.08 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 39.89 years
male: 39.42 years
female: 40.37 years (1999 est.)
Total fertility rate: 3.91 children born/woman (1999
est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Batswana 95%, Kalanga, Basarwa,
and Kgalagadi 4%, white 1%
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total population: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Population: uninhabited
Population: 171,853,126 (July 1999 est.)
note: Brazil took a census in August 1996 which
reported a population of 157,079,573; that figure was
about 5% lower than projections by the US Census
Bureau, and is close to the implied underenumeration
of 4.6% for 1991; the Factbook''s demographic
statistics for Brazil do not take into consideration the
results of thel 996 census since the full results have
not been released for analysis
Age structure:
0-14 years: 30% (male 26,059,687; female
25,095,236)
15-64 years: 65% (male 55,037,161 ; female
56,727,196)
65 years and over: 5% (male 3,626,893; female
5,306,953)(1999 est.)
Population growth rate: 1 .16% (1 999 est.)
Birth rate: 20.42 births/1,000 population (1999 est.)
Death rate: 8.79 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 35.37 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.06 years
male: 59.35 years
female: 69.01 years (1999 est.)
Total fertility rate: 2.28 children bom/woman (1 999
est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 70%
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 1 5 and over can read and write
total population: 83.3%
male: 83,3%
female: 83.2% (1995 est.)','73fbe31f08352bd599ef41624e36ec9149de6345f273b1b4a36b09e5a11d2d11','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aac4997afdce08511964c036a3454af88ccddb09e29613102d9f519eee2f9866',1999,'ID','Indonesia','people-and-society',200,'Population: no indigenous inhabitants
note: approximately 3,000 native inhabitants, known
as the Chagosians or Hois, were evacuated to
Mauritius before construction of UK-US military
facilities; now there are UK and US military personnel
and civilian contractors living on the island
Population: 216,108,345 (July 1999 est.)
Age structure:
0-14 years: 30% (male 33,367,287; female
32,411,786)
15-64 years: 65% (male 70,541 ,893; female
70,866,972)
65 years and over: 5% (male 3,936,41 5; female
4,983,992) (1999 est.)
lowest point: Indian Ocean 0 m
228
Indonesia (continued)
Population growth rate: 1.46% (1999 est.)
Birth rate: 22.78 births/1 ,000 population (1999 est.)
Death rate: 8.14 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 male(s)/female (1 999 est.)
Infant mortality rate: 57.3 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 62.92 years
male: 60.67 years
female: 65.29 years (1999 est.)
Total fertility rate: 2.57 children born/woman (1999
est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7.5%, coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%, Roman
Catholic 3%, Hindu 2%, Buddhist 1 %, other 1 % (1 998)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which is Javanese
Literacy:
definition: age 1 5 and over can read and write
total population: 83.8%
male: 89.6%
female: 78% (1995 est.)
Population: 65,179,752 (July 1999 est.)
Age structure:
0-14 years: 36% (male 1 1 ,963,438; female
11,447,191)
15-64 years: 60% (male 19,549,935; female
19,276,784)
65 years and over: 4% (male 1 ,561 ,877; female
1,380,527) (1999 est.)
Population growth rate: 1 .07% (1 999 est.)
Birth rate: 20.71 births/1 ,000 population (1999 est.)
Death rate: 5.39 deaths/1 ,000 population (1 999 est.)
Net migration rate: -4.6 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1 .03 male(s)/female (1999 est.)
Infant mortality rate: 29.73 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.76 years
mate: 68.43 years
female: 71 . 1 6 years (1 999 est.)
Total fertility rate: 2.45 children born/woman (1999
est.)
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azerbaijani 24%,
Gilaki and Mazandarani 8%, Kurd 7%, Arab 3%, Lur
2%, Baloch 2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 1 5 and over can read and write
total population: 72.1 %
male: 78.4%
female: 65.8% (1 994 est.)
Population: 22,427,150 (July 1999 est.)
Age structure:
0-14 years: 44% (male 4,982,510; female 4,825,129)
15-64 years: 53% (male 6,030,417; female
5,889,543)
65 years and over: 3% (male 326,223; female
373,328) (1999 est.)
Population growth rate: 3.19% (1999 est.)
Birth rate: 38.42 births/1,000 population (1999 est.)
Death rate: 6.56 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/fema!e
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 ,02 male(s)/female (1999 est.)
Infant mortality rate: 62,41 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.52 years
male: 65.54 years
female: 67,56 years (1999 est.)
Total fertility rate: 5.12 children born/woman (1999
est.)
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 1 5%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 58%
mate: 70.7%
female: 45% (1995 est.)
Population: 3,632,944 (July 1999 est.)
Age structure:
0- 14 years: 2 1 % (male 399,379; female 377,366)
15-64 years: 67% (male 1 ,232,072; female
1,213,364)
65 years and over: 12% (male 174,519; female
236,244) (1999 est.)
Population growth rate: 0.38% (1999 est.)
Birth rate: 13.58 births/1 ,000 population (1999 est.)
Death rate: 8.43 deaths/1 ,000 population (1999 est.)
Net migration rate: -1.31 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/fema!e
15-64 years: 1 .02 male(s)/female
65 years and over: 0.74 male(s)/fema!e
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 5.94 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.39 years
male: 73.64 years
female: 79.32 years (1999 est.)
Total fertility rate: 1.81 children born/woman (1999
est.)
Nationality:
noun: Irishman(men), Irishwoman(men), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 92%, Anglican 3%,
Islamic 0.1 1%, Jehovah''s Witness 0.1%, Jewish
0.04%, other 4.75% (1991)
Languages: English is the language generally used,
Irish (Gaelic) spoken mainly in areas located along the
western seaboard
Literacy:
definition: age 15 and over can read and write
total population: 98% (1981 est.)
male: NA%
female: NA%
Population: 21,376,066 (July 1999 est.)
Age structure:
0-14 years: 35% (male 3,879,012; female 3,680,895)
15-64 years: 61% (male 6,478,910; female
6,482,909)
65 years and over: 4% (male 369,639; female
484,701) (1999 est.)
Population growth rate: 2.08% (1999 est.)
Birth rate: 26.05 births/1 ,000 population (1 999 est.)
Death rate: 5.29 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
note: does not include illegal immigrants - large
numbers from Indonesia and smaller numbers from
the Philippines, Bangladesh, Burma, China, and India
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 21 .68 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.67 years
male: 67.62 years
301
Malaysia (continued)
female: 73.9 years (1999 est.)
Total fertility rate: 3.35 children born/woman (1999
est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%,
Chinese 26%, Indian 7%, others 9%
Religions: Islam, Buddhism, Daoism, Hinduism,
Christianity, Sikhism; note - in addition, Shamanism is
practiced on East Malaysia
Languages: Bahasa Melayu (official), English,
Chinese dialects (Cantonese, Mandarin, Hokkien,
Hakka, Hainan, Foochow), Tamil, Telugu, Malalalam,
Panjabi, Thai; note - in addition, in East Malaysia
several indigenous languages are spoken, the largest
of which are Iban and Kadazan
Literacy:
definition: age 15 and over can read and write
total population: 83.5%
male: 89.1%
female: 78.1% (1995 est.)
Population: 1 31 ,500 (July 1 999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 3.3% (1999 est.)
Birth rate: 27.32 births/1 ,000 population (1 999 est.)
Death rate: 6.01 deaths/1 ,000 population (1999 est.)
Net migration rate: 1 1 .65 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 33.99 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.48 years
male: 66.52 years
female: 70.48 years (1999 est.)
Total fertility rate: 3.87 children born/woman (1999
est.)
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Kosrae(s), Pohnpeian(s),
Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%,
other and none 3%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
Population: no indigenous inhabitants
Population: 4,460,838 (July 1999 est.)
Age structure:
0-14 years: 24% (male 555,096; female 535,625)
15-64 years: 66% (male 1 ,408,334; female
1,529,542)
65 years and over: 1 0% (male 1 60,31 7; female
271,924) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 1 4.43 births/1 ,000 population (1 999 est.)
Death rate: 12.5 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.92 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (1999 est.)
Infant mortality rate: 43.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.39 years
male: 59.76 years
female: 69.24 years (1999 est.)
Total fertility rate: 1 .86 children born/woman (1999
est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldavian/Romanian 64.5%,
Ukrainian 13.8%, Russian 13%, Gagauz 3.5%,
Jewish 1.5%, Bulgarian 2%, other 1.7% (1989 est.)
note: internal disputes with ethnic Russians in the
Transdniester region
Religions: Eastern Orthodox 98.5%, Jewish 1 .5%,
Baptist (only about 1 ,000 members) (1991)
note: the large majority of churchgoers are ethnic
Moldovans
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian, Gagauz (a Turkish
dialect)
Literacy:
definition: age 1 5 and over can read and write
326
Moldova (continued)
total population: 96%
male: 99%
female: 94% (1989 est.)
Population: 79,345,812 (July 1999 est.)
Age structure:
0-14 years: 37% (male 15,057,698; female
14,555,430)
1 5-64 years: 59% (male 23, 1 68,043; female
23,715,877)
65 years and over: 4% (male 1 ,269,522; female
1,579,242) (1999 est.)
Population growth rate: 2.04% (1999 est.)
Birth rate: 27.88 births/1,000 population (1999 est.)
Death rate: 6.45 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .03 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 33.89 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.58 years
male: 63.79 years
female: 69.5 years (1999 est.)
Total fertility rate: 3.46 children born/woman (1999
est.)
Nationality:
noun: Filipino(s)
386
Philippines (continued)
adjective: Philippine
Ethnic groups: Christian Malay 91 .5%, Muslim
Malay 4%, Chinese 1 .5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: Pilipino (official, based on Tagalog),
English (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)
Population: 49 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -2.04% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 1 00%
Languages: English (official), Pitcairnese, Tahitian,
18th century English dialect
Population: 3,531 ,600 (July 1 999 est.)
Age structure:
0-14 years: 21% (male 387,786; female 364,018)
15-64 years: 72% (male 1 ,265,291 ; female
1,268,458)
65 years and over: 7% (male 1 09,41 8; female
136,629) (1999 est.)
Population growth rate: 1 .15% (1 999 est.)
Birth rate: 1 3.38 births/1 ,000 population (1 999 est.)
Death rate: 4.69 deaths/1 ,000 population (1999 est.)
Net migration rate: 2.83 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 3.84 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.84 years
male: 75.79 years
female: 82.14 years (1999 est.)
Total fertility rate: 1 .47 children born/woman (1 999
est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.4%, Malay 14.9%,
Indian 6.4%, other 2.3%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 91 .1 %
mate: 95.9%
female: 86.3% (1995 est.)','4d8511a8c78aa698f8e729560f8d9256f74806ed4601935de6b7fa764a219401','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ef65022a7ac01fc1cdeec90735b631f4b376d84d846c826bdc2a6bb33f9ee4',1999,'IO','British Indian Ocean Territory','people-and-society',211,'Population: 19,156 (July 1999 est.)
Age structure:
0-14 years: 2t% (male 2,012; female 1,965)
15-64 years: 74% (male 7,300; female 6,896)
65 years and over: 5% (male 539; female 444) (1 999
est.)
Population growth rate: 2.37% (1999 est.)
Birth rate: 1 5.92 births/1 ,000 population (1 999 est.)
Death rate: 4.65 deaths/1 ,000 population (1 999 est.)
Net migration rate: 12.37 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .21 male(s)/female
total population: 1 .06 male(s)/female (1999 est.)
Infant mortality rate: 22.17 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.1 3 years
male: 74.37 years
female: 75.92 years (1999 est.)
Total fertility rate: 1 .71 children born/woman (1999
est.)
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%,
Anglican 21%, Church of God 7%, Seventh-Day
Adventist 5%, Baptist 4%, Jehovah''s Witnesses 2%,
other 2%), Roman Catholic 6%, none 2%, other 6%
(1981)
Languages: English (official)
Literacy:
definition: age 15 and over can read and write
total population: 97.8% (1991 est.)
male: NA%
female: NA%
Population: 322,982 (July 1999 est.)
Age structure:
0-14 years: 33% (male 54,154; female 51 ,766)
15-64 years: 63% (male 106,492; female 95,921)
65 years and over: 4% (male 7,945; female 6,704)
(1999 est.)
Population growth rate: 2,38% (1999 est.)
Birth rate: 24.69 births/1,000 population (1999 est.)
Death rate: 5,21 deaths/1 ,000 population (1999 est.)
Net migration rate: 4.35 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.11 ma!e(s)/female
65 years and over: 1.19 male(s)/female
total population: 1 .09 male(s)/female (1 999 est.)
Infant mortality rate: 22.83 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .84 years
male: 70.35 years
female: 73.42 years (1999 est.)
Total fertility rate: 3.33 children born/woman (1999
est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 64%, Chinese 20%, other
16%
Religions: Muslim (official) 63%, Buddhism 14%,
Christian 8%, indigenous beliefs and other 15%
(1981)
Languages: Malay (official), English, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)
Population: 8,194,772 (July 1999 est.)
Age structure:
0-14 years: 16% (male 674,643; female 641 ,943)
15-64 years: 68% (male 2,744,634; female
2,800,816)
65 years and over: 1 6% (male 570,766; female
761,970) (1999 est.)
Population growth rate: -0.52% (1999 est.)
Birth rate: 8.71 births/1,000 population (1999 est.)
Death rate: 13.2 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.66 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.75 ma!e(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 12,37 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 1221 years
male : 68.72 years
female: 76.03 years (1 999 est.)
Total fertility rate: 1 .23 children born/woman (1 999
est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 85%, Turk 9%, other 6%
Religions: Bulgarian Orthodox 85%, Muslim 13%,
Jewish 0.8%, Roman Catholic 0.5%, Uniate Catholic
0.2%, Protestant, Gregorian-Armenian, and other
0.5%
Languages: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1992 est.)
Population: 1 1 ,575,898 (July 1 999 est.)
Age structure:
0-14 years: 48% (male 2,792,895; female 2,759,072)
15-64 years: 49% (male 2,700,253; female
2,978,168)
65 years and over: 3% (male 1 47,01 7; female
198,493) (1999 est.)
Population growth rate: 2.7% (1999 est.)
Birth rate: 45.84 births/1,000 population (1999 est.)
Death rate: 1 7.56 deaths/1 ,000 population (1 999
est.)
Net migration rate: -1 .25 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 107.19 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 45.89 years
male: 44.97 years
female: 46.84 years (1999 est.)
Total fertility rate: 6.56 children born/woman (1999
est.)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi about 24%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), tribal languages
belonging to Sudanic family, spoken by 90% of the
population
Literacy:
definition: age 15 and over can read and write
total population: 19.2%
male: 29.5%
female: 9.2% (1995 est.)','ac77709e852e312d902e4221ade0065221e89c2e8dca85d333c349d4494b97af','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5167216dea0a02387b736491099c93be2a0d8cb682d1522b0c1ba448c7a241c6',1999,'NG','Nigeria','people-and-society',222,'Population: 48,081 ,302 (July 1 999 est.)
Age structure:
0-14 years : 36% (male 8,883,099; female 8,542,087)
15-64 years: 60% (male 14,343,888; female
14,293,233)
65 years and over: 4% (male 906,51 7; female
1,112,478) (1999 est.)
Population growth rate: 1 .61 % (1999 est.)
Birth rate: 28.48 births/1,000 population (1999 est.)
Death rate: 12.39 deaths/1 ,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
af birth: 1.06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 76.25 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54.74 years
male: 53.24 years
female: 56.32 years (1999 est.)
Total fertility rate: 3.63 children born/woman (1999
est.)
78
Burma (continued)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Mon 2%, Indian 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist beliefs 1%,
other 2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 1 5 and over can read and write
total population: 83.1 %
male: 88.7%
female: 77.7% (1995 est.)
Population: 1 1 3,828,587 (July 1 999 est.)
Age structure:
0-14 years: 45% (male 25,613,974; female
25,397,166)
15-64 years: 52% (male 30,272,539; female
29,197,611)
65 years and over: 3% (male 1 ,678,732; female
1,668,565) (1999 est.)
Population growth rate: 2.92% (1999 est.)
Birth rate: 41 .84 births/1 ,000 population (1999 est.)
Death rate: 1 2.98 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0.31 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 69.46 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 53.3 years
male: 52.55 years
female: 54.06 years (1999 est.)
Total fertility rate: 6.02 children born/woman (1999
est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Hausa, Fulani, Yoruba, Ibo, Ijaw,
Kanuri, Ibibio, Tiv
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa, Yoruba, Ibo,
Fulani
Literacy:
definition: age 15 and over can read and write
total population: 57 .1%
male: 67.3%
female: 47.3% (1995 est.)','e56c7a2767417686cee1e128716997048f5744489a354cf2b4ce5397b08ad99c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6078f80734f85997260f6f08469248b3e143f38a7beba66cf8c7401a75929d2d',1999,'BI','Burundi','people-and-society',226,'Population: 5,735,937 (July 1999 est.)
Age structure:
0-14 years: 47% (male 1 ,349,995; female 1,345,201)
15-64 years: 50% (male 1 ,392,880; female
1,479,835)
65 years and over: 3% (male 69,748; female 98,278)
(1999 est.)
Population growth rate: 3.54% (1999 est.)
Birth rate: 41 .27 births/1 ,000 population (1 999 est.)
Death rate: 1 7.23 deaths/1 ,000 population (1 999
est.)
Net migration rate: 1 1 .33 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 99.36 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 45.44 years
male: 43,54 years
female: 47.41 years (1999 est.)
Total fertility rate: 6.33 children born/woman (1999
est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 1 5 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
Population: 1 1 ,626,520 (July 1 999 est.)
Age structure:
0-14 years: 45% (male 2,667,768; female 2,587,590)
15-64 years: 52% (male 2,821 ,772; female
3,197,604)
65 years and over: 3% (male 1 43,01 6; female
208,770) (1999 est.)
Population growth rate: 2.49% (1999 est.)
Birth rate: 41.05 births/1,000 population (1999 est.)
Death rate: 1 6.2 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.88 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 male(s)/female (1 999 est.)
Infant mortality rate: 105.06 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 48.24 years
male: 46.81 years
female: 49.75 years (1 999 est.)
Total fertility rate: 5.81 children bom/woman (1999
est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhism 95%, other 5%
Languages: Khmer (official), French
Literacy:
definition: age 15 and over can read and write
total population: 35%
male: 48%
female: 22% (1990 est.)
Population: 15,456,092 (July 1999 est.)
Age structure:
0-14 years: 46% (male 3,562,553; female 3,528,778)
15-64 years: 51% (male 3,907,946; female
3,943,035)
65 years and over: 3% (male 231 ,521 ; female
282,259) (1999 est.)
Population growth rate: 2.79% (1999 est.)
Birth rate: 41.84 births/1,000 population (1999 est.)
Death rate: 1 3.95 deaths/1 ,000 population (1 999
est.)
Net migration rate: NA migrant(s)/1 ,000 population;
note - there may be some migration but figures are not
available
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 75.69 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 51 .32 years
male: 49.75 years
female: 52.94 years (1 999 est.)
Total fertility rate: 5.8 children born/woman (1999
est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: indigenous beliefs 51%, Christian 33%,
Muslim 16%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 15 and over can read and write
total population: 63.4%
male: 75%
female: 52.1% (1995 est.)','afde9c23ef82ddae50b85ee9dac9ef11e357ec574916f172ae61ea3259cbf9e5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10f76c3e98b7ff697a3f067724d0ba6ee770d93d5763a8cfb9d0261e38b5fc29',1999,'CA','Canada','people-and-society',234,'Population: 31,006,347 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,105,944; female 2,960,171)
15-64 years: 68% (male 1 0,587,553; female
10,461,455)
65 years and over: 12% (male 1 ,652,044; female
2,239,180) (1999 est.)
Population growth rate: 1.06% (1999 est.)
Birth rate: 1 1 .86 births/1 ,000 population (1 999 est.)
Death rate: 7.26 deaths/1 ,000 population (1 999 est.)
Net migration rate: 5.96 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.47 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 79.37 years
male: 76.12 years
female: 82.79 years (1999 est.)
Total fertility rate: 1 .65 children born/woman (1999
est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 40%, French
origin 27%, other European 20%, Amerindian 1 .5%,
other, mostly Asian 1 1 .5%
Religions: Roman Catholic 45%, United Church
12%, Anglican 8%, other 35% (1991)
Languages: English (official), French (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 97% (1986 est.)
male: NA%
female: NA%
G o v e r nm e n t
Country name:
conventional long form: none
conventional short form: Canada
Data code: CA
Government type: federation with parliamentary
democracy
Capital: Ottawa
Administrative divisions: 1 0 provinces and 3
territories*; Alberta, British Columbia, Manitoba, New
Brunswick, Newfoundland, Northwest Territories*,
Nova Scotia, Nunavut*, Ontario, Prince Edward
Island, Quebec, Saskatchewan, Yukon Territory*
Independence: 1 July 1867 (from UK)
National holiday: Canada Day, 1 July (1867)
Constitution: 17 April 1982 (Constitution Act);
originally, the machinery of the government was set
up in the British North America Act of 1 867; charter of
rights and unwritten customs
87
Canada (continued)
Legal system: based on English common law,
except in Quebec, where civil law system based on
French law prevails; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Romeo Le
BLANC (since 8 February 1995)
head of government: Prime Minister Jean CHRETIEN
(since 4 November 1993)
cabinet: Federal Ministry chosen by the prime minister
from among the members of his own party sitting in
Parliament
elections: none; the monarch is hereditary; governor
general appointed by the monarch on the advice of the
prime minister for a five-year term; following legislative
elections, the leader of the majority party in the House
of Commons is automatically designated by the
governor general to become prime minister
Legislative branch: bicameral Parliament or
Parlement consists of the Senate or Senat (a body
whose members are appointed to serve until reaching
75 years of age by the governor general and selected
on the advice of the prime minister; its normal limit is
104 senators) and the House of Commons or
Chambre des Communes (301 seats; members
elected by direct popular vote to serve five-year terms)
elections: House of Commons - last held 2 June 1 997
(next to be held by NA June 2002)
election results: percent of vote by party - Liberal
Party 38%, Reform Party 19%, Tories 19%, Bloc
Quebecois 11%, New Democratic Party 11%, other
2%; seats by party - Liberal Party 155, Reform Party
60, Bloc Quebecois 44, New Democratic Party 21 ,
Progressive Conservative Party 20, independents 1
Judicial branch: Supreme Court, judges are
appointed by the prime minister through the governor
general
Political parties and leaders: Liberal Party [Jean
CHRETIEN]; Bloc Quebecois [Gilles DUCEPPEj;
Reform Party [Preston MANNING]; New Democratic
Party [Alexa MCDONOUGH]; Progressive
Conservative Party [Joe CLARK]
International organization participation: ACCT,
AfDB, APEC, AsDB, Australia Group, BIS, C, CCC,
CDB (non-regional), CE (observer), CP, EAPC,
EBRD, ECE, ECLAC, ESA (cooperating state), FAO,
G- 7, G-10, IADB, IAEA, IBRD, ICAO, ICC, ICFTU,
ICRM, IDA, IEA, IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO, ITU,
MINURCA, MIPONUH, MTCR, NAM (guest), NATO,
NEA, NSG, OAS, OECD, OPCW, OSCE, PCA, UN,
UNCTAD, UNDOF, UNESCO, UNFICYP, UNHCR,
UNIDO, UNIKOM, UNMIBH, UNMOP, UNPREDEP,
UNTSO, UNU, UPU, WCL, WFTU, WHO, WIPO,
WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Raymond A. J.
CHRETIEN
chancery: 501 Pennsylvania Avenue NW,
Washington, DC 20001
telephone: [1] (202) 682-1740
FAX: [1] (202) 682-7726
consulate(s) general: Atlanta, Boston, Buffalo,
Chicago, Dallas, Detroit, Los Angeles, Minneapolis,
New York, and Seattle
consulate(s): Miami, Princeton, San Francisco, and
San Jose
Diplomatic representation from the US:
chief of mission: Ambassador Gordon D. GIFFIN
embassy: 100 Wellington Street, K1 P 5T1 , Ottawa
mailing address: P. O. Box 5000, Ogdensburg, NY
13669-0430
telephone: [1] (613) 238-5335, 4470
FAX; [1] (613) 238-5720
consulate(s) general: Calgary, Halifax, Montreal,
Quebec, Toronto, and Vancouver
Flag description: three vertical bands of red (hoist
side), white (double width, square), and red with a red
maple leaf centered in the white band
Population: 405,748 (July 1999 est.)
Age structure:
0-14 years: 45% (male 92,721 ; female 91 ,083)
15-64 years: 49% (male 92,658; female 104,264)
65 years and over: 6% (male 9,936; female 1 5,086)
(1999 est.)
Population growth rate: 1 .44% (1999 est.)
Birth rate: 33.49 births/1,000 population (1999 est.)
Death rate: 6.78 deaths/1 ,000 population (1 999 est.)
Net migration rate: -12.35 migrant(s)/1 ,000
population (1 999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 45.5 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.96 years
male: 67.66 years
female: 74.36 years (1999 est.)
Total fertility rate: 4.95 children born/woman (1999
est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of creole
Portuguese and West African words)
Literacy:
definition: age 1 5 and over can read and write
total population: 1 1.6%
male: 81 .4%
female: 63.8% (1995 est.)','6ba1118ec74107a5541433e2530709f16dcb9156722220d39c432db9173c0a3c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93d5ceba93fe0d0f8d7068f28c059fe89e004fc90e76f2b8feccbe921649945',1999,'HN','Honduras','people-and-society',249,'Population: 39,335 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 4.19% (1999 est.)
Birth rate: 1 3.66 births/1 ,000 population (1 999 est.)
Death rate: 4.98 deaths/1 ,000 population (1 999 est.)
Net migration rate: 33.2 migrant(s)/1 ,000
population (1999 est.)
note: major destination for Cubans trying to migrate to
the US
Infant mortality rate: 8.4 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77. 1 years
male: 75.37 years
female: 78.81 years (1999 est.)
Total fertility rate: 1.31 children born/woman (1999
est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Roman Catholic,
Church of God, other Protestant denominations
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 3,444,951 (July 1999 est.)
Age structure:
0-14 years: 44% (male 757,422; female 749,289)
15-64 years: 53% (male 885,087; female 927,282)
65 years and over: 3% (male 56,309; female 69,562)
(1999 est.)
Population growth rate: 2.04% (1999 est.)
Birth rate: 38.28 births/1 ,000 population (1 999 est.)
Death rate: 1 6.46 deaths/1 ,000 population (1 999
est.)
Net migration rate: -1 .45 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 male(s)/female (1 999 est.)
Infant mortality rate: 103.42 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 47. 1 9 years
male: 45.35 years
female: 49.09 years (1999 est.)
Total fertility rate: 5.03 children born/woman (1999
est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%,
Mandjia 21%, Mboum 4%, M''Baka 4%, Europeans
6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%,
Roman Catholic 25%, Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), Arabic, Hunsa, Swahili
93
Central African Republic (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 60%
mate: 68.5%
female: 52.4% (1995 est.)
Population: 7,557,436 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1 ,675,394; female 1 ,667,717)
15-64 years: 53% (male 1 ,953,251 ; female
2,034,883)
65 years and over: 3% (male 99,783; female
126,408) (1999 est.)
Population growth rate: 2.65% (1999 est.)
Birth rate: 43.06 births/1 ,000 population (1 999 est.)
Death rate: 16.57 deaths/1,000 population (1999
est.)
95
Chad (continued)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 1 15.27 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 48.56 years
male: 46.1 3 years
female: 51 .09 years (1999 est.)
Total fertility rate: 5.69 children born/woman (1999
est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims (Arabs, Toubou, Hadjerai,
Fulbe, Kotoko, Kanembou, Baguirmi, Boulala,
Zaghawa, and Maba), non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moundang, Moussei,
Massa), nonindigenous 150,000 (of whom 1,000 are
French)
Religions: Muslim 50%, Christian 25%, indigenous
beliefs (mostly animism) 25%
Languages: French (official), Arabic (official), Sara
and Sango (in south), more than 100 different
languages and dialects
Literacy:
definition: age 1 5 and over can read and write French
or Arabic
total population: 48.1%
male: 62.1%
female: 34.7% (1995 est.)','834f9a84068c75bbc1f96fd6afb64d8880879c1ce065329a0335923a8d6ba3c4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d398670c8c497fefe08291e5230d73278d4bc0b46d69ed41101551d08d4bcc1d',1999,'CL','Chile','people-and-society',258,'Population: 14,973,843 (July 1999 est.)
Age structure:
0-14 years: 28% (male 2,137,255; female 2,044,605)
15-64 years: 65% (male 4,845,523; female
4,885,328)
65 years and over: 7% (male 440,01 0; female
621,122) (1999 est.)
Population growth rate: 1 .23% (1 999 est.)
Birth rate: 17.81 births/1,000 population (1999 est.)
Death rate: 5.53 deaths/1 ,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/fema!e
total population: 0,98 male(s)/female (1999 est.)
Infant mortality rate: 1 0.02 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.46 years
male: 72,33 years
female: 78.75 years (1999 est.)
Total fertility rate: 2.25 children born/woman (1999
est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 11%,
Jewish less than 1%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 95.2%
male: 95.4%
female: 95% (1995 est.)','8f932421d2882638377e85fe3932b066879984f633329f7215de9ad9cfc2ae75','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b53ea8f917b4a78ab105c524506f48170c050030a274bc0e988c1a5b6df76fa',1999,'CN','China','people-and-society',267,'Population: 1,246,871,951 (July 1999 est.)
Age structure:
0-14 years: 26% (male 169,206,275; female
149,115,216)
15-64 years: 68% (male 435,047,915; female
408,663,265)
65 years and over: 6% (male 39,824,361 ; female
45,014,919) (1999 est.)
Population growth rate: 0.77% (1999 est.)
Birth rate: 15.1 births/1 ,000 population (1999 est.)
Death rate: 6.98 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.41 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.15 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 43.31 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.92 years
male: 68.57 years
female: 71 .48 years (1 999 est.)
Total fertility rate: 1 .8 children born/woman (1 999
est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 .9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoism (Taoism), Buddhism, Muslim
2%-3%, Christian 1% (est.)
note: officially atheist, but traditionally pragmatic and
eclectic
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic divisions
entry)
Literacy:
definition: age 15 and over can read and write
total population: 81 .5%
male: 89.9%
female: 72.7% (1995 est.)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi Desert in
southeast
Elevation extremes:
lowest point: Hoh Nuur 51 8 m
highest point: Tav an Bogd Uul 4,374 m
Natural resources: oil, coal, copper, molybdenum,
tungsten, phosphates, tin, nickel, zinc, wolfram,
fluorspar, gold
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 80%
forests and woodland: 9%
other: 10% (1993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: dust storms can occur in the
spring; grassland fires
Environment - current issues: limited natural fresh
water resources; policies of the former communist
regime promoting rapid urbanization and industrial
growth have raised concerns about their negative
effects on the environment; the burning of soft coal
and the concentration of factories in Ulaanbaatar have
severely polluted the air; deforestation, overgrazing,
Population: 2,617,379 (July 1999 est.)
Age structure:
0-14 years: 36% (male 480,087; female 464,609)
15-64 years: 60% (male 787,222; female 787,405)
65 years and over: 4% (male 42,21 9; female 55,837)
(1999 est.)
Population growth rate: 1.45% (1999 est.)
Birth rate: 22.51 births/1 ,000 population (1999 est.)
Death rate: 7.97 deaths/1 ,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 64,63 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 61 .81 years
male: 59.71 years
female: 64.02 years (1999 est.)
Total fertility rate: 2.6 children born/woman (1999
est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol 90%, Kazakh 4%, Chinese
2%, Russian 2%, other 2%
Religions: predominantly Tibetan Buddhist, Muslim
4%
note: previously limited religious activity because of
communist regime
Languages: Khalkha Mongol 90%, Turkic, Russian,
Chinese
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 88.6%
female: 77.2% (1988 est.)','0514db7e6476fd734e8b9c5faf09b0ea36712dd57ee5e4e1729f2f5ec01a3745','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c951e95972f5094171fc7f4a0979822d787e8d68ba7eebe0e1351d9bc26c5c7c',1999,'CX','Christmas Island','people-and-society',276,'Population: 2,373 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 7.77% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 61%, Malay 25%,
European 11%, other 3%, no indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim
10%, other 20% (1991)
Languages: English','06a0d661efbca8fd03d82c13182667090b45a76636b6c6bb02dcb22d8cc30c30','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5e78e26b3d89e11c0e8afc88978dad43df8c445c70daea5b54d85c3d042d25d',1999,'FR','France','people-and-society',282,'Population: 636 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA (July 1 998 est.)
Population growth rate: -0.21% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 57%, Christian 22%, other
21% (1981 est.)
Languages: English, Malay
Population: 2,758 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.43% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Population: 58,978,172 (July 1999 est.)
Age structure:
0-14 years: 19% (male 5,638,462; female 5,375,91 1)
15-64 years: 65% (male 19,302,121; female
19,235,235)
65 years and over: 1 6% (male 3,825,232; female
5,601,211)(1999 est.)
Population growth rate: 0.27% (1999 est.)
Birth rate: 1 1 .38 births/1 ,000 population (1 999 est.)
Death rate: 9.17 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.53 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 5.62 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.63 years
male: 74.76 years
female: 82.71 years (1999 est.)
Total fertility rate: 1.61 children born/woman (1999
est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%,
Jewish 1%, Muslim (North African workers) 1%,
unaffiliated 6%
Languages: French 1 00%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1980 est.)
Population: no indigenous inhabitants
note: in 1997 there were about 100 researchers
whose numbers vary from winter (July) to summer
(January)
Population: uninhabited
Population: 10,707,135 (July 1999 est.)
Age structure:
0-14 years: 16% (male 878,349; female 818,31 1)
15-64 years: 67% (male 3,61 9,982; female
3,587,591)
65 years and over: 17% (male 799,053; female
1,003,849) (1999 est.)
Population growth rate: 0.41% (1999 est.)
Birth rate: 9.54 births/1,000 population (1999 est.)
Death rate: 9.44 deaths/1 ,000 population (1 999 est.)
Net migration rate: 4.04 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0,8 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 7.13 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.43 years
male: 75.87 years
female: 81.18 years (1 999 est.)
Total fertility rate: 1 .3 children born/woman (1999
est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%,
other 0.7%
Languages: Greek (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 98%
female: 93% (1991 est.)
Population: 9,513,603 (July 1999 est.)
Age structure:
0-14 years: 31% (male 1,513,296; female 1 ,417,166)
15-64 years: 63% (male 3,006,029; female
3,018,411)
65 years and over: 6% (male 283,026; female
275,675) (1999 est.)
Population growth rate: 1.39% (1999 est.)
Birth rate: 1 9.72 births/1 ,000 population (1 999 est.)
Death rate: 5.05 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.74 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 31 .38 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.35 years
male: 71. 95 years
female: 74.86 years (1999 est.)
Total fertility rate: 2.38 children born/woman (1999
est.)
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
486
Tunisia (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 66.7%
male: 78.6%
female: 54.6% (1995 est.)
Population: 65,599,206 (July 1999 est.)
Age structure:
0-14 years: 30% (male 10,148,457; female
9,781,452)
15-64 years: 64% (male 21 ,255,506; female
20,560,070)
65 years and over: 6% (male 1 ,775, 1 64; female
2,078,557) (1999 est.)
Population growth rate: 1.57% (1999 est.)
Birth rate: 20,92 births/1,000 population (1999 est.)
Death rate: 5.27 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 35.81 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.29 years
male: 70.81 years
female: 75.88 years (1999 est.)
Total fertility rate: 2.41 children born/woman (1999
est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(Christian and Jews)
Languages: Turkish (official), Kurdish, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 82.3%
male: 91 .7%
female: 72.4% (1995 est.)
Population: 4,366,383 (July 1999 est.)
Age structure:
0-14 years: 38% (male 845,584; female 813,223)
15-64 years: 58% (male 1 ,243,031 ; female
1,283,985)
65 years and over: 4% (male 68,496; female
112,064) (1999 est.)
Population growth rate: 1.58% (1999 est.)
Birth rate: 25.91 births/1,000 population (1999 est.)
Death rate: 8.77 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .35 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 73.1 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 61 ,1 1 years
male: 57.48 years
female: 64.91 years (1999 est.)
Total fertility rate: 3.21 children born/woman (1999
est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%,
Russian 6.7%, Kazakh 2%, other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek
9%, other 7%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 59,1 1 3,439 (July 1 999 est.)
Age structure:
0-14 years: 19% (male 5,822,901; female 5,522,122)
15-64 years: 65% (male 19,393,706; female
19,103,882)
65 years and over: 1 6% (male 3,821 ,181; female
5,449,647) (1999 est.)
Population growth rate: 0.24% (1999 est.)
Birth rate: 1 1 .9 births/1 ,000 population (1 999 est.)
Death rate: 10.64 deaths/1,000 population (1999
est.)
Net migration rate: 1.11 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 5.78 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.37 years
male: 74.73 years
female: 80.1 5 years (1 999 est.)
Total fertility rate: 1.71 children born/woman (1999
est.)
Nationality:
noun: Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish
2.4%, Welsh 1.9%, Ulster 1.8%, West Indian, Indian,
Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9
million, Muslim 1 million, Presbyterian 800,000,
Methodist 760,000, Sikh 400,000, Hindu 350,000,
Jewish 300,000(1991 est.)
Languages: English, Welsh (about 26% of the
population of Wales), Scottish form of Gaelic (about
60,000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99% (1978 est.)
male: NA%
female: NA%
Population: 272,639,608 (July 1999 est.)
Age structure:
0-14 years: 22% (male 30,097,125; female
28,699,568)
15-64 years: 66% (male 89,024,052; female
90,379,328)
65 years and over: 12% (male 14,189,132; female
20,250,403) (1999 est.)
Population growth rate: 0.85% (1999 est.)
Birth rate: 14.3 births/1 ,000 population (1999 est.)
Death rate: 8.8 deaths/1 ,000 population (1999 est.)
Net migration rate: 3 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 6.33 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.23 years
male: 72.95 years
female: 79.67 years (1 999 est.)
Total fertility rate: 2.07 children born/woman (1999
est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 83.5%, black 12.4%, Asian
3.3%, Amerindian 0.8% (1992)
Religions: Protestant 56%, Roman Catholic 28%,
Jewish 2%, other 4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable
minority)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 97% (1979 est.)
Population: 1,611,109 (July 1999 est.)
note: in addition, there are some 166,000 Israeli
settlers in the West Bank and about 176,000 in East
Jerusalem (August 1998 est.)
Age structure:
0-14 years: 45% (male 370,770; female 352,803)
15-64 years: 52% (male 422,209; female 41 1 ,597)
65 years and over: 3% (male 22,376; female 31 ,354)
527
West Bank (continued)
(1999 est.)
Population growth rate: 3.14% (1999 est.)
Birth rate: 35.59 births/1 ,000 population (1 999 est.)
Death rate: 4.2 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/fema!e
15-64 years: 1 .03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 25.22 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.83 years
male: 70.96 years
female: 74.79 years (1999 est.)
Total fertility rate: 4.78 children born/woman (1999
est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy: NA','cc34229449a9d9629a7b4e2adb1998072ec331fdd9ceb3531354b374ac49401d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baf9e6ae66860b6013a4384f4363dd4d964a980ee6f227a499f1d76fa27f55a8',1999,'CO','Colombia','people-and-society',293,'Population: 39,309,422 (July 1999 est.)
Age structure:
0-14 years: 33% (male 6,556,566; female 6,402,1 1 5)
15-64 years: 62% (male 1 1 ,966,306; female
12,593,685)
65 years and over: 5% (male 807,282; female
983,468) (1999 est.)
Population growth rate: 1 .85% (1999 est.)
Birth rate: 24.45 births/1,000 population (1999 est.)
Death rate: 5.59 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 24.3 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.48 years
male: 66.54 years
female: 74.54 years (1 999 est.)
Total fertility rate: 2.87 children born/woman (1999
est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 91 .3%
male: 91 .2%
female: 91 .4% (1995 est.)','8badc59b1a569e72859e971ff1f02a078696cd9f4a6bb238632b13d9d877279a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f91011b94dfa80b73887e5a8ccd616a2fa6c14e64e71f1535e910a540656a2a',1999,'CG','Congo','people-and-society',308,'Population: 2,716,814 (July 1999 est.)
Age structure:
0-14 years: 42% (male 579,940; female 573,847)
15-64 years: 54% (male 71 8,820; female 751 ,911)
65 years and over: 4% (male 36,987; female 55,309)
(1999 est.)
Population growth rate: 2.16% (1999 est.)
Birth rate: 37.96 births/1,000 population (1999 est.)
Death rate: 1 6.33 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 100.58 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 47. 1 4 years
male: 45.42 years
female: 48.92 years (1 999 est.)
Total fertility rate: 4.89 children born/woman (1999
est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi
12%, Teke 17%, Europeans NA%; note - Europeans
estimated at 8,500, mostly French, before the 1997
civil war; may be half of that in 1998, following the
widespread destruction of foreign businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo has
the most users)
Literacy:
definition: age 15 and over can read and write
total population: 74.9%
male: 83.1%
female: 67.2% (1995 est.)','4c22add6e421a6c75603f87ae5b56dcbd279dbc80834da5034254f7b86213db4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ced116dcc3fc0c26eadb77d995b828b29aae74026e89c4b435e10d0f22dc5204',1999,'CK','Cook Islands','people-and-society',312,'Population: 20,200 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.04% (1999 est.)
Birth rate: 22.35 births/1,000 population (1999 est.)
Death rate: 5.2 deaths/1,000 population (1999 est.)
Net migration rate: -6.75 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 24.7 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .14 years
male: 69.2 years
female: 73.1 years (1999 est.)
Total fertility rate: 3.17 children born/woman (1999
est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81.3%,
Polynesian and European 7.7%, Polynesian and
non-European 7.7%, European 2.4%, other 0.9%
Religions: Christian (majority of populace are
members of the Cook Islands Christian Church)
Languages: English (official), Maori
Literacy: NA
Population: uninhabited
note: Millersville settlement on western side of island
occasionally used as a weather station from 1 935 until
World War II, when it was abandoned; reoccupied in
1957 during the International Geophysical Year by
scientists who left in 1958; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Sen/ice','3537a1db74714c8c6ece2bebf245175100ef9f5a948fdc4fe3868bb87ba4fbb0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4993b8c29b374592deab44b1fc735de0f19fc36b1cf30af4e9349ae2531bec87',1999,'CR','Costa Rica','people-and-society',320,'Population: 3,674,490 (July 1999 est.)
Age structure:
0-14 years: 33% (male 622,260; female 593,720)
15-64 years: 62% (male 1,150,900; female
1,121,970)
65 years and over: 5% (male 85,526; female
100,114) (1999 est.)
Population growth rate: 1 .89% (1 999 est.)
Birth rate: 22.46 births/1 ,000 population (1 999 est.)
Death rate: 4.16 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.63 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .02 male(s)/fema!e (1999 est.)
Infant mortality rate: 12.89 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.04 years
male: 73.6 years
female: 78.61 years (1999 est.)
Total fertility rate: 2.76 children born/woman (1999
est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white (including mestizo) 96%, black
2%, Amerindian 1%, Chinese 1%
Religions: Roman Catholic 95%
Languages: Spanish (official), English spoken
around Puerto Limon
Literacy:
definition: age 15 and over can read and write
total population: 94.8%
male: 94.7%
female: 95% (1995 est.)
Country name:
conventional long form: Republic of Costa Rica
conventional short form: Costa Rica
local long form: Republics de Costa Rica
local short form: Costa Rica
Data code: CS
Government type: democratic republic
Capital: San Jose
Administrative divisions: 7 provinces (provincias,
singular - provincial; Alajuela, Cartago, Guanacaste,
Heredia, Limon, Puntarenas, San Jose
Independence: 15 September 1821 (from Spain)
National holiday: Independence Day, 15
September (1821)
Constitution: 9 November 1949
Legal system: based on Spanish civil law system;
judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: President Miguel Angel RODRIGUEZ
(since 8 May 1 998); First Vice President Astrid
FISCHEL Volio (since 8 May 1998), Second Vice
President Elizabeth ODIO Benito (since 8 May 1998);
note - president is both the chief of state and head of
Population: 15,818,068 (July 1999 est.)
Age structure:
0-14 years: 47% (male 3,702,051 ; female 3,664,672)
15-64 years: 51% (male 4,154,440; female
3,952,999)
65 years and over: 2% (male 1 74,065; female
169,841) (1999 est.)
Population growth rate: 2.35% (1999 est.)
Birth rate: 41 .76 births/1 ,000 population (1 999 est.)
Death rate: 16.17 deaths/1 ,000 population (1 999
est.)
Net migration rate: -2.08 migrant(s)/1 ,000
population (1999 est.)
note: after Liberia''s civil war started in 1990, more
than 350,000 refugees fled to Cote d''Ivoire and, by
September 1998, according to the UNHCR, about
85,000 remain
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .03 male(s)/female (1999 est.)
Infant mortality rate: 94.17 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 46.05 years
male: 44.48 years
female: 47.67 years (1999 est.)
Total fertility rate: 5.89 children born/woman (1999
est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Baoule 23%, Bete 18%, Senoufou
15%, Malinke 11%, Agni, Africans from other
countries (mostly Burkinabe and Malians, about 3
million), non-Africans 130,000 to 330,000 (French
30,000 and Lebanese 100,000 to 300,000)
Religions: Muslim 60%, Christian 22%, indigenous
18% (some of these are also numbered among the
Christians and Muslims)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 1 5 and over can read and write
total population: 48.5%
120
Cote d''Ivoire (continued)
mate: 57%
female: 40%','f5dc70e95b4bc67e0c67e587eadca77fbf4f815ee3f73fc9c0c7ba4562ba23fb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8d75dfc6dd9387a6e64277b4aeed2f61511b8cef6d58bec9099ee2341514e0c',1999,'SI','Slovenia','people-and-society',328,'Population: 4,676,865 (July 1999 est.)
Age structure:
0-14 years: 17% (male 404,761 ; female 383,088)
15-64 years: 68% (male 1 ,591 ,831 ; female
1,591,106)
65 years and over: 1 5% (male 272,21 9; female
433,860) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 10.34 births/1,000 population (1999 est.)
Death rate: 11.14 deaths/1 ,000 population (1 999
est.)
Net migration rate: 1 .81 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.94 male(s)/female (1 999 est.)
Infant mortality rate: 7.84 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74 years
male: 70.69 years
female: 77. 52 years (1999 est.)
Total fertility rate: 1 .52 children born/woman (1 999
est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic groups: Croat 78%, Serb 12%, Muslim 0.9%,
Hungarian 0.5%, Slovenian 0.5%, others 8.1% (1991)
Religions: Catholic 76.5%, Orthodox 1 1 .1 %, Muslim
1.2%, Protestant 0.4%, others and unknown 10.8%
Languages: Serbo-Croatian 96%, other 4%
(including Italian, Hungarian, Czech, Slovak, and
German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 95% (1991 est.)','d028c229b1fa84dfa3ed6d644889c6c087fe45744308f8bfdee39cd3bad67ded','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b717efe138be02794ab00c0fe6072755268b72312684c54a97bb741467d96b2',1999,'CU','Cuba','people-and-society',337,'Population: 1 1 ,096,395 (July 1 999 est.)
Age structure:
0-14 years: 22% (male 1 ,236,899; female 1 ,1 72,560)
15-64 years: 69% (male 3,820,255; female
3,801,768)
65 years and over: 9% (male 496,772; female
568,141) (1999 est.)
125
Cuba (continued)
Population growth rate: 0.4% (1999 est.)
Birth rate: 12.9 births/1,000 population (1999 est.)
Death rate: 7.38 deaths/1 ,000 population (1999 est.)
Net migration rate: -1 .52 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 7.81 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.78 years
male: 73.41 years
female: 78.3 years (1999 est.)
Total fertility rate: 1 .58 children born/woman
(1999 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51 %, white 37%, black 11%,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 95.7%
male: 96.2%
female: 95.3% (1995 est.)','9ebbe2a10895c2271427aa97325065cc9f715ff50324ebd28292cd617c554fc8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa9a2a175dd66bf68261ec1243e2418a3f15d72f2367346b7394dda216049478',1999,'CY','Cyprus','people-and-society',345,'Population: 754,064 (July 1999 est.)
Age structure:
0-14 years: 24% (male 92,626; female 88,127)
15-64 years: 65% (male 249,083; female 244,750)
65 years and over: 11% (male 34,612; female
44,866) (1999 est.)
Population growth rate: 0.67% (1999 est.)
Birth rate: 1 3,64 births/1 ,000 population (1 999 est.)
Death rate: 7.42 deaths/1 ,000 population (1999 est.)
Net migration rate: 0.44 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/fema!e
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 7.68 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77 A years
male: 74.91 years
female: 79.39 years (1999 est.)
Total fertility rate: 2 children born/woman (1999
est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 78% (99.5% of the Greeks
live in the Greek Cypriot area; 0.5% of the Greeks live
in the Turkish Cypriot area), Turkish 18% (1 .3% of the
Turks live in the Greek Cypriot area; 98.7% of the
Turks live in the Turkish Cypriot area), other 4%
(99.2% of the other ethnic groups live in the Greek
Cypriot area; 0.8% of the other ethnic groups live in
the Turkish Cypriot area)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 15 and over can read and write
total population: 94%
male: 98%
female: 91% (1987 est.)','651610086c875c5a2ac46822884830a4fb2ee4034db27895461cc316fdea0883','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b5a3faf447fd3a9766d2ee49a164317258b38742bb0f6568876b2a49bc3ba75',1999,'PL','Poland','people-and-society',355,'Population: 1 0,280,51 3 (July 1 999 est.)
Age structure:
0-14 years: 17% (male 888,292; female 845,662)
15-64 years: 69% (male 3,569,677; female
3,558,844)
65 years and over: 1 4% (male 545,305; female
872,733) (1999 est.)
Population growth rate: -0.01% (1999 est.)
Birth rate: 9.84 births/1 ,000 population (1999 est.)
Death rate: 1 0.86 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0.91 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 6,67 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.35 years
male: 71 .01 years
female: 77.88 years (1999 est.)
Total fertility rate: 1.28 children born/woman (1999
est.)
Nationality:
noun: Czech(s)
adjective: Czech
note: 300,000 Slovaks declared themselves Czech
citizens in 1994
Ethnic groups: Czech 94.4%, Slovak 3%, Polish
0.6%, German 0.5%, Gypsy 0.3%, Hungarian 0.2%,
other 1%
Religions: atheist 39.8%, Roman Catholic 39.2%,
Protestant 4.6%, Orthodox 3%, other 13.4%
Languages: Czech, Slovak
Literacy:
definition: NA
total population: 99% (est.)
male: NA%
female: NA%','63917b5393dc45a43ed81c309cc7ac76e2d62f1ca057c54230c0301ada4274f6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddf809dbfad3e5abbeb79e81bb4aa5ef1dd892eb08f4cb97c1b5f7df10f37a85',1999,'DK','Denmark','people-and-society',364,'Population: 5,356,845 (July 1999 est.)
Age structure:
0-14 years: 18% (male 504,182; female 478,547)
15-64 years: 67% (male 1 ,81 1 ,445; female
1,765,038)
65 years and over: 1 5% (male 331 ,207; female
466,426) (1999 est.)
Population growth rate: 0.38% (1999 est.)
Birth rate: 1 1 .57 births/1 ,000 population (1 999 est.)
Death rate: 10.97 deaths/1 ,000 population (1999
est.)
Net migration rate: 3.22 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.71 male(s)/fema!e
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.1 1 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.51 years
male: 73.83 years
female: 79.33 years (1999 est.)
Total fertility rate: 1 .62 children born/woman (1999
est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Eskimo, Faroese,
German
Religions: Evangelical Lutheran 91%, other
Protestant and Roman Catholic 2%, other 7% (1988)
Languages: Danish, Faroese, Greenlandic (an
Eskimo dialect), German (small minority)
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1980 est.)
mate: NA%
female: NA%
Population: 447,439 (July 1999 est.)
Age structure:
0-14 years: 43% (male 96,222; female 96,023)
15-64 years: 54% (male 128,506; female 1 14,767)
65 years and over: 3% (male 6,155; female 5,766)
(1999 est.)
Population growth rate: 1 .51% (1 999 est.)
Birth rate: 41 .23 births/1 ,000 population (1 999 est.)
Death rate: 14.41 deaths/1,000 population (1999
est.)
Net migration rate: -1 1 .73 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 ma!e(s)/female
15-64 years: 1.12 ma!e(s)/female
65 years and over: 1 .07 male(s)/female
total population: 1 .07 male(s)/female (1999 est.)
Infant mortality rate: 100.24 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 51 .54 years
mate: 49.48 years
female: 53.67 years (1999 est.)
Total fertility rate: 5,87 children born/woman (1999
est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 1 5 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)','9ba5b2826ec130255cedb04fd3bfa1fd12343daab7d6785b7484f85f6f5db93c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('338a88e7238ee2805d5f1e75a9713ec2f9e29a8d389c25f30b54165d6b538713',1999,'DM','Dominica','people-and-society',368,'Population: 64,881 (July 1999 est.)
Age structure:
0-14 years: 27% (male 8,680; female 8,530)
15-64 years: 64% (male 21 ,090; female 20,294)
65 years and over: 9% (male 2,570; female 3,71 7)
(1999 est.)
Population growth rate: -1.41% (1999 est.)
Birth rate: 16.92 births/1 ,000 population (1999 est.)
Death rate: 6.35 deaths/1 ,000 population (1 999 est.)
Net migration rate: -24.69 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .02 ma!e(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 8.75 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.01 years
male: 75.1 5 years
female: 81 .01 years (1999 est.)
Total fertility rate: 1.89 children born/woman (1999
est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), none 2%, other
6%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
female: 94% (1970 est.)','93b364fea172531d965e1888964fa0d4e20592366f5123e3173d3c1ec69518d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cda9b279b063c7d490f892cfe9b0797630b459d2471df802b042da0d21e0729a',1999,'DO','Dominican Republic','people-and-society',375,'Population: 8,129,734 (July 1999 est.)
Age structure:
0-14 years: 35% (male 1 ,447,435; female 1,393,122)
15-64 years: 61 % (male 2,501 ,206; female
2,426,564)
65 years and over: 4% (male 171 ,049; female
190,358) (1999 est.)
Population growth rate: 1.62% (1999 est.)
Birth rate: 25.97 births/1 ,000 population (1 999 est.)
Death rate: 5.66 deaths/1 ,000 population (1999 est.)
Net migration rate: -4.14 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 42.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.07 years
male: 67.86 years
female: 72.4 years (1999 est.)
Total fertility rate: 3.03 children born/woman (1999
est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 82. 1 %
male: 82%
female: 82.2% (1995 est.)
Population: 3,887,652 (July 1999 est.)
Age structure:
0-14 years: 24% (male 482,1 1 1 ; female 459,940)
15-64 years: 65% (male 1 ,220,682; female
1,323,787)
65 years and over: 1 1 % (male 1 73,1 33; female
227,999) (1999 est.)
Population growth rate: 0.59% (1999 est.)
Birth rate: 15.9 births/1,000 population (1999 est.)
Death rate: 7.87 deaths/1 ,000 population (1 999 est.)
Net migration rate: -2.1 5 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.93 male(s)/female (1 999 est.)
Infant mortality rate: 1 0.79 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.06 years
male: 70.95 years
female: 79.41 years (1999 est.)
Total fertility rate: 1 ,94 children born/woman (1 999
est.)
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: Hispanic
Religions: Roman Catholic 85%, Protestant
denominations and other 15%
Languages: Spanish, English
395
Puerto Rico (continued)
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 90%
female: 88% (1980 est.)','43181a8eca6cf68c0ad3eb9083cd49f6fadad4dc7529450af5e770fade9e33d8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1af104367233962457e55b618ac750289a134d8532fd1c1faf6953de0736ee30',1999,'PE','Peru','people-and-society',381,'Population: 1 2,562,496 (July 1 999 est.)
Age structure:
0-14 years: 35% (male 2,250,690; female 2,1 72,302)
15-64 years: 60% (male 3,745,390; female
3,833,841)
65 years and over: 5% (male 261 ,090; female
299,183) (1999 est.)
Population growth rate: 1 .78% (1 999 est.)
Birth rate: 22.26 births/1,000 population (1999 est.)
Death rate: 5.06 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.55 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 30.69 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72. 1 6 years
male: 69.54 years
female: 74.9 years (1999 est.)
Total fertility rate: 2.63 children born/woman (1999
est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and
Spanish) 55%, Amerindian 25%, Spanish 10%, black
10%
Religions: Roman Catholic 95%
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 15 and over can read and write
total population: 90.1%
male: 92%
female: 88.2% (1995 est.)','798b59c9204bb38a5c39104c78c4f35f8c0c920624474aca209a3546998bc165','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d967ca360eccb19bc3e4a6b50e02c74fbc16bc05cbdc8e59910c935b5d4e678',1999,'EG','Egypt','people-and-society',389,'Population: 67,273,906 (July 1999 est.)
Age structure:
0-14 years: 36% (male 12,260,845; female
11,712,752)
15-64 years: 61% (male 20,604,620; female
20,211,012)
65 years and over: 3% (male 1 ,099,51 7; female
1,385,160) (1999 est.)
Population growth rate: 1 .82% (1 999 est.)
Birth rate: 26.8 births/1 ,000 population (1999 est.)
Death rate: 8.27 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.35 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
144
Egypt (continued)
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .02 male(s)/female (1 999 est.)
Infant mortality rate: 67.46 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 62.39 years
male: 60.39 years
female: 64.49 years (1999 est.)
Total fertility rate: 3.33 children born/woman (1999
est.)
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions: Muslim (mostly Sunni) 94% (official
estimate), Coptic Christian and other 6% (official
estimate)
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 15 and over can read and write
total population: 51 .4%
male: 63.6%
female: 38.8% (1995 est.)
Religions: Roman Catholic 75%
note: there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 15 and over can read and write
total population: 71 .5%
male: 73.5%
female: 69.8% (1995 est.)
Population: 465,746 (July 1999 est.)
Age structure:
0-14 years: 43% (male 100,334; female 99,826)
15-64 years: 53% (male 1 1 8,248; female 1 29,777)
65 years and over: 4% (male 7,801 ; female 9,760)
(1999 est.)
Population growth rate: 2.55% (1999 est.)
Birth rate: 38.49 births/1,000 population (1999 est.)
Death rate: 12.98 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
note: migration to Spain is a traditional and continuing
factor; between 80% and 90% of Equatorial Guinean
nationals going to Spain do not return
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
1 5-64 years: 0.91 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 91.18 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54.39 years
male: 52.03 years
female: 56.83 years (1999 est.)
Total fertility rate: 5 children born/woman (1999
est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1 ,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 15 and over can read and write
total population: 78.5%
male: 89.6%
female: 68.1% (1995 est.)','2945e2f30166569476066644164d20c6221976ed96be6f30f413c960bed47c6c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e830b9c545f4d59e69acd4ab1748f5a3f269d5ee8f2e6fffb558703debad908',1999,'GN','Guinea','people-and-society',404,'Population: 3,984,723 (July 1999 est.)
Age structure:
0-14 years: 43% (male 859,899; female 852,329)
15-64 years: 54% (male 1 ,061 ,921 ; female
1,078,102)
65 years and over: 3% (male 67,969; female 64,503)
(1999 est.)
Population growth rate: 3.88% (1999 est.)
Birth rate: 42.56 births/1,000 population (1999 est.)
Death rate: 1 2.32 deaths/1 ,000 population (1 999
est.)
Net migration rate: 8.53 migrant(s)/1 ,000
population (1999 est.)
note: it is estimated that approximately 315,000
Eritrean refugees were still living in Sudan by the end
of 1997 according to the UNHCR
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .05 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 76.84 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 55.74 years
male: 53.61 years
female: 57.95 years (1 999 est.)
Total fertility rate: 5.96 children born/woman (1999
est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
151
Eritrea (continued)
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, minor ethnic group languages
Literacy: NA
Population: 4,705,126 (July 1999 est.)
Age structure:
0-14 years: 39% (male 951 ,532; female 902,841 )
15-64 years: 58% (male 1 ,41 1 ,053; female
1,298,937)
65 years and over: 3% (male 64,101 ; female 76,662)
(1999 est.)
Population growth rate: 2.26% (1999 est.)
Birth rate: 32.04 births/1 ,000 population (1999 est.)
Death rate: 9.47 deaths/1 ,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .07 male(s)/female (1999 est.)
Infant mortality rate: 55.58 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 58.47 years
male: 57.58 years
female: 59.4 years (1 999 est.)
Total fertility rate: 4.17 children born/woman (1999
est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society
8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant sects
10%, indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin
English widespread, Motu spoken in Papua region
note: 715 indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 72.2%
379
Papua New Guinea (continued)
male: 81%
female: 62.7% (1995 est.)','d393358831c910d7ba8b43c7eb969c7fea3166e235616005ba93e9bba3418454','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc6e098767808728235b1ae6240f596641e5b8aba0b5d6a3ce01768ee82e7dfa',1999,'EE','Estonia','people-and-society',407,'Population: 1 ,408,523 (July 1999 est.)
Age structure:
0-14 years: 18% (male 130,883; female 126,112)
15-64 years: 67% (male 455,1 12; female 491 ,819)
65 years and over: 1 5% (male 66,700; female
137,897) (1999 est.)
Population growth rate: -0.82% (1999 est.)
Birth rate: 9.05 births/1 ,000 population (1 999 est.)
Death rate: 14.21 deaths/1,000 population (1999
est.)
Net migration rate: -3.08 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.86 male(s)/female (1999 est.)
Infant mortality rate: 1 3.83 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.65 years
male: 62.61 years
female: 75 years (1999 est.)
Total fertility rate: 1 .28 children born/woman (1 999
est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 65.1%, Russian 28.1%,
Ukrainian 2.5%, Byelorussian 1.5%, Finn 1%, other
1.8% (1998)
Religions: Evangelical Lutheran, Russian Orthodox,
Estonian Orthodox, others include Baptist, Methodist,
Seventh Day Adventist, Roman Catholic, Pentecostal,
Word of Life, Seventh Day Baptist, Judaism
Languages: Estonian (official), Russian, Ukrainian,
English, Finnish, other
Literacy:
definition: age 1 5 and over can read and write
total population: 1 00%
male: 100%
female: 100% (1998 est.)','0c67a9cf771d648ae173a4920bfa73bedacb9d0cc5de4a462fed6f052e4ff6f0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bbd6058bf6c5cdad458b7ef9319b75350310e96143ba54f6064c5fbd4aa125f',1999,'ET','Ethiopia','people-and-society',415,'Population: 59,680,383 (July 1999 est.)
Age structure:
0-14 years: 46% (male 13,787,810; female
13,703,546)
15-64 years: 51% (male 15,398,123; female
15,141,892)
65 years and over: 3% (male 745,737; female
903,275) (1999 est.)
Population growth rate: 2.16% (1999 est.)
Birth rate: 44.34 births/1 ,000 population (1999 est.)
Death rate: 21.43 deaths/1,000 population (1999
est.)
Net migration rate: -1 .3 migrant(s)/1 ,000 population
(1999 est.)
note: repatriation of Ethiopians who fled to Sudan,
Kenya, and Somalia for refuge from war and famine in
earlier years, is expected to continue slowly in 1998;
small numbers of Sudanese and Somali refugees,
who fled to Ethiopia from the fighting in their own
countries, began returning to their homes in 1998
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 ,01 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.01 ma!e(s)/female (1999 est.)
Infant mortality rate: 124.57 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 40.46 years
male: 39.22 years
female: 41 .73 years (1 999 est.)
Total fertility rate: 6.81 children born/woman (1999
est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigrean
32%, Sidamo9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Orominga,
Guaraginga, Somali, Arabic, English (major foreign
language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)
Population: 705,156 (July 1999 est.)
Age structure:
0-14 years: 30% (male 109,156; female 105,017)
15-64 years: 65% (male 230,624; female 227,677)
65 years and over: 5% (male 1 4,684; female 1 7,998)
(1999 est.)
Population growth rate: -0.32% (1999 est.)
Birth rate: 1 8.23 births/1 ,000 population (1 999 est.)
Death rate: 9.04 deaths/1 ,000 population (1999 est.)
Net migration rate: -12.43 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 48.64 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 61 .82 years
male: 59.15 years
female: 64.61 years (1 999 est.)
Total fertility rate: 2.09 children born/woman (1999
est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 49%, black 32%, mixed
12%, Amerindian 6%, white and Chinese 1%
Religions: Christian 57%, Hindu 33%, Muslim 9%,
other 1%
Languages: English, Amerindian dialects
Literacy:
definition: age 15 and over has ever attended school
208
Guyana (continued)
total population: 98.1%
male: 98.6%
female: 97.5% (1995 est.)','50b86e1cadeccd4c46659f50349ceba53f8c025e2bb4b2756ea38747d47c60cf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dae56f4a2c78f5372386940a6bedd09431edc2b4bfef0e177a5267371214dcaa',1999,'DJ','Djibouti','people-and-society',423,'Population: no indigenous inhabitants
note: there is a small French military garrison','aa6f90d46339fd170daf48c9f1e8a06e162d8c909ac2e8536c819ffd9364fba0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('007cc508642b61f464930b3ae6fcc2aecead8c744d521f84a151efcef5409cb9',1999,'FO','Faroe Islands','people-and-society',426,'Population: 41 ,059 (July 1 999 est.)
Age structure:
0-14 years: 23% (male 4,81 9; female 4,629)
15-64 years: 62% (male 1 3,600; female 11,811)
65 years and over: 1 5% (male 2,786; female 3,41 4)
(1999 est.)
Population growth rate: -2.03% (1999 est.)
Birth rate: 1 2.54 births/1 ,000 population (1 999 est.)
Death rate: 9.08 deaths/1 ,000 population (1 999 est.)
Net migration rate: -23.72 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 1 0.26 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.56 years
mate: 75.66 years
female: 81 .58 years (1 999 est.)
Total fertility rate: 2.36 children born/woman (1999
est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy: NA
note: similar to Denmark proper','22e20d311cf77c24e65801d5ecc3b27a8d887776f5c655777fe858868e5482fa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c2028b33b98802ebc9fa933d7651f66b003ed87468a8ad393fec6541e5036b',1999,'JE','Jersey','people-and-society',434,'Population: 812,918 (July 1999 est.)
Age structure:
0-14 years: 33% (male 138,796; female 133,428)
15-64 years: 63% (male 257, 1 30; female 256,834)
65 years and over: 4% (male 1 2,527; female 1 4,203)
(1999 est.)
Population growth rate: 1 .28% (1 999 est.)
Birth rate: 22.76 births/1 ,000 population (1 999 est.)
Death rate: 6.21 deaths/1 ,000 population (1 999 est.)
Net migration rate: -3.78 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 1 6.3 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.59 years
male: 64.19 years
female: 69.11 years (1999 est.)
Total fertility rate: 2.7 children born/woman (1999
est.)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51%, Indian 44%, European,
other Pacific Islanders, overseas Chinese, and other
5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
total population: 91 .6%
male: 93.8%
female: 89.3% (1995 est.)
Population: 5,749,760 (July 1999 est.)
note: includes about 166,000 Israeli settlers in the
West Bank, about 19,000 in the Israeli-occupied
Golan Heights, about 6,000 in the Gaza Strip, and
about 176,000 in East Jerusalem (August 1998 est.)
Age structure:
0-14 years: 28% (male 822,192; female 783,905)
15-64 years: 62% (male 1 ,792,062; female
1,783,755)
65 years and over: 10% (male 244,438; female
323,408) (1999 est.)
Population growth rate: 1.81% (1999 est.)
Birth rate: 1 9.83 births/1 ,000 population (1 999 est.)
Death rate: 6.1 6 deaths/1 ,000 population (1999 est.)
238
Israel (continued)
Net migration rate: 4.42 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 7.78 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.61 years
male: 76.71 years
female: 80.61 years (1999 est.)
Total fertility rate: 2.68 children born/woman (1999
est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/
America-born 32.1%, Israel-born 20.8%, Africa-born
14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Judaism 80.1%, Islam 14.6% (mostly
Sunni Muslim), Christian 2.1%, other 3.2% (1996 est.)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)
Population: 89,721 (July 1999 est.)
Age structure:
0-14 years: 18% (male 8,308; female 7,663)
15-64 years: 68% (male 30,168; female 30,754)
65 years and over: 1 4% (male 5,348; female 7,480)
(1999 est.)
Population growth rate: 0.63% (1999 est.)
Birth rate: 1 1 .85 births/1 ,000 population (1999 est.)
Death rate: 9.08 deaths/1 ,000 population (1 999 est.)
Net migration rate: 3.49 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 2.76 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.83 years
male: 76.08 years
female: 81 .87 years (1999 est.)
Total fertility rate: 1 .5 children born/woman (1 999
est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist, Presbyterian
Languages: English (official), French (official),
Norman-French dialect spoken in country districts
Literacy: NA
Population: no indigenous inhabitants
note: there are 1 ,200 US military and civilian
contractor personnel (January 1999 est.)
Population: 4,561,147 (July 1999 est.)
Age structure:
0-14 years: 43% (male 1 ,005,21 1 ; female 954,968)
15-64 years: 54% (male 1 ,265,1 1 6; female
1,200,372)
65 years and over: 3% (male 67,852; female 67,628)
(1999 est.)
Population growth rate: 3.05% (1999 est.)
Birth rate: 34.31 births/1,000 population (1999 est.)
Death rate: 3.85 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1 male(s)/female
total population: 1 .05 male(s)/female (1999 est.)
Infant mortality rate: 32.7 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.06 years
male: 71.15 years
female: 75.08 years (1 999 est.)
Total fertility rate: 4.64 children born/woman (1999
est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1 %, Armenian
1%
Religions: Sunni Muslim 96%, Christian 4% (1997
est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 15 and over can read and write
total population: 86.6%
male: 93.4%
female: 79.4% (1995 est.)
Population: 1 ,991 ,115 (July 1 999 est.)
no/e; includes 1,220,935 non-nationals (July 1999
est.)
Age structure:
0-14 years: 32% (male 343,461 ; female 285,129)
15-64 years: 66% (male 850,689; female 468,618)
65 years and over: 2% (male 26,593; female 1 6,625)
(1999 est.)
Population growth rate: 3.88% (1999 est.)
note: this rate reflects the continued post-Gulf crisis
return of expatriates
Birth rate: 20.45 births/1 ,000 population (1999 est.)
Death rate: 2.31 deaths/1 ,000 population (1999 est.)
Net migration rate: 20.65 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .2 male(s)/female
15-64 years: 1 .82 male(s)/female
65 years and over: 1 .6 male(s)/female
total population: 1 .58 male(s)/female (1999 est.)
Infant mortality rate: 10.26 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77. 1 5 years
male: 75.11 years
female: 79.3 years (1999 est.)
Total fertility rate: 3.34 children born/woman (1999
est.)
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 45%, Shi''a 40%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 78.6%
male: 82.2%
female: 74.9% (1995 est.)
Population: 197,361 (July 1999 est.)
350
New Caledonia (continued)
Age structure:
0-14 years: 29% (male 29,610; female 28,485)
15-64 years: 65% (male 64,552; female 63,229)
65 years and over: 6% (male 5,443; female 6,042)
(1999 est.)
Population growth rate: 1 .59% (1999 est.)
Birth rate: 20.68 births/1 ,000 population (1999 est.)
Death rate: 4.82 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.08 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .02 male(s)/female (1 999 est.)
infant mortality rate: 12.15 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.35 years
male: 72.1 years
female: 78.77 years (1 999 est.)
Total fertility rate: 2.43 children born/woman (1999
est.)
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1 .6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French, 28 Melanesian-Polynesian
dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
Population: 985,335 (July 1999 est.)
Age structure:
0-14 years: 46% (male 227,675; female 228,733)
15-64 years: 51% (male 243,853; female 259,950)
65 years and over: 3% (male 9,866; female 1 5,258)
(1999 est.)
Population growth rate: 1 .91% (1999 est.)
Birth rate: 40.8 births/1,000 population (1999 est.)
Death rate: 21 .72 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
af birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 1 01 .87 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 38. 1 1 years
male: 36.86 years
female: 39.4 years (1999 est.)
Total fertility rate: 5.92 children born/woman (1999
est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs 40%
Languages: English (official, government business
conducted in English), siSwati (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 76.7%
mate: 78%
female: 75.6% (1995 est.)
Population: 8,91 1 ,296 (July 1 999 est.)
Age structure:
0-14 years: 19% (male 856,819; female 812,958)
15-64 years: 64% (male 2,896,383; female
2,802,571)
65 years and over: 17% (male 651 ,549; female
891,016) (1999 est.)
Population growth rate: 0.29% (1999 est.)
Birth rate: 12 births/1,000 population (1999 est.)
Death rate: 1 0.77 deaths/1 ,000 population (1 999 est.)
Net migration rate: 1 .68 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 3.91 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 79.29 years
male: 76.61 years
female: 82.1 1 years (1 999 est.)
Total fertility rate: 1 .83 children born/woman (1999
est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: white, Lapp (Sami), foreign-born or
first-generation immigrants 12% (Finns, Yugoslavs,
Danes, Norwegians, Greeks, Turks)
Religions: Evangelical Lutheran 94%, Roman
Catholic 1 .5%, Pentecostal 1%, other 3.5% (1987)
Languages: Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%
[. G o v e rntnent
Country name:
conventional long form: Kingdom of Sweden
conventional short form: Sweden
local long form: Konungariket Sverige
local short form: Sverige
Data code: SW
Government type: constitutional monarchy
Capital: Stockholm
Administrative divisions: 21 counties (Ian, singular
and plural); Blekinge, Dalarnas, Gavleborgs,
Gotlands, Hallands, Jamtlands, Jonkopings, Kalmar,
Kronobergs, Norrbottens, Orebro, Ostergotlands,
Skane, Sodermanlands, Stockholms, Uppsala,
Varmlands, Vasterbottens, Vasternorrlands,
Vastmanlands, Vastra Gotalands
Independence: 6 June 1 523 (Gustav VASA elected
king); 6 June 1809 (constitutional monarchy was
established)
National holiday: Day of the Swedish Flag, 6 June
Constitution: 1 January 1975
Legal system: civil law system influenced by
customary law; accepts compulsory ICJ jurisdiction,
with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: King CARL XVI GUSTAF (since 19
September 1 973); Heir Apparent Princess VICTORIA
Ingrid Alice Desiree, daughter of the monarch (born 14
July 1977)
463
Sweden (continued)
head of government: Prime Minister Goran
PERSSON (since 21 March 1996)
cabinet: Cabinet appointed by the prime minister
elections: the monarch is hereditary; prime minister
elected by the Parliament; election last held NA
September 1998 (next to be held NA 2002)
election results: Goran PERSSON reelected prime
minister; percent of parliamentary vote -131 votes out
of 349
Legislative branch: unicameral Parliament or
Riksdag (349 seats; members are elected by popular
vote on a proportional representation basis to serve
four-year terms)
elections: last held 20 September 1998 (next to be
held NA September 2002)
election results: percent of vote by party - Social
Democrats 36.5%, Moderates 22.7%, Left Party 1 2%,
Christian Democrats 1 1 .8%, Center Party 5.1%,
Liberal Party 4.7%, Greens 4.5%; seats by party -
Social Democrats 131, Moderates 82, Left Party 43,
Christian Democrats 42, Center Party 18, Liberal
Party 17, Greens 16
Judicial branch: Supreme Court or Hogsta
Domstolen, judges are appointed by the government
(prime minister and cabinet)
Political parties and leaders: Social Democratic
Party [Goran PERSSON]; Moderate Party
(conservative) [Carl BILDT]; Liberal People''s Party
[Maria LEISSNER]; Center Party [Lennart DALEUS];
Christian Democratic Party [Alf SVENSSON]; New
Democracy Party [Vivianne FRANZEN]; Left Party or
VP (formerly Communist) [Gudrun SCHYMAN];
Communist Workers'' Party [Rolf HAGEL]; Green
Party [no formal leader but party spokesperson is
BrigerSCHLAUG]
International organization participation: ACCT,
AfDB, AsDB, Australia Group, BIS, CCC, CE, CERN,
EAPC, EBRD, ECE, EFTA, ESA, FAO, G-10, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, IEA,
IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, IOM, ISO, ITU, LAIA (observer), MTCR,
NAM (guest), NEA, NSG, OAS (observer), OECD,
OPCW, OSCE, PCA, PFP, UN (observer), UNCTAD,
UNESCO, UNHCR, UNIDO, UNITAR, UNMIBH,
UNMOP, UNMOT, UNOMIG, UNPREDEP, UNTSO,
UNU, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO,
ZC
Diplomatic representation in the US:
chief of mission: Ambassador Rolf EKEUS
chancery: 1501 M Street NW, Washington, DC
20005-1702
telephone:) 1] (202) 467-2600
FAX: [1] (202) 467-2699
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: Ambassador Lyndon Lowell
OLSON, Jr.
embassy: Strandvagen 1 01 , S-1 1 5 89 Stockholm
mailing address: American Embassy Stockholm,
Department of State, Washington, DC 20521-5750
(pouch)
telephone: [46] (8)783 53 00
FAX: [46] (8)661 19 64
Flag description: blue with a yellow cross that
extends to the edges of the flag; the vertical part of the
cross is shifted to the hoist side in the style of the
Dannebrog (Danish flag)','0cbb71513d706428ff7dcc94fc2131591d822992b27105bc2553f7f67c0f98a6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fae8953d08a667574a2f835a17b46baafb0b09fd268879f1da76ea46478fe616',1999,'FI','Finland','people-and-society',444,'Population: 5,158,372 (July 1999 est.)
Age structure:
0-14 years: 18% (male 483,700; female 464,431)
15-64 years: 67% (male 1 ,743,340; female
1,706,873)
65 years and over: 1 5% (male 289,405; female
470,623) (1999 est.)
Population growth rate: 0.15% (1999 est.)
Birth rate: 1 0.77 births/1 ,000 population (1 999 est.)
Death rate: 9.67 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.4 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 3.8 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.32 years
male: 73.81 years
female: 80.98 years (1999 est.)
Total fertility rate: 1 .68 children born/woman (1 999
est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Lapp 0.1 1%,
Gypsy 0.12%, Tatar 0.02%
Religions: Evangelical Lutheran 89%, Greek
Orthodox 1%, none 9%, other 1%
Languages: Finnish 93.5% (official), Swedish 6.3%
(official), small Lapp- and Russian-speaking
minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%','d1d32ca07dbf18960e8fa323244259cef3314a64d62a83af6567cbadc7664dad','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b7c3ab883eb1f917b6b70e6a58f2d95c982eb438bd7ce4329df5be2437b8572',1999,'WF','Wallis and Futuna','people-and-society',459,'Population: 167,982 (July 1999 est.)
Age structure:
0-14 years: 31% (male 26,713; female 25,514)
15-64 years: 64% (male 57,935; female 48,959)
65 years and over: 5% (male 4,479; female 4,382)
(1999 est.)
Population growth rate: 3.19% (1999 est.)
Birth rate: 23.27 births/1,000 population (1999 est.)
Death rate: 4.52 deaths/1 ,000 population (1 999 est.)
Net migration rate: 13.1 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.18 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .13 ma!e(s)/female (1999 est.)
Infant mortality rate: 12.93 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 76.61 years
male: 73.41 years
female: 79.97 years (1999 est.)
Total fertility rate: 3.31 children born/woman (1999
est.)
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 12%,
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 84%
female: 82% (1982 est.)','d8c49f392465dcc99960a526c4bc827f7308edfc469d2756879655c4bd24057d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbc85ac67ff77bfe9815b0de5e78bcda80037892824ae34f3394411910009cab',1999,'KI','Kiribati','people-and-society',462,'Population: 242,073 (July 1999 est.)
Age structure:
0-14 years: 33% (male 40,422; female 38,913)
15-64 years: 63% (male 78,637; female 72,832)
65 years and over: 4% (male 5,642; female 5,627)
(1999 est.)
Population growth rate: 1.72% (1999 est.)
Birth rate: 22.08 births/1,000 population (1999 est.)
Death rate: 5.06 deaths/1 ,000 population (1999 est.)
Net migration rate: 0.19 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema1e
under 15 years: 1 ,04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 male(s)/female
total population: 1 .06 male(s)/female (1999 est.)
Infant mortality rate: 13.59 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.33 years
male: 69,93 years
female: 74.85 years (1999 est.)
Total fertility rate: 2.64 children born/woman (1999
est.)
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
female: 98% (1977 est.)','848327ff7d4a814d84b9045a4eeb9f7373b70f39cf1fb3e14a54e768d052a969','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e8c239bd8e5de5068504c747e8cee0757d16cd040e05da4d1fd867cab199938',1999,'GA','Gabon','people-and-society',469,'Population: 1 ,225,853 (July 1 999 est.)
Age structure:
0-14 years: 33% (male 205,076; female 205,198)
15-64 years: 61 % (male 376,1 81 ; female 370,479)
65 years and over: 6% (male 34,078; female 34,841)
(1999 est.)
Population growth rate: 1.48% (1999 est.)
Birth rate: 27.89 births/1,000 population (1999 est.)
Death rate: 1 3.07 deaths/1 ,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 ,03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .01 male(s)/female (1 999 est.)
Infant mortality rate: 83.1 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 56.98 years
male: 53.98 years
female: 60.08 years (1 999 est.)
Total fertility rate: 3.77 children born/woman (1999
est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major
tribal groupings (Fang, Eshira, Bapounou, Bateke),
other Africans and Europeans 154,000, including
6,000 French and 1 1 ,000 persons of dual nationality
Religions: Christian 55%-75%, Muslim less than
1%, animist
Languages: French (official), Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 15 and over can read and write
total population: 63.2%
male: 73.7%
female: 53.3% (1995 est.)
Population: 1 ,336,320 (July 1 999 est.)
Age structure:
0-14 years: 46% (male 305,839; female 304,905)
15-64 years: 52% (male 341 ,947; female 348,163)
65 years and over: 2% (male 1 8,706; female 1 6,760)
(1999 est.)
Population growth rate: 3.35% (1999 est.)
Birth rate: 42.76 births/1,000 population (1999 est.)
Death rate: 12.57 deaths/1,000 population (1999
est.)
Net migration rate: 3.34 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 75.33 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54.39 years
male: 52.02 years
female: 56.83 years (1999 est.)
Total fertility rate: 5.83 children born/woman (1999
est.)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1%
177
Gambia, The (continued)
Religions; Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages; English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy;
definition: age 1 5 and over can read and write
total population: 38,6%
male: 52.8%
female: 24.9% (1 995 est.)
Population: 1,11 2,654 (July 1 999 est.)
note: in addition, there are some 6,000 Israeli settlers
in the Gaza Strip (August 1998 est.)
Age structure:
0-14 years: 52% (male 294,1 96; female 280,017)
15-64 years: 46% (male 255,209; female 251 ,317)
65 years and over: 2% (male 1 3,475; female 1 8,440)
(1999 est.)
Population growth rate: 4.44% (1999 est.)
Birth rate: 48.24 births/1 ,000 population (1 999 est.)
Death rate: 3.8 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 22.92 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.44 years
male: 72.01 years
female: 74.95 years (1 999 est.)
Total fertility rate: 7.46 children born/woman
(1999 est.)
179
Gaza Strip (continued)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 0.7%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy: NA','48839d9c4735d3169f58effd3a9fb371ec079cb8f6e33524f8be9bf350b59064','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e6b2a917531a396abcde0a429084206b1274c3ec15c1bb7c47f5b4d5be3445',1999,'GH','Ghana','people-and-society',480,'Population: 18,887,626 (July 1999 est.)
Age structure:
0-14 years: 42% (male 4,020,493; female 3,982,81 6)
15-64 years: 54% (male 5,050,736; female
5,231,951)
65 years and over: 4% (male 284,423; female
317,207) (1999 est.)
Population growth rate: 2.05% (1999 est.)
Birth rate: 31 .79 births/1 ,000 population (1 999 est.)
Death rate: 1 0.4 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.88 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 76.1 5 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 57. 1 4 years
male: 55.08 years
female: 59.27 years (1999 est.)
Total fertility rate: 4.1 1 children born/woman (1999
est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 99.8% (major tribes -
Akan 44%, Moshi-Dagomba 1 6%, Ewe 1 3%, Ga 8%),
European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%,
Christian 24%, other 8%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 15 and over can read and write
total population: 64.5%
male: 75.9%
female: 53.5% (1995 est.)','f56cd9d02857906145071e0ceb007fde777312e5176a44156a64552d6f61e8fa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb158033918cbcdd837745110aa48babe67cd71ed3885ccec3f09656f77205a9',1999,'ES','Spain','people-and-society',488,'Population: 29,165 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,129; female 2,749)
15-64 years: 66% (male 10,888; female 8,247)
65 years and over: 14% (male 1,729; female 2,423)
(1999 est.)
Population growth rate: 0.39% (1999 est.)
Birth rate: 1 2.65 births/1 ,000 population (1 999 est.)
Death rate: 8.81 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.03 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .14 male(s)/female
15-64 years: 1 .32 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 1 .17 male(s)/female (1999 est.)
Infant mortality rate: 6.47 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.37 years
male: 75 .1 years
female: 81 .81 years (1999 est.)
Total fertility rate: 2.16 children born/woman (1999
est.)
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Italian, English, Maltese,
Portuguese, Spanish
Religions: Roman Catholic 74%, Protestant 11%
(Church of England 8%, other 3%), Muslim 8%,
Jewish 2%, none or other 5% (1981)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 95%
male: NA%
female: NA%
Population: 39,167,744 (July 1999 est.)
Age structure:
0-14 years: 15% (male 3,012,907; female 2,835,455)
15-64 years: 68% (male 1 3,41 1 ,046; female
13,406,214)
65 years and over: 17% (male 2,702,654; female
3,799,468) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 9.99 births/1,000 population (1999 est.)
Death rate: 9.69 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.66 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 maie(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 6.41 deaths/1 ,000 live births
(1999 est.)
449
Spain (continued)
Life expectancy at birth:
total population: 77.7 1 years
male: 73.97 years
female: 81.71 years (1999 est.)
Total fertility rate: 1 .24 children born/woman (1 999
est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 99%, other 1%
Languages: Castilian Spanish 74%, Catalan 17%,
Galician 7%, Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 98%
female: 94% (1986 est.)','5bbff312ed2d17a93d6b1d202573a3297242faeaf046f8f06dc97ae33a15e08a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1a96059868b45bc8fe1bba27320471e00948ff8e58929481009f38de40fddb5',1999,'GL','Greenland','people-and-society',496,'Population: 59,827 (July 1999 est.)
Age structure:
0-14 years: 26% (male 7,789; female 7,728)
15-64 years: 68% (male 22,248; female 18,678)
65 years and over: 6% (male 1 ,562; female 1 ,822)
(1999 est.)
Population growth rate: 0.84% (1999 est.)
Birth rate: 1 5.23 births/1 ,000 population (1999 est.)
Death rate: 6.79 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1.19 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .12 male(s)/female (1999 est.)
Infant mortality rate: 20.06 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.1 years
male: 65.98 years
female: 74.24 years (1999 est.)
Total fertility rate: 2.14 children born/woman (1999
est.)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 87% (Eskimos and
Greenland-born whites), Danish and others 13%
Religions: Evangelical Lutheran
Languages: Eskimo dialects, Danish, Greenlandic
(an Inuit dialect)
Literacy: NA
note: similar to Denmark proper
Greenland (continued)','58c2d4a93db6ebfdbcd6018db6e5b163ba609f85cfb12e702cb8a18ab9eede72','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('620df81991286ffc437725f476a960562225868616673c5a148854090208a2f9',1999,'GD','Grenada','people-and-society',502,'Population: 97,008 (July 1999 est.)
Age structure:
0-14 years: 43% (male 21 ,055; female 20,365)
15-64 years: 53% (male 27,524; female 23,766)
65 years and over: 4% (male 2,034; female 2,264)
(1999 est.)
Population growth rate: 0.87% (1999 est.)
Birth rate: 27.62 births/1 ,000 population (1999 est.)
Death rate: 5.15 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 3.74 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.16 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.09 male(s)/female (1999 est.)
Infant mortality rate: 11.13 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .6 years
male: 68.97 years
female: 74.29 years (1 999 est.)
Total fertility rate: 3.57 children born/woman (1999
est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant sects 33.2%
Languages: English (official), French patois
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 420,943 (July 1999 est.)
Age structure:
0-14 years: 25% (male 53,427; female 51 ,234)
15-64 years: 66% (male 138,215; female 141,243)
65 years and over: 9% (male 1 5,536; female 21 ,288)
(1999 est.)
Population growth rate: 1.06% (1999 est.)
Birth rate: 1 6.33 births/1 ,000 population (1 999 est.)
Death rate: 5.62 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.16 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 8.54 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.01 years
male: 74.98 years
female: 81 .1 8 years (1 999 est.)
Total fertility rate: 1 .82 children born/woman (1 999
est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant sects 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 90%
male: 90%
female: 90% (1982 est.)
Population: 120,519 (July 1999 est.)
Age structure:
0-14 years: 30% (male 18,160; female 17,524)
15-64 years: 65% (male 39,448; female 38,672)
65 years and over: 5% (male 2,762; female 3,953)
(1999 est.)
Population growth rate: 0.57% (1999 est.)
Birth rate: 18.34 births/1,000 population (1999 est.)
Death rate: 5.23 deaths/1 ,000 population (1999 est.)
Net migration rate: -7.43 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 ma!e(s)/female
total population: 1 ma!e(s)/female (1999 est.)
Infant mortality rate: 15.16 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.8 years
male: 72.29 years
female: 75.36 years (1999 est.)
Total fertility rate: 1 .94 children born/woman (1 999
est.)
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black, white, East Indian, Carib
Amerindian
Religions: Anglican, Methodist, Roman Catholic,
Seventh-Day Adventist
Languages: English, French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 96%
male: 96%
female: 96% (1970 est.)','e2b916ca11e721f6788d379780101c07d7bf92217273042eebe66cdea99cfecd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c4c9802af6f3e13effc0b4d9cc0f1988bcff6c10b302e71635cf073cdc7192',1999,'GU','Guam','people-and-society',511,'Population: 151,716 (July 1999 est.)
Age structure:
0-14 years: 35% (male 27,301 ; female 25,106)
15-64 years: 60% (male 47,691 ; female 42,714)
65 years and over: 5% (male 4,486; female 4,418)
(1999 est.)
Population growth rate: 1 .67% (1 999 est.)
Birth rate: 26.52 births/1 ,000 population (1999 est.)
Death rate: 4.35 deaths/1 ,000 population (1 999 est.)
Net migration rate: -5.45 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .1 1 male(s)/female
under 15 years: 1 .09 male(s)/female
15-64 years: 1.12 male(s)/fema!e
65 years and over: 1 .02 male(s)/female
total population: 1 .1 male(s)/female (1999 est.)
Infant mortality rate: 7.81 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.78 years
male: 74.6 years
female: 81 .31 years (1999 est.)
Total fertility rate: 3.92 children born/woman (1999
est.)
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 47%, Filipino 25%, white
10%, Chinese, Japanese, Korean, and other 18%
Religions: Roman Catholic 98%, other 2%
Languages: English, Chamorro, Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 12,335,580 (July 1999 est.)
Age structure:
0-14 years: 43% (male 2,688,402; female 2,578,934)
15-64 years: 54% (male 3,312,360; female
3,314,102)
65 years and over: 3% (male 207,014; female
234,768) (1999 est.)
Population growth rate: 2.68% (1999 est.)
Birth rate: 35.57 births/1 ,000 population (1 999 est.)
Death rate: 6.8 deaths/1 ,000 population (1999 est.)
Net migration rate: -1.93 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 46.15 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 66.45 years
male: 63.78 years
female: 69.24 years (1999 est.)
Total fertility rate: 4.74 children born/woman (1999
est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish
- in local Spanish called Ladino) 56%, Amerindian or
predominantly Amerindian 44%
Religions: Roman Catholic, Protestant, traditional
Mayan
Languages: Spanish 60%, Amerindian languages
40% (23 Amerindian languages, including Quiche,
Cakchiquel, Kekchi)
Literacy:
definition: age 15 and over can read and write
total population: 55.6%
male: 62.5%
female: 48.6% (1995 est.)','a426df614ac64925ed64150679ca9976b42c9e572404b48149ec7c5cfb9afae6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d04d4aff0e04134fd57870339f721233786fadd850609bd9fe101ff958a9b95',1999,'GG','Guernsey','people-and-society',518,'Population: 65,386 (July 1999 est.)
Age structure:
0-14 years: 18% (male 6,012; female 5,875)
15-64 years: 66% (male 21,287; female 22,165)
65 years and over: 1 6% (male 4,069; female 5,978)
(1999 est.)
Population growth rate: 1.27% (1999 est.)
Birth rate: 14.16 births/1 ,000 population (1999 est.)
Death rate: 9.44 deaths/1 ,000 population (1 999 est.)
Net migration rate: 8.01 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 8.42 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.72 years
male: 75.78 years
female: 81 .77 years (1999 est.)
Total fertility rate: 1 .74 children born/woman (1 999
est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy: NA
Population: 7,538,953 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,640,158; female 1,653,184)
15-64 years: 54% (male 1,974,849; female
2,068,221)
65 years and over: 2% (male 83,859; female
118,682) (1999 est.)
Population growth rate: 0.82% (1999 est.)
Birth rate: 40.62 births/1,000 population (1999 est.)
Death rate: 17.3 deaths/1 ,000 population (1 999 est.)
Net migration rate: -15.12 migrant(s)/1 ,000
population (1999 est.)
note: over the years Guinea has received up to
several hundred thousand refugees from the civil wars
in Liberia and Sierra Leone, some of whom are now
returning to their own countries
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 1 26.32 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 46.5 years
male: 44.02 years
female: 49.06 years (1999 est.)
Total fertility rate: 5.53 children born/woman (1999
est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller tribes 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each tribe has its own
language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
mate: 49.9%
female: 21. 9% (1995 est.)','5df698a37f71de3ba68f4f89fcdf651e202ed0c7ea46c2f967684fa3857a068e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff2ef8e702988f26d4d3cbfe0c744c302a32283ea18accc3e0fc376de461355c',1999,'GW','Guinea-Bissau','people-and-society',526,'Population: 1 ,234,555 (July 1 999 est.)
Age structure:
0-14 years: 42% (male 260,821 ; female 259,520)
15-64 years: 55% (male 322,607; female 356,51 3)
65 years and over: 3% (male 1 6,233; female 1 8,861 )
(1999 est.)
Population growth rate: 2.31% (1999 est.)
Birth rate: 38.23 births/1 ,000 population (1999 est.)
Death rate: 15.13 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 1 09.5 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 49.57 years
male: 47.91 years
female: 51 .28 years (1 999 est.)
Total fertility rate: 5.09 children born/woman (1999
est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 15 and over can read and write
total population: 53.9%
male: 67.1%
female: 40.7% (1997 est.)','a63cf705f0936652746e026e6eaebe89639d6470b3a214cf3f062c79c1ae947b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0880c8c2e3f3556c33148f6e718e4de12ef5ee9b24d5657585d1c6cfdfdada2',1999,'HT','Haiti','people-and-society',537,'Population: 6,884,264 (July 1999 est.)
Age structure:
0-14 years: 42% (male 1 ,464,529; female 1 ,420,772)
15-64 years: 54% (male 1 ,783,884; female
1,932,240)
65 years and over: 4% (male 1 40,932; female
141,907) (1999 est.)
Population growth rate: 1 .53% (1999 est.)
Birth rate: 32.55 births/1,000 population (1999 est.)
Death rate: 13.97 deaths/1,000 population (1999
est.)
Net migration rate: -3.26 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 97.64 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 51 .65 years
male: 49.53 years
female: 53.88 years (1999 est.)
Total fertility rate: 4.59 children born/woman (1999
est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto plus white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%, other
1%), none 1%, other 3% (1982)
note: roughly one-half of the population also practices
Voodoo
Languages: French (official) 20%, Creole
Literacy:
definition: age 15 and over can read and write
total population: 45%
male: 48%
female: 42.2% (1995 est.)','cf7f1362de19a9664a1ed52f98bf4fafc01ec1b5d77499f7be8bc4bcd33edd0c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c567ef6ef45af0a849eea70e608527d5e83e2250d31f3ee3daf6dd05422e8c45',1999,'NI','Nicaragua','people-and-society',548,'Population: 6,847,125 (July 1999 est.)
Age structure:
0-14 years: 18% (male 644,982; female 598,188)
15-64 years: 71% (male 2,397,277; female
2,490,745)
65 years and over: 11% (male 323,949; female
391,984) (1999 est.)
Population growth rate: 1.9% (1999 est.)
Birth rate: 12.9 births/1,000 population (1999 est.)
Death rate: 5.96 deaths/1 ,000 population (1999 est.)
Net migration rate: 12.07 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .08 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 ma!e(s)/female (1999 est.)
Infant mortality rate: 5,2 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.91 years
male: 76.15 years
female: 81 .85 years (1 999 est.)
Total fertility rate: 1.39 children born/woman (1999
est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English
Literacy:
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)
Population: 4,717,132 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,037,269; female 1,018,909)
15-64 years: 54% (male 1 ,236,326; female
1,297,356)
65 years and over: 2% (male 54,706; female 72,566)
(1999 est.)
Population growth rate: 2.84% (1999 est.)
Birth rate: 35.04 births/1 ,000 population (1 999 est.)
Death rate: 5.6 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .06 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 40.47 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 67.08 years
male: 64.7 years
female: 69.56 years (1999 est.)
Total fertility rate: 4.14 children born/woman (1999
est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 95%, Protestant 5%
Languages: Spanish (official)
note: English- and Amerindian-speaking minorities on
Atlantic coast
Literacy:
definition: age 15 and over can read and write
total population: 65.7%
male: 64.6%
female: 66.6% (1995 est.)','809ab3bf0bd2fbe2fe67c5e33e7bd1d73a9412d29a7e5d47d2b99e140f9e9570','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff9a9afaaf9902293bf7f60203f8c8d40d1bced90c02b99c901e3d5d8e9d735e',1999,'HU','Hungary','people-and-society',556,'Population: 10,186,372 (July 1999 est.)
Age structure:
0-14 years: 17% (male 908,434; female 865,621 )
15-64 years: 68% (male 3,406,512; female
3,524,260)
65 years and over: 1 5% (male 552,337; female
929,208) (1999 est.)
Population growth rate: -0.2% (1999 est.)
Birth rate: 10.8 births/1,000 population (1999 est.)
Death rate: 13.29 deaths/1,000 population (1999
est.)
Net migration rate: 0.5 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 9.46 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 . 1 8 years
male: 66.85 years
female: 75.74 years (1 999 est.)
Total fertility rate: 1.45 children born/woman (1999
est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Gypsy 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages: Hungarian 98.2%, other 1 .8%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1980 est.)','88f7c94cb1bb74922cb99d30de7b21f724d85f65b7a9c5154b86da18e7827f44','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5e3dd07364987a5b3340792dce7513a405766dd42a3cfbf9ac8b66c39aef82',1999,'IS','Iceland','people-and-society',566,'Population: 272,512 (July 1999 est.)
Age structure:
0-14 years: 23% (male 32,608; female 31,061)
15-64 years: 65% (male 89,258; female 87,449)
65 years and over: 1 2% (male 1 4,51 0; female
17,626) (1999 est.)
Population growth rate: 0.57% (1999 est.)
Birth rate: 14.87 births/1,000 population (1999 est.)
Death rate: 7.01 deaths/1 ,000 population (1 999 est.)
Net migration rate: -2.17 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 5.22 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.96 years
male: 76.85 years
female: 81.19 years (1 999 est.)
Total fertility rate: 2.03 children born/woman (1999
est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norwegians and Celts
Religions: Evangelical Lutheran 96%, other
Protestant and Roman Catholic 3%, none 1% (1988)
Languages: Icelandic
Literacy:
definition: age 1 5 and over can read and write
total population: 100% (1976 est.)
male: NA%
female: NA%
Population: 1,000,848,550 (July 1999 est.)
Age structure:
0-14 years: 34% (male 175,463,726; female
165,722,164)
15-64 years: 61% (male 318,004,920; female
295,245,556)
65 years and over: 5% (male 23,571 ,270; female
22,840,914) (1999 est.)
Population growth rate: 1 .68% (1 999 est.)
Birth rate: 25.39 births/1 ,000 population (1 999 est.)
Death rate: 8.5 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.08 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 .03 ma!e(s)/female
total population: 1 .07 male(s)/female (1999 est.)
Infant mortality rate: 60.81 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63.4 years
male: 62.54 years
female: 64.29 years (1 999 est.)
Total fertility rate: 3.1 8 children born/woman (1 999
est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3%
Religions: Hindu 80%, Muslim 1 4%, Christian 2.4%,
Sikh 2%, Buddhist 0.7%, Jains 0.5%, other 0.4%
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication, Hindi the national
language and primary tongue of 30% of the people,
Bengali (official), Telugu (official), Marathi (official),
Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya
(official), Punjabi (official), Assamese (official),
Kashmiri (official), Sindhi (official), Sanskrit (official),
Hindustani (a popular variant of Hindi/Urdu spoken
widely throughout northern India)
note: 24 languages each spoken by a million or more
persons; numerous other languages and dialects, for
the most part mutually unintelligible
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
female: 37.7% (1995 est.)
Population: no indigenous inhabitants
note: there are personnel who operate the Long
Range Navigation (Loran) C base and the weather
and coastal services radio station','b5f364abd4e8dabfc76d436f5e382181f708e06b005efae4e3ce303f655deed9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74433d29b0d388a736ad93e1afb52056d2ef3e0c491db1dd06168a08a28bd71f',1999,'TN','Tunisia','people-and-society',580,'Population: 56,735,130 (July 1999 est.)
Age structure:
0-14years:U% (male 4,161,841; female 3,925,413)
15-64 years: 68% (male 19,205,293; female
19,285,848)
65 years and over: 1 8% (male 4,1 69,098; female
5,987,637) (1999 est.)
Population growth rate: -0.08% (1999 est.)
Birth rate: 9.27 births/1,000 population (1999 est.)
Death rate: 1 0.28 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0.17 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 ma!e(s)/female
total population: 0.94 male(s)/female (1 999 est.)
Infant mortality rate: 6.3 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.51 years
male: 75.4 years
female: 81 .82 years (1 999 est.)
Total fertility rate: 1.22 children born/woman (1999
est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-ltalians in the north
and Albanian-ltalians and Greek-ltalians in the south)
Religions: Roman Catholic 98%, other 2%
Languages: Italian, German (parts of Trentino-Alto
Adige region are predominantly German speaking),
French (small French-speaking minority in Valle
d''Aosta region), Slovene (Slovene-speaking minority
in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 96% (1990 est.)','7ddfcc725d54d92b60493f05e6d317d7fcd4a251f878231026800fc17cb13adb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a577433be7063d586cbca4d76e2a57a9a34e01118dd6e09abf42e1dde208a8d',1999,'JM','Jamaica','people-and-society',587,'Population: 2,652,443 (July 1999 est.)
Age structure:
0-14 years: 31% (male 421,127; female 402,593)
15-64 years: 62% (male 819,956; female 828,176)
65 years and over: 7% (male 79,747; female
100,844) (1999 est.)
Population growth rate: 0.64% (1999 est.)
Birth rate: 20.22 births/1,000 population (1999 est.)
Death rate: 5.39 deaths/1 ,000 population (1 999 est.)
Net migration rate: -8.39 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 13.93 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.62 years
male: 73.22 years
female: 78.13 years (1999 est.)
Total fertility rate: 2.26 children born/woman (1999
est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.4%, East Indian 1 .3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.6%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Baptist 8.8%, Anglican 5.5%, Seventh-Day Adventist
9%, Pentecostal 7.6%, Methodist 2,7%, United
Church 2.7%, Brethren 1.1%, Jehovah''s Witness
1.6%, Moravian 1.1%), Roman Catholic 4%, other,
including some spiritual cults 34.7%
Languages: English, Creole
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
male: 80.8%
female: 89.1% (1995 est.)','22c58920c04554eb36888c176c98f1f62b4f65a23ef59f9770195c96a28fa764','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ef09d993211c5fd499ebf36f8bc69e6e69459d56577e5245d2bac430d0a7bb',1999,'NO','Norway','people-and-society',593,'Population: 126,182,077 (July 1999 est.)
Age structure:
0-14 years: 1 5% (male 9,697,851 ; female 9,242,027)
15-64 years: 68% (male 43,405,024; female
43,023,885)
65 years and over: 17% (male 8,686,347; female
12,126,943) (1999 est.)
Population growth rate: 0.2% (1999 est.)
Birth rate: 10.48 births/1,000 population (1999 est.)
Death rate: 8.12 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 4.07 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 80.11 years
male: 77,02 years
female: 83.35 years (1999 est.)
Total fertility rate: 1 .48 children born/woman (1 999
est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99.4%, other 0.6%
(mostly Korean)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1 970 est.)
male: NA%
female: NA%
Population: 4,438,547 (July 1999 est.)
Age structure:
0-14 years: 20% (male 447,607; female 423,844)
15-64 years: 65% (male 1 ,462,906; female
1,415,992)
65 years and over: 15% (male 286,339; female
401 ,859) (1999 est.)
Population growth rate: 0.4% (1999 est.)
Birth rate: 12.54 births/1 ,000 population (1999 est.)
Death rate: 10.12 deaths/1 ,000 population (1 999
est.)
Net migration rate: 1 .62 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 ,03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 4.96 deaths/1 ,000 live births
(1999 est.)
366
Norway (continued)
Life expectancy at birth:
total population: 78.36 years
male: 75.55 years
female: 81 .35 years (1 999 est.)
Total fertility rate: 1 .77 children born/woman (1 999
est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Germanic (Nordic, Alpine, Baltic),
Lapps (Sami) 20,000
Religions: Evangelical Lutheran 87.8% (state
church), other Protestant and Roman Catholic 3.8%,
none 3.2%, unknown 5.2% (1980)
Languages: Norwegian (official)
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1 976 est.)
male: NA%
female: NA%
Population: 2,446,645 (July 1999 est.)
Age structure:
0-14 years: 41 % (male 508,681 ; female 489,453)
15-64 years: 57% (male 856,062; female 535,123)
65 years and over: 2% (male 30,083; female 27,243)
(1999 est.)
Population growth rate: 3.45% (1999 est.)
Birth rate: 37.98 births/1 ,000 population (1999 est.)
Death rate: 4.29 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.84 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .6 male(s)/female
65 years and over: 1 .1 male(s)/female
total population: 1 .33 male(s)/female (1999 est.)
Infant mortality rate: 24.71 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .3 years
male: 69.31 years
female: 73.39 years (1999 est.)
Total fertility rate: 6.1 1 children born/woman (1999
est.)
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%
Population: 138,123,359 (July 1999 est.)
Age structure:
0-14 years: 41% (male 29,423,876; female
27,763,774)
15-64 years: 55% (male 38,533,918; female
36,804,592)
65 years and over: 4% (male 2,768,942; female
2,828,257) (1999 est.)
Population growth rate: 2.18% (1999 est.)
Birth rate: 33.51 births/1 ,000 population (1999 est.)
Death rate: 10.45 deaths/1 ,000 population (1999
est.)
Net migration rate: -1.3 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .05 male(s)/female (1999 est.)
Infant mortality rate: 91 .86 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 59.38 years
male: 58.49 years
female: 60.3 years (1999 est.)
Total fertility rate: 4.73 children born/woman (1999
est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India and their
descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 37.8%
male: 50%
female: 24.4% (1995 est.)
Population: 18,467 (July 1999 est.)
Age structure:
0-14 years: 27% (male 2,595; female 2,446)
15-64 years: 68% (male 6,867; female 5,675)
65 years and over: 5% (male 41 6; female 468) (1 999
est.)
Population growth rate: 1 .94% (1999 est.)
Birth rate: 21 .55 births/1 ,000 population (1999 est.)
Death rate: 7.74 deaths/1 ,000 population (1999 est.)
Net migration rate: 5.63 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.21 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 .15 male(s)/female (1999 est.)
Infant mortality rate: 1 8.5 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 67.75 years
male: 64.69 years
female: 70.98 years (1999 est.)
Total fertility rate: 2.66 children born/woman (1999
est.)
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauans are a composite of
Polynesian, Malayan, and Melanesian races
Religions: Christian (Catholics, Seventh-Day
Adventists, Jehovah''s Witnesses, the Assembly of
God, the Liebenzell Mission, and Latter-Day Saints),
Modekngei religion (one-third of the population
observes this religion which is indigenous to Palau)
Languages: English (official in all of Palau''s 16
states), Sonsorolese (official in the state of Sonsoral),
Angaur and Japanese (in the state of Anguar), Tobi (in
the state of Tobi), Palauan (in the other 13 states)
Literacy:
definition: age 15 and over can read and write
total population: 92%
male: 93%
female: 90% (1980 est.)','7fce396ea66181d1c52ea78283c23fbc0cb5cc6a743926d695ef05c0452f7744','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ad078439f721f82dd4f81cb71ffaaa47a438dc0c3ccccfcbe3dd880984a9bbd',1999,'KZ','Kazakhstan','people-and-society',607,'Population: 16,824,825 (July 1999 est.)
Age structure:
0-14 years: 28% (male 2,432,519; female 2,359,375)
15-64 years: 65% (male 5,279,877; female
5,580,271)
65 years and over: 7% (male 392,934; female
779,849) (1999 est.)
Population growth rate: -0.09% (1999 est.)
Birth rate: 17.16 births/1 ,000 population (1999 est.)
Death rate: 10.34 deaths/1,000 population (1999
est.)
Net migration rate: -7.73 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 58.82 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63.39 years
male: 57.92 years
female: 69.13 years (1999 est.)
Total fertility rate: 2.09 children born/woman (1999
est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 46%, Russian
34.7%, Ukrainian 4.9%, German 3.1%; Uzbek 2.3%,
Tatar 1.9%, other 7.1% (1996)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq) (state language) 40%,
Russian (official, used in everyday business) 66%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 96% (1989 est.)
Population: 28,808,658 (July 1999 est.)
Age structure:
0-14 years: 43% (male 6,244,321 ; female 6,104,181)
15-64 years: 54% (male 7,845,083; female
7,826,442)
65 years and over: 3% (male 343,449; female
445,182) (1999 est.)
Population growth rate: 1 .59% (1 999 est.)
Birth rate: 30.8 births/1,000 population (1999 est.)
Death rate: 14.58 deaths/1,000 population (1999
est.)
Net migration rate: -0.34 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 59.07 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 47.02 years
male: 46.56 years
female: 47.49 years (1 999 est.)
Total fertility rate: 3.88 children born/woman (1999
est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant 38%, Roman Catholic 28%,
indigenous beliefs 26%, Muslim 7%, other 1%
Languages: English (official), Swahili (official),
numerous indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 78.1%
male: 86.3%
female: 70% (1995 est.)','34cec00e09e22fbc1d18809aafa2dd14f6e6e3d692939e953b9a9f2b9a769587','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02dc3170668650f5a4404bc9b17455d63d0566a2eafa6118e89bc2efdaf805c',1999,'WS','Samoa','people-and-society',614,'Population: uninhabited
Population: 85,501 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.78% (1999 est.)
Birth rate: 26.13 births/1,000 population (1999 est.)
Death rate: 7.53 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.77 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 48.22 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 62.88 years
male: 61 .02 years
female: 64.98 years (1999 est.)
Total fertility rate: 3.09 children born/woman (1999
est.)
Nationality:
noun: l-Kiribati (singular and plural)
adjective: l-Kiribati
Ethnic groups: Micronesian
Religions: Roman Catholic 53%, Protestant
(Congregational) 41%, Seventh-Day Adventist,
Baha''i, Church of God, Mormon 6% (1985 est.)
Languages: English (official), Gilbertese
Literacy: NA
Population: 21,386,109 (July 1999 est.)
Age structure:
0-14 years: 26% (male 2,800,748; female 2,666,207)
15-64 years: 68% (male 7,143,969; female
7,447,147)
65 years and over: 6% (male 412,161; female
915,877) (1999 est.)
Population growth rate: 1.45% (1999 est.)
Birth rate: 21 .37 births/1 ,000 population (1 999 est.)
Death rate: 6.92 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 ,05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.45 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 25.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.07 years
male: 67.41 years
female: 72.86 years (1999 est.)
Total fertility rate: 2.3 children born/woman (1999
est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
Religions: Buddhism and Confucianism, some
Christianity and syncretic Chondogyo
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Literacy:
definition: age 1 5 and over can read and write Korean
total population: 99%
male: 99%
female: 99% (1 990 est.)
Population: 46,884,800 (July 1999 est.)
Age structure:
0-14 years: 22% (male 5,504,333; female 4,874,974)
15-64 years: 71% (male 16,949,807; female
16,432,951)
65 years and over: 7% (male 1,192,688; female
1,930,047) (1999 est.)
Population growth rate: 1% (1999 est.)
Birth rate: 15.95 births/1,000 population (1999 est.)
Death rate: 5.68 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.3 migrant(s)/1, 000 population
(1999 est.)
Sex ratio:
at birth: 1.13 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 7.57 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.3 years
male: 70.75 years
female: 78.32 years (1999 est.)
Total fertility rate: 1.79 children born/woman (1999
est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: Christianity 49%, Buddhism 47%,
Confucianism 3%, pervasive folk religion
(shamanism), Chondogyo (Religion of the Heavenly
Way), and other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99.3%
female: 96.7% (1995 est.)
Population: uninhabited
Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total: 2,860 sq km
land: 2,850 sq km
water: 10 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (October to March),
dry season (May to October)
Terrain: narrow coastal plain with volcanic, rocky,
rugged mountains in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Manga Silisili 1,857 m
Natural resources: hardwood forests, fish
Land use:
arable land: 19%
permanent crops: 24%
permanent pastures: 0%
forests and woodland: 47%
other: 10%
Irrigated land: NA sq km
Natural hazards: occasional typhoons; active
volcanism
Environment - current issues: soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
Population: 229,979 (July 1999 est.)
note: other estimates range as low as 162,000
Age structure:
0-14 years: 39% (male 45,647; female 44,141)
15-64 years: 57% (male 68,054; female 62,61 2)
65 years and over: 4% (male 4,477; female 5,048)
(1999 est.)
Population growth rate: 2.3% (1999 est.)
Birth rate: 28.81 births/1,000 population (1999 est.)
Death rate: 5.4 deaths/1,000 population (1999 est.)
Net migration rate: -0.39 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .03 ma!e(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 .06 male(s)/female (1999 est.)
Infant mortality rate: 30.5 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.82 years
male: 67.43 years
female: 72.33 years (1999 est.)
Total fertility rate: 3.61 children born/woman (1999
est.)
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-half of
population associated with the London Missionary
Society; includes Congregational, Roman Catholic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97%
female: 97% (1971 est.)','3211451957d6d8211a9384585a705eaf324b4bc2cc93a8e262f7cf753465a67b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fabdcb8be00f1430fa229f7017a24d85aa92da7030ac9053805febef5b8978f7',1999,'KG','Kyrgyzstan','people-and-society',625,'Population: 4,546,055 (July 1999 est.)
Age structure:
0-14 years: 35% (male 804,502; female 788,076)
15-64 years: 59% (male 1,308,145; female
1,362,140)
65 years and over: 6% (male 1 05,442; female
177,750) (1999 est.)
Population growth rate: 0.68% (1999 est.)
Birth rate: 21 .83 births/1 ,000 population (1 999 est.)
Death rate: 8.74 deaths/1 ,000 population (1999 est.)
Net migration rate: -6.28 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
270
Kyrgyzstan (continued)
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 75.92 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63.57 years
male: 59.25 years
female: 68.1 years (1999 est.)
Total fertility rate: 2.63 children born/woman (1 999
est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kirghiz 52.4%, Russian 18%, Uzbek
12.9%, Ukrainian 2.5%, German 2.4%, other 1 1 .8%
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kirghiz (Kyrgyz) - official language,
Russian - official language
note: in March 1996, the Kyrgyzstani legislature
amended the constitution to make Russian an official
language, along with Kirghiz, in territories and work
places where Russian-speaking citizens predominate
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 5,407,453 (July 1999 est.)
Age structure:
0-14years: 45% (male 1,235,797; female 1 ,203,520)
15-64 years: 52% (male 1 ,360,991 ; female
1,434,378)
65 years and over: 3% (male 78,1 95; female 94,572)
(1999 est.)
Population growth rate: 2.74% (1999 est.)
Birth rate: 39.93 births/1 ,000 population (1999 est.)
Death rate: 12.56 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.98 male(s)/female (1 999 est.)
Infant mortality rate: 89.32 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54.21 years
male: 52.63 years
female: 55.87 years (1999 est.)
Total fertility rate: 5.55 children born/woman (1999
est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 70%
female: 48% (1998 est.)','587905a3d8732ea6e3d3d982920c34ab80f213442f8c467a0e9266a499a13e1e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ff24856b83621add2e94ca3010aafa8018e7a2c008adb828be9e92d46d417fd',1999,'LV','Latvia','people-and-society',633,'Population: 2,353,874 (July 1999 est.)
Age structure:
0-14 years: 18% (male 216,369; female 207,242)
15-64 years: 67% (male 749,396; female 825,988)
65 years and over: 1 5% (male 1 1 4,038; female
240,841) (1999 est.)
Population growth rate: -1.25% (1999 est.)
Birth rate: 8.1 births/1,000 population (1999 est.)
Death rate: 1 5.82 deaths/1 ,000 population (1 999
est.)
Net migration rate: -4.75 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.47 male(s)/female
total population: 0.85 ma!e(s)/female (1999 est.)
Infant mortality rate: 17.19 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 67.3 years
male: 61 .24 years
female: 73.66 years (1999 est.)
Total fertility rate: 1.18 children born/woman (1999
est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%,
Byelorussian 4.3%, Ukrainian 2.8%, Polish 2.6%,
other 3.4%
Religions: Lutheran, Roman Catholic, Russian
Orthodox
Languages: Lettish (official), Lithuanian, Russian,
other
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 99% (1989 est.)','a0f0fda09118330cedf6e3e242ee5903214ab6d9d72fe4781e03d4406965c2df','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eccffd6942c108e87dec379c5fcd5c7da2c2e6fe5450096b4872be728bf396a3',1999,'LB','Lebanon','people-and-society',642,'Population: 3,562,699 (July 1999 est.)
Age structure:
0-14 years: 30% (male 535,596; female 515,776)
15-64 years: 64% (male 1 ,084, 1 21 ; female
1,196,678)
65 years and over: 6% (male 1 05,1 33; female
125,395) (1999 est.)
Population growth rate: 1 .61 % (1 999 est.)
Birth rate: 22.5 births/1,000 population (1999 est.)
Death rate: 6.45 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 ma!e(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.94 ma!e(s)/female (1999 est.)
Infant mortality rate: 30.53 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70,93 years
male: 68.34 years
female: 73.66 years (1999 est.)
Total fertility rate: 2.25 children born/woman (1999
est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic
groups - Alawite or Nusayri, Druze, Isma''ilite, Shi''a,
Sunni), Christian 30% (1 1 legally recognized Christian
groups - 4 Orthodox Christian, 6 Catholic, 1
Protestant), Judaism NEGL%
Languages: Arabic (official), French, English,
Armenian widely understood
Literacy:
definition: age 1 5 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)','0cdf978fd4f97da127d21eb9717cd66d6d8822b1c348be2c0c037cd75a553a8c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('984fed31fb6cb16e3138cbcfb4c83ec9a8bb3d5b83c459a2813e14602324ce45',1999,'ZA','South Africa','people-and-society',650,'Population: 2,128,950 (July 1999 est.)
Age structure:
0-14 years: 40% (male 424,355; female 422,892)
15-64 years: 56% (male 573,285; female 610,636)
65 years and over: 4% (male 40,604; female 57,178)
(1999 est.)
Population growth rate: 1 .8% (1 999 est.)
Birth rate: 31 .26 births/1 ,000 population (1999 est.)
Death rate: 1 3.23 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 77.58 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 52.99 years
male: 51 .37 years
female: 54.65 years (1 999 est.)
Total fertility rate: 4.03 children born/woman (1999
est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans 1 ,600,
Asians 800
Religions: Christian 80%, rest indigenous beliefs
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 7 1.3%
male: 81.1%
female: 62.3% (1995 est.)
Population: 2,923,725 (July 1999 est.)
Age structure:
0-14 years: 45% (male 656,101; female 649,389)
15-64 years: 52% (male 775,429; female 738,904)
65 years and over: 3% (male 50,1 26; female 53,776)
(1999 est.)
Population growth rate: 4.92% (1999 est.)
Birth rate: 41.49 births/1,000 population (1999 est.)
Death rate: 1 1 .03 deaths/1 ,000 population (1999
est.)
Net migration rate: 18.77 migrant(s)/1 ,000
population (1999 est.)
note: evidence from UNHCR indicates Liberians are
being repatriated
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 1 .03 male(s)/female (1999 est.)
Infant mortality rate: 1 00.63 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 59.88 years
male: 57,2 years
female: 62.64 years (1999 est.)
Total fertility rate: 6.02 children born/woman (1999
est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
282
Liberia (continued)
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, and Bella),
Americo-Liberians 2.5% (descendants of immigrants
from the US who had been slaves)
Religions: traditional 70%, Muslim 20%, Christian
10%
Languages: English 20% (official), about 20 tribal
languages, of which a few can be written and are used
in correspondence
Literacy:
definition: age 1 5 and over can read and write
total population: 38.3%
mate: 53.9%
female: 22.4% (1995 est.)
note: these figures are increasing because of the
improving school system','e5d37644596aa6c22ad2fad919038572ab637d18d89710fe28e04ee2619dd794','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ddb62efe4fcb8862cd573702ae2912c3fe0acbeff5ba106c130341c109b6591',1999,'LY','Libya','people-and-society',660,'Population: 4,992,838 (July 1999 est.)
note: includes 161 ,251 non-nationals (July 1999 est.)
Age structure:
0-14 years: 36% (male 930,661 ; female 891 ,046)
15-64 years: 60% (male 1 ,545,958; female
1,437,120)
65 years and over: 4% (male 93,726; female 94,327)
(1999 est.)
Population growth rate: 2.4% (1999 est.)
Birth rate: 27.33 births/1,000 population (1999 est.)
Death rate: 3.35 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .06 male(s)/female (1 999 est.)
Infant mortality rate: 28.15 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.73 years
male: 73.81 years
female: 77.74 years (1999 est.)
Total fertility rate: 3.79 children born/woman (1999
est.)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 76.2%
male: 87.9%
female: 63% (1995 est.)','3237266bb5fd7a879924abc235996b305d88088a70119ad9d9bd512197005f75','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1df880be619de437ee0bf9a81629f7355a78bafdf53fb736b87eac7b74a1f938',1999,'CH','Switzerland','people-and-society',668,'Population: 32,057 (July 1999 est.)
Age structure:
0-14 years: 19% (male 3,076; female 2,949)
15-64 years: 70% (male 1 1 ,209; female 1 1 ,247)
65 years and over: 1 1 % (male 1 ,484; female 2,092)
(1999 est.)
Population growth rate: 1.08% (1999 est.)
Birth rate: 12.23 births/1,000 population (1999 est.)
Death rate: 7.33 deaths/1 ,000 population (1 999 est.)
Net migration rate: 5.9 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 5.23 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.11 years
male: 75.64 years
female: 80.69 years (1999 est.)
Total fertility rate: 1 .6 children born/woman (1 999
est.)
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7.7%, other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 10 and over can read and write
total population: 1 00%
male: 100%
female: 100% (1981 est.)
Population: 3,584,966 (July 1999 est.)
Age structure:
0-14 years: 20% (male 365,149; female 350,070)
15-64 years: 67% (male 1,156,161; female
1,239,145)
65 years and over: 1 3% (male 1 60,963; female
313,478) (1999 est.)
Population growth rate: -0.4% (1999 est.)
Birth rate: 10.52 births/1,000 population (1999 est.)
Death rate: 1 2.93 deaths/1 ,000 population (1 999
est.)
Net migration rate: -1 .58 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 14.71 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.96 years
male: 62.91 years
female: 75.31 years (1999 est.)
Total fertility rate: 1.45 children born/woman (1999
est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Byelorussian 1.6%, other 2.1%
Religions: primarily Roman Catholic, others include
Lutheran, Russian Orthodox, Protestant, evangelical
Christian Baptist, Islam, Judaism
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 98% (1989 est.)','a55e91d0baa6ab29cb7a07c610c7985a1fb05540ca8658f541223fdaca9b77a2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea0bc93851e49ea9b6b79ada100be2953fb7f639189f138d55d0f737fbb41566',1999,'MW','Malawi','people-and-society',681,'Population: 10,000,416 (July 1999 est.)
Age structure:
0-14 years: 45% (male 2,265,526; female 2,246,135)
15-64 years: 52% (male 2,580,125; female
2,637,464)
65 years and over: 3% (male 112,813; female
158,353) (1999 est.)
Population growth rate: 1 .57% (1 999 est.)
Birth rate: 39.54 births/1 ,000 population (1 999 est.)
Death rate: 23.84 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 132.14 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 36.3 years
male: 36.49 years
female: 36.1 1 years (1999 est.)
Total fertility rate: 5.48 children born/woman (1999
est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuko, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian,
European
Religions: Protestant 55%, Roman Catholic 20%,
Muslim 20%, traditional indigenous beliefs
Languages: English (official), Chichewa (official),
other languages important regionally
299
Malawi (continued)
Literacy:
definition: age 15 and over can read and write
total population: 56.4%
male: 71 .9%
female: 41 .8% (1995 est.)','b806b5d09420e943505950f4b50df38d1172046f0d43775aba04c450d8e25903','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5acf9ff9e4957d27eb93b39d580327a42da3bf81d53b37219ae26290a1f1977',1999,'MV','Maldives','people-and-society',692,'Population: 300,220 (July 1999 est.)
Age structure:
0-14 years: 47% (male 72,414; female 68,764)
15-64 years: 50% (male 76,446; female 73,275)
65 years and over: 3% (male 4,944; female 4,377)
(1999 est.)
Population growth rate: 3.37% (1999 est.)
Birth rate: 39.3 births/1,000 population (1999 est.)
Death rate: 5.63 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1 .05 male(s)/female (1999 est.)
Infant mortality rate: 38.14 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.29 years
male: 66.53 years
female: 70.15 years (1999 est.)
Total fertility rate: 5.73 children born/woman (1999
est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: Sinhalese, Dravidian, Arab, African
Religions: Sunni Muslim
Languages: Maldivian Divehi (dialect of Sinhala,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 15 and over can read and write
total population: 93.2%
male: 93,3%
female: 93% (1995 est.)','b05b77a68d03a16f18596608184c8db8a18a5103b00fa476456c487848204f0c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee7e0c7e3c30a4be09becb5bc5af1e59af10530396724bd34d25014c929fcd0',1999,'ML','Mali','people-and-society',699,'Population: 10,429,124 (July 1999 est.)
Age structure:
0-14 years: 47% (male 2,482,301 ; female 2,460,894)
15-64 years: 49% (male 2,447,712; female
2,708,978)
65 years and over: 4% (male 1 55,1 78; female
174,061)(1999 est.)
Population growth rate: 3.01% (1999 est.)
Birth rate: 49.5 births/1,000 population (1999 est.)
Death rate: 18.56 deaths/1,000 population (1999
est.)
Net migration rate: -0.87 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 ma!e(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 1 1 9.44 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 47.5 years
male: 46.09 years
female: 48.96 years (1999 est.)
Total fertility rate: 6.96 children born/woman (1 999
est.)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke,
Sarakole), Peul 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 1 5 and over can read and write
total population: 31%
male: 39.4%
female: 23.1% (1995 est.)','1a03f517bfd21f44574fb4e49545489540d3905e7617a61f7974df54a3b86645','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('171f77fb2767d6839bb8e37cb0f0dfcbeba9f2a6b277df589832d8a710164749',1999,'MT','Malta','people-and-society',706,'Population: 381,603 (July 1999 est.)
Age structure:
0-14 years: 20% (male 40,058; female 37,810)
15-64 years: 68% (male 130,282; female 128,390)
65 years and over: 12% (male 1 8,996; female
26,067) (1999 est.)
Population growth rate: 0.49% (1999 est.)
Birth rate: 1 1 .02 births/1 ,000 population (1 999 est.)
Death rate: 7.37 deaths/1 ,000 population (1999 est.)
Net migration rate: 1 .24 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 7.42 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.76 years
male: 75.43 years
female: 80.23 years (1999 est.)
Total fertility rate: 1 .63 children born/woman (1999
est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 98%
Languages: Maltese (official), English (official)
Literacy:
definition: age 10 and over can read and write
total population: 88%
male: 88%
female: 88% (1985)
Population: 75,686 (July 1999 est.)
Age structure:
0-14 years: 18% (male 6,906; female 6,597)
15-64 years: 65% (male 24,655; female 24,604)
65 years and over: 17% (male 5,156; female 7,768)
(1999 est.)
Population growth rate: 0.71% (1999 est.)
Birth rate: 1 2.43 births/1 ,000 population (1 999 est.)
Death rate: 1 1 .52 deaths/1 ,000 population (1999
est.)
Net migration rate: 6.17 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 2.45 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.79 years
male: 74.28 years
female: 81 .47 years (1999 est.)
Total fertility rate: 1 .67 children born/woman (1999
est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy: NA','640e855c269548017d3fdb9969f3f0869c7fd7fb1252560244854e3307b3c6fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18d6080d5eb2d45142237a711274703b7665fc97b2148c0c3028a064de707451',1999,'MH','Marshall Islands','people-and-society',715,'Population: 65,507 (July 1999 est.)
Age structure:
0-14 years: 50% (male 16,622; female 15,957)
15-64 years: 48% (male 16,106; female 15,386)
65 years and over: 2% (male 677; female 759) (1 999
est.)
Population growth rate: 3.86% (1999 est.)
Birth rate: 45.31 births/1,000 population (1999 est.)
Death rate: 6.73 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 .04 male(s)/female (1999 est.)
Infant mortality rate: 43.38 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.81 years
male: 63.21 years
female: 66.5 years (1999 est.)
Total fertility rate: 6.67 children born/woman (1999
est.)
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and is the
official language), two major Marshallese dialects
from the Malayo-Polynesian family, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 100%
female: 88% (1980 est.)','8fc65aef4e9a569fa9538581a40e40ccb42291933ffc07c6d788a5e4c00b44ee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce1e1ef874444691a2dcddddd5059de8ada8db02d7e359dc71783287c5064fa',1999,'MQ','Martinique','people-and-society',723,'Population: 41 1 ,539 (July 1 999 est.)
Age structure:
0-14 years: 23% (male 47,933; female 46,957)
15-64 years: 67% (male 136,058; female 138,935)
65 years and over: 1 0% (male 1 7,530; female
24,126) (1999 est.)
Population growth rate: 1 .03% (1 999 est.)
Birth rate: 16.3 births/1,000 population (1999 est.)
Death rate: 5.94 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.09 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 6.76 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 79.27 years
male: 76.47 years
female: 82.1 3 years (1 999 est.)
Total fertility rate: 1 .8 children born/woman (1 999
est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-lndian
mixture 90%, white 5%, East Indian, Lebanese,
Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 5%
Languages: French, Creole patois
Literacy:
definition: age 1 5 and over can read and write
total population: 93%
male: 92%
female: 93% (1982 est.)
Population: 6,966 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.75% (1999 est.)
Birth rate: 1 2.27 births/1 ,000 population (1 999 est.)
Death rate: 5.41 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.59 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 8.12 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.1 3 years
male: 75.58 years
female: 79 years (1999 est.)
Total fertility rate: 1 .58 children born/woman (1 999
est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)','624952808467e5207e260b56b09921a088659e7f47b09866bd935e213154e313','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebab2ab0d35f9b97c1dbf5b85d4f004e94e26119f3e44e73bd67c7c37e6b1238',1999,'MR','Mauritania','people-and-society',726,'Population: 2,581 ,738 (July 1 999 est.)
Age structure:
0-14 years: 47% (male 600,901 ; female 600,225)
15-64 years: 51% (male 641,481; female 678,951)
65 years and over: 2% (male 25,1 56; female 35,024)
(1999 est.)
Population growth rate: 2.99% (1999 est.)
Birthrate: 44.1 births/1,000 population (1999 est.)
Death rate: 1 4.2 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.72 male(s)/femate
total population: 0.96 male(s)/female (1 999 est.)
Infant mortality rate: 76.46 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 50.48 years
male: 47.39 years
female: 53.65 years (1999 est.)
Total fertility rate: 6.35 children born/woman (1999
est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%,
black 30%
Religions: Muslim 100%
Languages: Hasaniya Arabic (official), Pular,
Soninke, Wolof (official), French
Literacy:
definition: age 15 and over can read and write
total population: 37.7%
male: 49.6%
female: 26.3% (1995 est.)
Population: 1 0,051 ,930 (July 1 999 est.)
Age structure:
0-14 years: 48% (male 2,403,384; female 2,416,791)
15-64 years: 49% (male 2,360,1 1 3; female
2,594,278)
65 years and over: 3% (male 1 34,765; female
142,599) (1999 est.)
Population growth rate: 3.32% (1999 est.)
Birth rate: 43.88 births/1 ,000 population (1999 est.)
Death rate: 10.71 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 0.95 male(s)/female (1 999 est.)
Infant mortality rate: 59.81 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 57.83 years
male: 54.95 years
female: 60.78 years (1999 est.)
Total fertility rate: 6.11 children born/woman (1999
est.)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer
14.7%, Diola 3.7%, Mandink 3%, Soninke 1.1%,
European and Lebanese 1%, other 9.4%
Religions: Muslim 92%, indigenous beliefs 6%,
Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Diola,
Mandingo
Literacy:
definition: age 15 and over can read and write
total population: 33.1%
male: 43%
female: 23.2% (1995 est.)
425
Senegal (continued)','24da82dd144be529f9f42806c0a96c2280029e50e3e398240af6d2f5399d9515','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff435ab5eccfcb07dad9da53d1624179509cd62336929bcdcd05f449b707ef5e',1999,'MU','Mauritius','people-and-society',733,'Population: 1,182,212 (July 1999 est.)
Age structure:
0-14 years: 26% (male 156,616; female 153,698)
15-64 years: 68% (male 398,557; female 402,674)
65 years and over: 6% (male 28,586; female 42,081 )
(1999 est.)
Population growth rate: 1.18% (1999 est.)
Birth rate: 1 8.49 births/1 ,000 population (1 999 est.)
Death rate: 6.69 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (1 999 est.)
Infant mortality rate: 16.2 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71 .09 years
male: 67.21 years
female: 74.96 years (1999 est.)
Total fertility rate: 2.21 children born/woman (1999
est.)
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman
Catholic 26%, Protestant 2.3%), Muslim 16.6%, other
3.1%
Languages: English (official), Creole, French, Hindi,
Urdu, Hakka, Bojpoori
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 87.1%
female: 78.8% (1995 est.)','0f7922cb51d0367faf40bff7289567391481d7501d716a66090a73cbcde79931','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3378fd90b3860e15c0f7fdd5bb4a4cf3b1e090f9b32a09f0cbedba2ec4b52bad',1999,'MX','Mexico','people-and-society',747,'Population: 1 00,294,036 (July 1 999 est.)
Age structure:
0-14 years: 35% (male 17,987,500; female
17,289,875)
15-64 years: 61% (male 29,610,813; female
31,216,342)
65 years and over: 4% (male 1 ,873,986; female
2,315,520) (1999 est.)
Population growth rate: 1.73% (1999 est.)
Birth rate: 24.99 births/1,000 population (1999 est.)
Death rate: 4.83 deaths/1 ,000 population (1 999 est.)
Net migration rate: -2.84 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 ma!e(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 24.62 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72 years
male: 68.98 years
female: 75.17 years (1999 est.)
Total fertility rate: 2.85 children born/woman (1999
est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
male: 91 .8%
female: 87.4% (1995 est.)
Population: 38,608,929 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,921 ,093; female 3,734,223)
15-64 years: 68% (male 13,076,231 ; female
13,243,716)
65 years and over: 12% (male 1 ,762,135; female
2,871,531) (1999 est.)
Population growth rate: 0.05% (1999 est.)
Birthrate: 10.61 births/1 ,000 population (1999 est.)
Death rate: 9.72 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 12.76 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.06 years
male: 68.93 years
female: 77 At years (1999 est.)
Total fertility rate: 1 .45 children born/woman (1 999
est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1 .3%,
Ukrainian 0.6%, Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75%
practicing), Eastern Orthodox, Protestant, and other
5%
Languages: Polish
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1978 est.)
390
Poland (continued)','33a87c34789f303e70215946ffd149958586e52e28057dafe7211d74579c2234','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cff4e3aa4df1c70dc2ad0e3e1192f106fc6a2c02a7d1bd78448a60b76d47e40a',1999,'US','United States','people-and-society',755,'Population: 32,149 (July 1999 est.)
Age structure:
0-14 years: 17% (male 2,723; female 2,645)
15-64 years: 64% (male 10,014; female 10,530)
65 years and over: 1 9% (male 2,302; female 3,935)
(1999 est.)
Population growth rate: 0.31% (1999 est.)
Birth rate: 1 0.7 births/1 ,000 population (1 999 est.)
Death rate: 1 1 .79 deaths/1 ,000 population (1 999
est.)
Net migration rate: 4.17 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 6.47 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.58 years
male: 75 years
female: 82.35 years (1999 est.)
Total fertility rate: 1 .7 children born/woman (1 999
est.)
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 95%
Languages: French (official), English, Italian,
Monegasque
Literacy: NA','dac37ee1754c07e4b1f024b6832bcf4c1664790f19bbb87cec9bf8056f03c6c1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e945378d05a99801547899293338c9d3451afe2f6116e9006459852ddeac88b',1999,'MS','Montserrat','people-and-society',766,'Population: 12,853 (July 1999 est.)
note: demographic figures include an estimated 8,000
refugees who left the island following the resumption
of volcanic activity in July 1995
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.21% (1999 est.)
Birth rate: 1 3.87 births/1 ,000 population (1 999 est.)
Death rate: 9.88 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .94 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 1 2 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.56 years
male: 73.79 years
female: 77.37 years (1999 est.)
Total fertility rate: 1.78 children born/woman (1999
est.)
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)','c5bd5b65a27d63439b9907475a5b1a1e8ba3fac8a8a44d1beb5612e9efe464ab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08832a31b6f7abd68f48ea01ee5840a4bb33d36eb287bf8ff99da2168478bdb2',1999,'GI','Gibraltar','people-and-society',773,'Population: 29,661,636 (July 1999 est.)
Age structure:
0-14 years: 36% (male 5,409,322; female 5,208,742)
15-64 years: 60% (male 8,773,625; female
8,922,976)
65 years and over: 4% (male 61 9,1 64; female
727,807) (1999 est.)
Population growth rate: 1.84% (1999 est.)
Birth rate: 25.78 births/1,000 population (1999 est.)
Death rate: 6.1 2 deaths/1 ,000 population (1999 est.)
Net migration rate: -1 .27 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 50.96 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.87 years
male: 66.85 years
female: 70.99 years (1999 est.)
Total fertility rate: 3.24 children born/woman (1 999
est.)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%, Jewish
0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 1 5 and over can read and write
total population: 43.7%
male: 56.6%
female: 31% (1995 est.)','ed14b17a7a5650526a8c6aeb44625b5f52aa75cf09477323666dff053dfeb8c2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('458389a7fcbf56a54690d97d111c141f1af514f16eb82705dbb4cf29a9023f72',1999,'NA','Namibia','people-and-society',780,'Population: 1 ,648,270 (July 1 999 est.)
Age structure:
0-14 years: 44% (male 366,030; female 358,105)
15-64 years: 52% (male 424,879; female 435,1 1 6)
65 years and over: 4% (male 26,787; female 37,353)
(1999 est.)
Population growth rate: 1 .57% (1 999 est.)
Birth rate: 35.63 births/1 ,000 population (1 999 est.)
Death rate: 1 9.92 deaths/1 ,000 population (1 999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (1 999 est.)
Infant mortality rate: 65.94 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 41 .26 years
male: 41 .64 years
female: 40.87 years (1999 est.)
Total fertility rate: 4.94 children born/woman (1999
est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 86%, white 6.6%, mixed 7.4%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero 7%, Damara 7%, Nama 5%,
Caprivian 4%, Bushmen 3%, Baster 2%, Tswana
0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
least, other Christian denominations 30%), native
religions 10% to 20%
Languages: English 7% (official), Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 45%
female: 31% (1960 est.)','97d7925752007b39cb72d2622acf1e027f7749b6288601578a6379b02078ecf9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdefe47ef4ee1ba5ef61ba6909ae649d70ebb1535d5c7c9de13ad69a8c8deba9',1999,'NR','Nauru','people-and-society',788,'Population: 10,605 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over : NA
Population growth rate: 0% (1999 est.)
Birth rate: NA
Death rate: 0 deaths/1 ,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy: NA
Population: uninhabited
note: transient Haitian fishermen and others camp on
the island','2cf3baf895190f90919ed7e2b6785cbf75c9146b793b68f4286d6b60fe4b1122','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfd98b44344b7d6e7e59ef31e02914c1d778aa98772b92fe0ef164029ac5757e',1999,'NP','Nepal','people-and-society',796,'Population: 24,302,653 (July 1999 est.)
Age structure:
0-14 years: 41% (male 5,182,829; female 4,869,895)
15-64 years: 55% (male 6,856,905; female
6,571,916)
65 years and over: 4% (male 407,797; female
413,311) (1999 est.)
Population growth rate: 2.51% (1999 est.)
Birth rate: 35.32 births/1,000 population (1999 est.)
Death rate: 10.18 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 ,05 male(s)/female (1999 est.)
Infant mortality rate: 73.58 deaths/1 .000 live births
(1999 est.)
Life expectancy at birth:
total population: 58.42 years
male: 58.47 years
female: 58.36 years (1 999 est.)
Total fertility rate: 4.78 children born/woman (1999
est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais, Limbus,
Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim 3%,
other 2% (1981)
note: only official Hindu state in the world, although no
sharp distinction between many Hindu and Buddhist
groups
Languages: Nepali (official), 20 other languages
divided into numerous dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 27.5%
male: 40.9%
female: 14% (1995 est.)
People - note: refugee issue over the presence in
Nepal of approximately 91 ,000 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps','f4ea123ef73568573d8f8e26bbb2d935d2e1702346602a55ee868eb4420aa3c0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('744ff456129926f955f5e491613dfee4694baff0518cd8e108ab042eaa54bda4',1999,'BE','Belgium','people-and-society',802,'Population: 15,807,641 (July 1999 est.)
Age structure:
0-14 years: 18% (male 1 ,475,606; female 1,410,088)
15-64 years: 68% (male 5,482,193; female
5,288,948)
65 years and over: 1 4% (male 875,847; female
1,274,959) (1999 est.)
Population growth rate: 0.47% (1999 est.)
Birth rate: 1 1.36 births/1 ,000 population (1999 est.)
Death rate: 8.69 deaths/1 ,000 population (1999 est.)
Net migration rate: 1 .99 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.1 1 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78. 1 5 years
male: 75.28 years
female: 81.17 years (1999 est.)
Total fertility rate: 1.49 children born/woman (1999
est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 94%, Moroccans, Turks, and
other 6% (1988)
Religions: Roman Catholic 34%, Protestant 25%,
Muslim 3%, other 2%, unaffiliated 36% (1991)
Languages: Dutch
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%','3c081fa1257760721a61600710955da255b5bb84ecb8aba199b669782d61d36f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69431925b5224f0662ae11022f941e692475db0d7dac6c64376f4ed998f92797',1999,'NL','Netherlands','people-and-society',809,'Population: 207,827 (July 1999 est.)
Age structure:
0-14years: 26% (male 27,160; female 26,149)
15-64 years: 67% (male 65,781 ; female 73,054)
65 years and over: 7% (male 6,538; female 9,145)
(1999 est.)
Population growth rate: 1 .01 % (1 999 est.)
Birthrate: 17.11 births/1 ,000 population (1999 est.)
Death rate: 6.58 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.43 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 12.59 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.25 years
male: 72.1 9 years
female: 76.41 years (1999 est.)
Total fertility rate: 2.09 children born/woman (1999
est.)
Nationality:
noun: Netherlands Antillean(s)
adjective: Netherlands Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Portuguese-Dutch-English dialect)
predominates, English widely spoken, Spanish
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est.)','54702d454e2a725ab22a2c16d842224a72a3023b35d582d7b1d8408285460268','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee7b7e7bf89582177ce20af074c1c3b308a80fdc6a1304b8fd108110d9f0746e',1999,'NZ','New Zealand','people-and-society',817,'Population: 3,662,265 (July 1999 est.)
Age structure:
0-14 years: 23% (male 430,105; female 409,302)
15-64 years: 65% (male 1 ,202,762; female
1,195,006)
65 years and over: 12% (male 184,048; female
241,042) (1999 est.)
Population growth rate: 0.99% (1999 est.)
Birth rate: 14.42 births/1 ,000 population (1999 est.)
Death rate: 7.53 deaths/1 ,000 population (1 999 est.)
Net migration rate: 3.01 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 6.22 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.82 years
male: 74.55 years
female: 81 .27 years (1 999 est.)
Total fertility rate: 1.85 children born/woman (1999
est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%,
Maori 9.7%, other European 4.6%, Pacific Islander
3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 18%, Roman
Catholic 15%, Methodist 5%, Baptist 2%, other
Protestant 3%, unspecified or none 33% (1986)
Languages: English (official), Maori
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 109,082 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.8% (1999 est.)
Birth rate: 25.92 births/1,000 population (1999 est.)
Death rate: 6 deaths/1,000 population (1999 est.)
Net migration rate: -1.19 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: 37.93 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.78 years
male: 67.73 years
female: 72.22 years (1999 est.)
Total fertility rate: 3.56 children born/woman (1999
est.)
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
female: 98.7% (1996 est.)
Population: 1 ,1 02,096 (July 1 999 est.)
Age structure:
0-14 years: 27% (male 150,862; female 144,589)
15-64 years: 66% (male 377,894; female 346,375)
65 years and over: 7% (male 37,001 ; female 45,375)
(1999 est.)
Population growth rate: -1 .35% (1999 est.)
Birth rate: 14.46 births/1,000 population (1999 est.)
Death rate: 8.14 deaths/1 ,000 population (1999 est.)
Net migration rate: -19.8 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 .05 male(s)/female (1999 est.)
Infant mortality rate: 1 8.56 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.66 years
male: 68. 19 years
female: 73.19 years (1 999 est.)
Total fertility rate: 2.06 children born/woman (1999
est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic groups: black 40%, East Indian (a local term
- primarily immigrants from northern India) 40.3%,
mixed 14%, white 1%, Chinese 1%, other 3.7%
Religions: Roman Catholic 32.2%, Hindu 24.3%,
Anglican 14.4%, other Protestant 14%, Muslim 6%,
none or unknown 9.1%
Languages: English (official), Hindi, French,
Spanish
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
male: 98.8%
female: 97% (1995 est.)
Population: uninhabited
Population: 15,129 (July 1999 est.)
Age structure:
'' 0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 1.04% (1999 est.)
Birth rate: 22.34 births/1 ,000 population (1999 est.)
Death rate: 4.66 deaths/1 ,000 population (1 999 est.)
Net migration rate: -7.26 migrant(s)/1 ,000
population (1999 est.)
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Wallisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy:
definition: age 1 5 and over can read and write
total population: 50%
male: 50%
female: 50% (1969 est.)','41f30b058d4b130cdc4be0752517536e9c66aa5c6a08471cdaaf119b821ddc59','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0a8e6cf019992d3fa503d1061cd987f1e8f108c929021b0bbdb3936030124d',1999,'NE','Niger','people-and-society',824,'Population: 9,962,242 (July 1999 est.)
Age structure:
0-14 years: 48% (male 2,445,536; female 2,346,844)
15-64 years: 50% (male 2,421 ,971 ; female
2,518,248)
65 years and over: 2% (male 121 ,253; female
108,390) (1999 est.)
Population growth rate: 2.95% (1999 est.)
Birthrate: 52.31 births/1,000 population (1999 est.)
Death rate: 22.78 deaths/1,000 population (1999
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 1 12.79 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 41 .96 years
male: 42.22 years
female: 41 .7 years (1999 est.)
Total fertility rate: 7.24 children born/woman (1999
est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 13.6%
male: 20.9%
female: 6.6% (1995 est.)','fda09fd3ac9f5ba2d11b54db64fd18a1d057957ecec08678fc2ab30c24b16aee','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad70050a895e94b43ccc9dfd8354f97ce12ca885d3f5adf9325b73e184264072',1999,'NU','Niue','people-and-society',832,'Population: 2,103 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.5% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Niue (Niuean Church) 75% - a
Protestant church closely related to the London
Missionary Society, Latter-Day Saints 10%, other
15% (mostly Roman Catholic, Jehovah''s Witnesses,
Seventh-Day Adventist)
Languages: Polynesian closely related to Tongan
and Samoan, English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','0a80cd9505bd85d332553706a006e6064811552a15bfe9dfd3e5fc98ae48a010','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf69182b3e2ea8c8789aa383312e869ce0d6df6e5275088cf00b6210300e6d01',1999,'NF','Norfolk Island','people-and-society',836,'Population: 1 ,905 (July 1 999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.71% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 39%, Roman Catholic 1 1 .7%,
Uniting Church in Australia 16.4%, Seventh-Day
Adventist 4.4%, none 9.2%, unknown 16.9%, other
2.4% (1986)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian','ae1dbd12f9a1795e17be16bc192129906af1bfa5d0b785a79d7619fb47bf4510','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e2e19a7135b4a3cf37b3e22e7519516e4604133c356adf5ea18d39fce3b9e15',1999,'PA','Panama','people-and-society',847,'Population: 2,778,526 (July 1999 est.)
Age structure:
0-14 years: 32% (male 446,792; female 429,81 1)
15-64 years: 63% (male 882,541 ; female 859,455)
65 years and over: 5% (male 76,648; female 83,279)
(1999 est.)
Population growth rate: 1.53% (1999 est.)
Birth rate: 21 .69 births/1 ,000 population (1999 est.)
Death rate: 5.1 4 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1 .22 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/fema!e
65 years and over: 0.92 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 23.35 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.66 years
male: 71 .91 years
female: 77.51 years (1999 est.)
Total fertility rate: 2.54 children born/woman (1999
est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 1 5 and over can read and write
total population: 90.8%
male: 91 .4%
female: 90.2% (1995 est.)','07cb634d3671121702154589090e6b646177e8e276518b93795e7cf5e93eac3f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('487194a8d74d4877fa632164efcecea1666a61241210b37d3dceb91c0a92bf09',1999,'PT','Portugal','people-and-society',865,'Population: 9,918,040 (July 1999 est.)
Age structure:
0-14 years: 1 7% (male 866,1 1 5; female 820,438)
15-64 years: 68% (male 3,283,345; female
3,428,427)
65 years and over: 1 5% (male 61 9,086; female
900,629) (1999 est.)
Population growth rate: -0.13% (1999 est.)
Birth rate: 1 0.49 births/1 ,000 population (1 999 est.)
Death rate: 10.25 deaths/1,000 population (1999
est.)
Net migration rate: -1 .51 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.06 male(s)/female
under 15 years: 1 .06 ma!e(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 6.73 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.88 years
male: 72.51 years
female: 79.46 years (1 999 est.)
Total fertility rate: 1 .34 children born/woman (1 999
est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock;
citizens of black African descent who immigrated to
mainland during decolonization number less than
100,000
Religions: Roman Catholic 97%, Protestant
denominations 1%, other 2%
Languages: Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 85%
male: 89%
female: 82% (1 990 est.)','25a4ece955b1e003a044c344f2b5be5c46f3db116db2f1818fa3f0aae32a5348','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73cd208e187a1f845a45348b436d7642e55512274c8b8175c063f08a9763e39d',1999,'QA','Qatar','people-and-society',870,'Population: 723,542 (July 1999 est.)
Age structure:
0-14 years: 27% (male 99,232; female 95,421)
15-64 years: 71% (male 367,213; female 145,925)
65 years and over: 2% (male 1 1 ,047; female 4,704)
(1999 est.)
Population growth rate: 3.62% (1999 est.)
Birth rate: 1 6.75 births/1 ,000 population (1 999 est.)
Death rate: 3.57 deaths/1 ,000 population (1999 est.)
Net migration rate: 23.03 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 2.52 male(s)/female
65 years and over: 2.35 male(s)/female
total population: 1 .94 male(s)/female (1999 est.)
Infant mortality rate: 17.25 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 74.23 years
male: 71 .7 years
female: 76.89 years (1 999 est.)
Total fertility rate: 3.42 children born/woman (1999
est.)
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 1 5 and over can read and write
total population: 79.4%
male: 79.2%
female: 79.9% (1995 est.)
397
Qatar (continued)
Population: 717,723 (July 1999 est.)
Age structure:
0-14 years: 32% (male 1 18,401 ; female 1 12,878)
15-64 years: 62% (male 218,952; female 225,292)
65 years and over: 6% (male 1 7,506; female 24,694)
(1999 est.)
Population growth rate: 1 .75% (1 999 est.)
Birth rate: 22.16 births/1,000 population (1999 est.)
Death rate: 4.64 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 6.9 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.73 years
male: 72.69 years
female: 78.93 years (1999 est.)
Total fertility rate: 2.64 children born/woman (1999
est.)
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 86%, Hindu, Islam,
Buddhist (1995)
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)','fe15feb5a1085f3d762ec94ba02a5c6559f55a2864348d896432a9d583a331f0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08a03fb4fb142e4b559048921a074fde6624f14aeb4ec40909cef510531d5897',1999,'UA','Ukraine','people-and-society',878,'Population: 22,334,312 (July 1999 est.)
Age structure:
0-14 years: 19% (male 2,117,289; female 2,027,940)
15-64 years: 68% (male 7,563,695; female
7,663,491)
65 years and over: 1 3% (male 1 ,234,760; female
1,727,137) (1999 est.)
Population growth rate: -0.23% (1999 est.)
Birth rate: 10.09 births/1,000 population (1999 est.)
Death rate: 1 1 .55 deaths/1 ,000 population (1 999
est.)
Net migration rate: -0.87 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 ma!e(s)/female
total population: 0.96 male(s)/1emale (1999 est.)
Infant mortality rate: 18.12 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.83 years
male: 67.05 years
female: 74.81 years (1999 est.)
Total fertility rate: 1 .27 children born/woman (1999
est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.1%, Hungarian 8.9%,
German 0.4%, Ukrainian, Serb, Croat, Russian, Turk,
and Gypsy 1 .6%
Religions: Romanian Orthodox 70%, Roman
Catholic 6% (of which 3% are Uniate), Protestant 6%,
unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 146,393,569 (July 1999 est.)
Age structure:
0-14 years: 19% (male 14,224,033; female
13,666,440)
15-64 years: 68% (male 48,407,409; female
51,768,664)
65 years and over: 13% (male 5,698,356; female
12,628,667) (1999 est.)
Population growth rate: -0.33% (1999 est.)
Birth rate: 9.64 births/1 ,000 population (1999 est.)
Death rate: 1 4.96 deaths/1 ,000 population (1 999
est.)
Net migration rate: 2.05 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.45 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 23 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 65.12 years
mate: 58.83 years
female: 71 .72 years (1999 est.)
Total fertility rate: 1.34 children born/woman (1999
est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1 .2%, Bashkir 0.9%,
Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)
Population: 8,154,933 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1 ,807,695; female 1 ,793,590)
15-64 years: 53% (male 2,148,477; female
2,179,119)
65 years and over: 3% (male 92,490; female
133,562) (1999 est.)
Population growth rate: 2.43% (1999 est.)
Birth rate: 38.97 births/1 ,000 population (1 999 est.)
Death rate: 1 9.53 deaths/1 ,000 population (1 999
est.)
Net migration rate: 4.91 migrant(s)/1 ,000
population (1999 est.)
note: following the outbreak of genocidal strife in
Rwanda in April 1994 between Tutsi and Hutu
factions, more than 2 million refugees fled to
neighboring Burundi, Tanzania, Uganda, and
Democratic Republic of the Congo (formerly Zaire);
according to the UN High Commission on Refugees,
in 1996 and early 1997 nearly 1 .3 million Hutus
returned to Rwanda - of these 720,000 returned from
Democratic Republic of the Congo, 480,000 from
Tanzania, 88,000 from Burundi, and 10,000 from
Uganda; probably fewer than 100,000 Rwandans
remained outside of Rwanda by the end of 1997
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 maie(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (1 999 est.)
Infant mortality rate: 1 1 2.86 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 41 .31 years
male: 40.84 years
female: 41 .8 years (1 999 est.)
Total fertility rate: 5.8 children born/woman (1999
est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 80%, Tutsi 19%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%,
Muslim 1%, indigenous beliefs and other 25%
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 15 and over can read and write
total population: 60.5%
male: 69.8%
female: 51 .6% (1995 est.)
Population: 7,145 (July 1999 est.)
Age structure:
0-14 years: 20% (male 713; female 690)
15-64 years: 72% (male 2,664; female 2,449)
65 years and over: 8% (male 259; female 370) (1999
est.)
Population growth rate: 0.74% (1999 est.)
Birth rate: 13.86 births/1 ,000 population (1999 est.)
Death rate: 6.44 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 1 .04 male(s)/female (1 999 est.)
Infant mortality rate: 27.98 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.88 years
male: 72.78 years
female: 79.13 years (1999 est.)
Total fertility rate: 1.5 children born/woman (1999
est.)
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent, white
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
409
Saint Helena (continued)
male: 97%
female: 98% (1987 est.)
Population: 49,81 1,174 (July 1999 est.)
Age structure:
0-14 years: 18% (male 4,690,318; female 4,498,239)
15-64 years: 68% (male 16,136,296; female
17,572,011)
65 years and over: 14% (male 2,251 ,664; female
4,662,646) (1999 est.)
Population growth rate: -0.62% (1999 est.)
Birth rate: 9.54 births/1,000 population (1999 est.)
Death rate: 1 6.38 deaths/1 ,000 population (1999
est.)
Net migration rate: 0.63 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years : 0.92 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.86 male(s)/female (1999 est.)
Infant mortality rate: 21 .73 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 65.91 years
male: 60.23 years
female: 71 .87 years (1999 est.)
Total fertility rate: 1 .34 children born/woman (1 999
est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow
Patriarchate, Ukrainian Orthodox - Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)','ffd569298460d2228ac39160e8d0545826954fd901a01076b73bf444bbe5c48b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5062fb474f552d476e012979536d2dca45efa807d5a34ae9f4fbaf20b27f91d',1999,'TT','Trinidad and Tobago','people-and-society',889,'Population: 42,838 (July 1999 est.)
Age structure:
0-14 years: 33% (male 7,1 78; female 6,826)
15-64 years: 61% (male 13,226; female 13,083)
65 years and over: 6% (male 1 ,020; female 1 ,505)
(1999 est.)
Population growth rate: 1.34% (1999 est.)
Birth rate: 22.6 births/1 ,000 population (1999 est.)
Death rate: 8.15 deaths/1 ,000 population (1999 est.)
Net migration rate: -1 .05 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 ma!e(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .01 maie(s)/female
65 years and over: 0.68 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 17.39 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 67.94 years
male: 64.87 years
female: 71.21 years (1 999 est.)
Total fertility rate: 2.42 children born/woman (1999
est.)
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: black
Religions: Anglican, other Protestant sects, Roman
Catholic
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 98% (1980 est.)','82b2df0b39ffe742811a24727f52cbf715594809c852e29745d5a025ecd178fe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506d4d4cbf321f69c7fa15f58e656d05ca1f46a40c346e843980d01e0d6fd9f9',1999,'LC','Saint Lucia','people-and-society',897,'Population: 154,020 (July 1999 est.)
Age structure:
0-14 years: 33% (male 26,068; female 25,359)
15-64 years: 61 % (male 46,265; female 48,100)
65 years and over: 6% (male 3,097; female 5,1 31 )
(1999 est.)
Population growth rate: 1 .09% (1999 est.)
Birth rate: 21 .63 births/1 ,000 population (1 999 est.)
Death rate: 5.58 deaths/1 ,000 population (1 999 est.)
Net migration rate: -5.1 9 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.07 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 16.55 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 71. 81 years
male: 68.14 years
female: 75.74 years (1 999 est.)
Total fertility rate: 2.27 children born/woman (1999
est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian
3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 67%
male: 65%
female: 69% (1980 est.)','a098dc351e6ab585bd0453d08b497094d6c0c0e8a41997753eee4f8b713cd968','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('020afdca100b73060010c3b12972c61c8a7e14ba1c5699fca51e440a3fb80255',1999,'IT','Italy','people-and-society',905,'Population: 25,061 (July 1999 est.)
Age structure:
0-14 years: 16% (male 2,008; female 2,036)
15-64 years: 67% (male 8,501 ; female 8,294)
65 years and over: 17% (male 1 ,774; female 2,448)
(1999 est.)
Population growth rate: 0.64% (1 999 est.)
Birth rate: 10.41 births/1,000 population (1999 est.)
Death rate: 8.22 deaths/1 ,000 population (1999 est.)
Net migration rate: 4.23 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 ma!e(s)/female
under 15 years: 0.99 male(s)/female
15-64 years : 1 .02 male(s)/female
65 years and over: 0,72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 5.39 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 81 .47 years
male: 77.59 years
female: 85.35 years (1999 est.)
Total fertility rate: 1.51 children born/woman (1999
est.)
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
female: 95% (1976 est.)
Population: 154,878 (July 1999 est.)
421
Sao Tome and Principe (continued)
Age structure:
0-14 years: 48% (male 37,322; female 36,423)
15-64 years: 48% (male 36,067; female 38,730)
65 years and over: 4% (male 2,876; female 3,460)
(1999 est.)
Population growth rate: 3.14% (1999 est.)
Birth rate: 43.31 births/1 ,000 population (1999 est.)
Death rate: 8.08 deaths/1 ,000 population (1 999 est.)
Net migration rate: -3.88 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 52.93 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.71 years
male: 63.18 years
female: 66.28 years (1999 est.)
Total fertility rate: 6.14 children born/woman (1999
est.)
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola,
Mozambique, and Cape Verde), tongas (children of
servicais bom on the islands), Europeans (primarily
Portuguese)
Religions: Roman Catholic, Evangelical Protestant,
Seventh-Day Adventist
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 73%
male: 85%
female: 62% (1991 est.)
Population: 7,275,467 (July 1999 est.)
Age structure:
0-14 years: 1 7% (male 639,970; female 61 1 ,876)
15-64 years: 68% (male 2,509,988; female
2,417,580)
65 years and over: 1 5% (male 444,482; female
651,571) (1999 est.)
Population growth rate: 0.2% (1999 est.)
Birth rate: 10.53 births/1 ,000 population (1999 est.)
Death rate: 9.06 deaths/1 ,000 population (1999 est.)
Net migration rate: 0.49 migrant(s)/1 ,000
population (1999 est.)
Switzerland (continued)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years : 1 .04 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male{s)/fema!e (1999 est.)
Infant mortality rate: 4.87 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 78.99 years
male: 75.83 years
female: 82.32 years (1999 est.)
Total fertility rate: 1 .46 children born/woman (1999
est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 46.1%, Protestant 40%,
other 5%, no religion 8.9% (1990)
Languages: German 63.7%, French 19.2%, Italian
7.6%, Romansch 0.6%, other 8.9%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 980 est.)
male: NA%
female: NA%
f: Government
Country name:
conventional long form: Swiss Confederation
conventional short form: Switzerland
local long form: Schweizerische Eidgenossenschaft
(German), Confederation Suisse (French),
Confederazione Svizzera (Italian)
local short form: Schweiz (German), Suisse (French),
Svizzera (Italian)
Data code: SZ
Government type: federal republic
Capital: Bern
Administrative divisions: 26 cantons (cantons,
singular - canton in French; cantoni, singular - cantone
in Italian; kantone, singular - kanton in German);
Aargau, Ausser-Rhoden, Basel-Landschaft,
Basel-Stadt, Bern, Fribourg, Geneve, Glarus,
Graubunden, Inner-Rhoden, Jura, Luzern, Neuchatel,
Nidwalden, Obwalden, Sankt Gallen, Schaffhausen,
Schwyz, Solothurn, Thurgau, Ticino, Uri, Valais,
Vaud, Zug, Zurich
Independence: 1 August 1291
National holiday: Anniversary of the Founding of
the Swiss Confederation, 1 August (1291)
Constitution: 29 May 1874
Legal system: civil law system influenced by
customary law; judicial review of legislative acts,
except with respect to federal decrees of general
obligatory character; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Ruth DREIFUSS (since 1
January 1999); Vice President Adolf OGI (since 1
January 1999); note - the president is both the chief of
state and head of government
head of government: President Ruth DREIFUSS
(since 1 January 1999); Vice President Adolf OGI
(since 1 January 1 999); note - the president is both the
chief of state and head of government
cabinet: Federal Council or Bundesrat (in German),
Conseil Federal (in French), Consiglio Federate (in
Italian) elected by the Federal Assembly from among
its own members for a four-year term
elections: president and vice president elected by the
Federal Assembly from among the members of the
Federal Council for one-year terms that run
concurrently; election last held NA December 1998
(next to be held NA December 1999)
election results: Ruth DREIFUSS elected president;
percent of Federal Assembly vote - Ruth DREIFUSS
75%; Adolf OGI elected vice president; percent of
legislative vote - NA
Legislative branch: bicameral Federal Assembly or
Bundesversammlung (in German), Assemblee
Federate (in French), Assemblea Federate (in Italian)
consists of the Council of States or Standerat (in
German), Conseil des Etats (in French), Consiglio
degli Stati (in Italian) (46 seats - members serve
four-year terms) and the National Council or
Nationalrat (in German), Conseil National (in French),
Consiglio Nazionale (in Italian) (200 seats - members
are elected by popular vote on a basis of proportional
representation to serve four-year terms)
elections: Council of States - last held throughout
1 997 (each canton determines when the next election
will be held); National Council - last held 20 October
1995 (next to be held probably 24 October 1999)
election results: Council of States - percent of vote by
party - NA; seats by party - FDP 17, CVP 16, SVP 5,
SPS 5, LPS 2, LdU 1 ; National Council - percent of
vote by party - NA; seats by party - FDP 45, SPS 54,
CVP 34, SVP 29, Greens 9, LPS 7, FPS 7, LdU 3,
EVP 2, SD 3, PdAdS 3, Ticino League 1 , EDU 1 ,
FRAP 1, CSP 1
Judicial branch: Federal Supreme Court, judges
elected for six-year terms by the Federal Assembly
Political parties and leaders: Radical Free
Democratic Party (Freisinnig-Demokratische Partei
der Schweiz or FDP, Parti Radical-Democratique
Suisse or PRD, Partitio Liberal-Radicale Svizzero or
PLR) [Franz STEINEGGER, president]; Social
Democratic Party (Sozialdemokratische Partei der
Schweiz or SPS, Parti Socialist Suisse or PSS, Partito
Socialista Svizzero or PSS, Partida
Socialdemocratica de la Svizra or PSS) [Ursula
KOCH, president]; Christian Democratic People''s
Party (Christichdemokratische Volkspartei der
Schweiz or CVP, Parti Democrate-Chretien Suisse or
PDC, Partito Democratico-Cristiano Popolare
Svizzero or PDC, Partida Cristiandemocratica dalla
Svizra or PCD) [Adalbert DURRER, president]; Swiss
People''s Party (Schweizerische Volkspartei or SVP,
Union Democratique du Centre or UDC, Unione
Democratica de Centro or UDC, Uniun Democratica
dal Center or UDC) [Ueli MAURER, president]; Green
Party (Grune Partei der Schweiz or Grune, Parti
Ecologiste Suisse or Les Verts, Partito Ecologista
Svizzero or I Verdi, Partida Ecologica Svizra or La
Verda) [Ruedi BAUMANN, president]; Freedom Party
or FPS [Roland BORER]; Alliance of Independents''
Party (Landesring der Unabhaengigen or LdU,
Alliance des Independants or Adi) [Anton
SCHALLER, president]; Ticino League (Lega dei
Ticinesi) [leader NA]; and other minor parties
including Swiss Democratic Party (Schweizer
Demokraten or SD, Democrates Suisses or DS,
Democratici Svizzeri or DS), Liberal Party (Liberate
Partei der Schweiz or LPS, Parti Liberal Suisse or
PLS, Partito Liberate Svizzero or PLS), Workers'' Party
(Parti Suisse du Travail or PST, Partei der Arbeit der
Schweiz or PdAdS, Partito Svizzero del Lavoro or
PSdL), Evangelical People''s Party (Evangelische
Volkspartei der Schweiz or EVP, Parti Evangelique
Suisse or PEV, Partito Evangelico Svizzero or PEV),
and the Union of Federal Democrats
(Eidgenossisch-Demokratische Union or EDU, Union
Democratique Federate or UDF, Unione Democratica
Federate or UDF)
International organization participation: ACCT,
AfDB, AsDB, Australia Group, BIS, CCC, CE, CERN,
EAPC, EBRD, ECE, EFTA, ESA, FAO, G-10, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, IEA,
IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, IOM, ISO, ITU, LAIA (observer), MTCR,
NAM (guest), NEA, NSG, OAS (observer), OECD,
OSCE, PCA, PFP, UN (observer), UNCTAD,
UNESCO, UNHCR, UNIDO, UNITAR, UNMIBH,
UNMOP, UNMOT, UNOMIG, UNPREDEP, UNTSO,
UNU, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO,
ZC
Diplomatic representation in the US:
chief of mission: Ambassador Alfred DEFAGO
chancery: 2900 Cathedral Avenue NW, Washington,
DC 20008
telephone: [1] (202) 745-7900
FAX: [1] (202) 387-2564
consulate(s) general: Atlanta, Chicago, Houston, Los
Angeles, New York, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Madeleine May KUNIN
embassy: Jubilaeumstrasse 93, 3005 Bern
mailing address: use embassy street address
telephone: [41] (31) 357 7011
FAX: [41] (31) 357 73 44
Flag description: red square with a bold, equilateral
white cross in the center that does not extend to the
edges of the flag
Population: 17,213,871 (July 1999 est.)
note: in addition, there are about 37,200 people living
in the Israeli-occupied Golan Heights - 18,200 Arabs
(1 6,500 Druze and 1 ,700 Alawites) and about 1 9,000
Israeli settlers (August 1998 est.)
Age structure:
0- 14 years: 46% (male 4,032,620; female 3,840,431 )
15-64 years: 51% (male 4,515,274; female
4,322,415)
65 years and over: 3% (male 246,81 2; female
256,319) (1999 est.)
Population growth rate: 3.15% (1999 est.)
Birth rate: 36.95 births/1,000 population (1999 est.)
Death rate: 5.4 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/fema!e
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .04 male(s)/female (1999 est.)
Infant mortality rate: 36.42 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.09 years
male: 66.75 years
female: 69.48 years (1999 est.)
Total fertility rate: 5.37 children born/woman (1999
est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and
other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and
other Muslim sects 16%, Christian (various sects)
10%, Jewish (tiny communities in Damascus, Al
Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian,
Aramaic, Circassian widely understood; French,
English somewhat understood
Literacy:
definition: age 1 5 and over can read and write
total population: 70.8%
male: 85.7%
female: 55.8% (1997 est.)','fc6537197700e8609cefa54e1b206a95220b2f3d5e418f9906e8510604beb515','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83b6256605a9ef2f501ee198b459951625c96a1c3d27a52a9400eab0a2641b58',1999,'SA','Saudi Arabia','people-and-society',914,'Population: 21 ,504,613 (July 1999 est.)
note: includes 5,321,938 non-nationals (July 1999
est.)
Age structure:
0-14 years: 43% (male 4,705,724; female 4,543,91 8)
15-64 years: 54% (male 6,925,020; female
4,783,570)
65 years and over: 3% (male 291 ,449; female
254,932) (1999 est.)
Population growth rate: 3.39% (1999 est.)
Birth rate: 37.38 births/1 ,000 population (1999 est.)
Death rate: 4.86 deaths/1 ,000 population (1999 est.)
Net migration rate: 1 .4 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .45 male(s)/female
65 years and over: 1.14 male(s)/female
total population: 1 .24 male(s)/female (1999 est.)
Infant mortality rate: 38.8 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.55 years
male: 68.67 years
female: 72.53 years (1 999 est.)
Total fertility rate: 6.34 children born/woman (1999
est.)
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.8%
male: 71 .5%
female: 50.2% (1 995 est.)
K Government
Country name:
conventional long form: Kingdom of Saudi Arabia
conventional short form: Saudi Arabia
local long form: Al Mamlakah al Arabiyah as Suudiyah
local short form: Al Arabiyah as Suudiyah
Data code: SA
423
Saudi Arabia (continued)
Government type: monarchy
Capital: Riyadh
Administrative divisions: 13 provinces (mintaqat,
singular - mintaqah); Al Bahah, Al Hudud ash
Shamaliyah, Al Jawf, Al Madinah, Al Qasim, Ar Riyad,
Ash Sharqiyah (Eastern Province), ''Asir, Ha''il, Jizan,
Makkah, Najran, Tabuk
Independence: 23 September 1932 (unification)
National holiday: Unification of the Kingdom, 23
September (1932)
Constitution: governed according to Shari''a (Islamic
law); the Basic Law that articulates the government''s
rights and responsibilities was introduced in 1993
Legal system: based on Islamic law, several secular
codes have been introduced; commercial disputes
handled by special committees; has not accepted
compulsory ICJ jurisdiction
Suffrage: none
Executive branch:
chief of state: King and Prime Minister FAHD bin Abd
al-Aziz Al Saud (since 13 June 1982); Crown Prince
and First Deputy Prime Minister ABDALLAFI bin Abd
al-Aziz Al Saud (half-brother to the monarch, heir to
the throne since 1 3 June 1 982, regent from 1 January
to 22 February 1996); note - the monarch is both the
chief of state and head of government
head of government: King and Prime Minister FAHD
bin Abd al-Aziz Al Saud (since 1 3 June 1 982); Crown
Prince and First Deputy Prime Minister ABDALLAFI
bin Abd al-Aziz Al Saud (half-brother to the monarch,
heir to the throne since 13 June 1982, regent from 1
January to 22 February 1996); note - the monarch is
both the chief of state and head of government
cabinet: Council of Ministers is appointed by the
monarch and includes many royal family members
elections: none; the monarch is hereditary
Legislative branch: a consultative council (90
members and a chairman appointed by the monarch
for four-year terms)
Judicial branch: Supreme Council of Justice
Political parties and leaders: none allowed
International organization participation: ABEDA,
AfDB, AFESD, AL, AMF, BIS, CCC, ESCWA, FAO,
G-19, G-77, GCC, IAEA, IBRD, ICAO, ICC, ICRM,
IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, ISO, ITU, NAM, OAPEC, OAS
(observer), OIC, OPCW, OPEC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO,
WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador BANDAR bin Sultan bin
Abd al-Aziz Al Saud
chancery: 601 New Hampshire Avenue NW,
Washington, DC 20037
telephone: [1] (202) 342-3800
consulate(s) general: Houston, Los Angeles, and
New York
Diplomatic representation from the US:
chief of mission: Ambassador Wyche FOWLER, Jr.
embassy: Collector Road M, Diplomatic Quarter,
Riyadh
mailing address: American Embassy Riyadh, Unit
61307, APO AE 09803-1307; International Mail: P. O.
Box 94309, Riyadh 11693
telephone: [966] (1) 488-3800
FAX: [966] (1)488-7360
consulate(s) general: Dhahran, Jiddah (Jeddah)
Flag description: green with large white Arabic
script (that may be translated as There is no God but
God; Muhammad is the Messenger of God) above a
white horizontal saber (the tip points to the hoist side);
green is the traditional color of Islam','2f903e59bf5aecfe51263a1767359c500923e6e23d5bd14f001168014f845b23','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d1369d453b202555dcd39e042c1f63a63ab72773e887c7f387b7e830537e6e',1999,'ME','Montenegro','people-and-society',927,'Population: 1 1 ,206,847 (Serbia - 1 0,526,478;
Montenegro - 680,369) (July 1999 est.)
note: all data dealing with population is subject to
considerable error because of the dislocations caused
by military action and ethnic cleansing
Age structure:
0-14 years: Serbia - 20% (male 1,102,109; female
1,025,069); Montenegro - 21% (male 75,633; female
70,464)
15-64 years: Serbia - 67% (male 3,538,689; female
3,483,192); Montenegro - 68% (male 232,223; female
227,371)
65 years and over: Serbia - 13% (male 595,200;
female 782,219); Montenegro - 11% (male 30,829;
female 43,849) (July 1999 est.)
Population growth rate: Serbia - 0.02%;
Montenegro - 0.07% (1999 est.)
Birth rate: Serbia - 12.54 births/1 ,000 population;
Montenegro - 13.19 births/1 ,000 population (1999
est.)
Death rate: Serbia - 9.68 deaths/1 ,000 population;
Montenegro - 7.44 deaths/1 ,000 population (1999
est.)
Net migration rate: Serbia - -2.65 migrants/1 ,000
population; Montenegro - -5.09 migrants/1,000
population (1999 est.)
Sex ratio:
at birth: Serbia - 1 .08 male(s)/female; Montenegro -
1 .08 male(s)/female
under 15 years: Serbia - 1.08 male(s)/female;
Montenegro - 1 .07 male(s)/female
15-64 years: Serbia - 1 .02 male(s)/female;
Montenegro - 1 .02 ma!e(s)/female
65 years and over: Serbia - 0.76 male(s)/female;
Montenegro - 0.70 male(s)/fema!e
total population: Serbia - 0.99 male(s)/female;
Montenegro - 0,99 male(s)/female (1999 est.)
Infant mortality rate: Serbia - 1 6.49 deaths/1 ,000
live births; Montenegro - 10.99 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: Serbia - 73.45 years; Montenegro -
76.32 years
male: Serbia - 71 .03 years; Montenegro - 72.87 years
female: Serbia - 76.05 years; Montenegro - 80.07
years (1999 est.)
Total fertility rate: Serbia - 1 .74 children born/
woman; Montenegro - 1.76 children born/woman
(1999 est.)
Nationality:
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serbs 63%, Albanians 14%,
Montenegrins 6%, Hungarians 4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA','6f106b0de3ec418d1788baad61fc614aa2d553c04d772f7869ec9f612548c6dc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('790dcc3e65d5e1ca7852e1c99f984803b652070c1abcb08383be5a032e822090',1999,'SC','Seychelles','people-and-society',932,'Population: 79,164 (July 1999 est.)
Age structure:
0-14 years: 29% (male 11,712; female 1 1 ,569)
15-64 years: 64% (male 24,879; female 26,038)
65 years and over: 7% (male 1 ,709; female 3,257)
(1999 est.)
Population growth rate: 0.65% (1999 est.)
Birth rate: 1 9.39 births/1 ,000 population (1 999 est.)
Death rate: 6.56 deaths/1 ,000 population (1999 est.)
Net migration rate: -6.32 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.52 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 16.65 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.95 years
male: 66.61 years
female: 75.42 years (1999 est.)
Total fertility rate: 1 .97 children born/woman (1999
est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic groups: Seychellois (mixture of Asians,
Africans, Europeans)
Religions: Roman Catholic 90%, Anglican 8%, other
2%
Languages: English (official), French (official),
Creole
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 56%
female: 60% (1971 est.)','d1bd7ad99b71ba5a8f554c993bfc3a109f74d9cba3788de463615c424d97d61e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f446303e73c7861e17d5692b653fc590dfab350e2f810200d7c4f15acfbb0591',1999,'SL','Sierra Leone','people-and-society',940,'Population: 5,296,651 (July 1999 est.)
Age structure:
0-1 4 years: 45% (male 1,182,181; female 1,219,956)
15-64 years: 52% (male 1 ,307,475; female
1,423,046)
65 years and over: 3% (male 82,374; female 81,619)
(1999 est.)
Population growth rate: 4.34% (1999 est.)
Birth rate: 45.62 births/1,000 population (1999 est.)
Death rate: 1 6.77 deaths/1 ,000 population (1 999
est.)
Net migration rate: 14.5 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 126.23 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 49. 1 3 years
male: 46.07 years
432
Sierra Leone (continued)
female: 52.27 years (1999 est.)
Total fertility rate: 6.16 children born/woman (1999
est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole 10%
(descendents of freed Jamaican slaves who were
settled in the Freetown area in the late-eighteenth
century), refugees from Liberia''s recent civil war,
small numbers of Europeans, Lebanese, Pakistanis,
and Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendents of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English,
Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
female: 18.2% (1995 est.)','069c2f25f5f40ebff0de6b1ff1a6bf0a7f6caf4b25651fb7dafd65070aca05fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0b47e651dd18cc9e4ac7260149bacb5be61196f178eb60d3103ad6595dc72a4',1999,'SK','Slovakia','people-and-society',947,'Population: 5,396,193 (July 1999 est.)
Age structure:
0-14 years: 20% (male 551 ,847; female 528,236)
15-64 years: 69% (male 1,837,788; female
1,861,305)
65 years and over: 1 1 % (male 237,71 0; female
379,307) (1999 est.)
Population growth rate: 0.04% (1999 est.)
Birth rate: 9.52 births/1 ,000 population (1999 est.)
Death rate: 9.43 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.29 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.63 ma!e(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 9.48 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 73.46 years
male: 69.71 years
female: 77 A years (1 999 est.)
Total fertility rate: 1.2 children born/woman (1999
est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.7%,
Gypsy 1 .5% (the 1 992 census figures underreport the
Gypsy/Romany community, which is about 500,000),
Czech 1%, Ruthenian 0.3%, Ukrainian 0.3%, German
0.1%, Polish 0.1%, other 0.3%
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy: NA','06b67c5f8708650f6505df4d85d9f8715ff207cc466f267ab63d78d48439cd70','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1410db9b964d31e09cbf6115c51d0b1b39822b2ca9f058d552a66239934a2cd7',1999,'SB','Solomon Islands','people-and-society',957,'Population: 455,429 (July 1999 est.)
Age structure:
0-14 years: 45% (male 103,844; female 99,972)
15-64 years: 52% (male 120,518; female 117,298)
65 years and over: 3% (male 6,808; female 6,989)
(1999 est.)
Population growth rate: 3.18% (1999 est.)
Birth rate: 35.92 births/1,000 population (1999 est.)
Death rate: 4.1 1 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1 .03 male(s)/female (1 999 est.)
Infant mortality rate: 23 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.09 years
male: 69.55 years
female: 74.75 years (1999 est.)
Total fertility rate: 4.96 children born/woman (1999
est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%,
Micronesian 1 .5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions: Anglican 34%, Roman Catholic 19%,
Baptist 17%, United (Methodist/Presbyterian) 11%,
Seventh-Day Adventist 10%, other Protestant 5%,
traditional beliefs 4%
Languages: Melanesian pidgin in much of the
country is lingua franca, English spoken by 1%-2% of
population
note: 120 indigenous languages
Literacy: NA','8c922caf5f495d1339888578dc9254845972c79ecf96c94532f20fa25dddba81','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4408af8f537b9462dc892909a3d6f8661435e92434c6681b0494dea1d9e3c923',1999,'SO','Somalia','people-and-society',963,'Population: 7,140,643 (July 1999 est.)
note: this estimate was derived from an official census
taken in 1987 by the Somali Government with the
cooperation of the UN and the US Bureau of the
Census; population estimates are updated between
censuses by factoring in growth rates and by taking
account of refugee movements and losses due to
famine; lower estimates of Somalia''s population in
mid-1 996 (on the order of 6.0 million to 6.5 million)
have been made by aid and relief agencies, based on
the number.of persons being fed; population counting
in Somalia is complicated by the large numbers of
nomads and by refugee movements in response to
famine and clan warfare
Age structure:
0-14 years: 44% (male 1 ,588,025; female 1 ,584,770)
15-64 years: 53% (male 1 ,898,794; female
1,865,487)
65 years and over: 3% (male 92,41 9; female
111,148) (1999 est.)
Population growth rate: 4.13% (1999 est.)
Birth rate: 47.98 births/1 ,000 population (1999 est.)
Death rate: 18.62 deaths/1 ,000 population (1999
est.)
Net migration rate: 1 1 .9 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .01 male(s)/female (1999 est.)
Infant mortality rate: 125.77 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 46.23 years
male: 44.66 years
female: 47.85 years (1999 est.)
Total fertility rate: 7.25 children born/woman (1999
est.)
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu, Arabs 30,000
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 1 5 and over can read and write
total population: 24%
male: 36%
female: 14% (1990 est.)
Population: 43,426,386 (July 1999 est.)
note: South Africa took a census 10 October 1996
which showed a population of 37,859,000 (after a
6.8% adjustment for underenumeration based on a
post-enumeration survey); this figure is still about 1 0%
below projections from earlier censuses; since the full
results of that census have not been released for
analysis, the numbers shown for South Africa do not
take into consideration the results of this 1 996 census
Age structure:
0-14 years : 34% (male 7,541 ,840; female 7,403,235)
15-64 years: 61% (male 13,180,925; female
13,312,917)
65 years and over: 5% (male 798,825; female
1,188,644) (1999 est.)
Population growth rate: 1 .32% (1999 est.)
Birth rate: 25.94 births/1 ,000 population (1 999 est.)
Death rate: 12.81 deaths/1,000 population (1999
est.)
Net migration rate: 0.08 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 51 .99 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 54,76 years
male: 52.68 years
female: 56.9 years (1999 est.)
Total fertility rate: 3.09 children born/woman (1999
est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored
8.6%, Indian 2.6%
Religions: Christian 68% (includes most whites and
Coloreds, about 60% of blacks and about 40% of
Indians), Muslim 2%, Hindu 1.5% (60% of Indians),
traditional and animistic 28.5%
Languages: 11 official languages, including
Afrikaans, English, Ndebele, Pedi, Sotho, Swazi,
Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy:
definition: age 15 and over can read and write
total population: 81 .8%
male: 81 .9%
female: 81 .7% (1 995 est.)
Population: no indigenous inhabitants
note: there is a small military garrison on South
Georgia, and the British Antarctic Survey has a
biological station on Bird Island; the South Sandwich
Islands are uninhabited','031588fb8273771169cec3381a6824aad01f03caf97dca2a590ee15553b4451b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10acf919e1806fb40318a6e99d8b88f89c047cd2d510f9299e8fa2c48ae9b495',1999,'PH','Philippines','people-and-society',971,'Population: no indigenous inhabitants
note: there are scattered garrisons occupied by
personnel of several claimant states','c7a8692bcdf9ca5388061686f850305e6cb4b33b8a049d1827621c3d9904e7fd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c43b91a8eeef9a63bc079a513fcc5ddd66e93a3f38d58edf825cfb24fed71c9d',1999,'LK','Sri Lanka','people-and-society',973,'Population: 19,144,875 (July 1999 est.)
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island; as of late 1996, 63,068 were
housed in refugee camps in south India, another
30,000-40,000 lived outside the Indian camps, and
more than 200,000 Tamils have sought political
asylum in the West
Age structure:
0-14 years: 27% (male 2,650,135; female 2,535,092)
15-64 years: 67% (male 6,231 ,987; female
6,500,782)
65 years and over: 6% (male 592,539; female
634,340) (1999 est.)
Population growth rate: 1.1% (1 999 est.)
Birth rate: 18.16 births/1,000 population (1999 est.)
Death rate: 6.02 deaths/1 ,000 population (1 999 est.)
Net migration rate: -1.13 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 16.12 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.67 years
mate: 69.89 years
female: 75.59 years (1 999 est.)
Total fertility rate: 2.1 children born/woman (1999
est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 69%, Hindu 15%, Christian 8%,
Muslim 8%
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%
note: English is commonly used in government and is
spoken by about 10% of the population
Literacy:
definition: age 1 5 and over can read and write
total population: 90.2%
male: 93.4%
female: 87.2% (1995 est.)','4a320994b345c0689777a757e8909d1214e0b45f41bf92e3e213e272b5380866','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ca63c1e362c0565db7ec59c8ea9a99ae766fed3aeff3b70af27447f7d8999b2',1999,'SD','Sudan','people-and-society',979,'Population: 34,475,690 (July 1999 est.)
Age structure:
0-14 years: 45% (male 7,941 ,909; female 7,614,225)
15-64 years: 53% (male 9,094,712; female
9,061,194)
65 years and over: 2% (male 423,389; female
340,261) (1999 est.)
Population growth rate: 2.71% (1999 est.)
Birth rate: 39.34 births/1,000 population (1999 est.)
Death rate: 1 0.6 deaths/1 ,000 population (1999 est.)
Net migration rate: -1 .68 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years:! male(s)/female
65 years and over: 1 .24 maie(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 70.94 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 56.4 years
male: 55.41 years
female: 57 .44 years (1999 est.)
Total fertility rate: 5.58 children born/woman (1999
est.)
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of Arabization in process
Literacy:
definition: age 15 and over can read and write
total population: 46.1%
male: 57.7%
female: 34.6% (1995 est.)','0d95634b2b17a4f860f29ed7e3bbc98c9d9a8280055b906d9570166fdce638f5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f4940621a9f597ad4f89adfb9e8d441f4a6b29c96b0127358625fa182b0cd06',1999,'GY','Guyana','people-and-society',987,'Population: 431,156 (July 1999 est.)
Age structure:
0-14 years: 33% (male 72,673; female 69,212)
15-64 years: 62% (male 135,573; female 130,700)
65 years and over: 5% (male 1 0,585; female 1 2,41 3)
(1999 est.)
Population growth rate: 0.71% (1999 est.)
Birth rate: 21 .75 births/1 ,000 population (1 999 est.)
Death rate: 5.75 deaths/1 ,000 population (1 999 est.)
Net migration rate: -8.92 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .03 male(s)/female (1999 est.)
Infant mortality rate: 26.52 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 70.89 years
male: 68.32 years
female: 73.59 years (1999 est.)
Total fertility rate: 2.55 children born/woman (1999
est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians”; their ancestors emigrated from
northern India in the latter part of the 19th century)
37%, Creole (mixed white and black) 31%, Javanese
15.3%, "Maroons" (their African ancestors were
brought to the country in the 17th and 18th centuries
as slaves and escaped to the interior) 10.3%,
Amerindian 2.6%, Chinese 1.7%, white 1%, other
1.1%
Religions: Hindu 27.4%, Muslim 19.6%, Roman
Catholic 22.8%, Protestant 25.2% (predominantly
Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely
spoken), Sranang Tongo (Surinamese, sometimes
called Taki-Taki, is native language of Creoles and
much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi),
Javanese
Literacy:
definition: age 15 and over can read and write
457
Suriname (continued)
total population: 93%
male: 95%
female: 91% (1995 est.)
I Government
Country name:
conventional long form: Republic of Suriname
conventional short form: Suriname
local long form: Republiek Suriname
local short form: Suriname
former: Netherlands Guiana, Dutch Guiana
Data code: NS
Government type: republic
Capital: Paramaribo
Administrative divisions: 10 districts (distrikten,
singular - distrikt); Brokopondo, Commewijne,
Coronie, Marowijne, Nickerie, Para, Paramaribo,
Saramacca, Sipaliwini, Wanica
Independence: 25 November 1975 (from
Netherlands)
National holiday: Independence Day, 25 November
(1975)
Constitution: ratified 30 September 1987
Legal system: based on Dutch legal system
incorporating French penal theory
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Jules WIJDENBOSCH (since
14 September 1996); Vice President Pretaapnarian
RADHAKISHUN (since 14 September 1996); note -
the president is both the chief of state and head of
Population: 2,503 (July 1999 est.)
Age structure:
0- 14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -3.55% (1 999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Ethnic groups: Russian and Ukrainian 62%,
Norwegian 38%, other NEGL% (1994)
Languages: Russian, Norwegian','cae982b369c50c5050341a434c7381eee63d3fff0032e8039367da26aceee089','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fa0b684923e9aad5e769c722e3b64bc1cadf1f1a48a12eae60408493d5e449',1999,'TJ','Tajikistan','people-and-society',992,'Population: 6,1 02,854 (July 1 999 est.)
Age structure:
0-14 years: 41% (male 1,250,344; female 1 ,224,355)
15-64 years: 55% (male 1 ,661 ,488; female
1,681,839)
65 years and over: 4% (male 122,065; female
162,763) (1999 est.)
Population growth rate: 1 .43% (1 999 est.)
Birth rate: 27.46 births/1,000 population (1999 est.)
Death rate: 7.85 deaths/1 ,000 population (1 999 est.)
Net migration rate: -5.34 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 ma!e(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0,75 ma!e(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 1 14.78 deaths/1 ,000 live
births (1999 est.)
Life expectancy at birth:
total population: 64.28 years
male: 61. 15 years
female: 67.57 years (1999 est.)
Total fertility rate: 3.48 children born/woman (1999
est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 31 ,270,820 (July 1999 est.)
Age structure:
0-14 years: 44% (male 6,926,149; female 6,967,416)
15-64 years: 53% (male 8,030,141 ; female
8,437,978)
65 years and over: 3% (male 41 5,074; female
494,062) (1999 est.)
Population growth rate: 2.14% (1999 est.)
Birth rate: 40.37 births/1,000 population (1999 est.)
Death rate: 1 6.75 deaths/1 ,000 population (1999
est.)
Net migration rate: -2.24 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
1 5-64 years: 0.95 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 95.27 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 46.17 years
male: 43.85 years
female: 48.57 years (1999 est.)
Total fertility rate: 5.4 children born/woman (1999
est.)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar - Arab, native African, mixed Arab and
native African
Religions: mainland - Christian 45%, Muslim 35%,
indigenous beliefs 20; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
473
Tanzania (continued)
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local languages
Literacy:
definition: age 1 5 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67 .8%
male: 79.4%
female: 56.8% (1995 est.)','13aada4f8748401452a1335bfef636440467f13f229dc611acfa8b4555585f2b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7dd5d6d8c25ef1c3511b3f68030c42a7ae5dc13d3aaf8f70a13baca7b175fa4',1999,'TH','Thailand','people-and-society',1000,'Population: 60,609,046 (July 1999 est.)
Age structure:
0-14 years: 24% (male 7,364,41 1 ; female 7,095,428)
15-64 years: 70% (male 20,878,602; female
21,493,735)
65 years and over: 6% (male 1 ,664,1 1 3; female
2,112,757) (1999 est.)
Population growth rate: 0.93% (1999 est.)
Birth rate: 16.46 births/1,000 population (1999 est.)
Death rate: 7.1 6 deaths/1 ,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/fema!e (1999 est.)
Infant mortality rate: 29.54 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 69.21 years
male: 65.58 years
female: 73.01 years (1999 est.)
Total fertility rate: 1 .82 children born/woman (1 999
est.)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.8%
male: 96%
female: 91 .6% (1 995 est.)','66de9524a4600262440bf8cbca9fff2499109b6792e6bc634be1e1193aa1a62f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2891c7628c99b70dcdadc1021e6e70c4bcc58812359125245104a95947927323',1999,'TG','Togo','people-and-society',1008,'Population: 5,081 ,41 3 (July 1 999 est.)
Age structure:
0-14 years: 48% (male 1,229,026; female 1,218,956)
15-64 years: 50% (male 1 ,223,371 ; female
1,299,519)
65 years and over: 2% (male 49,890; female 60,651 )
(1999 est.)
Population growth rate: 3.51% (1999 est.)
Birth rate: 44.78 births/1 ,000 population (1999 est.)
Death rate: 9.69 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 77.55 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 59.25 years
male: 56,93 years
female: 61 .64 years (1 999 est.)
Total fertility rate: 6.53 children born/woman (1999
est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian 20%,
Muslim 10%
Languages: French (official and the language of
478
Togo (continued)
commerce), Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
male: 67%
female: 37% (1995 est.)','3f0a875e4f9846f60d59ecdaf16fe1b0296b47f67e1a80381599bc3616d5b64c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db8f2ad4769b0daaeee901d115fcbc1e3298894142b12569e43307d83694a44',1999,'TK','Tokelau','people-and-society',1017,'Population: 1,471 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.92% (1999 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Tokelauan(s)
adjective: Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English','13347907ba3ef39692a0d7dcdc045ff5ee0e652111a000b44632e2e9c57adf7e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('947bfe73a4b133e6a6e4ba3cc03059e519cdb65dd7f5ed1a73e7d0c739ba71db',1999,'TV','Tuvalu','people-and-society',1024,'Population: 10,588 (July 1999 est.)
Age structure:
0-14 years: 35% (male 1,870; female 1,799)
15-64 years: 61% (male 3,062; female 3,360)
65 years and over: 4% (male 225; female 272) (1 999
est.)
Population growth rate: 1,34% (1999 est.)
Birthrate: 21.91 births/1 ,000 population (1999 est.)
Death rate: 8.5 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 ma!e(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 25.53 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 64.15 years
male: 63.01 years
female: 65,34 years (1999 est.)
Total fertility rate: 3.1 1 children born/woman (1999
est.)
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1.4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English
Literacy: NA; note - education is free and
compulsory from ages 6 through 13
Population: 22,804,973 (July 1999 est.)
Age structure:
0-14 years: 51% (male 5,857,254; female 5,820,526)
15-64 years: 47% (male 5,301 ,208; female
5,330,005)
65 years and over: 2% (male 239,434; female
256,546) (1999 est.)
Population growth rate: 2.83% (1999 est.)
Birth rate: 48.54 births/1,000 population (1999 est.)
Death rate: 18.43 deaths/1 ,000 population (1999
est.)
Net migration rate: -1 .84 migrant(s)/1 ,000
population (1999 est.)
note: according to the UNHCR, by the end of 1997,
Uganda was host to refugees from a number of
neighboring countries, including: Sudan 160,000,
Democratic Republic of the Congo 14,000, and
Rwanda 12,000
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 90.68 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 43.06 years
male: 42.2 years
female: 43.94 years (1999 est.)
Total fertility rate: 7.03 children born/woman (1999
est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Karamojong 12%,
Basogo 8%, Iteso 8%, Langi 6%, Rwanda 6%, Bagisu
5%, Acholi 4%, Lugbara 4%, Bunyoro 3%, Batobo 3%,
non-African (European, Asian, Arab) 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications and may be taught in school),
other Niger-Congo languages, Nilo-Saharan
languages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 61 .8%
male: 73.7%
female: 50.2% (1995 est.)','f944a6b2a6ac97a454d48a1153bcfacb59a9a0c3aa30929ccbb3e907ed4cd52b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('440195f862cc9bedb8278da43001e6fa5522eb2d8057e1ab75fe6e23bcec9190',1999,'AE','United Arab Emirates','people-and-society',1031,'Population: 2,344,402 (July 1999 est.)
note: includes 1,576,589 non-nationals (July 1999
est.)
Age structure:
0-14 years: 31% (male 368,844; female 353,183)
15-64 years: 67% (male 1 ,015,690; female 558,902)
65 years and over: 2% (male 32,935; female 1 4,848)
(1999 est.)
Population growth rate: 1.78% (1999 est.)
Birth rate: 18.86 births/1,000 population (1999 est.)
Death rate: 3.13 deaths/1 ,000 population (1 999 est.)
Net migration rate: 2.03 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 ma!e(s)/female
15-64 years: 1 .82 male(s)/female
65 years and over: 2.22 male(s)/female
total population: 1 .53 ma!e(s)/female (1 999 est.)
Infant mortality rate: 1 4,1 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.24 years
male: 73.83 years
female: 76.72 years (1999 est.)
Total fertility rate: 3.5 children born/woman (1999
est.)
Nationality:
noun: Emirian(s)
adjective: Emirian
Ethnic groups: Emiri 19%, other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write
total population: 79.2%
male: 78.9%
female: 79.8% (1995 est.)','75ab0ed1415c28231db60423cf1aa534994e44a5d0cee2e1e8cf699409880516','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f4b8fbad19e43e6a1b46b112987784f5597f3d2eccfe12550422957493549b2',1999,'UY','Uruguay','people-and-society',1041,'Population: 3,308,523 (July 1999 est.)
Age structure:
0-14 years: 24% (male 407,990; female 388,293)
15-64 years: 63% (male 1 ,026,554; female
1,054,513)
65 years and over: 1 3% (male 1 79,331 ; female
251,842) (1999 est.)
Population growth rate: 0.73% (1999 est.)
Birth rate: 1 6.84 births/1 ,000 population (1 999 est.)
Death rate: 8.81 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.78 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
af birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 1 3.49 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 75.83 years
male: 72.69 years
female: 79.1 5 years (1999 est.)
Total fertility rate: 2.27 children born/woman (1999
est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than one-half
of the adult population attends church regularly),
Protestant 2%, Jewish 2%, nonprofessing or other
30%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
female: 97.7% (1995 est.)
511
Uruguay (continued)
Population: 24,102,473 (July 1999 est.)
Age structure:
0-14 years: 37% (male 4,556,973; female 4,413,617)
15-64 years: 58% (male 6,938,090; female
7,068,839)
65 years and over: 5% (male 443,604; female
681,350) (1999 est.)
Population growth rate: 1,32% (1999 est.)
Birth rate: 23.43 births/1 ,000 population (1999 est.)
Death rate: 7.75 deaths/1 ,000 population (1 999 est.)
Net migration rate: -2.44 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.98 ma!e(s)/female (1999 est.)
Infant mortality rate: 71 .58 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 63.91 years
male: 60.29 years
female: 67.71 years (1999 est.)
Total fertility rate: 2.82 children born/woman (1999
est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistan!
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1 .5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1996)','ae29de5202fedd9917956376ff7738e26bd0406866584ff0857507536f56ddb3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa4af56da8fc4315dcabaccdb29d542163890f575620ac8f59750ec842c6a02e',1999,'VU','Vanuatu','people-and-society',1050,'Population: 189,036 (July 1999 est.)
Age structure:
0-14 years: 39% (male 37,040; female 35,760)
15-64 years : 58% (male 56,649; female 53,799)
65 years and over: 3% (male 3,1 25; female 2,663)
(1999 est.)
Population growth rate: 2.02% (1999 est.)
Birth rate: 28.49 births/1,000 population (1999 est.)
Death rate: 8.26 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1.17 male(s)/female
total population: 1 .05 male(s)/femaie (1999 est.)
Infant mortality rate: 59.58 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 61 .44 years
male: 59,41 years
female: 63.57 years (1999 est.)
Total fertility rate: 3.61 children born/woman (1999
est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 94%,
French 4%, Vietnamese, Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%,
Catholic 15%, indigenous beliefs 7.6%, Seventh-Day
Adventist 6.2%, Church of Christ 3.8%, other 15.7%
Languages: English (official), French (official),
pidgin (known as Bislama or Bichelama)
516
Vanuatu (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 53%
male: 57%
female: 48% (1979 est.)
Population: 23,203,466 (July 1999 est.)
Age structure:
0-14 years: 33% (male 3,988,499; female 3,741 ,568)
15-64 years: 62% (male 7,231 ,546; female
7,184,769)
65 years and over: 5% (male 484,071 ; female
573,013) (1999 est.)
Population growth rate: 1.71% (1999 est.)
Birth rate: 22.25 births/1,000 population (1999 est.)
Death rate: 4.93 deaths/1 ,000 population (1999 est.)
Net migration rate: -0.23 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .02 male(s)/female (1999 est.)
Infant mortality rate: 26.51 deaths/1,000 live births
(1999 est.)
Life expectancy at birth:
total population: 72.95 years
male: 69.97 years
female: 76.16 years (1999 est.)
Total fertility rate: 2.61 children born/woman (1999
est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions: nominally Roman Catholic 96%,
Protestant 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 91 .1%
male: 91 .8%
female: 90.3% (1995 est.)
518
Venezuela (continued)
Population: 77,31 1 ,21 0 (July 1 999 est.)
Age structure:
0-14 years: 34% (male 13,377,315; female
12,603,906)
15-64 years: 61% (male 22,934,553; female
24,277,488)
65 years and over: 5% (male 1 ,645,288; female
2,472,660) (1999 est.)
Population growth rate: 1 .37% (1 999 est.)
Birth rate: 20.78 births/1,000 population (1999 est.)
Death rate: 6.56 deaths/1 ,000 population (1 999 est.)
Net migration rate: -0.53 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 34.84 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 68.1 years
male: 65.71 years
female: 70.64 years (1999 est.)
Total fertility rate: 2.41 children born/woman (1999
est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese 3%,
Muong, Tai, Meo, Khmer, Man, Cham
Religions: Buddhist, Taoist, Roman Catholic,
indigenous beliefs, Islam, Protestant, Cao Dai, Hoa
Hao
Languages: Vietnamese (official), Chinese, English,
French, Khmer, tribal languages (Mon-Khmer and
Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
female: 91 .2% (1995 est.)','499d640abe368480ef088981313b1fb8411962ef0bb0a6ac75869d77e282253d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a0ccc6ccdcc235e48a027ff91d3f4e4e77b29a2f10d2386cc37b647b31c4937',1999,'PR','Puerto Rico','people-and-society',1056,'Population: 1 1 9,827 (July 1 999 est.)
note: West Indian (45% born in the Virgin Islands and
29% born elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Age structure:
0-14 years: 28% (male 17,454; female 16,585)
15-64 years: 63% (male 34,71 2; female 41 ,325)
65 years and over: 9% (male 4,237; female 5,514)
(1999 est.)
Population growth rate: 1.19% (1999 est.)
Birth rate: 1 7.08 births/1 ,000 population (1 999 est.)
Death rate: 5.34 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0.13 migrant(s)/1, 000
population (1999 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.84 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.89 male(s)/female (1999 est.)
Infant mortality rate: 10.07 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 77.74 years
male: 74.04 years
female: 81 .67 years (1999 est.)
Total fertility rate: 2.42 children born/woman (1999
est.)
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic groups: black 80%, white 15%, other 5%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy: NA','b868c161da5958fdb05ba582ff211d11f76fe4a880dc376beab47b385537b1ac','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7d9d5f1c7ddafa5e325ac3f120c80bcf2c06e6abfa72fc2c64927b17af6ac5',1999,'MP','Northern Mariana Islands','people-and-society',1062,'Population: no indigenous inhabitants
note: US military personnel have left the island, but
some civilian personnel remain (1999 est.)','d57ddbc179b84bc7b9fecf2415429ff8c7352248e9a70354c76de27b4e50bcef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2622ae6f8fef77ce8db74afe24bae3bb8a408cd7a36e5fd3dd71852c0846ad',1999,'YE','Yemen','people-and-society',1064,'Population: 16,942,230 (July 1999 est.)
Age structure:
0-14years: 48% (male 4,1 18,292; female 3,971,886)
15-64 years: 49% (male 4,243,809; female
4,065,429)
65 years and over: 3% (male 278,1 33; female
264,681) (1999 est.)
Population growth rate: 3.34% (1999 est.)
Birth rate: 43.31 births/1 ,000 population (1999 est.)
Death rate: 9.88 deaths/1 ,000 population (1 999 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1999 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1 .05 male(s)/female
total population: 1 .04 male(s)/female (1999 est.)
Infant mortality rate: 69.82 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 59.98 years
male: 58.17 years
female: 61 .88 years (1999 est.)
Total fertility rate: 7.06 children born/woman (1999
est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; Afro-Arab
concentrations in western coastal locations; South
Asians in southern regions; small European
communities in major metropolitan areas
Religions: Muslim including Shaf''i (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
532
Yemen (continued)
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)','4c792b91662378e41013cae0dfa85932ac130fd21e64f768cb7304b6ffdc1414','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4041a2435a121dcf8bbbbdd6482b36e544bcc40919f87e9a9769942b6c3c428d',1999,'ZM','Zambia','people-and-society',1073,'Population: 9,663,535 (July 1999 est.)
Age structure:
0-14 years: 49% (male 2,381 ,937; female 2,355,807)
15-64 years: 49% (male 2,308,71 5; female
2,379,994)
65 years and over: 2% (male 1 07,427 ; female
129,655) (1999 est.)
Population growth rate: 2.12% (1999 est.)
Birth rate: 44.51 births/1,000 population (1999 est.)
Death rate: 22.56 deaths/1,000 population (1999
est.)
Net migration rate: -0.78 migrant(s)/1 ,000
population (1999 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.99 male(s)/female (1 999 est.)
Infant mortality rate: 91 .85 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 36.96 years
male: 36.72 years
female: 37.21 years (1999 est.)
Total fertility rate: 6.35 children born/woman (1999
est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 1 5 and over can read and write English
total population: 78.2%
male: 85.6%
female: 71 .3% (1995 est.)','702bf0d3c0220a8685b6a5ccf9ba546c52a85fe888e184a31c1aac5ec71c086d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea1fa2ffdf245fdc3ef0bd92242f6cddcb846742abf8601ed4c82f6e277d6403',1999,'ZW','Zimbabwe','people-and-society',1079,'Population: 11,163,160 (July 1999 est.)
Age structure:
0-14 years: 43% (male 2,432,785; female 2,389,029)
15-64 years: 54% (male 2,986,531 ; female
3,059,186)
65 years and over: 3% (male 1 32,532; female
163,097) (1999 est.)
Population growth rate: 1.02% (1999 est.)
Birth rate: 30.64 births/1 ,000 population (1999 est.)
Death rate: 20.43 deaths/1 ,000 population (1999
est.)
Net migration rate: NA migrant(s)/1 ,000 population
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 maie(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 61 .21 deaths/1 ,000 live births
(1999 est.)
Life expectancy at birth:
total population: 38.86 years
male: 38.77 years
female: 38.94 years (1999 est.)
Total fertility rate: 3.71 children born/woman (1999
est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 71%, Ndebele
16%, other 11%), white 1%, mixed and Asian 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 1 5 and over can read and write English
total population: 85%
male: 90%
female: 80% (1995 est.)','f46aadf6a102a8ed2c63c4ef263e616b2752f6ec43e8988ff338f0cb108a2e13','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b310e5539f54dc5004207c8a89ec446c98b571f3ee2dc3d1f6153f4ddd23cc9',1999,'ZW','Zimbabwe','people-and-society',8,'Population: 25,824,882 (July 1999 est.)
Age structure:
0-14 years: 43% (male 5,640,841; female 5,422,460)
15-64 years: 54% (male 7,273,681; female 6,776,750)
65 years and over: 3% (male 374,666; female 336,484) (1999 est.)
Population growth rate: 3.95% (1999 est.)
note: this rate reflects the continued return of refugees
Birth rate: 41.93 births/1,000 population (1999 est.)
Death rate: 17.02 deaths/1,000 population (1999 est.)
Net migration rate: 14.62 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 140.55 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 47.33 years
male: 47.82 years
female: 46.82 years (1999 est.)
Total fertility rate: 5.94 children born/woman (1999 est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%,
minor ethnic groups (Aimaks, Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic
languages (primarily Uzbek and Turkmen) 11%, 30 minor languages
(primarily Balochi and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31.5%
male: 47.2%
female: 15% (1995 est.)
Population: 3,364,571 (July 1999 est.)
Age structure:
0-14 years: 33% (male 568,642; female 530,088)
15-64 years: 61% (male 957,561; female 1,105,870)
65 years and over: 6% (male 84,280; female 118,130) (1999 est.)
Population growth rate: 1.05% (1999 est.)
Birth rate: 20.74 births/1,000 population (1999 est.)
Death rate: 7.35 deaths/1,000 population (1999 est.)
Net migration rate: -2.93 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.87 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 42.9 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69 years
male: 65.92 years
female: 72.33 years (1999 est.)
Total fertility rate: 2.5 children born/woman (1999 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2% (Vlachs,
Gypsies, Serbs, and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population ranged from
1% (official Albanian statistics) to 12% (from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%, Roman Catholic 10%
note: all mosques and churches were closed in 1967 and religious
observances prohibited; in November 1990, Albania began allowing
private religious practice
Languages: Albanian (Tosk is the official dialect), Greek
Literacy:
definition: age 9 and over can read and write
total population: 93%
male: NA%
female: NA% (1997 est.)
Population: 31,133,486 (July 1999 est.)
Age structure:
0-14 years: 37% (male 5,911,910; female 5,696,538)
15-64 years: 59% (male 9,255,702; female 9,063,954)
65 years and over: 4% (male 559,570; female 645,812) (1999 est.)
Population growth rate: 2.1% (1999 est.)
Birth rate: 27 births/1,000 population (1999 est.)
Death rate: 5.52 deaths/1,000 population (1999 est.)
Net migration rate: -0.49 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 43.82 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.24 years
male: 68.07 years
female: 70.46 years (1999 est.)
Total fertility rate: 3.27 children born/woman (1999 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less than 1%
Religions: Sunni Muslim (state religion) 99%, Christian and
Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 61.6%
male: 73.9%
female: 49% (1995 est.)','cf71da3041fe9e07f7b283f789035780e22a843fe8fa1ec64d25d2ee6e5703b9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86cf06c483db42908c0d78719d5670583564c04feeb2449b9435e2021c1bde46',1999,'LY','Libya','people-and-society',16,'Population: 63,786 (July 1999 est.)
Age structure:
0-14 years: 39% (male 12,840; female 12,074)
15-64 years: 56% (male 17,933; female 18,035)
65 years and over: 5% (male 1,494; female 1,410) (1999 est.)
Population growth rate: 2.64% (1999 est.)
Birth rate: 26.53 births/1,000 population (1999 est.)
Death rate: 4.04 deaths/1,000 population (1999 est.)
Net migration rate: 3.92 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1.06 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 10.19 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.46 years
male: 71.23 years
female: 79.95 years (1999 est.)
Total fertility rate: 3.66 children born/woman (1999 est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%, Caucasian 2%, Tongan 4%,
other 5%
Religions: Christian Congregationalist 50%, Roman Catholic 20%,
Protestant denominations and other 30%
Languages: Samoan (closely related to Hawaiian and other
Polynesian languages), English
note: most people are bilingual
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
Population: 65,939 (July 1999 est.)
Age structure:
0-14 years: 14% (male 4,880; female 4,527)
15-64 years: 73% (male 25,811; female 22,444)
65 years and over: 13% (male 4,196; female 4,081) (1999 est.)
Population growth rate: 2.24% (1999 est.)
Birth rate: 10.27 births/1,000 population (1999 est.)
Death rate: 5.46 deaths/1,000 population (1999 est.)
Net migration rate: 17.61 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 1.03 male(s)/female
total population: 1.12 male(s)/female (1999 est.)
Infant mortality rate: 4.08 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 83.46 years
male: 80.55 years
female: 86.55 years (1999 est.)
Total fertility rate: 1.25 children born/woman (1999 est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 61%, Andorran 30%, French 6%, other 3%
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy: NA
Population: 11,177,537 (July 1999 est.)
Age structure:
0-14 years: 45% (male 2,545,006; female 2,473,732)
15-64 years: 52% (male 2,938,178; female 2,909,844)
65 years and over: 3% (male 143,074; female 167,703) (1999 est.)
Population growth rate: 2.84% (1999 est.)
Birth rate: 43.11 births/1,000 population (1999 est.)
Death rate: 16.35 deaths/1,000 population (1999 est.)
Net migration rate: 1.6 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 129.19 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 48.39 years
male: 46.08 years
female: 50.82 years (1999 est.)
Total fertility rate: 6.12 children born/woman (1999 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico
(mixed European and Native African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant
15% (1998 est.)
Languages: Portuguese (official), Bantu and other African
languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1998 est.)
Population: 11,510 (July 1999 est.)
Age structure:
0-14 years: 27% (male 1,581; female 1,529)
15-64 years: 66% (male 3,874; female 3,695)
65 years and over: 7% (male 366; female 465) (1999 est.)
Population growth rate: 3.16% (1999 est.)
Birth rate: 16.68 births/1,000 population (1999 est.)
Death rate: 5.3 deaths/1,000 population (1999 est.)
Net migration rate: 20.24 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 18.72 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.71 years
male: 74.72 years
female: 80.78 years (1999 est.)
Total fertility rate: 1.95 children born/woman (1999 est.)
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%, Seventh-Day Adventist 7%,
Baptist 5%, Roman Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)
Population: no indigenous inhabitants, but there are seasonally
staffed research stations
note: approximately 29 nations, all signatory to the Antarctic
Treaty, send personnel to perform seasonal (summer) and year-round
research on the continent and in its surrounding oceans; the
population of persons doing and supporting science on the continent
and its nearby islands south of 60 degrees south latitude (the
region covered by the Antarctic Treaty) varies from approximately
4,000 in summer to 1,000 in winter; in addition, approximately 1,000
personnel including ship''s crew and scientists doing onboard
research are present in the waters of the treaty region; Summer
(January) population--3,687 total; Argentina 302, Australia 201,
Belgium 13, Brazil 80, Bulgaria 16, Chile 352, China 70, Finland 11,
France 100, Germany 51, India 60, Italy 106, Japan 136, South Korea
14, Netherlands 10, NZ 60, Norway 40, Peru 28, Poland 70, Russia
254, South Africa 80, Spain 43, Sweden 20, UK 192, US 1,378
(1998-99); Winter (July) population--964 total; Argentina 165,
Australia 75, Brazil 12, Chile 129, China 33, France 33, Germany 9,
India 25, Japan 40, South Korea 14, NZ 10, Poland 20, Russia 102,
South Africa 10, UK 39, US 248 (1998-99); year-round stations--42
total; Argentina 6, Australia 4, Brazil 1, Chile 4, China 2, Finland
1, France 1, Germany 1, India 1, Italy 1, Japan 1, South Korea 1, NZ
1, Norway 1, Poland 1, Russia 6, South Africa 1, Spain 1, Ukraine 1,
UK 2, US 3, Uruguay 1 (1998-99); Summer-only stations--32 total;
Argentina 3, Australia 4, Bulgaria 1, Chile 7, Germany 1, India 1,
Japan 3, NZ 1, Peru 1, Russia 3, Sweden 2, UK 5 (1998-99) in
addition, during the austral summer some nations have numerous
occupied locations such as tent camps, summer-long temporary
facilities, and mobile traverses in support of research
Population: 64,246 (July 1999 est.)
Age structure:
0-14 years: 26% (male 8,414; female 8,137)
15-64 years: 69% (male 21,936; female 22,227)
65 years and over: 5% (male 1,504; female 2,028) (1999 est.)
Population growth rate: 0.36% (1999 est.)
Birth rate: 16.22 births/1,000 population (1999 est.)
Death rate: 5.76 deaths/1,000 population (1999 est.)
Net migration rate: -6.9 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 20.69 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.46 years
male: 69.06 years
female: 73.98 years (1999 est.)
Total fertility rate: 1.72 children born/woman (1999 est.)
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese, Lebanese, Syrian
Religions: Anglican (predominant), other Protestant sects, some
Roman Catholic
Languages: English (official), local dialects
Literacy:
definition: age 15 and over has completed five or more years of
schooling
total population: 89%
male: 90%
female: 88% (1960 est.)
Population: 36,737,664 (July 1999 est.)
Age structure:
0-14 years: 27% (male 5,124,087; female 4,932,060)
15-64 years: 62% (male 11,457,399; female 11,469,346)
65 years and over: 11% (male 1,553,158; female 2,201,614) (1999 est.)
Population growth rate: 1.29% (1999 est.)
Birth rate: 19.91 births/1,000 population (1999 est.)
Death rate: 7.64 deaths/1,000 population (1999 est.)
Net migration rate: 0.65 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 18.41 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.76 years
male: 71.13 years
female: 78.56 years (1999 est.)
Total fertility rate: 2.66 children born/woman (1999 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white 85%, mestizo, Amerindian, or other nonwhite
groups 15%
Religions: nominally Roman Catholic 90% (less than 20%
practicing), Protestant 2%, Jewish 2%, other 6%
Languages: Spanish (official), English, Italian, German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
female: 96.2% (1995 est.)
Population: 3,409,234 (July 1999 est.)
Age structure:
0-14 years: 25% (male 442,117; female 425,561)
15-64 years: 66% (male 1,100,334; female 1,148,595)
65 years and over: 9% (male 122,170; female 170,457) (1999 est.)
Population growth rate: -0.38% (1999 est.)
Birth rate: 13.53 births/1,000 population (1999 est.)
Death rate: 9.03 deaths/1,000 population (1999 est.)
Net migration rate: -8.26 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 41.12 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.56 years
male: 62.21 years
female: 71.13 years (1999 est.)
Total fertility rate: 1.68 children born/woman (1999 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian 2%, other (mostly
Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had emigrated from','cb6d32c7497cd139775d8d30e62990b356036126019e08d243766865092eb3d9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04103804b60eeed65f2c197a82aad46ff874a55421628aa301c441d9506874a2',1999,'AM','Armenia','people-and-society',24,'Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
Population: 68,675 (July 1999 est.)
Age structure:
0-14 years: 22% (male 7,724; female 7,106)
15-64 years: 69% (male 22,723; female 24,747)
65 years and over: 9% (male 2,623; female 3,752) (1999 est.)
Population growth rate: 0.55% (1999 est.)
Birth rate: 13.28 births/1,000 population (1999 est.)
Death rate: 6.48 deaths/1,000 population (1999 est.)
Net migration rate: -1.31 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.09 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 7.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.04 years
male: 73.33 years
female: 80.94 years (1999 est.)
Total fertility rate: 1.8 children born/woman (1999 est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic groups: mixed white/Caribbean Amerindian 80%
Religions: Roman Catholic 82%, Protestant 8%, Hindu, Muslim,
Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish, Portuguese,
Dutch, English dialect), English (widely spoken), Spanish
Literacy: NA
Population: no indigenous inhabitants
note: there are only seasonal caretakers
Population: 18,783,551 (July 1999 est.)
Age structure:
0-14 years: 21% (male 2,023,569; female 1,926,901)
15-64 years: 66% (male 6,317,045; female 6,172,735)
65 years and over: 13% (male 1,022,485; female 1,320,816) (1999 est.)
Population growth rate: 0.9% (1999 est.)
Birth rate: 13.21 births/1,000 population (1999 est.)
Death rate: 6.9 deaths/1,000 population (1999 est.)
Net migration rate: 2.66 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 5.11 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 80.14 years
male: 77.22 years
female: 83.23 years (1999 est.)
Total fertility rate: 1.81 children born/woman (1999 est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%, aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%, other Christian
24.3%, non-Christian 11%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)
Population: 8,139,299 (July 1999 est.)
Age structure:
0-14 years: 17% (male 702,261; female 666,310)
15-64 years: 68% (male 2,792,484; female 2,713,397)
65 years and over: 15% (male 478,071; female 786,776) (1999 est.)
Population growth rate: 0.09% (1999 est.)
Birth rate: 9.62 births/1,000 population (1999 est.)
Death rate: 10.04 deaths/1,000 population (1999 est.)
Net migration rate: 1.32 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 5.1 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.48 years
male: 74.31 years
female: 80.82 years (1999 est.)
Total fertility rate: 1.37 children born/woman (1999 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 99.4%, Croatian 0.3%, Slovene 0.2%, other
0.1%
Religions: Roman Catholic 78%, Protestant 5%, other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1974 est.)
male: NA%
female: NA%
Population: 7,908,224 (July 1999 est.)
Age structure:
0-14 years: 32% (male 1,292,018; female 1,240,745)
15-64 years: 61% (male 2,361,792; female 2,496,721)
65 years and over: 7% (male 202,755; female 314,193) (1999 est.)
Population growth rate: 0.63% (1999 est.)
Birth rate: 21.58 births/1,000 population (1999 est.)
Death rate: 9.5 deaths/1,000 population (1999 est.)
Net migration rate: -5.76 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 82.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63.08 years
male: 58.76 years
female: 67.63 years (1999 est.)
Total fertility rate: 2.67 children born/woman (1999 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani Peoples 3.2%, Russian 2.5%,
Armenian 2%, other 2.3% (1998 est.)
note: almost all Armenians live in the separatist Nagorno-Karabakh
region
Religions: Muslim 93.4%, Russian Orthodox 2.5%, Armenian Orthodox
2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much lower
Languages: Azeri 89%, Russian 3%, Armenian 2%, other 6% (1995
est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 283,705 (July 1999 est.)
Age structure:
0-14 years: 27% (male 39,271; female 38,740)
15-64 years: 67% (male 92,830; female 96,814)
65 years and over: 6% (male 6,696; female 9,354) (1999 est.)
Population growth rate: 1.36% (1999 est.)
Birth rate: 20.58 births/1,000 population (1999 est.)
Death rate: 5.43 deaths/1,000 population (1999 est.)
Net migration rate: -1.55 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 18.38 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.25 years
male: 70.94 years
female: 77.64 years (1999 est.)
Total fertility rate: 2.31 children born/woman (1999 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 15%
Religions: Baptist 32%, Anglican 20%, Roman Catholic 19%,
Methodist 6%, Church of God 6%, other Protestant 12%, none or
unknown 3%, other 2%
Languages: English, Creole (among Haitian immigrants)
Literacy:
definition: age 15 and over can read and write
total population: 98.2%
male: 98.5%
female: 98% (1995 est.)','fdb71fc09e3bb4e1bf56222aa8830308481521f5b66f8f8218da26eab003bd36','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8dd79cc1ff39757fa084692fd3f33222147c67a574877f3bf7721bd637a61e9',1999,'SA','Saudi Arabia','people-and-society',34,'Population: 629,090 (July 1999 est.)
note: includes 227,801 non-nationals (July 1999 est.)
Age structure:
0-14 years: 31% (male 97,316; female 94,708)
15-64 years: 67% (male 249,594; female 169,337)
65 years and over: 2% (male 9,241; female 8,894) (1999 est.)
Population growth rate: 2% (1999 est.)
Birth rate: 21.86 births/1,000 population (1999 est.)
Death rate: 3.24 deaths/1,000 population (1999 est.)
Net migration rate: 1.42 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.47 male(s)/female
65 years and over: 1.04 male(s)/female
total population: 1.3 male(s)/female (1999 est.)
Infant mortality rate: 14.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.32 years
male: 72.75 years
female: 77.96 years (1999 est.)
Total fertility rate: 2.97 children born/woman (1999 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 13%, other Arab 10%, Iranian
8%, other 6%
Religions: Shi''a Muslim 75%, Sunni Muslim 25%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 15 and over can read and write
total population: 85.2%
male: 89.1%
female: 79.4% (1995 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after Japanese air and
naval attacks during World War II; occupied by US military during
World War II, but abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service only and
generally restricted to scientists and educators; a cemetery and
remnants of structures from early settlement are located near the
middle of the west coast; visited annually by US Fish and Wildlife
Service
Population: 127,117,967 (July 1999 est.)
Age structure:
0-14 years: 38% (male 24,516,722; female 23,346,904)
15-64 years: 59% (male 38,441,064; female 36,586,743)
65 years and over: 3% (male 2,303,613; female 1,922,921) (1999 est.)
Population growth rate: 1.59% (1999 est.)
Birth rate: 25.2 births/1,000 population (1999 est.)
Death rate: 8.5 deaths/1,000 population (1999 est.)
Net migration rate: -0.79 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.2 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 69.68 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 60.6 years
male: 60.73 years
female: 60.46 years (1999 est.)
Total fertility rate: 2.86 children born/woman (1999 est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladesh
Ethnic groups: Bengali 98%, Biharis 250,000, tribals less than 1
million
Religions: Muslim 88.3%, Hindu 10.5%, other 1.2%
Languages: Bangla (official), English
Literacy:
definition: age 15 and over can read and write
total population: 38.1%
male: 49.4%
female: 26.1% (1995 est.)
Population: 259,191 (July 1999 est.)
Age structure:
0-14 years: 23% (male 30,132; female 29,359)
15-64 years: 67% (male 85,437; female 88,131)
65 years and over: 10% (male 9,862; female 16,270) (1999 est.)
Population growth rate: 0.04% (1999 est.)
Birth rate: 14.46 births/1,000 population (1999 est.)
Death rate: 8.16 deaths/1,000 population (1999 est.)
Net migration rate: -5.86 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 16.74 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.98 years
male: 72.22 years
female: 77.81 years (1999 est.)
Total fertility rate: 1.83 children born/woman (1999 est.)
Nationality:
noun: Barbadian(s)
adjective: Barbadian
Ethnic groups: black 80%, white 4%, other 16%
Religions: Protestant 67% (Anglican 40%, Pentecostal 8%,
Methodist 7%, other 12%), Roman Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97.4%
male: 98%
female: 96.8% (1995 est.)
Population: uninhabited
Population: 10,401,784 (July 1999 est.)
Age structure:
0-14 years: 19% (male 1,027,974; female 985,342)
15-64 years: 67% (male 3,390,552; female 3,591,245)
65 years and over: 14% (male 463,369; female 943,302) (1999 est.)
Population growth rate: -0.09% (1999 est.)
Birth rate: 9.7 births/1,000 population (1999 est.)
Death rate: 13.71 deaths/1,000 population (1999 est.)
Net migration rate: 3.13 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.49 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 14.39 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.13 years
male: 62.04 years
female: 74.52 years (1999 est.)
Total fertility rate: 1.32 children born/woman (1999 est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Byelorussian 77.9%, Russian 13.2%, Polish 4.1%,
Ukrainian 2.9%, other 1.9%
Religions: Eastern Orthodox 80%, other (including Roman Catholic,
Protestant, Jewish, and Muslim) 20% (1997 est.)
Languages: Byelorussian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 10,182,034 (July 1999 est.)
Age structure:
0-14 years: 17% (male 895,987; female 853,494)
15-64 years: 66% (male 3,389,572; female 3,318,266)
65 years and over: 17% (male 703,933; female 1,020,782) (1999 est.)
Population growth rate: 0.06% (1999 est.)
Birth rate: 9.98 births/1,000 population (1999 est.)
Death rate: 10.43 deaths/1,000 population (1999 est.)
Net migration rate: 1.01 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 6.17 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.53 years
male: 74.31 years
female: 80.9 years (1999 est.)
Total fertility rate: 1.49 children born/woman (1999 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 55%, Walloon 33%, mixed or other 12%
Religions: Roman Catholic 75%, Protestant or other 25%
Languages: Flemish 56%, French 32%, German 1%, legally bilingual
11%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 235,789 (July 1999 est.)
Age structure:
0-14 years: 42% (male 49,991; female 48,074)
15-64 years: 55% (male 65,507; female 63,796)
65 years and over: 3% (male 4,129; female 4,292) (1999 est.)
Population growth rate: 2.42% (1999 est.)
Birth rate: 30.22 births/1,000 population (1999 est.)
Death rate: 5.39 deaths/1,000 population (1999 est.)
Net migration rate: -0.67 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 31.57 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.2 years
male: 67.23 years
female: 71.26 years (1999 est.)
Total fertility rate: 3.74 children born/woman (1999 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 44%, Creole 30%, Maya 11%, Garifuna 7%,
other 8%
Religions: Roman Catholic 62%, Protestant 30% (Anglican 12%,
Methodist 6%, Mennonite 4%, Seventh-Day Adventist 3%, Pentecostal
2%, Jehovah''s Witnesses 1%, other 2%), none 2%, other 6% (1980)
Languages: English (official), Spanish, Mayan, Garifuna (Carib)
Literacy:
definition: age 14 and over has ever attended school
total population: 70.3%
male: 70.3%
female: 70.3% (1991 est.)
note: other sources list the literacy rate as high as 75%
Population: 6,305,567 (July 1999 est.)
Age structure:
0-14 years: 48% (male 1,510,703; female 1,501,437)
15-64 years: 50% (male 1,511,114; female 1,637,155)
65 years and over: 2% (male 62,459; female 82,699) (1999 est.)
Population growth rate: 3.3% (1999 est.)
Birth rate: 45.37 births/1,000 population (1999 est.)
Death rate: 12.4 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 97.76 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.08 years
male: 51.98 years
female: 56.24 years (1999 est.)
Total fertility rate: 6.4 children born/woman (1999 est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most important
being Fon, Adja, Yoruba, Bariba), Europeans 5,500
Religions: indigenous beliefs 70%, Muslim 15%, Christian 15%
Languages: French (official), Fon and Yoruba (most common
vernaculars in south), tribal languages (at least six major ones in
north)
Literacy:
definition: age 15 and over can read and write
total population: 37%
male: 48.7%
female: 25.8% (1995 est.)
Population: 62,472 (July 1999 est.)
Age structure:
0-14 years: 20% (male 6,174; female 6,023)
15-64 years: 70% (male 21,479; female 22,041)
65 years and over: 10% (male 2,897; female 3,858) (1999 est.)
Population growth rate: 0.72% (1999 est.)
Birth rate: 11.83 births/1,000 population (1999 est.)
Death rate: 7.27 deaths/1,000 population (1999 est.)
Net migration rate: 2.67 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 9.27 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.97 years
male: 75.19 years
female: 78.83 years (1999 est.)
Total fertility rate: 1.71 children born/woman (1999 est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 61%, white and other 39%
Religions: Anglican 28%, Roman Catholic 15%, African Methodist
Episcopal (Zion) 12%, Seventh-Day Adventist 6%, Methodist 5%, other
34% (1991)
Languages: English (official), Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1970 est.)
Population: 1,951,965 (July 1999 est.)
note: other estimates range as low as 600,000
Age structure:
0-14 years: 40% (male 405,745; female 376,738)
15-64 years: 56% (male 561,754; female 530,420)
65 years and over: 4% (male 39,251; female 38,057) (1999 est.)
Population growth rate: 2.25% (1999 est.)
Birth rate: 36.76 births/1,000 population (1999 est.)
Death rate: 14.26 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.03 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 109.33 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 52.75 years
male: 53.19 years
female: 52.29 years (1999 est.)
Total fertility rate: 5.16 children born/woman (1999 est.)
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%, indigenous or
migrant tribes 15%
Religions: Lamaistic Buddhism 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak various Tibetan
dialects, Nepalese speak various Nepalese dialects
Literacy:
definition: age 15 and over can read and write
total population: 42.2%
male: 56.2%
female: 28.1% (1995 est.)
People--note: refugee issue over the presence in Nepal of
approximately 91,000 Bhutanese refugees, 90% of whom are in seven
United Nations Office of the High Commissioner for Refugees (UNHCR)
camps
Population: 7,982,850 (July 1999 est.)
Age structure:
0-14 years: 39% (male 1,573,391; female 1,540,123)
15-64 years: 56% (male 2,199,077; female 2,307,490)
65 years and over: 5% (male 164,213; female 198,556) (1999 est.)
Population growth rate: 1.96% (1999 est.)
Birth rate: 30.72 births/1,000 population (1999 est.)
Death rate: 9.61 deaths/1,000 population (1999 est.)
Net migration rate: -1.5 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 62.02 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 61.43 years
male: 58.51 years
female: 64.51 years (1999 est.)
Total fertility rate: 3.93 children born/woman (1999 est.)
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, Aymara 25%, mestizo (mixed white and
Amerindian ancestry) 30%, white 15%
Religions: Roman Catholic 95%, Protestant (Evangelical Methodist)
Languages: Spanish (official), Quechua (official), Aymara
(official)
Literacy:
definition: age 15 and over can read and write
total population: 83.1%
male: 90.5%
female: 76% (1995 est.)
Population: 723,542 (July 1999 est.)
Age structure:
0-14 years: 27% (male 99,232; female 95,421)
15-64 years: 71% (male 367,213; female 145,925)
65 years and over: 2% (male 11,047; female 4,704) (1999 est.)
Population growth rate: 3.62% (1999 est.)
Birth rate: 16.75 births/1,000 population (1999 est.)
Death rate: 3.57 deaths/1,000 population (1999 est.)
Net migration rate: 23.03 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 2.52 male(s)/female
65 years and over: 2.35 male(s)/female
total population: 1.94 male(s)/female (1999 est.)
Infant mortality rate: 17.25 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.23 years
male: 71.7 years
female: 76.89 years (1999 est.)
Total fertility rate: 3.42 children born/woman (1999 est.)
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic groups: Arab 40%, Pakistani 18%, Indian 18%, Iranian 10%,
other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly used as a second
language
Literacy:
definition: age 15 and over can read and write
total population: 79.4%
male: 79.2%
female: 79.9% (1995 est.)','66bb5909b12e707862a7bc1a859a470218c67fe96201a5406ecc635bdd8031b7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d1dc1a8431363ded8b657f369ec0016794e0f3f0ddd63b8586a6b0c9d19940d',1999,'HR','Croatia','people-and-society',49,'Population: 3,482,495 (July 1999 est.)
note: all data dealing with population is subject to considerable
error because of the dislocations caused by military action and
ethnic cleansing
Age structure:
0-14 years: 17% (male 310,430; female 294,298)
15-64 years: 71% (male 1,221,791; female 1,240,097)
65 years and over: 12% (male 166,876; female 249,003) (1999 est.)
Population growth rate: 3.2% (1999 est.)
Birth rate: 9.36 births/1,000 population (1999 est.)
Death rate: 10.81 deaths/1,000 population (1999 est.)
Net migration rate: 33.42 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 24.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.98 years
male: 62.55 years
female: 71.71 years (1999 est.)
Total fertility rate: 1.21 children born/woman (1999 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 40%, Muslim 38%, Croat 22% (est.); note--the
Croats claim they now make up only 17% of the total population
Religions: Muslim 40%, Orthodox 31%, Catholic 15%, Protestant 4%,
other 10%
Languages: Croatian, Serbian, Bosnian
Literacy: NA
Population: 1,464,167 (July 1999 est.)
Age structure:
0-14 years: 42% (male 310,578; female 303,495)
15-64 years: 54% (male 379,836; female 416,073)
65 years and over: 4% (male 20,224; female 33,961) (1999 est.)
Population growth rate: 1.05% (1999 est.)
Birth rate: 31.46 births/1,000 population (1999 est.)
Death rate: 21 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 59.08 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 39.89 years
male: 39.42 years
female: 40.37 years (1999 est.)
Total fertility rate: 3.91 children born/woman (1999 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Batswana 95%, Kalanga, Basarwa, and Kgalagadi 4%,
white 1%
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total population: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Population: uninhabited
Population: 171,853,126 (July 1999 est.)
note: Brazil took a census in August 1996 which reported a
population of 157,079,573; that figure was about 5% lower than
projections by the US Census Bureau, and is close to the implied
underenumeration of 4.6% for 1991; the Factbook''s demographic
statistics for Brazil do not take into consideration the results of
the1996 census since the full results have not been released for
analysis
Age structure:
0-14 years: 30% (male 26,059,687; female 25,095,236)
15-64 years: 65% (male 55,037,161; female 56,727,196)
65 years and over: 5% (male 3,626,893; female 5,306,953) (1999 est.)
Population growth rate: 1.16% (1999 est.)
Birth rate: 20.42 births/1,000 population (1999 est.)
Death rate: 8.79 deaths/1,000 population (1999 est.)
Net migration rate: -0.03 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 35.37 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.06 years
male: 59.35 years
female: 69.01 years (1999 est.)
Total fertility rate: 2.28 children born/woman (1999 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese, German, Italian,
Spanish, Polish) 55%, mixed white and black 38%, black 6%, other
(includes Japanese, Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 70%
Languages: Portuguese (official), Spanish, English, French
Literacy:
definition: age 15 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)
Population: no indigenous inhabitants
note: approximately 3,000 native inhabitants, known as the
Chagosians or Ilois, were evacuated to Mauritius before construction
of UK-US military facilities; now there are UK and US military
personnel and civilian contractors living on the island','cdc1a7de134a2505fb8be7f6fa5639c9606db014175741dbb2952703161d40b1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('368b09e6f30909d74e02d71900112bf0f2238f73ca01c8b16580ad97bc0643f7',1999,'PR','Puerto Rico','people-and-society',56,'Population: 19,156 (July 1999 est.)
Age structure:
0-14 years: 21% (male 2,012; female 1,965)
15-64 years: 74% (male 7,300; female 6,896)
65 years and over: 5% (male 539; female 444) (1999 est.)
Population growth rate: 2.37% (1999 est.)
Birth rate: 15.92 births/1,000 population (1999 est.)
Death rate: 4.65 deaths/1,000 population (1999 est.)
Net migration rate: 12.37 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 1.21 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 22.17 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.13 years
male: 74.37 years
female: 75.92 years (1999 est.)
Total fertility rate: 1.71 children born/woman (1999 est.)
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic groups: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%, Anglican 21%, Church of
God 7%, Seventh-Day Adventist 5%, Baptist 4%, Jehovah''s Witnesses
2%, other 2%), Roman Catholic 6%, none 2%, other 6% (1981)
Languages: English (official)
Literacy:
definition: age 15 and over can read and write
total population: 97.8% (1991 est.)
male: NA%
female: NA%
Population: 12,853 (July 1999 est.)
note: demographic figures include an estimated 8,000 refugees who
left the island following the resumption of volcanic activity in
July 1995
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.21% (1999 est.)
Birth rate: 13.87 births/1,000 population (1999 est.)
Death rate: 9.88 deaths/1,000 population (1999 est.)
Net migration rate: -1.94 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 12 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.56 years
male: 73.79 years
female: 77.37 years (1999 est.)
Total fertility rate: 1.78 children born/woman (1999 est.)
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic, Pentecostal,
Seventh-Day Adventist, other Christian denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 97% (1970 est.)
Population: 29,661,636 (July 1999 est.)
Age structure:
0-14 years: 36% (male 5,409,322; female 5,208,742)
15-64 years: 60% (male 8,773,625; female 8,922,976)
65 years and over: 4% (male 619,164; female 727,807) (1999 est.)
Population growth rate: 1.84% (1999 est.)
Birth rate: 25.78 births/1,000 population (1999 est.)
Death rate: 6.12 deaths/1,000 population (1999 est.)
Net migration rate: -1.27 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 50.96 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.87 years
male: 66.85 years
female: 70.99 years (1999 est.)
Total fertility rate: 3.24 children born/woman (1999 est.)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%, Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%, Jewish 0.2%
Languages: Arabic (official), Berber dialects, French often the
language of business, government, and diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 43.7%
male: 56.6%
female: 31% (1995 est.)
Population: 19,124,335 (July 1999 est.)
note: the 1997 Mozambican census reported a population of
16,542,800; other estimates range as low as 16.9 million
Age structure:
0-14 years: 45% (male 4,236,545; female 4,325,586)
15-64 years: 53% (male 4,941,048; female 5,181,282)
65 years and over: 2% (male 182,857; female 257,017) (1999 est.)
Population growth rate: 2.54% (1999 est.)
Birth rate: 42.75 births/1,000 population (1999 est.)
Death rate: 17.31 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 117.56 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 45.89 years
male: 44.73 years
female: 47.09 years (1999 est.)
Total fertility rate: 5.88 children born/woman (1999 est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66% (Shangaan, Chokwe,
Manyika, Sena, Makua, and others), Europeans 0.06%, Euro-Africans
0.2%, Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%, Muslim 20%
Languages: Portuguese (official), indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 40.1%
male: 57.7%
female: 23.3% (1995 est.)
Population: 1,648,270 (July 1999 est.)
Age structure:
0-14 years: 44% (male 366,030; female 358,105)
15-64 years: 52% (male 424,879; female 435,116)
65 years and over: 4% (male 26,787; female 37,353) (1999 est.)
Population growth rate: 1.57% (1999 est.)
Birth rate: 35.63 births/1,000 population (1999 est.)
Death rate: 19.92 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 65.94 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 41.26 years
male: 41.64 years
female: 40.87 years (1999 est.)
Total fertility rate: 4.94 children born/woman (1999 est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 86%, white 6.6%, mixed 7.4%
note: about 50% of the population belong to the Ovambo tribe and 9%
to the Kavangos tribe; other ethnic groups are: Herero 7%, Damara
7%, Nama 5%, Caprivian 4%, Bushmen 3%, Baster 2%, Tswana 0.5%
Religions: Christian 80% to 90% (Lutheran 50% at least, other
Christian denominations 30%), native religions 10% to 20%
Languages: English 7% (official), Afrikaans common language of
most of the population and about 60% of the white population, German
32%, indigenous languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 45%
female: 31% (1960 est.)
Population: 10,605 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0% (1999 est.)
Birth rate: NA
Death rate: 0 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander 26%, Chinese
8%, European 8%
Religions: Christian (two-thirds Protestant, one-third Roman
Catholic)
Languages: Nauruan (official, a distinct Pacific Island
language), English widely understood, spoken, and used for most
government and commercial purposes
Literacy: NA
Population: uninhabited
note: transient Haitian fishermen and others camp on the island
Population: 24,302,653 (July 1999 est.)
Age structure:
0-14 years: 41% (male 5,182,829; female 4,869,895)
15-64 years: 55% (male 6,856,905; female 6,571,916)
65 years and over: 4% (male 407,797; female 413,311) (1999 est.)
Population growth rate: 2.51% (1999 est.)
Birth rate: 35.32 births/1,000 population (1999 est.)
Death rate: 10.18 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 73.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 58.42 years
male: 58.47 years
female: 58.36 years (1999 est.)
Total fertility rate: 4.78 children born/woman (1999 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Newars, Indians, Tibetans, Gurungs, Magars,
Tamangs, Bhotias, Rais, Limbus, Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim 3%, other 2% (1981)
note: only official Hindu state in the world, although no sharp
distinction between many Hindu and Buddhist groups
Languages: Nepali (official), 20 other languages divided into
numerous dialects
Literacy:
definition: age 15 and over can read and write
total population: 27.5%
male: 40.9%
female: 14% (1995 est.)
People--note: refugee issue over the presence in Nepal of
approximately 91,000 Bhutanese refugees, 90% of whom are in seven
United Nations Office of the High Commissioner for Refugees (UNHCR)
camps
Population: 15,807,641 (July 1999 est.)
Age structure:
0-14 years: 18% (male 1,475,606; female 1,410,088)
15-64 years: 68% (male 5,482,193; female 5,288,948)
65 years and over: 14% (male 875,847; female 1,274,959) (1999 est.)
Population growth rate: 0.47% (1999 est.)
Birth rate: 11.36 births/1,000 population (1999 est.)
Death rate: 8.69 deaths/1,000 population (1999 est.)
Net migration rate: 1.99 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.11 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.15 years
male: 75.28 years
female: 81.17 years (1999 est.)
Total fertility rate: 1.49 children born/woman (1999 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 94%, Moroccans, Turks, and other 6% (1988)
Religions: Roman Catholic 34%, Protestant 25%, Muslim 3%, other
2%, unaffiliated 36% (1991)
Languages: Dutch
Literacy:
definition: age 15 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%
Population: 207,827 (July 1999 est.)
Age structure:
0-14 years: 26% (male 27,160; female 26,149)
15-64 years: 67% (male 65,781; female 73,054)
65 years and over: 7% (male 6,538; female 9,145) (1999 est.)
Population growth rate: 1.01% (1999 est.)
Birth rate: 17.11 births/1,000 population (1999 est.)
Death rate: 6.58 deaths/1,000 population (1999 est.)
Net migration rate: -0.43 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 12.59 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.25 years
male: 72.19 years
female: 76.41 years (1999 est.)
Total fertility rate: 2.09 children born/woman (1999 est.)
Nationality:
noun: Netherlands Antillean(s)
adjective: Netherlands Antillean
Ethnic groups: mixed black 85%, Carib Amerindian, white, East
Asian
Religions: Roman Catholic, Protestant, Jewish, Seventh-Day
Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Portuguese-Dutch-English dialect) predominates, English
widely spoken, Spanish
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est.)
Population: 3,308,523 (July 1999 est.)
Age structure:
0-14 years: 24% (male 407,990; female 388,293)
15-64 years: 63% (male 1,026,554; female 1,054,513)
65 years and over: 13% (male 179,331; female 251,842) (1999 est.)
Population growth rate: 0.73% (1999 est.)
Birth rate: 16.84 births/1,000 population (1999 est.)
Death rate: 8.81 deaths/1,000 population (1999 est.)
Net migration rate: -0.78 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 13.49 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.83 years
male: 72.69 years
female: 79.15 years (1999 est.)
Total fertility rate: 2.27 children born/woman (1999 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%, Amerindian,
practically nonexistent
Religions: Roman Catholic 66% (less than one-half of the adult
population attends church regularly), Protestant 2%, Jewish 2%,
nonprofessing or other 30%
Languages: Spanish, Portunol, or Brazilero (Portuguese-Spanish
mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 97.3%
male: 96.9%
female: 97.7% (1995 est.)','db4ff2c3f2dc15184e46758dc4162dd40b8439e343b6b52ade4e10ac4651aa5d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7eafa45db55df595c7c1884e5abd5bf6a4f86b35dee6300c143093dbd28690b',1999,'MY','Malaysia','people-and-society',67,'Population: 322,982 (July 1999 est.)
Age structure:
0-14 years: 33% (male 54,154; female 51,766)
15-64 years: 63% (male 106,492; female 95,921)
65 years and over: 4% (male 7,945; female 6,704) (1999 est.)
Population growth rate: 2.38% (1999 est.)
Birth rate: 24.69 births/1,000 population (1999 est.)
Death rate: 5.21 deaths/1,000 population (1999 est.)
Net migration rate: 4.35 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1.19 male(s)/female
total population: 1.09 male(s)/female (1999 est.)
Infant mortality rate: 22.83 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.84 years
male: 70.35 years
female: 73.42 years (1999 est.)
Total fertility rate: 3.33 children born/woman (1999 est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 64%, Chinese 20%, other 16%
Religions: Muslim (official) 63%, Buddhism 14%, Christian 8%,
indigenous beliefs and other 15% (1981)
Languages: Malay (official), English, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)
Population: 8,194,772 (July 1999 est.)
Age structure:
0-14 years: 16% (male 674,643; female 641,943)
15-64 years: 68% (male 2,744,634; female 2,800,816)
65 years and over: 16% (male 570,766; female 761,970) (1999 est.)
Population growth rate: -0.52% (1999 est.)
Birth rate: 8.71 births/1,000 population (1999 est.)
Death rate: 13.2 deaths/1,000 population (1999 est.)
Net migration rate: -0.66 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 12.37 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.27 years
male: 68.72 years
female: 76.03 years (1999 est.)
Total fertility rate: 1.23 children born/woman (1999 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 85%, Turk 9%, other 6%
Religions: Bulgarian Orthodox 85%, Muslim 13%, Jewish 0.8%, Roman
Catholic 0.5%, Uniate Catholic 0.2%, Protestant, Gregorian-Armenian,
and other 0.5%
Languages: Bulgarian, secondary languages closely correspond to
ethnic breakdown
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1992 est.)
Population: 11,575,898 (July 1999 est.)
Age structure:
0-14 years: 48% (male 2,792,895; female 2,759,072)
15-64 years: 49% (male 2,700,253; female 2,978,168)
65 years and over: 3% (male 147,017; female 198,493) (1999 est.)
Population growth rate: 2.7% (1999 est.)
Birth rate: 45.84 births/1,000 population (1999 est.)
Death rate: 17.56 deaths/1,000 population (1999 est.)
Net migration rate: -1.25 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 107.19 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 45.89 years
male: 44.97 years
female: 46.84 years (1999 est.)
Total fertility rate: 6.56 children born/woman (1999 est.)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi about 24%, Gurunsi, Senufo, Lobi, Bobo,
Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%, Christian (mainly
Roman Catholic) 10%
Languages: French (official), tribal languages belonging to
Sudanic family, spoken by 90% of the population
Literacy:
definition: age 15 and over can read and write
total population: 19.2%
male: 29.5%
female: 9.2% (1995 est.)
Population: 48,081,302 (July 1999 est.)
Age structure:
0-14 years: 36% (male 8,883,099; female 8,542,087)
15-64 years: 60% (male 14,343,888; female 14,293,233)
65 years and over: 4% (male 906,517; female 1,112,478) (1999 est.)
Population growth rate: 1.61% (1999 est.)
Birth rate: 28.48 births/1,000 population (1999 est.)
Death rate: 12.39 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 76.25 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.74 years
male: 53.24 years
female: 56.32 years (1999 est.)
Total fertility rate: 3.63 children born/woman (1999 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%, Rakhine 4%, Chinese
3%, Mon 2%, Indian 2%, other 5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%, Roman Catholic
1%), Muslim 4%, animist beliefs 1%, other 2%
Languages: Burmese, minority ethnic groups have their own
languages
Literacy:
definition: age 15 and over can read and write
total population: 83.1%
male: 88.7%
female: 77.7% (1995 est.)
Population: 5,735,937 (July 1999 est.)
Age structure:
0-14 years: 47% (male 1,349,995; female 1,345,201)
15-64 years: 50% (male 1,392,880; female 1,479,835)
65 years and over: 3% (male 69,748; female 98,278) (1999 est.)
Population growth rate: 3.54% (1999 est.)
Birth rate: 41.27 births/1,000 population (1999 est.)
Death rate: 17.23 deaths/1,000 population (1999 est.)
Net migration rate: 11.33 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 99.36 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 45.44 years
male: 43.54 years
female: 47.41 years (1999 est.)
Total fertility rate: 6.33 children born/woman (1999 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic) 14%, Twa (Pygmy)
1%, Europeans 3,000, South Asians 2,000
Religions: Christian 67% (Roman Catholic 62%, Protestant 5%),
indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official), Swahili (along
Lake Tanganyika and in the Bujumbura area)
Literacy:
definition: age 15 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
Population: 11,626,520 (July 1999 est.)
Age structure:
0-14 years: 45% (male 2,667,768; female 2,587,590)
15-64 years: 52% (male 2,821,772; female 3,197,604)
65 years and over: 3% (male 143,016; female 208,770) (1999 est.)
Population growth rate: 2.49% (1999 est.)
Birth rate: 41.05 births/1,000 population (1999 est.)
Death rate: 16.2 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.88 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 105.06 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 48.24 years
male: 46.81 years
female: 49.75 years (1999 est.)
Total fertility rate: 5.81 children born/woman (1999 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%, Chinese 1%, other 4%
Religions: Theravada Buddhism 95%, other 5%
Languages: Khmer (official), French
Literacy:
definition: age 15 and over can read and write
total population: 35%
male: 48%
female: 22% (1990 est.)
Population: 15,456,092 (July 1999 est.)
Age structure:
0-14 years: 46% (male 3,562,553; female 3,528,778)
15-64 years: 51% (male 3,907,946; female 3,943,035)
65 years and over: 3% (male 231,521; female 282,259) (1999 est.)
Population growth rate: 2.79% (1999 est.)
Birth rate: 41.84 births/1,000 population (1999 est.)
Death rate: 13.95 deaths/1,000 population (1999 est.)
Net migration rate: NA migrant(s)/1,000 population; note--there
may be some migration but figures are not available
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 75.69 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 51.32 years
male: 49.75 years
female: 52.94 years (1999 est.)
Total fertility rate: 5.8 children born/woman (1999 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%, Equatorial Bantu 19%,
Kirdi 11%, Fulani 10%, Northwestern Bantu 8%, Eastern Nigritic 7%,
other African 13%, non-African less than 1%
Religions: indigenous beliefs 51%, Christian 33%, Muslim 16%
Languages: 24 major African language groups, English (official),
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 63.4%
male: 75%
female: 52.1% (1995 est.)
Population: 31,006,347 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,105,944; female 2,960,171)
15-64 years: 68% (male 10,587,553; female 10,461,455)
65 years and over: 12% (male 1,652,044; female 2,239,180) (1999 est.)
Population growth rate: 1.06% (1999 est.)
Birth rate: 11.86 births/1,000 population (1999 est.)
Death rate: 7.26 deaths/1,000 population (1999 est.)
Net migration rate: 5.96 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.47 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 79.37 years
male: 76.12 years
female: 82.79 years (1999 est.)
Total fertility rate: 1.65 children born/woman (1999 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 40%, French origin 27%, other
European 20%, Amerindian 1.5%, other, mostly Asian 11.5%
Religions: Roman Catholic 45%, United Church 12%, Anglican 8%,
other 35% (1991)
Languages: English (official), French (official)
Literacy:
definition: age 15 and over can read and write
total population: 97% (1986 est.)
male: NA%
female: NA%
Population: 405,748 (July 1999 est.)
Age structure:
0-14 years: 45% (male 92,721; female 91,083)
15-64 years: 49% (male 92,658; female 104,264)
65 years and over: 6% (male 9,936; female 15,086) (1999 est.)
Population growth rate: 1.44% (1999 est.)
Birth rate: 33.49 births/1,000 population (1999 est.)
Death rate: 6.78 deaths/1,000 population (1999 est.)
Net migration rate: -12.35 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 45.5 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.96 years
male: 67.66 years
female: 74.36 years (1999 est.)
Total fertility rate: 4.95 children born/woman (1999 est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%, European 1%
Religions: Roman Catholic (infused with indigenous beliefs);
Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of creole Portuguese and
West African words)
Literacy:
definition: age 15 and over can read and write
total population: 71.6%
male: 81.4%
female: 63.8% (1995 est.)
Population: 39,335 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 4.19% (1999 est.)
Birth rate: 13.66 births/1,000 population (1999 est.)
Death rate: 4.98 deaths/1,000 population (1999 est.)
Net migration rate: 33.2 migrant(s)/1,000 population (1999 est.)
note: major destination for Cubans trying to migrate to the US
Infant mortality rate: 8.4 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.1 years
male: 75.37 years
female: 78.81 years (1999 est.)
Total fertility rate: 1.31 children born/woman (1999 est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%, expatriates of
various ethnic groups 20%
Religions: United Church (Presbyterian and Congregational),
Anglican, Baptist, Roman Catholic, Church of God, other Protestant
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: no indigenous inhabitants
note: there are scattered Chinese garrisons','12c86f436c18aa88367b06ff068512ad459b718557c0cc2db633038ad95a0b10','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec7fb964ff57d11f5b339672ae017ec75ddb3c9292498f05835459b049746b1',1999,'CG','Congo','people-and-society',78,'Population: 3,444,951 (July 1999 est.)
Age structure:
0-14 years: 44% (male 757,422; female 749,289)
15-64 years: 53% (male 885,087; female 927,282)
65 years and over: 3% (male 56,309; female 69,562) (1999 est.)
Population growth rate: 2.04% (1999 est.)
Birth rate: 38.28 births/1,000 population (1999 est.)
Death rate: 16.46 deaths/1,000 population (1999 est.)
Net migration rate: -1.45 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 103.42 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 47.19 years
male: 45.35 years
female: 49.09 years (1999 est.)
Total fertility rate: 5.03 children born/woman (1999 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%, Mandjia 21%, Mboum
4%, M''Baka 4%, Europeans 6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%, Roman Catholic
25%, Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence the
Christian majority
Languages: French (official), Sangho (lingua franca and national
language), Arabic, Hunsa, Swahili
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 68.5%
female: 52.4% (1995 est.)
Population: 7,557,436 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,675,394; female 1,667,717)
15-64 years: 53% (male 1,953,251; female 2,034,883)
65 years and over: 3% (male 99,783; female 126,408) (1999 est.)
Population growth rate: 2.65% (1999 est.)
Birth rate: 43.06 births/1,000 population (1999 est.)
Death rate: 16.57 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 115.27 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 48.56 years
male: 46.13 years
female: 51.09 years (1999 est.)
Total fertility rate: 5.69 children born/woman (1999 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims (Arabs, Toubou, Hadjerai, Fulbe, Kotoko,
Kanembou, Baguirmi, Boulala, Zaghawa, and Maba), non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moundang, Moussei, Massa), nonindigenous
150,000 (of whom 1,000 are French)
Religions: Muslim 50%, Christian 25%, indigenous beliefs (mostly
animism) 25%
Languages: French (official), Arabic (official), Sara and Sango
(in south), more than 100 different languages and dialects
Literacy:
definition: age 15 and over can read and write French or Arabic
total population: 48.1%
male: 62.1%
female: 34.7% (1995 est.)
Population: 14,973,843 (July 1999 est.)
Age structure:
0-14 years: 28% (male 2,137,255; female 2,044,605)
15-64 years: 65% (male 4,845,523; female 4,885,328)
65 years and over: 7% (male 440,010; female 621,122) (1999 est.)
Population growth rate: 1.23% (1999 est.)
Birth rate: 17.81 births/1,000 population (1999 est.)
Death rate: 5.53 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 10.02 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.46 years
male: 72.33 years
female: 78.75 years (1999 est.)
Total fertility rate: 2.25 children born/woman (1999 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%, Amerindian 3%,
other 2%
Religions: Roman Catholic 89%, Protestant 11%, Jewish less than 1%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.2%
male: 95.4%
female: 95% (1995 est.)
Population: 1,246,871,951 (July 1999 est.)
Age structure:
0-14 years: 26% (male 169,206,275; female 149,115,216)
15-64 years: 68% (male 435,047,915; female 408,663,265)
65 years and over: 6% (male 39,824,361; female 45,014,919) (1999
est.)
Population growth rate: 0.77% (1999 est.)
Birth rate: 15.1 births/1,000 population (1999 est.)
Death rate: 6.98 deaths/1,000 population (1999 est.)
Net migration rate: -0.41 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.15 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 1.06 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 43.31 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.92 years
male: 68.57 years
female: 71.48 years (1999 est.)
Total fertility rate: 1.8 children born/woman (1999 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91.9%, Zhuang, Uygur, Hui, Yi,
Tibetan, Miao, Manchu, Mongol, Buyi, Korean, and other nationalities
8.1%
Religions: Daoism (Taoism), Buddhism, Muslim 2%-3%, Christian 1%
(est.)
note: officially atheist, but traditionally pragmatic and eclectic
Languages: Standard Chinese or Mandarin (Putonghua, based on the
Beijing dialect), Yue (Cantonese), Wu (Shanghaiese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka dialects,
minority languages (see Ethnic divisions entry)
Literacy:
definition: age 15 and over can read and write
total population: 81.5%
male: 89.9%
female: 72.7% (1995 est.)
Population: 7,145 (July 1999 est.)
Age structure:
0-14 years: 20% (male 713; female 690)
15-64 years: 72% (male 2,664; female 2,449)
65 years and over: 8% (male 259; female 370) (1999 est.)
Population growth rate: 0.74% (1999 est.)
Birth rate: 13.86 births/1,000 population (1999 est.)
Death rate: 6.44 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 1.04 male(s)/female (1999 est.)
Infant mortality rate: 27.98 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.88 years
male: 72.78 years
female: 79.13 years (1999 est.)
Total fertility rate: 1.5 children born/woman (1999 est.)
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
Ethnic groups: African descent, white
Religions: Anglican (majority), Baptist, Seventh-Day Adventist,
Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
female: 98% (1987 est.)
Population: 42,838 (July 1999 est.)
Age structure:
0-14 years: 33% (male 7,178; female 6,826)
15-64 years: 61% (male 13,226; female 13,083)
65 years and over: 6% (male 1,020; female 1,505) (1999 est.)
Population growth rate: 1.34% (1999 est.)
Birth rate: 22.6 births/1,000 population (1999 est.)
Death rate: 8.15 deaths/1,000 population (1999 est.)
Net migration rate: -1.05 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 17.39 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 67.94 years
male: 64.87 years
female: 71.21 years (1999 est.)
Total fertility rate: 2.42 children born/woman (1999 est.)
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: black
Religions: Anglican, other Protestant sects, Roman Catholic
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
female: 98% (1980 est.)
Population: 154,020 (July 1999 est.)
Age structure:
0-14 years: 33% (male 26,068; female 25,359)
15-64 years: 61% (male 46,265; female 48,100)
65 years and over: 6% (male 3,097; female 5,131) (1999 est.)
Population growth rate: 1.09% (1999 est.)
Birth rate: 21.63 births/1,000 population (1999 est.)
Death rate: 5.58 deaths/1,000 population (1999 est.)
Net migration rate: -5.19 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 16.55 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.81 years
male: 68.14 years
female: 75.74 years (1999 est.)
Total fertility rate: 2.27 children born/woman (1999 est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian 3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%, Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 67%
male: 65%
female: 69% (1980 est.)
Population: 6,966 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.75% (1999 est.)
Birth rate: 12.27 births/1,000 population (1999 est.)
Death rate: 5.41 deaths/1,000 population (1999 est.)
Net migration rate: 0.59 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 8.12 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.13 years
male: 75.58 years
female: 79 years (1999 est.)
Total fertility rate: 1.58 children born/woman (1999 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French fishermen)
Religions: Roman Catholic 99%
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Population: 49,811,174 (July 1999 est.)
Age structure:
0-14 years: 18% (male 4,690,318; female 4,498,239)
15-64 years: 68% (male 16,136,296; female 17,572,011)
65 years and over: 14% (male 2,251,664; female 4,662,646) (1999 est.)
Population growth rate: -0.62% (1999 est.)
Birth rate: 9.54 births/1,000 population (1999 est.)
Death rate: 16.38 deaths/1,000 population (1999 est.)
Net migration rate: 0.63 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.86 male(s)/female (1999 est.)
Infant mortality rate: 21.73 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 65.91 years
male: 60.23 years
female: 71.87 years (1999 est.)
Total fertility rate: 1.34 children born/woman (1999 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%, Jewish 1%, other 4%
Religions: Ukrainian Orthodox--Moscow Patriarchate, Ukrainian
Orthodox--Kiev Patriarchate, Ukrainian Autocephalous Orthodox,
Ukrainian Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish, Hungarian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)
Population: 2,344,402 (July 1999 est.)
note: includes 1,576,589 non-nationals (July 1999 est.)
Age structure:
0-14 years: 31% (male 368,844; female 353,183)
15-64 years: 67% (male 1,015,690; female 558,902)
65 years and over: 2% (male 32,935; female 14,848) (1999 est.)
Population growth rate: 1.78% (1999 est.)
Birth rate: 18.86 births/1,000 population (1999 est.)
Death rate: 3.13 deaths/1,000 population (1999 est.)
Net migration rate: 2.03 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.82 male(s)/female
65 years and over: 2.22 male(s)/female
total population: 1.53 male(s)/female (1999 est.)
Infant mortality rate: 14.1 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.24 years
male: 73.83 years
female: 76.72 years (1999 est.)
Total fertility rate: 3.5 children born/woman (1999 est.)
Nationality:
noun: Emirian(s)
adjective: Emirian
Ethnic groups: Emiri 19%, other Arab and Iranian 23%, South Asian
50%, other expatriates (includes Westerners and East Asians) 8%
(1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian, Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi, Urdu
Literacy:
definition: age 15 and over can read and write
total population: 79.2%
male: 78.9%
female: 79.8% (1995 est.)
Population: 59,113,439 (July 1999 est.)
Age structure:
0-14 years: 19% (male 5,822,901; female 5,522,122)
15-64 years: 65% (male 19,393,706; female 19,103,882)
65 years and over: 16% (male 3,821,181; female 5,449,647) (1999 est.)
Population growth rate: 0.24% (1999 est.)
Birth rate: 11.9 births/1,000 population (1999 est.)
Death rate: 10.64 deaths/1,000 population (1999 est.)
Net migration rate: 1.11 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 5.78 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.37 years
male: 74.73 years
female: 80.15 years (1999 est.)
Total fertility rate: 1.71 children born/woman (1999 est.)
Nationality:
noun: Briton(s), British (collective plural)
adjective: British
Ethnic groups: English 81.5%, Scottish 9.6%, Irish 2.4%, Welsh
1.9%, Ulster 1.8%, West Indian, Indian, Pakistani, and other 2.8%
Religions: Anglican 27 million, Roman Catholic 9 million, Muslim
1 million, Presbyterian 800,000, Methodist 760,000, Sikh 400,000,
Hindu 350,000, Jewish 300,000 (1991 est.)
Languages: English, Welsh (about 26% of the population of Wales),
Scottish form of Gaelic (about 60,000 in Scotland)
Literacy:
definition: age 15 and over has completed five or more years of
schooling
total population: 99% (1978 est.)
male: NA%
female: NA%','4ed26aa745166c7729331fd9162453eb03018b15535cc940f1f73f6f4d7c6fe2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79a1fbf7e73544a977bd58dab451db48f8422e275174c2d4d2c3bf762b9cddb4',1999,'ID','Indonesia','people-and-society',94,'Population: 2,373 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 7.77% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 61%, Malay 25%, European 11%, other 3%, no
indigenous population
Religions: Buddhist 55%, Christian 15%, Muslim 10%, other 20%
(1991)
Languages: English
Population: 3,531,600 (July 1999 est.)
Age structure:
0-14 years: 21% (male 387,786; female 364,018)
15-64 years: 72% (male 1,265,291; female 1,268,458)
65 years and over: 7% (male 109,418; female 136,629) (1999 est.)
Population growth rate: 1.15% (1999 est.)
Birth rate: 13.38 births/1,000 population (1999 est.)
Death rate: 4.69 deaths/1,000 population (1999 est.)
Net migration rate: 2.83 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 3.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.84 years
male: 75.79 years
female: 82.14 years (1999 est.)
Total fertility rate: 1.47 children born/woman (1999 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.4%, Malay 14.9%, Indian 6.4%, other 2.3%
Religions: Buddhist (Chinese), Muslim (Malays), Christian, Hindu,
Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and national),
Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 95.9%
female: 86.3% (1995 est.)
Population: 5,396,193 (July 1999 est.)
Age structure:
0-14 years: 20% (male 551,847; female 528,236)
15-64 years: 69% (male 1,837,788; female 1,861,305)
65 years and over: 11% (male 237,710; female 379,307) (1999 est.)
Population growth rate: 0.04% (1999 est.)
Birth rate: 9.52 births/1,000 population (1999 est.)
Death rate: 9.43 deaths/1,000 population (1999 est.)
Net migration rate: 0.29 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 9.48 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.46 years
male: 69.71 years
female: 77.4 years (1999 est.)
Total fertility rate: 1.2 children born/woman (1999 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.7%, Gypsy 1.5% (the
1992 census figures underreport the Gypsy/Romany community, which is
about 500,000), Czech 1%, Ruthenian 0.3%, Ukrainian 0.3%, German
0.1%, Polish 0.1%, other 0.3%
Religions: Roman Catholic 60.3%, atheist 9.7%, Protestant 8.4%,
Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy: NA
Population: 1,970,570 (July 1999 est.)
Age structure:
0-14 years: 16% (male 163,816; female 155,509)
15-64 years: 70% (male 693,382; female 687,060)
65 years and over: 14% (male 99,121; female 171,682) (1999 est.)
Population growth rate: -0.04% (1999 est.)
Birth rate: 8.97 births/1,000 population (1999 est.)
Death rate: 9.62 deaths/1,000 population (1999 est.)
Net migration rate: 0.23 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 5.28 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.36 years
male: 71.71 years
female: 79.21 years (1999 est.)
Total fertility rate: 1.23 children born/woman (1999 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 91%, Croat 3%, Serb 2%, Muslim 1%, other 3%
Religions: Roman Catholic 70.8% (including 2% Uniate), Lutheran
1%, Muslim 1%, atheist 4.3%, other 22.9%
Languages: Slovenian 91%, Serbo-Croatian 6%, other 3%
Literacy:
definition: NA
total population: 99%
male: NA%
female: NA%
Population: 455,429 (July 1999 est.)
Age structure:
0-14 years: 45% (male 103,844; female 99,972)
15-64 years: 52% (male 120,518; female 117,298)
65 years and over: 3% (male 6,808; female 6,989) (1999 est.)
Population growth rate: 3.18% (1999 est.)
Birth rate: 35.92 births/1,000 population (1999 est.)
Death rate: 4.11 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 23 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.09 years
male: 69.55 years
female: 74.75 years (1999 est.)
Total fertility rate: 4.96 children born/woman (1999 est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%, Micronesian 1.5%,
European 0.8%, Chinese 0.3%, other 0.4%
Religions: Anglican 34%, Roman Catholic 19%, Baptist 17%, United
(Methodist/Presbyterian) 11%, Seventh-Day Adventist 10%, other
Protestant 5%, traditional beliefs 4%
Languages: Melanesian pidgin in much of the country is lingua
franca, English spoken by 1%-2% of population
note: 120 indigenous languages
Literacy: NA
Population: 7,140,643 (July 1999 est.)
note: this estimate was derived from an official census taken in
1987 by the Somali Government with the cooperation of the UN and the
US Bureau of the Census; population estimates are updated between
censuses by factoring in growth rates and by taking account of
refugee movements and losses due to famine; lower estimates of
Somalia''s population in mid-1996 (on the order of 6.0 million to 6.5
million) have been made by aid and relief agencies, based on the
number of persons being fed; population counting in Somalia is
complicated by the large numbers of nomads and by refugee movements
in response to famine and clan warfare
Age structure:
0-14 years: 44% (male 1,588,025; female 1,584,770)
15-64 years: 53% (male 1,898,794; female 1,865,487)
65 years and over: 3% (male 92,419; female 111,148) (1999 est.)
Population growth rate: 4.13% (1999 est.)
Birth rate: 47.98 births/1,000 population (1999 est.)
Death rate: 18.62 deaths/1,000 population (1999 est.)
Net migration rate: 11.9 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 125.77 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 46.23 years
male: 44.66 years
female: 47.85 years (1999 est.)
Total fertility rate: 7.25 children born/woman (1999 est.)
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu, Arabs 30,000
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 15 and over can read and write
total population: 24%
male: 36%
female: 14% (1990 est.)
Population: 43,426,386 (July 1999 est.)
note: South Africa took a census 10 October 1996 which showed a
population of 37,859,000 (after a 6.8% adjustment for
underenumeration based on a post-enumeration survey); this figure is
still about 10% below projections from earlier censuses; since the
full results of that census have not been released for analysis, the
numbers shown for South Africa do not take into consideration the
results of this 1996 census
Age structure:
0-14 years: 34% (male 7,541,840; female 7,403,235)
15-64 years: 61% (male 13,180,925; female 13,312,917)
65 years and over: 5% (male 798,825; female 1,188,644) (1999 est.)
Population growth rate: 1.32% (1999 est.)
Birth rate: 25.94 births/1,000 population (1999 est.)
Death rate: 12.81 deaths/1,000 population (1999 est.)
Net migration rate: 0.08 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 51.99 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.76 years
male: 52.68 years
female: 56.9 years (1999 est.)
Total fertility rate: 3.09 children born/woman (1999 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black 75.2%, white 13.6%, Colored 8.6%, Indian 2.6%
Religions: Christian 68% (includes most whites and Coloreds,
about 60% of blacks and about 40% of Indians), Muslim 2%, Hindu 1.5%
(60% of Indians), traditional and animistic 28.5%
Languages: 11 official languages, including Afrikaans, English,
Ndebele, Pedi, Sotho, Swazi, Tsonga, Tswana, Venda, Xhosa, Zulu
Literacy:
definition: age 15 and over can read and write
total population: 81.8%
male: 81.9%
female: 81.7% (1995 est.)
Population: no indigenous inhabitants
note: there is a small military garrison on South Georgia, and the
British Antarctic Survey has a biological station on Bird Island;
the South Sandwich Islands are uninhabited','a7aad6a2ee046cc328410ee01a70f64541216748cf226912a83a7ffc853bd2f6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('433c3d583e5e2438f91b035504ac849fd22e60db825ce7524e31289d32825a18',1999,'AU','Australia','people-and-society',116,'Population: uninhabited
Population: 636 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA (July 1998 est.)
Population growth rate: -0.21% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 57%, Christian 22%, other 21% (1981 est.)
Languages: English, Malay
Population: 39,309,422 (July 1999 est.)
Age structure:
0-14 years: 33% (male 6,556,566; female 6,402,115)
15-64 years: 62% (male 11,966,306; female 12,593,685)
65 years and over: 5% (male 807,282; female 983,468) (1999 est.)
Population growth rate: 1.85% (1999 est.)
Birth rate: 24.45 births/1,000 population (1999 est.)
Death rate: 5.59 deaths/1,000 population (1999 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 24.3 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.48 years
male: 66.54 years
female: 74.54 years (1999 est.)
Total fertility rate: 2.87 children born/woman (1999 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto 14%, black 4%,
mixed black-Amerindian 3%, Amerindian 1%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 91.3%
male: 91.2%
female: 91.4% (1995 est.)
Population: 562,723 (July 1999 est.)
Age structure:
0-14 years: 43% (male 120,397; female 119,945)
15-64 years: 54% (male 150,851; female 154,990)
65 years and over: 3% (male 7,878; female 8,662) (1999 est.)
Population growth rate: 3.11% (1999 est.)
Birth rate: 40.29 births/1,000 population (1999 est.)
Death rate: 9.23 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 81.63 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 60.85 years
male: 58.39 years
female: 63.38 years (1999 est.)
Total fertility rate: 5.43 children born/woman (1999 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 14%
Languages: Arabic (official), French (official), Comoran (a blend
of Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
total population: 57.3%
male: 64.2%
female: 50.4% (1995 est.)
Population: no indigenous inhabitants
note: there is a staff of three to four at the meteorological station
Population: 3,674,490 (July 1999 est.)
Age structure:
0-14 years: 33% (male 622,260; female 593,720)
15-64 years: 62% (male 1,150,900; female 1,121,970)
65 years and over: 5% (male 85,526; female 100,114) (1999 est.)
Population growth rate: 1.89% (1999 est.)
Birth rate: 22.46 births/1,000 population (1999 est.)
Death rate: 4.16 deaths/1,000 population (1999 est.)
Net migration rate: 0.63 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 12.89 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.04 years
male: 73.6 years
female: 78.61 years (1999 est.)
Total fertility rate: 2.76 children born/woman (1999 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white (including mestizo) 96%, black 2%,
Amerindian 1%, Chinese 1%
Religions: Roman Catholic 95%
Languages: Spanish (official), English spoken around Puerto Limon
Literacy:
definition: age 15 and over can read and write
total population: 94.8%
male: 94.7%
female: 95% (1995 est.)
Population: 15,818,068 (July 1999 est.)
Age structure:
0-14 years: 47% (male 3,702,051; female 3,664,672)
15-64 years: 51% (male 4,154,440; female 3,952,999)
65 years and over: 2% (male 174,065; female 169,841) (1999 est.)
Population growth rate: 2.35% (1999 est.)
Birth rate: 41.76 births/1,000 population (1999 est.)
Death rate: 16.17 deaths/1,000 population (1999 est.)
Net migration rate: -2.08 migrant(s)/1,000 population (1999 est.)
note: after Liberia''s civil war started in 1990, more than 350,000
refugees fled to Cote d''Ivoire and, by September 1998, according to
the UNHCR, about 85,000 remain
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 94.17 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 46.05 years
male: 44.48 years
female: 47.67 years (1999 est.)
Total fertility rate: 5.89 children born/woman (1999 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Baoule 23%, Bete 18%, Senoufou 15%, Malinke 11%,
Agni, Africans from other countries (mostly Burkinabe and Malians,
about 3 million), non-Africans 130,000 to 330,000 (French 30,000 and
Lebanese 100,000 to 300,000)
Religions: Muslim 60%, Christian 22%, indigenous 18% (some of
these are also numbered among the Christians and Muslims)
Languages: French (official), 60 native dialects with Dioula the
most widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 48.5%
male: 57%
female: 40%
Population: 4,676,865 (July 1999 est.)
Age structure:
0-14 years: 17% (male 404,761; female 383,088)
15-64 years: 68% (male 1,591,831; female 1,591,106)
65 years and over: 15% (male 272,219; female 433,860) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 10.34 births/1,000 population (1999 est.)
Death rate: 11.14 deaths/1,000 population (1999 est.)
Net migration rate: 1.81 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 7.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74 years
male: 70.69 years
female: 77.52 years (1999 est.)
Total fertility rate: 1.52 children born/woman (1999 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic groups: Croat 78%, Serb 12%, Muslim 0.9%, Hungarian 0.5%,
Slovenian 0.5%, others 8.1% (1991)
Religions: Catholic 76.5%, Orthodox 11.1%, Muslim 1.2%,
Protestant 0.4%, others and unknown 10.8%
Languages: Serbo-Croatian 96%, other 4% (including Italian,
Hungarian, Czech, Slovak, and German)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 95% (1991 est.)
Population: 11,096,395 (July 1999 est.)
Age structure:
0-14 years: 22% (male 1,236,899; female 1,172,560)
15-64 years: 69% (male 3,820,255; female 3,801,768)
65 years and over: 9% (male 496,772; female 568,141) (1999 est.)
Population growth rate: 0.4% (1999 est.)
Birth rate: 12.9 births/1,000 population (1999 est.)
Death rate: 7.38 deaths/1,000 population (1999 est.)
Net migration rate: -1.52 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 7.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.78 years
male: 73.41 years
female: 78.3 years (1999 est.)
Total fertility rate: 1.58 children born/woman (1999 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51%, white 37%, black 11%, Chinese 1%
Religions: nominally 85% Roman Catholic prior to CASTRO assuming
power; Protestants, Jehovah''s Witnesses, Jews, and Santeria are also
represented
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.7%
male: 96.2%
female: 95.3% (1995 est.)
Population: 754,064 (July 1999 est.)
Age structure:
0-14 years: 24% (male 92,626; female 88,127)
15-64 years: 65% (male 249,083; female 244,750)
65 years and over: 11% (male 34,612; female 44,866) (1999 est.)
Population growth rate: 0.67% (1999 est.)
Birth rate: 13.64 births/1,000 population (1999 est.)
Death rate: 7.42 deaths/1,000 population (1999 est.)
Net migration rate: 0.44 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 7.68 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.1 years
male: 74.91 years
female: 79.39 years (1999 est.)
Total fertility rate: 2 children born/woman (1999 est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 78% (99.5% of the Greeks live in the Greek
Cypriot area; 0.5% of the Greeks live in the Turkish Cypriot area),
Turkish 18% (1.3% of the Turks live in the Greek Cypriot area; 98.7%
of the Turks live in the Turkish Cypriot area), other 4% (99.2% of
the other ethnic groups live in the Greek Cypriot area; 0.8% of the
other ethnic groups live in the Turkish Cypriot area)
Religions: Greek Orthodox 78%, Muslim 18%, Maronite, Armenian
Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 15 and over can read and write
total population: 94%
male: 98%
female: 91% (1987 est.)
Population: 10,280,513 (July 1999 est.)
Age structure:
0-14 years: 17% (male 888,292; female 845,662)
15-64 years: 69% (male 3,569,677; female 3,558,844)
65 years and over: 14% (male 545,305; female 872,733) (1999 est.)
Population growth rate: -0.01% (1999 est.)
Birth rate: 9.84 births/1,000 population (1999 est.)
Death rate: 10.86 deaths/1,000 population (1999 est.)
Net migration rate: 0.91 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 6.67 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.35 years
male: 71.01 years
female: 77.88 years (1999 est.)
Total fertility rate: 1.28 children born/woman (1999 est.)
Nationality:
noun: Czech(s)
adjective: Czech
note: 300,000 Slovaks declared themselves Czech citizens in 1994
Ethnic groups: Czech 94.4%, Slovak 3%, Polish 0.6%, German 0.5%,
Gypsy 0.3%, Hungarian 0.2%, other 1%
Religions: atheist 39.8%, Roman Catholic 39.2%, Protestant 4.6%,
Orthodox 3%, other 13.4%
Languages: Czech, Slovak
Literacy:
definition: NA
total population: 99% (est.)
male: NA%
female: NA%
Population: 5,356,845 (July 1999 est.)
Age structure:
0-14 years: 18% (male 504,182; female 478,547)
15-64 years: 67% (male 1,811,445; female 1,765,038)
65 years and over: 15% (male 331,207; female 466,426) (1999 est.)
Population growth rate: 0.38% (1999 est.)
Birth rate: 11.57 births/1,000 population (1999 est.)
Death rate: 10.97 deaths/1,000 population (1999 est.)
Net migration rate: 3.22 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 5.11 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.51 years
male: 73.83 years
female: 79.33 years (1999 est.)
Total fertility rate: 1.62 children born/woman (1999 est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Eskimo, Faroese, German
Religions: Evangelical Lutheran 91%, other Protestant and Roman
Catholic 2%, other 7% (1988)
Languages: Danish, Faroese, Greenlandic (an Eskimo dialect),
German (small minority)
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 447,439 (July 1999 est.)
Age structure:
0-14 years: 43% (male 96,222; female 96,023)
15-64 years: 54% (male 128,506; female 114,767)
65 years and over: 3% (male 6,155; female 5,766) (1999 est.)
Population growth rate: 1.51% (1999 est.)
Birth rate: 41.23 births/1,000 population (1999 est.)
Death rate: 14.41 deaths/1,000 population (1999 est.)
Net migration rate: -11.73 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 1.07 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 100.24 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 51.54 years
male: 49.48 years
female: 53.67 years (1999 est.)
Total fertility rate: 5.87 children born/woman (1999 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French, Arab, Ethiopian, and
Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official), Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 46.2%
male: 60.3%
female: 32.7% (1995 est.)
Population: 216,108,345 (July 1999 est.)
Age structure:
0-14 years: 30% (male 33,367,287; female 32,411,786)
15-64 years: 65% (male 70,541,893; female 70,866,972)
65 years and over: 5% (male 3,936,415; female 4,983,992) (1999 est.)
Population growth rate: 1.46% (1999 est.)
Birth rate: 22.78 births/1,000 population (1999 est.)
Death rate: 8.14 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 57.3 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 62.92 years
male: 60.67 years
female: 65.29 years (1999 est.)
Total fertility rate: 2.57 children born/woman (1999 est.)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%, Madurese 7.5%,
coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%, Roman Catholic 3%, Hindu
2%, Buddhist 1%, other 1% (1998)
Languages: Bahasa Indonesia (official, modified form of Malay),
English, Dutch, local dialects, the most widely spoken of which is
Javanese
Literacy:
definition: age 15 and over can read and write
total population: 83.8%
male: 89.6%
female: 78% (1995 est.)
Population: 65,179,752 (July 1999 est.)
Age structure:
0-14 years: 36% (male 11,963,438; female 11,447,191)
15-64 years: 60% (male 19,549,935; female 19,276,784)
65 years and over: 4% (male 1,561,877; female 1,380,527) (1999 est.)
Population growth rate: 1.07% (1999 est.)
Birth rate: 20.71 births/1,000 population (1999 est.)
Death rate: 5.39 deaths/1,000 population (1999 est.)
Net migration rate: -4.6 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 29.73 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.76 years
male: 68.43 years
female: 71.16 years (1999 est.)
Total fertility rate: 2.45 children born/woman (1999 est.)
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azerbaijani 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur 2%, Baloch 2%, Turkmen 2%,
other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%, Zoroastrian,
Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%, Turkic and Turkic
dialects 26%, Kurdish 9%, Luri 2%, Balochi 1%, Arabic 1%, Turkish
1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 72.1%
male: 78.4%
female: 65.8% (1994 est.)
Population: 22,427,150 (July 1999 est.)
Age structure:
0-14 years: 44% (male 4,982,510; female 4,825,129)
15-64 years: 53% (male 6,030,417; female 5,889,543)
65 years and over: 3% (male 326,223; female 373,328) (1999 est.)
Population growth rate: 3.19% (1999 est.)
Birth rate: 38.42 births/1,000 population (1999 est.)
Death rate: 6.56 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 62.41 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.52 years
male: 65.54 years
female: 67.56 years (1999 est.)
Total fertility rate: 5.12 children born/woman (1999 est.)
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%, Turkoman, Assyrian
or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni 32%-37%), Christian
or other 3%
Languages: Arabic, Kurdish (official in Kurdish regions),
Assyrian, Armenian
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 70.7%
female: 45% (1995 est.)
Population: 3,632,944 (July 1999 est.)
Age structure:
0-14 years: 21% (male 399,379; female 377,366)
15-64 years: 67% (male 1,232,072; female 1,213,364)
65 years and over: 12% (male 174,519; female 236,244) (1999 est.)
Population growth rate: 0.38% (1999 est.)
Birth rate: 13.58 births/1,000 population (1999 est.)
Death rate: 8.43 deaths/1,000 population (1999 est.)
Net migration rate: -1.31 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 5.94 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.39 years
male: 73.64 years
female: 79.32 years (1999 est.)
Total fertility rate: 1.81 children born/woman (1999 est.)
Nationality:
noun: Irishman(men), Irishwoman(men), Irish (collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 92%, Anglican 3%, Islamic 0.11%,
Jehovah''s Witness 0.1%, Jewish 0.04%, other 4.75% (1991)
Languages: English is the language generally used, Irish (Gaelic)
spoken mainly in areas located along the western seaboard
Literacy:
definition: age 15 and over can read and write
total population: 98% (1981 est.)
male: NA%
female: NA%
Population: 5,749,760 (July 1999 est.)
note: includes about 166,000 Israeli settlers in the West Bank,
about 19,000 in the Israeli-occupied Golan Heights, about 6,000 in
the Gaza Strip, and about 176,000 in East Jerusalem (August 1998
est.)
Age structure:
0-14 years: 28% (male 822,192; female 783,905)
15-64 years: 62% (male 1,792,062; female 1,783,755)
65 years and over: 10% (male 244,438; female 323,408) (1999 est.)
Population growth rate: 1.81% (1999 est.)
Birth rate: 19.83 births/1,000 population (1999 est.)
Death rate: 6.16 deaths/1,000 population (1999 est.)
Net migration rate: 4.42 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 7.78 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.61 years
male: 76.71 years
female: 80.61 years (1999 est.)
Total fertility rate: 2.68 children born/woman (1999 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/America-born 32.1%,
Israel-born 20.8%, Africa-born 14.6%, Asia-born 12.6%), non-Jewish
19.9% (mostly Arab) (1996 est.)
Religions: Judaism 80.1%, Islam 14.6% (mostly Sunni Muslim),
Christian 2.1%, other 3.2% (1996 est.)
Languages: Hebrew (official), Arabic used officially for Arab
minority, English most commonly used foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)
Population: 56,735,130 (July 1999 est.)
Age structure:
0-14 years: 14% (male 4,161,841; female 3,925,413)
15-64 years: 68% (male 19,205,293; female 19,285,848)
65 years and over: 18% (male 4,169,098; female 5,987,637) (1999 est.)
Population growth rate: -0.08% (1999 est.)
Birth rate: 9.27 births/1,000 population (1999 est.)
Death rate: 10.28 deaths/1,000 population (1999 est.)
Net migration rate: 0.17 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 6.3 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.51 years
male: 75.4 years
female: 81.82 years (1999 est.)
Total fertility rate: 1.22 children born/woman (1999 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of German-,
French-, and Slovene-Italians in the north and Albanian-Italians and
Greek-Italians in the south)
Religions: Roman Catholic 98%, other 2%
Languages: Italian, German (parts of Trentino-Alto Adige region
are predominantly German speaking), French (small French-speaking
minority in Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 96% (1990 est.)
Population: 2,652,443 (July 1999 est.)
Age structure:
0-14 years: 31% (male 421,127; female 402,593)
15-64 years: 62% (male 819,956; female 828,176)
65 years and over: 7% (male 79,747; female 100,844) (1999 est.)
Population growth rate: 0.64% (1999 est.)
Birth rate: 20.22 births/1,000 population (1999 est.)
Death rate: 5.39 deaths/1,000 population (1999 est.)
Net migration rate: -8.39 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 13.93 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.62 years
male: 73.22 years
female: 78.13 years (1999 est.)
Total fertility rate: 2.26 children born/woman (1999 est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.4%, East Indian 1.3%, white 0.2%, Chinese
0.2%, mixed 7.3%, other 0.6%
Religions: Protestant 61.3% (Church of God 21.2%, Baptist 8.8%,
Anglican 5.5%, Seventh-Day Adventist 9%, Pentecostal 7.6%, Methodist
2.7%, United Church 2.7%, Brethren 1.1%, Jehovah''s Witness 1.6%,
Moravian 1.1%), Roman Catholic 4%, other, including some spiritual
cults 34.7%
Languages: English, Creole
Literacy:
definition: age 15 and over has ever attended school
total population: 85%
male: 80.8%
female: 89.1% (1995 est.)
Population: no indigenous inhabitants
note: there are personnel who operate the Long Range Navigation
(Loran) C base and the weather and coastal services radio station
Population: 126,182,077 (July 1999 est.)
Age structure:
0-14 years: 15% (male 9,697,851; female 9,242,027)
15-64 years: 68% (male 43,405,024; female 43,023,885)
65 years and','1ec83cf5eb076c806155a00d944825022e020b167e205e6d2a2a7e5f514f0e31','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b81ea4b7a25a9ea4b03b086860c540ccb25beee55b03bf0ce0a44423956b618',1999,'AU','Australia','people-and-society',117,'over: 17% (male 8,686,347; female 12,126,943) (1999
est.)
Population growth rate: 0.2% (1999 est.)
Birth rate: 10.48 births/1,000 population (1999 est.)
Death rate: 8.12 deaths/1,000 population (1999 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 4.07 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 80.11 years
male: 77.02 years
female: 83.35 years (1999 est.)
Total fertility rate: 1.48 children born/woman (1999 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99.4%, other 0.6% (mostly Korean)
Religions: observe both Shinto and Buddhist 84%, other 16%
(including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99% (1970 est.)
male: NA%
female: NA%
Population: uninhabited
note: Millersville settlement on western side of island occasionally
used as a weather station from 1935 until World War II, when it was
abandoned; reoccupied in 1957 during the International Geophysical
Year by scientists who left in 1958; public entry is by special-use
permit from US Fish and Wildlife Service only and generally
restricted to scientists and educators; visited annually by US Fish
and Wildlife Service
Population: 89,721 (July 1999 est.)
Age structure:
0-14 years: 18% (male 8,308; female 7,663)
15-64 years: 68% (male 30,168; female 30,754)
65 years and over: 14% (male 5,348; female 7,480) (1999 est.)
Population growth rate: 0.63% (1999 est.)
Birth rate: 11.85 births/1,000 population (1999 est.)
Death rate: 9.08 deaths/1,000 population (1999 est.)
Net migration rate: 3.49 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 2.76 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.83 years
male: 76.08 years
female: 81.87 years (1999 est.)
Total fertility rate: 1.5 children born/woman (1999 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Baptist, Congregational New
Church, Methodist, Presbyterian
Languages: English (official), French (official), Norman-French
dialect spoken in country districts
Literacy: NA
Population: 197,361 (July 1999 est.)
Age structure:
0-14 years: 29% (male 29,610; female 28,485)
15-64 years: 65% (male 64,552; female 63,229)
65 years and over: 6% (male 5,443; female 6,042) (1999 est.)
Population growth rate: 1.59% (1999 est.)
Birth rate: 20.68 births/1,000 population (1999 est.)
Death rate: 4.82 deaths/1,000 population (1999 est.)
Net migration rate: 0.08 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 12.15 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.35 years
male: 72.1 years
female: 78.77 years (1999 est.)
Total fertility rate: 2.43 children born/woman (1999 est.)
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European 37.1%, Wallisian 8.4%,
Polynesian 3.8%, Indonesian 3.6%, Vietnamese 1.6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%, other 10%
Languages: French, 28 Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
Population: 3,662,265 (July 1999 est.)
Age structure:
0-14 years: 23% (male 430,105; female 409,302)
15-64 years: 65% (male 1,202,762; female 1,195,006)
65 years and over: 12% (male 184,048; female 241,042) (1999 est.)
Population growth rate: 0.99% (1999 est.)
Birth rate: 14.42 births/1,000 population (1999 est.)
Death rate: 7.53 deaths/1,000 population (1999 est.)
Net migration rate: 3.01 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 6.22 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.82 years
male: 74.55 years
female: 81.27 years (1999 est.)
Total fertility rate: 1.85 children born/woman (1999 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: New Zealand European 74.5%, Maori 9.7%, other
European 4.6%, Pacific Islander 3.8%, Asian and others 7.4%
Religions: Anglican 24%, Presbyterian 18%, Roman Catholic 15%,
Methodist 5%, Baptist 2%, other Protestant 3%, unspecified or none
33% (1986)
Languages: English (official), Maori
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 4,717,132 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,037,269; female 1,018,909)
15-64 years: 54% (male 1,236,326; female 1,297,356)
65 years and over: 2% (male 54,706; female 72,566) (1999 est.)
Population growth rate: 2.84% (1999 est.)
Birth rate: 35.04 births/1,000 population (1999 est.)
Death rate: 5.6 deaths/1,000 population (1999 est.)
Net migration rate: -1.06 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 40.47 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 67.08 years
male: 64.7 years
female: 69.56 years (1999 est.)
Total fertility rate: 4.14 children born/woman (1999 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and white) 69%, white
17%, black 9%, Amerindian 5%
Religions: Roman Catholic 95%, Protestant 5%
Languages: Spanish (official)
note: English- and Amerindian-speaking minorities on Atlantic coast
Literacy:
definition: age 15 and over can read and write
total population: 65.7%
male: 64.6%
female: 66.6% (1995 est.)
Population: 1,905 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.71% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty mutineers, Australian,
New Zealander, Polynesians
Religions: Anglican 39%, Roman Catholic 11.7%, Uniting Church in
Australia 16.4%, Seventh-Day Adventist 4.4%, none 9.2%, unknown
16.9%, other 2.4% (1986)
Languages: English (official), Norfolk a mixture of 18th century
English and ancient Tahitian
Population: 69,398 (July 1999 est.)
Age structure:
0-14 years: 24% (male 8,459; female 8,197)
15-64 years: 74% (male 24,651; female 26,949)
65 years and over: 2% (male 550; female 592) (1999 est.)
Population growth rate: 3.99% (1999 est.)
Birth rate: 22.19 births/1,000 population (1999 est.)
Death rate: 2.42 deaths/1,000 population (1999 est.)
Net migration rate: 20.14 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 6.8 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.36 years
male: 72.19 years
female: 78.72 years (1999 est.)
Total fertility rate: 1.86 children born/woman (1999 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Chamorro, Carolinians and other Micronesians,
Caucasian, Japanese, Chinese, Korean
Religions: Christian (Roman Catholic majority, although
traditional beliefs and taboos may still be found)
Languages: English, Chamorro, Carolinian
note: 86% of population speaks a language other than English at home
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 96% (1980 est.)
Population: 4,438,547 (July 1999 est.)
Age structure:
0-14 years: 20% (male 447,607; female 423,844)
15-64 years: 65% (male 1,462,906; female 1,415,992)
65 years and over: 15% (male 286,339; female 401,859) (1999 est.)
Population growth rate: 0.4% (1999 est.)
Birth rate: 12.54 births/1,000 population (1999 est.)
Death rate: 10.12 deaths/1,000 population (1999 est.)
Net migration rate: 1.62 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 4.96 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.36 years
male: 75.55 years
female: 81.35 years (1999 est.)
Total fertility rate: 1.77 children born/woman (1999 est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Germanic (Nordic, Alpine, Baltic), Lapps (Sami)
20,000
Religions: Evangelical Lutheran 87.8% (state church), other
Protestant and Roman Catholic 3.8%, none 3.2%, unknown 5.2% (1980)
Languages: Norwegian (official)
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 99% (1976 est.)
male: NA%
female: NA%
Population: 2,446,645 (July 1999 est.)
Age structure:
0-14 years: 41% (male 508,681; female 489,453)
15-64 years: 57% (male 856,062; female 535,123)
65 years and over: 2% (male 30,083; female 27,243) (1999 est.)
Population growth rate: 3.45% (1999 est.)
Birth rate: 37.98 births/1,000 population (1999 est.)
Death rate: 4.29 deaths/1,000 population (1999 est.)
Net migration rate: 0.84 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.6 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1.33 male(s)/female (1999 est.)
Infant mortality rate: 24.71 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.3 years
male: 69.31 years
female: 73.39 years (1999 est.)
Total fertility rate: 6.11 children born/woman (1999 est.)
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian, Pakistani, Sri
Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu, Indian
dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%
Population: 138,123,359 (July 1999 est.)
Age structure:
0-14 years: 41% (male 29,423,876; female 27,763,774)
15-64 years: 55% (male 38,533,918; female 36,804,592)
65 years and over: 4% (male 2,768,942; female 2,828,257) (1999 est.)
Population growth rate: 2.18% (1999 est.)
Birth rate: 33.51 births/1,000 population (1999 est.)
Death rate: 10.45 deaths/1,000 population (1999 est.)
Net migration rate: -1.3 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 91.86 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 59.38 years
male: 58.49 years
female: 60.3 years (1999 est.)
Total fertility rate: 4.73 children born/woman (1999 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan), Baloch, Muhajir
(immigrants from India and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%), Christian, Hindu,
and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a Punjabi variant)
10%, Pashtu 8%, Urdu (official) 8%, Balochi 3%, Hindko 2%, Brahui
1%, English (official and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 37.8%
male: 50%
female: 24.4% (1995 est.)
Population: 18,467 (July 1999 est.)
Age structure:
0-14 years: 27% (male 2,595; female 2,446)
15-64 years: 68% (male 6,867; female 5,675)
65 years and over: 5% (male 416; female 468) (1999 est.)
Population growth rate: 1.94% (1999 est.)
Birth rate: 21.55 births/1,000 population (1999 est.)
Death rate: 7.74 deaths/1,000 population (1999 est.)
Net migration rate: 5.63 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.21 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.15 male(s)/female (1999 est.)
Infant mortality rate: 18.5 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 67.75 years
male: 64.69 years
female: 70.98 years (1999 est.)
Total fertility rate: 2.66 children born/woman (1999 est.)
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauans are a composite of Polynesian, Malayan,
and Melanesian races
Religions: Christian (Catholics, Seventh-Day Adventists,
Jehovah''s Witnesses, the Assembly of God, the Liebenzell Mission,
and Latter-Day Saints), Modekngei religion (one-third of the
population observes this religion which is indigenous to Palau)
Languages: English (official in all of Palau''s 16 states),
Sonsorolese (official in the state of Sonsoral), Angaur and Japanese
(in the state of Anguar), Tobi (in the state of Tobi), Palauan (in
the other 13 states)
Literacy:
definition: age 15 and over can read and write
total population: 92%
male: 93%
female: 90% (1980 est.)
Population: uninhabited
Population: 2,778,526 (July 1999 est.)
Age structure:
0-14 years: 32% (male 446,792; female 429,811)
15-64 years: 63% (male 882,541; female 859,455)
65 years and over: 5% (male 76,648; female 83,279) (1999 est.)
Population growth rate: 1.53% (1999 est.)
Birth rate: 21.69 births/1,000 population (1999 est.)
Death rate: 5.14 deaths/1,000 population (1999 est.)
Net migration rate: -1.22 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 23.35 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.66 years
male: 71.91 years
female: 77.51 years (1999 est.)
Total fertility rate: 2.54 children born/woman (1999 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and white) 70%,
Amerindian and mixed (West Indian) 14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%
note: many Panamanians bilingual
Literacy:
definition: age 15 and over can read and write
total population: 90.8%
male: 91.4%
female: 90.2% (1995 est.)
Population: 4,705,126 (July 1999 est.)
Age structure:
0-14 years: 39% (male 951,532; female 902,841)
15-64 years: 58% (male 1,411,053; female 1,298,937)
65 years and over: 3% (male 64,101; female 76,662) (1999 est.)
Population growth rate: 2.26% (1999 est.)
Birth rate: 32.04 births/1,000 population (1999 est.)
Death rate: 9.47 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 55.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 58.47 years
male: 57.58 years
female: 59.4 years (1999 est.)
Total fertility rate: 4.17 children born/woman (1999 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito, Micronesian,
Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society 8%, Anglican 5%,
Evangelical Alliance 4%, Seventh-Day Adventist 1%, other Protestant
sects 10%, indigenous beliefs 34%
Languages: English spoken by 1%-2%, pidgin English widespread,
Motu spoken in Papua region
note: 715 indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 72.2%
male: 81%
female: 62.7% (1995 est.)
Population: 10,588 (July 1999 est.)
Age structure:
0-14 years: 35% (male 1,870; female 1,799)
15-64 years: 61% (male 3,062; female 3,360)
65 years and over: 4% (male 225; female 272) (1999 est.)
Population growth rate: 1.34% (1999 est.)
Birth rate: 21.91 births/1,000 population (1999 est.)
Death rate: 8.5 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 25.53 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.15 years
male: 63.01 years
female: 65.34 years (1999 est.)
Total fertility rate: 3.11 children born/woman (1999 est.)
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist) 97%, Seventh-Day
Adventist 1.4%, Baha''i 1%, other 0.6%
Languages: Tuvaluan, English
Literacy: NA; note--education is free and compulsory from ages 6
through 13
Population: 22,804,973 (July 1999 est.)
Age structure:
0-14 years: 51% (male 5,857,254; female 5,820,526)
15-64 years: 47% (male 5,301,208; female 5,330,005)
65 years and over: 2% (male 239,434; female 256,546) (1999 est.)
Population growth rate: 2.83% (1999 est.)
Birth rate: 48.54 births/1,000 population (1999 est.)
Death rate: 18.43 deaths/1,000 population (1999 est.)
Net migration rate: -1.84 migrant(s)/1,000 population (1999 est.)
note: according to the UNHCR, by the end of 1997, Uganda was host to
refugees from a number of neighboring countries, including: Sudan
160,000, Democratic Republic of the Congo 14,000, and Rwanda 12,000
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 90.68 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 43.06 years
male: 42.2 years
female: 43.94 years (1999 est.)
Total fertility rate: 7.03 children born/woman (1999 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Karamojong 12%, Basogo 8%, Iteso 8%,
Langi 6%, Rwanda 6%, Bagisu 5%, Acholi 4%, Lugbara 4%, Bunyoro 3%,
Batobo 3%, non-African (European, Asian, Arab) 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%, Muslim 16%,
indigenous beliefs 18%
Languages: English (official national language, taught in grade
schools, used in courts of law and by most newspapers and some radio
broadcasts), Ganda or Luganda (most widely used of the Niger-Congo
languages, preferred for native language publications and may be
taught in school), other Niger-Congo languages, Nilo-Saharan
languages, Swahili, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 61.8%
male: 73.7%
female: 50.2% (1995 est.)','6788d37be6c6fdea66e8bcea4efd94ef1bb745aeec88546db317881b3254359f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86410f70558b72fc2962f1848e21833bef383eb9dd138b89b7a212f2a344bccc',1999,'KM','Comoros','people-and-society',126,'Population: 50,481,305 (July 1999 est.)
Age structure:
0-14 years: 48% (male 12,200,532; female 12,136,372)
15-64 years: 49% (male 12,135,901; female 12,692,057)
65 years and over: 3% (male 564,084; female 752,359) (1999 est.)
Population growth rate: 2.96% (1999 est.)
Birth rate: 46.37 births/1,000 population (1999 est.)
Death rate: 14.99 deaths/1,000 population (1999 est.)
Net migration rate: -1.78 migrant(s)/1,000 population (1999 est.)
note: in 1994, about a million refugees fled into Zaire (now called
the Democratic Republic of the Congo or DROC), to escape the
fighting between the Hutus and the Tutsis in Rwanda and Burundi; the
outbreak of widespread fighting in the DROC between rebels and
government forces in October 1996 spurred about 875,000 refugees to
return to Rwanda in late 1996 and early 1997; additionally,the DROC
is host to 200,000 Angolan, 110,000 Burundi, 100,000 Sudanese, and
15,000 Ugandan refugees; renewed fighting in the DROC in August 1998
resulted in more internal displacement and refugee outflows
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 99.45 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 49.44 years
male: 47.28 years
female: 51.67 years (1999 est.)
Total fertility rate: 6.45 children born/woman (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of which the
majority are Bantu; the four largest tribes--Mongo, Luba, Kongo (all
Bantu), and the Mangbetu-Azande (Hamitic) make up about 45% of the
population
Religions: Roman Catholic 50%, Protestant 20%, Kimbanguist 10%,
Muslim 10%, other syncretic sects and traditional beliefs 10%
Languages: French (official), Lingala (a lingua franca trade
language), Kingwana (a dialect of Kiswahili or Swahili), Kikongo,
Tshiluba
Literacy:
definition: age 15 and over can read and write French, Lingala,
Kingwana, or Tshiluba
total population: 77.3%
male: 86.6%
female: 67.7% (1995 est.)
Population: 2,716,814 (July 1999 est.)
Age structure:
0-14 years: 42% (male 579,940; female 573,847)
15-64 years: 54% (male 718,820; female 751,911)
65 years and over: 4% (male 36,987; female 55,309) (1999 est.)
Population growth rate: 2.16% (1999 est.)
Birth rate: 37.96 births/1,000 population (1999 est.)
Death rate: 16.33 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 100.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 47.14 years
male: 45.42 years
female: 48.92 years (1999 est.)
Total fertility rate: 4.89 children born/woman (1999 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%, M''Bochi 12%, Teke 17%,
Europeans NA%; note--Europeans estimated at 8,500, mostly French,
before the 1997 civil war; may be half of that in 1998, following
the widespread destruction of foreign businesses in 1997
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and Monokutuba (lingua
franca trade languages), many local languages and dialects (of which
Kikongo has the most users)
Literacy:
definition: age 15 and over can read and write
total population: 74.9%
male: 83.1%
female: 67.2% (1995 est.)','981077667896a13b07ea48e6d9afbfe04ff848618108c4ba21b7ee71e0961620','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e16e602f18423cc471434e05eb14ccf22e706ed83e68a37f1ccef80cc81ff3',1999,'ET','Ethiopia','people-and-society',134,'Population: 20,200 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.04% (1999 est.)
Birth rate: 22.35 births/1,000 population (1999 est.)
Death rate: 5.2 deaths/1,000 population (1999 est.)
Net migration rate: -6.75 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 24.7 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.14 years
male: 69.2 years
female: 73.1 years (1999 est.)
Total fertility rate: 3.17 children born/woman (1999 est.)
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Polynesian (full blood) 81.3%, Polynesian and
European 7.7%, Polynesian and non-European 7.7%, European 2.4%,
other 0.9%
Religions: Christian (majority of populace are members of the
Cook Islands Christian Church)
Languages: English (official), Maori
Literacy: NA
Population: 381,603 (July 1999 est.)
Age structure:
0-14 years: 20% (male 40,058; female 37,810)
15-64 years: 68% (male 130,282; female 128,390)
65 years and over: 12% (male 18,996; female 26,067) (1999 est.)
Population growth rate: 0.49% (1999 est.)
Birth rate: 11.02 births/1,000 population (1999 est.)
Death rate: 7.37 deaths/1,000 population (1999 est.)
Net migration rate: 1.24 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 7.42 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.76 years
male: 75.43 years
female: 80.23 years (1999 est.)
Total fertility rate: 1.63 children born/woman (1999 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient Carthaginians and
Phoenicians, with strong elements of Italian and other Mediterranean
stock)
Religions: Roman Catholic 98%
Languages: Maltese (official), English (official)
Literacy:
definition: age 10 and over can read and write
total population: 88%
male: 88%
female: 88% (1985)','f68968ccfd9cab0310082e187c8900d4687adcfbf2faa0e7cb06df738bcf4ef8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8a6b97623615b4b90523b53bf3d7bc91d4684767e0b82010d1f1830620764de',1999,'TT','Trinidad and Tobago','people-and-society',143,'Population: 64,881 (July 1999 est.)
Age structure:
0-14 years: 27% (male 8,680; female 8,530)
15-64 years: 64% (male 21,090; female 20,294)
65 years and over: 9% (male 2,570; female 3,717) (1999 est.)
Population growth rate: -1.41% (1999 est.)
Birth rate: 16.92 births/1,000 population (1999 est.)
Death rate: 6.35 deaths/1,000 population (1999 est.)
Net migration rate: -24.69 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 8.75 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.01 years
male: 75.15 years
female: 81.01 years (1999 est.)
Total fertility rate: 1.89 children born/woman (1999 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15% (Methodist 5%,
Pentecostal 3%, Seventh-Day Adventist 3%, Baptist 2%, other 2%),
none 2%, other 6%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
female: 94% (1970 est.)
Population: 8,129,734 (July 1999 est.)
Age structure:
0-14 years: 35% (male 1,447,435; female 1,393,122)
15-64 years: 61% (male 2,501,206; female 2,426,564)
65 years and over: 4% (male 171,049; female 190,358) (1999 est.)
Population growth rate: 1.62% (1999 est.)
Birth rate: 25.97 births/1,000 population (1999 est.)
Death rate: 5.66 deaths/1,000 population (1999 est.)
Net migration rate: -4.14 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 42.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.07 years
male: 67.86 years
female: 72.4 years (1999 est.)
Total fertility rate: 3.03 children born/woman (1999 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 82.1%
male: 82%
female: 82.2% (1995 est.)
Population: 12,562,496 (July 1999 est.)
Age structure:
0-14 years: 35% (male 2,250,690; female 2,172,302)
15-64 years: 60% (male 3,745,390; female 3,833,841)
65 years and over: 5% (male 261,090; female 299,183) (1999 est.)
Population growth rate: 1.78% (1999 est.)
Birth rate: 22.26 births/1,000 population (1999 est.)
Death rate: 5.06 deaths/1,000 population (1999 est.)
Net migration rate: 0.55 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 30.69 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.16 years
male: 69.54 years
female: 74.9 years (1999 est.)
Total fertility rate: 2.63 children born/woman (1999 est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and Spanish) 55%,
Amerindian 25%, Spanish 10%, black 10%
Religions: Roman Catholic 95%
Languages: Spanish (official), Amerindian languages (especially
Quechua)
Literacy:
definition: age 15 and over can read and write
total population: 90.1%
male: 92%
female: 88.2% (1995 est.)
Population: 411,539 (July 1999 est.)
Age structure:
0-14 years: 23% (male 47,933; female 46,957)
15-64 years: 67% (male 136,058; female 138,935)
65 years and over: 10% (male 17,530; female 24,126) (1999 est.)
Population growth rate: 1.03% (1999 est.)
Birth rate: 16.3 births/1,000 population (1999 est.)
Death rate: 5.94 deaths/1,000 population (1999 est.)
Net migration rate: -0.09 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 6.76 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 79.27 years
male: 76.47 years
female: 82.13 years (1999 est.)
Total fertility rate: 1.8 children born/woman (1999 est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-Indian mixture 90%,
white 5%, East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan African 5%
Languages: French, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 92%
female: 93% (1982 est.)
Population: 120,519 (July 1999 est.)
Age structure:
0-14 years: 30% (male 18,160; female 17,524)
15-64 years: 65% (male 39,448; female 38,672)
65 years and over: 5% (male 2,762; female 3,953) (1999 est.)
Population growth rate: 0.57% (1999 est.)
Birth rate: 18.34 births/1,000 population (1999 est.)
Death rate: 5.23 deaths/1,000 population (1999 est.)
Net migration rate: -7.43 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 15.16 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.8 years
male: 72.29 years
female: 75.36 years (1999 est.)
Total fertility rate: 1.94 children born/woman (1999 est.)
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black, white, East Indian, Carib Amerindian
Religions: Anglican, Methodist, Roman Catholic, Seventh-Day
Adventist
Languages: English, French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 96%
male: 96%
female: 96% (1970 est.)
Population: 229,979 (July 1999 est.)
note: other estimates range as low as 162,000
Age structure:
0-14 years: 39% (male 45,647; female 44,141)
15-64 years: 57% (male 68,054; female 62,612)
65 years and over: 4% (male 4,477; female 5,048) (1999 est.)
Population growth rate: 2.3% (1999 est.)
Birth rate: 28.81 births/1,000 population (1999 est.)
Death rate: 5.4 deaths/1,000 population (1999 est.)
Net migration rate: -0.39 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 30.5 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.82 years
male: 67.43 years
female: 72.33 years (1999 est.)
Total fertility rate: 3.61 children born/woman (1999 est.)
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7% (persons of European
and Polynesian blood), Europeans 0.4%
Religions: Christian 99.7% (about one-half of population
associated with the London Missionary Society; includes
Congregational, Roman Catholic, Methodist, Latter-Day Saints,
Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 97% (1971 est.)
Population: 25,061 (July 1999 est.)
Age structure:
0-14 years: 16% (male 2,008; female 2,036)
15-64 years: 67% (male 8,501; female 8,294)
65 years and over: 17% (male 1,774; female 2,448) (1999 est.)
Population growth rate: 0.64% (1999 est.)
Birth rate: 10.41 births/1,000 population (1999 est.)
Death rate: 8.22 deaths/1,000 population (1999 est.)
Net migration rate: 4.23 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 5.39 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 81.47 years
male: 77.59 years
female: 85.35 years (1999 est.)
Total fertility rate: 1.51 children born/woman (1999 est.)
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
female: 95% (1976 est.)
Population: 154,878 (July 1999 est.)
Age structure:
0-14 years: 48% (male 37,322; female 36,423)
15-64 years: 48% (male 36,067; female 38,730)
65 years and over: 4% (male 2,876; female 3,460) (1999 est.)
Population growth rate: 3.14% (1999 est.)
Birth rate: 43.31 births/1,000 population (1999 est.)
Death rate: 8.08 deaths/1,000 population (1999 est.)
Net migration rate: -3.88 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 52.93 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.71 years
male: 63.18 years
female: 66.28 years (1999 est.)
Total fertility rate: 6.14 children born/woman (1999 est.)
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of Angolan
slaves), forros (descendants of freed slaves), servicais (contract
laborers from Angola, Mozambique, and Cape Verde), tongas (children
of servicais born on the islands), Europeans (primarily Portuguese)
Religions: Roman Catholic, Evangelical Protestant, Seventh-Day
Adventist
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 73%
male: 85%
female: 62% (1991 est.)
Population: 21,504,613 (July 1999 est.)
note: includes 5,321,938 non-nationals (July 1999 est.)
Age structure:
0-14 years: 43% (male 4,705,724; female 4,543,918)
15-64 years: 54% (male 6,925,020; female 4,783,570)
65 years and over: 3% (male 291,449; female 254,932) (1999 est.)
Population growth rate: 3.39% (1999 est.)
Birth rate: 37.38 births/1,000 population (1999 est.)
Death rate: 4.86 deaths/1,000 population (1999 est.)
Net migration rate: 1.4 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.45 male(s)/female
65 years and over: 1.14 male(s)/female
total population: 1.24 male(s)/female (1999 est.)
Infant mortality rate: 38.8 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.55 years
male: 68.67 years
female: 72.53 years (1999 est.)
Total fertility rate: 6.34 children born/woman (1999 est.)
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 62.8%
male: 71.5%
female: 50.2% (1995 est.)
Population: 10,051,930 (July 1999 est.)
Age structure:
0-14 years: 48% (male 2,403,384; female 2,416,791)
15-64 years: 49% (male 2,360,113; female 2,594,278)
65 years and over: 3% (male 134,765; female 142,599) (1999 est.)
Population growth rate: 3.32% (1999 est.)
Birth rate: 43.88 births/1,000 population (1999 est.)
Death rate: 10.71 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 59.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 57.83 years
male: 54.95 years
female: 60.78 years (1999 est.)
Total fertility rate: 6.11 children born/woman (1999 est.)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer 14.7%, Diola 3.7%,
Mandink 3%, Soninke 1.1%, European and Lebanese 1%, other 9.4%
Religions: Muslim 92%, indigenous beliefs 6%, Christian 2%
(mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar, Diola, Mandingo
Literacy:
definition: age 15 and over can read and write
total population: 33.1%
male: 43%
female: 23.2% (1995 est.)
Population: 11,206,847 (Serbia--10,526,478; Montenegro?680,369)
(July 1999 est.)
note: all data dealing with population is subject to considerable
error because of the dislocations caused by military action and
ethnic cleansing
Age structure:
0-14 years: Serbia--20% (male 1,102,109; female 1,025,069);
Montenegro--21% (male 75,633; female 70,464)
15-64 years: Serbia--67% (male 3,538,689; female 3,483,192);
Montenegro--68% (male 232,223; female 227,371)
65 years and over: Serbia--13% (male 595,200; female 782,219);
Montenegro--11% (male 30,829; female 43,849) (July 1999 est.)
Population growth rate: Serbia--0.02%; Montenegro?0.07% (1999 est.)
Birth rate: Serbia--12.54 births/1,000 population; Montenegro?
13.19 births/1,000 population (1999 est.)
Death rate: Serbia--9.68 deaths/1,000 population; Montenegro? 7.44
deaths/1,000 population (1999 est.)
Net migration rate: Serbia---2.65 migrants/1,000 population;
Montenegro---5.09 migrants/1,000 population (1999 est.)
Sex ratio:
at birth: Serbia--1.08 male(s)/female; Montenegro--1.08 male(s)/female
under 15 years: Serbia--1.08 male(s)/female; Montenegro--1.07
male(s)/female
15-64 years: Serbia--1.02 male(s)/female; Montenegro--1.02
male(s)/female
65 years and over: Serbia--0.76 male(s)/female; Montenegro--0.70
male(s)/female
total population: Serbia--0.99 male(s)/female; Montenegro--0.99
male(s)/female (1999 est.)
Infant mortality rate: Serbia--16.49 deaths/1,000 live births;
Montenegro--10.99 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: Serbia--73.45 years; Montenegro--76.32 years
male: Serbia--71.03 years; Montenegro-- 72.87 years
female: Serbia--76.05 years; Montenegro--80.07 years (1999 est.)
Total fertility rate: Serbia--1.74 children born/woman;
Montenegro--1.76 children born/woman (1999 est.)
Nationality:
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serbs 63%, Albanians 14%, Montenegrins 6%,
Hungarians 4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman Catholic 4%,
Protestant 1%, other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA
Population: 79,164 (July 1999 est.)
Age structure:
0-14 years: 29% (male 11,712; female 11,569)
15-64 years: 64% (male 24,879; female 26,038)
65 years and over: 7% (male 1,709; female 3,257) (1999 est.)
Population growth rate: 0.65% (1999 est.)
Birth rate: 19.39 births/1,000 population (1999 est.)
Death rate: 6.56 deaths/1,000 population (1999 est.)
Net migration rate: -6.32 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.52 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 16.65 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.95 years
male: 66.61 years
female: 75.42 years (1999 est.)
Total fertility rate: 1.97 children born/woman (1999 est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic groups: Seychellois (mixture of Asians, Africans,
Europeans)
Religions: Roman Catholic 90%, Anglican 8%, other 2%
Languages: English (official), French (official), Creole
Literacy:
definition: age 15 and over can read and write
total population: 58%
male: 56%
female: 60% (1971 est.)','763e1aa2e05016d4b56c01684a3983cedda1b6dcff19524504365dd6cd70d212','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbbd804649f78def781af7f9521e6a64ae7524021acee5fc130b9234a614f294',1999,'MX','Mexico','people-and-society',154,'Population: 67,273,906 (July 1999 est.)
Age structure:
0-14 years: 36% (male 12,260,845; female 11,712,752)
15-64 years: 61% (male 20,604,620; female 20,211,012)
65 years and over: 3% (male 1,099,517; female 1,385,160) (1999 est.)
Population growth rate: 1.82% (1999 est.)
Birth rate: 26.8 births/1,000 population (1999 est.)
Death rate: 8.27 deaths/1,000 population (1999 est.)
Net migration rate: -0.35 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 67.46 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 62.39 years
male: 60.39 years
female: 64.49 years (1999 est.)
Total fertility rate: 3.33 children born/woman (1999 est.)
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Eastern Hamitic stock (Egyptians, Bedouins, and
Berbers) 99%, Greek, Nubian, Armenian, other European (primarily
Italian and French) 1%
Religions: Muslim (mostly Sunni) 94% (official estimate), Coptic
Christian and other 6% (official estimate)
Languages: Arabic (official), English and French widely
understood by educated classes
Literacy:
definition: age 15 and over can read and write
total population: 51.4%
male: 63.6%
female: 38.8% (1995 est.)
Population: 5,839,079 (July 1999 est.)
Age structure:
0-14 years: 37% (male 1,091,500; female 1,044,658)
15-64 years: 58% (male 1,612,847; female 1,786,318)
65 years and over: 5% (male 138,052; female 165,704) (1999 est.)
Population growth rate: 1.53% (1999 est.)
Birth rate: 26.19 births/1,000 population (1999 est.)
Death rate: 6.2 deaths/1,000 population (1999 est.)
Net migration rate: -4.66 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 28.38 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.02 years
male: 66.7 years
female: 73.5 years (1999 est.)
Total fertility rate: 2.99 children born/woman (1999 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 94%, Amerindian 5%, white 1%
Religions: Roman Catholic 75%
note: there is extensive activity by Protestant groups throughout
the country; by the end of 1992, there were an estimated 1 million
Protestant evangelicals in El Salvador
Languages: Spanish, Nahua (among some Amerindians)
Literacy:
definition: age 15 and over can read and write
total population: 71.5%
male: 73.5%
female: 69.8% (1995 est.)
Population: 465,746 (July 1999 est.)
Age structure:
0-14 years: 43% (male 100,334; female 99,826)
15-64 years: 53% (male 118,248; female 129,777)
65 years and over: 4% (male 7,801; female 9,760) (1999 est.)
Population growth rate: 2.55% (1999 est.)
Birth rate: 38.49 births/1,000 population (1999 est.)
Death rate: 12.98 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
note: migration to Spain is a traditional and continuing factor;
between 80% and 90% of Equatorial Guinean nationals going to Spain
do not return
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 91.18 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.39 years
male: 52.03 years
female: 56.83 years (1999 est.)
Total fertility rate: 5 children born/woman (1999 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some Fernandinos), Rio Muni
(primarily Fang), Europeans less than 1,000, mostly Spanish
Religions: nominally Christian and predominantly Roman Catholic,
pagan practices
Languages: Spanish (official), French (official), pidgin English,
Fang, Bubi, Ibo
Literacy:
definition: age 15 and over can read and write
total population: 78.5%
male: 89.6%
female: 68.1% (1995 est.)
Population: 3,984,723 (July 1999 est.)
Age structure:
0-14 years: 43% (male 859,899; female 852,329)
15-64 years: 54% (male 1,061,921; female 1,078,102)
65 years and over: 3% (male 67,969; female 64,503) (1999 est.)
Population growth rate: 3.88% (1999 est.)
Birth rate: 42.56 births/1,000 population (1999 est.)
Death rate: 12.32 deaths/1,000 population (1999 est.)
Net migration rate: 8.53 migrant(s)/1,000 population (1999 est.)
note: it is estimated that approximately 315,000 Eritrean refugees
were still living in Sudan by the end of 1997 according to the UNHCR
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.05 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 76.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 55.74 years
male: 53.61 years
female: 57.95 years (1999 est.)
Total fertility rate: 5.96 children born/woman (1999 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and Kunama 40%, Afar
4%, Saho (Red Sea coast dwellers) 3%
Religions: Muslim, Coptic Christian, Roman Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and Kunama, Tigrinya,
minor ethnic group languages
Literacy: NA
Population: 1,408,523 (July 1999 est.)
Age structure:
0-14 years: 18% (male 130,883; female 126,112)
15-64 years: 67% (male 455,112; female 491,819)
65 years and over: 15% (male 66,700; female 137,897) (1999 est.)
Population growth rate: -0.82% (1999 est.)
Birth rate: 9.05 births/1,000 population (1999 est.)
Death rate: 14.21 deaths/1,000 population (1999 est.)
Net migration rate: -3.08 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.86 male(s)/female (1999 est.)
Infant mortality rate: 13.83 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.65 years
male: 62.61 years
female: 75 years (1999 est.)
Total fertility rate: 1.28 children born/woman (1999 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 65.1%, Russian 28.1%, Ukrainian 2.5%,
Byelorussian 1.5%, Finn 1%, other 1.8% (1998)
Religions: Evangelical Lutheran, Russian Orthodox, Estonian
Orthodox, others include Baptist, Methodist, Seventh Day Adventist,
Roman Catholic, Pentecostal, Word of Life, Seventh Day Baptist,
Judaism
Languages: Estonian (official), Russian, Ukrainian, English,
Finnish, other
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1998 est.)
Population: 59,680,383 (July 1999 est.)
Age structure:
0-14 years: 46% (male 13,787,810; female 13,703,546)
15-64 years: 51% (male 15,398,123; female 15,141,892)
65 years and over: 3% (male 745,737; female 903,275) (1999 est.)
Population growth rate: 2.16% (1999 est.)
Birth rate: 44.34 births/1,000 population (1999 est.)
Death rate: 21.43 deaths/1,000 population (1999 est.)
Net migration rate: -1.3 migrant(s)/1,000 population (1999 est.)
note: repatriation of Ethiopians who fled to Sudan, Kenya, and
Somalia for refuge from war and famine in earlier years, is expected
to continue slowly in 1998; small numbers of Sudanese and Somali
refugees, who fled to Ethiopia from the fighting in their own
countries, began returning to their homes in 1998
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 124.57 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 40.46 years
male: 39.22 years
female: 41.73 years (1999 est.)
Total fertility rate: 6.81 children born/woman (1999 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigrean 32%, Sidamo 9%,
Shankella 6%, Somali 6%, Afar 4%, Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox 35%-40%, animist
12%, other 3%-8%
Languages: Amharic, Tigrinya, Orominga, Guaraginga, Somali,
Arabic, English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)','a7b2c133e65bd65f9c52480d45c0d3a05500c504694f8329b9b275e179df2753','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3388ecb78942284c56fbb06e052b82a04beb37649db09674c3051882fcaefb4',1999,'MZ','Mozambique','people-and-society',164,'Population: no indigenous inhabitants
note: there is a small French military garrison
Population: 2,758 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.43% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic, United Free
Church, Evangelist Church, Jehovah''s Witnesses, Lutheran,
Seventh-Day Adventist
Languages: English
Population: 14,873,387 (July 1999 est.)
Age structure:
0-14 years: 45% (male 3,356,104; female 3,279,056)
15-64 years: 52% (male 3,841,248; female 3,908,209)
65 years and over: 3% (male 234,549; female 254,221) (1999 est.)
Population growth rate: 2.8% (1999 est.)
Birth rate: 41.52 births/1,000 population (1999 est.)
Death rate: 13.56 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 89.1 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 53.24 years
male: 52.01 years
female: 54.51 years (1999 est.)
Total fertility rate: 5.7 children born/woman (1999 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-Indonesian (Merina and related Betsileo),
Cotiers (mixed African, Malayo-Indonesian, and Arab
ancestry--Betsimisaraka, Tsimihety, Antaisaka, Sakalava), French,
Indian, Creole, Comoran
Religions: indigenous beliefs 52%, Christian 41%, Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 15 and over can read and write
total population: 80%
male: 88%
female: 73% (1990 est.)
Population: 10,000,416 (July 1999 est.)
Age structure:
0-14 years: 45% (male 2,265,526; female 2,246,135)
15-64 years: 52% (male 2,580,125; female 2,637,464)
65 years and over: 3% (male 112,813; female 158,353) (1999 est.)
Population growth rate: 1.57% (1999 est.)
Birth rate: 39.54 births/1,000 population (1999 est.)
Death rate: 23.84 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 132.14 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 36.3 years
male: 36.49 years
female: 36.11 years (1999 est.)
Total fertility rate: 5.48 children born/woman (1999 est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuko, Yao, Lomwe, Sena, Tonga,
Ngoni, Ngonde, Asian, European
Religions: Protestant 55%, Roman Catholic 20%, Muslim 20%,
traditional indigenous beliefs
Languages: English (official), Chichewa (official), other
languages important regionally
Literacy:
definition: age 15 and over can read and write
total population: 56.4%
male: 71.9%
female: 41.8% (1995 est.)
Population: 21,376,066 (July 1999 est.)
Age structure:
0-14 years: 35% (male 3,879,012; female 3,680,895)
15-64 years: 61% (male 6,478,910; female 6,482,909)
65 years and over: 4% (male 369,639; female 484,701) (1999 est.)
Population growth rate: 2.08% (1999 est.)
Birth rate: 26.05 births/1,000 population (1999 est.)
Death rate: 5.29 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
note: does not include illegal immigrants--large numbers from
Indonesia and smaller numbers from the Philippines, Bangladesh,
Burma, China, and India
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 21.68 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.67 years
male: 67.62 years
female: 73.9 years (1999 est.)
Total fertility rate: 3.35 children born/woman (1999 est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay and other indigenous 58%, Chinese 26%,
Indian 7%, others 9%
Religions: Islam, Buddhism, Daoism, Hinduism, Christianity,
Sikhism; note--in addition, Shamanism is practiced on East Malaysia
Languages: Bahasa Melayu (official), English, Chinese dialects
(Cantonese, Mandarin, Hokkien, Hakka, Hainan, Foochow), Tamil,
Telugu, Malalalam, Panjabi, Thai; note--in addition, in East Malaysia
several indigenous languages are spoken, the largest of which are
Iban and Kadazan
Literacy:
definition: age 15 and over can read and write
total population: 83.5%
male: 89.1%
female: 78.1% (1995 est.)
Population: 300,220 (July 1999 est.)
Age structure:
0-14 years: 47% (male 72,414; female 68,764)
15-64 years: 50% (male 76,446; female 73,275)
65 years and over: 3% (male 4,944; female 4,377) (1999 est.)
Population growth rate: 3.37% (1999 est.)
Birth rate: 39.3 births/1,000 population (1999 est.)
Death rate: 5.63 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 38.14 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.29 years
male: 66.53 years
female: 70.15 years (1999 est.)
Total fertility rate: 5.73 children born/woman (1999 est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: Sinhalese, Dravidian, Arab, African
Religions: Sunni Muslim
Languages: Maldivian Divehi (dialect of Sinhala, script derived
from Arabic), English spoken by most government officials
Literacy:
definition: age 15 and over can read and write
total population: 93.2%
male: 93.3%
female: 93% (1995 est.)
Population: 149,336 (July 1999 est.)
Age structure:
0-14 years: 47% (male 34,838; female 34,798)
15-64 years: 52% (male 42,073; female 35,068)
65 years and over: 1% (male 1,257; female 1,302) (1999 est.)
Population growth rate: 5% (1999 est.)
Birth rate: 46.12 births/1,000 population (1999 est.)
Death rate: 8.9 deaths/1,000 population (1999 est.)
Net migration rate: 12.73 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.2 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.1 male(s)/female (1999 est.)
Infant mortality rate: 69.06 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 60.02 years
male: 57.61 years
female: 62.51 years (1999 est.)
Total fertility rate: 6.41 children born/woman (1999 est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 99%, Christian (mostly Roman Catholic)
Languages: Mahorian (a Swahili dialect), French
Literacy: NA
Population: 100,294,036 (July 1999 est.)
Age structure:
0-14 years: 35% (male 17,987,500; female 17,289,875)
15-64 years: 61% (male 29,610,813; female 31,216,342)
65 years and over: 4% (male 1,873,986; female 2,315,520) (1999 est.)
Population growth rate: 1.73% (1999 est.)
Birth rate: 24.99 births/1,000 population (1999 est.)
Death rate: 4.83 deaths/1,000 population (1999 est.)
Net migration rate: -2.84 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 24.62 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72 years
male: 68.98 years
female: 75.17 years (1999 est.)
Total fertility rate: 2.85 children born/woman (1999 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%, Amerindian or
predominantly Amerindian 30%, white 9%, other 1%
Religions: nominally Roman Catholic 89%, Protestant 6%
Languages: Spanish, various Mayan, Nahuatl, and other regional
indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 89.6%
male: 91.8%
female: 87.4% (1995 est.)
Population: 131,500 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 3.3% (1999 est.)
Birth rate: 27.32 births/1,000 population (1999 est.)
Death rate: 6.01 deaths/1,000 population (1999 est.)
Net migration rate: 11.65 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 33.99 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.48 years
male: 66.52 years
female: 70.48 years (1999 est.)
Total fertility rate: 3.87 children born/woman (1999 est.)
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Kosrae(s), Pohnpeian(s), Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%, other and none 3%
Languages: English (official and common language), Trukese,
Pohnpeian, Yapese, Kosrean
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
Population: no indigenous inhabitants
Population: 4,460,838 (July 1999 est.)
Age structure:
0-14 years: 24% (male 555,096; female 535,625)
15-64 years: 66% (male 1,408,334; female 1,529,542)
65 years and over: 10% (male 160,317; female 271,924) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 14.43 births/1,000 population (1999 est.)
Death rate: 12.5 deaths/1,000 population (1999 est.)
Net migration rate: -0.92 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (1999 est.)
Infant mortality rate: 43.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.39 years
male: 59.76 years
female: 69.24 years (1999 est.)
Total fertility rate: 1.86 children born/woman (1999 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldavian/Romanian 64.5%, Ukrainian 13.8%, Russian
13%, Gagauz 3.5%, Jewish 1.5%, Bulgarian 2%, other 1.7% (1989 est.)
note: internal disputes with ethnic Russians in the Transdniester
region
Religions: Eastern Orthodox 98.5%, Jewish 1.5%, Baptist (only
about 1,000 members) (1991)
note: the large majority of churchgoers are ethnic Moldovans
Languages: Moldovan (official, virtually the same as the Romanian
language), Russian, Gagauz (a Turkish dialect)
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 99%
female: 94% (1989 est.)
Population: 32,149 (July 1999 est.)
Age structure:
0-14 years: 17% (male 2,723; female 2,645)
15-64 years: 64% (male 10,014; female 10,530)
65 years and over: 19% (male 2,302; female 3,935) (1999 est.)
Population growth rate: 0.31% (1999 est.)
Birth rate: 10.7 births/1,000 population (1999 est.)
Death rate: 11.79 deaths/1,000 population (1999 est.)
Net migration rate: 4.17 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 6.47 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.58 years
male: 75 years
female: 82.35 years (1999 est.)
Total fertility rate: 1.7 children born/woman (1999 est.)
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%, Italian 16%, other 21%
Religions: Roman Catholic 95%
Languages: French (official), English, Italian, Monegasque
Literacy: NA
Population: 2,617,379 (July 1999 est.)
Age structure:
0-14 years: 36% (male 480,087; female 464,609)
15-64 years: 60% (male 787,222; female 787,405)
65 years and over: 4% (male 42,219; female 55,837) (1999 est.)
Population growth rate: 1.45% (1999 est.)
Birth rate: 22.51 births/1,000 population (1999 est.)
Death rate: 7.97 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 64.63 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 61.81 years
male: 59.71 years
female: 64.02 years (1999 est.)
Total fertility rate: 2.6 children born/woman (1999 est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol 90%, Kazakh 4%, Chinese 2%, Russian 2%,
other 2%
Religions: predominantly Tibetan Buddhist, Muslim 4%
note: previously limited religious activity because of communist
regime
Languages: Khalkha Mongol 90%, Turkic, Russian, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 88.6%
female: 77.2% (1988 est.)','4db7d7b9b7ddd78c8a8a22a87081f021b024f9a46150fc8d493e1a2bb16a8d07','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18fa154873c31febe46fe36a206740a51290cafc6a19f8f8edbc5f700c197e3a',1999,'AR','Argentina','people-and-society',180,'Population: 41,059 (July 1999 est.)
Age structure:
0-14 years: 23% (male 4,819; female 4,629)
15-64 years: 62% (male 13,600; female 11,811)
65 years and over: 15% (male 2,786; female 3,414) (1999 est.)
Population growth rate: -2.03% (1999 est.)
Birth rate: 12.54 births/1,000 population (1999 est.)
Death rate: 9.08 deaths/1,000 population (1999 est.)
Net migration rate: -23.72 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 10.26 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.56 years
male: 75.66 years
female: 81.58 years (1999 est.)
Total fertility rate: 2.36 children born/woman (1999 est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: NA
note: similar to Denmark proper
Population: 812,918 (July 1999 est.)
Age structure:
0-14 years: 33% (male 138,796; female 133,428)
15-64 years: 63% (male 257,130; female 256,834)
65 years and over: 4% (male 12,527; female 14,203) (1999 est.)
Population growth rate: 1.28% (1999 est.)
Birth rate: 22.76 births/1,000 population (1999 est.)
Death rate: 6.21 deaths/1,000 population (1999 est.)
Net migration rate: -3.78 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 16.3 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.59 years
male: 64.19 years
female: 69.11 years (1999 est.)
Total fertility rate: 2.7 children born/woman (1999 est.)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51%, Indian 44%, European, other Pacific
Islanders, overseas Chinese, and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman Catholic 9%),
Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu, and there is
a Muslim minority (1986)
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 15 and over can read and write
total population: 91.6%
male: 93.8%
female: 89.3% (1995 est.)
Population: 5,158,372 (July 1999 est.)
Age structure:
0-14 years: 18% (male 483,700; female 464,431)
15-64 years: 67% (male 1,743,340; female 1,706,873)
65 years and over: 15% (male 289,405; female 470,623) (1999 est.)
Population growth rate: 0.15% (1999 est.)
Birth rate: 10.77 births/1,000 population (1999 est.)
Death rate: 9.67 deaths/1,000 population (1999 est.)
Net migration rate: 0.4 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 3.8 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.32 years
male: 73.81 years
female: 80.98 years (1999 est.)
Total fertility rate: 1.68 children born/woman (1999 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93%, Swede 6%, Lapp 0.11%, Gypsy 0.12%, Tatar
0.02%
Religions: Evangelical Lutheran 89%, Greek Orthodox 1%, none 9%,
other 1%
Languages: Finnish 93.5% (official), Swedish 6.3% (official),
small Lapp- and Russian-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 100% (1980 est.)
male: NA%
female: NA%
Population: 58,978,172 (July 1999 est.)
Age structure:
0-14 years: 19% (male 5,638,462; female 5,375,911)
15-64 years: 65% (male 19,302,121; female 19,235,235)
65 years and over: 16% (male 3,825,232; female 5,601,211) (1999 est.)
Population growth rate: 0.27% (1999 est.)
Birth rate: 11.38 births/1,000 population (1999 est.)
Death rate: 9.17 deaths/1,000 population (1999 est.)
Net migration rate: 0.53 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 5.62 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.63 years
male: 74.76 years
female: 82.71 years (1999 est.)
Total fertility rate: 1.61 children born/woman (1999 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic, Slavic, North
African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%, Jewish 1%, Muslim
(North African workers) 1%, unaffiliated 6%
Languages: French 100%, rapidly declining regional dialects and
languages (Provencal, Breton, Alsatian, Corsican, Catalan, Basque,
Flemish)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1980 est.)
Population: 167,982 (July 1999 est.)
Age structure:
0-14 years: 31% (male 26,713; female 25,514)
15-64 years: 64% (male 57,935; female 48,959)
65 years and over: 5% (male 4,479; female 4,382) (1999 est.)
Population growth rate: 3.19% (1999 est.)
Birth rate: 23.27 births/1,000 population (1999 est.)
Death rate: 4.52 deaths/1,000 population (1999 est.)
Net migration rate: 13.1 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.18 male(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.13 male(s)/female (1999 est.)
Infant mortality rate: 12.93 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.61 years
male: 73.41 years
female: 79.97 years (1999 est.)
Total fertility rate: 3.31 children born/woman (1999 est.)
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 12%, East Indian,
Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male: 84%
female: 82% (1982 est.)','7847ff75869c4821be0f88c51f64f4b52ea43dba5d1d2a85f77d52ea9b141f03','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6497dc44b0ca2354115eed39f06cb0341655c029415afe41f8274b0b9b84318d',1999,'NR','Nauru','people-and-society',182,'Population: 242,073 (July 1999 est.)
Age structure:
0-14 years: 33% (male 40,422; female 38,913)
15-64 years: 63% (male 78,637; female 72,832)
65 years and over: 4% (male 5,642; female 5,627) (1999 est.)
Population growth rate: 1.72% (1999 est.)
Birth rate: 22.08 births/1,000 population (1999 est.)
Death rate: 5.06 deaths/1,000 population (1999 est.)
Net migration rate: 0.19 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 1 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 13.59 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.33 years
male: 69.93 years
female: 74.85 years (1999 est.)
Total fertility rate: 2.64 children born/woman (1999 est.)
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%, local French 6%,
metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%, other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
female: 98% (1977 est.)
Population: no indigenous inhabitants
note: in 1997 there were about 100 researchers whose numbers vary
from winter (July) to summer (January)
Population: 1,225,853 (July 1999 est.)
Age structure:
0-14 years: 33% (male 205,076; female 205,198)
15-64 years: 61% (male 376,181; female 370,479)
65 years and over: 6% (male 34,078; female 34,841) (1999 est.)
Population growth rate: 1.48% (1999 est.)
Birth rate: 27.89 births/1,000 population (1999 est.)
Death rate: 13.07 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 83.1 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 56.98 years
male: 53.98 years
female: 60.08 years (1999 est.)
Total fertility rate: 3.77 children born/woman (1999 est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes including four major tribal groupings
(Fang, Eshira, Bapounou, Bateke), other Africans and Europeans
154,000, including 6,000 French and 11,000 persons of dual
nationality
Religions: Christian 55%-75%, Muslim less than 1%, animist
Languages: French (official), Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 15 and over can read and write
total population: 63.2%
male: 73.7%
female: 53.3% (1995 est.)
Population: 85,501 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 1.78% (1999 est.)
Birth rate: 26.13 births/1,000 population (1999 est.)
Death rate: 7.53 deaths/1,000 population (1999 est.)
Net migration rate: -0.77 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 48.22 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 62.88 years
male: 61.02 years
female: 64.98 years (1999 est.)
Total fertility rate: 3.09 children born/woman (1999 est.)
Nationality:
noun: I-Kiribati (singular and plural)
adjective: I-Kiribati
Ethnic groups: Micronesian
Religions: Roman Catholic 53%, Protestant (Congregational) 41%,
Seventh-Day Adventist, Baha''i, Church of God, Mormon 6% (1985 est.)
Languages: English (official), Gilbertese
Literacy: NA
Population: 21,386,109 (July 1999 est.)
Age structure:
0-14 years: 26% (male 2,800,748; female 2,666,207)
15-64 years: 68% (male 7,143,969; female 7,447,147)
65 years and over: 6% (male 412,161; female 915,877) (1999 est.)
Population growth rate: 1.45% (1999 est.)
Birth rate: 21.37 births/1,000 population (1999 est.)
Death rate: 6.92 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.45 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 25.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.07 years
male: 67.41 years
female: 72.86 years (1999 est.)
Total fertility rate: 2.3 children born/woman (1999 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a small Chinese
community and a few ethnic Japanese
Religions: Buddhism and Confucianism, some Christianity and
syncretic Chondogyo
note: autonomous religious activities now almost nonexistent;
government-sponsored religious groups exist to provide illusion of
religious freedom
Languages: Korean
Literacy:
definition: age 15 and over can read and write Korean
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 46,884,800 (July 1999 est.)
Age structure:
0-14 years: 22% (male 5,504,333; female 4,874,974)
15-64 years: 71% (male 16,949,807; female 16,432,951)
65 years and over: 7% (male 1,192,688; female 1,930,047) (1999 est.)
Population growth rate: 1% (1999 est.)
Birth rate: 15.95 births/1,000 population (1999 est.)
Death rate: 5.68 deaths/1,000 population (1999 est.)
Net migration rate: -0.3 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.13 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 7.57 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 74.3 years
male: 70.75 years
female: 78.32 years (1999 est.)
Total fertility rate: 1.79 children born/woman (1999 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about 20,000 Chinese)
Religions: Christianity 49%, Buddhism 47%, Confucianism 3%,
pervasive folk religion (shamanism), Chondogyo (Religion of the
Heavenly Way), and other 1%
Languages: Korean, English widely taught in junior high and high
school
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99.3%
female: 96.7% (1995 est.)
Population: 1,991,115 (July 1999 est.)
note: includes 1,220,935 non-nationals (July 1999 est.)
Age structure:
0-14 years: 32% (male 343,461; female 285,129)
15-64 years: 66% (male 850,689; female 468,618)
65 years and over: 2% (male 26,593; female 16,625) (1999 est.)
Population growth rate: 3.88% (1999 est.)
note: this rate reflects the continued post-Gulf crisis return of
expatriates
Birth rate: 20.45 births/1,000 population (1999 est.)
Death rate: 2.31 deaths/1,000 population (1999 est.)
Net migration rate: 20.65 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.2 male(s)/female
15-64 years: 1.82 male(s)/female
65 years and over: 1.6 male(s)/female
total population: 1.58 male(s)/female (1999 est.)
Infant mortality rate: 10.26 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.15 years
male: 75.11 years
female: 79.3 years (1999 est.)
Total fertility rate: 3.34 children born/woman (1999 est.)
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South Asian 9%,
Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 45%, Shi''a 40%), Christian, Hindu,
Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 78.6%
male: 82.2%
female: 74.9% (1995 est.)
Population: 4,546,055 (July 1999 est.)
Age structure:
0-14 years: 35% (male 804,502; female 788,076)
15-64 years: 59% (male 1,308,145; female 1,362,140)
65 years and over: 6% (male 105,442; female 177,750) (1999 est.)
Population growth rate: 0.68% (1999 est.)
Birth rate: 21.83 births/1,000 population (1999 est.)
Death rate: 8.74 deaths/1,000 population (1999 est.)
Net migration rate: -6.28 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 75.92 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63.57 years
male: 59.25 years
female: 68.1 years (1999 est.)
Total fertility rate: 2.63 children born/woman (1999 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kirghiz 52.4%, Russian 18%, Uzbek 12.9%, Ukrainian
2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%, other 5%
Languages: Kirghiz (Kyrgyz)--official language, Russian?official
language
note: in March 1996, the Kyrgyzstani legislature amended the
constitution to make Russian an official language, along with
Kirghiz, in territories and work places where Russian-speaking
citizens predominate
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
Population: 5,407,453 (July 1999 est.)
Age structure:
0-14 years: 45% (male 1,235,797; female 1,203,520)
15-64 years: 52% (male 1,360,991; female 1,434,378)
65 years and over: 3% (male 78,195; female 94,572) (1999 est.)
Population growth rate: 2.74% (1999 est.)
Birth rate: 39.93 births/1,000 population (1999 est.)
Death rate: 12.56 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 89.32 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.21 years
male: 52.63 years
female: 55.87 years (1999 est.)
Total fertility rate: 5.55 children born/woman (1999 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao Theung (upland) 22%,
Lao Soung (highland) including the Hmong ("Meo") and the Yao (Mien)
9%, ethnic Vietnamese/Chinese 1%
Religions: Buddhist 60%, animist and other 40%
Languages: Lao (official), French, English, and various ethnic
languages
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 70%
female: 48% (1998 est.)
Population: 2,353,874 (July 1999 est.)
Age structure:
0-14 years: 18% (male 216,369; female 207,242)
15-64 years: 67% (male 749,396; female 825,988)
65 years and over: 15% (male 114,038; female 240,841) (1999 est.)
Population growth rate: -1.25% (1999 est.)
Birth rate: 8.1 births/1,000 population (1999 est.)
Death rate: 15.82 deaths/1,000 population (1999 est.)
Net migration rate: -4.75 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.47 male(s)/female
total population: 0.85 male(s)/female (1999 est.)
Infant mortality rate: 17.19 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 67.3 years
male: 61.24 years
female: 73.66 years (1999 est.)
Total fertility rate: 1.18 children born/woman (1999 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%, Byelorussian 4.3%,
Ukrainian 2.8%, Polish 2.6%, other 3.4%
Religions: Lutheran, Roman Catholic, Russian Orthodox
Languages: Lettish (official), Lithuanian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 99% (1989 est.)','4bf8841b5cbfb7c0a9a113f4685631099758f0172c7dcc9b56ad573ef7c23f9b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('041f4a6424b688ff4d25245bf4c8e7196d0ea0057c9c3fbd6e3ac91ccd37fc8c',1999,'SN','Senegal','people-and-society',193,'Population: 1,336,320 (July 1999 est.)
Age structure:
0-14 years: 46% (male 305,839; female 304,905)
15-64 years: 52% (male 341,947; female 348,163)
65 years and over: 2% (male 18,706; female 16,760) (1999 est.)
Population growth rate: 3.35% (1999 est.)
Birth rate: 42.76 births/1,000 population (1999 est.)
Death rate: 12.57 deaths/1,000 population (1999 est.)
Net migration rate: 3.34 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 75.33 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 54.39 years
male: 52.02 years
female: 56.83 years (1999 est.)
Total fertility rate: 5.83 children born/woman (1999 est.)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula 18%, Wolof 16%,
Jola 10%, Serahuli 9%, other 4%), non-African 1%
Religions: Muslim 90%, Christian 9%, indigenous beliefs 1%
Languages: English (official), Mandinka, Wolof, Fula, other
indigenous vernaculars
Literacy:
definition: age 15 and over can read and write
total population: 38.6%
male: 52.8%
female: 24.9% (1995 est.)
Population: 1,112,654 (July 1999 est.)
note: in addition, there are some 6,000 Israeli settlers in the Gaza
Strip (August 1998 est.)
Age structure:
0-14 years: 52% (male 294,196; female 280,017)
15-64 years: 46% (male 255,209; female 251,317)
65 years and over: 2% (male 13,475; female 18,440) (1999 est.)
Population growth rate: 4.44% (1999 est.)
Birth rate: 48.24 births/1,000 population (1999 est.)
Death rate: 3.8 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 22.92 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.44 years
male: 72.01 years
female: 74.95 years (1999 est.)
Total fertility rate: 7.46 children born/woman (1999 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%, Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%, Christian 0.7%,
Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
Population: 5,066,499 (July 1999 est.)
Age structure:
0-14 years: 21% (male 544,055; female 522,491)
15-64 years: 67% (male 1,628,993; female 1,753,527)
65 years and over: 12% (male 236,124; female 381,309) (1999 est.)
Population growth rate: -0.74% (1999 est.)
Birth rate: 11.64 births/1,000 population (1999 est.)
Death rate: 14.3 deaths/1,000 population (1999 est.)
Net migration rate: -4.69 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.91 male(s)/female (1999 est.)
Infant mortality rate: 52.01 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.63 years
male: 61.13 years
female: 68.32 years (1999 est.)
Total fertility rate: 1.53 children born/woman (1999 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%, Russian 6.3%, Azeri
5.7%, Ossetian 3%, Abkhaz 1.8%, other 5%
Religions: Christian Orthodox 75% (Georgian Orthodox 65%, Russian
Orthodox 10%), Muslim 11%, Armenian Apostolic 8%, unknown 6%
Languages: Georgian 71% (official), Russian 9%, Armenian 7%,
Azeri 6%, other 7%
note: Abkhaz (official in Abkhazia)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est.)
Population: 82,087,361 (July 1999 est.)
Age structure:
0-14 years: 15% (male 6,495,882; female 6,172,359)
15-64 years: 69% (male 28,687,267; female 27,526,698)
65 years and over: 16% (male 4,990,090; female 8,215,065) (1999 est.)
Population growth rate: 0.01% (1999 est.)
Birth rate: 8.68 births/1,000 population (1999 est.)
Death rate: 10.76 deaths/1,000 population (1999 est.)
Net migration rate: 2.12 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 5.14 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.17 years
male: 74.01 years
female: 80.5 years (1999 est.)
Total fertility rate: 1.26 children born/woman (1999 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91.5%, Turkish 2.4%, Italians 0.7%, Greeks
0.4%, Poles 0.4%, other 4.6% (made up largely of people fleeing the
war in the former Yugoslavia)
Religions: Protestant 38%, Roman Catholic 34%, Muslim 1.7%,
unaffiliated or other 26.3%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99% (1977 est.)
male: NA%
female: NA%
Population: 18,887,626 (July 1999 est.)
Age structure:
0-14 years: 42% (male 4,020,493; female 3,982,816)
15-64 years: 54% (male 5,050,736; female 5,231,951)
65 years and over: 4% (male 284,423; female 317,207) (1999 est.)
Population growth rate: 2.05% (1999 est.)
Birth rate: 31.79 births/1,000 population (1999 est.)
Death rate: 10.4 deaths/1,000 population (1999 est.)
Net migration rate: -0.88 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 76.15 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 57.14 years
male: 55.08 years
female: 59.27 years (1999 est.)
Total fertility rate: 4.11 children born/woman (1999 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 99.8% (major tribes--Akan 44%,
Moshi-Dagomba 16%, Ewe 13%, Ga 8%), European and other 0.2%
Religions: indigenous beliefs 38%, Muslim 30%, Christian 24%,
other 8%
Languages: English (official), African languages (including Akan,
Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 15 and over can read and write
total population: 64.5%
male: 75.9%
female: 53.5% (1995 est.)
Population: 29,165 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,129; female 2,749)
15-64 years: 66% (male 10,888; female 8,247)
65 years and over: 14% (male 1,729; female 2,423) (1999 est.)
Population growth rate: 0.39% (1999 est.)
Birth rate: 12.65 births/1,000 population (1999 est.)
Death rate: 8.81 deaths/1,000 population (1999 est.)
Net migration rate: 0.03 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.14 male(s)/female
15-64 years: 1.32 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 1.17 male(s)/female (1999 est.)
Infant mortality rate: 6.47 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.37 years
male: 75.1 years
female: 81.81 years (1999 est.)
Total fertility rate: 2.16 children born/woman (1999 est.)
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Italian, English, Maltese, Portuguese, Spanish
Religions: Roman Catholic 74%, Protestant 11% (Church of England
8%, other 3%), Muslim 8%, Jewish 2%, none or other 5% (1981)
Languages: English (used in schools and for official purposes),
Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 95%
male: NA%
female: NA%
Population: uninhabited
Population: 10,707,135 (July 1999 est.)
Age structure:
0-14 years: 16% (male 878,349; female 818,311)
15-64 years: 67% (male 3,619,982; female 3,587,591)
65 years and over: 17% (male 799,053; female 1,003,849) (1999 est.)
Population growth rate: 0.41% (1999 est.)
Birth rate: 9.54 births/1,000 population (1999 est.)
Death rate: 9.44 deaths/1,000 population (1999 est.)
Net migration rate: 4.04 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 7.13 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.43 years
male: 75.87 years
female: 81.18 years (1999 est.)
Total fertility rate: 1.3 children born/woman (1999 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no ethnic divisions in','1639aabbd9203f17298152c2ae8a8660815990797d9b2faa6aee33f901ecd903','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09303aa0d1fca5de4d0e8dac81e9bbc5098198efeca8203cd26735ae6ab9782d',1999,'GR','Greece','people-and-society',201,'Religions: Greek Orthodox 98%, Muslim 1.3%, other 0.7%
Languages: Greek (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 98%
female: 93% (1991 est.)
Population: 59,827 (July 1999 est.)
Age structure:
0-14 years: 26% (male 7,789; female 7,728)
15-64 years: 68% (male 22,248; female 18,678)
65 years and over: 6% (male 1,562; female 1,822) (1999 est.)
Population growth rate: 0.84% (1999 est.)
Birth rate: 15.23 births/1,000 population (1999 est.)
Death rate: 6.79 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.19 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.12 male(s)/female (1999 est.)
Infant mortality rate: 20.06 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.1 years
male: 65.98 years
female: 74.24 years (1999 est.)
Total fertility rate: 2.14 children born/woman (1999 est.)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 87% (Eskimos and Greenland-born
whites), Danish and others 13%
Religions: Evangelical Lutheran
Languages: Eskimo dialects, Danish, Greenlandic (an Inuit dialect)
Literacy: NA
note: similar to Denmark proper
Population: 97,008 (July 1999 est.)
Age structure:
0-14 years: 43% (male 21,055; female 20,365)
15-64 years: 53% (male 27,524; female 23,766)
65 years and over: 4% (male 2,034; female 2,264) (1999 est.)
Population growth rate: 0.87% (1999 est.)
Birth rate: 27.62 births/1,000 population (1999 est.)
Death rate: 5.15 deaths/1,000 population (1999 est.)
Net migration rate: -13.74 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.16 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.09 male(s)/female (1999 est.)
Infant mortality rate: 11.13 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.6 years
male: 68.97 years
female: 74.29 years (1999 est.)
Total fertility rate: 3.57 children born/woman (1999 est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black
Religions: Roman Catholic 53%, Anglican 13.8%, other Protestant
sects 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 420,943 (July 1999 est.)
Age structure:
0-14 years: 25% (male 53,427; female 51,234)
15-64 years: 66% (male 138,215; female 141,243)
65 years and over: 9% (male 15,536; female 21,288) (1999 est.)
Population growth rate: 1.06% (1999 est.)
Birth rate: 16.33 births/1,000 population (1999 est.)
Death rate: 5.62 deaths/1,000 population (1999 est.)
Net migration rate: -0.16 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 8.54 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.01 years
male: 74.98 years
female: 81.18 years (1999 est.)
Total fertility rate: 1.82 children born/woman (1999 est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%, East Indian,
Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan African 4%,
Protestant sects 1%
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 90%
female: 90% (1982 est.)','e478c3ce2ba2731ed7e1b53d420745346c1dafb8c89a2f9cf484a22b148288f0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a10694c9dfb68771dfde0d7e46837b41de8f785b6fbf0d1bc15c064a6496dbbe',1999,'MQ','Martinique','people-and-society',214,'Population: 151,716 (July 1999 est.)
Age structure:
0-14 years: 35% (male 27,301; female 25,106)
15-64 years: 60% (male 47,691; female 42,714)
65 years and over: 5% (male 4,486; female 4,418) (1999 est.)
Population growth rate: 1.67% (1999 est.)
Birth rate: 26.52 births/1,000 population (1999 est.)
Death rate: 4.35 deaths/1,000 population (1999 est.)
Net migration rate: -5.45 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.11 male(s)/female
under 15 years: 1.09 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 1.02 male(s)/female
total population: 1.1 male(s)/female (1999 est.)
Infant mortality rate: 7.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.78 years
male: 74.6 years
female: 81.31 years (1999 est.)
Total fertility rate: 3.92 children born/woman (1999 est.)
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 47%, Filipino 25%, white 10%, Chinese,
Japanese, Korean, and other 18%
Religions: Roman Catholic 98%, other 2%
Languages: English, Chamorro, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)
Population: 12,335,580 (July 1999 est.)
Age structure:
0-14 years: 43% (male 2,688,402; female 2,578,934)
15-64 years: 54% (male 3,312,360; female 3,314,102)
65 years and over: 3% (male 207,014; female 234,768) (1999 est.)
Population growth rate: 2.68% (1999 est.)
Birth rate: 35.57 births/1,000 population (1999 est.)
Death rate: 6.8 deaths/1,000 population (1999 est.)
Net migration rate: -1.93 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 46.15 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.45 years
male: 63.78 years
female: 69.24 years (1999 est.)
Total fertility rate: 4.74 children born/woman (1999 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish--in local Spanish
called Ladino) 56%, Amerindian or predominantly Amerindian 44%
Religions: Roman Catholic, Protestant, traditional Mayan
Languages: Spanish 60%, Amerindian languages 40% (23 Amerindian
languages, including Quiche, Cakchiquel, Kekchi)
Literacy:
definition: age 15 and over can read and write
total population: 55.6%
male: 62.5%
female: 48.6% (1995 est.)','39404264d4cb8413682cf0838b0c248655ddb75992dca746ba4244744e6c8471','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b9ae97375fe1bf4c6fed1c6fa80fc06dbb8d03fcee5e57a714ae72010cadc0',1999,'GT','Guatemala','people-and-society',223,'Population: 65,386 (July 1999 est.)
Age structure:
0-14 years: 18% (male 6,012; female 5,875)
15-64 years: 66% (male 21,287; female 22,165)
65 years and over: 16% (male 4,069; female 5,978) (1999 est.)
Population growth rate: 1.27% (1999 est.)
Birth rate: 14.16 births/1,000 population (1999 est.)
Death rate: 9.44 deaths/1,000 population (1999 est.)
Net migration rate: 8.01 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 8.42 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.72 years
male: 75.78 years
female: 81.77 years (1999 est.)
Total fertility rate: 1.74 children born/woman (1999 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian, Baptist,
Congregational, Methodist
Languages: English, French, Norman-French dialect spoken in
country districts
Literacy: NA
Population: 7,538,953 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,640,158; female 1,653,184)
15-64 years: 54% (male 1,974,849; female 2,068,221)
65 years and over: 2% (male 83,859; female 118,682) (1999 est.)
Population growth rate: 0.82% (1999 est.)
Birth rate: 40.62 births/1,000 population (1999 est.)
Death rate: 17.3 deaths/1,000 population (1999 est.)
Net migration rate: -15.12 migrant(s)/1,000 population (1999 est.)
note: over the years Guinea has received up to several hundred
thousand refugees from the civil wars in Liberia and Sierra Leone,
some of whom are now returning to their own countries
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 126.32 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 46.5 years
male: 44.02 years
female: 49.06 years (1999 est.)
Total fertility rate: 5.53 children born/woman (1999 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou 20%, smaller
tribes 10%
Religions: Muslim 85%, Christian 8%, indigenous beliefs 7%
Languages: French (official), each tribe has its own language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
male: 49.9%
female: 21.9% (1995 est.)
Population: 1,234,555 (July 1999 est.)
Age structure:
0-14 years: 42% (male 260,821; female 259,520)
15-64 years: 55% (male 322,607; female 356,513)
65 years and over: 3% (male 16,233; female 18,861) (1999 est.)
Population growth rate: 2.31% (1999 est.)
Birth rate: 38.23 births/1,000 population (1999 est.)
Death rate: 15.13 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 109.5 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 49.57 years
male: 47.91 years
female: 51.28 years (1999 est.)
Total fertility rate: 5.09 children born/woman (1999 est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula 20%, Manjaca 14%,
Mandinga 13%, Papel 7%), European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%, Christian 5%
Languages: Portuguese (official), Crioulo, African languages
Literacy:
definition: age 15 and over can read and write
total population: 53.9%
male: 67.1%
female: 40.7% (1997 est.)
Population: 705,156 (July 1999 est.)
Age structure:
0-14 years: 30% (male 109,156; female 105,017)
15-64 years: 65% (male 230,624; female 227,677)
65 years and over: 5% (male 14,684; female 17,998) (1999 est.)
Population growth rate: -0.32% (1999 est.)
Birth rate: 18.23 births/1,000 population (1999 est.)
Death rate: 9.04 deaths/1,000 population (1999 est.)
Net migration rate: -12.43 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 48.64 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 61.82 years
male: 59.15 years
female: 64.61 years (1999 est.)
Total fertility rate: 2.09 children born/woman (1999 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 49%, black 32%, mixed 12%, Amerindian
6%, white and Chinese 1%
Religions: Christian 57%, Hindu 33%, Muslim 9%, other 1%
Languages: English, Amerindian dialects
Literacy:
definition: age 15 and over has ever attended school
total population: 98.1%
male: 98.6%
female: 97.5% (1995 est.)
Population: 6,884,264 (July 1999 est.)
Age structure:
0-14 years: 42% (male 1,464,529; female 1,420,772)
15-64 years: 54% (male 1,783,884; female 1,932,240)
65 years and over: 4% (male 140,932; female 141,907) (1999 est.)
Population growth rate: 1.53% (1999 est.)
Birth rate: 32.55 births/1,000 population (1999 est.)
Death rate: 13.97 deaths/1,000 population (1999 est.)
Net migration rate: -3.26 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 97.64 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 51.65 years
male: 49.53 years
female: 53.88 years (1999 est.)
Total fertility rate: 4.59 children born/woman (1999 est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto plus white 5%
Religions: Roman Catholic 80%, Protestant 16% (Baptist 10%,
Pentecostal 4%, Adventist 1%, other 1%), none 1%, other 3% (1982)
note: roughly one-half of the population also practices Voodoo
Languages: French (official) 20%, Creole
Literacy:
definition: age 15 and over can read and write
total population: 45%
male: 48%
female: 42.2% (1995 est.)
Population: uninhabited
Population: 870 (July 1999 est.)
Population growth rate: 1.15% (1999 est.)
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, various other languages
Population: 5,997,327 (July 1999 est.)
Age structure:
0-14 years: 41% (male 1,262,190; female 1,217,752)
15-64 years: 55% (male 1,643,550; female 1,665,666)
65 years and over: 4% (male 98,715; female 109,454) (1999 est.)
Population growth rate: 2.24% (1999 est.)
Birth rate: 30.98 births/1,000 population (1999 est.)
Death rate: 7.14 deaths/1,000 population (1999 est.)
Net migration rate: -1.46 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 40.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.68 years
male: 63.16 years
female: 66.27 years (1999 est.)
Total fertility rate: 3.97 children born/woman (1999 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and European) 90%,
Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 72.7%
male: 72.6%
female: 72.7% (1995 est.)
Population: 6,847,125 (July 1999 est.)
Age structure:
0-14 years: 18% (male 644,982; female 598,188)
15-64 years: 71% (male 2,397,277; female 2,490,745)
65 years and over: 11% (male 323,949; female 391,984) (1999 est.)
Population growth rate: 1.9% (1999 est.)
Birth rate: 12.9 births/1,000 population (1999 est.)
Death rate: 5.96 deaths/1,000 population (1999 est.)
Net migration rate: 12.07 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 5.2 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.91 years
male: 76.15 years
female: 81.85 years (1999 est.)
Total fertility rate: 1.39 children born/woman (1999 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%, Christian 10%
Languages: Chinese (Cantonese), English
Literacy:
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)
Population: uninhabited
note: American civilians evacuated in 1942 after Japanese air and
naval attacks during World War II; occupied by US military during
World War II, but abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service only and
generally restricted to scientists and educators; visited annually
by US Fish and Wildlife Service
Population: 10,186,372 (July 1999 est.)
Age structure:
0-14 years: 17% (male 908,434; female 865,621)
15-64 years: 68% (male 3,406,512; female 3,524,260)
65 years and over: 15% (male 552,337; female 929,208) (1999 est.)
Population growth rate: -0.2% (1999 est.)
Birth rate: 10.8 births/1,000 population (1999 est.)
Death rate: 13.29 deaths/1,000 population (1999 est.)
Net migration rate: 0.5 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 9.46 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.18 years
male: 66.85 years
female: 75.74 years (1999 est.)
Total fertility rate: 1.45 children born/woman (1999 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 89.9%, Gypsy 4%, German 2.6%, Serb 2%,
Slovak 0.8%, Romanian 0.7%
Religions: Roman Catholic 67.5%, Calvinist 20%, Lutheran 5%,
atheist and other 7.5%
Languages: Hungarian 98.2%, other 1.8%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1980 est.)
Population: 272,512 (July 1999 est.)
Age structure:
0-14 years: 23% (male 32,608; female 31,061)
15-64 years: 65% (male 89,258; female 87,449)
65 years and over: 12% (male 14,510; female 17,626) (1999 est.)
Population growth rate: 0.57% (1999 est.)
Birth rate: 14.87 births/1,000 population (1999 est.)
Death rate: 7.01 deaths/1,000 population (1999 est.)
Net migration rate: -2.17 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 5.22 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.96 years
male: 76.85 years
female: 81.19 years (1999 est.)
Total fertility rate: 2.03 children born/woman (1999 est.)
Nationality:
noun: Icelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of descendants of Norwegians
and Celts
Religions: Evangelical Lutheran 96%, other Protestant and Roman
Catholic 3%, none 1% (1988)
Languages: Icelandic
Literacy:
definition: age 15 and over can read and write
total population: 100% (1976 est.)
male: NA%
female: NA%
Population: 1,000,848,550 (July 1999 est.)
Age structure:
0-14 years: 34% (male 175,463,726; female 165,722,164)
15-64 years: 61% (male 318,004,920; female 295,245,556)
65 years and over: 5% (male 23,571,270; female 22,840,914) (1999
est.)
Population growth rate: 1.68% (1999 est.)
Birth rate: 25.39 births/1,000 population (1999 est.)
Death rate: 8.5 deaths/1,000 population (1999 est.)
Net migration rate: -0.08 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 1.03 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 60.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63.4 years
male: 62.54 years
female: 64.29 years (1999 est.)
Total fertility rate: 3.18 children born/woman (1999 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%, Mongoloid and other
3%
Religions: Hindu 80%, Muslim 14%, Christian 2.4%, Sikh 2%,
Buddhist 0.7%, Jains 0.5%, other 0.4%
Languages: English enjoys associate status but is the most
important language for national, political, and commercial
communication, Hindi the national language and primary tongue of 30%
of the people, Bengali (official), Telugu (official), Marathi
(official), Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya (official), Punjabi
(official), Assamese (official), Kashmiri (official), Sindhi
(official), Sanskrit (official), Hindustani (a popular variant of
Hindi/Urdu spoken widely throughout northern India)
note: 24 languages each spoken by a million or more persons;
numerous other languages and dialects, for the most part mutually
unintelligible
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
female: 37.7% (1995 est.)','bcd20f7e32581dae91a5a0af4620dc53bc38ec7f2c958b5caafaf37da1c8b6d7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6efa384209f099c894b8a797fd73699adc7580ce699d7efc629ff751223e8660',1999,'FR','France','people-and-society',235,'Population: no indigenous inhabitants
note: there are 1,200 US military and civilian contractor personnel
(January 1999 est.)
Population: 4,561,147 (July 1999 est.)
Age structure:
0-14 years: 43% (male 1,005,211; female 954,968)
15-64 years: 54% (male 1,265,116; female 1,200,372)
65 years and over: 3% (male 67,852; female 67,628) (1999 est.)
Population growth rate: 3.05% (1999 est.)
Birth rate: 34.31 births/1,000 population (1999 est.)
Death rate: 3.85 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 32.7 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.06 years
male: 71.15 years
female: 75.08 years (1999 est.)
Total fertility rate: 4.64 children born/woman (1999 est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1%, Armenian 1%
Religions: Sunni Muslim 96%, Christian 4% (1997 est.)
Languages: Arabic (official), English widely understood among
upper and middle classes
Literacy:
definition: age 15 and over can read and write
total population: 86.6%
male: 93.4%
female: 79.4% (1995 est.)
Population: 437,312 (July 1999 est.)
Age structure:
0-14 years: 24% (male 54,456; female 50,912)
15-64 years: 69% (male 142,575; female 158,132)
65 years and over: 7% (male 12,547; female 18,690) (1999 est.)
Population growth rate: 1.86% (1999 est.)
Birth rate: 12.5 births/1,000 population (1999 est.)
Death rate: 3.48 deaths/1,000 population (1999 est.)
Net migration rate: 9.59 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.92 male(s)/female (1999 est.)
Infant mortality rate: 4.23 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 81.88 years
male: 78.79 years
female: 85.13 years (1999 est.)
Total fertility rate: 1.27 children born/woman (1999 est.)
Nationality:
noun: Macanese (singular and plural)
adjective: Macau
Ethnic groups: Chinese 95%, Portuguese 3%, other 2%
Religions: Buddhist 50%, Roman Catholic 15%, none and other 35%
(1997 est.)
Languages: Portuguese, Chinese (Cantonese)
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 93%
female: 86% (1981 est.)
Population: 2,581,738 (July 1999 est.)
Age structure:
0-14 years: 47% (male 600,901; female 600,225)
15-64 years: 51% (male 641,481; female 678,951)
65 years and over: 2% (male 25,156; female 35,024) (1999 est.)
Population growth rate: 2.99% (1999 est.)
Birth rate: 44.1 births/1,000 population (1999 est.)
Death rate: 14.2 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 76.46 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 50.48 years
male: 47.39 years
female: 53.65 years (1999 est.)
Total fertility rate: 6.35 children born/woman (1999 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Maur 30%, black 30%
Religions: Muslim 100%
Languages: Hasaniya Arabic (official), Pular, Soninke, Wolof
(official), French
Literacy:
definition: age 15 and over can read and write
total population: 37.7%
male: 49.6%
female: 26.3% (1995 est.)','bd3502a3d9d284d582bf76c4af7e4aa3257d2f60141221f489dbb53046cb2f97','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7756288e8173b4e3c1558aec611b15ae1b13e4419cbb408f8c9e6dad1ff49e65',1999,'CN','China','people-and-society',243,'Population: uninhabited
Population: 16,824,825 (July 1999 est.)
Age structure:
0-14 years: 28% (male 2,432,519; female 2,359,375)
15-64 years: 65% (male 5,279,877; female 5,580,271)
65 years and over: 7% (male 392,934; female 779,849) (1999 est.)
Population growth rate: -0.09% (1999 est.)
Birth rate: 17.16 births/1,000 population (1999 est.)
Death rate: 10.34 deaths/1,000 population (1999 est.)
Net migration rate: -7.73 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 58.82 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63.39 years
male: 57.92 years
female: 69.13 years (1999 est.)
Total fertility rate: 2.09 children born/woman (1999 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 46%, Russian 34.7%, Ukrainian 4.9%,
German 3.1%, Uzbek 2.3%, Tatar 1.9%, other 7.1% (1996)
Religions: Muslim 47%, Russian Orthodox 44%, Protestant 2%, other
7%
Languages: Kazakh (Qazaq) (state language) 40%, Russian
(official, used in everyday business) 66%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 96% (1989 est.)
Population: 28,808,658 (July 1999 est.)
Age structure:
0-14 years: 43% (male 6,244,321; female 6,104,181)
15-64 years: 54% (male 7,845,083; female 7,826,442)
65 years and over: 3% (male 343,449; female 445,182) (1999 est.)
Population growth rate: 1.59% (1999 est.)
Birth rate: 30.8 births/1,000 population (1999 est.)
Death rate: 14.58 deaths/1,000 population (1999 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 59.07 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 47.02 years
male: 46.56 years
female: 47.49 years (1999 est.)
Total fertility rate: 3.88 children born/woman (1999 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%, Kalenjin 12%,
Kamba 11%, Kisii 6%, Meru 6%, other African 15%, non-African (Asian,
European, and Arab) 1%
Religions: Protestant 38%, Roman Catholic 28%, indigenous beliefs
26%, Muslim 7%, other 1%
Languages: English (official), Swahili (official), numerous
indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 78.1%
male: 86.3%
female: 70% (1995 est.)
Population: uninhabited','45a9ece92f665af8c5e6d9cd83812efa75b96b7b53fc3a4c3806c3531bf1c0af','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c33d93813995b4f8354c0ee93353e267c65d77315c1bb0ea0d255f9d6be4634a',1999,'SE','Sweden','people-and-society',253,'Population: 3,562,699 (July 1999 est.)
Age structure:
0-14 years: 30% (male 535,596; female 515,776)
15-64 years: 64% (male 1,084,121; female 1,196,678)
65 years and over: 6% (male 105,133; female 125,395) (1999 est.)
Population growth rate: 1.61% (1999 est.)
Birth rate: 22.5 births/1,000 population (1999 est.)
Death rate: 6.45 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 30.53 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.93 years
male: 68.34 years
female: 73.66 years (1999 est.)
Total fertility rate: 2.25 children born/woman (1999 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic groups--Alawite
or Nusayri, Druze, Isma''ilite, Shi''a, Sunni), Christian 30% (11
legally recognized Christian groups--4 Orthodox Christian, 6
Catholic, 1 Protestant), Judaism NEGL%
Languages: Arabic (official), French, English, Armenian widely
understood
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)
Population: 2,128,950 (July 1999 est.)
Age structure:
0-14 years: 40% (male 424,355; female 422,892)
15-64 years: 56% (male 573,285; female 610,636)
65 years and over: 4% (male 40,604; female 57,178) (1999 est.)
Population growth rate: 1.8% (1999 est.)
Birth rate: 31.26 births/1,000 population (1999 est.)
Death rate: 13.23 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 77.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 52.99 years
male: 51.37 years
female: 54.65 years (1999 est.)
Total fertility rate: 4.03 children born/woman (1999 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans 1,600, Asians 800
Religions: Christian 80%, rest indigenous beliefs
Languages: Sesotho (southern Sotho), English (official), Zulu,
Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 71.3%
male: 81.1%
female: 62.3% (1995 est.)
Population: 2,923,725 (July 1999 est.)
Age structure:
0-14 years: 45% (male 656,101; female 649,389)
15-64 years: 52% (male 775,429; female 738,904)
65 years and over: 3% (male 50,126; female 53,776) (1999 est.)
Population growth rate: 4.92% (1999 est.)
Birth rate: 41.49 births/1,000 population (1999 est.)
Death rate: 11.03 deaths/1,000 population (1999 est.)
Net migration rate: 18.77 migrant(s)/1,000 population (1999 est.)
note: evidence from UNHCR indicates Liberians are being repatriated
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 100.63 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 59.88 years
male: 57.2 years
female: 62.64 years (1999 est.)
Total fertility rate: 6.02 children born/woman (1999 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95% (including Kpelle,
Bassa, Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai,
and Bella), Americo-Liberians 2.5% (descendants of immigrants from
the US who had been slaves)
Religions: traditional 70%, Muslim 20%, Christian 10%
Languages: English 20% (official), about 20 tribal languages, of
which a few can be written and are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1995 est.)
note: these figures are increasing because of the improving school
system
Population: 4,992,838 (July 1999 est.)
note: includes 161,251 non-nationals (July 1999 est.)
Age structure:
0-14 years: 36% (male 930,661; female 891,046)
15-64 years: 60% (male 1,545,958; female 1,437,120)
65 years and over: 4% (male 93,726; female 94,327) (1999 est.)
Population growth rate: 2.4% (1999 est.)
Birth rate: 27.33 births/1,000 population (1999 est.)
Death rate: 3.35 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1.06 male(s)/female (1999 est.)
Infant mortality rate: 28.15 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.73 years
male: 73.81 years
female: 77.74 years (1999 est.)
Total fertility rate: 3.79 children born/woman (1999 est.)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks, Maltese, Italians,
Egyptians, Pakistanis, Turks, Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely understood in
the major cities
Literacy:
definition: age 15 and over can read and write
total population: 76.2%
male: 87.9%
female: 63% (1995 est.)','c0c7b23ded6ebdbd102c52246133a9194c344cd41782833ae2a048de0a2961c2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84be534fbd85d6d7c158f1e67a16e4af9c2e0f9fc8f8bd52b9630325b8423870',1999,'EG','Egypt','people-and-society',262,'Population: 32,057 (July 1999 est.)
Age structure:
0-14 years: 19% (male 3,076; female 2,949)
15-64 years: 70% (male 11,209; female 11,247)
65 years and over: 11% (male 1,484; female 2,092) (1999 est.)
Population growth rate: 1.08% (1999 est.)
Birth rate: 12.23 births/1,000 population (1999 est.)
Death rate: 7.33 deaths/1,000 population (1999 est.)
Net migration rate: 5.9 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 5.23 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.11 years
male: 75.64 years
female: 80.69 years (1999 est.)
Total fertility rate: 1.6 children born/woman (1999 est.)
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish, and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%, unknown 7.7%,
other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 10 and over can read and write
total population: 100%
male: 100%
female: 100% (1981 est.)
Population: 3,584,966 (July 1999 est.)
Age structure:
0-14 years: 20% (male 365,149; female 350,070)
15-64 years: 67% (male 1,156,161; female 1,239,145)
65 years and over: 13% (male 160,963; female 313,478) (1999 est.)
Population growth rate: -0.4% (1999 est.)
Birth rate: 10.52 births/1,000 population (1999 est.)
Death rate: 12.93 deaths/1,000 population (1999 est.)
Net migration rate: -1.58 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 14.71 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.96 years
male: 62.91 years
female: 75.31 years (1999 est.)
Total fertility rate: 1.45 children born/woman (1999 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%, Polish 7%,
Byelorussian 1.6%, other 2.1%
Religions: primarily Roman Catholic, others include Lutheran,
Russian Orthodox, Protestant, evangelical Christian Baptist, Islam,
Judaism
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 98% (1989 est.)
Population: 429,080 (July 1999 est.)
Age structure:
0-14 years: 18% (male 39,701; female 37,998)
15-64 years: 67% (male 146,336; female 140,717)
65 years and over: 15% (male 26,201; female 38,127) (1999 est.)
Population growth rate: 0.88% (1999 est.)
Birth rate: 10.35 births/1,000 population (1999 est.)
Death rate: 9.32 deaths/1,000 population (1999 est.)
Net migration rate: 7.78 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 4.99 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.65 years
male: 74.58 years
female: 80.83 years (1999 est.)
Total fertility rate: 1.57 children born/woman (1999 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and German blend),
Portuguese, Italian, and European (guest and worker residents)
Religions: Roman Catholic 97%, Protestant and Jewish 3%
Languages: Luxembourgian, German, French, English
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)','81337880649c7a6f7a1a762abd047f2118b8b4da26092b134ff3a4b1065cc31b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca5367275e2b83fd7e6f32e0c8e5f36235a815fd908732930f1d82c69360039f',1999,'HK','Hong Kong','people-and-society',272,'Population: 2,022,604 (July 1999 est.)
note: the Macedonian Government census of July 1994 put the
population at 1.94 million, but ethnic allocations were likely
undercounted
Age structure:
0-14 years: 23% (male 243,190; female 228,491)
15-64 years: 67% (male 680,692; female 673,923)
65 years and over: 10% (male 88,116; female 108,192) (1999 est.)
Population growth rate: 0.64% (1999 est.)
Birth rate: 15.21 births/1,000 population (1999 est.)
Death rate: 8.03 deaths/1,000 population (1999 est.)
Net migration rate: -0.83 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 18.68 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.05 years
male: 70.93 years
female: 75.34 years (1999 est.)
Total fertility rate: 2 children born/woman (1999 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups: Macedonian 66%, Albanian 23%, Turkish 4%, Serb 2%,
Gypsies 3%, other 2%
Religions: Eastern Orthodox 67%, Muslim 30%, other 3%
Languages: Macedonian 70%, Albanian 21%, Turkish 3%,
Serbo-Croatian 3%, other 3%
Literacy: NA','906529049d7bae7276b71dad6e815c2f61c50307cd399b37b709c4b6bf783282','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7b52910f6f8b8d7cd02aff59c856208d05518e9ede7c18967cb50b61c0468c0',1999,'TH','Thailand','people-and-society',279,'Population: 10,429,124 (July 1999 est.)
Age structure:
0-14 years: 47% (male 2,482,301; female 2,460,894)
15-64 years: 49% (male 2,447,712; female 2,708,978)
65 years and over: 4% (male 155,178; female 174,061) (1999 est.)
Population growth rate: 3.01% (1999 est.)
Birth rate: 49.5 births/1,000 population (1999 est.)
Death rate: 18.56 deaths/1,000 population (1999 est.)
Net migration rate: -0.87 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 119.44 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 47.5 years
male: 46.09 years
female: 48.96 years (1999 est.)
Total fertility rate: 6.96 children born/woman (1999 est.)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke, Sarakole), Peul 17%,
Voltaic 12%, Songhai 6%, Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%, Christian 1%
Languages: French (official), Bambara 80%, numerous African
languages
Literacy:
definition: age 15 and over can read and write
total population: 31%
male: 39.4%
female: 23.1% (1995 est.)','5fdf1165397fe5e2d860d0d220d4120170476d10999e67aa8881bc6f886edefc','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80a15bdfe842d04c861a7321077051ed02ecebd236bdde4e8fd080c8f9f02ac7',1999,'MT','Malta','people-and-society',288,'Population: 75,686 (July 1999 est.)
Age structure:
0-14 years: 18% (male 6,906; female 6,597)
15-64 years: 65% (male 24,655; female 24,604)
65 years and over: 17% (male 5,156; female 7,768) (1999 est.)
Population growth rate: 0.71% (1999 est.)
Birth rate: 12.43 births/1,000 population (1999 est.)
Death rate: 11.52 deaths/1,000 population (1999 est.)
Net migration rate: 6.17 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 2.45 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.79 years
male: 74.28 years
female: 81.47 years (1999 est.)
Total fertility rate: 1.67 children born/woman (1999 est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist, Baptist,
Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy: NA
Population: 65,507 (July 1999 est.)
Age structure:
0-14 years: 50% (male 16,622; female 15,957)
15-64 years: 48% (male 16,106; female 15,386)
65 years and over: 2% (male 677; female 759) (1999 est.)
Population growth rate: 3.86% (1999 est.)
Birth rate: 45.31 births/1,000 population (1999 est.)
Death rate: 6.73 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.04 male(s)/female (1999 est.)
Infant mortality rate: 43.38 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.81 years
male: 63.21 years
female: 66.5 years (1999 est.)
Total fertility rate: 6.67 children born/woman (1999 est.)
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Christian (mostly Protestant)
Languages: English (universally spoken and is the official
language), two major Marshallese dialects from the Malayo-Polynesian
family, Japanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 100%
female: 88% (1980 est.)','ad65afce8c77cf3cf68abf050b3f386decf1f653ba67b9eb463e9302cc9c3db6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdb5e6c5fe07c0d0e910e46a9a9a823146348e1340ee6b9e5efddc8cc959f355',1999,'MG','Madagascar','people-and-society',290,'Population: 1,182,212 (July 1999 est.)
Age structure:
0-14 years: 26% (male 156,616; female 153,698)
15-64 years: 68% (male 398,557; female 402,674)
65 years and over: 6% (male 28,586; female 42,081) (1999 est.)
Population growth rate: 1.18% (1999 est.)
Birth rate: 18.49 births/1,000 population (1999 est.)
Death rate: 6.69 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 16.2 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 71.09 years
male: 67.21 years
female: 74.96 years (1999 est.)
Total fertility rate: 2.21 children born/woman (1999 est.)
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%, Sino-Mauritian 3%,
Franco-Mauritian 2%
Religions: Hindu 52%, Christian 28.3% (Roman Catholic 26%,
Protestant 2.3%), Muslim 16.6%, other 3.1%
Languages: English (official), Creole, French, Hindi, Urdu,
Hakka, Bojpoori
Literacy:
definition: age 15 and over can read and write
total population: 82.9%
male: 87.1%
female: 78.8% (1995 est.)
Population: 717,723 (July 1999 est.)
Age structure:
0-14 years: 32% (male 118,401; female 112,878)
15-64 years: 62% (male 218,952; female 225,292)
65 years and over: 6% (male 17,506; female 24,694) (1999 est.)
Population growth rate: 1.75% (1999 est.)
Birth rate: 22.16 births/1,000 population (1999 est.)
Death rate: 4.64 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 6.9 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.73 years
male: 72.69 years
female: 78.93 years (1999 est.)
Total fertility rate: 2.64 children born/woman (1999 est.)
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese, Pakistani,
Indian
Religions: Roman Catholic 86%, Hindu, Islam, Buddhist (1995)
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)
Population: 22,334,312 (July 1999 est.)
Age structure:
0-14 years: 19% (male 2,117,289; female 2,027,940)
15-64 years: 68% (male 7,563,695; female 7,663,491)
65 years and over: 13% (male 1,234,760; female 1,727,137) (1999 est.)
Population growth rate: -0.23% (1999 est.)
Birth rate: 10.09 births/1,000 population (1999 est.)
Death rate: 11.55 deaths/1,000 population (1999 est.)
Net migration rate: -0.87 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 18.12 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.83 years
male: 67.05 years
female: 74.81 years (1999 est.)
Total fertility rate: 1.27 children born/woman (1999 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.1%, Hungarian 8.9%, German 0.4%,
Ukrainian, Serb, Croat, Russian, Turk, and Gypsy 1.6%
Religions: Romanian Orthodox 70%, Roman Catholic 6% (of which 3%
are Uniate), Protestant 6%, unaffiliated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Population: 146,393,569 (July 1999 est.)
Age structure:
0-14 years: 19% (male 14,224,033; female 13,666,440)
15-64 years: 68% (male 48,407,409; female 51,768,664)
65 years and over: 13% (male 5,698,356; female 12,628,667) (1999
est.)
Population growth rate: -0.33% (1999 est.)
Birth rate: 9.64 births/1,000 population (1999 est.)
Death rate: 14.96 deaths/1,000 population (1999 est.)
Net migration rate: 2.05 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.45 male(s)/female
total population: 0.88 male(s)/female (1999 est.)
Infant mortality rate: 23 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 65.12 years
male: 58.83 years
female: 71.72 years (1999 est.)
Total fertility rate: 1.34 children born/woman (1999 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 81.5%, Tatar 3.8%, Ukrainian 3%, Chuvash
1.2%, Bashkir 0.9%, Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)
Population: 8,154,933 (July 1999 est.)
Age structure:
0-14 years: 44% (male 1,807,695; female 1,793,590)
15-64 years: 53% (male 2,148,477; female 2,179,119)
65 years and over: 3% (male 92,490; female 133,562) (1999 est.)
Population growth rate: 2.43% (1999 est.)
Birth rate: 38.97 births/1,000 population (1999 est.)
Death rate: 19.53 deaths/1,000 population (1999 est.)
Net migration rate: 4.91 migrant(s)/1,000 population (1999 est.)
note: following the outbreak of genocidal strife in Rwanda in April
1994 between Tutsi and Hutu factions, more than 2 million refugees
fled to neighboring Burundi, Tanzania, Uganda, and Democratic
Republic of the Congo (formerly Zaire); according to the UN High
Commission on Refugees, in 1996 and early 1997 nearly 1.3 million
Hutus returned to Rwanda--of these 720,000 returned from Democratic
Republic of the Congo, 480,000 from Tanzania, 88,000 from Burundi,
and 10,000 from Uganda; probably fewer than 100,000 Rwandans
remained outside of Rwanda by the end of 1997
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 112.86 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 41.31 years
male: 40.84 years
female: 41.8 years (1999 est.)
Total fertility rate: 5.8 children born/woman (1999 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 80%, Tutsi 19%, Twa (Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%, Muslim 1%,
indigenous beliefs and other 25%
Languages: Kinyarwanda (official) universal Bantu vernacular,
French (official), English (official), Kiswahili (Swahili) used in
commercial centers
Literacy:
definition: age 15 and over can read and write
total population: 60.5%
male: 69.8%
female: 51.6% (1995 est.)
Population: uninhabited
Population: 9,513,603 (July 1999 est.)
Age structure:
0-14 years: 31% (male 1,513,296; female 1,417,166)
15-64 years: 63% (male 3,006,029; female 3,018,411)
65 years and over: 6% (male 283,026; female 275,675) (1999 est.)
Population growth rate: 1.39% (1999 est.)
Birth rate: 19.72 births/1,000 population (1999 est.)
Death rate: 5.05 deaths/1,000 population (1999 est.)
Net migration rate: -0.74 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1.03 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 31.38 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.35 years
male: 71.95 years
female: 74.86 years (1999 est.)
Total fertility rate: 2.38 children born/woman (1999 est.)
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and other 1%
Languages: Arabic (official and one of the languages of
commerce), French (commerce)
Literacy:
definition: age 15 and over can read and write
total population: 66.7%
male: 78.6%
female: 54.6% (1995 est.)
Population: 65,599,206 (July 1999 est.)
Age structure:
0-14 years: 30% (male 10,148,457; female 9,781,452)
15-64 years: 64% (male 21,255,506; female 20,560,070)
65 years and over: 6% (male 1,775,164; female 2,078,557) (1999 est.)
Population growth rate: 1.57% (1999 est.)
Birth rate: 20.92 births/1,000 population (1999 est.)
Death rate: 5.27 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 35.81 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.29 years
male: 70.81 years
female: 75.88 years (1999 est.)
Total fertility rate: 2.41 children born/woman (1999 est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2% (Christian and
Jews)
Languages: Turkish (official), Kurdish, Arabic
Literacy:
definition: age 15 and over can read and write
total population: 82.3%
male: 91.7%
female: 72.4% (1995 est.)
Population: 4,366,383 (July 1999 est.)
Age structure:
0-14 years: 38% (male 845,584; female 813,223)
15-64 years: 58% (male 1,243,031; female 1,283,985)
65 years and over: 4% (male 68,496; female 112,064) (1999 est.)
Population growth rate: 1.58% (1999 est.)
Birth rate: 25.91 births/1,000 population (1999 est.)
Death rate: 8.77 deaths/1,000 population (1999 est.)
Net migration rate: -1.35 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 73.1 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 61.11 years
male: 57.48 years
female: 64.91 years (1999 est.)
Total fertility rate: 3.21 children born/woman (1999 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%, Russian 6.7%, Kazakh 2%,
other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%, unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek 9%, other 7%
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)','d3c818e5e9f929968cf4d9e982ec98aaa8249519bba09d8928bd5cb6d346a16a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c44bf37ab58e3af3d20bc058f72212db5a5f3cf03475fc2b7b8b075c7b497e84',1999,'HN','Honduras','people-and-society',301,'Population: 9,962,242 (July 1999 est.)
Age structure:
0-14 years: 48% (male 2,445,536; female 2,346,844)
15-64 years: 50% (male 2,421,971; female 2,518,248)
65 years and over: 2% (male 121,253; female 108,390) (1999 est.)
Population growth rate: 2.95% (1999 est.)
Birth rate: 52.31 births/1,000 population (1999 est.)
Death rate: 22.78 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 male(s)/female (1999 est.)
Infant mortality rate: 112.79 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 41.96 years
male: 42.22 years
female: 41.7 years (1999 est.)
Total fertility rate: 7.24 children born/woman (1999 est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula 8.5%, Tuareg 8%, Beri
Beri (Kanouri) 4.3%, Arab, Toubou, and Gourmantche 1.2%, about 1,200
French expatriates
Religions: Muslim 80%, remainder indigenous beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 13.6%
male: 20.9%
female: 6.6% (1995 est.)
Population: 113,828,587 (July 1999 est.)
Age structure:
0-14 years: 45% (male 25,613,974; female 25,397,166)
15-64 years: 52% (male 30,272,539; female 29,197,611)
65 years and over: 3% (male 1,678,732; female 1,668,565) (1999 est.)
Population growth rate: 2.92% (1999 est.)
Birth rate: 41.84 births/1,000 population (1999 est.)
Death rate: 12.98 deaths/1,000 population (1999 est.)
Net migration rate: 0.31 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 69.46 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 53.3 years
male: 52.55 years
female: 54.06 years (1999 est.)
Total fertility rate: 6.02 children born/woman (1999 est.)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Hausa, Fulani, Yoruba, Ibo, Ijaw, Kanuri, Ibibio,
Tiv
Religions: Muslim 50%, Christian 40%, indigenous beliefs 10%
Languages: English (official), Hausa, Yoruba, Ibo, Fulani
Literacy:
definition: age 15 and over can read and write
total population: 57.1%
male: 67.3%
female: 47.3% (1995 est.)','0167165633481b3763e95036f14513c201128ccd328c31d3f03d5e64926790bb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f738fa251aee3b9b6189ed7fc7728433ca670eb76582a60085b1fde605b5f58a',1999,'TO','Tonga','people-and-society',308,'Population: 2,103 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.5% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Polynesian (with some 200 Europeans, Samoans, and
Tongans)
Religions: Ekalesia Niue (Niuean Church) 75%--a Protestant church
closely related to the London Missionary Society, Latter-Day Saints
10%, other 15% (mostly Roman Catholic, Jehovah''s Witnesses,
Seventh-Day Adventist)
Languages: Polynesian closely related to Tongan and Samoan,
English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','f64d12e693c51e6ab9bf8187d2daaee2862e68df8a46477ba2f58ce62c04c011','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4ab43511fd18ffe3d6e2bfc7aa307a47ea99cb4d933e6edaf862ddd18fadd3a',1999,'BR','Brazil','people-and-society',315,'Population: 5,434,095 (July 1999 est.)
Age structure:
0-14 years: 39% (male 1,086,107; female 1,049,833)
15-64 years: 56% (male 1,528,127; female 1,517,213)
65 years and over: 5% (male 116,761; female 136,054) (1999 est.)
Population growth rate: 2.65% (1999 est.)
Birth rate: 31.87 births/1,000 population (1999 est.)
Death rate: 5.23 deaths/1,000 population (1999 est.)
Net migration rate: -0.09 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 36.35 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.43 years
male: 70.47 years
female: 74.49 years (1999 est.)
Total fertility rate: 4.22 children born/woman (1999 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and Amerindian) 95%, white
plus Amerindian 5%
Religions: Roman Catholic 90%, Mennonite and other Protestant
denominations
Languages: Spanish (official), Guarani
Literacy:
definition: age 15 and over can read and write
total population: 92.1%
male: 93.5%
female: 90.6% (1995 est.)
Population: 26,624,582 (July 1999 est.)
Age structure:
0-14 years: 35% (male 4,786,048; female 4,637,280)
15-64 years: 60% (male 8,045,747; female 7,939,760)
65 years and over: 5% (male 557,252; female 658,495) (1999 est.)
Population growth rate: 1.93% (1999 est.)
Birth rate: 26.09 births/1,000 population (1999 est.)
Death rate: 5.7 deaths/1,000 population (1999 est.)
Net migration rate: -1.13 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (1999 est.)
Infant mortality rate: 38.97 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.38 years
male: 68.08 years
female: 72.78 years (1999 est.)
Total fertility rate: 3.23 children born/woman (1999 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed Amerindian and
white) 37%, white 15%, black, Japanese, Chinese, and other 3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua (official), Aymara
Literacy:
definition: age 15 and over can read and write
total population: 88.7%
male: 94.5%
female: 83% (1995 est.)
Population: 79,345,812 (July 1999 est.)
Age structure:
0-14 years: 37% (male 15,057,698; female 14,555,430)
15-64 years: 59% (male 23,168,043; female 23,715,877)
65 years and over: 4% (male 1,269,522; female 1,579,242) (1999 est.)
Population growth rate: 2.04% (1999 est.)
Birth rate: 27.88 births/1,000 population (1999 est.)
Death rate: 6.45 deaths/1,000 population (1999 est.)
Net migration rate: -1.03 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 33.89 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 66.58 years
male: 63.79 years
female: 69.5 years (1999 est.)
Total fertility rate: 3.46 children born/woman (1999 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91.5%, Muslim Malay 4%, Chinese
1.5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%, Muslim 5%, Buddhist
and other 3%
Languages: Pilipino (official, based on Tagalog), English
(official)
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)
Population: 49 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -2.04% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty mutineers and their
Tahitian wives
Religions: Seventh-Day Adventist 100%
Languages: English (official), Pitcairnese, Tahitian, 18th
century English dialect
Population: 38,608,929 (July 1999 est.)
Age structure:
0-14 years: 20% (male 3,921,093; female 3,734,223)
15-64 years: 68% (male 13,076,231; female 13,243,716)
65 years and over: 12% (male 1,762,135; female 2,871,531) (1999 est.)
Population growth rate: 0.05% (1999 est.)
Birth rate: 10.61 births/1,000 population (1999 est.)
Death rate: 9.72 deaths/1,000 population (1999 est.)
Net migration rate: -0.4 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 12.76 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 73.06 years
male: 68.93 years
female: 77.41 years (1999 est.)
Total fertility rate: 1.45 children born/woman (1999 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 97.6%, German 1.3%, Ukrainian 0.6%,
Byelorussian 0.5% (1990 est.)
Religions: Roman Catholic 95% (about 75% practicing), Eastern
Orthodox, Protestant, and other 5%
Languages: Polish
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1978 est.)
Population: 9,918,040 (July 1999 est.)
Age structure:
0-14 years: 17% (male 866,115; female 820,438)
15-64 years: 68% (male 3,283,345; female 3,428,427)
65 years and over: 15% (male 619,086; female 900,629) (1999 est.)
Population growth rate: -0.13% (1999 est.)
Birth rate: 10.49 births/1,000 population (1999 est.)
Death rate: 10.25 deaths/1,000 population (1999 est.)
Net migration rate: -1.51 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 6.73 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.88 years
male: 72.51 years
female: 79.46 years (1999 est.)
Total fertility rate: 1.34 children born/woman (1999 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock; citizens of black
African descent who immigrated to mainland during decolonization
number less than 100,000
Religions: Roman Catholic 97%, Protestant denominations 1%, other
2%
Languages: Portuguese
Literacy:
definition: age 15 and over can read and write
total population: 85%
male: 89%
female: 82% (1990 est.)
Population: 3,887,652 (July 1999 est.)
Age structure:
0-14 years: 24% (male 482,111; female 459,940)
15-64 years: 65% (male 1,220,682; female 1,323,787)
65 years and over: 11% (male 173,133; female 227,999) (1999 est.)
Population growth rate: 0.59% (1999 est.)
Birth rate: 15.9 births/1,000 population (1999 est.)
Death rate: 7.87 deaths/1,000 population (1999 est.)
Net migration rate: -2.15 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.93 male(s)/female (1999 est.)
Infant mortality rate: 10.79 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 75.06 years
male: 70.95 years
female: 79.41 years (1999 est.)
Total fertility rate: 1.94 children born/woman (1999 est.)
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: Hispanic
Religions: Roman Catholic 85%, Protestant denominations and other
15%
Languages: Spanish, English
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 90%
female: 88% (1980 est.)','e1768efc4b54f2c70d7f519e9a0e7ec8003ffa4cd1dd6af468efebb72fefc384','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5446ccaa3b9c7e22b84e82f6f3230ea46073f608a52b11a6dd0d4f235a6485af',1999,'SC','Seychelles','people-and-society',333,'Population: 5,296,651 (July 1999 est.)
Age structure:
0-14 years: 45% (male 1,182,181; female 1,219,956)
15-64 years: 52% (male 1,307,475; female 1,423,046)
65 years and over: 3% (male 82,374; female 81,619) (1999 est.)
Population growth rate: 4.34% (1999 est.)
Birth rate: 45.62 births/1,000 population (1999 est.)
Death rate: 16.77 deaths/1,000 population (1999 est.)
Net migration rate: 14.5 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 0.94 male(s)/female (1999 est.)
Infant mortality rate: 126.23 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 49.13 years
male: 46.07 years
female: 52.27 years (1999 est.)
Total fertility rate: 6.16 children born/woman (1999 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne 30%, Mende
30%, other 30%), Creole 10% (descendents of freed Jamaican slaves
who were settled in the Freetown area in the late-eighteenth
century), refugees from Liberia''s recent civil war, small numbers of
Europeans, Lebanese, Pakistanis, and Indians
Religions: Muslim 60%, indigenous beliefs 30%, Christian 10%
Languages: English (official, regular use limited to literate
minority), Mende (principal vernacular in the south), Temne
(principal vernacular in the north), Krio (English-based Creole,
spoken by the descendents of freed Jamaican slaves who were settled
in the Freetown area, a lingua franca and a first language for 10%
of the population but understood by 95%)
Literacy:
definition: age 15 and over can read and write English, Mende,
Temne, or Arabic
total population: 31.4%
male: 45.4%
female: 18.2% (1995 est.)','8e134ddeb4fd5ccb9c2ca9ee1468b94828e571756fe35423efa980ccf868378b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbe260b053e754a0d0a07ac93cc0a4a113c184f13cc665585e6a5c0be44b0926',1999,'GI','Gibraltar','people-and-society',340,'Population: 39,167,744 (July 1999 est.)
Age structure:
0-14 years: 15% (male 3,012,907; female 2,835,455)
15-64 years: 68% (male 13,411,046; female 13,406,214)
65 years and over: 17% (male 2,702,654; female 3,799,468) (1999 est.)
Population growth rate: 0.1% (1999 est.)
Birth rate: 9.99 births/1,000 population (1999 est.)
Death rate: 9.69 deaths/1,000 population (1999 est.)
Net migration rate: 0.66 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (1999 est.)
Infant mortality rate: 6.41 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.71 years
male: 73.97 years
female: 81.71 years (1999 est.)
Total fertility rate: 1.24 children born/woman (1999 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and Nordic types
Religions: Roman Catholic 99%, other 1%
Languages: Castilian Spanish 74%, Catalan 17%, Galician 7%,
Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 98%
female: 94% (1986 est.)
Population: no indigenous inhabitants
note: there are scattered garrisons occupied by personnel of several
claimant states','d2ba67ec6856eac936e4080abc05f6b5677c4f924f8be3b75a11f00941284201','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1331d5de5ef32e34e2f12a2b05e5a9236f2248d421db01afdcafdebf5b3b365',1999,'IN','India','people-and-society',350,'Population: 19,144,875 (July 1999 est.)
note: since the outbreak of hostilities between the government and
armed Tamil separatists in the mid-1980s, several hundred thousand
Tamil civilians have fled the island; as of late 1996, 63,068 were
housed in refugee camps in south India, another 30,000-40,000 lived
outside the Indian camps, and more than 200,000 Tamils have sought
political asylum in the West
Age structure:
0-14 years: 27% (male 2,650,135; female 2,535,092)
15-64 years: 67% (male 6,231,987; female 6,500,782)
65 years and over: 6% (male 592,539; female 634,340) (1999 est.)
Population growth rate: 1.1% (1999 est.)
Birth rate: 18.16 births/1,000 population (1999 est.)
Death rate: 6.02 deaths/1,000 population (1999 est.)
Net migration rate: -1.13 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 16.12 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.67 years
male: 69.89 years
female: 75.59 years (1999 est.)
Total fertility rate: 2.1 children born/woman (1999 est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor 7%, Burgher, Malay,
and Vedda 1%
Religions: Buddhist 69%, Hindu 15%, Christian 8%, Muslim 8%
Languages: Sinhala (official and national language) 74%, Tamil
(national language) 18%
note: English is commonly used in government and is spoken by about
10% of the population
Literacy:
definition: age 15 and over can read and write
total population: 90.2%
male: 93.4%
female: 87.2% (1995 est.)
Population: 34,475,690 (July 1999 est.)
Age structure:
0-14 years: 45% (male 7,941,909; female 7,614,225)
15-64 years: 53% (male 9,094,712; female 9,061,194)
65 years and over: 2% (male 423,389; female 340,261) (1999 est.)
Population growth rate: 2.71% (1999 est.)
Birth rate: 39.34 births/1,000 population (1999 est.)
Death rate: 10.6 deaths/1,000 population (1999 est.)
Net migration rate: -1.68 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1.24 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 70.94 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 56.4 years
male: 55.41 years
female: 57.44 years (1999 est.)
Total fertility rate: 5.58 children born/woman (1999 est.)
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%, foreigners 2%, other
1%
Religions: Sunni Muslim 70% (in north), indigenous beliefs 25%,
Christian 5% (mostly in south and Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie, diverse
dialects of Nilotic, Nilo-Hamitic, Sudanic languages, English
note: program of Arabization in process
Literacy:
definition: age 15 and over can read and write
total population: 46.1%
male: 57.7%
female: 34.6% (1995 est.)
Population: 431,156 (July 1999 est.)
Age structure:
0-14 years: 33% (male 72,673; female 69,212)
15-64 years: 62% (male 135,573; female 130,700)
65 years and over: 5% (male 10,585; female 12,413) (1999 est.)
Population growth rate: 0.71% (1999 est.)
Birth rate: 21.75 births/1,000 population (1999 est.)
Death rate: 5.75 deaths/1,000 population (1999 est.)
Net migration rate: -8.92 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.03 male(s)/female (1999 est.)
Infant mortality rate: 26.52 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.89 years
male: 68.32 years
female: 73.59 years (1999 est.)
Total fertility rate: 2.55 children born/woman (1999 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as "East Indians";
their ancestors emigrated from northern India in the latter part of
the 19th century) 37%, Creole (mixed white and black) 31%, Javanese
15.3%, "Maroons" (their African ancestors were brought to the
country in the 17th and 18th centuries as slaves and escaped to the
interior) 10.3%, Amerindian 2.6%, Chinese 1.7%, white 1%, other 1.1%
Religions: Hindu 27.4%, Muslim 19.6%, Roman Catholic 22.8%,
Protestant 25.2% (predominantly Moravian), indigenous beliefs 5%
Languages: Dutch (official), English (widely spoken), Sranang
Tongo (Surinamese, sometimes called Taki-Taki, is native language of
Creoles and much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi), Javanese
Literacy:
definition: age 15 and over can read and write
total population: 93%
male: 95%
female: 91% (1995 est.)
Population: 2,503 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -3.55% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Ethnic groups: Russian and Ukrainian 62%, Norwegian 38%, other
NEGL% (1994)
Languages: Russian, Norwegian
Population: 985,335 (July 1999 est.)
Age structure:
0-14 years: 46% (male 227,675; female 228,733)
15-64 years: 51% (male 243,853; female 259,950)
65 years and over: 3% (male 9,866; female 15,258) (1999 est.)
Population growth rate: 1.91% (1999 est.)
Birth rate: 40.8 births/1,000 population (1999 est.)
Death rate: 21.72 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 101.87 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 38.11 years
male: 36.86 years
female: 39.4 years (1999 est.)
Total fertility rate: 5.92 children born/woman (1999 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs 40%
Languages: English (official, government business conducted in
English), siSwati (official)
Literacy:
definition: age 15 and over can read and write
total population: 76.7%
male: 78%
female: 75.6% (1995 est.)
Population: 8,911,296 (July 1999 est.)
Age structure:
0-14 years: 19% (male 856,819; female 812,958)
15-64 years: 64% (male 2,896,383; female 2,802,571)
65 years and over: 17% (male 651,549; female 891,016) (1999 est.)
Population growth rate: 0.29% (1999 est.)
Birth rate: 12 births/1,000 population (1999 est.)
Death rate: 10.77 deaths/1,000 population (1999 est.)
Net migration rate: 1.68 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 3.91 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 79.29 years
male: 76.61 years
female: 82.11 years (1999 est.)
Total fertility rate: 1.83 children born/woman (1999 est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: white, Lapp (Sami), foreign-born or
first-generation immigrants 12% (Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks)
Religions: Evangelical Lutheran 94%, Roman Catholic 1.5%,
Pentecostal 1%, other 3.5% (1987)
Languages: Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%
Population: 7,275,467 (July 1999 est.)
Age structure:
0-14 years: 17% (male 639,970; female 611,876)
15-64 years: 68% (male 2,509,988; female 2,417,580)
65 years and over: 15% (male 444,482; female 651,571) (1999 est.)
Population growth rate: 0.2% (1999 est.)
Birth rate: 10.53 births/1,000 population (1999 est.)
Death rate: 9.06 deaths/1,000 population (1999 est.)
Net migration rate: 0.49 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 4.87 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 78.99 years
male: 75.83 years
female: 82.32 years (1999 est.)
Total fertility rate: 1.46 children born/woman (1999 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian 10%, Romansch 1%,
other 6%
Religions: Roman Catholic 46.1%, Protestant 40%, other 5%, no
religion 8.9% (1990)
Languages: German 63.7%, French 19.2%, Italian 7.6%, Romansch
0.6%, other 8.9%
Literacy:
definition: age 15 and over can read and write
total population: 99% (1980 est.)
male: NA%
female: NA%
Population: 17,213,871 (July 1999 est.)
note: in addition, there are about 37,200 people living in the
Israeli-occupied Golan Heights--18,200 Arabs (16,500 Druze and 1,700
Alawites) and about 19,000 Israeli settlers (August 1998 est.)
Age structure:
0-14 years: 46% (male 4,032,620; female 3,840,431)
15-64 years: 51% (male 4,515,274; female 4,322,415)
65 years and over: 3% (male 246,812; female 256,319) (1999 est.)
Population growth rate: 3.15% (1999 est.)
Birth rate: 36.95 births/1,000 population (1999 est.)
Death rate: 5.4 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1.04 male(s)/female (1999 est.)
Infant mortality rate: 36.42 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.09 years
male: 66.75 years
female: 69.48 years (1999 est.)
Total fertility rate: 5.37 children born/woman (1999 est.)
Nationality:
noun: Syrian(s)
adjective: Syrian
Ethnic groups: Arab 90.3%, Kurds, Armenians, and other 9.7%
Religions: Sunni Muslim 74%, Alawite, Druze, and other Muslim
sects 16%, Christian (various sects) 10%, Jewish (tiny communities
in Damascus, Al Qamishli, and Aleppo)
Languages: Arabic (official); Kurdish, Armenian, Aramaic,
Circassian widely understood; French, English somewhat understood
Literacy:
definition: age 15 and over can read and write
total population: 70.8%
male: 85.7%
female: 55.8% (1997 est.)
Population: 22,113,250 (July 1999 est.)
Age structure:
0-14 years: 22% (male 2,515,398; female 2,338,506)
15-64 years: 70% (male 7,825,953; female 7,574,836)
65 years and over: 8% (male 989,040; female 869,517) (1999 est.)
Population growth rate: 0.93% (1999 est.)
Birth rate: 14.63 births/1,000 population (1999 est.)
Death rate: 5.32 deaths/1,000 population (1999 est.)
Net migration rate: -0.02 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 1.14 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 6.01 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.49 years
male: 74.38 years
female: 80.85 years (1999 est.)
Total fertility rate: 1.77 children born/woman (1999 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Taiwanese (including Hakka) 84%, mainland Chinese
14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and Taoist 93%,
Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese (Min), Hakka
dialects
Literacy:
definition: age 15 and over can read and write
total population: 94% (1998 est.)
male: 93% (1980 est.)
female: 79% (1980 est.)
Population: 6,102,854 (July 1999 est.)
Age structure:
0-14 years: 41% (male 1,250,344; female 1,224,355)
15-64 years: 55% (male 1,661,488; female 1,681,839)
65 years and over: 4% (male 122,065; female 162,763) (1999 est.)
Population growth rate: 1.43% (1999 est.)
Birth rate: 27.46 births/1,000 population (1999 est.)
Death rate: 7.85 deaths/1,000 population (1999 est.)
Net migration rate: -5.34 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 114.78 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 64.28 years
male: 61.15 years
female: 67.57 years (1999 est.)
Total fertility rate: 3.48 children born/woman (1999 est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian 3.5% (declining
because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in government
and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Population: 31,270,820 (July 1999 est.)
Age structure:
0-14 years: 44% (male 6,926,149; female 6,967,416)
15-64 years: 53% (male 8,030,141; female 8,437,978)
65 years and over: 3% (male 415,074; female 494,062) (1999 est.)
Population growth rate: 2.14% (1999 est.)
Birth rate: 40.37 births/1,000 population (1999 est.)
Death rate: 16.75 deaths/1,000 population (1999 est.)
Net migration rate: -2.24 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 95.27 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 46.17 years
male: 43.85 years
female: 48.57 years (1999 est.)
Total fertility rate: 5.4 children born/woman (1999 est.)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland--native African 99% (of which 95% are
Bantu consisting of more than 130 tribes), other 1% (consisting of
Asian, European, and Arab); Zanzibar--Arab, native African, mixed
Arab and native African
Religions: mainland--Christian 45%, Muslim 35%, indigenous beliefs
20; Zanzibar--more than 99% Muslim
Languages: Kiswahili or Swahili (official), Kiunguju (name for
Swahili in Zanzibar), English (official, primary language of
commerce, administration, and higher education), Arabic (widely
spoken in Zanzibar), many local languages
note: Kiswahili (Swahili) is the mother tongue of the Bantu people
living in Zanzibar and nearby coastal Tanzania; although Kiswahili
is Bantu in structure and origin, its vocabulary draws on a variety
of sources, including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first language of
most people is one of the local languages
Literacy:
definition: age 15 and over can read and write Kiswahili (Swahili),
English, or Arabic
total population: 67.8%
male: 79.4%
female: 56.8% (1995 est.)
Population: 60,609,046 (July 1999 est.)
Age structure:
0-14 years: 24% (male 7,364,411; female 7,095,428)
15-64 years: 70% (male 20,878,602; female 21,493,735)
65 years and over: 6% (male 1,664,113; female 2,112,757) (1999 est.)
Population growth rate: 0.93% (1999 est.)
Birth rate: 16.46 births/1,000 population (1999 est.)
Death rate: 7.16 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 29.54 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.21 years
male: 65.58 years
female: 73.01 years (1999 est.)
Total fertility rate: 1.82 children born/woman (1999 est.)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhism 95%, Muslim 3.8%, Christianity 0.5%, Hinduism
0.1%, other 0.6% (1991)
Languages: Thai, English (secondary language of the elite),
ethnic and regional dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.8%
male: 96%
female: 91.6% (1995 est.)
Population: 5,081,413 (July 1999 est.)
Age structure:
0-14 years: 48% (male 1,229,026; female 1,218,956)
15-64 years: 50% (male 1,223,371; female 1,299,519)
65 years and over: 2% (male 49,890; female 60,651) (1999 est.)
Population growth rate: 3.51% (1999 est.)
Birth rate: 44.78 births/1,000 population (1999 est.)
Death rate: 9.69 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (1999 est.)
Infant mortality rate: 77.55 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 59.25 years
male: 56.93 years
female: 61.64 years (1999 est.)
Total fertility rate: 6.53 children born/woman (1999 est.)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and most
important are Ewe, Mina, and Kabre) 99%, European and
Syrian-Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian 20%, Muslim 10%
Languages: French (official and the language of commerce), Ewe
and Mina (the two major African languages in the south), Kabye
(sometimes spelled Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51.7%
male: 67%
female: 37% (1995 est.)
Population: 1,471 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: -0.92% (1999 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
Nationality:
noun: Tokelauan(s)
adjective: Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%, Roman Catholic
28%, other 2%
note: on Atafu, all Congregational Christian Church of Samoa; on
Nukunonu, all Roman Catholic; on Fakaofo, both denominations, with
the Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language), English
Population: 109,082 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 0.8% (1999 est.)
Birth rate: 25.92 births/1,000 population (1999 est.)
Death rate: 6 deaths/1,000 population (1999 est.)
Net migration rate: -1.19 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 37.93 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 69.78 years
male: 67.73 years
female: 72.22 years (1999 est.)
Total fertility rate: 3.56 children born/woman (1999 est.)
Nationality:
noun: Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims over 30,000
adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
female: 98.7% (1996 est.)
Population: 1,102,096 (July 1999 est.)
Age structure:
0-14 years: 27% (male 150,862; female 144,589)
15-64 years: 66% (male 377,894; female 346,375)
65 years and over: 7% (male 37,001; female 45,375) (1999 est.)
Population growth rate: -1.35% (1999 est.)
Birth rate: 14.46 births/1,000 population (1999 est.)
Death rate: 8.14 deaths/1,000 population (1999 est.)
Net migration rate: -19.8 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.09 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 18.56 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 70.66 years
male: 68.19 years
female: 73.19 years (1999 est.)
Total fertility rate: 2.06 children born/woman (1999 est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
Ethnic groups: black 40%, East Indian (a local term--primarily
immigrants from northern India) 40.3%, mixed 14%, white 1%, Chinese
1%, other 3.7%
Religions: Roman Catholic 32.2%, Hindu 24.3%, Anglican 14.4%,
other Protestant 14%, Muslim 6%, none or unknown 9.1%
Languages: English (official), Hindi, French, Spanish
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
male: 98.8%
female: 97% (1995 est.)','38b89cd9f6b29c9143ba168fd12b29eeb4490ece8955298ee95b58c24e4a3b8e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e758c1169224d1ca300524c4d8b0568ea20f273737457a77a0c945a6a7f896',1999,'TM','Turkmenistan','people-and-society',364,'Population: 16,863 (July 1999 est.)
Age structure:
0-14 years: 32% (male 2,777; female 2,697)
15-64 years: 63% (male 5,619; female 5,085)
65 years and over: 5% (male 305; female 380) (1999 est.)
Population growth rate: 3.65% (1999 est.)
Birth rate: 26.39 births/1,000 population (1999 est.)
Death rate: 4.86 deaths/1,000 population (1999 est.)
Net migration rate: 15 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.07 male(s)/female (1999 est.)
Infant mortality rate: 21.11 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.35 years
male: 70.4 years
female: 74.4 years (1999 est.)
Total fertility rate: 3.28 children born/woman (1999 est.)
Nationality:
noun: none
adjective: none
Ethnic groups: black
Religions: Baptist 41.2%, Methodist 18.9%, Anglican 18.3%,
Seventh-Day Adventist 1.7%, other 19.9% (1980)
Languages: English (official)
Literacy:
definition: age 15 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)','12057c216f4aa973a932074724c5b56edcd4b0e71d99831b99c7fbb3ebf25862','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e590140a51fb39f14ea5610b25fefe237c7bb5f98d1d1ab92428160ce96c997e',1999,'TC','Turks and Caicos Islands','people-and-society',378,'Population: 272,639,608 (July 1999 est.)
Age structure:
0-14 years: 22% (male 30,097,125; female 28,699,568)
15-64 years: 66% (male 89,024,052; female 90,379,328)
65 years and over: 12% (male 14,189,132; female 20,250,403) (1999
est.)
Population growth rate: 0.85% (1999 est.)
Birth rate: 14.3 births/1,000 population (1999 est.)
Death rate: 8.8 deaths/1,000 population (1999 est.)
Net migration rate: 3 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 6.33 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 76.23 years
male: 72.95 years
female: 79.67 years (1999 est.)
Total fertility rate: 2.07 children born/woman (1999 est.)
Nationality:
noun: American(s)
adjective: American
Ethnic groups: white 83.5%, black 12.4%, Asian 3.3%, Amerindian
0.8% (1992)
Religions: Protestant 56%, Roman Catholic 28%, Jewish 2%, other
4%, none 10% (1989)
Languages: English, Spanish (spoken by a sizable minority)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 97% (1979 est.)','26d8a8fb06e727e311a6ba7f1d10ef5307fae4d01f920c5771ddcd868b123c00','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ec4fc4dd878d49e6c6b8d3d10870073a912765cbdb614b2f6c423d7160a241e',1999,'ES','Spain','people-and-society',385,'Population: 24,102,473 (July 1999 est.)
Age structure:
0-14 years: 37% (male 4,556,973; female 4,413,617)
15-64 years: 58% (male 6,938,090; female 7,068,839)
65 years and over: 5% (male 443,604; female 681,350) (1999 est.)
Population growth rate: 1.32% (1999 est.)
Birth rate: 23.43 births/1,000 population (1999 est.)
Death rate: 7.75 deaths/1,000 population (1999 est.)
Net migration rate: -2.44 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.98 male(s)/female (1999 est.)
Infant mortality rate: 71.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63.91 years
male: 60.29 years
female: 67.71 years (1999 est.)
Total fertility rate: 2.82 children born/woman (1999 est.)
Nationality:
noun: Uzbekistani(s)
adjective: Uzbekistani
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik 5%, Kazakh 3%,
Karakalpak 2.5%, Tatar 1.5%, other 2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern Orthodox 9%, other
3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik 4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (yearend 1996)
Population: 189,036 (July 1999 est.)
Age structure:
0-14 years: 39% (male 37,040; female 35,760)
15-64 years: 58% (male 56,649; female 53,799)
65 years and over: 3% (male 3,125; female 2,663) (1999 est.)
Population growth rate: 2.02% (1999 est.)
Birth rate: 28.49 births/1,000 population (1999 est.)
Death rate: 8.26 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.17 male(s)/female
total population: 1.05 male(s)/female (1999 est.)
Infant mortality rate: 59.58 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 61.44 years
male: 59.41 years
female: 63.57 years (1999 est.)
Total fertility rate: 3.61 children born/woman (1999 est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: indigenous Melanesian 94%, French 4%, Vietnamese,
Chinese, Pacific Islanders
Religions: Presbyterian 36.7%, Anglican 15%, Catholic 15%,
indigenous beliefs 7.6%, Seventh-Day Adventist 6.2%, Church of
Christ 3.8%, other 15.7%
Languages: English (official), French (official), pidgin (known
as Bislama or Bichelama)
Literacy:
definition: age 15 and over can read and write
total population: 53%
male: 57%
female: 48% (1979 est.)','164645b7a19d7c5dddde9bf3742b0b7310872f994c2c76423f30d66b7cd819d3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22bc7992d839b41793137b83fee8f586d1d1dc62e4507a47cf81505d2b540f7e',1999,'NC','New Caledonia','people-and-society',389,'Population: 23,203,466 (July 1999 est.)
Age structure:
0-14 years: 33% (male 3,988,499; female 3,741,568)
15-64 years: 62% (male 7,231,546; female 7,184,769)
65 years and over: 5% (male 484,071; female 573,013) (1999 est.)
Population growth rate: 1.71% (1999 est.)
Birth rate: 22.25 births/1,000 population (1999 est.)
Death rate: 4.93 deaths/1,000 population (1999 est.)
Net migration rate: -0.23 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 26.51 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.95 years
male: 69.97 years
female: 76.16 years (1999 est.)
Total fertility rate: 2.61 children born/woman (1999 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab, German,
African, indigenous people
Religions: nominally Roman Catholic 96%, Protestant 2%
Languages: Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 91.8%
female: 90.3% (1995 est.)
Population: 77,311,210 (July 1999 est.)
Age structure:
0-14 years: 34% (male 13,377,315; female 12,603,906)
15-64 years: 61% (male 22,934,553; female 24,277,488)
65 years and over: 5% (male 1,645,288; female 2,472,660) (1999 est.)
Population growth rate: 1.37% (1999 est.)
Birth rate: 20.78 births/1,000 population (1999 est.)
Death rate: 6.56 deaths/1,000 population (1999 est.)
Net migration rate: -0.53 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.96 male(s)/female (1999 est.)
Infant mortality rate: 34.84 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 68.1 years
male: 65.71 years
female: 70.64 years (1999 est.)
Total fertility rate: 2.41 children born/woman (1999 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese 3%, Muong, Tai, Meo,
Khmer, Man, Cham
Religions: Buddhist, Taoist, Roman Catholic, indigenous beliefs,
Islam, Protestant, Cao Dai, Hoa Hao
Languages: Vietnamese (official), Chinese, English, French,
Khmer, tribal languages (Mon-Khmer and Malayo-Polynesian)
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 96.5%
female: 91.2% (1995 est.)
Population: 119,827 (July 1999 est.)
note: West Indian (45% born in the Virgin Islands and 29% born
elsewhere in the West Indies) 74%, US mainland 13%, Puerto Rican 5%,
other 8%
Age structure:
0-14 years: 28% (male 17,454; female 16,585)
15-64 years: 63% (male 34,712; female 41,325)
65 years and over: 9% (male 4,237; female 5,514) (1999 est.)
Population growth rate: 1.19% (1999 est.)
Birth rate: 17.08 births/1,000 population (1999 est.)
Death rate: 5.34 deaths/1,000 population (1999 est.)
Net migration rate: 0.13 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.84 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.89 male(s)/female (1999 est.)
Infant mortality rate: 10.07 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 77.74 years
male: 74.04 years
female: 81.67 years (1999 est.)
Total fertility rate: 2.42 children born/woman (1999 est.)
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic groups: black 80%, white 15%, other 5%
Religions: Baptist 42%, Roman Catholic 34%, Episcopalian 17%,
other 7%
Languages: English (official), Spanish, Creole
Literacy: NA
Population: no indigenous inhabitants
note: US military personnel have left the island, but some civilian
personnel remain (1999 est.)
Population: 15,129 (July 1999 est.)
Age structure:
0-14 years: NA%
15-64 years: NA%
65 years and over: NA%
Population growth rate: 1.04% (1999 est.)
Birth rate: 22.34 births/1,000 population (1999 est.)
Death rate: 4.66 deaths/1,000 population (1999 est.)
Net migration rate: -7.26 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: NA deaths/1,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Wallisian(s), Futunan(s), or Wallis and Futuna Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous Polynesian language)
Literacy:
definition: age 15 and over can read and write
total population: 50%
male: 50%
female: 50% (1969 est.)
Population: 1,611,109 (July 1999 est.)
note: in addition, there are some 166,000 Israeli settlers in the
West Bank and about 176,000 in East Jerusalem (August 1998 est.)
Age structure:
0-14 years: 45% (male 370,770; female 352,803)
15-64 years: 52% (male 422,209; female 411,597)
65 years and over: 3% (male 22,376; female 31,354) (1999 est.)
Population growth rate: 3.14% (1999 est.)
Birth rate: 35.59 births/1,000 population (1999 est.)
Death rate: 4.2 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 25.22 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 72.83 years
male: 70.96 years
female: 74.79 years (1999 est.)
Total fertility rate: 4.78 children born/woman (1999 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%, Jewish 17%
Religions: Muslim 75% (predominantly Sunni), Jewish 17%,
Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
Population: 239,333 (July 1999 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA
Population growth rate: 2.34% (1999 est.)
Birth rate: 45.42 births/1,000 population (1999 est.)
Death rate: 16.58 deaths/1,000 population (1999 est.)
Net migration rate: -5.41 migrant(s)/1,000 population (1999 est.)
Infant mortality rate: 136.67 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 49.1 years
male: 47.98 years
female: 50.57 years (1999 est.)
Total fertility rate: 6.7 children born/woman (1999 est.)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: NA
Population: 5,995,544,836 (July 1999 est.)
Age structure:
0-14 years: 30% (male 934,816,288; female 884,097,095)
15-64 years: 63% (male 1,905,701,066; female 1,861,265,079)
65 years and over: 7% (male 179,094,601; female 230,570,707) (1999
est.)
Population growth rate: 1.3% (1999 est.)
Birth rate: 22 births/1,000 population (1999 est.)
Death rate: 9 deaths/1,000 population (1999 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64: 1.02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.02 male(s)/female (1999 est.)
Infant mortality rate: 56 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 63 years
male: 61 years
female: 65 years (1999 est.)
Total fertility rate: 2.8 children born/woman (1999 est.)
Population: 16,942,230 (July 1999 est.)
Age structure:
0-14 years: 48% (male 4,118,292; female 3,971,886)
15-64 years: 49% (male 4,243,809; female 4,065,429)
65 years and over: 3% (male 278,133; female 264,681) (1999 est.)
Population growth rate: 3.34% (1999 est.)
Birth rate: 43.31 births/1,000 population (1999 est.)
Death rate: 9.88 deaths/1,000 population (1999 est.)
Net migration rate: 0 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 1.05 male(s)/female
total population: 1.04 male(s)/female (1999 est.)
Infant mortality rate: 69.82 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 59.98 years
male: 58.17 years
female: 61.88 years (1999 est.)
Total fertility rate: 7.06 children born/woman (1999 est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; Afro-Arab concentrations in
western coastal locations; South Asians in southern regions; small
European communities in major metropolitan areas
Religions: Muslim including Shaf''i (Sunni) and Zaydi (Shi''a),
small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)
Population: 9,663,535 (July 1999 est.)
Age structure:
0-14 years: 49% (male 2,381,937; female 2,355,807)
15-64 years: 49% (male 2,308,715; female 2,379,994)
65 years and over: 2% (male 107,427; female 129,655) (1999 est.)
Population growth rate: 2.12% (1999 est.)
Birth rate: 44.51 births/1,000 population (1999 est.)
Death rate: 22.56 deaths/1,000 population (1999 est.)
Net migration rate: -0.78 migrant(s)/1,000 population (1999 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 91.85 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 36.96 years
male: 36.72 years
female: 37.21 years (1999 est.)
Total fertility rate: 6.35 children born/woman (1999 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%, other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu 24%-49%,
indigenous beliefs 1%
Languages: English (official), major vernaculars--Bemba, Kaonda,
Lozi, Lunda, Luvale, Nyanja, Tonga, and about 70 other indigenous
languages
Literacy:
definition: age 15 and over can read and write English
total population: 78.2%
male: 85.6%
female: 71.3% (1995 est.)
Population: 11,163,160 (July 1999 est.)
Age structure:
0-14 years: 43% (male 2,432,785; female 2,389,029)
15-64 years: 54% (male 2,986,531; female 3,059,186)
65 years and over: 3% (male 132,532; female 163,097) (1999 est.)
Population growth rate: 1.02% (1999 est.)
Birth rate: 30.64 births/1,000 population (1999 est.)
Death rate: 20.43 deaths/1,000 population (1999 est.)
Net migration rate: NA migrant(s)/1,000 population
note: there is a small but steady flow of Zimbabweans into South
Africa in search of better paid employment
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.99 male(s)/female (1999 est.)
Infant mortality rate: 61.21 deaths/1,000 live births (1999 est.)
Life expectancy at birth:
total population: 38.86 years
male: 38.77 years
female: 38.94 years (1999 est.)
Total fertility rate: 3.71 children born/woman (1999 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 71%, Ndebele 16%, other 11%),
white 1%, mixed and Asian 1%
Religions: syncretic (part Christian, part indigenous beliefs)
50%, Christian 25%, indigenous beliefs 24%, Muslim and other 1%
Languages: English (official), Shona, Sindebele (the language of
the Ndebele, sometimes called Ndebele), numerous but minor tribal
dialects
Literacy:
definition: age 15 and over can read and write English
total population: 85%
male: 90%
female: 80% (1995 est.)','86d8c7df73cb35c6bac0eb544b2e17ad13cf24e9e8bf24e22296860a6383df6b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

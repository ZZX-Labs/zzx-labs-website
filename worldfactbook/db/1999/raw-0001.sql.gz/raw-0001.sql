SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2ab5f543f7dacadabbdf39e94be8cd51fb324e569ae4b513134943bb911be25',1999,'','','raw',1,'The Central Intelligence Agency (CIA) prepares The World
Factbook in printed, CD-ROM, and Internet versions. US
Government officials may obtain information about availability of
the Factbook from their own organizations or through liaison
channels to the CIA. Other users may obtain sales information
about printed copies and CD-ROMs from the following:
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
FAX: [1] (202) 512-2250
http://www.access.gpo.gov/su_docs/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The Internet version may be accessed through the
following World-Wide Web uniform resource locator
(URL):
http://www.cia.gov
Printed by Printing & Photography Group
DTIC QUALITY INCPECZSD S-
Central
Intelligence
Agency
The
World
Factbook
1999
In general, information available as of 1 January
1999 was used in the preparation of this edition.
The World Factbook is prepared by the Central
Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and
content are designed to meet their specific
requirements. Information is provided by the Bureau
of the Census (Department of Commerce), Bureau
of Labor Statistics (Department of Labor), Central
Intelligence Agency, Council of Managers of
National Antarctic Programs, Defense Intelligence
Agency (Department of Defense), Defense Threat
Reduction Agency (Department of Defense),
Department of State, Fish and Wildlife Service
(Department of the Interior), Maritime Administration
(Department of Transportation), National Imagery
and Mapping Agency (Department of Defense),
Antarctic Information Program (National Science
Foundation), Naval Facilities Engineering
Command (Department of Defense), Office of
Insular Affairs (Department of the Interior), Office of
Naval Intelligence (Department of Defense), US
Board on Geographic Names (Department of the
Interior), and other public and private sources.
The Factbook is in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties.
Comments and queries are welcome and may be
addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data
that may be fragmentary, contradictory, unreiiabie,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current,
and estimative. Basic intelligence provides the fundamental
and factual reference material on a country or issue. Current
intelligence reports on new developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President''s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington, but only since
World War II have they been coordinated on a
governmentwide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1) the Joint Army Navy Intelligence Studies (JANIS), (2) the
National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence— ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services— OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1 943 and July 1 947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security, He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1 946, page 46) that world leadership in peace requires
even more elaborate intelligence than war. "The conduct of
peace involves all countries, all human activities — not just
the enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
1 3 January 1 948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. . . . There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbookwas created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbookwas published in August
1 962, and the first unclassified version was published in June
1971 . The NIS program was terminated in 1973 except for the
Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with
sales through the US Government Printing Office (GPO). The
1996 edition was printed by GPO and the 1997 edition was
reprinted by GPO. The year 1 999 marks the 52nd anniversary
of the establishment of the Central Intelligence Agency and
the 56th year of continuous basic intelligence support to the
US Government by The World Factbook and its two
predecessor programs.
Contents
Page
Page
Page
Notes and Definitions
vii','6735d9b5f7cc2a9a6aecdaf805bf3b03946147f56a664800f4e7e996430cb472','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eae86e6226ecfeed598c7275adbf5b17812378f840e731cb7f4df97c927e7113',1999,'PF','French Polynesia','raw',2,'172
Korea, South
266
British Virgin Islands
70
French Southern and Antarctic Lands
174','c6f5919589b163881b9ad0ca654bde35913aef41b121c3b672c6d108836d3559','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('194c74a1e2dfcd16df333e862370ee4a023ac8bffd7cb6216e8297fbe75cded8',1999,'NF','Norfolk Island','raw',3,'363
1 China— Hong Kong
2 Denmark— Faroe Islands, Greenland
16 France— Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands, Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
2 Netherlands— Aruba, Netherlands Antilles
3 New Zealand— Cook Islands, Niue, Tokelau
3 Norway— Bouvet Island, Jan Mayen, Svalbard
1 Portugal— Macau
15 UK— Anguilla, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey,
Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and
the South Sandwich Islands, Turks and Caicos Islands
14 US— American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Northern Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands,
Wake Atoll
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','9f4a426e6c8fa00e3c71da25a86e8bc82d832d3ccd0831240a2a080c56bb0b57','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfc5d458ef428386742f446a8a4cca2d12ed0b23bafcd7910b826ee3520313fe',1999,'US','United States','raw',4,'508
v
Notes and Definitions
In addition to the updating of information, the following changes have been made
in this edition of The World Factbook. The name Wake Island has been officially
changed to Wake Atoll. The Historical perspective and Current issues entries
in the Introduction category have been combined into a new Background entry.
It appears in only a few country profiles at this time. There are new entries on
Population below poverty line, Household income or consumption by
percentage share, Electricity— production by source (fossil fuel, hydro,
nuclear, other), Electricity— exports, and Electricity— imports. A new
reference map of Kosovo has been included and terrain has been added to most
of the reference maps. A new physical map of the world has also been added.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years, 65
years and over). The age structure of a population affects a nation’s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture— products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports— with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces). For airports with more than one
runway, only the longest runway is included according to the following five groups
-(1 ) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m, (4) 91 4 to 1 ,523 m,
and (5) under 914 m. Only airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance, or air traffic control.
Airports— with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces). For airports with
more than one runway, only the longest runway is included according to the
following five groups— (1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437
m, (4) 914 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control.
Appendixes: This section includes Fac tooo/c- related material by topic.
vii
Notes and Definitions (continued)
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area— comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events, current issues,
and may include a statement about one or two key future trends. This entry
appears for only a few countries at the present time, but will be added to all
countries in the future.
Birth rate: This entry gives the average annual number of births during a year per
1,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Capital: This entry gives the location of the seat of government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, and television entries.
Communications— note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country map: Most versions of the Factbookpmlde a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italians), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
viii
Notes and Definitions (continued)
Currency: This entry identifies the national medium of exchange and its basic
subunit.
Data code: This entry gives the official US Government digraph that precisely
identifies every land entity without overlap, duplication, or omission. AF, for
example, is the data code for Afghanistan. This two-letter country code is a
standardized geopolitical data element promulgated in the Federal Information
Processing Standards Publication (FIPS) 10-4 by the National Institute of
Standards and Technology at the US Department of Commerce and maintained
by the Office of the Geographer and Global Issues at the US Department of State.
The data code is used to eliminate confusion and incompatibility in the collection,
processing, and dissemination of area-specific data and is particularly useful for
interchanging data between databases. Appendix F cross-references various
country data codes and Appendix G does the same thing for hydrographic data
codes.
Data codes— country: This information is presented in Appendix F:
Cross-Reference List of Country Data Codes which includes the US
Government approved Federal Information Processing Standards (FIPS) codes,
the International Organization for Standardization (ISO) codes, and Internet codes
for land entities.
Data codes— hydrographic: This information is presented in Appendix G:
Cross-Reference List of Hydrographic Data Codes which includes the
International Hydrographic Organization (IHO) codes, Aeronautical Chart and
Information Center (ACIC; now National Imagery and Mapping Agency or NIMA)
codes, and Defense Intelligence Agency (DIA) codes for hydrographic entities.
The US Government has not yet approved a standard for hydrographic data codes
similar to the FIPS 10-4 standard for country data codes.
Date of information: In general, information available as of 1 January 1999, was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt— external: This entry gives the total amount of public foreign financial
obligations.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
184 independent states, including 178 of the 185 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, former Yugoslavia, and the
US itself). In addition, the US has diplomatic relations with 6 independent states
that are not in the UN— Holy See, Kiribati, Nauru, Switzerland, Tonga, and Tuvalu.
IX
Notes and Definitions (continued)
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, branch office
locations, consulate general locations, and consulate locations.
Diplomatic representation in the US: This entry includes the chief of the foreign
mission, chancery address, telephone number, FAX number, consulate general
locations, consulate locations, honorary consulate general locations, and
honorary consulate locations.
Disputes— international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Economic aid— donor: This entry refers to net official development assistance
(ODA) from OECD nations to developing countries and multilateral organizations.
ODA is defined as financial assistance that is concessional in character, has the
main objective to promote economic development and welfare of LDCs, and
contains a grant element of at least 25%. The entry does not cover other official
flows (OOF) or private flows.
Economic aid— recipient: This entry, which is subject to major problems of
definition and statistical coverage, refers to the net inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new inflows
and repayments.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy— overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity— consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt hours.
Electricity— exports: This entry is the total exported electricity in kilowatt hours.
Electricity— imports: This entry is the total imported electricity in kilowatt hours.
Electricity— production: This entry is the annual electricity generated expressed
in kilowatt hours.
x
Notes and Definitions (continued)
Electricity— production by source: This entry indicates the percentage share of
annual electricity production of each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes: This entry includes both the highest point and the lowest
point.
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 266 separate
geographic entities in The World Factbook that may be categorized as follows:
INDEPENDENT STATES
191 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
XI
Notes and Definitions (continued)
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia— Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald Islands,','e4a360783440dc2fe7e37fb48e106e43c58dbb05a7dd6d743707bfe43e2d1118','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e9381b5a0029ec3891e212e02e47bdc08af9e39f3a3aceb677ba99917c9dc20',1999,'EH','Western Sahara','raw',5,'529
World
530
Y
OTHER ENTITIES
4 oceans— Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 World
266 Total
Environment— current issues: This entry lists the most pressing and important
environmental problems.
Environment— international agreements: This entry separates country
participation in international environmental agreements into two levels— party to
and signed but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix D:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and normally includes the percent of total population.
XII
Notes and Definitions (continued)
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local
currency per US dollar and as determined by international market forces or official
fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day
activities of the government. Cabinet includes the official name for this body of
high-ranking advisers and the method for selection of members. E/ecf/onsindudes
the nature of election process or accession to power, date of the last election, and
date of the next election. Election results includes the percent of vote for each
candidate in the last election. In the UK, the monarch is the chief of state, and the
prime minister is the head of government. In the US, the president is both the chief
of state and the head of government.
Exports: This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports— commodities: This entry provides a rank ordering of exported
products starting with the most important; it sometimes includes the percent of
total dollar value.
Exports— partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but which may
begin in any month. FY93/94 refers to the fiscal year that began in calendar year
1 993 and ended in calendar year 1 994. All yearly references are for the calendar
year (CY) unless indicated as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodology for more information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
xiii
Notes and Definitions (continued)
derived from the PPP method provide the best available starting point for
comparisons of economic strength and well-being between countries. The
division of a GDP estimate in domestic currency by the corresponding PPP
estimate in dollars gives the PPP conversion rate. Whereas PPP estimates for
OECD countries are quite reliable, PPP estimates for developing countries are
often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International Comparison
Program (UNICP) and by Professors Robert Summers and Alan Heston of the
University of Pennsylvania and their colleagues. In contrast, currency exchange
rates depend on a variety of international and domestic financial forces that often
have little relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically one-fourth to
one-half the PPP estimate. Furthermore, exchange rates may suddenly go up or
down by 1 0% or more because of market forces or official fiat whereas real output
has remained unchanged. On 1 2 January 1 994, for example, the 1 4 countries of
the African Financial Community (whose currencies are tied to the French franc)
devalued their currencies by 50%. This move, of course, did not cut the real output
of these countries by half. One important caution: the proportion of, say, defense
expenditures as a percentage of GDP in local currency accounts may differ
substantially from the proportion when GDP accounts are expressed in PPP
terms, as, for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP and other
economic data can not be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information, and changes in
national statistical methods and practices. For statistical series on GDP and other
economic variables, see the Handbook of International Economic Statistics
available from the same sources as The World Factbook.
GDP— composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP.
GDP— per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP— real growth rate: This entry gives GDP growth on an annual basis
adjusted for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix H:
Cross-Reference List of Geographic Names which indicates where various
geographic names— including alternate names, former names, political or
geographical portions of larger entities, and the location of all US Foreign Service
posts— can be found in The World Factbook. Spellings are normally, but not
always, those approved by the US Board on Geographic Names (BGN). Alternate
names are included in parentheses, while additional information is included in
brackets.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
XIV
Notes and Definitions (continued)
Geography— note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g., republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government— note: This entry includes miscellaneous government information
of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry includes the total length of the highway system as well as
the length of the paved and unpaved components.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Illicit drugs: This entry gives information on the five categories of illicit drugs —
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
xv
Notes and Definitions (continued)
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(POP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
phenmetrazine (Preludin), methylphenidate (Ritalin), and others (Cylert, Sanorex,
Tenuate).
Imports: This entry provides the total US dollar amount of imports on a c.i.f. (cost,
insurance, and freighter f.o.b. (free on board) basis.
Imports— commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports— partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
xvi
Notes and Definitions (continued)
Independence: For most countries, this entry gives the date that sovereignty was
achieved, and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as traditional founding date, date of
unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year. This rate is often
used an indicator of the level of health in a country.
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year’s consumer prices.
International disputes: see Disputes— international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix C:
International Organizations and Groups which includes the name, abbreviation,
address, telephone, FAX, date established, aim, and members by category.
Introduction: This category includes one entry, Background. At present it
appears in only a few country profiles, but will be added to others in the future.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force— by occupation: This entry contains a rank ordering of component
parts of the labor force by occupation.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for five
different types of land use. Arable land— land cultivated for crops that are
replanted after each harvest like wheat, maize, and rice. Permanent crops— land
cultivated for crops that are not replanted after each harvest like citrus, coffee, and
rubber. Permanent pastures— land permanently used for herbaceous forage
crops. Forests and woodland— land under dense or open stands of trees. Other—
any land type not specifically mentioned above, such as urban areas, roads,
desert, etc.
XVII
Notes and Definitions (continued)
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition— the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Map references: This entry includes the name of the Factbook reference map on
which a country may be found. The entry on Geographic coordinates may be
helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims: contiguous zone,
continental shelf, exclusive economic zone, exclusive fishing zone, extended
fishing zone, none (usually for a landlocked country), other (unique maritime
claims like Libya’s Gulf of Sidra Closing Line or North Korea’s Military Boundary
Line), and territorial sea. The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged in the
carriage of goods; all commercial vessels (as opposed to all nonmilitary ships),
which excludes tugs, fishing vessels, offshore oil rigs, etc.; or a grouping of
merchant ships by nationality or register. This entry contains information in two
subfields— total and ships by type. Total includes the total number of ships (1 ,000
GRT or over), total DWT for those ships, and total GRT for those ships. Ships by
type includes a listing of barge carriers, bulk cargo ships, cargo ships, combination
bulk carriers, combination ore/oil carriers, container ships, intermodal ships,
liquefied gas tankers, livestock carriers, multifunction large-load carriers, oil
xviii
Notes and Definitions (continued)
tankers, passenger ships, passenger-cargo ships, railcar carriers, refrigerated
cargo ships, roll-on/roll-off cargo ships, short-sea passenger ships, specialized
tankers, tanker tug-barges, and vehicle carriers.
A captive register is a register of ships maintained by a territory, possession,
or colony primarily or exclusively for the use of ships owned in the parent country;
it is also referred to as an offshore register, the offshore equivalent of an internal
register. Ships on a captive register will fly the same flag as the parent country, or
a local variant of it, but will be subject to the maritime laws and taxation rules of
the offshore territory. Although the nature of a captive register makes it especially
desirable for ships owned in the parent country, just as in the internal register, the
ships may also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an independent state.
A flag of convenience register is a national register offering registration to a
merchant ship not owned in the flag state. The major flags of convenience (FOC)
attract ships to their registers by virtue of low fees, low or nonexistent taxation of
profits, and liberal manning requirements. True FOC registers are characterized by
having relatively few of the registered ships actually owned in the flag state. Thus,
while virtually any flag can be used for ships under a given set of circumstances,
an FOC register is one where the majority of the merchant fleet is owned abroad.
It is also referred to as an open register.
A flag state is the nation in which a ship is registered and which holds legal
jurisdiction over operation of the ship, whether at home or abroad. Maritime
legislation of the flag state determines how a ship is crewed and taxed and
whether a foreign-owned ship may be placed on the register.
An internal register is a register of ships maintained as a subset of a national
register. Ships on the internal register fly the national flag and have that nationality
but are subject to a separate set of maritime rules from those on the main national
register. These differences usually include lower taxation of profits, use of foreign
nationals as crew members, and, usually, ownership outside the flag state (when
it functions as an FOC register). The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of an internal
register. Both have been instrumental in stemming flight from the national flag to
flags of convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of freight; it is
commonly used to denote any nonmilitary ship but accurately restricted to
commercial vessels only.
A register is the record of a ship''s ownership and nationality as listed with the
maritime authorities of a country; also, it is the compendium of such individual
ships'' registrations. Registration of a ship provides it with a nationality and makes
it subject to the laws of the country in which registered (the flag state) regardless
of the nationality of the ship''s ultimate owner.
Military: This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military branches: This entry lists the names of the ground, naval, air, marine,
and other defense or security forces.
Military expenditures— dollar figure: This entry gives current military
expenditures in US dollars; the figure is calculated by multiplying the estimated
defense spending in percentage terms by the gr','83a05e1ad3d08bdb9f8b3499adeb9505647f0d9fb55b45524e0e3738c9757651','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77238d388b8324276132cddd66c21529939dc2e41df1069eb0e15be665b94eb6',1999,'EH','Western Sahara','raw',6,'oss domestic product (GDP)
calculated on an exchange rate basis not purchasing power parity (PPP) terms.
XIX
Notes and Definitions (continued)
The figure should be treated with caution because of different price patterns and
accounting methods among nations, as well as wide variations in the strength of
their currencies.
Military expenditures— percent of GDP: This entry gives current military
expenditures as an estimated percent of gross domestic product (GDP).
Military manpower— availability: This entry gives the total numbers of males
and females age 15-49 and assumes that every individual is fit to serve.
Military manpower— lit for military service: This entry gives the number of
males and females age 15-49 fit for military service. This is a more refined
measure of potential military manpower availability which tries to correct for the
health situation in the country and reduces the maximum potential number to a
more realistic estimate of the actual number fit to serve.
Military manpower— military age: This entry gives the minimum age at which an
individual may volunteer for military service or be subject to conscription.
Military manpower— reaching military age annually: This entry gives the
number of draft-age males and females entering the military manpower pool in any
given year and is a measure of the availability of draft-age young adults.
Military— note: This entry includes miscellaneous military information of
significance not included elsewhere.
Money figures: All money figures are expressed in contemporaneous US dollars
unless otherwise indicated.
National holiday: This entry gives the primary national day of celebration - usually
independence day.
Nationality: This entry provides the identifying terms for citizens - noun and
adjective.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum, hydropower,
and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference between the
number of persons entering and leaving a country during the year per 1 ,000
persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1 ,000 population); an
excess of persons leaving the country as net emigration (e.g., -9.26 migrants/
1 ,000 population). The net migration rate indicates the contribution of migration to
the overall level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people are coming
in) or a reduction in the labor force, perhaps in certain key sectors (if people are
leaving).
People: This category includes the entries dealing with the characteristics of the
people and their society.
People— note: This entry includes miscellaneous demographic information of
significance not included elsewhere.
xx
Notes and Definitions (continued)
Personal Names— Capitalization: The Factooo/c capitalizes the surname or
family name of individuals for the convenience of our users who are faced with a
world of different cultures and naming conventions. An example would be
President SADDAM Husayn of Iraq. Saddam is his name and Husayn is his
father''s name, He may be referred to as President SADDAM Husayn or President
SADDAM, but not President Husayn. The need for capitalization, bold type,
underlining, italics, or some other indicator of the individual''s surname is apparent
in the following examples: MAO Zedong, Fidel CASTRO Ruz, William Jefferson
CLINTON, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-Marhum Sultan
Hisammuddin Alam Shah. By knowing the surname, a short form without all
capital letters can be used with confidence as in President Saddam, President
Castro, Chairman Mao, President Clinton, or Sultan Tunku Salahuddin. The same
system of capitalization is extended to the names of leaders with surnames that
are not commonly used such as Queen ELIZABETH II.
Personal Names— Spelling: The romanization of personal names in the
Factbook normally follows the same transliteration system used by the US Board
on Geographic Names for spelling place names. At times, however, a foreign
leader expressly indicates a preference for, or the media or official documents
regularly use, a romanized spelling that differs from the transliteration derived from
the US Government standard. In such cases, the Factbook uses the alternative
spelling.
Personal Names— Titles: The Factbook capitalizes any valid title (or short form
of it) immediately preceding a person''s name. A title standing alone is lowercased.
Examples: President YEL''TSIN and President CLINTON are chiefs of state. In
Russia, the president is chief of state and the premier is the head of the
government, while in the US, the president is both chief of state and head of','e1f9aef5902f6b36223dfb632cc42a6fdca1c6f6cd69af69feb06644f505e418','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bcd06c35cada938db76aab582978dc1984afb3c19730a7594e09fc4937ca399',1999,'ZW','Zimbabwe','raw',7,'536
Taiwan
538
IV
Appendixes
Page
A: Abbreviations 541
B: United Nations System 549
C: International Organizations and Groups 550
D: Selected International Environmental Agreements 602
E: Weights and Measures 609
F: Cross-Reference List of Country Data Codes 622
G: Cross-Reference List of Hydrographic Data Codes 630
H: Cross-Reference List of Geographic Names 635
Reference Maps Africa
Antarctic Region
Arctic Region
Asia
Central Africa
Central America and the Caribbean
Central Balkan Region
Commonwealth of Independent States
Europe
Kosovo
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World','18687cd0cf5df4d8f2ffafa3cedd524fc4def0f3833f348a22b9fee267129be3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3afe04638d8067ca1e2a096f556c82fd68a50e87e377dae4381b2605568456e7',1999,'','','raw',1,'The Project Gutenberg EBook of The 1999 CIA Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1999 CIA Factbook
Author: United States. Central Intelligence Agency.
Release Date: December 31, 2008 [EBook #27676]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1999 CIA FACTBOOK ***
Produced by Al Haines
The World Factbook 1999
In general, information available as of 1 January 1999 was used in the
preparation of this edition.
The World Factbook is prepared by the Central Intelligence Agency for
the use of US Government officials, and the style, format, coverage,
and content are designed to meet their specific requirements.
Information is provided by the Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department of Labor), Central
Intelligence Agency, Council of Managers of National Antarctic
Programs, Defense Intelligence Agency (Department of Defense), Defense
Threat Reduction Agency (Department of Defense), Department of State,
Fish and Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National Imagery and
Mapping Agency (Department of Defense), Antarctic Information Program
(National Science Foundation), Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs (Department of the
Interior), Office of Naval Intelligence (Department of Defense), US
Board on Geographic Names (Department of the Interior), and other
public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA). The
official seal of the CIA, however, may NOT be copied without permission
as required by the CIA Act of 1949 (50 U.S.C. section 403m). Misuse of
the official seal of the CIA could result in civil and criminal
penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
=====================================================================
Country Listings
A','8da198785aaa7aefa889e5efaad53e0c5dfa6fae82361bf820593fd6a8bb9035','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bafe378ec7bac8375df7456c1f113eeacc86a5ecb8ce3e645a2c8b737599a52a',1999,'ZW','Zimbabwe','raw',2,'Taiwan
=====================================================================
Appendixes
A. Abbreviations
B. United Nations System
C. International Organizations and Groups
D. Selected International Environmental Agreements
E. Weights and Measures
F. Cross-Reference List of Country Data Codes
G. Cross-Reference List of Hydrographic Data Codes
H. Cross-Reference List of Geographic Names
=====================================================================
Notes and Definitions
In addition to the updating of information, the following
changes have been made in this edition of The World
Factbook. The name Wake Island has been officially changed
to Wake Atoll. The Historical perspective and Current issues
entries in the Introduction category have been combined into
a new Background entry. It appears in only a few country
profiles at this time. There are new entries on Population
below poverty line, Household income or consumption by
percentage share, Electricity--production by source (fossil
fuel, hydro, nuclear, other), Electricity--exports, and
Electricity--imports. A new reference map of Kosovo has been
included and terrain has been added to most of the reference
maps.
Abbreviations: This information is included in Appendix A:
Abbreviations, which includes all abbreviations and acronyms
used in the Factbook, with their expansions.
Administrative divisions: This entry generally gives the
numbers, designatory terms, and first-order administrative
divisions as approved by the US Board on Geographic Names
(BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the
population according to age. Information is included by sex
and age group (0-14 years, 15-64 years, 65 years and over).
The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high
percentage under age 15) need to invest more in schools,
while countries with older populations (high percentage ages
65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential
political issues. For example, the rapid growth of a young
adult population unable to find employment can lead to
unrest.
Agriculture--products: This entry is a rank ordering of major
crops and products starting with the most important.
Airports: This entry gives the total number of airports. The
runway(s) may be paved (concrete or asphalt surfaces) or
unpaved (grass, dirt, sand, or gravel surfaces), but must be
usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports--with paved runways: This entry gives the total
number of airports with paved runways (concrete or asphalt
surfaces). For airports with more than one runway, only the
longest runway is included according to the following five
groups --(1) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to
2,437 m, (4) 914 to 1,523 m, and (5) under 914 m. Only
airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance,
or air traffic control.
Airports--with unpaved runways: This entry gives the total
number of airports with unpaved runways (grass, dirt, sand,
or gravel surfaces). For airports with more than one runway,
only the longest runway is included according to the
following five groups--(1) over 3,047 m, (2) 2,438 to 3,047
m, (3) 1,524 to 2,437 m, (4) 914 to 1,523 m, and (5) under
914 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for
refueling, maintenance, or air traffic control.
Appendixes: This section includes Factbook-related material
by topic.
Area: This entry includes three subfields. Total area is the
sum of all land and water areas delimited by international
boundaries and/or coastlines. Land area is the aggregate of
all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes,
reservoirs, rivers). Water area is the sum of all water
surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes,
reservoirs, rivers).
Area--comparative: This entry provides an area comparison
based on total area equivalents. Most entities are compared
with the entire US or one of the 50 states based on area
measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington,
DC (178 sq km, 69 sq mi) or The Mall in Washington, DC (0.59
sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic
events, current issues, and may include a statement about
one or two key future trends. This entry appears for only a
few countries at the present time, but will be added to all
countries in the future.
Birth rate: This entry gives the average annual number of
births during a year per 1,000 persons in the population at
midyear; also known as crude birth rate. The birth rate is
usually the dominant factor in determining the rate of
population growth. It depends on both the level of fertility
and the age structure of the population.
Budget: This entry includes revenues, total expenditures,
and capital expenditures. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity
(PPP) terms.
Capital: This entry gives the location of the seat of','8ed5908b81e0a17cab5a4fe1205d5cd52cd028335d91693640fef38dea25f3f8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

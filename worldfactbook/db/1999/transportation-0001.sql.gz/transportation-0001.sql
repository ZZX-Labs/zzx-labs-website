SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68a0d7145b37faa4405dd73e5e8714539e4a242149bec671e10810d2b0b6160b',1999,'EH','Western Sahara','transportation',13,'Railways
total
broad gauge
dual gauge
narrow gauge
standard gauge
other gauges
Highways
total
paved
unpaved
xxvii
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports— with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports— with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Transportation— note
Railways:
total: 1 ,201 ,337 km includes about 190,000 to
1 95,000 km of electrified routes of which 1 47,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,1 60 km in
North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) - Atlantique line
broad gauge: 251,153 km
standard gauge: 71 0,754 km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina'' al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama
Merchant marine:
total: 28,31 0 ships (1 ,000 GRT or over) totaling
495,299,489 GRT/764, 129, 056 DWT
ships by type: barge carrier 23, bulk 5,745, cargo
8,766, chemical tanker 1,326, combination bulk 319,
531
World (continued)
combination ore/oil 227, container 2,61 5, liquefied gas
tanker 802, livestock carrier 60, multifunction
large-load carrier 90, oil tanker 4,521 , passenger 392,
passenger-cargo 126, railcar carrier 19, refrigerated
cargo 1,067, roll-on/roll-off cargo 1,117, short-sea
passenger 484, specialized tanker 118, vehicle carrier
493(1998 est.)','f3ab7c5107a8da7de5ce8f5732a4f8eb8a4ef5bc49285989d3122d1c5fb3597a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27c02606e1b8a9de52d1e18557d019c857c2a56bd3fa6015b31fb966ae607556',1999,'AF','Afghanistan','transportation',21,'Railways:
total: 24.6 km
broad gauge: 9.6 km 1 ,524-m gauge from Gushgy
(Turkmenistan) to Towraghondi; 15 km 1.524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
Highways:
total: 21 ,000 km
paved: 2,793 km
unpaved: 18,207 km (1996 est.)
Waterways: 1 ,200 km; chiefly Amu Darya, which
handles vessels up to about 500 DWT
Pipelines: petroleum products - Uzbekistan to
Bagram and Turkmenistan to Shindand; natural gas
180 km
Ports and harbors: Kheyrabad, Shir Khan
Merchant marine:
total: 1 container ship (1 ,000 GRT or over) totaling
2
Afghanistan (continued)
11,982 GRT/14, 101 DWT (1998 est.)
Airports: 44 (1998 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 33
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
91 4 to 1,523 m: 4
under 914 m: 10 (1998 est.)
Heliports: 3 (1998 est.)
Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none
Airports: 7 (1998 est, )
Airports - with paved runways:
total: 4
1,524 to 2, 437 m: 3
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)','4749b664db405023cf440ea6249067f996ebc6eac340f6cc281082e23dcb74cd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00aecbd49dfa8cd1790af5a96a2610be5e90e101624c668e44e900c5a9c19adb',1999,'AL','Albania','transportation',28,'Railways:
total: 447 km (none electrified)
standard gauge: 447 km 1.435-m gauge (1995)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1996 est.)
Waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55
km; natural gas 64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin,
Vlore
Merchant marine:
total: 8 cargo ships (1 ,000 GRT or over) totaling
28,394 GRT/41 ,429 DWT (1998 est.)
Airports: 9 (1998 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (1998 est.)
Heliports: 1 (1 998 est.)
Railways:
total: 4,772 km
standard gauge: 3,616 km 1.435-m gauge (301 km
electrified; 215 km double track)
narrow gauge: 1 ,156 km 1 ,055-m gauge
Highways:
total: 102,424 km
paved: 70,570 km (including 608 km of expressways)
unpaved: 31 ,854 km (1995 est.)
Pipelines: crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Dellys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 78 ships (1 ,000 GRT or over) totaling 933,672
GRT/1 ,094,104 DWT
ships by type: bulk 9, cargo 27, chemical tanker 7,
liquefied gas tanker 1 1 , oil tanker 5, roll-on/roll-off
cargo 13, short-sea passenger 5, specialized tanker 1
(1998 est.)
Airports: 137 (1998 est.)
Airports - with paved runways:
total: 51
over 3,047 m: 8
2,438 to 3,047 m: 24
1,524 to 2,437 m: 1 3
914 to 1,523 m: 5
under 914 m:1 (1998 est.)
Airports - with unpaved runways:
total: 86
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 40
under 914 m: 19 (1998 est.)
Heliports: 1 (1 998 est.)','2ee37121a874086142f0a65d5b00cc8f54c8ac5d8ca0e6367a83d7763f7a55e1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4248b6b55bf87151d5249123479d2d557032d4a8f22ee7ebd96713ec14c3067a',1999,'AS','American Samoa','transportation',37,'Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1 998 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 71 km (1991 est.)
Ports and harbors: none
Airports: none','6e10fcef70d04255f1df7cf7257f6124348ded3711bbc34af2258fa63cefb71f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54be0f2a29f0589117bf1a6aad1e12b3561025aefe993a27b26eaf28fa925391',1999,'AI','Anguilla','transportation',46,'Railways:
total: 2,952 km (limited trackage in use because of
land mines still in place from the civil war) (1997 est.)
narrow gauge: 2,798 km 1.067-m gauge; 154 km
0.600-m gauge
Highways:
total: 76,626 km
paved: 19,156 km
unpaved: 57,470 km (1997 est.)
Waterways: 1 ,295 km navigable
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Namibe, Porto Amboim, Soyo
Merchant marine:
total: 10 ships (1 ,000 GRT or over) totaling 48,384
GRT/78,357 DWT
ships by type: cargo 9, oil tanker 1 (1 998 est.)
Airports: 252 (1998 est.)
Airports - with paved runways:
total: 32
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 220
over 3,047 m:1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 32
914 to 1,523 m: 100
under 914 m: 82 (1998 est.)
Railways: 0 km
14
Anguilla (continued)
Highways:
total: 105 km
paved: 65 km
unpaved: 40 km (1992 est.)
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1998 est.)','5b598b58f85850d95aa7373aff7cc038056999327b042314f206a12087e0dcda','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79848c5e3928f2433262572dba492ccbed751be26ec0345abd2f15821a394d70',1999,'AQ','Antarctica','transportation',58,'Ports and harbors: none; offshore anchorage
Airports: 17; 27 stations, operated by 16 national
governments party to the Antarctic Treaty, have
landing facilities for either helicopters and/or
fixed-wing aircraft; commercial enterprises operate
two additional air facilities; helicopter pads are
available at 27 stations; runways at 15 locations are
gravel, sea-ice, blue-ice, or compacted snow suitable
for landing wheeled, fixed-wing aircraft; of these, 1 is
greater than 3 km in length, 6 are between 2 km and
3 km in length, 3 are between 1 km and 2 km in length,
3 are less than 1 km in length, and 2 are of unknown
length; snow surface skiways, limited to use by
ski-equipped, fixed-wing aircraft, are available at
another 1 5 locations; of these, 4 are greater than 3 km
in length, 3 are between 2 km and 3 km in length, 2 are
between 1 km and 2 km in length, 2 are less than 1 km
in length, and 4 are of unknown length; airports
generally subject to severe restrictions and limitations
resulting from extreme seasonal and geographic
conditions; airports do not meet ICAO standards;
advance approval from the respective governmental
or nongovernmental operating organization required
for landing (1998 est.)
Airports - with unpaved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m; 5 (1998 est.)
Heliports: 1 (1998 est.)
16
Antarctica (continued)
Railways:
total: 37,830 km
broad gauge: 23,992 km 1.676-m gauge (167 km
electrified)
standard gauge: 2,765 km 1 .435-m gauge
narrow gauge: 1 1 ,073 km 1 ,000-m gauge (26 km
electrified)
Highways:
total: 208,350 km
paved: 47,550 km (including 567 km of expressways)
unpaved: 160,800 km (1998 est.)
Waterways: 1 1 ,000 km navigable
Pipelines: crude oil 4,090 km; petroleum products
2,900 km; natural gas 9,918 km
Ports and harbors: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, Concepcion del Uruguay, La
Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 29 ships (1 ,000 GRT or over) totaling 233,856
GRT/363,335 DWT
ships by type: cargo 10, container 1 , oil tanker 13,
railcar carrier 1 , refrigerated cargo 2, roll-on/roll-off
cargo 1 , short-sea passenger 1 (1998 est.)
Airports: 1 ,374 (1 998 est.)
Airports - with paved runways:
total: 141
over 3,047 m: 5
2,438 to 3,047m: 26
1,524 to 2,437 m: 58
914 to 1,523 m: 45
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 1 ,233
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 67
914 to 1,523 m: 621
under 914 m: 541 (1998 est.)','756e4c13d67c3b8851d7b35ef5bc40f8897fdb21c13ce5496a0fa6092e9c74db','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e30db21a2b556acef842b0550fa53a4c49e4377f245ced48b7772f0a0c74d788',1999,'GP','Guadeloupe','transportation',67,'Railways:
total: 77 km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.61 0-m
gauge (used almost exclusively for handling
sugarcane)
Highways:
total: 250 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Saint John''s
Merchant marine:
total: 51 7 ships (1 ,000 GRT or over) totaling
2,706,126 GRT/3, 542, 664 DWT
ships by type: bulk 21 , cargo 338, chemical tanker 7,
combination bulk 2, container 111, liquefied gas
tanker 2, multifunctional large-load carrier 1 , oil tanker
4, refrigerated cargo 9, roll-on/roll-off cargo 21 ,
vehicle carrier 1
note: a flag of convenience registry: Germany owns
10 ships, Slovenia 2, and Cyprus 2 (1998 est.)
18
Antigua and Barbuda (continued)
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
T ransportation - note: sparse network of air, ocean,
river, and land routes; the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways','a279042981696af1b726ffd3fbb20177ecf56f2acd19c021927d56490759c1c9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c25b5b4a9f6bdf827bbe3fe41e14c05734ddc72f00748a6f53b5960035111a6b',1999,'GE','Georgia','transportation',84,'Railways:
total: 825 km in common carrier service; does not
include industrial lines
broad gauge: 825 km 1.520-m gauge (1992)
Highways:
total: 8,580 km
paved: 8,580 km
unpaved: 0 km (1996 est.)
Waterways: NAkm
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 11 (1996 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1996 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2, 437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (1996 est.)
Railways: 0 km
Highways:
total: 300 km
paved: 130 km
unpaved: 170 km
note: most coastal roads are paved, while unpaved
roads serve large tracts of the interior
Ports and harbors: Barcadera, Oranjestad, Sint
Nicolaas
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,366
GRT/1,595 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
27
Atlantic Ocean (continued)
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
Transportation - note: Kiel Canal and Saint
Lawrence Seaway are two important waterways
Railways:
total: 1 ,583 km in common carrier service; does not
include industrial lines
broad gauge: 1 ,583 km 1.520-m gauge (1993)
Highways:
total: 20,700 km
paved: 19,354 km
unpaved: 1 ,346 km (1 996 est.)
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Bat''umi, P''ot''i, Sokhumi
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 86,667
GRT/121 ,679 DWT
ships by type: cargo 2, oil tanker 5, short-sea
passenger 1 (1998 est.)
Airports: 28 (1994 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (1994 est.)
Airports - with unpaved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 914 m: 6 (1994 est.)
Transportation - note: transportation network is in
poor condition and disrupted by ethnic conflict,
criminal activities, and fuel shortages; network lacks
maintenance and repair','cf1fbecf773063b862341defe51421321ee351b02ad6f644f38c78ed4ebc91ab','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba647e6b979c03f078eefe2b0f03be00e9bffbddccb7b3a5db1340da94448673',1999,'AU','Australia','transportation',96,'Railways:
total: 38,563 km (2,914 km electrified)
broad gauge: 6,083 km 1 ,600-m gauge
standard gauge: 16,752 km 1 .435-m gauge
narrow gauge: 15,728 km 1.067-m gauge
dual gauge: 1 72 km NA gauges
Highways:
total: 91 3,000 km
paved: 353,331 km (including 13,630 km of
expressways)
unpaved: 559,669 km (1996 est.)
Waterways: 8,368 km; mainly by small, shallow-draft
craft
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantle, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 57 ships (1 ,000 GRT or over) totaling 1 ,767,387
GRT/2,426,710 DWT
ships by type: bulk 29, cargo 3, chemical tanker 4,
container 4, liquefied gas tanker 4, oil tanker 8,
passenger 1 , roll-on/roll-off cargo 4 (1 998 est.)
Airports: 408 (1998 est.)
Airports - with paved runways:
total: 262
over 3,047 m: 11
2,438 to 3,047 m: 11
1,524 to 2,437 m: 112
914 to 1,523 m: 120
under 91 4 m: 8 (1998 est.)
Airports - with unpaved runways:
total: 146
1,524 to 2,437 m: 19
914 to 1,523 m: 114
under 914 m: 1 3 (1 998 est.)
Railways:
total: 5,849 km (there is also 594 km of private tracks)
standard gauge: 5,470 km 1 ,435-m gauge (3,41 8 km
electrified)
narrow gauge: 379 km 1 ,000-m and 0.760-m gauge
(84 km electrified) (1997)
Highways: 129,061 km
paved: 129,061 km (including 1,613 km of
expressways)
unpaved: 0 km (1997 est.)
Waterways: 358 km (1997)
Pipelines: crude oil 777 km; natural gas 840 km
(1997)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 22 ships (1 ,000 GRT or over) totaling 67,066
GRT/95,693 DWT
ships by type: bulk 1 , cargo 1 8, combination bulk 2,
container 1 (1998 est.)
Airports: 55 (1998 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 12 (1998 est.)
Airports - with unpaved runways:
total: 33
914 to 1,523 m: 4
under 914 m: 29 (1998 est.)
Heliports: 1 (1 998 est.)
Ports and harbors: none; offshore anchorage only
Ports and harbors: none; offshore anchorage only
Railways:
total: 862 m; note - connects to Italy''s network at
Rome''s Saint Peter''s station
narrow gauge: 862 m 1.435-m gauge
Highways: none; all city streets
Ports and harbors: none
Airports: none
Heliports: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area along the middle
of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
Earhart and Fred Noonan - they left Lae, New Guinea,
for Howland Island, but were never seen again; the
airstrip is no longer serviceable
Transportation - note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia Earhart
Railways: 0 km
Highways:
total: 234 km
paved: 0 km
unpaved: 234 km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: 1 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2, 437 m: 1 (1998 est.)','e9ff4c8483f7e12628f8349bde4c9e44d05c23ee8562ce1703e81dc87981d743','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceaad256c7abf6a629acd4311302b8aa2d116492d0abc402e812225c85ec49da',1999,'AZ','Azerbaijan','transportation',105,'Railways:
total: 2,125 km in common carrier service; does not
include industrial lines
broad gauge: 2,125 km 1 ,520-m gauge (1 ,278 km
electrified) (1993)
Highways:
total: 57,770 km
paved: 54,188 km
unpaved: 3,582 km (1995 est.)
Pipelines: crude oil 1 ,130 km; petroleum products
630 km; natural gas 1 ,240 km
Ports and harbors: Baku (Baki)
Merchant marine:
total: 57 ships (1 ,000 GRT or over) totaling 251 ,404
GRT/ 306,264 DWT
ships by type: cargo 12, oil tanker 42, roll-on/roll-off
cargo 2, short-sea passenger 1 (1998 est.)
Airports: 69 (1996 est.)
Airports - with paved runways:
total: 29
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 17
914 to 1,523 m: 3
under 91 4 m: 1 (1996 est.)
Airports - with unpaved runways:
total: 40
914 to 1,523 m: 7
under 914 m: 33 (1 996 est.)','0c8c07ebfeb608e2ca157a3f8b15f9dda96b8664b4e70747bd33b6745b3d97a8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('571e6b6a091fee39814eed74065488ad56aa9979a2556a7fae2b4dc0e051ea73',1999,'BS','Bahamas','transportation',110,'Railways: 0 km
Highways:
total: 2,693 km
paved: 1 ,546 km
unpaved: 1,147 km (1997 est.)
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,079 ships (1 ,000 GRT or over) totaling
26,631,924 GRT/41 ,196,326 DWT
ships by type: bulk 209, cargo 241 , chemical tanker
43, combination bulk 13, combination ore/oil 22,
container 61 , liquefied gas tanker 34, livestock carrier
1 , oil tanker 170, passenger 62, passenger-cargo 1 ,
railcar carrier 1 , refrigerated cargo 1 40, roll-on/roll-off
cargo 48, short-sea passenger 12, specialized tanker
2, vehicle carrier 19
note: a flag of convenience registry; includes ships
from 49 countries among which are Norway 177,
Greece 1 41 , UK 1 1 3, US 61 , Denmark 39, Finland 27,
Japan 25, Sweden 24, France 22, and Italy 22 (1998
est.)
Airports: 62 (1998 est.)
Airports - with paved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 15
914 to 1,523 m: 13
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m:21 (1998 est.)','db20c9f7b9da6f21d8f58ad78755d883dd9418e2523ea754734473840b0e4b44','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa7b4863f330d42ea9cf8c22e5a286b28ce9486b5aefef696c55fc0e7026758',1999,'BH','Bahrain','transportation',118,'Railways: 0 km
Highways:
total: 3,1 03 km
paved: 2,374 km
unpaved: 729 km (1997 est.)
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 228,273
GRT/304,654 DWT
ships by type: bulk 2, cargo 3, container 2, oil tanker 1
(1998 est.)
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 2 (1 998 est.)
Airports • with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Heliports: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area along the middle
of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
m, completely covered with vegetation and unusable
Transportation - note: there is a day beacon near
the middle of the west coast','57385018e579e2b2f680193c5a4b8b33969ba5df0526f673d6f24d30d35551b0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2e092cb87293d786ce7b04c4b3a5d8f758a1762e7f45973b3063a420480d99',1999,'BD','Bangladesh','transportation',126,'Railways:
total: 2,745 km
broad gauge: 923 km 1 ,676-m gauge
narrow gauge: 1 ,822 km 1.000-m gauge (1998 est.)
Highways:
total: 204,022 km
paved: 25,095 km
unpaved: 178,927 km (1996 est.)
Waterways: 5,150-8,046 km navigable waterways
(includes 2,575-3,058 km main cargo routes)
Pipelines: natural gas 1 ,220 km
Ports and harbors: Chittagong, Dhaka, Mongla
Port
Merchant marine:
total: 40 ships (1,000 GRT or over) totaling 315,855
GRT/453,002 DWT
ships by type: bulk 2, cargo 33, oil tanker 2,
refrigerated cargo 1 , roll-on/roll-off cargo 2 (1 998 est.)
Airports: 16 (1998 est.)
Airports - with paved runways:
total: 15
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m: 7 (1 998 est.)
Airports - with unpaved runways:
total: 1
over 3,047 m:1 (1998 est.)','813b9e32c61417e48949e6f7982fc01330ee83c90542b8031606a12973160203','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a2f2506f5bd18bba4ae8c286888fa121bf8cfeea9e6e8e85f7d64afe6530957',1999,'LC','Saint Lucia','transportation',135,'Railways: 0 km
Highways:
total: 1 ,650 km
paved: 1,582 km
unpaved: 68 km (1998 est.)
Ports and harbors: Bridgetown, Speightstown (Port
Charles Marina)
Merchant marine:
total: 44 ships (1 ,000 GRT or over) totaling 641 ,550
GRT/1 ,087,042 DWT
ships by type: bulk 1 1 , cargo 26, combination bulk 1 ,
oil tanker 4, refrigerated cargo 1 , roll-on/roll-off cargo
1
note: a flag of convenience registry; includes ships of
2 countries: Canada owns 2 ships, Hong Kong 1
(1998 est.)
Airports: 1 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)','c77b60db7a232515378ece42417415eadc9cf024df3313b93dd1f3890477ec52','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d62103db5084d4ee16aab433cc151829cf2e45e957161310168c67b9ccfe54',1999,'MZ','Mozambique','transportation',143,'Ports and harbors: none; offshore anchorage only
Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1996 est.)
Ports and harbors: Fomboni, Moroni,
Moutsamoudou
Merchant marine: none
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (1998 est.)
Railways:
total: 3,131 km
narrow gauge: 2,988 km 1.067-m gauge; 143 km
0.762-m gauge (1994)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (1996 est.)
Waterways: about 3,750 km of navigable routes
Pipelines: crude oil 306 km; petroleum products 289
km
note: not operating
Ports and harbors: Beira, Inhambane, Maputo,
Nacala, Pemba, Quelimane
Merchant marine:
total: 3 cargo ships (1 ,000 GRT or over) totaling 4,125
GRT/7,024 DWT (1998 est.)
Airports: 174 (1998 est.)
Airports - with paved runways:
total: 22
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 91 4 m: 4 (1 998 est.)
Airports - with unpaved runways:
total: 152
2,438 to 3,047 m: 1
1,524 to 2, 437 m: 16
914 to 1,523 m: 39
under 914 m: 96 (1998 est.)
Pipelines: petroleum products 212 km
Ports and harbors: Binga, Kariba
Airports: 467 (1998 est.)
Airports - with paved runways:
total: 18
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 9(1998 est.)
Airports - with unpaved runways:
total: 449
1,524 to 2,437 m: 4
914 to 1,523 m: 220
under 914 m: 225 (1 998 est.)
Railways:
total: 4,600 km (519 km electrified); note - 1,108 km
belongs to the Taiwan Railway Administration and the
remaining 3,492 km is dedicated to industrial use
narrow gauge: 4,600 km 1.067-m
Highways:
total: 19,634 km
paved: 17,171 km (including 548 km of expressways)
unpaved: 2,463 km (1997)
Pipelines: petroleum products 615 km; natural gas
97 km
Ports and harbors: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, T''ai-chung
Merchant marine:
total: 180 ships (1 ,000 GRT or over) totaling
5,106,573 GRT/7, 963, 834 DWT
ships by type: bulk 47, cargo 30, combination bulk 3,
container 72, oil tanker 17, refrigerated cargo 9,
roll-on/roll-off cargo 2 (1998 est.)
Airports: 39 (1998 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 12
1,524 to 2,437 m: 6
914 to 1,523 m: 6
under 914 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m:1
under 91 4 m: 2 (1998 est.)
Heliports: 2 (1998 est.)','08e81d8e1d9f04bf2cbf9be5c86aead9027777e9e1568ba0cfedf711303ce786','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7b74e36b144ed6204bcae82d731b5e5d20bf54302d09fe3d24a6adfff06ed9',1999,'DE','Germany','transportation',153,'Railways:
total: 5,563 km
broad gauge: 5,563 km 1 .520-m gauge (894 km
electrified)
Highways:
total: 53,407 km
paved: 52,446 km
unpaved: 961 km (1997 est.)
Waterways: NA km; note - Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1 ,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 118 (1996 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 18
1,524 to 2,437 m: 5
under 91 4 m: 11 (1996 est.)
Airports - with unpaved runways:
total: 82
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 62 (1 996 est.)
Railways:
total: 3,380 km (2,459 km electrified; 2,563 km double
track)
standard gauge: 3,380 km 1.435-m gauge (1996)
Highways:
total: 143,175 km
paved: 143,175 km (including 1,674 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 2,043 km (1,528 km in regular
commercial use)
Pipelines: crude oil 161 km; petroleum products
1,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mons,
Namur, Oostende, Zeebrugge
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 35,668
GRT/56,412 DWT
ships by type: bulk 1 , cargo 8, chemical tanker 8, oil
tanker 6 (1998 est.)
Airports: 42 (1998 est.)
Airports - with paved runways:
total: 24
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 6 (1998 est.)
Airports - with unpaved runways:
total: 18
914 to 1,523 m: 2
under 914 m: 16 (1998 est.)
Heliports: 1 (1998 est.)
I Military
Military branches: Army, Navy, Air Force, National
Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,537,544 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,098,883 (1999 est.)
Military manpower - reaching military age
annually:
males: 64,180 (1999 est.)
Military expenditures - dollar figure: $4.6 billion
(1995)
Military expenditures - percent of GDP: 1 .7%
(1995)
Railways:
total: 275 km
standard gauge: 275 km 1.435-m gauge (262 km
electrified; 178 km double track) (1995)
Highways:
total: 5,137 km
paved: 5,086 km (including 123 km of expressways)
unpaved: 51 km (1996 est.)
note: one source lists roads 2,863 km; expressways
115 km
Waterways: 37 km; Moselle
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 37 ships (1 ,000 GRT or over) totaling 1 ,033,045
GRT/1 ,480,023 DWT
ships by type: bulk 1 , chemical tanker 6, liquefied gas
tanker 13, oil tanker 6, passenger 4, roll-on/roll-off
cargo 6, vehicle carrier 1 (1998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Macau
Merchant marine: none
Airports: 1 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m:1 (1998 est.)
Railways:
total: 922 km
standard gauge: 922 km 1 ,435-m gauge (232 km
electrified) (1997)
Highways:
total: 10,591 km
paved: 5,500 km (including 133 km of expressways)
unpaved: 5,091 km (1997 est.)
Waterways: none, lake transport only
Pipelines: 0 km
Ports and harbors: none
Airports: 16 (1998 est.)
Airports - with paved runways:
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (1998 est.)
Airports - with unpaved runways:
total: 6
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)
Railways:
total: 883 km
narrow gauge: 883 km 1 ,000-m gauge (1 994)
Highways:
total: 49,837 km
paved: 5,781 km
unpaved: 44,056 km (1996 est.)
Waterways: of local importance only; isolated
streams and small portions of Lakandranon''
Ampangalana (Canal des Pangalanes)
Ports and harbors: Antsiranana,
Antsohimbondrona, Mahajanga, Toamasina, Toliara
Merchant marine:
total: 12 ships (1 ,000 GRT or over) totaling 23,31 1
GRT/31 ,533 DWT
ships by type: cargo 6, chemical tanker 1 , liquefied
gas tanker 1 , oil tanker 2, roll-on/roll-off cargo 2 (1 998
est.)
Airports: 133 (1998 est.)
Airports - with paved runways:
total: 29
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 104
1,524 to 2,437 m: 3
914 to 1,523 m: 59
under 914 m: 42 (1998 est.)
Railways:
total: 101 km; note - all in Kosi close to Indian border
narrow gauge: 101 km 0.762-m gauge
Highways:
total: 7,700 km
paved: 3,1 96 km
unpaved: 4,504 km (1996 est.)
Ports and harbors: none
Airports: 45 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m:1
1,524 to 2,437 m: 3
345
Nepal (continued)
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 40
1,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 29 (1 998 est.)','33495e35c1bbd5e39affe6c3ff81a555fdf25ceaa7a5a64d3cc984d594b6692a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10b98cbfb64a3a6cb195cfd5b0964f10366f32b2a81d2cc1204c98f6feba74dc',1999,'BZ','Belize','transportation',165,'Railways: 0 km
Highways:
total: 2,248 km
paved: 427 km
unpaved: 1 ,821 km (1996 est.)
Waterways: 825 km river network used by
shallow-draft craft; seasonally navigable
Ports and harbors: Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine:
total: 403 ships (1 ,000 GRT or over) totaling
1 ,740,325 GRT/2,51 1 ,709 DWT
ships by type: bulk 34, cargo 259, chemical tanker 5,
container 9, liquefied gas tanker 1 , oil tanker 58,
passenger-cargo 2, refrigerated cargo 21, roll-on/
roll-off cargo 8, short-sea/passenger 3, specialized
tanker 2, vehicle carrier 1
note: a flag of convenience registry; includes ships of
7 countries: Cuba 2, Cyprus 1 , Greece 1 , Singapore 2,
UAE12, UK 1, and US 1 (1998 est.)
Airports: 44 (1998 est.)
Airports - with paved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 41
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 30 (1998 est.)','0304af70bb01049e7f4290f5545e718815b211b00897bd9e2e811cc6dfcde295','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4e7e4a3bb30c4889e459e7848c265ae41ee54f2246cbd24a356b10fe57b327',1999,'BJ','Benin','transportation',172,'Railways:
total: 578 km (single track)
narrow gauge: 578 km 1.000-m gauge (1995 est.)
Highways:
total: 6,787 km
paved: 1,357 km (including 10 km of expressways)
unpaved: 5,430 km (1996 est.)
Waterways: navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 2(1998 est.)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1998 est.)','a2b9b4a4a88ec5ca25919f44e40aa8cc69a6b1ce4c9bb720d8b964dc33227c46','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c212f5d54c1f4a7c29a76645ca239eb8d4336e6c4ea52b93f07f750e0457fc',1999,'BM','Bermuda','transportation',180,'Railways: 0 km
Highways:
total: 225 km
paved: 225 km
unpaved: 0 km (1997 est.)
note: in addition, there are 232 km of paved and
unpaved roads that are privately owned
Ports and harbors: Hamilton, Saint George
Merchant marine:
total: 97 ships (1 ,000 GRT or over) totaling 4,647,576
GRT/7, 61 2,686 DWT
ships by type: bulk 18, cargo 3, chemical tanker 1 ,
container 20, liquefied gas tanker 7, oil tanker 27,
refrigerated cargo 15, roll-on/roll-off cargo 4,
short-sea passenger 2
note: a flag of convenience registry; includes ships
from 1 1 countries among which are UK 24, Canada
12, Hong Kong 1 1 , US 1 1 , Nigeria 4, Sweden 4,
Norway 3, and Switzerland 2 (1998 est.)
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)','e5a6ce98152bb4e4a3f3c4179a77fc23a8d8fa7c0e556137bff7858a2331bd4a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee9475ca136cba8055c0858936a2ef2876154536a0db413c3b69b3020b76e745',1999,'BT','Bhutan','transportation',187,'Railways: 0 km
Highways:
total: 3,285 km
paved: 1 ,994 km
unpaved: 1 ,291 km (1996 est.)
Ports and harbors: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1998 est.)
57
Bhutan (continued)','004e88b196ed007a735c19dd942eeb7248c350e0cf7f9748ed44aa2d3c52c61e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c86f68fdb79774b2465b6d5afab8aa34f798f324f6c6b68fec5ae32a45cf0e2f',1999,'BR','Brazil','transportation',194,'Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1.000-m gauge; 39 km
0.760-m gauge (13 km electrified) (1995)
Highways:
total: 52,216 km
paved: 2,872 km (including 27 km of expressways)
unpaved: 49,344 km (1995 est.)
Waterways: 10,000 km of commercially navigable
waterways
Pipelines: crude oil 1 ,800 km; petroleum products
580 km; natural gas 1,495 km
Ports and harbors: none; however, Bolivia has free
port privileges in the maritime ports of Argentina,
Brazil, Chile, and Paraguay
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 34,948
GRT/58,472 DWT
ships by type: bulk 1 , cargo 5 (1998 est.)
Airports: 1,130 (1998 est.)
Airports - with paved runways:
total: 12
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: est.)
Airports - with unpaved runways:
total: 1,118
2,438 to 3,047 m: 3
1,524 to 2,437 m: 70
914 to 1,523 m: 224
under 914 m: 821 (1998 est.)
Railways:
total: 1 ,021 km (electrified 795 km; operating as diesel
or steam until grids are repaired)
standard gauge: 1 ,021 km 1.435-m gauge (1995);
note - some segments still need repair and/or
reconstruction
Highways:
total: 21 ,846 km
paved: 1 1 ,425 km
unpaved: 10,421 km (1996 est.)
note: roads need maintenance and repair
Waterways: NA km; large sections of Sava blocked
by downed bridges, silt, and debris
Pipelines: crude oil 174 km; natural gas 90 km
(1992); note - pipelines now disrupted
Ports and harbors: Bosanska Gradiska, Bosanski
Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava none of which are fully
operational), Orasje
Merchant marine: none
Airports: 25 (1998 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m:4
1,524 to 2, 437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 16
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 91 4 m: 8 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 971 km
narrow gauge: 971 km 1.067-m gauge (1995)
Highways:
total: 18,482 km
paved: 4,343 km
unpaved: 14,139 km (1996 est.)
Ports and harbors: none
Airports: 92 (1998 est.)
Airports - with paved runways:
total: 12
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 80
1,524 to 2,437 m: 2
914 to 1,523 m: 57
under 914 m: 21 (1 998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 28,862 km (1 ,187 km electrified)
broad gauge: 4,123 km 1.600-m gauge
narrow gauge: 24, 390 km 1.000-m gauge; 13 km
0.760-m gauge
dual gauge: 336 km 1.000-m and 1.600-m gauges
(three rails)
Highways:
total: 1 .98 million km
paved: 184,140 km
unpaved: 1 ,795,860 km (1996 est.)
Waterways: 50,000 km navigable
Pipelines: crude oil 2,980 km; petroleum products
4,762 km; natural gas 4,246 km (1998)
Ports and harbors: Belem, Fortaleza, llheus,
Imbituba, Manaus, Paranagua, Porto Alegre, Recife,
Rio de Janeiro, Rio Grande, Salvador, Santos, Vitoria
Merchant marine:
total: 179 ships (1 ,000 GRT or over) totaling
4,132,037 GRT/6, 642, 442 DWT
ships by type: bulk 35, cargo 28, chemical tanker 6,
combination ore/oil 10, container 10, liquefied gas
tanker 10, multifunction large-load carrier 1 , oil tanker
61, passenger-cargo 5, refrigerated cargo 1 , roll-on/
roll-off cargo 1 1 , short-sea passenger 1 (1998 est.)
Airports: 3,265 (1998 est.)
Airports - with paved runways:
total: 514
over 3,047 m: 5
2,438 to 3,047 m: 19
1,524 to 2,437 m: 134
914 to 1,523 m: 325
under 914 m: 31 (1998 est.)
Airports - with unpaved runways:
total: 2,751
1,524 to 2,437 m: 73
914 to 1,523 m: 1,312
under 914 m:1 ,366 (1 998 est.)
68
Brazil (continued)','fc781d9e1f99f9c9ef3448df0432f8bec317fd07616348d54c226e39750c28d0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b65d3427d5057f41ac003539e90d5564d69b198e36ac08914fac9caace6c43',1999,'IO','British Indian Ocean Territory','transportation',207,'Highways:
total: NA km
paved: short stretch of paved road of NA km between
port and airfield on Diego Garcia
unpaved: NA km
Ports and harbors: Diego Garcia
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways: 0 km
Highways:
fofa/: 113 km (1995 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Road Town
Merchant marine: none
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
574 to 7,523 m: 1 (1998 est.)
Railways:
total: 13 km (private line)
narrow gauge: 13 km 0.61 0-m gauge
Highways:
total: 1,150 km
paved: 399 km
unpaved: 751 km (1996 est.)
Waterways: 209 km; navigable by craft drawing less
than 1 .2 m
Pipelines: crude oil 1 35 km; petroleum products 41 8
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 liquefied gas tankers (1 ,000 GRT or over)
totaling 348,476 GRT/340,635 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 4,292 km
standard gauge: 4,047 km 1 ,435-m gauge (2,650 km
electrified; 917 km double track)
narrow gauge: 245 km 0.760-m gauge (1995)
Highways:
total: 36,724 km
paved: 33,786 km (including 314 km of expressways)
unpaved: 2,938 km (1997 est.)
Waterways: 470 km (1987)
Pipelines: crude oil 1 93 km; petroleum products 525
km; natural gas 1,400 km (1992)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 89 ships (1 ,000 GRT or over) totaling 1 ,005,092
GRT/1 ,508,61 4 DWT
ships by type: bulk 44, cargo 20, chemical tanker 4,
container 2, oil tanker 8, passenger-cargo 1 , railcar
carrier 2, refrigerated cargo 1 , roll-on/roll-off cargo 6,
short-sea passenger 1 (1998 est.)
Airports: 61 (1998 est.)
Airports - with paved runways:
total: 56
over 3,047 m:1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 11
under 914 m: 25 (1 998 est.)
75
Bulgaria (continued)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 1
under 914 m: 4 (1998 est.)','2a7e6b50cb9cf29b9083b21006daaff42fa6d25a31640906b6105b02d3951967','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4891e75f64b16d80fc6d842a89887e1cb1de0560ebde5003844dc186c54a185c',1999,'NG','Nigeria','transportation',218,'Railways:
total: 622 km (517 km from Ouagadougou to the Cote
d''Ivoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km 1 ,000-m gauge (1995 est.)
Highways:
total: 12,506 km
paved: 2,001 km
unpaved: 10,505 km (1995 est.)
Ports and harbors: none
Airports: 33 (1998 est.)
Airports - with paved runways;
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 31
2,438 to 3,047 mA
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 16 (1998 est.)
Railways:
total: 3,740 km
narrow gauge: 3,740 km 1.000-m gauge (1997)
Highways:
total: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1996 est.)
Waterways: 12,800 km; 3,200 km navigable by large
commercial vessels
Pipelines: crude oil 1 ,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk,
Mandalay, Moulmein, Myitkyina, Rangoon, Akyab
(Sittwe), Tavoy
Merchant marine:
total: 41 ships (1 ,000 GRT or over) totaling 464,478
GRT/695,923 DWT
ships by type: bulk 14, cargo 20, container 2, oil
tanker 3, passenger-cargo 2
note: a flag of convenience registry; includes ships of
2 countries: Japan owns 2 ships, US 3 (1998 est.)
Airports: 80 (1998 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 2(1998 est.)
Airports - with unpaved runways:
total: 69
over 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 23
under 914 m: 32 (1998 est.)
Heliports: 1 (1 998 est.)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1.067-m gauge
standard gauge: 52 km 1 ,435-m gauge (1995)
note: years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and
utility of the system; a project to restore Nigeria''s
railways is now underway
Highways:
total: 51 ,000 km
paved: 26,000 km (including 2,044 km of
expressways)
unpaved: 25,000 km (1 998 est.)
note: many of the roads reported as paved may be
graveled; because of poor maintenance and years of
heavy freight traffic (in part the result of the failure of
the railroad system), much of the road system is
barely useable
Waterways: 8,575 km consisting ot the Niger and
Benue rivers and smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products
3,000 km; natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warri
Merchant marine:
total: 38 ships (1 ,000 GRT or over) totaling 371 ,499
GRT/631 ,425 DWT
ships by type: bulk 1 , cargo 1 3, chemical tanker 3, oil
tanker 20, roll-on/roll-off cargo 1 (1998 est.)
Airports: 72 (1998 est.)
Airports - with paved runways:
total: 36 .
over 3,047 m: 6
2,438 to 3,047 m:10
1,524 to 2,437 m: 10
91 4 to 1,523 m: 8
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 36
over 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 16
under 914 m: 18 (1998 est.)
Heliports: 1 (1998 est.)','c63c55c4fecbe719509960df1c68c8de2eb65797bd2bb0d1e5d59c14d2106c2d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab7f618d82f6cf353f980db93c2ebe177a18dcd4d9fa85b00ac7b4cd24c3a2d1',1999,'BI','Burundi','transportation',230,'Railways: 0 km
Highways:
total: 14,480 km
paved: 1 ,028 km
unpaved: 13,452 km (1996 est.)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1 998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Railways:
total: 603 km
narrow gauge: 603 km 1.000-m gauge
Highways:
total: 35,769 km
paved: 4, 165 km
unpaved: 31 ,604 km (1997 est.)
Waterways: 3,700 km navigable all year to craft
drawing 0.6 m; 282 km navigable to craft drawing 1 .8
m
Ports and harbors: Kampong Saom
(Sihanoukville), Kampot, Krong Kaoh Kong, Phnom
Penh
Merchant marine:
total: 141 ships (1 ,000 GRT or over) totaling 598,867
GRT/841 ,240 DWT
ships by type: barge carrier 1 , bulk 1 6, cargo 1 08,
container 4, livestock carrier 2, multifunctional
large-load carrier 1 , oil tankers 1 , refrigerated cargo 4,
roll-on/roll-off cargo 4
note: a flag of convenience registry; includes ships of
8 countries: Aruba 1 , Cyprus 7, Egypt 1 , South Korea
1, Malta 1, Panama 1, Russia 5, Singapore 1 (1998
est.)
Airports: 20 (1998 est.)
Airports - with paved runways:
total: 7
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 3(1998 est.)
Airports - with unpaved runways:
total: 13
1,524 to 2,437 m: 3
914 to 1,523 m: 10 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 1,104 km
narrow gauge: 1 ,1 04 km 1 ,000-m gauge (1 995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1995 est.)
Waterways: 2,090 km; of decreasing importance
Ports and harbors: Bonaberi, Douala, Garoua,
Kribi, Tiko
Airports: 52 (1998 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m:1 (1998 est.)
Airports - with unpaved runways:
total: 41
1,524 to 2, 437 m: 8
914 to 1,523 m: 21
under 914 m: 12 (1998 est.)','dbf22fcb8dea2bef25f0b5e8c229282096ff5739ee5e6eecf5a23d565fda6bb6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1d8780c5ad48de86eefb59c59eb078008ef1d7234ad660fa9823e642114c466',1999,'CA','Canada','transportation',237,'Railways:
total: 67,773 km; note - there are two major
transcontinental freight railway systems: Canadian
National (privatized November 1995) and Canadian
Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage
of its own
standard gauge: 67,773 km 1 .435-m gauge (1 83 km
electrified) (1996)
Highways:
total: 912,200 km
paved: 246,400 km (including 16,600 km of
expressways)
unpaved: 665, 800 km (1996 est.)
Waterways: 3,000 km, including Saint Lawrence
Seaway
Pipelines: crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine:
total: 109 ships (1,000 GRT or over) totaling
1,489,1 10 GRT/2, 205, 274 DWT
ships by type: barge carrier 1 , bulk 56, cargo 1 1 ,
chemical tanker 5, combination bulk 2, oil tanker 16,
passenger 3, passenger-cargo 1 , railcar carrier 2,
roll-on/roll-off cargo 7, short-sea passenger 4,
specialized tanker 1
note: does not include ships used exclusively in the
Great Lakes (1998 est.)
Airports: 1 ,395 (1 998 est.)
Airports - with paved runways:
total: 51 5
over 3,047 m: 16
2,438 to 3,047 m: 16
1,524 to 2,437 m: 154
91 4 to 1,523 m: 238
under 914 m: 91 (1998 est.)
Airports - with unpaved runways:
total: 880
1,524 to 2, 437 m: 73
91 4 to 1,523 m: 353
under 914 m: 454 (1 998 est.)
Heliports: 16 (1998 est.)
Highways:
total: 16,382 km
paved: 1,818 km
unpaved: 14,564 km (1998 est.)
Waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none
356
Nicaragua (continued)
Airports: 184 (1998 est.)
Airports - with paved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 91 4 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 171
1,524 to 2,437 m:1
914 to 1,523 m: 27
under 914 m: 143 (1998 est.)','521e9d9e0cd512d4da673155f28a2e2e298908af7346dcd537eb3942477c0acb','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b5c70464226be1f6df60287741b99f83379dba938baf69067eadced31abf730',1999,'PT','Portugal','transportation',244,'Railways: 0 km
Highways:
total: 1,100 km
paved: 858 km
unpaved: 242 km (1996 est.)
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 9,620 GRT /
13,920 DWT
ships by type: cargo 3, chemical tanker 1 (1 998 est.)
Airports: 6 (1998 est.)
Airports - with paved runways:
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (1998 est.)
Railways:
total: 3,072 km
broad gauge: 2,769 km 1.668-m gauge (528 km
electrified; 426 km double track)
narrow gauge: 303 km 1.000-m gauge (1996)
Highways:
total: 68,732 km
paved: 59,1 10 km (including 687 km of expressways)
unpaved: 9,622 km (1995 est.)
Waterways: 820 km navigable; relatively
unimportant to national economy, used by
shallow-draft craft limited to 300 metric-ton cargo
capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
note: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
394
Portugal (continued)
Merchant marine:
total: 1 32 ships (1 ,000 GRT or over) totaling 894,640
GRT/1 ,366,955 DWT
ships by type: bulk 13, cargo 72, chemical tanker 14,
container 7, liquefied gas tanker 7, oil tanker 9,
refrigerated cargo 1 , roll-on/roll-off cargo 3, short-sea
passenger 4, vehicle carrier 2
note: Portugal has created a captive register on
Madeira for Portuguese-owned ships; ships on the
Madeira Register (MAR) will have taxation and
crewing benefits of a flag of convenience (1998 est.)
Airports: 66 (1998 est.)
Airports - with paved runways:
total: 40
over 3,047 m: 5
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 18
under 914 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 26
914 to 1,523 m:1
under 914 m: 25 (1 998 est.)','a6bdcffc62218305ff48ffabd59dcfdbdcdd4ad82c5a47d3f7a6d6e4fca1fccc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a226881d374ea18e0fdf1df167b8dbf15d6a987b75d15207c97bd6abd0e8d38',1999,'HN','Honduras','transportation',253,'Railways: 0 km
92
Cayman Islands (continued)
Highways:
total: 406 km
paved: 304 km
unpaved: 102 km
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 76 ships (1 ,000 GRT or over) totaling 1,264,113
GRT/1 ,970,959 DWT
ships by type: bulk 1 3, cargo 1 0, chemical tanker 1 1 ,
container 4, liquefied gas tanker 1 , oil tanker 7,
refrigerated cargo 22, roll-on/roll-off cargo 6,
specialized tanker 1 , vehicle carrier 1
note: a flag of convenience registry; includes ships
from 1 1 countries among which are: Greece 1 5, US 5,
UK 5, Cyprus 2, Denmark 2, Norway 3 (1998 est.)
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2(1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 23,810 km
paved: 429 km
unpaved: 23,381 km (1995 est.)
Waterways: 800 km; traditional trade carried on by
means of shallow-draft dugouts; Oubangui is the most
important river
Ports and harbors: Bangui, Nola
Airports: 52 (1998 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 49
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 1 5 (1 998 est.)
Railways: 0 km
Highways:
total: 33,400 km
paved: 267 km
unpaved: 33,133 km (1996 est.)
Waterways: 2,000 km navigable
Ports and harbors: none
Airports: 52 (1998 est.)
Airports - with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 91 4 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 44
1,524 to 2,437 m: 12
914 to 1,523 m: 22
under 914 m: 10 (1998 est.)
Railways:
total: 595 km
narrow gauge: 190 km 1.067-m gauge; 128 km
1.057-m gauge; 277 km 0.914-m gauge
Highways:
total: 14,173 km
paved: 3,126 km
unpaved: 1 1 ,047 km (1998 est.)
Waterways: 465 km navigable by small craft
Ports and harbors: La Ceiba, Puerto Castilla,
Puerto Cortes, San Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 247 ships (1 ,000 GRT or over) totaling 555,534
GRT/730,602 DWT
ships by type: bulk 21 , cargo 1 57, chemical tanker 4,
container 7, livestock carrier 1 , oil tanker 25,
passenger 1 , passenger-cargo 4, refrigerated cargo
15, roll-on/roll-off cargo 6, short-sea passenger 5,
vehicle carrier 1
note: a flag of convenience registry; Russia owns 6
ships, Vietnam 1, Singapore 3, North Korea 1 (1998
est.)
Airports: 122 (1998 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 3
1,524 to 2, 437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 1 1 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 21
under 914 m: 87 (1 998 est.)','2e9a921d1f13c73d9b92c3ba7c8b803c59646273c12bec61b627e836037e85dc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a0a3dd2768dc22d3381d0f581d1df32bfe36293ad7af252441add5ce932ecf0',1999,'CL','Chile','transportation',262,'Railways:
total: 6,782 km
broad gauge: 3,743 km 1 ,676-m gauge (1 ,653 km
electrified)
narrow gauge: 1 16 km 1.067-m gauge; 2,923 km
1 ,000-m gauge (40 km electrified) (1995)
Highways:
total: 79,800 km
paved: 11,012 km
unpaved: 68,788 km (1996 est.)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 42 ships (1 ,000 GRT or over) totaling 527,201
GRT/787,719 DWT
ships by type: bulk 1 1 , cargo 1 0, chemical tanker 5,
container 2, liquefied gas tanker 1 , oil tanker 4,
passenger 3, roll-on/roll-off cargo 4, vehicle carrier 2
(1998 est.)
Airports: 378 (1998 est.)
Airports - with paved runways:
total: 58
over 3,047 m: 5
2,438 to 3,047 m: 6
1,524 to 2,437 m: 19
914 to 1,523 m: 19
under 914 m: 9 (1998 est.)
Airports - with unpaved runways:
total: 320
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 13
91 4 to 1,523 m: 73
under 914 m: 229 (1 998 est.)','cacfe30c168cbf2408605e97250e2e3b27b56d398bc10445621d52bb88b31489','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e14a8e3e3f60382e0557783101fa452d3970c71a9e88725108cf36df0409c49',1999,'HK','Hong Kong','transportation',272,'Railways:
total: 64,900 km (including 5,400 km of provincial
"local" rails)
standard gauge: 61 ,300 km 1.435-m gauge (12,000
km electrified; 20,000 km double track)
narrow gauge: 3,600 km 0.750-m gauge local
industrial lines (1998 est.)
note: a new total of 68,000 km has been estimated for
early 1999
Highways:
fofaM.21 million km
paved: 271 ,300 km (with at least 24,474 km of
motorways)
unpaved: 938,700 km (1998 est.)
Waterways: 109,800 km navigable (1997)
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Tianjin, Xiamen, Xingang, Yantai, Zhanjiang
Merchant marine:
total: 1 ,759 ships (1 ,000 GRT or over) totaling
1 6,828,349 GRT/24,801 ,291 DWT
ships by type: barge carrier 2, bulk 330, cargo 855,
chemical tanker 21 , combination bulk 1 0, combination
ore/oil 1 , container 121 , liquefied gas tanker 20,
multifunction large-load carrier 6, oil tanker 245,
passenger 8, passenger-cargo 47, refrigerated cargo
25, roll-on/roll-off cargo 24, short-sea passenger 43,
vehicle carrier 1 (1998 est.)
Airports: 206 (1996 est.)
Airports - with paved runways:
total: 192
over 3,047 m: 18
2,438 to 3,047 m: 65
1,524 to 2,437 m: 90
914 to 1,523 m: 13
under 914 m: 6 (1996 est.)
Airports - with unpaved runways:
total: 14
1,524 to 2,437 m: 8
914 to 1,523 m: 5
under 914 m: 1 (1996 est.)
102
China (continued)','f2d58cb55907443adc36eb333c388075d20fdd0a92a6df5337fea1827531fa27','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7332a246d89fe70a033c74db017db2be12f9f61175959d37624e34d9de26af01',1999,'CX','Christmas Island','transportation',280,'Railways: 24 km to serve phosphate mines
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Flying Fish Cove
Merchant marine: none
Airports: 1 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)','99340b1dc61a32d0d560c7798c4689d166f96ecf9838bae75b909eb5f148c52e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fc2dee7cd27e37ae8180950efef16b846dcafa562be6ccf4ddb38e18f43f312',1999,'FR','France','transportation',289,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; lagoon anchorage only
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 660 km
narrow gauge: 660 km 1 .000-meter gauge; 25 km
double track (1995 est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,51 1 km (1996 est.)
Waterways: 980 km navigable rivers, canals, and
numerous coastal lagoons
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Merchant marine:
total: 1 oil tanker (1 ,000 GRT or over) totaling 1 ,200
GRT/1,500 DWT (1998 est.)
Airports: 36 (1998 est.)
Airports - with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4(1998 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 8
914 to 1,523 m: 12
under 914 m: 9 (1998 est.)
Railways: 0 km
Highways:
total: 348 km
paved: 83 km
unpaved: 265 km
Ports and harbors: Stanley
Merchant marine: none
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
under 914 m: 3 (1998 est.)
Railways: 0 km (1995)
Highways:
total: 1,817 km (national 432 km, departmental 385
km, community 1 ,000 km)
paved: 727 km
unpaved: 1 ,090 km (1995 est.)
Waterways: 460 km, navigable by small oceangoing
vessels and river and coastal steamers; 3,300 km
navigable by native craft
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none
Airports: 11 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m:1 (1998 est.)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 91 4 m: 5 (1998 est.)
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 66 ships (1 ,000 GRT or over) totaling 2,201 ,120
GRT/3,832,935 DWT
ships by type: bulk 3, cargo 7, chemical tanker 10,
container 9, liquefied gas tanker 6, oil tanker 19,
refrigerated cargo 2, roll-on/roll-off cargo 10 (1998
est.)
Airports: none
Railways:
total: 2,548 km
standard gauge: 1 ,565 km 1 ,435-m gauge (36 km
electrified; 23 km double track)
narrow gauge: 961 km 1 ,000-m gauge; 22 km
0.750-m gauge (a rack type railway for steep grades)
Highways:
total: 117,000 km
paved: 107,406 km (including 470 km of
expressways)
unpaved: 9,594 km (1996 est.)
Waterways: 80 km; system consists of three coastal
canals; including the Corinth Canal (6 km) which
crosses the Isthmus of Corinth connecting the Gulf of
Corinth with the Saronic Gulf and shortens the sea
voyage from the Adriatic to Peiraiefs (Piraeus) by 325
km; and three unconnected rivers
Pipelines: crude oil 26 km; petroleum products 547
km
Ports and harbors: Alexandroupolis, Elefsis,
Irakleion (Crete), Kavala, Kerkyra, Chalkis,
Igoumenitsa, Lavrion, Patrai, Peiraiefs (Piraeus),
Thessaloniki, Volos
Merchant marine:
total: 810 ships (1 ,000 GRT or over) totaling
24,798,431 GRT/44, 056, 618 DWT
ships by type: bulk 307, cargo 66, chemical tanker 1 9,
combination bulk 9, combination ore/oil 12, container
45, liquefied gas tanker 5, multifunction large-load
carrier 1, oil tanker 229, passenger 15,
passenger-cargo 2, refrigerated cargo 4, roll-on/
roll-off cargo 1 7, short-sea passenger 76, specialized
tanker 3 (1998 est.)
Airports: 78 (1998 est.)
Airports - with paved runways:
total: 63
over 3,047 m: 5
2,438 to 3,047 m: 15
1,524 to 2,437 m: 18
914 to 1,523 m: 16
under 914 m: 9 (1998 est.)
Airports - with unpaved runways:
total: 15
1,524 to 2,437 m: 1
91 4 to 1,523 m: 3
192
Greece (continued)
under 914 m: 11 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: NA km; privately owned, narrow-gauge
plantation lines
Highways:
total: 2,082 km
paved: 1 ,742 km
unpaved: 340 km (1985 est.)
note: in 1996 there were a total of 3,200 km of roads
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine: none
Airports: 9 (1998 est.)
Airports - with paved runways:
total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 21, 71 6 km
paved: 9,673.5 km
unpaved: 12,042.5 km (1998 est.)
Waterways: about 4,587 km, primarily Mekong and
tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 2,370
GRT/3,000DWT (1998 est.)
Airports: 52 (1998 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 25 (1998 est.)
Railways: 0 km
Highways:
total: 2,724 km
paved: NA km
unpaved.'' N A km (1994)
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1 998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 2,784 km
paved: 2,1 87 km
unpaved: 597 km (1987 est.)
Ports and harbors: Le Port, Pointe des Galets
Merchant marine:
total: 1 chemical tanker (1,000 GRT or over) totaling
28,264 GRT/44,885 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 7,523 m: 1 (1998 est.)
Railways:
total: 2,260 km
standard gauge: 492 km 1 .435-m gauge
narrow gauge: 1 ,758 km 1 ,000-m gauge
dual gauge: 10 km 1 ,000-m and 1. 435-m gauges
(three rails) (1993 est.)
Highways:
total: 23,100 km
paved: 18,226 km
unpaved: 4,874 km (1996 est.)
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 188,345
GRT/21 5,749 DWT
ships by type: bulk 4, cargo 5, chemical tanker 3,
liquefied gas tanker 1, oil tanker 3, short-sea
passenger 3, specialized tanker 1 (1 998 est.)
Airports: 32 (1998 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (m3 est.)
Airports - with unpaved runways:
total: 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 91 4 m: 7 (1998 est.)
Railways:
total: 10,386 km
standard gauge: 10,386 km 1 ,435-m gauge (1 ,088 km
electrified)
Highways:
total: 382,397 km
paved: 95,599 km (including 1 ,560 km of
expressways)
unpaved: 286,798 km (1997 est.)
Waterways: about 1,200 km
Pipelines: crude oil 1 ,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Icel (Mersin), Samsun,
Trabzon
Merchant marine:
total: 531 ships (1 ,000 GRT or over) totaling
5,913,171 GRT/9,832,994 DWT
ships by type: bulk 1 59, cargo 239, chemical tanker
32, combination bulk 5, combination ore/oil 6,
container 12, liquefied gas tanker 5, oil tanker 36,
passenger-cargo 1 , refrigerated cargo 3, roll-on/
roll-off cargo 21 , short-sea passenger 9, specialized
tanker 3 (1998 est.)
Airports: 117 (1998 est.)
Airports - with paved runways:
total: 81
over 3,047 m: 16
2,438 to 3,047 m: 25
1,524 to 2,437 m: 1 9
914 to 1,523 m: 16
under 914 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 26 (1 998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 2,187 km
broad gauge: 2,1 87 km 1 .520-m gauge (1 996 est.)
Highways:
total: 24,000 km
paved: 19,488 km (note - these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced)
unpaved: 4,512 km (1996 est.)
Waterways: the Amu Darya is an important inland
waterway
Pipelines: crude oil 250 km; natural gas 4,400 km
493
Turkmenistan (continued)
Ports and harbors: Turkmenbashy
Merchant marine:
total: 1 oil tanker (1 ,000 GRT or over) totaling 1 ,896
GRT/3, 389 DWT (1998 est.)
Airports: 64 (1994 est.)
Airports - with paved runways:
total: 22
2,438 to 3,047 m: 13
1,524 to 2,437 m: 8
914 to 1,523 m:1 (1994 est.)
Airports - with unpaved runways:
total: 42
914 to 1,523 m: 7
under 914 m: 35 (1994 est.)
Railways:
total: 16,878 km
broad gauge: 342 km 1 ,600-m gauge (1 90 km double
track); note - all 1 ,600-m gauge track, of which 342 km
is in common carrier use, is in Northern Ireland
standard gauge: 1 6,536 km 1 ,435-m gauge (4,928 km
electrified; 12,591 km double or multiple track) (1996)
Highways:
total: 372,000 km
paved: 372,000 km (including 3,270 km of
expressways)
unpaved: 0 km (1996 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km;
petroleum products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol,
Cardiff, Dover, Falmouth, Felixstowe, Glasgow,
Grangemouth, Hull, Leith, Liverpool, London,
Manchester, Peterhead, Plymouth, Scapa Flow,
Sullom Voe, Tees, Tyne
Merchant marine:
total: 155 ships (1 ,000 GRT or over) totaling
2,460,361 GRT/2,51 7,875 DWT
ships by type: bulk 3, cargo 29, chemical tanker 6,
combination ore/oil 1 , container 25, liquefied gas
tanker 1 , oil tanker 51 , passenger 8, passenger-cargo
1 , roll-on/roll-off cargo 17, short-sea passenger 12,
specialized tanker 1 (1998 est.)
Airports: 497 (1998 est.)
Airports - with paved runways:
total: 356
over 3,047 m: 10
2,438 to 3,047 m: 32
1,524 to 2,437 m: 169
914 to 1,523 m: 91
under 914 m: 54 (1 998 est.)
Airports - with unpaved runways:
fofa/:141
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 117 (1998 est.)
Heliports: 12 (1998 est.)
Railways:
total: 240,000 km mainline routes (nongovernment
owned)
standard gauge: 240,000 km 1.435-m gauge (1989)
Highways:
total: 6.42 million km
paved: 3,903,360 km (including 88,400 km of
expressways)
unpaved: 2,516,640 km (1996 est.)
Waterways: 41 ,009 km of navigable inland
channels, exclusive of the Great Lakes
Pipelines: petroleum products 276,000 km; natural
gas 331,000 km (1991)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago, Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 385 ships (1 ,000 GRT or over) totaling
11,123,848 GRT/15, 255, 996 DWT
ships by type: barge carrier 1 0, bulk 61 , cargo 28,
chemical tanker 1 3, combination bulk 2, container 83,
liquefied gas tanker 9, multifunctional large-load
carrier 3, oil tanker 114, passenger 7,
passenger-cargo 1 , roll-on/roll-off cargo 43, short-sea
passenger 3, specialized tanker 1 , vehicle carrier 7
(1998 est.)
Airports: 14,459 (1998 est.)
Airports - with paved runways:
total: 5,167
over 3,047 m: 180
2,438 to 3,047 m: 219
1,524 to 2, 437 m: 1,294
914 to 1,523 m: 2,447
under 91 4 m: 1,027 (1998 est.)
Airports - with unpaved runways:
total: 9,292
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 156
914 to 1,523 m: 1,647
under 914 m: 7,482 (1998 est.)
Heliports: 122 (1998 est.)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1 ,800 km (1997 est.)
note: Israelis have developed many highways to
service Jewish settlements
Ports and harbors: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (1998 est.)','43e4684b036c5dd316716a48d9767c5571a146473af080e90be2bc50e0c414a8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7d01f43aeea2c5a1e42750563213197fcf9256f327df53a0ce0195e283963aa',1999,'CO','Colombia','transportation',297,'Railways:
total: 3,380 km
standard gauge: 150 km 1.435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia de
Portete)
narrow gauge: 3,230 km 0.91 4-m gauge (1 ,830 km in
use) (1995)
Highways:
total: 11 5,564 km
paved: 13,868 km
unpaved: 101 ,696 km (1997 est.)
Waterways: 14,300 km, navigable by river boats
Pipelines: crude oil 3,585 km; petroleum products
1 ,350 km; natural gas 830 km; natural gas liquids 1 25
km
Ports and harbors: Bahia de Portete, Barranquilla,
Buenaventura, Cartagena, Leticia, Puerto Bolivar,
San Andres, Santa Marta, Tumaco, Turbo
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 64,7575
GRT/84,518 DWT
ships by type: bulk 4, cargo 5, container 1 ,
multifunction large-load carrier 2, oil tanker 2 (1998
est.)
Airports: 1,120 (1998 est.)
Airports - with paved runways:
total: 89
over 3,047 m: 2
2,438 to 3,047m: 9
1,524 to 2,437 m: 36
914 to 1,523 m: 35
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 1,031
2,438 to 3,047 m: 1
1,524 to 2,437 m: 63
914 to 1,523 m: 339
under 914 m: 628 (1998 est.)','6ec2535d522948f351b3dfd0f54a57408a7ec7cad0dc7c59aeb69049e8971a7c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2b3ef77780d2c990fa2e567e2dea15addb8b218c59f3e799233d51c9395ed87',1999,'CG','Congo','transportation',304,'Railways:
total: 5,138 km (1995); note - severely reduced
route-distance in use because of damage to facilities
by civil strife
narrow gauge: 3,987 km 1 ,067-m gauge (858 km
electrified); 125 km 1.000-m gauge; 1,026 km
0.600-m gauge
112
Congo, Democratic Republic of the
(continued)
Highways:
total: 145,000 km
paved: 2,500 km
unpaved: 142,500 km (1993 est.)
Waterways: 15,000 km including the Congo, its
tributaries, and unconnected lakes
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Merchant marine: none
Airports: 233 (1998 est.)
Airports - with paved runways:
total: 23
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437m: 14
914 to 1,523 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 210
1,524 to 2,437 m: 21
914 to 1,523 m: 95
under 91 4 m: 94 (1998 est.)
Railways:
total: 795 km (includes 285 km private track)
narrow gauge: 795 km 1.067-m gauge (1995 est.)
Highways:
total: 12,800 km
paved: 1 ,242 km
unpaved: 1 1 ,558 km (1 996 est.)
Waterways: the Congo and Ubangi (Oubangui)
Rivers provide 1 ,120 km of commercially navigable
water transport; other rivers are used for local traffic
only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Airports: 36 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 32
1,524 to 2,437 m: 8
914 to 1,523 m: 14
under 914 m: 1 0 (1 998 est.)','8c996d418121a127ca5754f49cd528cdc5af8915fc1e864859daf8c8092390c0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddcc0a17e781a51bf1338b9469b7a5ec8335ebec1425963f7b9477b531043063',1999,'CK','Cook Islands','transportation',316,'Railways: 0 km
Highways:
total: 187 km
paved: 35 km
unpaved: 152 km (1980 est.)
Ports and harbors: Avarua, Avatiu
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 2,310
GRT/2,1 81 DWT (1998 est.)
Airports: 7 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:] (1998 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (1998 est.)
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area in the middle of
the west coast and another near the southwest corner
of the island
Transportation - note: there is a day beacon near
the middle of the west coast','a8452031c671bbc268cb75e7b6c04435c68db9a8c2574212e0cee3c20562af67','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba178d8e055b43984b76fc90e6168edc88535ce964f27a56eaf8b64b2b84b089',1999,'CR','Costa Rica','transportation',323,'Railways:
total: 950 km
narrow gauge: 950 km 1 .067-m gauge (260 km
electrified)
Highways:
total: 35,597 km
paved: 6,051 km
unpaved: 29,546 km (1997 est.)
Waterways: about 730 km, seasonally navigable
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine: none
Airports: 156 (1998 est.)
Airports - with paved runways:
total: 28
2,438 to 3,047 m: 2
1,524 to 2,437 m:1
914 to 1,523 m: 18
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 128
914 to 1,523 m: 29
under 914 m: 99 (1998 est.)','4e4316f61fe64658222cfb2c3e4b6dfb948fa1686cc3f66142a4b74b76a240c9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b3bdfeea1c6f1166fb990be1143fa897a39cc0a937315b9fd715aabe490cf5',1999,'SI','Slovenia','transportation',332,'Railways:
total: 2,296 km
standard gauge: 2,296 km 1.435-m gauge (796 km
electrified)
note: some lines remain inoperative or not in use;
disrupted by territorial dispute (1997)
Highways:
total: 27,840 km
paved: 22,690 km (including 330 km of expressways)
unpaved: 5,150 km (1997 est.)
Waterways: 785 km perennially navigable; large
sections of Sava blocked by downed bridges, silt, and
debris
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992); note - under repair
following territorial dispute
Ports and harbors: Dubrovnik, Dugi Rat, Omisalj,
Ploce, Pula, Rijeka, Sibenik, Split, Vukovar (inland
waterway port on Danube), Zadar
Merchant marine:
total: 64 ships (1 ,000 GRT or over) totaling 810,226
GRT/1 ,227,468 DWT
ships by type: bulk 15, cargo 26, chemical tanker 2,
combination bulk 5, container 5, liquefied gas 1 ,
multifunction large-load carrier 3, oil tanker 1 ,
passenger 1 , roll-on/roll-off cargo 2, short-sea
passenger 3 (1998 est.)
Airports: 72 (1998 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 91 4 m: 42 (1998 est.)
Heliports: 1 (1 998 est.)','dfd78b084c1f1e861fdb08d973e50c688f7173b42cf346663a857cf326b96cce','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63c407f7671480381678119191b25882ab26b01a3655fbee1e622e3e06741ad4',1999,'CU','Cuba','transportation',341,'Railways:
total: 4,807 km
standard gauge: 4, 807 km 1.435-m gauge (147 km
electrified)
note: a large amount of track is in private use by sugar
plantations
Highways:
total: 60,858 km
paved: 29,820 km (including 638 km of expressway)
unpaved: 31 ,038 km (1 997 est.)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanillo, Mariel, Matanzas, Nuevitas, Santiago de
Merchant marine:
total: 18 ships (1,000 GRT or over) totaling 89,091
GRT/125,463 DWT
ships by type: bulk 1 , cargo 9, liquefied gas tanker 1 ,
oil tanker 2, refrigerated cargo 5 (1998 est.)
Airports: 170 (1998 est.)
Airports - with paved runways:
total: 77
over 3,047 m: 1
2,438 to 3,047 m: 9
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 36 (1 998 est.)
Airports - with unpaved runways:
total: 93
914 to 1,523 m: 32
under 914 m: 61 (1998 est.)','2ea282835fb11469e65b93a39b2fcdd482cee9e90d058dc08db6e822bfc03d54','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31a1cb8173fee7199711b7bd9f934426e741855e7b097e053b1ecf70d8f2722c',1999,'CY','Cyprus','transportation',349,'Railways: 0 km
Highways:
total: Greek Cypriot area: 10,415 km; Turkish Cypriot
area: 2,350 km
paved: Greek Cypriot area: 5,947 km; T urkish Cypriot
area: 1,370 km
unpaved: Greek Cypriot area: 4,468 km; Turkish
Cypriot area: 980 km (1996 est.)
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos Bay
Merchant marine:
total: 1 ,469 ships (1 ,000 GRT or over) totaling
23,362,067 GRT/36,945,331 DWT
ships by type: barge carrier 2, bulk 430, cargo 530,
chemical tanker 23, combination bulk 42, combination
ore/oil 1 1 , container 141 , liquefied gas tanker 6, oil
tanker 1 52, passenger 7, refrigerated cargo 58,
roll-on/roll-off cargo 49, short-sea passenger 14,
specialized tanker 3, vehicle carrier 1
note: a flag of convenience registry; includes ships
from 37 countries among which are Greece 61 1 ,
Germany 1 29, Russia 49, Latvia 278, Netherlands 20,
Japan 28, Cuba 16, China 15, Hong Kong 13, and
Poland 15 (1998 est.)
Airports: 15 (1998 est.)
Airports - with paved runways:
total: 12
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Heliports: 4 (1998 est.)','7629234dfeeb454c96dee4d74cf7dfde61f8d709622485e4e5b7808200ae50d9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0202119cc9945d4154732c105f31df91825ce204127d8eac0f1ea7158086c321',1999,'DK','Denmark','transportation',360,'Railways:
total: 9,440 km
standard gauge: 9,344 km 1 ,435-m standard gauge
(2,743 km electrified at three voltages; 1 ,885 km
double track)
narrow gauge: % km 0.760-m narrow gauge (1996)
Highways:
total: 55,489 km
paved: 55,489 km (including 423 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: NA km; the Elbe (Labe) is the principal
river
Pipelines: natural gas 5,400 km
Ports and harbors: Decin, Prague, Usti nad Labem
Airports: 69 (1998 est.)
Airports - with paved runways:
total: 35
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 11
914 to 1,523 m:1
under 914 m: 13 (1998 est.)
Airports - with unpaved runways:
total: 34
914 to 1,523 m: 17
under 914 m: 17 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 3,323 km (458 km privately owned and
operated)
standard gauge: 3,323 km 1 ,435-m gauge (440 km
electrified; 760 km double track) (1996)
Highways:
total: 71 ,600 km
paved: 71 ,600 km (including 880 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 417 km
Pipelines: crude oil 1 1 0 km; petroleum products 578
km; natural gas 700 km
Ports and harbors: Alborg, Arhus, Copenhagen,
Esbjerg, Fredericia, Grena, Koge, Odense, Struer
Merchant marine:
total: 337 ships (1 ,000 GRT or over) totaling
5,130,643 GRT/6,880,248 DWT
ships by type: bulk 1 4, cargo 1 30, chemical tanker 1 9,
container 73, liquefied gas tanker 26, livestock carrier
6, oil tanker 20, railcar carrier 1 , refrigerated cargo 1 5,
roll-on/roll-off cargo 21 , short-sea passenger 9,
specialized tanker 3
note: Denmark has created its own internal register,
called the Danish International Ship register (DIS);
DIS ships do not have to meet Danish manning
regulations, and they amount to a flag of convenience
within the Danish register (1998 est.)
Airports: 118 (1998 est.)
Airports - with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 90
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 91 4 m: 82 (1 998 est.)
Railways:
total: 97 km (Djibouti segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 97 km 1 ,000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-old railroad that links
their capitals
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996 est.)
Ports and harbors: Djibouti
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,369
GRT/3,030 DWT (1998 est.)
Airports: 11 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m:1 (1998 est.)
Airports - with unpaved runways:
total: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 2 (1998 est.)','df5569b8739b4dcd597d8ffeeaa5ca5060162cdb99c52c32a2013d6fe9a3200b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28f6d7fb15c8d66c8397e3f514c8d5ff41aa081a95ef4d9bc9ebf2dba98f51e4',1999,'DO','Dominican Republic','transportation',372,'Railways: 0 km
Highways:
total: 780 km
paved: 393 km
unpaved: 387 km (1996 est.)
Ports and harbors: Portsmouth, Roseau
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2 (1998 est.)
Railways:
total: 757 km
standard gauge: 375 km 1.435-m gauge (Central
Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominica
Government Railway); 240 km operated by sugar
companies in various gauges (0.558-m, 0.762-m,
1.067-m gauges) (1995)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1996 est.)
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana, Puerto
Plata, San Pedro de Macoris, Santo Domingo
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1 ,587
GRT/1,165 DWT (1998 est.)
Airports: 36 (1998 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 22
1,524 to 2,437 m;1
914 to 1,523 m: 6
under 914 m: 15 (1998 est.)
Railways:
total: 96 km
narrow gauge: 96 km 1 ,000-m gauge, rural,
narrow-gauge system for hauling sugarcane; no
passenger service
Highways:
total: 14,400 km
paved: 14,400 km
unpaved: 0 km (1996 est.)
Ports and harbors: Guanica, Guayanilia,
Guayama, Playa de Ponce, San Juan
Merchant marine: none
Airports: 30 (1998 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 6 (1998 est.)
Airports - with unpaved runways:
total: 9
914 to 1,523 m: 2
under 914 m: 7 (1998 est.)','5b25541e15d5efd9354c5078350b04d8952ba4cdf5290d79a6b3c1fbf8ce58a0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2159168f2e7163c55d2f8de87817115a954c120f57509571b522677dfb78469',1999,'PE','Peru','transportation',384,'Railways:
total: 965 km (single track)
narrow gauge: 965 km 1 ,067-m gauge
Highways:
total: 42,874 km
paved: 5,752 km
unpaved: 37,122 km (1998 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 99,078
GRT/1 62,423 DWT
ships by type: chemical tanker 2, liquefied gas tanker
1 , oil tanker 1 7, passenger 3 (1 998 est.)
Airports: 183 (1998 est.)
Airports - with paved runways:
total: 56
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 15
914 to 1,523 m: 14
under 914 m: 19 (1998 est.)
Airports - with unpaved runways:
total: 127
914 to 1,523 m: 37
under 914 m: 90 (1998 est.)
Heliports: 1 (1 998 est.)','fb1bca297ebb78326fbdc43de3d2297da87c8c52f1c82529e4fd4002b859b371','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ece112071575bebcb3538f4fe5db7a034b36b3cbcf1453c1d36fd29da948bb5',1999,'EG','Egypt','transportation',393,'Railways:
total: 4, 751 km
standard gauge: 4,751 km 1 ,435-m gauge (42 km
electrified; 951 km double track)
Highways:
total: 64,000 km
paved: 49,984 km
unpaved: 14,016 km (1996 est.)
Waterways: 3,500 km (including the Nile, Lake
Nasser, Alexandria-Cairo Waterway, and numerous
smaller canals in the delta); Suez Canal, 193.5 km
long (including approaches), used by oceangoing
vessels drawing up to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, Bur Safajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine:
total: 180 ships (1,000 GRT or over) totaling
1 ,334,406 GRT/2, 022, 785 DWT
ships by type: bulk 25, cargo 63, container 1 , liquefied
gas tanker 1 , oil tanker 14, passenger 56, refrigerated
cargo 1 , roll-on/roll-off cargo 16, short-sea passenger
3 (1998 est.)
Airports: 89 (1998 est.)
Airports - with paved runways:
total: 70
over 3,047 m: 10
2,438 to 3,047 m: 37
1,524 to 2,437 m: 16
914 to 1,523 m: 3
under 914 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 19
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 2
914 to 1,523 m: 6
under 914 m: 9 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 602 km (single track; note - some sections
abandoned, unusable, or operating at reduced
capacity)
148
El Salvador (continued)
narrow gauge: 602 km 0.91 4-m gauge
Highways:
total: 10,029 km
paved: 1 ,986 km (including 327 km of expressways)
unpaved: 8,043 km (1997 est.)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutla, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
Merchant marine: none
Airports: 86 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m:1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 82
914 to 1,523 m: 17
under 914 m: 65 (1998 est.)
Heliports: 1 (1998 est.)','68ad2c7c0e1284cef78d4e082bed554265df93b662b3b58bf3f458222aac69fa','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39968a62112fb6a0b7f5035c2fd0b67eba3408ec100e7a934d1193e534bcfc71',1999,'GN','Guinea','transportation',399,'Railways:
total: 0 km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2, 880 km (1996 est.)
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
total: 12 ships (1 ,000 GRT or over) totaling 23,370
GRT/25,194 DWT
ships by type: cargo 9, passenger2, passenger-cargo
1 (1 998 est.)
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047m: 1
1,524 to 2,437 m:1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways:
total: 307 km
narrow gauge: 307 km 0.950-m gauge (1995 est.)
note: nonoperational since 1978 except for about a 5
km stretch that was reopened in Massawa in 1994;
rehabilitation of the remainder and of the rolling stock
is under way; links Ak''ordat and Asmara (formerly
Asmera) with the port of Massawa (formerly Mits''iwa)
Highways:
tote/; 4,01 0 km
paved: 874 km
unpaved: 3,136 km (1996 est.)
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 5,947 GRT/
5,747 DWT
ships by type: oil tanker 1 , roll-on/roll-off cargo 1
(1998 est.)
Airports: 20 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 18
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 5
914 to 1,523 m: 6
under 914 m: 3 (1998 est.)
Railways: 0 km
Highways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1996 est.)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port
Moresby, Rabaul
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 35,400
GRT/50,869 DWT
ships by type: bulk 2, cargo 6, chemical tanker 1 ,
combination ore/oil 5, container 1 , oil tanker 2, roll-on/
roll-off 3 (1998 est.)
Airports: 492 (1998 est.)
Airports - with paved runways:
total: 19
2,438 to 3,047 m:1
1,524 to 2,437 m: 14
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 473
1,524 to 2,437m: 13
914 to 1,523 m: 60
under 914 m: 400 (1998 est.)
Heliports: 2 (1998 est.)','3435d0d863d188dd11e16059f54aba4dc4d936162f52a2ba4a66be8c9cda8508','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b81f34ad0d71eb2a285f3005c5796da6bb4367be323d665fec285db9dfccb1fd',1999,'EE','Estonia','transportation',411,'Railways:
total: 1,018 km common carrier lines only; does not
include dedicated industrial lines
broad gauge: 1 ,01 8 km 1 .520-m gauge (1 32 km
electrified) (1995)
Highways:
total: 16,437 km
paved: 8,343 km (including 65 km of expressways)
unpaved: 8,094 km (1997 est.)
Waterways: 320 km perennially navigable
Pipelines: natural gas 420 km (1 992)
Ports and harbors: Haapsalu, Kunda, Muuga,
Paldiski, Parnu, Tallinn
Merchant marine:
total: 52 ships (1 ,000 GRT or over) totaling 337,163
GRT/348,749 DWT
ships by type: bulk 4, cargo 22, combination bulk 1 ,
container 5, oil tanker 2, roll-on/roll-off cargo 12,
short-sea passenger 6 (1998 est.)
Airports: 5 (1997 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (1997 est.)','d2c5e9d3d2d167f0a8cbf66b586f542614ec8ece41e54c21e695ae8dc36cc82b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199f89451e016b7f0f20e8f2289b3ea897bfdc69c212e612a0543e34a5460bbb',1999,'ET','Ethiopia','transportation',418,'Railways:
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-old railroad that links
their capitals
Highways:
total: 28,500 km
paved: 4,275 km
unpaved: 24,225 km (1996 est.)
Ports and harbors: none; Ethiopia is landlocked
and was by agreement with Eritrea using the ports of
Assab and Massawa, but since the border dispute
with Eritrea flared, Ethiopia has used the port of
Railways: Okm
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1996 est.)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none
Airports: 30 (1998 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 27
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 22 (1 998 est.)
Railways: 0 km
Highways:
total: 320 km
paved: 21 8 km
unpaved: 102 km (1996 est.)
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 3 cargo ships (1 ,000 G RT or over) totaling 7,610
GRT/9,446 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)','e11d876808c5f3f7981004961119fd731fe4086698eb15166087fa6c12f48cff','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f07ca68bef1a6cc360357e635fa4c63ca22aa5fd909d90714bb5ac812aaf26e',1999,'DJ','Djibouti','transportation',419,'Merchant marine:
total: 1 1 ships (1 ,000 GRT or over) totaling 71 ,264
GRT/94,489 DWT
ships by type: cargo 7, oil tanker 1 , roll-on/roll-off
cargo 3 (1998 est.)
Airports: 84 (1998 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2, 437 m: 2
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 73
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2, 437 m: 9
914 to 1,523 m: 36
under 914 m: 18 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1 998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1998 est.)','00c7372059f3d95d193b4810cedc92ad90c47a067d9536c6ab21f60295ca44c9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca3152a68a22ff94b14fbde5af78c4e2513699f10b7c72d57ca5b6f5f24939f5',1999,'FO','Faroe Islands','transportation',430,'Railways: 0 km
Highways:
total: 458 km
paved: 450 km
unpaved: 8 km (1995 est.)
Ports and harbors: Torshavn, Klaksvik, Tvoroyri,
Runavik, Fuglafjorour
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 22,853
GRT/1 3,481 DWT
ships by type: cargo 2, oil tanker 1 , refrigerated cargo
1 , roll-on/roll-off cargo 1 , short-sea passenger 1 (1 998
est.)
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:1 (1998 est.)','30676fbc13a70cc72cbe49e11553dffb16097155984d5c465c527b7ac8dc0d4b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35509bbd6c98fe1eedb2d8a99d738334c60ed346095872398596bf942a992a4',1999,'JE','Jersey','transportation',439,'Railways:
total: 597 km; note - belongs to the
government-owned Fiji Sugar Corporation
narrow gauge: 597 km 0.61 0-m gauge (1995)
Highways:
total: 3,440 km
paved: 1 ,692 km
unpaved: 1,748 km (1996 est.)
Waterways: 203 km; 1 22 km navigable by motorized
craft and 200-metric-ton barges
Ports and harbors: Labasa, Lautoka, Levuka,
Savusavu, Suva
Merchant marine:
tofa/; 5 ships (1 ,000 GRT or over) totaling 10,721
GRT/13,145 DWT
ships by type: chemical tanker 2, passenger 1 , roll-on/
roll-off cargo 1 , specialized tanker 1 (1 998 est.)
Airports: 24 (1998 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 21
914 to 1,523 m: 4
under 914 m: 17 (1998 est.)
Railways:
total: 61 0 km
standard gauge: 610 km 1.435-m gauge (1996)
Highways:
total: 15,464 km
paved: 15,464 km (including 56 km of expressways)
unpaved: 0 km (1997 est.)
Pipelines: crude oil 708 km; petroleum products 290
km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 736,41 9
GRT/855,497 DWT
ships by type: cargo 1 , container 21 , roll-on/roll-off
cargo 1 (1998 est.)
Airports: 54 (1998 est.)
Airports - with paved runways:
total: 31
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 18 (1998 est.)
Heliports: 2 (1998 est.)
Railways: 0 km
Highways:
total: 577 km (1995)
paved: NA km
unpaved: NA km
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (1998 est.)
Ports and harbors: Johnston Island
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,587 km
unpaved: 863 km (1996 est.)
269
Kuwait (continued)
Pipelines: crude oil 877 km; petroleum products 40
km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina1 Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 49 ships (1 ,000 GRT or over) totaling 2,509,061
GRT/4,046,739 DWT
ships by type: bulk 1 , cargo 10, container 6, liquefied
gas tanker 7, livestock carrier 3, oil tanker 22 (1998
est.)
Airports: 8 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047m: 2 (1998 est.)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 mA
914 to 1,523 mA
under 91 4 m: 2 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 5,562 km
paved: 975 km
unpaved: 4,587 km (1 993)
Ports and harbors: Mueo, Noumea, Thio
Merchant marine: none
Airports: 27 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 22
914 to 1,523 m: 11
under 914 m:11 (1998 est.)
Heliports: 7 (1998 est.)
Railways:
total: 1 ,201 km
standard gauge: 1 ,201 km 1 ,435-m gauge (electrified
489 km) (1998)
Highways:
total: 14,830 km
paved: 12,309 km (including 251 km of expressways)
unpaved: 2,521 km (1997 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Airports: 14 (1998 est.)
Airports - with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
91 4 to 1,523 m: 2
under 914 m:1 (1998 est.)
Airports - with unpaved runways:
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)
Railways:
total: 297 km; note - includes 71 km which are not in
use
narrow gauge: 297 km 1.067-m gauge
Highways:
fofa/: 3,810 km
paved: NA km
unpaved: NA km (1996 est.)
Ports and harbors: none
Airports: 18 (1998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 7
under 914 m: 10 (1998 est.)
Railways:
total: 13,415 km (includes 3,594 km of
privately-owned railways)
464
Sweden (continued)
standard gauge: 1 3,41 5 km 1 .435-m gauge (7,91 7 km
electrified and 1,152 km double track) (1996)
Highways:
total: 138,000 km
paved: 105,018 km (including 1 ,330 km of
expressways)
unpaved: 32,982 km (1996 est.)
Waterways: 2,052 km navigable for small steamers
and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavle, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 1 54 ships (1 ,000 GRT or over) totaling
1,894,783 GRT/1 ,528,077 DWT
ships by type: bulk 6, cargo 28, chemical tanker 28,
combination ore/oil 4, liquefied gas tanker 1 , oil tanker
24, railcar carrier 1 , refrigerated cargo 1 , roll-on/roll-off
cargo 39, short-sea passenger 5, specialized tanker
4, vehicle carrier 13 (1998 est.)
Airports: 255 (1998 est.)
Airports - with paved runways:
total: 145
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2, 437 m: 82
91 4 to 1,523 m: 27
under 914 m: 24 (1 998 est.)
Airports - with unpaved runways:
total: 110
914 to 1,523 m: 5
under 914 m: 105 (1998 est.)
Heliports: 1 (1 998 est.)','6c213bd71d09dfb77c93e447008f10eb9b129e7c889d7cdaf020d67c4dcde68f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a08c844644a65afc72e5d22706b3e66fff827c7383d799f385260b0e396ccb1',1999,'FI','Finland','transportation',448,'Railways:
total: 5,859 km
broad gauge: 5,859 km 1.524-m gauge (2,073 km
electrified; 480 km double- or more-track) (1996)
Highways:
total: 77; 796 km
paved: 49,789 km (including 444 km of expressways)
unpaved: 28,007 km (1997 est.)
Waterways: 6,675 km total (including Saimaa
Canal); 3,700 km suitable for steamers
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 101 ships (1,000 GRT or over) totaling
1,192,559 GRT/1, 161, 594 DWT
ships by type: bulk 9, cargo 23, chemical tanker 6, oil
tanker 1 1 , passenger 1 , railcar carrier 1 , roll-on/roll-off
cargo 38, short-sea passenger 12 (1998 est.)
Airports: 157 (1998 est.)
Airports - with paved runways:
total: 68
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437 m: 10
914 to 1,523 m: 20
under 914 m: 9 (1998 est.)
Airports - with unpaved runways:
total: 89
914 to 1,523 m: 6
under 914 m: 83 (1998 est.)','f127a9ad25b8d71d395d53d82dfb3d386c687f8d86bdd6601f597653512f8807','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504ca65f6127cc2cc67d467eb0f2db8b3dbf61a596c9a458016cd55a0325484d',1999,'WF','Wallis and Futuna','transportation',455,'Railways:
total: 32,027 km ( 31 ,940 km are operated by French
National Railways (SNCF); 1 3,803 km of SNCF routes
are electrified and 12,132 km are double- or
multiple-tracked)
standard gauge: 31 ,928 km 1 ,435-m gauge
narrow gauge: 99 km 1 ,000-m gauge
note: does not include 33 tourist railroads, totaling 469
km, many being of very narrow gauge (1996)
Highways:
total: 892,900 km
paved: 892,900 km (including 9,900 km of
expressways)
unpaved: 0 km (1997 est.)
Waterways: 14,932 km; 6,969 km heavily traveled
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Muilhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 64 ships (1 ,000 GRT or over) totaling 1 ,826,364
GRT/2,962,338 DWT
ships by type: bulk 5, cargo 5, chemical tanker 6,
combination bulk 1 , container 6, liquefied gas tanker
4, multifunction large-load carrier 2, oil tanker 20,
passenger 3, roll-on/roll-off cargo 5, short-sea
passenger 6, specialized tanker 1
note: France also maintains a captive register for
French-owned ships in lies Kerguelen (French
Southern and Antarctic Lands) (1998 est.)
Airports: 474 (1998 est.)
Airports - with paved runways:
total: 267
over 3,047 m: 13
2,438 to 3,047 m: 31
1,524 to 2,437 m: 94
914 to 1,523 m: 73
under 914 m: 56 (1998 est.)
Airports - with unpaved runways:
total: 207
1,524 to 2,437 m: 3
914 to 1,523 m: 75
under 914 m: 1 29 (1 998 est.)
Heliports: 3 (1998 est.)
Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (1998 est.)
Transportation - note: formerly an important
commercial aviation base, now occasionally used by
US military, some commercial cargo planes, and for
emergency landings','9464f2e2e1e421fb1d625566285b7f70f18084fa79e84d662a640eb88d7a05e5','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c92a5042fcf9ce97987790f27c17b915469b4ff8f7cd9490ff00162f28fa3151',1999,'KI','Kiribati','transportation',466,'Railways: 0 km
Highways:
total: 792 km
paved: 792 km (1995 est.)
Ports and harbors: Mataura, Papeete, Rikitea,
Uturoa
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 5,240 GRT/
7,765 DWT
ships by type: cargo 1 , passenger-cargo 2,
refrigerated cargo 1 (1998 est.)
Airports: 45 (1998 est.)
Airports - with paved runways:
total: 29
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 17
under 91 4 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 16
914 to 1,523 m: 5
under 914 m: 1 1 (1 998 est.)','e0c0ede8262d7e443fe4380914fb10d7e3d88a26635b913653ff60634cb3921d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fe537ab3f7253dac49bdf3ad25db326dc8205c9fda280ec12567ca79e99feff',1999,'GA','Gabon','transportation',473,'Railways:
total: 649 km Gabon State Railways (OCTRA)
standard gauge: 649 km 1 ,435-m gauge; single track
(1994)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996 est.)
Waterways: 1,600 km perennially navigable
Pipelines: crude oil 270 km; petroleum products 14
km
Ports and harbors: Cap Lopez, Kango, Lambarene,
Libreville, Mayumba, Owendo, Port-Gentil
Merchant marine:
tofa/; 2 ships (1,000 GRT or over) totaling 13,613
GRT/22, 599 DWT (1998 est.)
ships by type: bulk 1 , cargo 1 (1 998 est.)
Airports: 62 (1998 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2, 437 m: 1
914 to 7,523 m; 1 (1998 est.)
Airports - with unpaved runways:
total: 52
1,524 to 2,437 m: 10
914 to 1,523 m: 16
under 914 m: 26 (1998 est.)
Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
unpaved: 1,744 km (1996 est.)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1 998 est.)
Railways:
total: NA km; note - one line, abandoned and in
disrepair, little trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Ports and harbors: Gaza
Airports: 2 (1998 est.)
note: includes Gaza International Airport that opened
on 24 November 1998 as part of agreements
stipulated in the 23 October 1998 Wye River
Memorandum
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)','4347730830fc47e64592a7d8d611e7ca6a42f5318ccb6a8d9428745f3d244579','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df58366fa1144809bd3b9599778729dad98661aaec27dad6f9afb26296e5bcd2',1999,'GH','Ghana','transportation',477,'Railways:
total: 46,300 km including 18,866 km electrified and
14,768 km double- or multipie-tracked (1996)
note: since privatization in 1994, Deutsche Bahn AG
(DBAG) no longer publishes details of the tracks it
owns; in addition to the DBAG system there are 102
privately owned railway companies which own an
approximate 3,000 km to 4,000 km of the total tracks
Highways:
total: 656,074 km
paved: 650,1 69 km (including 11,309 km of
expressways)
unpaved: 5,905 km all-weather (1997 est.)
Waterways: 7,467 km (1997); major rivers include
the Rhine and Elbe; Kiel Canal is an important
connection between the Baltic Sea and North Sea
Pipelines: crude oil 2,460 km (1997)
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Lubeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 594 ships (1 ,000 GRT or over) totaling
7,699,596 GRT/9, 629, 163 DWT
ships by type: cargo 227, chemical tanker 1 5,
combination bulk 1 , container 306, liquefied gas
tanker 5, multifunction large-load carrier 5, oil tanker
7, passenger 3, railcar carrier 2, refrigerated cargo 2,
roll-on/roll-off cargo 14, short-sea passenger 7 (1998
est.)
Airports: 618 (1998 est.)
Airports - with paved runways:
tofa/:319
over 3,047 m: 14
2,438 to 3,047 m: 62
1,524 to 2,437 m: 68
914 to 1,523 m: 54
under 914 m: 121 (1 998 est.)
Airports - with unpaved runways:
total: 299
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 6
914 to 1,523 m: 58
under 914 m: 227(1998 est.)
Heliports: 61 (1998 est.)
Railways:
total: 953 km (undergoing major rehabilitation)
narrow gauge: 953 km 1 ,067-m gauge (32 km double
track) (1997 est.)
Highways:
total: 39,409 km
paved: 1 1 ,653 km (including 30 km of expressways)
unpaved: 27 ,756 km (1997 est.)
Waterways: Volta, Ankobra, and Tano Rivers
provide 168 km of perennial navigation for launches
and lighters; Lake Volta provides 1,125 km of arterial
and feeder waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
fofa/;5 ships (1,000 GRT or over) totaling 10,552
GRT/14,839 DWT
ships by type: oil tanker 2, refrigerated cargo 3 (1998
est.)
Airports: 12 (1998 est, )
Airports - with paved runways:
total: 6
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (1998 est.)
Airports ■ with unpaved runways:
total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)','0f6cb757c829d3a48b8784b0413001be65a58370ff51165b7c7e5ad961d0fbc2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8c7fe69257b5e8c922b23797a8fa123ab673ad78bded44b258d9e3d3042495a',1999,'ES','Spain','transportation',494,'Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1998 est.)
Railways:
total: 15,079 km
broad gauge: 12,781 km 1 ,668-m gauge (6,355 km
electrified; 2,295 km double track)
standard gauge: 525 km 1.435-m gauge (480 km
electrified)
narrow gauge: 1 ,773 km 1.000-m gauge (594 km
electrified) (1996)
Highways:
total: 346,858 km
paved: 343,389 km (including 9,063 km of
expressways)
unpaved: 3,469 km (1997 est.)
Waterways: 1 ,045 km, but of minor economic
importance
Pipelines: crude oil 265 km; petroleum products
1,794 km; natural gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilla, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Santander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 137 ships (1,000 GRT or over) totaling
1 ,094,408 GRT/1 ,695,708 DWT
ships by type: bulk 1 1 , cargo 29, chemical tanker 1 0,
container 10, liquefied gas tanker 3, oil tanker 25,
passenger 1 , refrigerated cargo 6, roll-on/roll-off cargo
35, short-sea passenger 6, specialized tanker 1 (1 998
est.)
Airports: 99 (1998 est.)
Airports - with paved runways:
total: 66
over 3,047 m: 15
2,438 to 3,047 m: 11
1,524 to 2, 437 m: 16
914 to 1,523 m: 15
under 914 m: 9 (1998 est.)
Airports - with unpaved runways:
total: 33
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 21 (1998 est.)
Heliports: 2 (1998 est.)','6b228c986d4ac86baae158ee39c7d4548073b30b982fa33cc195e38003ee39e3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94ebcc3df9b8cb76d0824e0279fe2302cecee095395ecbaa267368eb7e96c874',1999,'GL','Greenland','transportation',500,'Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
194
Greenland (continued)
Ports and harbors: Kangerluarsoruseq,
Kangerlussuaq, Nanorialik, Narsarsuaq, Nuuk
(Godthab), Sisimiut
Merchant marine:
total: 1 passenger (1 ,000 GRT or over) totaling 1 ,21 1
GRT/162 DWT (1998 est.)
Airports: 13 (1998 est.)
Airports - with paved runways:
total: 9
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)','789a3f6fe80e2209a446aedfc7b979a9a8dc7060d10a964f314c7411d497df85','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b525a739f5bb097d39e161024d17b26f0b66a8eeaa28ee9ccb1a5ddb8177f153',1999,'GD','Grenada','transportation',506,'Railways: Okm
Highways:
total: 1 ,040 km
paved: 638 km
unpaved: 402 km (1996 est.)
Ports and harbors: Grenville, Saint George''s
Merchant marine: none
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 1 ,040 km
paved: 320 km
unpaved: 720 km (1996 est.)
Ports and harbors: Kingstown
Merchant marine:
total: 814 ships (1,000 GRT or over) totaling
7,726,930 GRT/1 1,835, 144 DWT
ships by type: barge carrier 1, bulk 138, cargo 402,
chemical tanker 26, combination bulk 1 1 , combination
ore/oil 7, container 47, liquefied gas tanker 3, livestock
carrier 4, multifunction large-load carrier 2, oil tanker
64, passenger 2, refrigerated cargo 40, roll-on/roll-off
cargo 51 , short-sea passenger 1 0, specialized tanker
5, vehicle carrier 1
note: a flag of convenience registry; includes ships
from 20 countries among which are Croatia 17,
Slovenia 7, China 5, Greece 5, UAE 3, Norway 2,
Japan 2, and Ukraine 2 (1998 est.)
Airports: 6 (1998 est.)
Airports - with paved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)','4dab110cb18aca4c2986ada27686ac961303b213c2bdd9e781f9a9fb409cf09f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d6d52ba0e4f9b38366aa0af2add063d8acc253d780dec992279b20b163f36c',1999,'GU','Guam','transportation',515,'Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there is another 685 km of roads classified
non-public, including roads located on federal
government installations
Ports and harbors: Apra Harbor
Merchant marine: none
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways:
total: 884 km (102 km privately owned)
narrow gauge: 884 km 0.91 4-m gauge (single track)
Highways:
total: 13,100 km
paved: 3,616 km (including 140 km of expressways)
unpaved: 9,484 km (1996 est.)
Waterways: 260 km navigable year round; additional
730 km navigable during high-water season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none
Airports: 478 (1998 est.)
Airports - with paved runways:
fo/a/:12
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m : 6
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 466
2,438 to 3,047 m:1
1,524 to 2,437 m: 9
914 to 1,523 m: 124
under 914 m: 332 (1998 est.)','fb5403d8b3f4dea489775b68573bfb74fea403749297f98d835e285eb39d97be','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('412de3d3f6c23ca6a8da9f2e186e3392c7f8bc6a161365ca15a0a103ea89b515',1999,'GG','Guernsey','transportation',522,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Saint Peter Port, Saint
Sampson
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m:!
under 914 m:1 (1998 est.)
Railways:
total: 1 ,086 km
standard gauge: 279 km 1 ,435-m gauge
narrow gauge: 807 km 1 ,000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25,467 km (1996 est.)
Waterways: 1 ,295 km navigable by shallow-draft
native craft
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none
Airports: 15 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3(1998 est.)
Airports - with unpaved runways:
total: 10
1,524 to 2, 437 m: 5
914 to 1,523 m: 4
under 914 m:1 (1998 est.)','34e5bb9492daba1fd9bf6ed946ac4f4c2057147e54a7a111cab3d50190af0e26','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73f1578f5837f956a0f37d1516e6093fcb76a4d15325ddf112dea077ba5b9735',1999,'GY','Guyana','transportation',533,'Railways:
total: 88 km (all dedicated to ore transport)
standard gauge: 40 km 1 .435-m gauge
narrow gauge: 48 km 0.91 4-m gauge
Highways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (1996 est.)
Waterways: 6,000 km total of navigable waterways;
Berbice, Demerara, and Essequibo Rivers are
navigable by oceangoing vessels for 1 50 km, 1 00 km,
and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total: 2 cargo ships (1 ,000 GRT or over) totaling 2,340
GRT/4,530 DWT (1998 est.)
Airports: 48 (1998 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 44
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 35 (1 998 est.)
Railways:
fofa/;166 km (single track)
standard gauge: 80 km 1 .435-m gauge
narrow gauge: 86 km 1 .000-m gauge
Highways:
total: 4,530 km
paved: 1,178 km
unpaved: 3,352 km (1996 est.)
Waterways: 1 ,200 km; most important means of
transport; oceangoing vessels with drafts ranging up
to 7 m can navigate many of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie,
Paramaribo, Paranam, Wageningen
Airports: 46 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
under 914 m: 4(1 998 est.)
Airports - with unpaved runways:
total: 41
914 to 1,523 m: 7
under 914 m: 34 (1998 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Merchant marine: none
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (1998 est.)
Airports - with unpaved runways:
total: 3
under 914 m: 3 (1998 est.)','ab4491d73a3f67e05b4a536ff1ae14692c1b7c86abdd016724533c16c8152094','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45e4eef2d8a745f2d13eaddb99d02afbd2558a1a4a3266b05a5ce6a735ff7f7b',1999,'HT','Haiti','transportation',542,'Railways:
total: 40 km (single track; privately owned industrial
line) -closed in early 1990s
narrow gauge: 40 km 0.760-m gauge
Highways:
fofa/:4,160 km
paved: 1 ,01 1 km
unpaved: 3,149 km (1996 est.)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, Les Cayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none
Airports: 13 (1998 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
fofa/:10
914 to 1,523 m: 5
under 914 m: 5 (1998 est.)','87db885f4b4a05024133ee9fb3d0b9ad63a3bf784828a33c0ada6ab23001d1f7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84bd1e79395d0e1dfb578e29d06c4b7cf25f5b1f740945abf550d72e34aec67a',1999,'NI','Nicaragua','transportation',552,'Railways:
total: 34 km
standard gauge: 34 km 1 ,435-m gauge (all electrified)
(1996 est.)
Highways:
total: 1 ,831 km
paved: 1 ,831 km
unpaved: 0 km (1997)
Ports and harbors: Hong Kong
Merchant marine:
total: 1 95 ships (1 ,000 GRT or over) totaling
6,075,304 GRT/10, 133, 186 DWT
ships by type: barge carrier 1 , bulk 1 1 7, cargo 1 8,
chemical tanker 2, combination bulk 2, container 40,
liquefied gas tanker 1 , multifunction large-load carrier
2, oil tanker 6, refrigerated cargo 1 , roll-on/roll-off
cargo 1 , short-sea passenger 1 , vehicle carrier 3
note: a flag of convenience registry; includes ships
from 13 countries among which are UK 16, South
Africa 3, China 9, Japan 6, Bermuda 2, Germany 3,
Canada 2, Cyprus 1 , Belgium 1, and Norway 1 (1998
est.)
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m: 1 (1998 est.)
Heliports: 2 (1998 est.)','b9a250f30047a196c704805b1ecbc6531a2040bf4e105befaf0d9fe0128915e8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2882f09ebd6fc8833efca83fc59fe6b50a1c7f5c7481054e6818c7079776dcf8',1999,'HU','Hungary','transportation',559,'Railways:
total: 7,606 km
broad gauge: 36 km 1 ,524-m gauge
standard gauge: 7,394 km 1 ,435-m gauge (2,207 km
electrified; 1 ,236 km double track)
narrow gauge: 176 km 0.760-m gauge (1996)
note: Hungary and Austria jointly manage the
cross-border standard-gauge railway between Gyor,
Sopron, Ebenfurt (Gyor-Sopron-Ebenfurti Vasut Rt) a
distance of about 101 km in Hungary and 65 km in','d6a3be173eaac0defd6650a892a94cf68b73d65547251ba29ce77210130375e9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('062671d00b4ef42193d6b962014cf6a6a0a06bf81e23b3c19966007e20ed7705',1999,'AT','Austria','transportation',560,'Highways:
total: 188,203 km
paved: 81 ,680 km (including 438 km of expressways)
unpaved: 106,523 km (1997 est.)
Waterways: 1 ,622 km (1 988)
Pipelines: crude oil 1 ,204 km; natural gas 4,387 km
(1991)
Ports and harbors: Budapest, Dunaujvaros
Merchant marine:
total: 3 cargo ships (1 ,000 GRT or over) totaling
16,210 GRT/1 9,81 0 DWT (1998 est.)
Airports: 25 (1998 est.)
Airports - with paved runways:
total: 15
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 10
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 3(1998 est.)','575513ef8053a369691ad2a3a2bdda1de1e77a28bdb5bba5d2bd1467b129add3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f34ccb68f40ef3b80b019f5effb82ff752834f57d0c37558921743ec8c804881',1999,'IS','Iceland','transportation',570,'Railways: 0 km
Highways:
total: 12,691 km
paved: 3,262 km
unpaved: 9,429 km (1997 est.)
Ports and harbors: Akureyri, Hornafjordur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 13,085
GRT/1 6,938 DWT
ships by type: chemical tanker 1 , container 1 , oil
tanker 1 (1998 est.)
Airports: 87 (1998 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 77
1,524 to 2,437 m: 3
914 to 1,523 m: 21
under 914 m: 53 (1998 est.)
Ports and harbors: Calcutta (India), Chennai
(Madras; India), Colombo (Sri Lanka), Durban (South
Africa), Jakarta (Indonesia), Melbourne (Australia),
Mumbai (Bombay; India), Richards Bay (South Africa)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)','d7deea0598b7467630b6236ab938d66da9cfa8822125b17dfa6e9dc2de9a9893','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0f388ab9c88c162174e921a00de93c7b38b3e0432c928c2ccbdca8417751f4',1999,'ID','Indonesia','transportation',573,'Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km
electrified; 101 km double track); 497 km 0.750-m
gauge (1995)
Highways:
total: 342,700 km
paved: 158,670 km
unpaved: 184,030 km (1997 est.)
Waterways: 21 ,579 km total; Sumatra 5,471 km,
Java and Madura 820 km, Kalimantan 10,460 km,
Sulawesi (Celebes) 241 km, Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Palembang, Semarang, Surabaya,
Ujungpandang
Merchant marine:
total: 587 ships (1 ,000 GRT or over) totaling
2,707,004 GRT/3,701 ,001 DWT
ships by type: bulk 37, cargo 348, chemical tanker 8,
container 20, liquefied gas tanker 5, livestock carrier
1, oil tanker 116, passenger 9, passenger-cargo 13,
roll-on/roll-off cargo 1 1 , short-sea passenger 7,
specialized tanker 7, vehicle carrier 5 (1998 est.)
Airports: 443 (1998 est.)
Airports - with paved runways:
total: 125
over 3,047 m: 4
2,438 to 3,047 m:U
1,524 to 2,437 m: 41
914 to 1,523 m: 39
under 914 m: 30 (1998 est.)
Airports - with unpaved runways:
total: 318
1,524 to 2, 437 m: 5
914 to 1,523 m: 31
under 914 m: 282 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 7,286 km
broad gauge: 94 km 1 .676-m gauge
standard gauge: 7, 192 km 1.435-m gauge (146 km
electrified) (1996 est.)
Highways:
total: 162,000 km
paved: 81 ,000 km (including 470 km of expressways)
unpaved: 81 ,000 km (1996 est.)
Waterways: 904 km; the Shaft al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzali, Bushehr, Bandar-e Imam Khomeyni,
Bandar-e Lengeh, Bandar-e Mahshahr, Bandar-e
Torkaman, Chabahar (Bandar Beheshti), Jazireh-ye
Khark, Jazireh-ye Lavan, Jazireh-ye Sirri,
Khorramshahr (limited operation since November
232
Iran (continued)
1992), Now Shahr
Merchant marine:
total: 132 ships (1,000 GRT or over) totaling
3,238,293 GRT/5,658,259 DWT
ships by type: bulk 46, cargo 35, chemical tanker 4,
combination bulk 1 , container 5, liquefied gas tanker
1 , multifunction large-load carrier 6, oil tanker 21 ,
refrigerated cargo 2, roll-on/roll-off cargo 10,
short-sea passenger 1 (1998 est.)
Airports: 288 (1998 est.)
Airports - with paved runways:
fofa/:110
over 3,047 m: 38
2,438 to 3,047 m: 18
1,524 to 2,437 m: 25
91 4 to 1,523 m: 23
under 914 m: 6 (1998 est.)
Airports - with unpaved runways:
total: 178
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 126
under 914 m: 32 (1998 est.)
Heliports: 11 (1998 est.)
Railways:
total: 2,032 km
standard gauge: 2,032 km 1.435-m gauge
Highways:
total: 47,400 km
paved: 40,764 km
unpaved: 6,636 km (1 996 est.)
Waterways: 1 ,01 5 km; Shatt al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 meters and is in use;
Tigris and Euphrates Rivers have navigable sections
for shallow-draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft craft before closing in 1 991
because of the Persian Gulf war
Pipelines: crude oil 4,350 km; petroleum products
725 km; natural gas 1 ,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr,
and Al Basrah have limited functionality
Merchant marine:
total: 30 ships (1 ,000 GRT or over) totaling 456,845
GRT/780,318 DWT
ships by type: cargo 14, oil tanker 1 1 , passenger 1 ,
passenger-cargo 1 , refrigerated cargo 1 , roll-on/
roll-off cargo 2 (1998 est.)
Airports: 109 (1998 est.)
Airports - with paved runways:
total: 77
over 3,047 m: 20
2,438 to 3,047 m: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 7
under 914 m: 7 (1998 est.)
Airports - with unpaved runways:
total: 32
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 10
under 914 m: 11 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 1 ,947 km
broad gauge: 1 ,947 km 1 .600-m gauge (38 km
electrified; 485 km double track) (1996)
Highways:
total: 92,500 km
paved: 87,042 km (including 80 km of expressways)
unpaved: 5,458 km (1996 est.)
Waterways: limited for commercial traffic
Pipelines: natural gas 225 km
Ports and harbors: Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
Merchant marine:
total: 31 ships (1 ,000 GRT or over) totaling 79,284
GRT/11 7,652 DWT
ships by type: bulk 1 , cargo 28, container 2 (1 998
est.)
Airports: 44 (1998 est.)
Airports - with paved runways:
total: 16
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 91 4 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 28
914 to 1,523 m: 3
under 914 m: 25 (1 998 est.)
237
Ireland (continued)
i Military
Military branches: Army (includes Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 974,226 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 790,155 (1999 est.)
Military manpower - reaching military age
annually:
males: 33, 81 0(1999 est.)
Military expenditures - dollar figure: $771 million
(1997)
Military expenditures - percent of GDP: 1 %
(1997)
Railways:
total: 1 ,798 km
narrow gauge: 1,798 km 1.000-m gauge (148 km
electrified) (1998 est.)
Highways:
total: 94,500 km
paved: 70,970 km (including 580 km of expressways)
unpaved: 23,530 km (1996 est.)
Waterways: 7,296 km (Peninsular Malaysia 3,209
km, Sabah 1,569 km, Sarawak 2,51 8 km)
Pipelines: crude oil 1,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabalu,
Kuantan, Kuching, Kudat, Labuan, Lahad Datu,
Lumut, Miri, Pasir Gudang, Penang, Port Dickson,
Port Kelang, Sandakan, Sibu, Tanjung Berhala,
Tanjung Kidurong, Tawau
Merchant marine:
total: 378 ships (1 ,000 GRT or over) totaling
5,059,272 GRT/7,428,623 DWT
ships by type: bulk 62, cargo 1 28, chemical tanker 30,
container 58, liquefied gas tanker 1 9, livestock carrier
1 , oil tanker 61 , passenger 2, refrigerated cargo 2,
roll-on/roll-off cargo 6, specialized tanker 2, vehicle
carrier 7 (1998 est.)
Airports: 115 (1998 est.)
Airports - with paved runways:
total: 32
over 3,047 m: 5
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 6
under 914 m: 6 (1998 est.)
Airports - with unpaved runways:
total: 83
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 74 (1 998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 240 km
paved: 42 km
unpaved: 198 km (1996 est.)
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none
Airports: 6 (1998 est.)
Airports - with paved runways:
total: 5
1,524 to 2,437m: 4
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1998 est.)
Highways:
total: 32 km
paved: NA km
unpaved: NA km
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2(1998 est.)
Airports - with unpaved runways:
total: 1-
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 1 ,328 km
broad gauge: 1 ,328 km 1 ,520-m gauge (1992)
Highways:
total: 12,300 km
paved: 10,738 km
unpaved: 1 ,562 km (1996 est.)
Waterways: 424 km (1994)
Pipelines: natural gas 31 0 km (1 992)
Ports and harbors: none
Airports: 26 (1994 est.)
Airports - with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 91 4 m: 3 (1994 est.)
Airports - with unpaved runways:
total: 18
2,438 to 3,047 m: 3
1,524 to 2, 437 m: 2
914 to 1,523 m: 5
under 914 m: 8 (1994 est.)
Railways:
total: 897 km of which 492 km in operation
narrow gauge: 492 km 1.067-m gauge (1996)
Highways:
total: 161,313 km
paved: 290 km
unpaved: 161,023 km (1997)
Waterways: 3,219 km; limited to shallow-draft (less
than 1.5 m) vessels
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, Iloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 51 3 ships (1 ,000 GRT or over) totaling
6,544,029 GRT/1 0,052, 418 DWT
ships by type: bulk 1 79, cargo 131, chemical tanker 6,
combination bulk 1 3, container 9, liquefied gas tanker
12, livestock carrier 10, oil tanker 48, passenger 4,
passenger-cargo 13, refrigerated cargo 19, roll-on/
roll-off cargo 17, short-sea passenger 31 , specialized
tanker 1 , vehicle carrier 20
note: a flag of convenience registry; Japan owns 19
ships, Hong Kong 5, Cyprus 1, Denmark 1 , Greece 1 ,
Netherlands 1 , Singapore 1 , and UK 1 (1998 est.)
Airports: 260 (1998 est.)
Airports - with paved runways:
total: 75
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1,523 m: 30
under 914 m: 10 (1998 est.)
Airports - with unpaved runways:
total: 185
1,524 to 2,437 m: 3
914 to 1,523 m: 61
under 914 m: 121 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports and harbors: Bounty Bay
Merchant marine: none
Airports: none
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 ,000-m gauge
note: there is a 67 km mass transit system with 42
stations
Highways:
total: 3,017 km
paved: 2,936 km (including 148 km of expressways)
unpaved: 81 km (1997 est.)
Ports and harbors: Singapore
Merchant marine:
total: 875 ships (1 ,000 GRT or over) totaling
19,734,146 GRT/31 ,442,482 DWT
ships by type: bulk 142, cargo 132, chemical tanker
51 , combination bulk 6, combination ore/oil 6,
container 154, liquefied gas tanker 27, livestock
carrier 1, multifunction large-load carrier 6, oil tanker
291 , refrigerated cargo 8, roll-on/roll-off cargo 1 1 ,
short-sea passenger 1 , specialized tanker 9, vehicle
carrier 30
note: a flag of convenience registry; includes ships
from 22 countries among which are Japan 41 ,
Denmark 35, Sweden 28, Thailand 28, Hong Kong 26,
Germany 1 9, Taiwan 1 9, and Indonesia 1 1 (1 998 est.)
Airports: 9 (1998 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 91 4 m: 1 (1998 est.)
Heliports: 1 (1 998 est.)','ee76b0a7cd51a2e9707af3636197e04cc0dca01cefdfc7c37f867e4b579cccb7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4b4396cacb19390375e573ba59731170fd59554e8823217920351eb9f95319',1999,'JM','Jamaica','transportation',591,'Railways:
total: 370 km
standard gauge: 370 km 1 ,435-m gauge; note - 207
km belong to the Jamaica Railway Corporation in
common carrier service, but are no longer operational;
the remaining track is privately owned and used to
transport bauxite
Highways:
total: 18,700 km
paved: 13,100 km
unpaved: 5,600 km (1997 est.)
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rios, Port Antonio,
Rocky Point, Port Esquivel (Longswharf)
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 3,478 GRT I
5,878 DWT
ships by type: oil tanker 1 , roll-on/roll-off cargo 1
(1998 est.)
Airports: 36 (1998 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 5 (1998 est.)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 2
under 914 m: 23 (1 998 est.)
i Military
Military branches: Jamaica Defense Force
(includes Ground Forces, Coast Guard, and Air
Wing), Jamaica Constabulary Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 715,260 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 503,667 (1999 est.)
Military manpower - reaching military age
annually:
males: 26,108 (1999 est.)
Military expenditures - dollar figure: $47.9 million
(FY97/98 est.)
Military expenditures - percent of GDP: NA%
245
Jamaica (continued)','eab7705f147f32c412a3dc951220be6b63059f52322e7ca37184747261a16ff0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c78d0f43f52dd07d9301d8d12dd93d59b7c73bf39403ed9744f3f6a26f14630',1999,'NO','Norway','transportation',597,'Railways:
total: 23,670.7 km
standard gauge: 2,893. 1 km 1.435-m gauge (entirely
electrified)
narrow gauge: 89.8 km 1.372-m gauge (89.8 km
electrified); 20,656.8 km 1 ,067-m gauge (10,383.6 km
electrified); 31 km 0.762-m gauge (3.6 km electrified)
(1994)
Highways:
tofa/: 1.16 million km
paved: 859,560 km (including 6,070 km of
expressways)
unpaved: 300,440 km (1996 est.)
Waterways: about 1 ,770 km; seagoing craft ply all
coastal inland seas
Pipelines: crude oil 84 km; petroleum products 322
km; natural gas 1 ,800 km
Ports and harbors: Akita, Amagasaki, Chiba,
Hachinohe, Hakodate, Higashi-Harima, Himeji,
Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide,
Shimizu, Tokyo, Tomakomai
Merchant marine:
total: 713 ships (1 ,000 GRT or over) totaling
13,753,027 GRT/1 9, 31 1,31 2 DWT
ships by type: bulk 1 59, cargo 54, chemical tanker 1 3,
combination bulk 16, combination ore/oil 4, container
27, liquefied gas tanker 40, oil tanker 232, passenger
10, passenger-cargo 2, refrigerated cargo 27, roll-on/
roll-off cargo 48, short-sea passenger 13, vehicle
carrier 68 (1998 est.)
Airports: 170 (1998 est.)
Airports - with paved runways:
fofa/:140
over 3,047 m: 5
2,438 to 3,047 m: 35
1,524 to 2,437 m: 39
914 to 1,523 m: 30
under 914 m: 31 (1 998 est.)
Airports - with unpaved runways:
total: 30
914 to 1,523 m: 2
under 914 m: 28 (1998 est.)
Heliports: 14 (1998 est, )
Railways:
total: 4,012 km
standard gauge: 4,012 km 1.435-m gauge (2,422 km
electrified; 96 km double track) (1996)
Highways:
total: 91,180 km
paved: 67,473 km (including 109 km of expressways)
unpaved: 23,707 km (1997 est.)
Waterways: 1 ,577 km along west coast; navigable
by 2.4 m draft vessels maximum
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Flora,
Hammerfest, Harstad, Haugesund, Kristiansand,
Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 788 ships (1 ,000 GRT or over) totaling
21,200,416 GRT/33,642,888 DWT
ships by type: bulk 106, cargo 150, chemical tanker
99, combination bulk 8, combination ore/oil 39,
container 19, liquefied gas tanker 86, multifunction
large-load carrier 1 , oil tanker 143, passenger 12,
refrigerated cargo 15, roll-on/roll-off cargo 52,
*
Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22,960 km (1996 est.)
Pipelines: crude oil 1 ,300 km; natural gas 1 ,030 km
Ports and harbors: Matrah, Mina'' al Fahl, Mina''
Raysut
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 16,306
GRT/8,210 DWT
ships by type: cargo 1 , passenger 1 , passenger-cargo
1 (1 998 est.)
Airports: 143 (1998 est.)
Airports - with paved runways:
total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 137
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 58
914 to 1,523 m: 36
under 914 m: 35 (1 998 est.)
Heliports: 1 (1998 est.)
Ports and harbors: Bangkok (Thailand), Hong
Kong, Kao-hsiung (Taiwan), Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)
Railways:
total: 8,163 km
broad gauge: 7, 718 km 1.676-m gauge (293 km
electrified; 1 ,037 km double track)
narrow gauge: 445 km 1.000-m gauge (1996 est.)
Highways:
total: 224,774 km
paved: 128,121 km
unpaved: 96,653 km (1996 est.)
Pipelines: crude oil 250 km; petroleum products 885
km; natural gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin
Qasim
Merchant marine:
total: 23 ships (1 ,000 GRT or over) totaling 384,304
GRT/61 9,668 DWT
ships by type: bulk 4, cargo 1 5, container 3, oil tanker
1 (1 998 est.)
Airports: 116 (1998 est.)
Airports - with paved runways:
total: 80
over 3,047 m: 11
2,438 to 3,047 m: 20
1,524 to 2,437 m: 31
914 to 1,523 m: 15
under 914 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 36
over 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 18 (1998 est.)
Heliports: 7 (1998 est.)
Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Ports and harbors: Koror
Merchant marine: none
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437m: 1 (1998 est.)
Airports - with unpaved runways:
total: 2
1,524 to 2,437 m: 2(1998 est.)','a7530bb1f1808918179701f830aeed1d5c68728b6401c7f9fccfca978387a009','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bef18c030e2c495f4243ad1860cdd2e8572baccad7fa1b288d9d5a463f0c392',1999,'JO','Jordan','transportation',602,'Railways:
total: 677 km
narrow gauge: 677 km 1.050-m gauge; note - an
additional 1 10 km stretch of the old Hejaz railroad is
out of use (1998 est.)
Highways:
total: 8,000 km
paved: 8,000 km
unpaved: 0 km (1 998 est.)
Pipelines: crude oil 209 km
Ports and harbors: Al Aqabah
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 42,746
GRT/59,1 00 DWT
ships by type: bulk 2, cargo 2, container 1 , livestock
carrier 1 , roll-on/roll-off cargo 1 (1998 est.)
Airports: 17 (1998 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 9
2,438 to 3,047 m: 4
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 91 4 m: 2 (1998 est.)
Railways:
total: NA km; short line going to a jetty
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m;1 (1998 est.)','ac065e22b7488035e1ffaf570dff026634ccf0c56a79967bfb1849c8d40b03be','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('778965ac1b0d2007e4158a7a23d8425e34bd6eae17dae32b1582cfc0d0e80ae7',1999,'KZ','Kazakhstan','transportation',611,'Railways:
total: 14,400 km in common carrier service; does not
include industrial lines
broad gauge: 14,400 km 1.520-m gauge (3,299 km
electrified) (1997)
Highways:
total: 141,000 km
paved: 104,200 km
unpaved: 36,800 km (1997 est.)
Waterways: 3,900 km on the Syrdariya (Syr Darya)
and Ertis (Irtysh)
Pipelines: crude oil 2,850 km; refined products
1 ,500 km; natural gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Airports: 10 (1997 est.)
Airports - with paved runways:
total: 9
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2, 437 m: 2 (1997 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Railways:
total: 2,652 km
narrow gauge: 2,652 km 1.000-m gauge
Highways:
total: 63,800 km
paved: 8,868 km
unpaved: 54,932 km (1996 est.)
Waterways: part of the Lake Victoria system is within
the boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,883 GRT /
6,255 DWT
ships by type: oil tanker 1 , roll-on/roll-off cargo 1
(1998 est.)
Airports: 232 (1998 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 4
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 14 (1998 est.)
Airports - with unpaved runways:
total: 21 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 113
under 914 m: 83 (1998 est.)','15eb2542743cc079218b5e6ba38f68774a2e8d14ba5c9441fb82dc079450355c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afed24f8251e7dac489c8a275529967234622ded653375409e2c3b76f47bf8cd',1999,'WS','Samoa','transportation',617,'Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1937 and 1938
Railways: Okm
Highways:
total: 670 km (1996 est.)
paved: NA km
unpaved: NA km
Waterways: small network of canals, totaling 5 km,
in Line Islands
Ports and harbors: Banaba, Betio, English Harbor,
Kanton
Merchant marine:
total: 1 passenger-cargo (1 ,000 GRT or over) totaling
1 ,291 GRT/1 ,295 DWT (1998 est.)
Airports: 21 (1998 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 17
91 4 to 1,523 m: 12
under 914 m: 5 (1998 est.)
Railways:
broad gauge: NA km
total: 5,000 km
standard gauge: 4,095 km 1.435-m gauge (3,500 km
electrified; 159 km double track)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1.435-m and 1,600-m gauges
(three rails) (1996 est.)
Highways:
total: 31 ,200 km
paved: 1 ,997 km
unpaved: 29,203 km (1996 est.)
Waterways: 2,253 km; mostly navigable by small
craft only
Pipelines: crude oil 37 km; petroleum product 180
km
Ports and harbors: Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine:
total: 1 1 0 ships (1 ,000 GRT or over) totaling 691 ,802
GRT/992,789 DWT
ships by type: bulk 8, cargo 91 , combination bulk 1 ,
multifunction large-load carrier 1 , oil tanker 4,
passenger 2, passenger-cargo 1 , short-sea
passenger 2 (1998 est.)
Airports: 49 (1994 est.) (1998 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 15
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1994 est.)
Airports - with unpaved runways:
total: 27
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 6 (1994 est.)
Railways:
total: 6,240 km
standard gauge: 6,240 km 1 .435-m gauge (525 km
electrified) (1998 est.)
267
Korea, South (continued)
Highways:
total: 63,500 km
paved: 46,800 km (including 1 ,720 km of
expressways)
unpaved: 16,700 km (1998 est.)
Waterways: 1 ,609 km; use restricted to small native
craft
Pipelines: petroleum products 455 km; note -
additionally, there is a parallel petroleum, oils, and
lubricants (POL) pipeline being completed
Ports and harbors: Chinhae, Inch''on, Kunsan,
Masan, Mokp''o, P''ohang, Pusan, Tonghae-hang,
Ulsan, Yosu
Merchant marine:
total: 442 ships (1,000 GRT or over) totaling
5,212,089 GRT/8, 161, 845 DWT
ships by type: bulk 106, cargo 133, chemical tanker
36, combination bulk 5, container 52, liquefied gas
tanker 1 3, multifunction large-load carrier 1 , oil tanker
56, passenger 3, refrigerated cargo 22, roll-on/roll-off
cargo 2, short-sea passenger 1 , specialized tanker 3,
vehicle carrier 9 (1998 est.)
Airports: 103 (1998 est.)
Airports - with paved runways:
total: 68
over 3,047 m:1
2,438 to 3,047 m: 18
1,524 to 2,437 m: 15
914 to 1,523 m: 13
under 91 4 m: 21 (1998 est.)
Airports - with unpaved runways:
total: 35
914 to 1,523 m: 3
under 914 m: 32 (1998 est.)
Heliports: 200 (1998 est.)
Highways: much of the road and many causeways
built during World War II are unserviceable and
overgrown
Ports and harbors: West Lagoon
Airports: 1 (1998 esf.)
note: some overgrowth of vegetation on runway but
still serviceable
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 790 km
paved: 332 km
unpaved: 458 km (1996 est.)
Ports and harbors: Apia, Asau, Mulifanua,
Salelologa
Airports: 3 (1998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1 998 est.)','f71ed3f2eccd6b52e078c3278269423acd0711850510160fe242a9c84d8da787','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acfa2dbe0356cdd4887e46b7911d64a25548d3d74a0cf524ec78af996570cbf0',1999,'KG','Kyrgyzstan','transportation',629,'Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 18,500 km
paved: 16,854 km (including 140 km of expressways)
unpaved: 1 ,646 km (1 996 est.)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 54 (1994 est.)
Airports - with paved runways:
total: 14
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
under 914 m: 1 (1994 est.)
Airports - with unpaved runways:
total: 40
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 32 (1 994 est.)','d510139e6b87f27a41d5f61cb038a5601ad46b7dffe1b2db75d301e29540f3da','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa8f16b62968d004b0ee20dff89d9ca7abf004e8ed6a65fb9be4c408ce2ccc5b',1999,'LV','Latvia','transportation',637,'Railways:
total: 2,412 km
broad gauge: 2,379 km 1 ,520-m gauge (271 km
electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1 994)
Highways:
total: 55,942 km
paved: 21 ,426 km
unpaved: 34,516 km (1997 est.)
Waterways: 300 km perennially navigable
Pipelines: crude oil 750 km; refined products 780
km; natural gas 560 km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga,
Ventspils
Merchant marine:
total: 1 1 ships (1 ,000 GRT or over) totaling 42,429
GRT/44,583 DWT
ships by type: cargo 3, oil tanker 4, refrigerated cargo
3, roll-on/roll-off cargo 1 (1998 est.)
Airports: 50 (1994 est.)
Airports ■ with paved runways:
total: 36
2,438 to 3,047 m: 6
1,524 to 2,437m: 2
914 to 1,523 m: 1
under 914 m: 27 (1994 est.)
Airports - with unpaved runways:
total: 14
2,438 to 3,047 m: 2
914 to 1,523 m: 2
under 914 m: 1 0 (1 994 est.)','eb38727b7ec0fac283ccb4a0a15b01b3fc34f9bb732db1479852ffb649bcef37','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad50aa79401a9c9caa43b5e09a1c25d0d4008c2109faaa63e2be7ac6d240115c',1999,'LB','Lebanon','transportation',646,'Railways:
total: 222 km
standard gauge: 222 km 1 ,435-m (from Beirut to the
Syrian border)
Highways:
total: 6,270 km
paved: 6,270 km
unpaved: 0 km (1998 est.)
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Al Batrun, Al Mina'', An Naqurah,
Antilyas, Az Zahrani, Beirut, Jubayl, Juniyah, Shikka,
Sidon, Tripoli, Tyre
Merchant marine:
total: 64 ships (1 ,000 GRT or over) totaling 267,562
GRT/403,252 DWT
ships by type: bulk 6, cargo 41 , chemical tanker 1 ,
combination bulk 1 , combination ore/oil 1 , container 3,
livestock carrier 6, roll-on/roll-off cargo 2, vehicle
carrier 3 (1998 est.)
Airports: 9 (1998 est.)
Airports - with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 2
914 to 1,523 m: 1
under 91 4 m: 1 (1998 est.)','edb3c933edca55452a08c2b79a5262e349152003e9682163002cf9edc837b5e6','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c21526f042958343768ca126b65497ca1682bcc406ecc4c1453ea823b22e3bb0',1999,'ZA','South Africa','transportation',654,'Railways:
total: 2,6 km; note - owned by, operated by, and
included in the statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge (1995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,068 km (1996 est.)
Ports and harbors: none
Airports: 29 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m: 21 (1998 est.)
Railways:
total: 480 km (328 km single track); note - three rail
systems owned and operated by foreign steel and
financial interests in conjunction with the Liberian
Government; one of these, the Lamco Railroad,
closed in 1989 after iron ore production ceased; the
other two were shut down by the civil war; large
sections of the rail lines have been dismantled;
approximately 60 km of railroad track was exported for
scrap
standard gauge: NA km 1.435-m gauge
narrow gauge: NA km 1 ,067-m gauge
Highways:
total: 10,037 km (there is major deterioration on all
highways due to lack of maintenance since the civil
war began)
paved: 603 km
unpaved: 9,434 km (1996 est.)
Ports and harbors: Buchanan, Greenville, Harper,
Monrovia
Merchant marine:
total: 1 ,651 ships (1 ,000 GRT or over) totaling
59,804,012 GRT/96,650,752 DWT
ships by type: barge carrier 4, bulk 408, cargo 106,
chemical tanker 176, combination bulk 25,
combination ore/oil 50, container 193, liquefied gas
tanker 89, multifunction large-load carrier 2, oil tanker
413, passenger 37, refrigerated cargo 69, roll-on/
roll-off cargo 19, short-sea passenger 3, specialized
tanker 12, vehicle carrier 45
note: a flag of convenience registry; includes ships
from 54 countries among which are Germany 1 86, US
1 61 , Norway 1 42, Greece 144, Japan 1 24, Hong Kong
100, China 53, UK 32, Singapore 39, and Monaco 38
(1998 est.)
Airports: 45 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m:1 (1998 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 3
91 4 to 1,523 m: 5
under 914 m: 35 (1998 est.)','0aebac50918fcf9e9648a7898888d10eb27dbe722dc24f342b69bd5582f3af34','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af8180b6e0f01219caa35be4aa71a96704bff1c32911c2d19c0796ed03ec09c',1999,'LY','Libya','transportation',664,'Railways:
note: Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m standard
gauge line from the Tunisian frontier to Tripoli and
Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been no progress;
other plans made jointly with Egypt would establish a
rail line from As Sallum, Egypt, to Tobruk with
completion set for mid-1994; no progress has been
reported
Highways:
total: 83,200 km
paved: 47,590 km
unpaved: 35,610 km (1996 est.)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1,947 km
Ports and harbors: A! Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 30 ships (1 ,000 GRT or over) totaling 588,928
GRT/989,662 DWT
ships by type: cargo 9, chemical tanker 1 , liquefied
gas tanker 3, oil tanker 9, roll-on/roll-off cargo 4,
short-sea passenger 4 (1998 est.)
Airports: 143 (1998 est.)
Airports - with paved runways:
total: 60
over 3,047 m: 24
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 5
under 914 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 83
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 42
under 914 m: 19 (1998 est.)','12a07addc3aebf827a4a9dc920ed3d8c1bc7724da9580cd0ea495e676ebcaf71','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('474a958d8ea781431906af7b4aa1cad8dcf0b4cf65c68451c2247b0ae7ab563e',1999,'LI','Liechtenstein','transportation',673,'Railways:
total: 18.5 km; note - owned, operated, and included in
statistics of Austrian Federal Railways
standard gauge: 18.5 km 1.435-m gauge (electrified)
Highways:
total: 250 km
paved: 250 km
unpaved: 0 km
Ports and harbors: none
Airports: none','e6c84dcdbe549afd26897d7aa6d985c3b41e2f36fdccb95ce5fed22a4f077f6d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c6b68312f6a445d0a3d7436cce3a66c0a6f4e06a01f7f82d552b1e202c38ef',1999,'CH','Switzerland','transportation',677,'Railways:
total: 2,002 km
broad gauge: 2,002 km 1.524-m gauge (122 km
electrified) (1994)
Highways:
total: 68,161 km
paved: 60,527 km (including 41 0 km of expressways)
unpaved: 7,634 km (1997 est.)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Kaunas, Klaipeda
Merchant marine:
total: 54 ships (1 ,000 GRT or over) totaling 316,616
GRT/353,683 DWT
ships by type: cargo 26, combination bulk 1 1 , oil
tanker 2, railcar carrier 1 , refrigerated cargo 10,
roll-on/roll-off cargo 1 , short-sea passenger 3 (1 998
est.)
Airports: 96 (1994 est.)
Airports - with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 14 (1994 est.)
Airports - with unpaved runways:
total: 71
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 6
under 914 m: 63 (1 994 est.)','53c22b70f7bd645ec2d9ceed35dedb9454cbda0b374265537b5ac9611069bacf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8bf7de309589d3256b5105eac6cf7c4df16e3e0bd131a26c6cec63e15c3365b',1999,'JP','Japan','transportation',686,'Railways:
total: 789 km
narrow gauge: 789 km 1.067-m gauge
Highways:
total: 28,400 km
paved: 5,254 km
unpaved: 23,146 km (1996 est.)
Waterways: Lake Nyasa (Lake Malawi); Shire River,
144 km
Ports and harbors: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota
Airports: 45 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2, 437 m: 1
914 to 1,523 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 40
1,524 to 2, 437 m: 1
914 to 1,523 m: 16
under 914 m: 23 (1 998 est.)','b85a9347ff64972345dd7bff885fc536d60caf7e3aad89ff29277c31355b52c3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16bde9fa5b2d7988bb4073bb2109fe1b0f632658fca2dce4fb05d6f242f1daa0',1999,'MV','Maldives','transportation',696,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km; note - Male has 9.6 km of coral
highways within the city (1988 est.)
Ports and harbors: Gan, Male
Merchant marine:
total: 21 ships (1 ,000 GRT or over) totaling 75,585
GRT/1 15,590 DWT
ships by type: cargo 1 8, container 1 , oil tanker 1 ,
short-sea passenger 1 (1998 est.)
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m:1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 3 (1998 est.)','dde1f2dae0a6eebbe4a3a0de6775687e8f29ec22b3eda35133c50d9fde637009','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62356b7a6c4f395109ae2f4048e17d6ed4eb33087b5bb9dc10c670213be57b51',1999,'ML','Mali','transportation',703,'Railways:
total: 641 km; (linked to Senegal''s rail system through
Kayes)
narrow gauge: 641 km 1.000-m gauge (1995)
Highways:
tofa/: 15,100 km
paved: 1 ,827 km
unpaved: 13,273 km (1996 est.)
Waterways: 1,815 km navigable
Ports and harbors: Kouiikoro
Airports: 28 (1998 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m: A
914 to 1,523 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 22
2,438 to 3,047 m:1
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 1 0 (1 998 est.)','434b10b00c0b4fe468300302fdacb2bc0e3959ec97045df13dac94117532d36c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c247d97b157143b6dd771a7179347c2712d6e8f5db20db723c2e7fc886ce5e8',1999,'MT','Malta','transportation',710,'Railways: 0 km
Highways:
total: 1 ,582 km
paved: 1 ,471 km
unpaved: 111 km (1993 est.)
Ports and harbors: Marsaxlokk, Valletta
Merchant marine:
total: 1 ,361 ships (1 ,000 GRT or over) totaling
24,436,956 GRT/40,706,665 DWT
ships by type: bulk 370, cargo 400, chemical tanker
49, combination bulk 18, combination ore/oil 17,
container 56, liquefied gas tanker 2, livestock carrier
3, multifunction large-load carrier 3, oil tanker 302,
passenger 7, refrigerated cargo 46, roll-on/roll-off
cargo 47, short-sea passenger 19, specialized tanker
4, vehicle carrier 18
note: a flag of convenience registry; includes ships
from 49 countries among which includes Greece 445,
Russia 51 , Switzerland 45, Italy 44, Norway 40,
Croatia 26, Turkey 35, Germany 32, Georgia 23, and
Monaco 24(1998 est.)
Airports: 1 (1998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: 52 km (27 km electrified)
Highways:
total: 640 km
paved: 320 km
unpaved: 320 km
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
310
Man, Isle of (continued)
Merchant marine:
total: 148 ships (1 ,000 GRT or over) totaling
4,161,154 GRT/6, 880,170 DWT
ships by type: bulk 28, cargo 7, chemical tanker 14,
combination bulk 3, container 20, liquefied gas tanker
14, oil tanker 43, refrigerated cargo 3, roll-on/roll-off
cargo 14, vehicle carrier 2
note: a flag of convenience registry; UK owns 8 ships,
Denmark 1 , Sweden 1 , Belgium 1 , and Netherlands 1
(1998 est.)
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
t Military
Military - note: defense is the responsibility of the
UK','63b9c94fadc8a246f6ab244c1ac7393d7d3622eb3f993053166564ad15314837','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87d410b487a6b4f60a49a59c59449cf90e2d0c4318c3c839714144b780063749',1999,'MH','Marshall Islands','transportation',719,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks
Ports and harbors: Majuro
Merchant marine:
total: 131 ships (1 ,000 GRT or over) totaling
6,572,915 GRT/11, 208, 214 DWT
ships by type: bulk 56, cargo 5, chemical tanker 3,
container 20, liquefied gas tanker 2, oil tanker 42,
roll-on/roll-off cargo 2, vehicle carrier 1
note: a flag of convenience registry; includes the ships
312
Marshall Islands (continued)
of Canada 1 , China 1 , Germany 1 , Japan 1 , and US 7
(1998 est.)
Airports: 16 (1998 est.)
Airports - with paved runways:
total: 4
1,524 to 2, 437 m: 3
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 12
914 to 1,523 m: 7
under 914 m: 5 (1998 est.)','1bb9ebc79f96c1de4ae6fd9fee428e9b591b42b1513cd433f8f55e862c46bf32','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eff8e0a68c90586cfc611eaf290cd8234081452eae57026e3336a21e1a6643d',1999,'MR','Mauritania','transportation',730,'Railways:
total: 704 km (single track); note - owned and
operated by government mining company
standard gauge: 704 km 1 ,435-m gauge (1995)
Highways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1996 est.)
Waterways: mostly ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none
Airports: 26 (1998 est.)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m:1 (1998 est.)
Airports ■ with unpaved runways:
total: 18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 9
under 914 m: 2 (1998 est.)','5ba3bf795957e5403377b1d902ac5b49b60a9512dd2165e9a200f9ee63b7d504','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7fa8721cee8d7f908c66302cc9bf910e4765a72cf2107520d10057d6b5e8278',1999,'MU','Mauritius','transportation',737,'Railways: 0 km
Highways:
total: 1 ,860 km
paved: 1 ,732 km (including 30 km of expressways)
unpaved: 128 km (1996 est.)
Ports and harbors: Port Louis
Merchant marine:
total: 17 ships (1 ,000 GRT or over) totaling 178,846
GRT/236,308 DWT
ships by type: cargo 6, combination bulk 2, container
6, liquefied gas tanker 1 , refrigerated cargo 2
318
Mauritius (continued)
note: a flag of convenience registry; India owns 1 ship
(1998 est.)
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1 998 est.)','cdaad9ba651140f44cbeeaae2c5fa3c153b40684d039ce9d03939020fc53a6c7','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd6661bd0718b7482ad4288b55093c4320af2fa21cae02ce6587d4a6e006553e',1999,'YT','Mayotte','transportation',744,'Railways: 0 km
Highways:
total: 93 km
paved: 72 km
unpaved: 21 km
Ports and harbors: Dzaoudzi
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
914 to 7,523 m: 1 (1998 est.)','c6a909d320188d0e182893ab5ec7f16a896c0b908276b83937d7f408fca66ba3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a55526b5beb20d9c43035f5f0568a794186414608a15804b23ef5b4716a6c8ef',1999,'MX','Mexico','transportation',750,'Railways:
total: 31 ,048 km
standard gauge: 30, 958 km 1.435-m gauge (246 km
electrified)
narrow gauge: 90 km 0.91 4-m gauge (1998 est.)
Highways:
total: 252,000 km
paved: 94,248 km (including 6,740 km of
expressways)
unpaved: 157,752 km (1996 est.)
Waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km
Ports and harbors: Acapulco, Altamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 52 ships (1 ,000 GRT or over) totaling 852,004
GRT/1 ,236,475 DWT
ships by type: bulk 2, cargo 1 , chemical tanker 4,
container 4, liquefied gas tanker 7, oil tanker 28,
roll-on/roll-off cargo 3, short-sea passenger 3 (1 998
est.)
Airports: 1,805 (1998 est.)
Airports - with paved runways:
total: 232
over 3,047 m: 10
2,438 to 3,047 m: 27
1,524 to 2,437 m: 91
914 to 1,523 m: 78
under 914 m: 26 (1998 est.)
Airports - with unpaved runways:
total: 1,573
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 63
914 to 1,523 m: 468
under 914 m: 1 ,040 (1 998 est.)
Heliports: 1 (1 998 est.)
Railways:
total: 24,313 km
broad gauge: 652 km 1.520-m gauge
standard gauge: 22,243 km 1 ,435-m gauge (1 1 ,648
km electrified; 8,978 km double track)
narrow gauge: 1,418 km various gauges including
1.000-m, 0.785-m, 0.750-m, and 0.600-m (1996)
Highways:
total: 377,048 km
paved: 247,721 km (including 264 km of
expressways)
unpaved: 129,327 km (1997 est.)
Waterways: 3,812 km navigable rivers and canals
(1996)
Pipelines: crude oil and petroleum products 2,280
km; natural gas 17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Gliwice,
Kolobrzeg, Szczecin, Swinoujscie, Ustka, Warsaw,
Wrocaw
Merchant marine:
total: 61 ships (1,000 GRT or over) totaling 1 ,162,954
GRT/1 ,866,462 DWT
ships by type: bulk 53, cargo 3, chemical tanker 2,
roll-on/roll-off cargo 1, short-sea passenger 2 (1998
est.)
Airports: 92 (1998 est.)
Airports - with paved runways:
total: 74
over 3,047 m: 2
2,438 to 3,047 m: 25
1,524 to 2, 437 m: 38
914 to 1,523 m: 6
under 914 m: 3(1998 est.)
Airports - with unpaved runways:
total: 1 8
2,438 to 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m: 7 (1998 est.)
Heliports: 3 (1998 est.)','48303afa6ae611fa43c8a3cad5e5860b2f503be1e90a6d50a02021edbcc548dc','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca69256f259d40c422c0fb973c00e367b3062ff47c18575c69f0b6d977600e53',1999,'US','United States','transportation',759,'Railways:
total: 1 .7 km
standard gauge: 1 .7 km 1.435-m gauge
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Monaco
Merchant marine: none
Airports: linked to airport in Nice, France, by
helicopter service','68e484e17949d107ec964e2d16ae7a21744ef9cb326c1df8d3e826eb3badc037','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8869396a83833a75c9fa96e5e1df0cf7193a81fa9d24f2e408039e02cbf5cc4f',1999,'CN','China','transportation',763,'Railways:
total: 1 ,928 km
broad gauge: 1,928 km 1.524-m gauge (1994)
Highways:
total: 46,470 km
paved: 3,730 km
unpaved: 42,740 km (1997 est.)
note: much of the unpaved rural road system consists
of rough cross-country tracks
Waterways: 397 km of principal routes (1988)
Ports and harbors: none
Airports: 34 (1994 est.)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m: 1 (1994 est.)
Airports - with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
332
Mongolia (continued)
91 4 to 1,523 m: 3
under 914 m: 5 (1994 est.)','ee903ebcedaccfa7c60a3c7d7b9dc8535e5449caec1734a937e287ae5f3c7b63','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d858c7a8f3b2fc6d585faf5d579e1b910ea4714b66dedd2ce4be8a2e7c748cd4',1999,'MS','Montserrat','transportation',769,'Railways: 0 km
Highways:
total: 269 km
paved: 203 km
unpaved: 66 km (1995)
Ports and harbors: Plymouth (abandoned), Little
Bay (anchorages and ferry landing), Carr''s Bay
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:1 (1998 est.)','1d2462adda95ede5896b3d3290871231207069d7869201bd0a814cb06c29e5ad','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48a5fae514cfc54374cf6497cb87d2582c301f1048b0e9072f1eb6723eb9fe88',1999,'GI','Gibraltar','transportation',777,'Railways:
total: 1 ,907 km
standard gauge: 1 ,907 km 1.435-m gauge (1,003 km
electrified; 246 km double track) (1994)
Highways:
total: 60,626 km
paved: 30,556 km (including 219 km of expressways)
unpaved: 30,070 km (1996 est.)
Pipelines: crude oil 362 km; petroleum products 491
336
Morocco (continued)
km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Mellila
Merchant marine:
total: 40 ships (1 ,000 GRT or over) totaling 21 7,869
GRT/263,033 DWT
ships by type: cargo 8, chemical tanker 6, container 3,
oil tanker 3, passenger 1 , refrigerated cargo 10,
roll-on/roll-off cargo 8, short-sea passenger 1 (1998
est.)
Airports: 69 (1998 est.)
Airports - with paved runways:
total: 26
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2, 437 m: 8
914 to 1,523 m: 2
under 914 m;1 (1998 est.)
Airports - with unpaved runways:
total: 43
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 21
under 914 m: 1 1 (1 998 est.)
Heliports: 1 (1998 est.)','acd1a78b76433a452c33ae15b13a9ff88def084ecd13b000e966637877ef0b1f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79d515eb44ba55724f7e9bbb339ac6fed1fae08725bfc49856b8ebebe8ac5932',1999,'NA','Namibia','transportation',784,'Railways:
total: 2,382 km
340
Namibia (continued)
narrow gauge; 2,382 km 1 .067-m gauge; single track
(1995)
Highways:
total: 64,799 km
paired: 7,841 km
unpaved: 56,958 km (1996 est.)
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none
Airports: 135 (1998 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 3 (1998 est.)
Airports - with unpaved runways:
tofa/:113
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 20
914 to 1,523 m: 70
under 914 m: 21 (1998 est.)','c9fca9638c222d5ce19aa7a2474c5af23b8c1ae1f45a30e75e6e4f6b69a8ee7f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd0f81bf7f308e25a3edd85b023d5552ed1e681b87f0fd206e0693e4590dd4c0',1999,'NR','Nauru','transportation',791,'Unemployment rate: 0%
Budget:
revenues: $23.4 million
expenditures: $64,8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, financial services,
coconut products
Industrial production growth rate: NA%
Electricity - production: 32 million kWh (1996)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1996)
Electricity - consumption: 32 million kWh (1996)
Electricity - exports: 0 kWh (1996)
Electricity - imports: 0 kWh (1 996)
Agriculture - products: coconuts
Exports: $25.3 million (f.o.b., 1991)
Exports - commodities: phosphates
Exports - partners: Australia, NZ
Imports: $21.1 million (c.i.f., 1991)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia, UK, NZ, Japan
Debt -external: $33.3 million
Economic aid - recipient: $2.5 million (1 995); note -
$2.25 million from Australia (FY96/97 est.)
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1 .5853 (January 1 999), 1 .5888 (1 998), 1 .3439 (1 997),
1.2773 (1996), 1.3486 (1995), 1.3667 (1994)
Fiscal year: 1 July - 30 June
Railways:
total: 3.9 km; note - used to haul phosphates from the
center of the island to processing facilities on the
southwest coast
Highways:
total: 30 km
paved: 24 km
unpaved: 6 km (1996 est.)
Ports and harbors: Nauru
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (1998 est.)
Ports and harbors: none; offshore anchorage only','dbdd3b213d5b1835321d2283d603cd191ed2d890d82ffd7b5267d541dfe0010e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b0adbdec737c96fe9be10dc374fd48b8d7d8d22d7d6306fef3a453de4afe75e',1999,'BE','Belgium','transportation',806,'Railways:
total: 2,813 km
standard gauge: 2,813 km 1 .435-m gauge; (1 ,991 km
electrified) (1996)
Highways:
total: 127,000 km
paved: 114,427 km (including 2,360 km of
expressways)
unpaved: 12,573 km (1996 est.)
Waterways: 5,046 km, of which 47% is usable by
craft of 1 ,000 metric ton capacity or larger
Pipelines: crude oil 41 8 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, Delfzijl, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht
Merchant marine:
total: 510 ships (1 ,000 GRT or over) totaling
3,632,477 GRT/4,097,328 DWT
ships by type: bulk 4, cargo 303, chemical tanker 42,
combination bulk 1 , container 52, liquefied gas tanker
17, livestock carrier 1 , multifunction large-load carrier
9, oil tanker 24, passenger 8, refrigerated cargo 30,
roll-on/roll-off cargo 12, short-sea passenger 3,
specialized tanker 4
note: many Dutch-owned ships are also operating
under the registry of Netherlands Antilles (1998 est.)
Airports: 28 (1998 est.)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 91 4 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 9
914 to 1,523 m: 3
under 914 m: 6 (1998 est.)
Heliports: 1 (1 998 est.)','c8243b6d52e650ec4a442df6beee77d6b3bb70bdcbf8f92f34fcdbde8a416793','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cedece6511405c92a489f1e0d837b310a9dbdfd55344042b4a0cafbfe4d79b2',1999,'NL','Netherlands','transportation',813,'Railways: 0 km
Highways:
total: 600 km
paved: 300 km
unpaved: 300 km (1992 est.)
Ports and harbors: Kralendijk, Philipsburg,
Willemstad
Merchant marine:
total: 95 ships (1 ,000 GRT or over) totaling 81 1 ,782
GRT/1 ,045,989 DWT
ships by type: bulk 2, cargo 26, chemical tanker 2,
combination ore/oil 3, container 10, liquefied gas
tanker 4, multifunction large-load carrier 19, oil tanker
4, passenger 1, refrigerated cargo 18, roll-on/roll-off
cargo 6
note: a flag of convenience registry; includes ships of
2 countries: Belgium owns 9 ships, Germany 1 (1 998
est.)
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)','9729f74296287eebf98d621b53700e41b82d230a2e424100eee561cd62cf59a9','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('647beb69a2471f41e71445fa8e296ece379939a4bb043818a7e52186dd4fde3e',1999,'NZ','New Zealand','transportation',821,'Railways:
total: 3,973 km
narrow gauge: 3,973 km 1 ,067-m gauge (51 9 km
electrified)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1 996 est.)
Waterways: 1 ,609 km; of little importance to
Pipelines: petroleum products 160 km; natural gas
1,000 km; liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 138,687
GRT/1 83,372 DWT
ships by type: bulk 4, cargo 1 , liquefied gas tanker 1 ,
oil tanker 3, railcar carrier 1 , roll-on/roll-off cargo 4
(1998 est.)
Airports: 111 (1998 est.)
Airports - with paved runways:
total: 44
over 3,047 m: 2
1,524 to 2,437 m: 10
914 to 1,523 m: 29
under 914 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 67
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 43 (1 998 est.)
Railways: 0 km
Highways:
total: 680 km
paved: 184 km
unpaved: 496 km (1996 est.)
Ports and harbors: Neiafu, Nukualofa, Pangai
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 1 7,754
GRT/25,969 DWT
ships by type: bulk 1 , cargo 2, chemical tanker 1 ,
liquefied gas tanker 2, roll-on/roll-off cargo 1 (1998
•est.)
Airports: 6 (1998 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (1998 est.)
Railways: minimal agricultural railroad system near
San Fernando; railway service was discontinued in
1968
Highways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1996 est.)
Pipelines: crude oil 1,032 km; petroleum products
19 km; natural gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin,
Point Lisas, Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 1 ,336
GRT/2,567 DWT (1998 est.)
Airports: 6 (1998 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:\\
under 91 4 m: 2 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (1998 est, )
Railways: 0 km
Highways:
total: 120 km (lie Uvea 100 km, lie Futuna 20 km)
paved: 16 km (all on lie Uvea)
unpaved: 104 km (lie Uvea 84 km, lie Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 44,1 60
GRT/41 ,656 DWT
ships by type: oil tanker 1 , passenger 1 (1 998 est.)
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)','d54130112edd51d458868b40b753c1b6d6637cdd175f3a522354ceaed5084114','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb933e35d945d52bd1058ea67e7100c9e2b04c5413d917fe6a76d6ebc0170dc0',1999,'NE','Niger','transportation',828,'Railways: 0 km
Highways:
total: 10,100 km
paved: 798 km
unpaved: 9,302 km (1996 est.)
Waterways: Niger river is navigable 300 km from
Niamey to Gaya on the Benin frontier from
mid-December through March
Ports and harbors: none
Airports: 27 (1998 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 2 (1998 est.)','32a75a9f8651607d7670a1a595b9f0b7bff19681ec5e9d10ef39521beb3f99db','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f91656c34660a2d316dc2bcd85b13c7d8610ff6c8f4e9a13334c2baf1967bded',1999,'NF','Norfolk Island','transportation',840,'Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none
Airports: 1 (1998 est.)
Airports'' - with paved runways:
total: 1
1,524 to 2,437 m:1 (1998 est.)','836e5ea01d474fcb9d1b76aab145ab7fd3b0b26ee07b99ea9429e8ee3fc9200f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94170b45270a5c4732b0c12938c20b4c43c75e84f481643f9b71faecc82b39c7',1999,'MP','Northern Mariana Islands','transportation',844,'Railways: 0 km
Highways:
total: 362 km (1991 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none
Airports: 5 (1998 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Heliports: 1 (1998 est.)','3822713337017c659639d38df723f675143a9b88682b094ec4c144e37dfa1f5f','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526b3b80a884313df7e050cb537c521cd27591d5c029e77b4ddaf4b2da6a4f1a',1999,'PA','Panama','transportation',851,'Railways:
total: 355 km
broad gauge: 76 km 1 ,524-m gauge
narrow gauge: 279 km 0.91 4-m gauge
Highways:
total: 11,100 km
paved: 3,730 km (including 30 km of expressways)
unpaved: 7,370 km (1996 est.)
Waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
Pipelines: crude oil 130 km
Ports and harbors: Balboa, Cristobal, Coco Solo,
378
Panama (continued)
Manzanillo (part of Colon area), Vacamonte
Merchant marine:
total: 4,632 ships (1 ,000 GRT or over) totaling
98,433,972 GRT/1 49,800,820 DWT
ships by type: bulk 1 ,335, cargo 1 ,028, chemical
tanker 288, combination bulk 68, combination ore/oil
15, container 507, liquefied gas tanker 176, livestock
carrier 9, multifunction large-load carrier 6, oil tanker
498, passenger 41 , passenger-cargo 5, railcar carrier
2, refrigerated cargo 312, roll-on/roll-off cargo 102,
short-sea passenger 40, specialized tanker 23,
vehicle carrier 177
note: a flag of convenience registry; includes ships
from 71 countries among which are Japan 1 ,262,
Greece 378, Hong Kong 244, South Korea 259,
Taiwan 229, China 193, Singapore 103, US 116,
Switzerland 78, and Indonesia 53 (1998 est.)
Airports: 110 (1998 est.)
Airports - with paved runways:
total: 43
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 22 (1 998 est.)
Airports - with unpaved runways:
total: 67
914 to 1,523 m: 17
under 914 m: 50 (1998 est.)','24ca035d24b747ab61e2d3f1c00060bf13f4f0b4b92fa8c4b9ccc3c66ab5983a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2118cf1561c0eff1604e6ebd89a3392c91c159d7eb0efa3231fa862a0ea9f6ce',1999,'PH','Philippines','transportation',858,'Ports and harbors: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Ports and harbors: none
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2(1998 est.)','9f9e2be341a84bfbcf2fdd3bde60f0c4e89b378a8023de6e469a240a4f77d368','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('966ab42f3fc77989ebe660d55a9636db15c52516cd3d06a46a5f7a9e7c0e3643',1999,'AR','Argentina','transportation',862,'Railways:
total: 971 km
standard gauge: 441 km 1 ,435-m gauge
narrow gauge: km 1.000-m gauge
note: there are 470 km of various gauges that are
privately owned
Highways:
total: 29,500 km
paved: 2,803 km
unpaved: 26,697 km (1996 est.)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encarnacion
Merchant marine:
total: 21 ships (1 ,000 GRT or over) totaling 30,287
GRT/32,510 DWT
ships by type: cargo 15, chemical tanker 1 , oil tanker
4, roll-on/roll-off 1 (1998 est.)
Airports: 941 (1998 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 931
over 3,047 m: 1
1,524 to 2, 437 m: 29
914 to 1,523 m: 349
under 914 m: 552 (1 998 est.)
Railways:
total: 2,041 km
standard gauge: 1 ,726 km 1 .435-m gauge
narrow gauge: 315 km 0.91 4-m gauge (1997)
Highways:
fofa/;72,146 km
paved: 7,353 km
unpaved: 64,793 km (1998 est.)
Waterways: 8,600 km of navigable tributaries of
Amazon system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
385
Peru (continued)
Ports and harbors: Callao, Chimbote, llo, Matarani,
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 51,518
GRT/75,018 DWT
ships by type: cargo 6, oil tanker 1 (1 998 est.)
Airports: 244 (1998 est.)
Airports - with paved runways:
total: 44
over 3,047 m: 7
2,438 to 3,047 m: 15
1,524 to 2,437 m: 12
914 to 1,523 m: 8
under 914 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 200
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 73
under 914 m: 99 (1998 est.)','e267ae7e3516a5dc8f57532e26340fc1ec1f37e2f9a177c3a1593300ce55f6da','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0fef188c523007906890f39539d47a1bac6d6ddbc9b1203f47d236749f990e5',1999,'QA','Qatar','transportation',874,'Railways: 0 km
Highways:
total: 1 ,230 km
paved: 1,107 km
unpaved: 123 km (1996 est.)
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul Island, Umm Sa''id
Merchant marine:
total: 22 ships (1,000 GRT or over) totaling 713,014
GRT/1 ,1 12,829 DWT
ships by type: cargo 10, combination ore/oil 2,
container 5, oil tanker 5 (1998 est.)
Airports: 4 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 2 (1998 est.)
398
Qatar (continued)
Airports - with unpaved runways:
total: 2
914 to 1,523 m:1
under 914 m:1 (1998 est.)
Heliports: 1 (1998 est.)','86ec2fdd2b523417c6ba0e296628ba5f1f4527f29d0834417319421b6e8678cf','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3252f7c6d93acb7ab2056dee704873edcbd3100fb16fb02a1d43d5e5502220ee',1999,'UA','Ukraine','transportation',883,'Railways:
total: 1 1 ,376 km
broad gauge: 60 km 1 ,524-m gauge
standard gauge: 1 0,889 km 1 ,435-m gauge (3,723 km
electrified; 3,060 km double track)
narrow gauge: 427 km 0.760-m gauge (1994)
Highways:
total: 153,358 km
paved: 78,213 km (including 1 1 3 km of expressways)
unpaved: 75,145 km (1996 est.)
Waterways: 1 ,724 km (1 984)
Pipelines: crude oil 2,800 km; petroleum products
1 ,429 km; natural gas 6,400 km (1992)
402
Romania (continued)
Ports and harbors: Braila, Constanta, Galati,
Mangalia, Sulina, Tulcea
Merchant marine:
total: 199 ships (1 ,000 GRT or over) totaling
1 ,996,1 57 GRT/2,91 7,895 DWT
ships by type: bulk 35, cargo 141 , container 2, oil
tanker 7, passenger 1 , passenger-cargo 1 , railcar
carrier 2, roll-on/roll-off cargo 9, specialized tanker 1
(1998 est.)
Airports: 27 (1998 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 4
2,438 to 3,047 m: 6
1,524 to 2,437 m: 1 1 (1998 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1 998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 1 50,000 km; note - 87,000 km in common carrier
service; 63,000 km serve specific industries and are
not available for common carrier use
broad gauge: 150,000 km 1.520-m gauge (January
1997 est.)
Highways:
total: 948,000 km (including 416,000 km which serve
specific industries or farms and are not maintained by
governmental highway maintenance departments)
paved: 336,000 km
unpaved: 61 2,000 km (including 41 1 ,000 km of
graveled or some other form of surfacing and 201 ,000
km of unstabilized earth) (1995 est.)
Waterways: total navigable routes in general use
101 ,000 km; routes with navigation guides serving the
Russian River Fleet 95,900 km; routes with night
navigational aids 60,400 km; man-made navigable
routes 16,900 km (January 1994 est.)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (June 1993 est.)
Ports and harbors: Arkhangelsk, Astrakhan'',
Kaliningrad, Kazan'', Khabarovsk, Kholmsk,
Krasnoyarsk, Moscow, Murmansk, Nakhodka,
Nevel''sk, Novorossiysk, Petropavlovsk-Kamchatski,
St. Petersburg, Rostov, Sochi, Tuapse, Vladivostok,
Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 617 ships (1,000 GRT or over) totaling
4,146,329 GRT/5, 278, 909 DWT
ships by type: barge carrier 1 , bulk 1 9, cargo 309,
combination bulk 21 , combination ore/oil 6, container
25, multifunction large-load carrier 1, oil tanker 149,
passenger 35, passenger-cargo 3, refrigerated cargo
16, roll-on/roll-off cargo 25, short-sea passenger 7
(1998 est.)
Airports: 2,517 (1994 est.)
Airports - with paved runways:
total: 630
over 3,047 m: 54
2,438 to 3,047 m: 202
1,524 to 2,437 m: 108
914 to 1,523 m: 115
under 914 m: 151 (1994 est.)
Airports - with unpaved runways:
total: 1 ,887
over 3,047 m: 25
2,438 to 3,047 m: 45
1,524 to 2,437 m: 134
914 to 1,523 m: 291
under 914 m: 1 ,392 (1994 est.)
Railways: 0 km
Highways:
total: 12,000 km
paved: 1 ,000 km
unpaved: 1 1 ,000 km (1 997 est.)
Waterways: Lac Kivu navigable by shallow-draft
barges and native craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 7 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m:1 (1998 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: NA km (Saint Helena 1 18 km, Ascension NA km,
Tristan da Cunha NA km)
paved: 180.7 km (Saint Helena 98 km, Ascension 80
km, Tristan da Cunha 2.70 km)
unpaved: NA km (Saint Helena 20 km, Ascension NA
km, Tristan da Cunha NA km)
Ports and harbors: Georgetown (on Ascension),
Jamestown
Merchant marine: none
Airports: 1 (1 998 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: 23,350 km
broad gauge: 23,350 km 1 ,524-m gauge (8,600 km
electrified)
Highways:
total: 172,565 km
paved: 163,937 km (including 1 ,875 km of
expressways); note - these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced
unpaved: 8,628 km (1996 est.)
Waterways: 4,400 km navigable waterways, of
which 1 ,672 km were on the Pryp"yat'' and Dnistr
(1990)
Pipelines: crude oil 4,000 km (1995); petroleum
products 4,500 km (1995); natural gas 34,400 km
(1998)
Ports and harbors: Berdyans''k, lllichivs''k, Izmayil,
Kerch, Kherson, Kiev (Kyyiv), Mariupol'', Mykolayiv,
Odesa, Reni
Merchant marine:
total: 181 ships (1,000 GRT or over) totaling
1 ,022,047 GRT/1 ,1 01 ,278 DWT
ships by type: bulk 9, cargo 117, liquefied gas tanker
1 , container 4, multifunction large-load carrier 2, oil
tanker 16, passenger 12, passenger-cargo 3, railcar
carrier 2, refrigerated cargo 2, roll-on/roll-off cargo 10,
short-sea passenger 3 (1998 est.)
Airports: 706 (1994 est.)
Airports - with paved runways:
total: 163
over 3,047 m: 14
2,438 to 3,047 m: 55
1,524 to 2,437 m: 34
914 to 1,523 m: 3
under 914 m: 57 (1 994 est.)
Airports - with unpaved runways:
total: 543
over 3,047 m: 7
2,438 to 3,047 m: 7
1,524 to 2,437 m: 16
914 to 1,523 m: 37
under 914 m: 476 (1994 est.)','144ab3f18fcdbb4efbde3b28a5c541ca1a730aab0eb305013651abe0d2d0bc39','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c067ddf02ed8357ab7f579a4b5d0f2ef7633f5c5462dafb68fbd6293d020278',1999,'TT','Trinidad and Tobago','transportation',893,'Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations (1995)
Highways:
total: 320 km
paved: 1 36 km
unpaved: 184 km (1996 est.)
Ports and harbors: Basseterre, Charlestown
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m: 1 (1998 est.)','fe5e7fc447758fed43858716329ce204feb3d820d5ebcc1cd84157f56020f677','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce8ee6a429e0fafc147cc9c9e38bb8a46695cec80fa0b34bf314a6e95d950bed',1999,'MQ','Martinique','transportation',901,'Railways: 0 km
Highways:
total: 1,210 km
paved: 63 km
unpaved: 1,147 km (1996 est.)
Ports and harbors: Castries, Vieux Fort
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m:1 (1998 est.)
Railways: 0 km
Highways:
total: 1 14 km
paved: 69 km
unpaved: 45 km (1994 est.)
Ports and harbors: Saint Pierre
Merchant marine: none
Airports: 2 (1998 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2(1998 est.)','8c73724e858761d64122a042c274a26e09eb75c522af9799e88dcb76177353c0','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a42145ddc38d49fd04a29886bc14036cb9719770a1039195971ab1c53a7e7b5c',1999,'IT','Italy','transportation',909,'Railways: 0 km; note - there is a 1 .5 km cable railway
connecting the city of San Marino to Borgo Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports and harbors: none
Airports: none
Railways:
total: 4,479 km (1 ,564 km double track)
standard gauge: 3,304 km 1 ,435-m gauge (3,288 km
electrified)
narrow gauge: 1,165 km 1.000-m gauge (1,057 km
electrified); 10 km 0.750-m or 0.800-m gauge (1996)
Highways:
total: 71 ,048 km (including 1 ,613 km of expressways)
paved: NA km
unpaved: NA km (1997 est.)
Waterways: 65 km; Rhine (Basel to Rheinfelden,
Schaffhausen to Bodensee); 12 navigable lakes
Pipelines: crude oil 31 4 km; natural gas 1 ,506 km
Ports and harbors: Basel
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 41 2,459
GRT/724,995 DWT
ships by type: bulk 1 3, cargo 1 , chemical tanker 5, oil
tanker 1 (1998 est.)
Airports: 67 (1998 est.)
Airports - with paved runways:
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 12
914 to 1,523 m:l
under 914 m: 15 (1998 est.)
Airports - with unpaved runways:
total: 25
under 914 m: 25 (1998 est.)
F Military
Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1 ,867,290 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,592,696 (1 999 est.)
Military manpower - reaching military age
annually:
males: 41 ,204 (1999 est.)
Military expenditures - dollar figure: $3.1 billion
(1999)
Military expenditures - percent of GDP: 1 .2%
(1999)
Railways:
total: 1 ,998 km
broad gauge: 1 ,766 km 1 ,435-m gauge
narrow gauge: 232 km 1.050-m gauge
Highways:
total: 41,451 km
paved: 9,575 km (including 877 km of expressways)
unpaved: 31 ,876 km (1997 est.)
Waterways: 870 km; minimal economic importance
Pipelines: crude oil 1 ,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia,
Tartus
Merchant marine:
total: 131 ships (1 ,000 GRT or over) totaling 401 ,407
GRT/578,081 DWT
ships by type: bulk 1 1 , cargo 1 1 5, livestock carrier 4,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 104 (1998 est.)
Airports - with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m:1
under 91 4 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 80
1,524 to 2,437 m: 3
914 to 1,523 m: 14
under 914 m: 63 (1998 est.)
Heliports: 2 (1998 est.)
469
Syria (continued)
i Military Tajwan
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force, Syrian Arab Air Defense
Forces, Police and Security Force
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 4,060,995 (1999 est.)
Military manpower - fit for military service:
males age 15-49: 2,271 ,539 (1999 est.)
Military manpower - reaching military age
annually:
males: 188,546 (1999 est.)
Military expenditures - dollar figure: $800
million-$1 billion (1997 est.); note - based on official
budget data that understate actual spending
Military expenditures - percent of GDP: 8% (1 995
est.)','596acd71b04b02d21dd497716d7c589c9019bfbbc1d8b8687dbbe851bf348022','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('125572439ae7e743561b15adef61df862b384ec326ca57811bda54c45327a1e2',1999,'SA','Saudi Arabia','transportation',917,'Railways:
total: 1 ,390 km
standard gauge: 1 ,390 km 1 .435-m gauge (448 km
double track) (1992)
Highways:
total: 162,000 km
paved: 69,174 km
unpaved: 92,826 km (1996 est.)
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1,600 km)
424
Saudi Arabia (continued)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Mishab, Ras
Tanura, Yanbu'' al Bahr, Madinat Yanbu1 al Sinaiyah
Merchant marine:
total: 73 ships (1 ,000 GRT or over) totaling 1 ,1 24,1 10
GRT/1 ,467,121 DWT
ships by type: bulk 1 , cargo 13, chemical tanker 7,
container 5, liquefied gas tanker 1 , livestock carrier 4,
oil tanker 17, passenger 1, refrigerated cargo 4,
roll-on/roll-off cargo 12, short-sea passenger 8 (1998
est.)
Airports: 205 (1998 est.)
Airports - with paved runways:
total: 70
over 3,047 m: 30
2,438 to 3,047 m: 12
1,524 to 2,437 m: 23
914 to 1,523 m: 3
under 914 m: 2(1998 est.)
Airports - with unpaved runways:
fofa/:135
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 78
914 to 1,523 m: 38
under 914 m: 13 (1998 est.)
Heliports: 4 (1998 est.)','38e815eba505211881fbe5bf531cd472f25b350094023e445d8527d7250d2d10','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2232de669873f9682218fce868ab8c78f5adcb09cd37daaa870b87512c92e60',1999,'ME','Montenegro','transportation',923,'Railways:
total: 904 km
narrow gauge: 904 km 1 .000-meter gauge (70 km
double track) (1995)
Highways:
total: 14,576 km
paved: 4,271 km
unpaved: 10,305 km (1996 est.)
Waterways: 897 km total; 785 km on the Senegal
river, and 1 12 km on the Saloum river
Ports and harbors: Dakar, Kaolack, Matam, Podor,
Richard-Toll, Saint-Louis, Ziguinchor
Merchant marine:
total: 1 bulk ship (1 ,000 GRT or over) totaling 1 ,995
GRT/3,775 DWT (1998 est.)
Airports: 20 (1998 est.)
Airports - with paved runways:
fofa/:10
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1, 523 m: 2 (1998 est.)
Airports - with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 1 (1998 est.)
Railways:
total: 3,987 km
standard gauge: 3,987 km 1 .435-m gauge (1 ,377 km
partially electrified since 1992) (1998)
Highways:
tote/: 50,41 4 km
paved: 45,020 km (including 545 km of expressways)
unpaved: 5,394 km (1997 est.)
Waterways: NAkm
Pipelines: crude oil 41 5 km; petroleum products 1 30
km; natural gas 2,110 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Merchant marine:
total: 1 short-sea passenger (1 ,000 GRT or over)
totaling 2,437 GRT/400 DWT (owned by Montenegro)
(1998 est.)
Airports: 48 (Serbia 43, Montenegro 5) (1998 est.)
Airports - with paved runways:
total: 18
over 3,047 m: 2 (Serbia 2, Montenegro 0)
2,438 to 3,047 m: 5 (Serbia 3, Montenegro 2)
429
Serbia and Montenegro (continued)
1,524 to 2,437 m: 5 (Serbia 4, Montenegro 1 )
914 to 1,523 m: 2 (Serbia 2, Montenegro 0)
under 914 m: 4 (Serbia 4, Montenegro 0) (1998 est.)
Airports - with unpaved runways:
total: 30
1,524 to 2,437 m: 2 (Serbia 2, Montenegro 0)
914 to 1,523 m: 14 (Serbia 13, Montenegro 1)
under 91 4 m: 14 (Serbia 13, Montenegro 1) (1998
est.)','3d206eb516856717b0b29c6b73f29ead667131e7d01b3d3d80f7e378ad7bc84a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e45c0a967aa9506d8701781b1e18df660cb39111ceb24a9b5c697f85dee03bd',1999,'SC','Seychelles','transportation',936,'Railways: 0 km
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1996 est.)
Ports and harbors: Victoria
Merchant marine: none
Airports: 14 (1998 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
431
Seychelles (continued)
Airports - with unpaved runways:
total: 8
914 to 1,523 m: 4
under 914 m: 4 (1998 est.)','5d5140c4279cde35db8127db60a36e6ee6a9ba318f7390545754b4886e40773d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1cd5d799844b09b3d1cd1449a3b7e62a31d88549e1cf2ad6604aae2682c0ed',1999,'SL','Sierra Leone','transportation',944,'Railways:
total: 84 km used on a limited basis because the mine
at Marampa is closed
narrow gauge: 84 km 1 ,067-m gauge
Highways:
total: 1 1 ,700 km
paved: 1 ,287 km
unpaved: 10,413 km (1996 est.)
Waterways: 800 km; 600 km navigable year round
Ports and harbors: Bonthe, Freetown, Pepel
Merchant marine: none
Airports: 10 (1998 est.)
Airports - with paved runways:
total: 2
over 3,047 m:1
914 to 1,523 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 8
914 to 1,523 m: 5
under 914 m: 3 (1998 est,)
Heliports: 1 (1 998 est.)
f Military
Military branches: Army
Military manpower - availability:
males age 15-49: 1,11 9,239 (1 999 est.)
Military manpower - fit for military service:
males age 15-49: 543,210 (1999 est.)
Military expenditures - dollar figure: $46 million
(FY96/97)
Military expenditures - percent of GDP: 2%
(FY96/97)','f99e2a8a86cbb26d3e8b9e69a95be9d51d73467fcdf5fc15cf46e8ab67e172ec','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82e94b77bc37c6f3341c5e30af78b0adda5e07df906c1d629ea05cbb768e5c1a',1999,'SK','Slovakia','transportation',951,'Railways:
total: 3,660 km
broad gauge: 102 km 1.520-m gauge
438
Slovakia (continued)
standard gauge: 3,507 km 1 .435-m gauge (1424 km
electrified)
narrow gauge: 51 km (46 km 1 ,000-m gauge; 5 km
0.750-m gauge) (1996)
Highways:
total: 38,000 km
paved: 37,500 km (including 280 km of expressways)
unpaved: 500 km (1998 est.)
Waterways: 172 km on the Danube
Pipelines: petroleum products NA km; natural gas
2,700 km
Ports and harbors: Bratislava, Komarno
Merchant marine:
total: 3 cargo ships (1 ,000 GRT or over) totaling
15,041 GRT/1 9,51 7 DWT (1998 est.)
Airports: 15 (1998 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2(1998 est.)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (1998 est.)','5dc219e0366afe30b2d8ee8cbe8967b1e4721c6b85c5456363c244608c086842','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22fedfe00780ac21b865d2923778d41aeb908b764d40cd55a7d0891f998d8e84',1999,'SB','Solomon Islands','transportation',961,'Railways: 0 km
Highways:
total: 1 ,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Ports and harbors: Aola Bay, Honiara, Lofung,
Nora, Viru Harbor, Yandina
Merchant marine: none
Airports: 33 (1998 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m;1 (1998 est.)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 91 4 m: 21 (1998 est.)','b478c567616334037cbbe143ba4324707e81b363c32178a55711398cd5220847','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d623008ef09eac070776e230d9a78a1955a0308a94f5ad21337e9fca69cb6dd',1999,'SO','Somalia','transportation',967,'Railways: 0 km
Highways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (1996 est.)
Pipelines: crude oil 15 km
Ports and harbors: Bender Cassim (Boosaaso),
Berbera, Chisimayu (Kismaayo), Merca, Mogadishu
Merchant marine: none
Airports: 61 (1998 est.)
Airports - with paved runways:
total: 7
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m;1
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 54
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 28
under 914 m: 10 (1998 est.)
Railways:
total: 21 ,431 km
narrow gauge: 20,995 km 1 ,067-m gauge (9,087 km
electrified); 436 km 0.61 0-m gauge (1995)
Highways:
total: 331 ,265 km
paved: 137,475 km (including 1,142 km of
expressways)
unpaved: 193,790 km (1995 est.)
Pipelines: crude oil 931 km; petroleum products
1 ,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mosselbaai, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 274,797
GRT/270,837 DWT
ships by type: container 6, oil tanker 2, roll-on/roll-off
cargo 1 (1998 est.)
Airports: 749 (1998 est.)
Airports - with paved runways:
total: 144
over 3,047 m: 10
2,438 to 3,047 m: 4
1,524 to 2,437 m: 45
914 to 1,523 m: 75
under 914 m: 10 (1998 est.)
Airports - with unpaved runways:
total: 605
1,524 to 2,437 m: 35
914 to 1,523 m: 304
under 914 m: 266 (1998 est.)
Ports and harbors: Grytviken
Airports: none
448
South Georgia and the South
Sandwich Islands (continued)','e88c03c4406aa31e56615543dc46480eacba287ac840db4240a34688a992b727','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3d97bdff9c3c6438e9d19433e27fbeb75e8fca91f3815ee0135562b0ce65f02',1999,'LK','Sri Lanka','transportation',976,'Railways:
total: 1 ,501 km
broad gauge; 1,442 km 1.676-m gauge
narrow gauge: 59 km 0.762-m gauge (1995)
Highways:
total: 99,200 km
paved: 39,680 km
unpaved: 59,520 km (1996 est.)
Waterways: 430 km; navigable by shallow-draft craft
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine:
total: 22 ships (1 ,000 GRT or over) totaling 1 78,867
GRT/276,363 DWT
ships by type: bulk 1 , cargo 14, container 1 , oil tanker
1, refrigerated cargo 5 (1998 est.)
Airports: 13 (1998 est.)
Airports - with paved runways:
total: 12
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 6(1998 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2, 437 m:1 (1998 est.)','86ec7ca93070edd7717dd7c4cd69418a6b63c2168634c5719d990ea2fccc6fef','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62516d6b2b6d951c59587f1c7a1fc122c922e3ba80647ab83c808b2507c68695',1999,'SD','Sudan','transportation',983,'Railways:
fofa/:5,516km
narrow gauge: 4,800 km 1.067-m gauge; 716 km
1 .6096-m gauge plantation line
Highways:
total: 1 1 ,900 km
paved: 4,320 km
unpaved: 7, 580 km (1996 est.)
Waterways: 5,310 km navigable
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 38,093
GRT/49,727 DWT
ships by type: cargo 2, roll-on/roll-off cargo 2 (1 998
est.)
Airports: 63 (1998 est.)
Airports - with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (1998 est.)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m: 14
914 to 1,523 m: 26
under 914 m: 11 (1998 est.)
Heliports: 1 (1998 est.)','b263d5bc9679f0b48c237851db008271bf13656d3fbf371d9d87624a84b0be7b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2edd4444790a93f4c1912a7f9894e4fdb4ca4d7a959a107de7ec6c031b3bf8e',1999,'TJ','Tajikistan','transportation',996,'Railways:
total: 480 km in common carrier service; does not
include industrial lines (1990)
Highways:
total: 13,700 km
paved: 1 1 ,330 km (note - these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced)
unpaved: 2,370 km (1996 est.)
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports: 59 (1994 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (1994 est.)
Airports - with unpaved runways:
total: 45
914 to 1,523 m: 9
under 914 m: 36 (1 994 est.)
Railways:
total: 3,569 km (1995)
narrow gauge: 2,600 km 1.000-m gauge; 969 km
1 .067-m gauge
note: the Tanzania-Zambia Railway Authority
(TAZARA), which operates 1 ,860 km of 1 ,067-m
narrow gauge track between Dar es Salaam and
Kapiri Mposhi in Zambia (of which 969 km are in
Tanzania and 891 km are in Zambia) is not a part of
Tanzania Railways Corporation; because of the
difference in gauge, this system does not connect to
Tanzania Railways
Highways:
total: 88,200 km
paved: 3,704 km
unpaved: 84,496 km (1996 est.)
Waterways: Lake Tanganyika, Lake Victoria, Lake
Nyasa
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam,
Kigoma, Kilwa Masoko, Lindi, Mtwara, Mwanza,
Pangani, Tanga, Wete, Zanzibar
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 20,61 8
GRT/26,321 DWT
ships by type: cargo 2, oil tanker 2, passenger-cargo
2, roll-on/roll-off cargo 1 (1998 est.)
Airports: 129 (1998 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 91 4 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 119
over 3,047 m: 1
1,524 to 2,437 m: 18
914 to 1,523 m: 65
under 914 m: 35 (1 998 est.)','aaae0ac056095216254a4c7a6b7816f426ebf17d0659e592d55348042c2b9025','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53c76fadf08abe8155dba1923c3a76a8821e93026cf06077836bba081d657b94',1999,'TH','Thailand','transportation',1004,'Railways:
total: 4,623 km
narrow gauge: 4,623 km 1 ,000-m gauge (99 km
double track)
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1 ,61 5 km (1 996 est.)
Waterways: 3,999 km principal waterways; 3,701
km with navigable depths of 0.9 m or more throughout
the year; numerous minor waterways navigable by
shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhla
Merchant marine:
total: 293 ships (1 ,000 GRT or over) totaling
1,848,626 GRT/2, 989, 382 DWT
ships by type: bulk 41 , cargo 1 35, chemical tanker 5,
combination bulk 1 , container 1 3, liquefied gas tanker
17, multifunction large-load carrier 3, oil tanker 61,
passenger 1 , refrigerated cargo 1 1 , roll-on/roll-off
carqo 2, short-sea passenqer 1 , specialized tanker 2
(1998 est.)
Airports: 107 (1998 est.)
Airports - with paved runways:
total: 56
over 3,047 m: 6
2,438 to 3,047 m: 9
1,524 to 2,437 m: 17
914 to 1,523 m: 20
under 914 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 914 m: 35 (1998 est.)
Heliports: 3 (1998 est.)','90e42f8dcc4514009f09151e9a5d917f6cf0fe44cbee23628fa0cd25faa905e3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a1c6d2fc654b1b00c961898ee45e0e69310cab2b80436229ec94f64e769ddb4',1999,'TG','Togo','transportation',1012,'Railways:
total: 525 km (1995)
narrow gauge: 525 km 1.000-m gauge
Highways:
total: 7, 520 km
paved: 2,376 km
unpaved: 5,144 km (1996 est.)
Waterways: 50 km Mono river
Ports and harbors: Kpeme, Lome
Merchant marine: none
Airports: 9 (1998 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047m: 2(1998 est.)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 5
under 91 4 m: 2 (1998 est.)','a21aab3ffa124b6a6654577a7156f7b0b7286337fee63707af9cf01bf7bff5b2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ac158818e7230ed5cd7eae2725011be04b3a563d32019245ef580251e504b1',1999,'TK','Tokelau','transportation',1013,'(territory of New Zealand)
71K * *
O
O 40 km
0
20 40 ml
Atafu
South Pacific Ocean
i\\
Nukunonu h''~
Fakaofo
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: none; lagoon landings by amphibious
aircraft from Western Samoa','961baf621ba111522e4940441ea240dc464df15c2a2be29c89bbf60776529efe','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac9cea3c1e51d1917cfe9400e0e061f68b0035e7e9eb9b5731844e5b6c9d90a7',1999,'TV','Tuvalu','transportation',1028,'Railways: 0 km
Highways:
fo?a/:8 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 10 ships (1,000 GRT or over) totaling 44,371
GRT/70,137 DWT
ships by type: cargo 6, chemical tanker 2, oil tanker 1 ,
passenger-cargo 1 (1998 est.)
Airports: 1 (1 998 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1 998 est.)
Railways:
total: 1 ,241 km
narrow gauge: 1,241 km 1.000-m gauge
note: a program to rehabilitate the railroad is
underway (1995)
Highways:
total: 27,000 km
paved: 1 ,800 km
unpaved: 25,200 km (of which about 4,800 km are
all-weather roads) (1990 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 roll-on/roll-off cargo ships (1 ,000 GRT or over)
totaling 5,091 GRT/8,229 DWT (1 998 est.)
Airports: 27 (1998 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2,437 m:1 (1998 est.)
Airports - with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 9
under 914 m: 1 (1998 est.)','448f7103ad5f829e5f9ea87b06033d6cb42fec0f83e9ae9e8ab56746ba20d647','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f67fcea89f9477f45ccc8f22acb022a108595152919e594e7e12c8b936eadb9',1999,'AE','United Arab Emirates','transportation',1035,'Railways: 0 km
Highways:
total: 4,835 km
paved: 4,835 km
unpaved: 0 km (1996 est.)
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, Al Fujayrah, Das Island,
Khawr Fakkan, Mina'' Jabal ‘Ali, Mina1 Khalid, Mina1
Rashid, Mina'' Saqr, Mina'' Zayid, Umm al Qaywayn
Merchant marine:
total: 74 ships (1 ,000 GRT or over) totaling 1 ,093,795
GRT/1 ,757,189 DWT
ships by type: bulk 4, cargo 20, chemical tanker 4,
container 8, liquefied gas tanker 1 , livestock carrier 1 ,
oil tanker 28, refrigerated cargo 1 , roll-on/roll-off cargo
7 (1998 est.)
Airports: 41 (1998 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4 (1998 est.)
Airports - with unpaved runways:
total: 20
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m : 9
under 914 m: 5 (1998 est.)
Heliports: 2 (1998 est.)','a3de76e69c30a70c64562fe036d1d6f0f633908e0bcff6b16919eae4a3106623','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40012e946ed93b9d7ef2c63f145802740248e8f6cebdef84af03e433d8fe38ca',1999,'UY','Uruguay','transportation',1044,'Railways:
total: 2,994 km
standard gauge: 2,073 km 1.435-m gauge (921 km
closed) (1997)
Highways:
total: 8,420 km
paved: 7,578 km
unpaved: 842 km (1996 est.)
Waterways: 1 ,600 km; used by coastal and
shallow-draft river craft
Ports and harbors: Fray Bentos, Montevideo,
Nueva Palmira, Paysandu, Punta del Este, Colonia,
Piriapolis
Merchant marine:
total: 2 oil tankers (1 ,000 GRT or over) totaling 44,042
GRT/83,684 DWT(1998 est.)
Airports: 65 (1998 est.)
Airports - with paved runways:
total: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 50
1,524 to 2, 437 m: 2
914 to 1,523 m: 15
under 914 m: 33 (1 998 est.)
Railways:
total: 3,380 km in common carrier service; does not
include industrial lines
broad gauge: 3,380 km 1.520-m gauge (300 km
electrified) (1993)
Highways:
total: 81 ,600 km
paved: 71 ,237 km (note - these roads are said to be
hard surfaced, meaning that some are paved and
some are all-weather gravel surfaced)
unpaved: 10,363 km dirt (1 996 est.)
Waterways: 1,100(1990)
Pipelines: crude oil 250 km; petroleum products 40
km; natural gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya river)
Airports: 3 (1997 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m: 1 (1997 est.)','08ed1ce4be591e2c3cd915f774cb29f0f72f83229e02f5adec2fdb1f4f09ba50','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a804ac9f9e8fab5dfb0bffcd1a71a67f3d4529df33d33933dceff2098858181',1999,'VU','Vanuatu','transportation',1054,'Railways: 0 km
Highways:
total: 1 ,070 km
paved: 256 km
unpaved: 814 km (1996 est.)
Ports and harbors: Forari, Port-Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 82 ships (1 ,000 GRT or over) totaling 1 ,327,078
GRT/1 ,764,558 DWT
ships by type: bulk 31 , cargo 24, chemical tanker 3,
combination bulk 1 , liquefied gas tanker 4, oil tanker 2,
refrigerated cargo 1 1 , vehicle carrier 6
note: a flag of convenience registry; includes ships
from 1 5 countries among which are ships of Japan 28,
India 10, US 10, Greece 3, Hong Kong 3, Australia 2,
Canada 1, China 1, and France 1 (1998 est.)
Airports: 32 (1998 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m:1 (1998 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 17 (1998 est.)
Railways:
total: 584 km (248 km privately owned)
standard gauge: 584 km 1 ,435-m gauge
Highways:
tote/: 84,300 km
paved: 33,21 4 km
unpaved: 51 ,086 km (1996 est.)
Waterways: 7,100 km; Rio Orinoco and Lago de
Maracaibo accept oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz, Puerto Ordaz,
Puerto Sucre, Punta Cardon
Merchant marine:
total: 32 ships (1 ,000 GRT or over) totaling 535,882
GRT/937,461 DWT
ships by type: bulk 5, cargo 9, combination bulk 1 ,
liquefied gas tanker 2, oil tanker 8, passenger-cargo 1 ,
roll-on/roll-off cargo 5, short-sea passenger 1 (1998
est.)
Airports: 371 (1998 est.)
Airports - with paved runways:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 4,639 km
border countries: Cambodia 1 ,228 km, China 1,281
km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical in south; monsoonal in north with
hot, rainy season (mid-May to mid-September) and
520
Vietnam (continued)
warm, dry season (mid-October to mid-March)
Terrain: low, tlat delta in south and north; central
highlands; hilly, mountainous in far north and
northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,1 43 m
Natural resources: phosphates, coal, manganese,
bauxite, chromate, offshore oil and gas deposits,
forests
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 1 %
forests and woodland: 30%
other: 48% (1993 est.)
Irrigated land: 18,600 sq km (1993 est.)
Natural hazards: occasional typhoons (May to
January) with extensive flooding
Environment - current issues: logging and
slash-and-burn agricultural practices contribute to
deforestation and soil degradation; water pollution
and overfishing threaten marine life populations;
groundwater contamination limits potable water
supply; growing urban industrialization and population
migration are rapidly degrading environment in Hanoi
and Ho Chi Minh City
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Railways:
total: 2,835 km (in addition, there are 224 km not
restored to service after war damage)
standard gauge: 151 km 1.435-m gauge
narrow gauge: 2,454 km 1 ,000-m gauge
dual gauge: 230 km NA-m gauges (three rails)
Highways:
total: 93,300 km
paved: 23,41 8 km
unpaved: 69,882 km (1996 est.)
Waterways: 17,702 km navigable; more than 5,149
km navigable at all times by vessels up to 1 .8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minh City, Hong Gai, Qui Nhon,
Nha Trang
Merchant marine:
total: 123 ships (1 ,000 GRT or over) totaling 527,920
GRT/820,515 DWT
ships by type: bulk 7, cargo 98, chemical tanker 1 ,
combination bulk 1 , oil tanker 12, refrigerated cargo 4
(1998 est.)
Airports: 48 (1994 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 7 (1994 est.)
Airports - with unpaved runways:
total: 12
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 5 (1994 est.)','90d61516a2784538787379bd2aa458403459b2433461d7c8cd4880822048153a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de9ab0b3b9da2492b72d032fe56afbd1a70a543c7b7e4cca01afdd6c154ffe74',1999,'PR','Puerto Rico','transportation',1060,'Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine: none
Airports: 2
note: international airports on Saint Thomas and Saint
Croix; there is an airfield on St. John (1998 est.)
Airports - with paved runways:
total: 2
1, 524 to 2, 437 m: 2 (1998 est.)','a189eeddf63c90b34701e462fab6c879229b8a3f89e83f54c4b983cc3e041513','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c967fcb9be2a1386057e30ce1dba47cc56421ef742eead82058ebf64f9f619ee',1999,'ZM','Zambia','transportation',1070,'Railways: 0 km
Highways:
total: 64,725 km
paved: 5,243 km
unpaved: 59,482 km (1 996 est.)
Pipelines: crude oil 644 km; petroleum products 32
km
Ports and harbors: Aden, Al Hudaydah, Al Mukalla,
As Salif, Mocha, Nishtun
Merchant marine:
fofa/: 3 ships (1 ,000 GRT or over) totaling 12,059
GRT/1 8,563 DWT
ships by type: cargo 1 , oil tanker 2 (1 998 est.)
Airports: 48 (1998 est.)
Airports - with paved runways:
total: 12
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports - with unpaved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 10
914 to 1,523 m: 12
under 91 4 m: 3 (1998 est.)','cabb6fca567d9093323bedab5572c3bb370d834a70ab2c24e42ffbb34fd67dc4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2f51a36dfdeb2501102f99fcb2867ce43fa3de475122322e8a0fec2b004b233',1999,'ZW','Zimbabwe','transportation',1078,'Railways:
total: 2,164 km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13 km
double track)
note: the total includes 891 km of the
Tanzania-Zambia Railway Authority (TAZARA), which
operates 1 ,860 km of 1 .067-m narrow gauge track
between Dar es Salaam and Kapiri Mposhi where it
connects to the Zambia Railways system; TAZARA is
not a part of Zambia Railways
Highways:
total: 39,700 km
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium, tin,
platinum group metals
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 23%
other: 57% (1993 est.)
Irrigated land: 1 ,930 sq km (1993 est.)
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment - current issues: deforestation; soil
erosion; land degradation; air and water pollution; the
black rhinoceros herd - once the largest concentration
of the species in the world - has been significantly
reduced by poaching
536
Zimbabwe (continued)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection
signed , but not ratified: none of the selected
agreements
Geography - note: landlocked
Railways:
total: 2,759 km (1995)
narrow gauge: 2, 759 km 1.067-m gauge (313 km
electrified; 42 km double track) (1995 est.)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1 996 est.)
Waterways: the Mazoe and Zambezi rivers are used
for transporting chrome ore from Harare to','7de8b134c69de76cbf519f07be70d66ced47746902b48d484eb8cb649ff035be','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e497f8520d29c88f2ed3f2d556e4f82c03282ccb80740d8dbca7156e922a6f6',1999,'ZW','Zimbabwe','transportation',11,'Railways:
total: 24.6 km
broad gauge: 9.6 km 1.524-m gauge from Gushgy (Turkmenistan) to
Towraghondi; 15 km 1.524-m gauge from Termiz (Uzbekistan) to
Kheyrabad transshipment point on south bank of Amu Darya
Highways:
total: 21,000 km
paved: 2,793 km
unpaved: 18,207 km (1996 est.)
Waterways: 1,200 km; chiefly Amu Darya, which handles vessels up
to about 500 DWT
Pipelines: petroleum products--Uzbekistan to Bagram and
Turkmenistan to Shindand; natural gas 180 km
Ports and harbors: Kheyrabad, Shir Khan
Merchant marine:
total: 1 container ship (1,000 GRT or over) totaling 11,982
GRT/14,101 DWT (1998 est.)
Airports: 44 (1998 est.)
Airports--with paved runways:
total: 11
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 33
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 4
under 914 m: 10 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 447 km (none electrified)
standard gauge: 447 km 1.435-m gauge (1995)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1996 est.)
Waterways: 43 km plus Albanian sections of Lake Scutari, Lake
Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55 km; natural
gas 64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin, Vlore
Merchant marine:
total: 8 cargo ships (1,000 GRT or over) totaling 28,394 GRT/41,429
DWT (1998 est.)
Airports: 9 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 4,772 km
standard gauge: 3,616 km 1.435-m gauge (301 km electrified; 215 km
double track)
narrow gauge: 1,156 km 1.055-m gauge
Highways:
total: 102,424 km
paved: 70,570 km (including 608 km of expressways)
unpaved: 31,854 km (1995 est.)
Pipelines: crude oil 6,612 km; petroleum products 298 km; natural
gas 2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia, Beni Saf,
Dellys, Djendjene, Ghazaouet, Jijel, Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 78 ships (1,000 GRT or over) totaling 933,672 GRT/1,094,104
DWT
ships by type: bulk 9, cargo 27, chemical tanker 7, liquefied gas
tanker 11, oil tanker 5, roll-on/roll-off cargo 13, short-sea
passenger 5, specialized tanker 1 (1998 est.)
Airports: 137 (1998 est.)
Airports--with paved runways:
total: 51
over 3,047 m: 8
2,438 to 3,047 m: 24
1,524 to 2,437 m: 13
914 to 1,523 m: 5
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 86
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 40
under 914 m: 19 (1998 est.)
Heliports: 1 (1998 est.)','52e801a072e1ee754826184e34ca2aaf06878e716af3dda43a50abb96ac5deaa','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d062bc776155952b309c4769580fe1c1f455dee9fcf6294f0437d665469e61c',1999,'LY','Libya','transportation',21,'Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Ports and harbors: Aunu''u (new construction), Auasi, Faleosao,
Ofu, Pago Pago, Ta''u
Merchant marine: none
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 2
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 71 km (1991 est.)
Ports and harbors: none
Airports: none
Railways:
total: 2,952 km (limited trackage in use because of land mines still
in place from the civil war) (1997 est.)
narrow gauge: 2,798 km 1.067-m gauge; 154 km 0.600-m gauge
Highways:
total: 76,626 km
paved: 19,156 km
unpaved: 57,470 km (1997 est.)
Waterways: 1,295 km navigable
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito, Luanda, Malongo,
Namibe, Porto Amboim, Soyo
Merchant marine:
total: 10 ships (1,000 GRT or over) totaling 48,384 GRT/78,357 DWT
ships by type: cargo 9, oil tanker 1 (1998 est.)
Airports: 252 (1998 est.)
Airports--with paved runways:
total: 32
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 220
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 32
914 to 1,523 m: 100
under 914 m: 82 (1998 est.)
Railways: 0 km
Highways:
total: 105 km
paved: 65 km
unpaved: 40 km (1992 est.)
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 2
under 914 m: 2 (1998 est.)
Ports and harbors: none; offshore anchorage
Airports: 17; 27 stations, operated by 16 national governments
party to the Antarctic Treaty, have landing facilities for either
helicopters and/or fixed-wing aircraft; commercial enterprises
operate two additional air facilities; helicopter pads are available
at 27 stations; runways at 15 locations are gravel, sea-ice,
blue-ice, or compacted snow suitable for landing wheeled, fixed-wing
aircraft; of these, 1 is greater than 3 km in length, 6 are between
2 km and 3 km in length, 3 are between 1 km and 2 km in length, 3
are less than 1 km in length, and 2 are of unknown length; snow
surface skiways, limited to use by ski-equipped, fixed-wing
aircraft, are available at another 15 locations; of these, 4 are
greater than 3 km in length, 3 are between 2 km and 3 km in length,
2 are between 1 km and 2 km in length, 2 are less than 1 km in
length, and 4 are of unknown length; airports generally subject to
severe restrictions and limitations resulting from extreme seasonal
and geographic conditions; airports do not meet ICAO standards;
advance approval from the respective governmental or nongovernmental
operating organization required for landing (1998 est.)
Airports--with unpaved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 5 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 77 km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.610-m gauge (used almost
exclusively for handling sugarcane)
Highways:
total: 250 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Saint John''s
Merchant marine:
total: 517 ships (1,000 GRT or over) totaling 2,706,126
GRT/3,542,664 DWT
ships by type: bulk 21, cargo 338, chemical tanker 7, combination
bulk 2, container 111, liquefied gas tanker 2, multifunctional
large-load carrier 1, oil tanker 4, refrigerated cargo 9,
roll-on/roll-off cargo 21, vehicle carrier 1
note: a flag of convenience registry: Germany owns 10 ships,
Slovenia 2, and Cyprus 2 (1998 est.)
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Ports and harbors: Churchill (Canada), Murmansk (Russia), Prudhoe
Bay (US)
Transportation--note: sparse network of air, ocean, river, and
land routes; the Northwest Passage (North America) and Northern Sea
Route (Eurasia) are important seasonal waterways
Railways:
total: 37,830 km
broad gauge: 23,992 km 1.676-m gauge (167 km electrified)
standard gauge: 2,765 km 1.435-m gauge
narrow gauge: 11,073 km 1.000-m gauge (26 km electrified)
Highways:
total: 208,350 km
paved: 47,550 km (including 567 km of expressways)
unpaved: 160,800 km (1998 est.)
Waterways: 11,000 km navigable
Pipelines: crude oil 4,090 km; petroleum products 2,900 km;
natural gas 9,918 km
Ports and harbors: Bahia Blanca, Buenos Aires, Comodoro
Rivadavia, Concepcion del Uruguay, La Plata, Mar del Plata,
Necochea, Rio Gallegos, Rosario, Santa Fe, Ushuaia
Merchant marine:
total: 29 ships (1,000 GRT or over) totaling 233,856 GRT/363,335 DWT
ships by type: cargo 10, container 1, oil tanker 13, railcar carrier
1, refrigerated cargo 2, roll-on/roll-off cargo 1, short-sea
passenger 1 (1998 est.)
Airports: 1,374 (1998 est.)
Airports--with paved runways:
total: 141
over 3,047 m: 5
2,438 to 3,047 m: 26
1,524 to 2,437 m: 58
914 to 1,523 m: 45
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 1,233
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 67
914 to 1,523 m: 621
under 914 m: 541 (1998 est.)','01972537fdf48264ac6c3bdce6d248c9673b36719123b4b75d534e28413a5906','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd74440aed64787d0ca143e4dc70a096d0aadbb28edd1ae3bb22915abfc7200e',1999,'AM','Armenia','transportation',28,'Railways:
total: 825 km in common carrier service; does not include industrial
lines
broad gauge: 825 km 1.520-m gauge (1992)
Highways:
total: 8,580 km
paved: 8,580 km
unpaved: 0 km (1996 est.)
Waterways: NA km
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 11 (1996 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1996 est.)
Airports--with unpaved runways:
total: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 1 (1996 est.)
Railways: 0 km
Highways:
total: 300 km
paved: 130 km
unpaved: 170 km
note: most coastal roads are paved, while unpaved roads serve large
tracts of the interior
Ports and harbors: Barcadera, Oranjestad, Sint Nicolaas
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,366 GRT/1,595 DWT
(1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Ports and harbors: Alexandria (Egypt), Algiers (Algeria), Antwerp
(Belgium), Barcelona (Spain), Buenos Aires (Argentina), Casablanca
(Morocco), Colon (Panama), Copenhagen (Denmark), Dakar (Senegal),
Gdansk (Poland), Hamburg (Germany), Helsinki (Finland), Las Palmas
(Canary Islands, Spain), Le Havre (France), Lisbon (Portugal),
London (UK), Marseille (France), Montevideo (Uruguay), Montreal
(Canada), Naples (Italy), New Orleans (US), New York (US), Oran
(Algeria), Oslo (Norway), Peiraiefs or Piraeus (Greece), Rio de
Janeiro (Brazil), Rotterdam (Netherlands), Saint Petersburg
(Russia), Stockholm (Sweden)
Transportation--note: Kiel Canal and Saint Lawrence Seaway are two
important waterways
Railways:
total: 38,563 km (2,914 km electrified)
broad gauge: 6,083 km 1.600-m gauge
standard gauge: 16,752 km 1.435-m gauge
narrow gauge: 15,728 km 1.067-m gauge
dual gauge: 172 km NA gauges
Highways:
total: 913,000 km
paved: 353,331 km (including 13,630 km of expressways)
unpaved: 559,669 km (1996 est.)
Waterways: 8,368 km; mainly by small, shallow-draft craft
Pipelines: crude oil 2,500 km; petroleum products 500 km; natural
gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns, Darwin, Devonport
(Tasmania), Fremantle, Geelong, Hobart (Tasmania), Launceston
(Tasmania), Mackay, Melbourne, Sydney, Townsville
Merchant marine:
total: 57 ships (1,000 GRT or over) totaling 1,767,387 GRT/2,426,710
DWT
ships by type: bulk 29, cargo 3, chemical tanker 4, container 4,
liquefied gas tanker 4, oil tanker 8, passenger 1, roll-on/roll-off
cargo 4 (1998 est.)
Airports: 408 (1998 est.)
Airports--with paved runways:
total: 262
over 3,047 m: 11
2,438 to 3,047 m: 11
1,524 to 2,437 m: 112
914 to 1,523 m: 120
under 914 m: 8 (1998 est.)
Airports--with unpaved runways:
total: 146
1,524 to 2,437 m: 19
914 to 1,523 m: 114
under 914 m: 13 (1998 est.)
Railways:
total: 5,849 km (there is also 594 km of private tracks)
standard gauge: 5,470 km 1.435-m gauge (3,418 km electrified)
narrow gauge: 379 km 1.000-m and 0.760-m gauge (84 km electrified)
(1997)
Highways: 129,061 km
paved: 129,061 km (including 1,613 km of expressways)
unpaved: 0 km (1997 est.)
Waterways: 358 km (1997)
Pipelines: crude oil 777 km; natural gas 840 km (1997)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 22 ships (1,000 GRT or over) totaling 67,066 GRT/95,693 DWT
ships by type: bulk 1, cargo 18, combination bulk 2, container 1
(1998 est.)
Airports: 55 (1998 est.)
Airports--with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 12 (1998 est.)
Airports--with unpaved runways:
total: 33
914 to 1,523 m: 4
under 914 m: 29 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 2,125 km in common carrier service; does not include
industrial lines
broad gauge: 2,125 km 1.520-m gauge (1,278 km electrified) (1993)
Highways:
total: 57,770 km
paved: 54,188 km
unpaved: 3,582 km (1995 est.)
Pipelines: crude oil 1,130 km; petroleum products 630 km; natural
gas 1,240 km
Ports and harbors: Baku (Baki)
Merchant marine:
total: 57 ships (1,000 GRT or over) totaling 251,404 GRT/ 306,264 DWT
ships by type: cargo 12, oil tanker 42, roll-on/roll-off cargo 2,
short-sea passenger 1 (1998 est.)
Airports: 69 (1996 est.)
Airports--with paved runways:
total: 29
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 17
914 to 1,523 m: 3
under 914 m: 1 (1996 est.)
Airports--with unpaved runways:
total: 40
914 to 1,523 m: 7
under 914 m: 33 (1996 est.)
Railways: 0 km
Highways:
total: 2,693 km
paved: 1,546 km
unpaved: 1,147 km (1997 est.)
Ports and harbors: Freeport, Matthew Town, Nassau
Merchant marine:
total: 1,079 ships (1,000 GRT or over) totaling 26,631,924
GRT/41,196,326 DWT
ships by type: bulk 209, cargo 241, chemical tanker 43, combination
bulk 13, combination ore/oil 22, container 61, liquefied gas tanker
34, livestock carrier 1, oil tanker 170, passenger 62,
passenger-cargo 1, railcar carrier 1, refrigerated cargo 140,
roll-on/roll-off cargo 48, short-sea passenger 12, specialized
tanker 2, vehicle carrier 19
note: a flag of convenience registry; includes ships from 49
countries among which are Norway 177, Greece 141, UK 113, US 61,
Denmark 39, Finland 27, Japan 25, Sweden 24, France 22, and Italy 22
(1998 est.)
Airports: 62 (1998 est.)
Airports--with paved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 15
914 to 1,523 m: 13
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 29
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 21 (1998 est.)','0e7a17ccd98d9e0590f542a3ea94ba88425bfdc63d73924e4d9993d42816669e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de717469488bc2c6b51393add94918d016c7db7a06b69fd5ce8eb0e7e9ae5afc',1999,'SA','Saudi Arabia','transportation',40,'Railways: 0 km
Highways:
total: 3,103 km
paved: 2,374 km
unpaved: 729 km (1997 est.)
Pipelines: crude oil 56 km; petroleum products 16 km; natural gas
32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 228,273 GRT/304,654 DWT
ships by type: bulk 2, cargo 3, container 2, oil tanker 1 (1998 est.)
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Heliports: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only; note--there is
one boat landing area along the middle of the west coast
Airports: 1 abandoned World War II runway of 1,665 m, completely
covered with vegetation and unusable
Transportation--note: there is a day beacon near the middle of the
west coast
Railways:
total: 2,745 km
broad gauge: 923 km 1.676-m gauge
narrow gauge: 1,822 km 1.000-m gauge (1998 est.)
Highways:
total: 204,022 km
paved: 25,095 km
unpaved: 178,927 km (1996 est.)
Waterways: 5,150-8,046 km navigable waterways (includes
2,575-3,058 km main cargo routes)
Pipelines: natural gas 1,220 km
Ports and harbors: Chittagong, Dhaka, Mongla Port
Merchant marine:
total: 40 ships (1,000 GRT or over) totaling 315,855 GRT/453,002 DWT
ships by type: bulk 2, cargo 33, oil tanker 2, refrigerated cargo 1,
roll-on/roll-off cargo 2 (1998 est.)
Airports: 16 (1998 est.)
Airports--with paved runways:
total: 15
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 1,650 km
paved: 1,582 km
unpaved: 68 km (1998 est.)
Ports and harbors: Bridgetown, Speightstown (Port Charles Marina)
Merchant marine:
total: 44 ships (1,000 GRT or over) totaling 641,550 GRT/1,087,042
DWT
ships by type: bulk 11, cargo 26, combination bulk 1, oil tanker 4,
refrigerated cargo 1, roll-on/roll-off cargo 1
note: a flag of convenience registry; includes ships of 2 countries:
Canada owns 2 ships, Hong Kong 1 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 5,563 km
broad gauge: 5,563 km 1.520-m gauge (894 km electrified)
Highways:
total: 53,407 km
paved: 52,446 km
unpaved: 961 km (1997 est.)
Waterways: NA km; note--Belarus has extensive and widely used
canal and river systems
Pipelines: crude oil 1,470 km; refined products 1,100 km; natural
gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 118 (1996 est.)
Airports--with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 18
1,524 to 2,437 m: 5
under 914 m: 11 (1996 est.)
Airports--with unpaved runways:
total: 82
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 62 (1996 est.)
Railways:
total: 3,380 km (2,459 km electrified; 2,563 km double track)
standard gauge: 3,380 km 1.435-m gauge (1996)
Highways:
total: 143,175 km
paved: 143,175 km (including 1,674 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 2,043 km (1,528 km in regular commercial use)
Pipelines: crude oil 161 km; petroleum products 1,167 km; natural
gas 3,300 km
Ports and harbors: Antwerp (one of the world''s busiest ports),
Brugge, Gent, Hasselt, Liege, Mons, Namur, Oostende, Zeebrugge
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 35,668 GRT/56,412 DWT
ships by type: bulk 1, cargo 8, chemical tanker 8, oil tanker 6
(1998 est.)
Airports: 42 (1998 est.)
Airports--with paved runways:
total: 24
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 6 (1998 est.)
Airports--with unpaved runways:
total: 18
914 to 1,523 m: 2
under 914 m: 16 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 2,248 km
paved: 427 km
unpaved: 1,821 km (1996 est.)
Waterways: 825 km river network used by shallow-draft craft;
seasonally navigable
Ports and harbors: Belize City, Big Creek, Corozol, Punta Gorda
Merchant marine:
total: 403 ships (1,000 GRT or over) totaling 1,740,325
GRT/2,511,709 DWT
ships by type: bulk 34, cargo 259, chemical tanker 5, container 9,
liquefied gas tanker 1, oil tanker 58, passenger-cargo 2,
refrigerated cargo 21, roll-on/roll-off cargo 8, short-sea/passenger
3, specialized tanker 2, vehicle carrier 1
note: a flag of convenience registry; includes ships of 7 countries:
Cuba 2, Cyprus 1, Greece 1, Singapore 2, UAE 12, UK 1, and US 1
(1998 est.)
Airports: 44 (1998 est.)
Airports--with paved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 41
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 30 (1998 est.)
Railways:
total: 578 km (single track)
narrow gauge: 578 km 1.000-m gauge (1995 est.)
Highways:
total: 6,787 km
paved: 1,357 km (including 10 km of expressways)
unpaved: 5,430 km (1996 est.)
Waterways: navigable along small sections, important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: 225 km
paved: 225 km
unpaved: 0 km (1997 est.)
note: in addition, there are 232 km of paved and unpaved roads that
are privately owned
Ports and harbors: Hamilton, Saint George
Merchant marine:
total: 97 ships (1,000 GRT or over) totaling 4,647,576 GRT/7,612,686
DWT
ships by type: bulk 18, cargo 3, chemical tanker 1, container 20,
liquefied gas tanker 7, oil tanker 27, refrigerated cargo 15,
roll-on/roll-off cargo 4, short-sea passenger 2
note: a flag of convenience registry; includes ships from 11
countries among which are UK 24, Canada 12, Hong Kong 11, US 11,
Nigeria 4, Sweden 4, Norway 3, and Switzerland 2 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 3,285 km
paved: 1,994 km
unpaved: 1,291 km (1996 est.)
Ports and harbors: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1.000-m gauge; 39 km 0.760-m gauge (13 km
electrified) (1995)
Highways:
total: 52,216 km
paved: 2,872 km (including 27 km of expressways)
unpaved: 49,344 km (1995 est.)
Waterways: 10,000 km of commercially navigable waterways
Pipelines: crude oil 1,800 km; petroleum products 580 km; natural
gas 1,495 km
Ports and harbors: none; however, Bolivia has free port
privileges in the maritime ports of Argentina, Brazil, Chile, and
Railways: 0 km
Highways:
total: 1,230 km
paved: 1,107 km
unpaved: 123 km (1996 est.)
Pipelines: crude oil 235 km; natural gas 400 km
Ports and harbors: Doha, Halul Island, Umm Sa''id
Merchant marine:
total: 22 ships (1,000 GRT or over) totaling 713,014 GRT/1,112,829
DWT
ships by type: cargo 10, combination ore/oil 2, container 5, oil
tanker 5 (1998 est.)
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Heliports: 1 (1998 est.)','d852f2f4cf397becf6e61e1433d1e250159356d3d5829fb7fdff02ab5f3d7498','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e3384cc6ed5176abc7a4505f37ec739b87ae60bd099e850783997bc1466e23f',1999,'PY','Paraguay','transportation',44,'Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 34,948 GRT/58,472 DWT
ships by type: bulk 1, cargo 5 (1998 est.)
Airports: 1,130 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1,118
2,438 to 3,047 m: 3
1,524 to 2,437 m: 70
914 to 1,523 m: 224
under 914 m: 821 (1998 est.)','44d522ec710e04bb8c37298a4073e0ef160b1a21fdb8648bde2929b284d6f787','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c059779b5095ef7f8e6c43b46e07af1bf576dc08fa85b2464f0b627f23034e46',1999,'HR','Croatia','transportation',53,'Railways:
total: 1,021 km (electrified 795 km; operating as diesel or steam
until grids are repaired)
standard gauge: 1,021 km 1.435-m gauge (1995); note--some segments
still need repair and/or reconstruction
Highways:
total: 21,846 km
paved: 11,425 km
unpaved: 10,421 km (1996 est.)
note: roads need maintenance and repair
Waterways: NA km; large sections of Sava blocked by downed
bridges, silt, and debris
Pipelines: crude oil 174 km; natural gas 90 km (1992);
note--pipelines now disrupted
Ports and harbors: Bosanska Gradiska, Bosanski Brod, Bosanski
Samac, and Brcko (all inland waterway ports on the Sava none of
which are fully operational), Orasje
Merchant marine: none
Airports: 25 (1998 est.)
Airports--with paved runways:
total: 9
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 16
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 8 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 971 km
narrow gauge: 971 km 1.067-m gauge (1995)
Highways:
total: 18,482 km
paved: 4,343 km
unpaved: 14,139 km (1996 est.)
Ports and harbors: none
Airports: 92 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 80
1,524 to 2,437 m: 2
914 to 1,523 m: 57
under 914 m: 21 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 28,862 km (1,187 km electrified)
broad gauge: 4,123 km 1.600-m gauge
narrow gauge: 24,390 km 1.000-m gauge; 13 km 0.760-m gauge
dual gauge: 336 km 1.000-m and 1.600-m gauges (three rails)
Highways:
total: 1.98 million km
paved: 184,140 km
unpaved: 1,795,860 km (1996 est.)
Waterways: 50,000 km navigable
Pipelines: crude oil 2,980 km; petroleum products 4,762 km;
natural gas 4,246 km (1998)
Ports and harbors: Belem, Fortaleza, Ilheus, Imbituba, Manaus,
Paranagua, Porto Alegre, Recife, Rio de Janeiro, Rio Grande,
Salvador, Santos, Vitoria
Merchant marine:
total: 179 ships (1,000 GRT or over) totaling 4,132,037
GRT/6,642,442 DWT
ships by type: bulk 35, cargo 28, chemical tanker 6, combination
ore/oil 10, container 10, liquefied gas tanker 10, multifunction
large-load carrier 1, oil tanker 61, passenger-cargo 5, refrigerated
cargo 1, roll-on/roll-off cargo 11, short-sea passenger 1 (1998 est.)
Airports: 3,265 (1998 est.)
Airports--with paved runways:
total: 514
over 3,047 m: 5
2,438 to 3,047 m: 19
1,524 to 2,437 m: 134
914 to 1,523 m: 325
under 914 m: 31 (1998 est.)
Airports--with unpaved runways:
total: 2,751
1,524 to 2,437 m: 73
914 to 1,523 m: 1,312
under 914 m: 1,366 (1998 est.)
Highways:
total: NA km
paved: short stretch of paved road of NA km between port and
airfield on Diego Garcia
unpaved: NA km
Ports and harbors: Diego Garcia
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)','58def677cdbe3736ae854fbd149d0043d9fffa8b664d52cf6d65b5b9088e9ca1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cbb607b3ff0e9b6cea7ac950d0bb9639ac42f5f62104b2cf18f46c35f25306e',1999,'PR','Puerto Rico','transportation',62,'Railways: 0 km
Highways:
total: 113 km (1995 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Road Town
Merchant marine: none
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 269 km
paved: 203 km
unpaved: 66 km (1995)
Ports and harbors: Plymouth (abandoned), Little Bay (anchorages
and ferry landing), Carr''s Bay
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 1,907 km
standard gauge: 1,907 km 1.435-m gauge (1,003 km electrified; 246 km
double track) (1994)
Highways:
total: 60,626 km
paved: 30,556 km (including 219 km of expressways)
unpaved: 30,070 km (1996 est.)
Pipelines: crude oil 362 km; petroleum products 491 km
(abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca, El Jorf Lasfar,
Kenitra, Mohammedia, Nador, Rabat, Safi, Tangier; also
Spanish-controlled Ceuta and Melilla
Merchant marine:
total: 40 ships (1,000 GRT or over) totaling 217,869 GRT/263,033 DWT
ships by type: cargo 8, chemical tanker 6, container 3, oil tanker
3, passenger 1, refrigerated cargo 10, roll-on/roll-off cargo 8,
short-sea passenger 1 (1998 est.)
Airports: 69 (1998 est.)
Airports--with paved runways:
total: 26
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 43
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 21
under 914 m: 11 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 3,131 km
narrow gauge: 2,988 km 1.067-m gauge; 143 km 0.762-m gauge (1994)
Highways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (1996 est.)
Waterways: about 3,750 km of navigable routes
Pipelines: crude oil 306 km; petroleum products 289 km
note: not operating
Ports and harbors: Beira, Inhambane, Maputo, Nacala, Pemba,
Quelimane
Merchant marine:
total: 3 cargo ships (1,000 GRT or over) totaling 4,125 GRT/7,024
DWT (1998 est.)
Airports: 174 (1998 est.)
Airports--with paved runways:
total: 22
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 152
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1,523 m: 39
under 914 m: 96 (1998 est.)
Railways:
total: 2,382 km
narrow gauge: 2,382 km 1.067-m gauge; single track (1995)
Highways:
total: 64,799 km
paved: 7,841 km
unpaved: 56,958 km (1996 est.)
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none
Airports: 135 (1998 est.)
Airports--with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 113
2,438 to 3,047 m: 2
1,524 to 2,437 m: 20
914 to 1,523 m: 70
under 914 m: 21 (1998 est.)
Railways:
total: 3.9 km; note--used to haul phosphates from the center of the
island to processing facilities on the southwest coast
Highways:
total: 30 km
paved: 24 km
unpaved: 6 km (1996 est.)
Ports and harbors: Nauru
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 101 km; note--all in Kosi close to Indian border
narrow gauge: 101 km 0.762-m gauge
Highways:
total: 7,700 km
paved: 3,196 km
unpaved: 4,504 km (1996 est.)
Ports and harbors: none
Airports: 45 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 40
1,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 29 (1998 est.)
Railways:
total: 2,813 km
standard gauge: 2,813 km 1.435-m gauge; (1,991 km electrified) (1996)
Highways:
total: 127,000 km
paved: 114,427 km (including 2,360 km of expressways)
unpaved: 12,573 km (1996 est.)
Waterways: 5,046 km, of which 47% is usable by craft of 1,000
metric ton capacity or larger
Pipelines: crude oil 418 km; petroleum products 965 km; natural
gas 10,230 km
Ports and harbors: Amsterdam, Delfzijl, Dordrecht, Eemshaven,
Groningen, Haarlem, Ijmuiden, Maastricht, Rotterdam, Terneuzen,
Utrecht
Merchant marine:
total: 510 ships (1,000 GRT or over) totaling 3,632,477
GRT/4,097,328 DWT
ships by type: bulk 4, cargo 303, chemical tanker 42, combination
bulk 1, container 52, liquefied gas tanker 17, livestock carrier 1,
multifunction large-load carrier 9, oil tanker 24, passenger 8,
refrigerated cargo 30, roll-on/roll-off cargo 12, short-sea
passenger 3, specialized tanker 4
note: many Dutch-owned ships are also operating under the registry
of Netherlands Antilles (1998 est.)
Airports: 28 (1998 est.)
Airports--with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 9
914 to 1,523 m: 3
under 914 m: 6 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 600 km
paved: 300 km
unpaved: 300 km (1992 est.)
Ports and harbors: Kralendijk, Philipsburg, Willemstad
Merchant marine:
total: 95 ships (1,000 GRT or over) totaling 811,782 GRT/1,045,989
DWT
ships by type: bulk 2, cargo 26, chemical tanker 2, combination
ore/oil 3, container 10, liquefied gas tanker 4, multifunction
large-load carrier 19, oil tanker 4, passenger 1, refrigerated cargo
18, roll-on/roll-off cargo 6
note: a flag of convenience registry; includes ships of 2 countries:
Belgium owns 9 ships, Germany 1 (1998 est.)
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Railways:
total: 240,000 km mainline routes (nongovernment owned)
standard gauge: 240,000 km 1.435-m gauge (1989)
Highways:
total: 6.42 million km
paved: 3,903,360 km (including 88,400 km of expressways)
unpaved: 2,516,640 km (1996 est.)
Waterways: 41,009 km of navigable inland channels, exclusive of
the Great Lakes
Pipelines: petroleum products 276,000 km; natural gas 331,000 km
(1991)
Ports and harbors: Anchorage, Baltimore, Boston, Charleston,
Chicago, Duluth, Hampton Roads, Honolulu, Houston, Jacksonville, Los
Angeles, New Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco, Savannah, Seattle,
Tampa, Toledo
Merchant marine:
total: 385 ships (1,000 GRT or over) totaling 11,123,848
GRT/15,255,996 DWT
ships by type: barge carrier 10, bulk 61, cargo 28, chemical tanker
13, combination bulk 2, container 83, liquefied gas tanker 9,
multifunctional large-load carrier 3, oil tanker 114, passenger 7,
passenger-cargo 1, roll-on/roll-off cargo 43, short-sea passenger 3,
specialized tanker 1, vehicle carrier 7 (1998 est.)
Airports: 14,459 (1998 est.)
Airports--with paved runways:
total: 5,167
over 3,047 m: 180
2,438 to 3,047 m: 219
1,524 to 2,437 m: 1,294
914 to 1,523 m: 2,447
under 914 m: 1,027 (1998 est.)
Airports--with unpaved runways:
total: 9,292
over 3,047 m: 1
2,438 to 3,047 m: 6
1,524 to 2,437 m: 156
914 to 1,523 m: 1,647
under 914 m: 7,482 (1998 est.)
Heliports: 122 (1998 est.)','4c5346254ccf29346bc5fad6c59f3ea680694e2e203ae96c4512595cbe718b1f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d1d76ce6044da8c980ad3c85a694d4183a921a1d03b6df455242b37575883b1',1999,'MY','Malaysia','transportation',73,'Railways:
total: 13 km (private line)
narrow gauge: 13 km 0.610-m gauge
Highways:
total: 1,150 km
paved: 399 km
unpaved: 751 km (1996 est.)
Waterways: 209 km; navigable by craft drawing less than 1.2 m
Pipelines: crude oil 135 km; petroleum products 418 km; natural
gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala Belait, Muara,
Seria, Tutong
Merchant marine:
total: 7 liquefied gas tankers (1,000 GRT or over) totaling 348,476
GRT/340,635 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 4,292 km
standard gauge: 4,047 km 1.435-m gauge (2,650 km electrified; 917 km
double track)
narrow gauge: 245 km 0.760-m gauge (1995)
Highways:
total: 36,724 km
paved: 33,786 km (including 314 km of expressways)
unpaved: 2,938 km (1997 est.)
Waterways: 470 km (1987)
Pipelines: crude oil 193 km; petroleum products 525 km; natural
gas 1,400 km (1992)
Ports and harbors: Burgas, Lom, Nesebur, Ruse, Varna, Vidin
Merchant marine:
total: 89 ships (1,000 GRT or over) totaling 1,005,092 GRT/1,508,614
DWT
ships by type: bulk 44, cargo 20, chemical tanker 4, container 2,
oil tanker 8, passenger-cargo 1, railcar carrier 2, refrigerated
cargo 1, roll-on/roll-off cargo 6, short-sea passenger 1 (1998 est.)
Airports: 61 (1998 est.)
Airports--with paved runways:
total: 56
over 3,047 m: 1
2,438 to 3,047 m: 19
1,524 to 2,437 m: 11
under 914 m: 25 (1998 est.)
Airports--with unpaved runways:
total: 5
914 to 1,523 m: 1
under 914 m: 4 (1998 est.)
Railways:
total: 622 km (517 km from Ouagadougou to the Cote d''Ivoire border
and 105 km from Ouagadougou to Kaya)
narrow gauge: 622 km 1.000-m gauge (1995 est.)
Highways:
total: 12,506 km
paved: 2,001 km
unpaved: 10,505 km (1995 est.)
Ports and harbors: none
Airports: 33 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 31
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 16 (1998 est.)
Railways:
total: 3,740 km
narrow gauge: 3,740 km 1.000-m gauge (1997)
Highways:
total: 28,200 km
paved: 3,440 km
unpaved: 24,760 km (1996 est.)
Waterways: 12,800 km; 3,200 km navigable by large commercial
vessels
Pipelines: crude oil 1,343 km; natural gas 330 km
Ports and harbors: Bassein, Bhamo, Chauk, Mandalay, Moulmein,
Myitkyina, Rangoon, Akyab (Sittwe), Tavoy
Merchant marine:
total: 41 ships (1,000 GRT or over) totaling 464,478 GRT/695,923 DWT
ships by type: bulk 14, cargo 20, container 2, oil tanker 3,
passenger-cargo 2
note: a flag of convenience registry; includes ships of 2 countries:
Japan owns 2 ships, US 3 (1998 est.)
Airports: 80 (1998 est.)
Airports--with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 69
over 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 23
under 914 m: 32 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 14,480 km
paved: 1,028 km
unpaved: 13,452 km (1996 est.)
Waterways: Lake Tanganyika
Ports and harbors: Bujumbura
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Railways:
total: 603 km
narrow gauge: 603 km 1.000-m gauge
Highways:
total: 35,769 km
paved: 4,165 km
unpaved: 31,604 km (1997 est.)
Waterways: 3,700 km navigable all year to craft drawing 0.6 m;
282 km navigable to craft drawing 1.8 m
Ports and harbors: Kampong Saom (Sihanoukville), Kampot, Krong
Kaoh Kong, Phnom Penh
Merchant marine:
total: 141 ships (1,000 GRT or over) totaling 598,867 GRT/841,240 DWT
ships by type: barge carrier 1, bulk 16, cargo 108, container 4,
livestock carrier 2, multifunctional large-load carrier 1, oil
tankers 1, refrigerated cargo 4, roll-on/roll-off cargo 4
note: a flag of convenience registry; includes ships of 8 countries:
Aruba 1, Cyprus 7, Egypt 1, South Korea 1, Malta 1, Panama 1, Russia
5, Singapore 1 (1998 est.)
Airports: 20 (1998 est.)
Airports--with paved runways:
total: 7
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 13
1,524 to 2,437 m: 3
914 to 1,523 m: 10 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 1,104 km
narrow gauge: 1,104 km 1.000-m gauge (1995 est.)
Highways:
total: 34,300 km
paved: 4,288 km
unpaved: 30,012 km (1995 est.)
Waterways: 2,090 km; of decreasing importance
Ports and harbors: Bonaberi, Douala, Garoua, Kribi, Tiko
Airports: 52 (1998 est.)
Airports--with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 41
1,524 to 2,437 m: 8
914 to 1,523 m: 21
under 914 m: 12 (1998 est.)
Railways:
total: 67,773 km; note--there are two major transcontinental freight
railway systems: Canadian National (privatized November 1995) and
Canadian Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage of its own
standard gauge: 67,773 km 1.435-m gauge (183 km electrified) (1996)
Highways:
total: 912,200 km
paved: 246,400 km (including 16,600 km of expressways)
unpaved: 665,800 km (1996 est.)
Waterways: 3,000 km, including Saint Lawrence Seaway
Pipelines: crude and refined oil 23,564 km; natural gas 74,980 km
Ports and harbors: Becancour (Quebec), Churchill, Halifax,
Hamilton, Montreal, New Westminster, Prince Rupert, Quebec, Saint
John (New Brunswick), St. John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver, Windsor
Merchant marine:
total: 109 ships (1,000 GRT or over) totaling 1,489,110
GRT/2,205,274 DWT
ships by type: barge carrier 1, bulk 56, cargo 11, chemical tanker
5, combination bulk 2, oil tanker 16, passenger 3, passenger-cargo
1, railcar carrier 2, roll-on/roll-off cargo 7, short-sea passenger
4, specialized tanker 1
note: does not include ships used exclusively in the Great Lakes
(1998 est.)
Airports: 1,395 (1998 est.)
Airports--with paved runways:
total: 515
over 3,047 m: 16
2,438 to 3,047 m: 16
1,524 to 2,437 m: 154
914 to 1,523 m: 238
under 914 m: 91 (1998 est.)
Airports--with unpaved runways:
total: 880
1,524 to 2,437 m: 73
914 to 1,523 m: 353
under 914 m: 454 (1998 est.)
Heliports: 16 (1998 est.)
Railways: 0 km
Highways:
total: 1,100 km
paved: 858 km
unpaved: 242 km (1996 est.)
Ports and harbors: Mindelo, Praia, Tarrafal
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 9,620 GRT/13,920 DWT
ships by type: cargo 3, chemical tanker 1 (1998 est.)
Airports: 6 (1998 est.)
Airports--with paved runways:
total: 6
over 3,047 m: 1
914 to 1,523 m: 5 (1998 est.)
Railways: 0 km
Highways:
total: 406 km
paved: 304 km
unpaved: 102 km
Ports and harbors: Cayman Brac, George Town
Merchant marine:
total: 76 ships (1,000 GRT or over) totaling 1,264,113 GRT/1,970,959
DWT
ships by type: bulk 13, cargo 10, chemical tanker 11, container 4,
liquefied gas tanker 1, oil tanker 7, refrigerated cargo 22,
roll-on/roll-off cargo 6, specialized tanker 1, vehicle carrier 1
note: a flag of convenience registry; includes ships from 11
countries among which are: Greece 15, US 5, UK 5, Cyprus 2, Denmark
2, Norway 3 (1998 est.)
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1996 est.)
Waterways: 10,940 km
Ports and harbors: Kieta, Lae, Madang, Port Moresby, Rabaul
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 35,400 GRT/50,869 DWT
ships by type: bulk 2, cargo 6, chemical tanker 1, combination
ore/oil 5, container 1, oil tanker 2, roll-on/roll-off 3 (1998 est.)
Airports: 492 (1998 est.)
Airports--with paved runways:
total: 19
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 473
1,524 to 2,437 m: 13
914 to 1,523 m: 60
under 914 m: 400 (1998 est.)
Heliports: 2 (1998 est.)
Ports and harbors: small Chinese port facilities on Woody Island
and Duncan Island being expanded
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)','e704ebfd6313c8ec856e7c6e3fbf1c48e10bc5613c75485103c905c4feb6f1ac','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('904048b4975123ec12c7407a355c956081f79142d66c0d3a785f921ce3785854',1999,'CG','Congo','transportation',85,'Railways: 0 km
Highways:
total: 23,810 km
paved: 429 km
unpaved: 23,381 km (1995 est.)
Waterways: 800 km; traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important river
Ports and harbors: Bangui, Nola
Airports: 52 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 49
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 15 (1998 est.)
Railways: 0 km
Highways:
total: 33,400 km
paved: 267 km
unpaved: 33,133 km (1996 est.)
Waterways: 2,000 km navigable
Ports and harbors: none
Airports: 52 (1998 est.)
Airports--with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 44
1,524 to 2,437 m: 12
914 to 1,523 m: 22
under 914 m: 10 (1998 est.)
Railways:
total: 6,782 km
broad gauge: 3,743 km 1.676-m gauge (1,653 km electrified)
narrow gauge: 116 km 1.067-m gauge; 2,923 km 1.000-m gauge (40 km
electrified) (1995)
Highways:
total: 79,800 km
paved: 11,012 km
unpaved: 68,788 km (1996 est.)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785 km; natural
gas 320 km
Ports and harbors: Antofagasta, Arica, Chanaral, Coquimbo,
Iquique, Puerto Montt, Punta Arenas, San Antonio, San Vicente,
Talcahuano, Valparaiso
Merchant marine:
total: 42 ships (1,000 GRT or over) totaling 527,201 GRT/787,719 DWT
ships by type: bulk 11, cargo 10, chemical tanker 5, container 2,
liquefied gas tanker 1, oil tanker 4, passenger 3, roll-on/roll-off
cargo 4, vehicle carrier 2 (1998 est.)
Airports: 378 (1998 est.)
Airports--with paved runways:
total: 58
over 3,047 m: 5
2,438 to 3,047 m: 6
1,524 to 2,437 m: 19
914 to 1,523 m: 19
under 914 m: 9 (1998 est.)
Airports--with unpaved runways:
total: 320
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 13
914 to 1,523 m: 73
under 914 m: 229 (1998 est.)
Railways: 0 km
Highways:
total: NA km (Saint Helena 118 km, Ascension NA km, Tristan da Cunha
NA km)
paved: 180.7 km (Saint Helena 98 km, Ascension 80 km, Tristan da
Cunha 2.70 km)
unpaved: NA km (Saint Helena 20 km, Ascension NA km, Tristan da
Cunha NA km)
Ports and harbors: Georgetown (on Ascension), Jamestown
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to serve sugarcane
plantations (1995)
Highways:
total: 320 km
paved: 136 km
unpaved: 184 km (1996 est.)
Ports and harbors: Basseterre, Charlestown
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 1,210 km
paved: 63 km
unpaved: 1,147 km (1996 est.)
Ports and harbors: Castries, Vieux Fort
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 23,350 km
broad gauge: 23,350 km 1.524-m gauge (8,600 km electrified)
Highways:
total: 172,565 km
paved: 163,937 km (including 1,875 km of expressways); note--these
roads are said to be hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced
unpaved: 8,628 km (1996 est.)
Waterways: 4,400 km navigable waterways, of which 1,672 km were
on the Pryp''''yat'' and Dnistr (1990)
Pipelines: crude oil 4,000 km (1995); petroleum products 4,500 km
(1995); natural gas 34,400 km (1998)
Ports and harbors: Berdyans''k, Illichivs''k, Izmayil, Kerch,
Kherson, Kiev (Kyyiv), Mariupol'', Mykolayiv, Odesa, Reni
Merchant marine:
total: 181 ships (1,000 GRT or over) totaling 1,022,047
GRT/1,101,278 DWT
ships by type: bulk 9, cargo 117, liquefied gas tanker 1, container
4, multifunction large-load carrier 2, oil tanker 16, passenger 12,
passenger-cargo 3, railcar carrier 2, refrigerated cargo 2,
roll-on/roll-off cargo 10, short-sea passenger 3 (1998 est.)
Airports: 706 (1994 est.)
Airports--with paved runways:
total: 163
over 3,047 m: 14
2,438 to 3,047 m: 55
1,524 to 2,437 m: 34
914 to 1,523 m: 3
under 914 m: 57 (1994 est.)
Airports--with unpaved runways:
total: 543
over 3,047 m: 7
2,438 to 3,047 m: 7
1,524 to 2,437 m: 16
914 to 1,523 m: 37
under 914 m: 476 (1994 est.)
Railways: 0 km
Highways:
total: 4,835 km
paved: 4,835 km
unpaved: 0 km (1996 est.)
Pipelines: crude oil 830 km; natural gas, including natural gas
liquids, 870 km
Ports and harbors: ''Ajman, Al Fujayrah, Das Island, Khawr Fakkan,
Mina'' Jabal ''Ali, Mina'' Khalid, Mina'' Rashid, Mina'' Saqr, Mina''
Zayid, Umm al Qaywayn
Merchant marine:
total: 74 ships (1,000 GRT or over) totaling 1,093,795 GRT/1,757,189
DWT
ships by type: bulk 4, cargo 20, chemical tanker 4, container 8,
liquefied gas tanker 1, livestock carrier 1, oil tanker 28,
refrigerated cargo 1, roll-on/roll-off cargo 7 (1998 est.)
Airports: 41 (1998 est.)
Airports--with paved runways:
total: 21
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 20
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 5 (1998 est.)
Heliports: 2 (1998 est.)','76ede6d7321e361c75a045f4e9322b30c66ac533fd415d542cab6b41020772e3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f896925ffd941da563515e2109a46d39cca3f1fe5c8bf9d356d20aae432e3d4',1999,'DE','Germany','transportation',90,'Railways:
total: 64,900 km (including 5,400 km of provincial "local" rails)
standard gauge: 61,300 km 1.435-m gauge (12,000 km electrified;
20,000 km double track)
narrow gauge: 3,600 km 0.750-m gauge local industrial lines (1998
est.)
note: a new total of 68,000 km has been estimated for early 1999
Highways:
total: 1.21 million km
paved: 271,300 km (with at least 24,474 km of motorways)
unpaved: 938,700 km (1998 est.)
Waterways: 109,800 km navigable (1997)
Pipelines: crude oil 9,070 km; petroleum products 560 km; natural
gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou, Haikou, Huangpu,
Lianyungang, Nanjing, Nantong, Ningbo, Qingdao, Qinhuangdao,
Shanghai, Shantou, Tianjin, Xiamen, Xingang, Yantai, Zhanjiang
Merchant marine:
total: 1,759 ships (1,000 GRT or over) totaling 16,828,349
GRT/24,801,291 DWT
ships by type: barge carrier 2, bulk 330, cargo 855, chemical tanker
21, combination bulk 10, combination ore/oil 1, container 121,
liquefied gas tanker 20, multifunction large-load carrier 6, oil
tanker 245, passenger 8, passenger-cargo 47, refrigerated cargo 25,
roll-on/roll-off cargo 24, short-sea passenger 43, vehicle carrier 1
(1998 est.)
Airports: 206 (1996 est.)
Airports--with paved runways:
total: 192
over 3,047 m: 18
2,438 to 3,047 m: 65
1,524 to 2,437 m: 90
914 to 1,523 m: 13
under 914 m: 6 (1996 est.)
Airports--with unpaved runways:
total: 14
1,524 to 2,437 m: 8
914 to 1,523 m: 5
under 914 m: 1 (1996 est.)','2ca5685960b5e7d49a53e4817e73e10bc5b2593afcde109e76e46f9690534753','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f998382b84796cc5be772e6c3d44b2d612254464bafe8c6bdbe1048697211d37',1999,'AU','Australia','transportation',109,'Railways: 24 km to serve phosphate mines
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Flying Fish Cove
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; lagoon anchorage only
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 3,380 km
standard gauge: 150 km 1.435-m gauge (connects Cerrejon coal mines
to maritime port at Bahia de Portete)
narrow gauge: 3,230 km 0.914-m gauge (1,830 km in use) (1995)
Highways:
total: 115,564 km
paved: 13,868 km
unpaved: 101,696 km (1997 est.)
Waterways: 14,300 km, navigable by river boats
Pipelines: crude oil 3,585 km; petroleum products 1,350 km;
natural gas 830 km; natural gas liquids 125 km
Ports and harbors: Bahia de Portete, Barranquilla, Buenaventura,
Cartagena, Leticia, Puerto Bolivar, San Andres, Santa Marta, Tumaco,
Turbo
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 64,7575 GRT/84,518 DWT
ships by type: bulk 4, cargo 5, container 1, multifunction
large-load carrier 2, oil tanker 2 (1998 est.)
Airports: 1,120 (1998 est.)
Airports--with paved runways:
total: 89
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 36
914 to 1,523 m: 35
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 1,031
2,438 to 3,047 m: 1
1,524 to 2,437 m: 63
914 to 1,523 m: 339
under 914 m: 628 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 950 km
narrow gauge: 950 km 1.067-m gauge (260 km electrified)
Highways:
total: 35,597 km
paved: 6,051 km
unpaved: 29,546 km (1997 est.)
Waterways: about 730 km, seasonally navigable
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto Limon, Puerto
Quepos, Puntarenas
Merchant marine: none
Airports: 156 (1998 est.)
Airports--with paved runways:
total: 28
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 18
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 128
914 to 1,523 m: 29
under 914 m: 99 (1998 est.)
Railways:
total: 660 km
narrow gauge: 660 km 1.000-meter gauge; 25 km double track (1995
est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,511 km (1996 est.)
Waterways: 980 km navigable rivers, canals, and numerous coastal
lagoons
Ports and harbors: Abidjan, Aboisso, Dabou, San-Pedro
Merchant marine:
total: 1 oil tanker (1,000 GRT or over) totaling 1,200 GRT/1,500 DWT
(1998 est.)
Airports: 36 (1998 est.)
Airports--with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 29
1,524 to 2,437 m: 8
914 to 1,523 m: 12
under 914 m: 9 (1998 est.)
Railways:
total: 2,296 km
standard gauge: 2,296 km 1.435-m gauge (796 km electrified)
note: some lines remain inoperative or not in use; disrupted by
territorial dispute (1997)
Highways:
total: 27,840 km
paved: 22,690 km (including 330 km of expressways)
unpaved: 5,150 km (1997 est.)
Waterways: 785 km perennially navigable; large sections of Sava
blocked by downed bridges, silt, and debris
Pipelines: crude oil 670 km; petroleum products 20 km; natural
gas 310 km (1992); note--under repair following territorial dispute
Ports and harbors: Dubrovnik, Dugi Rat, Omisalj, Ploce, Pula,
Rijeka, Sibenik, Split, Vukovar (inland waterway port on Danube),
Zadar
Merchant marine:
total: 64 ships (1,000 GRT or over) totaling 810,226 GRT/1,227,468
DWT
ships by type: bulk 15, cargo 26, chemical tanker 2, combination
bulk 5, container 5, liquefied gas 1, multifunction large-load
carrier 3, oil tanker 1, passenger 1, roll-on/roll-off cargo 2,
short-sea passenger 3 (1998 est.)
Airports: 72 (1998 est.)
Airports--with paved runways:
total: 21
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 51
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 42 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 4,807 km
standard gauge: 4,807 km 1.435-m gauge (147 km electrified)
note: a large amount of track is in private use by sugar plantations
Highways:
total: 60,858 km
paved: 29,820 km (including 638 km of expressway)
unpaved: 31,038 km (1997 est.)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana, Manzanillo, Mariel,
Matanzas, Nuevitas, Santiago de Cuba
Merchant marine:
total: 18 ships (1,000 GRT or over) totaling 89,091 GRT/125,463 DWT
ships by type: bulk 1, cargo 9, liquefied gas tanker 1, oil tanker
2, refrigerated cargo 5 (1998 est.)
Airports: 170 (1998 est.)
Airports--with paved runways:
total: 77
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 36 (1998 est.)
Airports--with unpaved runways:
total: 93
914 to 1,523 m: 32
under 914 m: 61 (1998 est.)
Railways: 0 km
Highways:
total: Greek Cypriot area: 10,415 km; Turkish Cypriot area: 2,350 km
paved: Greek Cypriot area: 5,947 km; Turkish Cypriot area: 1,370 km
unpaved: Greek Cypriot area: 4,468 km; Turkish Cypriot area: 980 km
(1996 est.)
Ports and harbors: Famagusta, Kyrenia, Larnaca, Limassol, Paphos,
Vasilikos Bay
Merchant marine:
total: 1,469 ships (1,000 GRT or over) totaling 23,362,067
GRT/36,945,331 DWT
ships by type: barge carrier 2, bulk 430, cargo 530, chemical tanker
23, combination bulk 42, combination ore/oil 11, container 141,
liquefied gas tanker 6, oil tanker 152, passenger 7, refrigerated
cargo 58, roll-on/roll-off cargo 49, short-sea passenger 14,
specialized tanker 3, vehicle carrier 1
note: a flag of convenience registry; includes ships from 37
countries among which are Greece 611, Germany 129, Russia 49, Latvia
278, Netherlands 20, Japan 28, Cuba 16, China 15, Hong Kong 13, and
Poland 15 (1998 est.)
Airports: 15 (1998 est.)
Airports--with paved runways:
total: 12
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 9,440 km
standard gauge: 9,344 km 1.435-m standard gauge (2,743 km
electrified at three voltages; 1,885 km double track)
narrow gauge: 96 km 0.760-m narrow gauge (1996)
Highways:
total: 55,489 km
paved: 55,489 km (including 423 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: NA km; the Elbe (Labe) is the principal river
Pipelines: natural gas 5,400 km
Ports and harbors: Decin, Prague, Usti nad Labem
Airports: 69 (1998 est.)
Airports--with paved runways:
total: 35
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 11
914 to 1,523 m: 1
under 914 m: 13 (1998 est.)
Airports--with unpaved runways:
total: 34
914 to 1,523 m: 17
under 914 m: 17 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 3,323 km (458 km privately owned and operated)
standard gauge: 3,323 km 1.435-m gauge (440 km electrified; 760 km
double track) (1996)
Highways:
total: 71,600 km
paved: 71,600 km (including 880 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 417 km
Pipelines: crude oil 110 km; petroleum products 578 km; natural
gas 700 km
Ports and harbors: Alborg, Arhus, Copenhagen, Esbjerg,
Fredericia, Grena, Koge, Odense, Struer
Merchant marine:
total: 337 ships (1,000 GRT or over) totaling 5,130,643
GRT/6,880,248 DWT
ships by type: bulk 14, cargo 130, chemical tanker 19, container 73,
liquefied gas tanker 26, livestock carrier 6, oil tanker 20, railcar
carrier 1, refrigerated cargo 15, roll-on/roll-off cargo 21,
short-sea passenger 9, specialized tanker 3
note: Denmark has created its own internal register, called the
Danish International Ship register (DIS); DIS ships do not have to
meet Danish manning regulations, and they amount to a flag of
convenience within the Danish register (1998 est.)
Airports: 118 (1998 est.)
Airports--with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 90
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 82 (1998 est.)
Railways:
total: 97 km (Djibouti segment of the Addis Ababa-Djibouti railroad)
narrow gauge: 97 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced plans to
revitalize the century-old railroad that links their capitals
Highways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1996 est.)
Ports and harbors: Djibouti
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,369 GRT/3,030 DWT
(1998 est.)
Airports: 11 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 9
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 2 (1998 est.)
Ports and harbors: Calcutta (India), Chennai (Madras; India),
Colombo (Sri Lanka), Durban (South Africa), Jakarta (Indonesia),
Melbourne (Australia), Mumbai (Bombay; India), Richards Bay (South
Africa)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (101 km electrified; 101 km
double track); 497 km 0.750-m gauge (1995)
Highways:
total: 342,700 km
paved: 158,670 km
unpaved: 184,030 km (1997 est.)
Waterways: 21,579 km total; Sumatra 5,471 km, Java and Madura 820
km, Kalimantan 10,460 km, Sulawesi (Celebes) 241 km, Irian Jaya
4,587 km
Pipelines: crude oil 2,505 km; petroleum products 456 km; natural
gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta, Kupang, Palembang,
Semarang, Surabaya, Ujungpandang
Merchant marine:
total: 587 ships (1,000 GRT or over) totaling 2,707,004
GRT/3,701,001 DWT
ships by type: bulk 37, cargo 348, chemical tanker 8, container 20,
liquefied gas tanker 5, livestock carrier 1, oil tanker 116,
passenger 9, passenger-cargo 13, roll-on/roll-off cargo 11,
short-sea passenger 7, specialized tanker 7, vehicle carrier 5 (1998
est.)
Airports: 443 (1998 est.)
Airports--with paved runways:
total: 125
over 3,047 m: 4
2,438 to 3,047 m: 11
1,524 to 2,437 m: 41
914 to 1,523 m: 39
under 914 m: 30 (1998 est.)
Airports--with unpaved runways:
total: 318
1,524 to 2,437 m: 5
914 to 1,523 m: 31
under 914 m: 282 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 7,286 km
broad gauge: 94 km 1.676-m gauge
standard gauge: 7,192 km 1.435-m gauge (146 km electrified) (1996
est.)
Highways:
total: 162,000 km
paved: 81,000 km (including 470 km of expressways)
unpaved: 81,000 km (1996 est.)
Waterways: 904 km; the Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been dredged to 3 m
and is in use
Pipelines: crude oil 5,900 km; petroleum products 3,900 km;
natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in fighting during
1980-88 war), Ahvaz, Bandar ''Abbas, Bandar-e Anzali, Bushehr,
Bandar-e Imam Khomeyni, Bandar-e Lengeh, Bandar-e Mahshahr, Bandar-e
Torkaman, Chabahar (Bandar Beheshti), Jazireh-ye Khark, Jazireh-ye
Lavan, Jazireh-ye Sirri, Khorramshahr (limited operation since
November 1992), Now Shahr
Merchant marine:
total: 132 ships (1,000 GRT or over) totaling 3,238,293
GRT/5,658,259 DWT
ships by type: bulk 46, cargo 35, chemical tanker 4, combination
bulk 1, container 5, liquefied gas tanker 1, multifunction
large-load carrier 6, oil tanker 21, refrigerated cargo 2,
roll-on/roll-off cargo 10, short-sea passenger 1 (1998 est.)
Airports: 288 (1998 est.)
Airports--with paved runways:
total: 110
over 3,047 m: 38
2,438 to 3,047 m: 18
1,524 to 2,437 m: 25
914 to 1,523 m: 23
under 914 m: 6 (1998 est.)
Airports--with unpaved runways:
total: 178
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 126
under 914 m: 32 (1998 est.)
Heliports: 11 (1998 est.)
Railways:
total: 2,032 km
standard gauge: 2,032 km 1.435-m gauge
Highways:
total: 47,400 km
paved: 40,764 km
unpaved: 6,636 km (1996 est.)
Waterways: 1,015 km; Shatt al Arab is usually navigable by
maritime traffic for about 130 km; channel has been dredged to 3
meters and is in use; Tigris and Euphrates Rivers have navigable
sections for shallow-draft watercraft; Shatt al Basrah canal was
navigable by shallow-draft craft before closing in 1991 because of
the Persian Gulf war
Pipelines: crude oil 4,350 km; petroleum products 725 km; natural
gas 1,360 km
Ports and harbors: Umm Qasr, Khawr az Zubayr, and Al Basrah have
limited functionality
Merchant marine:
total: 30 ships (1,000 GRT or over) totaling 456,845 GRT/780,318 DWT
ships by type: cargo 14, oil tanker 11, passenger 1, passenger-cargo
1, refrigerated cargo 1, roll-on/roll-off cargo 2 (1998 est.)
Airports: 109 (1998 est.)
Airports--with paved runways:
total: 77
over 3,047 m: 20
2,438 to 3,047 m: 36
1,524 to 2,437 m: 7
914 to 1,523 m: 7
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 32
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 10
under 914 m: 11 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 1,947 km
broad gauge: 1,947 km 1.600-m gauge (38 km electrified; 485 km
double track) (1996)
Highways:
total: 92,500 km
paved: 87,042 km (including 80 km of expressways)
unpaved: 5,458 km (1996 est.)
Waterways: limited for commercial traffic
Pipelines: natural gas 225 km
Ports and harbors: Arklow, Cork, Drogheda, Dublin, Foynes,
Galway, Limerick, New Ross, Waterford
Merchant marine:
total: 31 ships (1,000 GRT or over) totaling 79,284 GRT/117,652 DWT
ships by type: bulk 1, cargo 28, container 2 (1998 est.)
Airports: 44 (1998 est.)
Airports--with paved runways:
total: 16
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 28
914 to 1,523 m: 3
under 914 m: 25 (1998 est.)
Railways:
total: 610 km
standard gauge: 610 km 1.435-m gauge (1996)
Highways:
total: 15,464 km
paved: 15,464 km (including 56 km of expressways)
unpaved: 0 km (1997 est.)
Pipelines: crude oil 708 km; petroleum products 290 km; natural
gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat), Hadera, Haifa,
Tel Aviv-Yafo
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 736,419 GRT/855,497 DWT
ships by type: cargo 1, container 21, roll-on/roll-off cargo 1 (1998
est.)
Airports: 54 (1998 est.)
Airports--with paved runways:
total: 31
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 7 (1998 est.)
Airports--with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 18 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 19,272 km
standard gauge: 17,983 km 1.435-m gauge; Italian Railways (FS)
operates 15,942 km of the total standard gauge routes (10,889 km
electrified)
narrow gauge: 112 km 1.000-m gauge (112 km electrified); 1,177 km
0.950-m gauge (19 km electrified) (1996)
Highways:
total: 317,000 km
paved: 317,000 km (including 9,500 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 2,400 km for various types of commercial traffic,
although of limited overall value
Pipelines: crude oil 1,703 km; petroleum products 2,148 km;
natural gas 19,400 km
Ports and harbors: Augusta (Sicily), Bagnoli, Bari, Brindisi,
Gela, Genoa, La Spezia, Livorno, Milazzo, Naples, Porto Foxi, Porto
Torres (Sardinia), Salerno, Savona, Taranto, Trieste, Venice
Merchant marine:
total: 393 ships (1,000 GRT or over) totaling 5,982,870
GRT/8,413,850 DWT
ships by type: bulk 38, cargo 46, chemical tanker 60, combination
ore/oil 2, container 16, liquefied gas tanker 35, livestock carrier
1, multifunction large-load carrier 1, oil tanker 84, passenger 6,
roll-on/roll-off cargo 53, short-sea passenger 28, specialized
tanker 12, vehicle carrier 11 (1998 est.)
Airports: 136 (1998 est.)
Airports--with paved runways:
total: 97
over 3,047 m: 5
2,438 to 3,047 m: 33
1,524 to 2,437 m: 17
914 to 1,523 m: 30
under 914 m: 12 (1998 est.)
Airports--with unpaved runways:
total: 39
1,524 to 2,437 m: 2
914 to 1,523 m: 19
under 914 m: 18 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 370 km
standard gauge: 370 km 1.435-m gauge; note--207 km belong to the
Jamaica Railway Corporation in common carrier service, but are no
longer operational; the remaining track is privately owned and used
to transport bauxite
Highways:
total: 18,700 km
paved: 13,100 km
unpaved: 5,600 km (1997 est.)
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay, Kingston,
Montego Bay, Ocho Rios, Port Antonio, Rocky Point, Port Esquivel
(Longswharf)
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 3,478 GRT/5,878 DWT
ships by type: oil tanker 1, roll-on/roll-off cargo 1 (1998 est.)
Airports: 36 (1998 est.)
Airports--with paved runways:
total: 11
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 25
914 to 1,523 m: 2
under 914 m: 23 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 23,670.7 km
standard gauge: 2,893.1 km 1.435-m gauge (entirely electrified)
narrow gauge: 89.8 km 1.372-m gauge (89.8 km electrified); 20,656.8
km 1.067-m gauge (10,383.6 km electrified); 31 km 0.762-m gauge (3.6
km electrified) (1994)
Highways:
total: 1.16 million km
paved: 859,560 km (including 6,070 km of expressways)
unpaved: 300,440 km (1996 est.)
Waterways: about 1,770 km; seagoing craft ply all coastal inland
seas
Pipelines: crude oil 84 km; petroleum products 322 km; natural
gas 1,800 km
Ports and harbors: Akita, Amagasaki, Chiba, Hachinohe, Hakodate,
Higashi-Harima, Himeji, Hiroshima, Kawasaki, Kinuura, Kobe, Kushiro,
Mizushima, Moji, Nagoya, Osaka, Sakai, Sakaide, Shimizu, Tokyo,
Tomakomai
Merchant marine:
total: 713 ships (1,000 GRT or over) totaling 13,753,027
GRT/19,311,312 DWT
ships by type: bulk 159, cargo 54, chemical tanker 13, combination
bulk 16, combination ore/oil 4, container 27, liquefied gas tanker
40, oil tanker 232, passenger 10, passenger-cargo 2, refrigerated
cargo 27, roll-on/roll-off cargo 48, short-sea passenger 13, vehicle
carrier 68 (1998 est.)
Airports: 170 (1998 est.)
Airports--with paved runways:
total: 140
over 3,047 m: 5
2,438 to 3,047 m: 35
1,524 to 2,437 m: 39
914 to 1,523 m: 30
under 914 m: 31 (1998 est.)
Airports--with unpaved runways:
total: 30
914 to 1,523 m: 2
under 914 m: 28 (1998 est.)
Heliports: 14 (1998 est.)
Ports and harbors: none; offshore anchorage only; note--there is
one boat landing area in the middle of the west coast and another
near the southwest corner of the island
Transportation--note: there is a day beacon near the middle of the
west coast
Railways: 0 km
Highways:
total: 5,562 km
paved: 975 km
unpaved: 4,587 km (1993)
Ports and harbors: Mueo, Noumea, Thio
Merchant marine: none
Airports: 27 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 22
914 to 1,523 m: 11
under 914 m: 11 (1998 est.)
Heliports: 7 (1998 est.)
Railways:
total: 3,973 km
narrow gauge: 3,973 km 1.067-m gauge (519 km electrified)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of expressways)
unpaved: 38,632 km (1996 est.)
Waterways: 1,609 km; of little importance to transportation
Pipelines: petroleum products 160 km; natural gas 1,000 km;
liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch, Dunedin, Tauranga,
Wellington
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 138,687 GRT/183,372 DWT
ships by type: bulk 4, cargo 1, liquefied gas tanker 1, oil tanker
3, railcar carrier 1, roll-on/roll-off cargo 4 (1998 est.)
Airports: 111 (1998 est.)
Airports--with paved runways:
total: 44
over 3,047 m: 2
1,524 to 2,437 m: 10
914 to 1,523 m: 29
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 67
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 43 (1998 est.)
Highways:
total: 16,382 km
paved: 1,818 km
unpaved: 14,564 km (1998 est.)
Waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff, Puerto Cabezas,
Puerto Sandino, Rama, San Juan del Sur
Merchant marine: none
Airports: 184 (1998 est.)
Airports--with paved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 171
1,524 to 2,437 m: 1
914 to 1,523 m: 27
under 914 m: 143 (1998 est.)
Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km
Ports and harbors: none; loading jetties at Kingston and Cascade
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 362 km (1991 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 4,012 km
standard gauge: 4,012 km 1.435-m gauge (2,422 km electrified; 96 km
double track) (1996)
Highways:
total: 91,180 km
paved: 67,473 km (including 109 km of expressways)
unpaved: 23,707 km (1997 est.)
Waterways: 1,577 km along west coast; navigable by 2.4 m draft
vessels maximum
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Floro, Hammerfest, Harstad,
Haugesund, Kristiansand, Larvik, Narvik, Oslo, Porsgrunn, Stavanger,
Tromso, Trondheim
Merchant marine:
total: 788 ships (1,000 GRT or over) totaling 21,200,416
GRT/33,642,888 DWT
ships by type: bulk 106, cargo 150, chemical tanker 99, combination
bulk 8, combination ore/oil 39, container 19, liquefied gas tanker
86, multifunction large-load carrier 1, oil tanker 143, passenger
12, refrigerated cargo 15, roll-on/roll-off cargo 52, short-sea
passenger 22, vehicle carrier 36
note: the government has created an internal register, the Norwegian
International Ship register (NIS), as a subset of the Norwegian
register; ships on the NIS enjoy many benefits of flags of
convenience and do not have to be crewed by Norwegians (1998 est.)
Airports: 103 (1998 est.)
Airports--with paved runways:
total: 66
over 3,047 m: 1
2,438 to 3,047 m: 11
1,524 to 2,437 m: 14
914 to 1,523 m: 11
under 914 m: 29 (1998 est.)
Airports--with unpaved runways:
total: 37
914 to 1,523 m: 5
under 914 m: 32 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 32,800 km
paved: 9,840 km (including 550 km of expressways)
unpaved: 22,960 km (1996 est.)
Pipelines: crude oil 1,300 km; natural gas 1,030 km
Ports and harbors: Matrah, Mina'' al Fahl, Mina'' Raysut
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 16,306 GRT/8,210 DWT
ships by type: cargo 1, passenger 1, passenger-cargo 1 (1998 est.)
Airports: 143 (1998 est.)
Airports--with paved runways:
total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 137
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 58
914 to 1,523 m: 36
under 914 m: 35 (1998 est.)
Heliports: 1 (1998 est.)
Ports and harbors: Bangkok (Thailand), Hong Kong, Kao-hsiung
(Taiwan), Los Angeles (US), Manila (Philippines), Pusan (South
Korea), San Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia), Wellington
(NZ), Yokohama (Japan)
Railways:
total: 8,163 km
broad gauge: 7,718 km 1.676-m gauge (293 km electrified; 1,037 km
double track)
narrow gauge: 445 km 1.000-m gauge (1996 est.)
Highways:
total: 224,774 km
paved: 128,121 km
unpaved: 96,653 km (1996 est.)
Pipelines: crude oil 250 km; petroleum products 885 km; natural
gas 4,044 km (1987)
Ports and harbors: Karachi, Port Muhammad bin Qasim
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 384,304 GRT/619,668 DWT
ships by type: bulk 4, cargo 15, container 3, oil tanker 1 (1998
est.)
Airports: 116 (1998 e','879bb9bf6f0578dc31b96b99ac0cca0d2b5b9ad8065449236172ded20a4526c5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01cb6896217e2c3e126eb1c44bd401fcbcdf4e029e43ac1d7a3d84d928e1e0f0',1999,'AU','Australia','transportation',110,'st.)
Airports--with paved runways:
total: 80
over 3,047 m: 11
2,438 to 3,047 m: 20
1,524 to 2,437 m: 31
914 to 1,523 m: 15
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 36
over 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 9
under 914 m: 18 (1998 est.)
Heliports: 7 (1998 est.)
Railways: 0 km
Highways:
total: 61 km
paved: 36 km
unpaved: 25 km
Ports and harbors: Koror
Merchant marine: none
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 2
1,524 to 2,437 m: 2 (1998 est.)
Highways: much of the road and many causeways built during World
War II are unserviceable and overgrown
Ports and harbors: West Lagoon
Airports: 1 (1998 est.)
note: some overgrowth of vegetation on runway but still serviceable
Airports--with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 355 km
broad gauge: 76 km 1.524-m gauge
narrow gauge: 279 km 0.914-m gauge
Highways:
total: 11,100 km
paved: 3,730 km (including 30 km of expressways)
unpaved: 7,370 km (1996 est.)
Waterways: 800 km navigable by shallow draft vessels; 82 km
Panama Canal
Pipelines: crude oil 130 km
Ports and harbors: Balboa, Cristobal, Coco Solo, Manzanillo (part
of Colon area), Vacamonte
Merchant marine:
total: 4,632 ships (1,000 GRT or over) totaling 98,433,972
GRT/149,800,820 DWT
ships by type: bulk 1,335, cargo 1,028, chemical tanker 288,
combination bulk 68, combination ore/oil 15, container 507,
liquefied gas tanker 176, livestock carrier 9, multifunction
large-load carrier 6, oil tanker 498, passenger 41, passenger-cargo
5, railcar carrier 2, refrigerated cargo 312, roll-on/roll-off cargo
102, short-sea passenger 40, specialized tanker 23, vehicle carrier
177
note: a flag of convenience registry; includes ships from 71
countries among which are Japan 1,262, Greece 378, Hong Kong 244,
South Korea 259, Taiwan 229, China 193, Singapore 103, US 116,
Switzerland 78, and Indonesia 53 (1998 est.)
Airports: 110 (1998 est.)
Airports--with paved runways:
total: 43
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 22 (1998 est.)
Airports--with unpaved runways:
total: 67
914 to 1,523 m: 17
under 914 m: 50 (1998 est.)
Railways: 0 km
Highways:
total: 8 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 10 ships (1,000 GRT or over) totaling 44,371 GRT/70,137 DWT
ships by type: cargo 6, chemical tanker 2, oil tanker 1,
passenger-cargo 1 (1998 est.)
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 1,241 km
narrow gauge: 1,241 km 1.000-m gauge
note: a program to rehabilitate the railroad is underway (1995)
Highways:
total: 27,000 km
paved: 1,800 km
unpaved: 25,200 km (of which about 4,800 km are all-weather roads)
(1990 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake George,
Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
Merchant marine:
total: 3 roll-on/roll-off cargo ships (1,000 GRT or over) totaling
5,091 GRT/8,229 DWT (1998 est.)
Airports: 27 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 9
under 914 m: 7 (1998 est.)','52f8274ef6897cd7b66a83a5de396c06b8de3262b763703f64be3285aea08743','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3527c7dcf208081955bb19c21c5debc23a71081006b7ea44e25349c075f0f19',1999,'KM','Comoros','transportation',122,'Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1996 est.)
Ports and harbors: Fomboni, Moroni, Moutsamoudou
Merchant marine: none
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (1998 est.)
Railways:
total: 5,138 km (1995); note--severely reduced route-distance in use
because of damage to facilities by civil strife
narrow gauge: 3,987 km 1.067-m gauge (858 km electrified); 125 km
1.000-m gauge; 1,026 km 0.600-m gauge
Highways:
total: 145,000 km
paved: 2,500 km
unpaved: 142,500 km (1993 est.)
Waterways: 15,000 km including the Congo, its tributaries, and
unconnected lakes
Pipelines: petroleum products 390 km
Ports and harbors: Banana, Boma, Bukavu, Bumba, Goma, Kalemie,
Kindu, Kinshasa, Kisangani, Matadi, Mbandaka
Merchant marine: none
Airports: 233 (1998 est.)
Airports--with paved runways:
total: 23
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 14
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 210
1,524 to 2,437 m: 21
914 to 1,523 m: 95
under 914 m: 94 (1998 est.)','2fa9d2bf083561116c430412b39f57c2565012fcb813ea5492bec063c0e32cc1','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87659d51c498e1888e732781e7678b9c8801816acf7e092cc361a12aa3c3d314',1999,'ET','Ethiopia','transportation',129,'Railways:
total: 795 km (includes 285 km private track)
narrow gauge: 795 km 1.067-m gauge (1995 est.)
Highways:
total: 12,800 km
paved: 1,242 km
unpaved: 11,558 km (1996 est.)
Waterways: the Congo and Ubangi (Oubangui) Rivers provide 1,120
km of commercially navigable water transport; other rivers are used
for local traffic only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso, Oyo,
Pointe-Noire
Airports: 36 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 32
1,524 to 2,437 m: 8
914 to 1,523 m: 14
under 914 m: 10 (1998 est.)
Railways:
total: 641 km; (linked to Senegal''s rail system through Kayes)
narrow gauge: 641 km 1.000-m gauge (1995)
Highways:
total: 15,100 km
paved: 1,827 km
unpaved: 13,273 km (1996 est.)
Waterways: 1,815 km navigable
Ports and harbors: Koulikoro
Airports: 28 (1998 est.)
Airports--with paved runways:
total: 6
2,438 to 3,047 m: 4
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 22
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 10 (1998 est.)','b5d6677b9631126daa59735093e0e66912c9c43ad1acf56e2d07bce8370a03ca','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69dcfe6b3c46868dcac0d0b027a2900f876ffe05e4aaf6d4bb098f18fb1c0a19',1999,'NZ','New Zealand','transportation',139,'Railways: 0 km
Highways:
total: 187 km
paved: 35 km
unpaved: 152 km (1980 est.)
Ports and harbors: Avarua, Avatiu
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 2,310 GRT/2,181 DWT
(1998 est.)
Airports: 7 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (1998 est.)','c65c319eeb202727d1bb096b6a0bea8730c3b997bdf8da339bbb3ef8d02e7743','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da761311a0d3929bcd1026c40006b9ca39129a320eeb9e4c393b4da0c8dedb0',1999,'TT','Trinidad and Tobago','transportation',149,'Railways: 0 km
Highways:
total: 780 km
paved: 393 km
unpaved: 387 km (1996 est.)
Ports and harbors: Portsmouth, Roseau
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
914 to 1,523 m: 2 (1998 est.)
Railways:
total: 757 km
standard gauge: 375 km 1.435-m gauge (Central Romana Railroad)
narrow gauge: 142 km 0.762-m gauge (Dominica Government Railway);
240 km operated by sugar companies in various gauges (0.558-m,
0.762-m, 1.067-m gauges) (1995)
Highways:
total: 12,600 km
paved: 6,224 km
unpaved: 6,376 km (1996 est.)
Pipelines: crude oil 96 km; petroleum products 8 km
Ports and harbors: Barahona, La Romana, Puerto Plata, San Pedro
de Macoris, Santo Domingo
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,587 GRT/1,165 DWT
(1998 est.)
Airports: 36 (1998 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 22
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 15 (1998 est.)
Railways:
total: 965 km (single track)
narrow gauge: 965 km 1.067-m gauge
Highways:
total: 42,874 km
paved: 5,752 km
unpaved: 37,122 km (1998 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products 1,358 km
Ports and harbors: Esmeraldas, Guayaquil, La Libertad, Manta,
Puerto Bolivar, San Lorenzo
Merchant marine:
total: 23 ships (1,000 GRT or over) totaling 99,078 GRT/162,423 DWT
ships by type: chemical tanker 2, liquefied gas tanker 1, oil tanker
17, passenger 3 (1998 est.)
Airports: 183 (1998 est.)
Airports--with paved runways:
total: 56
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 15
914 to 1,523 m: 14
under 914 m: 19 (1998 est.)
Airports--with unpaved runways:
total: 127
914 to 1,523 m: 37
under 914 m: 90 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 1,040 km
paved: 320 km
unpaved: 720 km (1996 est.)
Ports and harbors: Kingstown
Merchant marine:
total: 814 ships (1,000 GRT or over) totaling 7,726,930
GRT/11,835,144 DWT
ships by type: barge carrier 1, bulk 138, cargo 402, chemical tanker
26, combination bulk 11, combination ore/oil 7, container 47,
liquefied gas tanker 3, livestock carrier 4, multifunction
large-load carrier 2, oil tanker 64, passenger 2, refrigerated cargo
40, roll-on/roll-off cargo 51, short-sea passenger 10, specialized
tanker 5, vehicle carrier 1
note: a flag of convenience registry; includes ships from 20
countries among which are Croatia 17, Slovenia 7, China 5, Greece 5,
UAE 3, Norway 2, Japan 2, and Ukraine 2 (1998 est.)
Airports: 6 (1998 est.)
Airports--with paved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 790 km
paved: 332 km
unpaved: 458 km (1996 est.)
Ports and harbors: Apia, Asau, Mulifanua, Salelologa
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 2
under 914 m: 2 (1998 est.)
Railways: 0 km; note--there is a 1.5 km cable railway connecting
the city of San Marino to Borgo Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports and harbors: none
Airports: none
Railways: 0 km
Highways:
total: 320 km
paved: 218 km
unpaved: 102 km (1996 est.)
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 3 cargo ships (1,000 GRT or over) totaling 7,610 GRT/9,446
DWT (1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 1,390 km
standard gauge: 1,390 km 1.435-m gauge (448 km double track) (1992)
Highways:
total: 162,000 km
paved: 69,174 km
unpaved: 92,826 km (1996 est.)
Pipelines: crude oil 6,400 km; petroleum products 150 km; natural
gas 2,200 km (includes natural gas liquids 1,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba, Jiddah, Jizan,
Rabigh, Ra''s al Khafji, Mishab, Ras Tanura, Yanbu'' al Bahr, Madinat
Yanbu'' al Sinaiyah
Merchant marine:
total: 73 ships (1,000 GRT or over) totaling 1,124,110 GRT/1,467,121
DWT
ships by type: bulk 1, cargo 13, chemical tanker 7, container 5,
liquefied gas tanker 1, livestock carrier 4, oil tanker 17,
passenger 1, refrigerated cargo 4, roll-on/roll-off cargo 12,
short-sea passenger 8 (1998 est.)
Airports: 205 (1998 est.)
Airports--with paved runways:
total: 70
over 3,047 m: 30
2,438 to 3,047 m: 12
1,524 to 2,437 m: 23
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 135
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 78
914 to 1,523 m: 38
under 914 m: 13 (1998 est.)
Heliports: 4 (1998 est.)
Railways:
total: 904 km
narrow gauge: 904 km 1.000-meter gauge (70 km double track) (1995)
Highways:
total: 14,576 km
paved: 4,271 km
unpaved: 10,305 km (1996 est.)
Waterways: 897 km total; 785 km on the Senegal river, and 112 km
on the Saloum river
Ports and harbors: Dakar, Kaolack, Matam, Podor, Richard-Toll,
Saint-Louis, Ziguinchor
Merchant marine:
total: 1 bulk ship (1,000 GRT or over) totaling 1,995 GRT/3,775 DWT
(1998 est.)
Airports: 20 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 1 (1998 est.)
Railways:
total: 3,987 km
standard gauge: 3,987 km 1.435-m gauge (1,377 km partially
electrified since 1992) (1998)
Highways:
total: 50,414 km
paved: 45,020 km (including 545 km of expressways)
unpaved: 5,394 km (1997 est.)
Waterways: NA km
Pipelines: crude oil 415 km; petroleum products 130 km; natural
gas 2,110 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad, Pancevo,
Tivat, Zelenika
Merchant marine:
total: 1 short-sea passenger (1,000 GRT or over) totaling 2,437
GRT/400 DWT (owned by Montenegro) (1998 est.)
Airports: 48 (Serbia 43, Montenegro 5) (1998 est.)
Airports--with paved runways:
total: 18
over 3,047 m: 2 (Serbia 2, Montenegro 0)
2,438 to 3,047 m: 5 (Serbia 3, Montenegro 2)
1,524 to 2,437 m: 5 (Serbia 4, Montenegro 1)
914 to 1,523 m: 2 (Serbia 2, Montenegro 0)
under 914 m: 4 (Serbia 4, Montenegro 0) (1998 est.)
Airports--with unpaved runways:
total: 30
1,524 to 2,437 m: 2 (Serbia 2, Montenegro 0)
914 to 1,523 m: 14 (Serbia 13, Montenegro 1)
under 914 m: 14 (Serbia 13, Montenegro 1) (1998 est.)','ad3d6c33deff3690daad4c3fb3cd6a36d11585fec47af51b6339635328bc0df3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6442fa8890119a0e2c8cdcc008a06a861e446a32a8b4d18228aacde1cc13499b',1999,'MX','Mexico','transportation',159,'Railways:
total: 4,751 km
standard gauge: 4,751 km 1,435-m gauge (42 km electrified; 951 km
double track)
Highways:
total: 64,000 km
paved: 49,984 km
unpaved: 14,016 km (1996 est.)
Waterways: 3,500 km (including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller canals in the
delta); Suez Canal, 193.5 km long (including approaches), used by
oceangoing vessels drawing up to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products 596 km; natural
gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah, Aswan, Asyut, Bur
Safajah, Damietta, Marsa Matruh, Port Said, Suez
Merchant marine:
total: 180 ships (1,000 GRT or over) totaling 1,334,406
GRT/2,022,785 DWT
ships by type: bulk 25, cargo 63, container 1, liquefied gas tanker
1, oil tanker 14, passenger 56, refrigerated cargo 1,
roll-on/roll-off cargo 16, short-sea passenger 3 (1998 est.)
Airports: 89 (1998 est.)
Airports--with paved runways:
total: 70
over 3,047 m: 10
2,438 to 3,047 m: 37
1,524 to 2,437 m: 16
914 to 1,523 m: 3
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 19
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 6
under 914 m: 9 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 602 km (single track; note--some sections abandoned, unusable,
or operating at reduced capacity)
narrow gauge: 602 km 0.914-m gauge
Highways:
total: 10,029 km
paved: 1,986 km (including 327 km of expressways)
unpaved: 8,043 km (1997 est.)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutla, Puerto Cutuco, La Libertad, La
Union, Puerto El Triunfo
Merchant marine: none
Airports: 86 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 82
914 to 1,523 m: 17
under 914 m: 65 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 0 km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2,880 km (1996 est.)
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling 23,370 GRT/25,194 DWT
ships by type: cargo 9, passenger 2, passenger-cargo 1 (1998 est.)
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways:
total: 307 km
narrow gauge: 307 km 0.950-m gauge (1995 est.)
note: nonoperational since 1978 except for about a 5 km stretch that
was reopened in Massawa in 1994; rehabilitation of the remainder and
of the rolling stock is under way; links Ak''ordat and Asmara
(formerly Asmera) with the port of Massawa (formerly Mits''iwa)
Highways:
total: 4,010 km
paved: 874 km
unpaved: 3,136 km (1996 est.)
Ports and harbors: Assab (Aseb), Massawa (Mits''iwa)
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 5,947 GRT/5,747 DWT
ships by type: oil tanker 1, roll-on/roll-off cargo 1 (1998 est.)
Airports: 20 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 18
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 3 (1998 est.)
Railways:
total: 1,018 km common carrier lines only; does not include
dedicated industrial lines
broad gauge: 1,018 km 1.520-m gauge (132 km electrified) (1995)
Highways:
total: 16,437 km
paved: 8,343 km (including 65 km of expressways)
unpaved: 8,094 km (1997 est.)
Waterways: 320 km perennially navigable
Pipelines: natural gas 420 km (1992)
Ports and harbors: Haapsalu, Kunda, Muuga, Paldiski, Parnu,
Tallinn
Merchant marine:
total: 52 ships (1,000 GRT or over) totaling 337,163 GRT/348,749 DWT
ships by type: bulk 4, cargo 22, combination bulk 1, container 5,
oil tanker 2, roll-on/roll-off cargo 12, short-sea passenger 6 (1998
est.)
Airports: 5 (1997 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (1997 est.)
Railways:
total: 681 km (Ethiopian segment of the Addis Ababa-Djibouti
railroad)
narrow gauge: 681 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced plans to
revitalize the century-old railroad that links their capitals
Highways:
total: 28,500 km
paved: 4,275 km
unpaved: 24,225 km (1996 est.)
Ports and harbors: none; Ethiopia is landlocked and was by
agreement with Eritrea using the ports of Assab and Massawa, but
since the border dispute with Eritrea flared, Ethiopia has used the
port of Djibouti
Merchant marine:
total: 11 ships (1,000 GRT or over) totaling 71,264 GRT/94,489 DWT
ships by type: cargo 7, oil tanker 1, roll-on/roll-off cargo 3 (1998
est.)
Airports: 84 (1998 est.)
Airports--with paved runways:
total: 11
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 2
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 73
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 9
914 to 1,523 m: 36
under 914 m: 18 (1998 est.)','979660d9e37fb09669228663603b10f2b40adb090ecde2e2a0e561fc3c41839d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37271f7923aec9ef28eedba5b537e9a2c5157515375433ab68f138d314a9cc5d',1999,'MZ','Mozambique','transportation',170,'Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 883 km
narrow gauge: 883 km 1.000-m gauge (1994)
Highways:
total: 49,837 km
paved: 5,781 km
unpaved: 44,056 km (1996 est.)
Waterways: of local importance only; isolated streams and small
portions of Lakandranon'' Ampangalana (Canal des Pangalanes)
Ports and harbors: Antsiranana, Antsohimbondrona, Mahajanga,
Toamasina, Toliara
Merchant marine:
total: 12 ships (1,000 GRT or over) totaling 23,311 GRT/31,533 DWT
ships by type: cargo 6, chemical tanker 1, liquefied gas tanker 1,
oil tanker 2, roll-on/roll-off cargo 2 (1998 est.)
Airports: 133 (1998 est.)
Airports--with paved runways:
total: 29
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 104
1,524 to 2,437 m: 3
914 to 1,523 m: 59
under 914 m: 42 (1998 est.)
Railways:
total: 789 km
narrow gauge: 789 km 1.067-m gauge
Highways:
total: 28,400 km
paved: 5,254 km
unpaved: 23,146 km (1996 est.)
Waterways: Lake Nyasa (Lake Malawi); Shire River, 144 km
Ports and harbors: Chipoka, Monkey Bay, Nkhata Bay, Nkhotakota
Airports: 45 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 40
1,524 to 2,437 m: 1
914 to 1,523 m: 16
under 914 m: 23 (1998 est.)
Railways:
total: 1,798 km
narrow gauge: 1,798 km 1.000-m gauge (148 km electrified) (1998 est.)
Highways:
total: 94,500 km
paved: 70,970 km (including 580 km of expressways)
unpaved: 23,530 km (1996 est.)
Waterways: 7,296 km (Peninsular Malaysia 3,209 km, Sabah 1,569
km, Sarawak 2,518 km)
Pipelines: crude oil 1,307 km; natural gas 379 km
Ports and harbors: Bintulu, Kota Kinabalu, Kuantan, Kuching,
Kudat, Labuan, Lahad Datu, Lumut, Miri, Pasir Gudang, Penang, Port
Dickson, Port Kelang, Sandakan, Sibu, Tanjung Berhala, Tanjung
Kidurong, Tawau
Merchant marine:
total: 378 ships (1,000 GRT or over) totaling 5,059,272
GRT/7,428,623 DWT
ships by type: bulk 62, cargo 128, chemical tanker 30, container 58,
liquefied gas tanker 19, livestock carrier 1, oil tanker 61,
passenger 2, refrigerated cargo 2, roll-on/roll-off cargo 6,
specialized tanker 2, vehicle carrier 7 (1998 est.)
Airports: 115 (1998 est.)
Airports--with paved runways:
total: 32
over 3,047 m: 5
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 6
under 914 m: 6 (1998 est.)
Airports--with unpaved runways:
total: 83
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 74 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 93 km
paved: 72 km
unpaved: 21 km
Ports and harbors: Dzaoudzi
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 31,048 km
standard gauge: 30,958 km 1.435-m gauge (246 km electrified)
narrow gauge: 90 km 0.914-m gauge (1998 est.)
Highways:
total: 252,000 km
paved: 94,248 km (including 6,740 km of expressways)
unpaved: 157,752 km (1996 est.)
Waterways: 2,900 km navigable rivers and coastal canals
Pipelines: crude oil 28,200 km; petroleum products 10,150 km;
natural gas 13,254 km; petrochemical 1,400 km
Ports and harbors: Acapulco, Altamira, Coatzacoalcos, Ensenada,
Guaymas, La Paz, Lazaro Cardenas, Manzanillo, Mazatlan, Progreso,
Salina Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 52 ships (1,000 GRT or over) totaling 852,004 GRT/1,236,475
DWT
ships by type: bulk 2, cargo 1, chemical tanker 4, container 4,
liquefied gas tanker 7, oil tanker 28, roll-on/roll-off cargo 3,
short-sea passenger 3 (1998 est.)
Airports: 1,805 (1998 est.)
Airports--with paved runways:
total: 232
over 3,047 m: 10
2,438 to 3,047 m: 27
1,524 to 2,437 m: 91
914 to 1,523 m: 78
under 914 m: 26 (1998 est.)
Airports--with unpaved runways:
total: 1,573
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 63
914 to 1,523 m: 468
under 914 m: 1,040 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 240 km
paved: 42 km
unpaved: 198 km (1996 est.)
Ports and harbors: Colonia (Yap), Kolonia (Pohnpei), Lele, Moen
Merchant marine: none
Airports: 6 (1998 est.)
Airports--with paved runways:
total: 5
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Highways:
total: 32 km
paved: NA km
unpaved: NA km
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 1,328 km
broad gauge: 1,328 km 1.520-m gauge (1992)
Highways:
total: 12,300 km
paved: 10,738 km
unpaved: 1,562 km (1996 est.)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 26 (1994 est.)
Airports--with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 3 (1994 est.)
Airports--with unpaved runways:
total: 18
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 8 (1994 est.)
Railways:
total: 1.7 km
standard gauge: 1.7 km 1.435-m gauge
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Monaco
Merchant marine: none
Airports: linked to airport in Nice, France, by helicopter service
Railways:
total: 1,928 km
broad gauge: 1,928 km 1.524-m gauge (1994)
Highways:
total: 46,470 km
paved: 3,730 km
unpaved: 42,740 km (1997 est.)
note: much of the unpaved rural road system consists of rough
cross-country tracks
Waterways: 397 km of principal routes (1988)
Ports and harbors: none
Airports: 34 (1994 est.)
Airports--with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m: 1 (1994 est.)
Airports--with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 m: 5 (1994 est.)','e2717d3cfb9f728b7d238b687b00446a25b918ef4abb0ecbd1f62c43f7b624bf','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7765601536b7524401af221d5b970cc7179c0121c6511f78cb4fbbc27eafc177',1999,'AR','Argentina','transportation',176,'Railways: 0 km
Highways:
total: 348 km
paved: 83 km
unpaved: 265 km
Ports and harbors: Stanley
Merchant marine: none
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
under 914 m: 3 (1998 est.)
Railways: 0 km
Highways:
total: 458 km
paved: 450 km
unpaved: 8 km (1995 est.)
Ports and harbors: Torshavn, Klaksvik, Tvoroyri, Runavik,
Fuglafjorour
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 22,853 GRT/13,481 DWT
ships by type: cargo 2, oil tanker 1, refrigerated cargo 1,
roll-on/roll-off cargo 1, short-sea passenger 1 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 597 km; note--belongs to the government-owned Fiji Sugar
Corporation
narrow gauge: 597 km 0.610-m gauge (1995)
Highways:
total: 3,440 km
paved: 1,692 km
unpaved: 1,748 km (1996 est.)
Waterways: 203 km; 122 km navigable by motorized craft and
200-metric-ton barges
Ports and harbors: Labasa, Lautoka, Levuka, Savusavu, Suva
Merchant marine:
total: 5 ships (1,000 GRT or over) totaling 10,721 GRT/13,145 DWT
ships by type: chemical tanker 2, passenger 1, roll-on/roll-off
cargo 1, specialized tanker 1 (1998 est.)
Airports: 24 (1998 est.)
Airports--with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 21
914 to 1,523 m: 4
under 914 m: 17 (1998 est.)
Railways:
total: 5,859 km
broad gauge: 5,859 km 1.524-m gauge (2,073 km electrified; 480 km
double- or more-track) (1996)
Highways:
total: 77,796 km
paved: 49,789 km (including 444 km of expressways)
unpaved: 28,007 km (1997 est.)
Waterways: 6,675 km total (including Saimaa Canal); 3,700 km
suitable for steamers
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola, Kotka, Loviisa,
Oulu, Pori, Rauma, Turku, Uusikaupunki, Varkaus
Merchant marine:
total: 101 ships (1,000 GRT or over) totaling 1,192,559
GRT/1,161,594 DWT
ships by type: bulk 9, cargo 23, chemical tanker 6, oil tanker 11,
passenger 1, railcar carrier 1, roll-on/roll-off cargo 38, short-sea
passenger 12 (1998 est.)
Airports: 157 (1998 est.)
Airports--with paved runways:
total: 68
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437 m: 10
914 to 1,523 m: 20
under 914 m: 9 (1998 est.)
Airports--with unpaved runways:
total: 89
914 to 1,523 m: 6
under 914 m: 83 (1998 est.)
Railways:
total: 32,027 km ( 31,940 km are operated by French National
Railways (SNCF); 13,803 km of SNCF routes are electrified and 12,132
km are double- or multiple-tracked)
standard gauge: 31,928 km 1.435-m gauge
narrow gauge: 99 km 1.000-m gauge
note: does not include 33 tourist railroads, totaling 469 km, many
being of very narrow gauge (1996)
Highways:
total: 892,900 km
paved: 892,900 km (including 9,900 km of expressways)
unpaved: 0 km (1997 est.)
Waterways: 14,932 km; 6,969 km heavily traveled
Pipelines: crude oil 3,059 km; petroleum products 4,487 km;
natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne, Cherbourg, Dijon,
Dunkerque, La Pallice, Le Havre, Lyon, Marseille, Mullhouse, Nantes,
Paris, Rouen, Saint Nazaire, Saint Malo, Strasbourg
Merchant marine:
total: 64 ships (1,000 GRT or over) totaling 1,826,364 GRT/2,962,338
DWT
ships by type: bulk 5, cargo 5, chemical tanker 6, combination bulk
1, container 6, liquefied gas tanker 4, multifunction large-load
carrier 2, oil tanker 20, passenger 3, roll-on/roll-off cargo 5,
short-sea passenger 6, specialized tanker 1
note: France also maintains a captive register for French-owned
ships in Iles Kerguelen (French Southern and Antarctic Lands) (1998
est.)
Airports: 474 (1998 est.)
Airports--with paved runways:
total: 267
over 3,047 m: 13
2,438 to 3,047 m: 31
1,524 to 2,437 m: 94
914 to 1,523 m: 73
under 914 m: 56 (1998 est.)
Airports--with unpaved runways:
total: 207
1,524 to 2,437 m: 3
914 to 1,523 m: 75
under 914 m: 129 (1998 est.)
Heliports: 3 (1998 est.)
Railways: 0 km (1995)
Highways:
total: 1,817 km (national 432 km, departmental 385 km, community
1,000 km)
paved: 727 km
unpaved: 1,090 km (1995 est.)
Waterways: 460 km, navigable by small oceangoing vessels and
river and coastal steamers; 3,300 km navigable by native craft
Ports and harbors: Cayenne, Degrad des Cannes, Saint-Laurent du
Maroni
Merchant marine: none
Airports: 11 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5 (1998 est.)','7d2a570d202e3567b301ea3b76df228cff35366a0810df964cb78ff30ff6848c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d5f9a2ef76f4796dc157018549c086aad32c88ebd5e0e1c34bc9e4f1659107b',1999,'NR','Nauru','transportation',188,'Railways: 0 km
Highways:
total: 792 km
paved: 792 km (1995 est.)
Ports and harbors: Mataura, Papeete, Rikitea, Uturoa
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 5,240 GRT/7,765 DWT
ships by type: cargo 1, passenger-cargo 2, refrigerated cargo 1
(1998 est.)
Airports: 45 (1998 est.)
Airports--with paved runways:
total: 29
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 17
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 16
914 to 1,523 m: 5
under 914 m: 11 (1998 est.)
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 66 ships (1,000 GRT or over) totaling 2,201,120 GRT/3,832,935
DWT
ships by type: bulk 3, cargo 7, chemical tanker 10, container 9,
liquefied gas tanker 6, oil tanker 19, refrigerated cargo 2,
roll-on/roll-off cargo 10 (1998 est.)
Airports: none
Railways:
total: 649 km Gabon State Railways (OCTRA)
standard gauge: 649 km 1.435-m gauge; single track (1994)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996 est.)
Waterways: 1,600 km perennially navigable
Pipelines: crude oil 270 km; petroleum products 14 km
Ports and harbors: Cap Lopez, Kango, Lambarene, Libreville,
Mayumba, Owendo, Port-Gentil
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 13,613 GRT/22,599 DWT
(1998 est.)
ships by type: bulk 1, cargo 1 (1998 est.)
Airports: 62 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 52
1,524 to 2,437 m: 10
914 to 1,523 m: 16
under 914 m: 26 (1998 est.)
Railways: 0 km
Highways:
total: 670 km (1996 est.)
paved: NA km
unpaved: NA km
Waterways: small network of canals, totaling 5 km, in Line Islands
Ports and harbors: Banaba, Betio, English Harbor, Kanton
Merchant marine:
total: 1 passenger-cargo (1,000 GRT or over) totaling 1,291
GRT/1,295 DWT (1998 est.)
Airports: 21 (1998 est.)
Airports--with paved runways:
total: 4
1,524 to 2,437 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 17
914 to 1,523 m: 12
under 914 m: 5 (1998 est.)
Railways:
broad gauge: NA km
total: 5,000 km
standard gauge: 4,095 km 1.435-m gauge (3,500 km electrified; 159 km
double track)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1.435-m and 1.600-m gauges (three rails) (1996
est.)
Highways:
total: 31,200 km
paved: 1,997 km
unpaved: 29,203 km (1996 est.)
Waterways: 2,253 km; mostly navigable by small craft only
Pipelines: crude oil 37 km; petroleum product 180 km
Ports and harbors: Ch''ongjin, Haeju, Hungnam (Hamhung),
Kimch''aek, Kosong, Najin, Namp''o, Sinuiju, Songnim, Sonbong
(formerly Unggi), Ungsang, Wonsan
Merchant marine:
total: 110 ships (1,000 GRT or over) totaling 691,802 GRT/992,789 DWT
ships by type: bulk 8, cargo 91, combination bulk 1, multifunction
large-load carrier 1, oil tanker 4, passenger 2, passenger-cargo 1,
short-sea passenger 2 (1998 est.)
Airports: 49 (1994 est.) (1998 est.)
Airports--with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 15
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 2 (1994 est.)
Airports--with unpaved runways:
total: 27
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 6 (1994 est.)
Railways:
total: 6,240 km
standard gauge: 6,240 km 1.435-m gauge (525 km electrified) (1998
est.)
Highways:
total: 63,500 km
paved: 46,800 km (including 1,720 km of expressways)
unpaved: 16,700 km (1998 est.)
Waterways: 1,609 km; use restricted to small native craft
Pipelines: petroleum products 455 km; note--additionally, there is
a parallel petroleum, oils, and lubricants (POL) pipeline being
completed
Ports and harbors: Chinhae, Inch''on, Kunsan, Masan, Mokp''o,
P''ohang, Pusan, Tonghae-hang, Ulsan, Yosu
Merchant marine:
total: 442 ships (1,000 GRT or over) totaling 5,212,089
GRT/8,161,845 DWT
ships by type: bulk 106, cargo 133, chemical tanker 36, combination
bulk 5, container 52, liquefied gas tanker 13, multifunction
large-load carrier 1, oil tanker 56, passenger 3, refrigerated cargo
22, roll-on/roll-off cargo 2, short-sea passenger 1, specialized
tanker 3, vehicle carrier 9 (1998 est.)
Airports: 103 (1998 est.)
Airports--with paved runways:
total: 68
over 3,047 m: 1
2,438 to 3,047 m: 18
1,524 to 2,437 m: 15
914 to 1,523 m: 13
under 914 m: 21 (1998 est.)
Airports--with unpaved runways:
total: 35
914 to 1,523 m: 3
under 914 m: 32 (1998 est.)
Heliports: 200 (1998 est.)
Railways: 0 km
Highways:
total: 4,450 km
paved: 3,587 km
unpaved: 863 km (1996 est.)
Pipelines: crude oil 877 km; petroleum products 40 km; natural
gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh, Kuwait, Mina''
''Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 49 ships (1,000 GRT or over) totaling 2,509,061 GRT/4,046,739
DWT
ships by type: bulk 1, cargo 10, container 6, liquefied gas tanker
7, livestock carrier 3, oil tanker 22 (1998 est.)
Airports: 8 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 370 km in common carrier service; does not include industrial
lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 18,500 km
paved: 16,854 km (including 140 km of expressways)
unpaved: 1,646 km (1996 est.)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or Rybach''ye)
Airports: 54 (1994 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
under 914 m: 1 (1994 est.)
Airports--with unpaved runways:
total: 40
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 32 (1994 est.)
Railways: 0 km
Highways:
total: 21,716 km
paved: 9,673.5 km
unpaved: 12,042.5 km (1998 est.)
Waterways: about 4,587 km, primarily Mekong and tributaries;
2,897 additional kilometers are sectionally navigable by craft
drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 2,370 GRT/3,000 DWT
(1998 est.)
Airports: 52 (1998 est.)
Airports--with paved runways:
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 25 (1998 est.)','48e8b917afba6ed5c8ba6ad3ac960dd6cd3ec4bce0663fe4e26c3a848020ccca','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd91d6a951c210cfcc813a8481310834f38b98c5c3798c5b70fc0dc21f04f37c',1999,'SN','Senegal','transportation',197,'Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
unpaved: 1,744 km (1996 est.)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: NA km; note--one line, abandoned and in disrepair, little
trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Ports and harbors: Gaza
Airports: 2 (1998 est.)
note: includes Gaza International Airport that opened on 24 November
1998 as part of agreements stipulated in the 23 October 1998 Wye
River Memorandum
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways:
total: 1,583 km in common carrier service; does not include
industrial lines
broad gauge: 1,583 km 1.520-m gauge (1993)
Highways:
total: 20,700 km
paved: 19,354 km
unpaved: 1,346 km (1996 est.)
Pipelines: crude oil 370 km; refined products 300 km; natural gas
440 km (1992)
Ports and harbors: Bat''umi, P''ot''i, Sokhumi
Merchant marine:
total: 8 ships (1,000 GRT or over) totaling 86,667 GRT/121,679 DWT
ships by type: cargo 2, oil tanker 5, short-sea passenger 1 (1998
est.)
Airports: 28 (1994 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (1994 est.)
Airports--with unpaved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 6 (1994 est.)
Transportation--note: transportation network is in poor condition
and disrupted by ethnic conflict, criminal activities, and fuel
shortages; network lacks maintenance and repair
Railways:
total: 46,300 km including 18,866 km electrified and 14,768 km
double- or multiple-tracked (1996)
note: since privatization in 1994, Deutsche Bahn AG (DBAG) no longer
publishes details of the tracks it owns; in addition to the DBAG
system there are 102 privately owned railway companies which own an
approximate 3,000 km to 4,000 km of the total tracks
Highways:
total: 656,074 km
paved: 650,169 km (including 11,309 km of expressways)
unpaved: 5,905 km all-weather (1997 est.)
Waterways: 7,467 km (1997); major rivers include the Rhine and
Elbe; Kiel Canal is an important connection between the Baltic Sea
and North Sea
Pipelines: crude oil 2,460 km (1997)
Ports and harbors: Berlin, Bonn, Brake, Bremen, Bremerhaven,
Cologne, Dresden, Duisburg, Emden, Hamburg, Karlsruhe, Kiel, Lubeck,
Magdeburg, Mannheim, Rostock, Stuttgart
Merchant marine:
total: 594 ships (1,000 GRT or over) totaling 7,699,596
GRT/9,629,163 DWT
ships by type: cargo 227, chemical tanker 15, combination bulk 1,
container 306, liquefied gas tanker 5, multifunction large-load
carrier 5, oil tanker 7, passenger 3, railcar carrier 2,
refrigerated cargo 2, roll-on/roll-off cargo 14, short-sea passenger
7 (1998 est.)
Airports: 618 (1998 est.)
Airports--with paved runways:
total: 319
over 3,047 m: 14
2,438 to 3,047 m: 62
1,524 to 2,437 m: 68
914 to 1,523 m: 54
under 914 m: 121 (1998 est.)
Airports--with unpaved runways:
total: 299
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 6
914 to 1,523 m: 58
under 914 m: 227 (1998 est.)
Heliports: 61 (1998 est.)
Railways:
total: 953 km (undergoing major rehabilitation)
narrow gauge: 953 km 1.067-m gauge (32 km double track) (1997 est.)
Highways:
total: 39,409 km
paved: 11,653 km (including 30 km of expressways)
unpaved: 27,756 km (1997 est.)
Waterways: Volta, Ankobra, and Tano Rivers provide 168 km of
perennial navigation for launches and lighters; Lake Volta provides
1,125 km of arterial and feeder waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 5 ships (1,000 GRT or over) totaling 10,552 GRT/14,839 DWT
ships by type: oil tanker 2, refrigerated cargo 3 (1998 est.)
Airports: 12 (1998 est.)
Airports--with paved runways:
total: 6
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Railways:
total: NA km; 1.000-m gauge system in dockyard area only
Highways:
total: 49.9 km
paved: 49.9 km
unpaved: 0 km
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 18 ships (1,000 GRT or over) totaling 346m951 GRT/588,765 DWT
ships by type: chemical tanker 2, container 4, oil tanker 11,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)','e98bc89da443666306e0d0ed53e439e8bc1a515763527bf9c7b6a80f2f8925c9','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2e1d09a3fc8f212331949111b1baf7b704f84ff749d3bc9f551385b970b6aee',1999,'GR','Greece','transportation',205,'Railways:
total: 2,548 km
standard gauge: 1,565 km 1.435-m gauge (36 km electrified; 23 km
double track)
narrow gauge: 961 km 1.000-m gauge; 22 km 0.750-m gauge (a rack type
railway for steep grades)
Highways:
total: 117,000 km
paved: 107,406 km (including 470 km of expressways)
unpaved: 9,594 km (1996 est.)
Waterways: 80 km; system consists of three coastal canals;
including the Corinth Canal (6 km) which crosses the Isthmus of
Corinth connecting the Gulf of Corinth with the Saronic Gulf and
shortens the sea voyage from the Adriatic to Peiraiefs (Piraeus) by
325 km; and three unconnected rivers
Pipelines: crude oil 26 km; petroleum products 547 km
Ports and harbors: Alexandroupolis, Elefsis, Irakleion (Crete),
Kavala, Kerkyra, Chalkis, Igoumenitsa, Lavrion, Patrai, Peiraiefs
(Piraeus), Thessaloniki, Volos
Merchant marine:
total: 810 ships (1,000 GRT or over) totaling 24,798,431
GRT/44,056,618 DWT
ships by type: bulk 307, cargo 66, chemical tanker 19, combination
bulk 9, combination ore/oil 12, container 45, liquefied gas tanker
5, multifunction large-load carrier 1, oil tanker 229, passenger 15,
passenger-cargo 2, refrigerated cargo 4, roll-on/roll-off cargo 17,
short-sea passenger 76, specialized tanker 3 (1998 est.)
Airports: 78 (1998 est.)
Airports--with paved runways:
total: 63
over 3,047 m: 5
2,438 to 3,047 m: 15
1,524 to 2,437 m: 18
914 to 1,523 m: 16
under 914 m: 9 (1998 est.)
Airports--with unpaved runways:
total: 15
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 11 (1998 est.)
Heliports: 2 (1998 est.)
Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Ports and harbors: Kangerluarsoruseq, Kangerlussuaq, Nanortalik,
Narsarsuaq, Nuuk (Godthab), Sisimiut
Merchant marine:
total: 1 passenger (1,000 GRT or over) totaling 1,211 GRT/162 DWT
(1998 est.)
Airports: 13 (1998 est.)
Airports--with paved runways:
total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 1,040 km
paved: 638 km
unpaved: 402 km (1996 est.)
Ports and harbors: Grenville, Saint George''s
Merchant marine: none
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)','38e04ad0f05afb224cbf3c7ec3d49b8d4a4981fc46e38dbeb859f8cc3cd925a3','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a0c743d9181edeacb49a149bba27487d0f7a3470b2132d68d5b75e61e764c38',1999,'MQ','Martinique','transportation',210,'Railways:
total: NA km; privately owned, narrow-gauge plantation lines
Highways:
total: 2,082 km
paved: 1,742 km
unpaved: 340 km (1985 est.)
note: in 1996 there were a total of 3,200 km of roads
Ports and harbors: Basse-Terre, Gustavia (on Saint Barthelemy),
Marigot, Pointe-a-Pitre
Merchant marine: none
Airports: 9 (1998 est.)
Airports--with paved runways:
total: 8
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there is another 685 km of roads classified non-public,
including roads located on federal government installations
Ports and harbors: Apra Harbor
Merchant marine: none
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)','5444500538770cae2964f2ad2207a2257d2fdca420295780df4ea42d7cf89076','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd5ba4eaeb6b8e3c242b0183e1fea53a82aafea6fc804948013226234d6d1c9',1999,'GT','Guatemala','transportation',219,'Railways:
total: 884 km (102 km privately owned)
narrow gauge: 884 km 0.914-m gauge (single track)
Highways:
total: 13,100 km
paved: 3,616 km (including 140 km of expressways)
unpaved: 9,484 km (1996 est.)
Waterways: 260 km navigable year round; additional 730 km
navigable during high-water season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios, Puerto Quetzal,
San Jose, Santo Tomas de Castilla
Merchant marine: none
Airports: 478 (1998 est.)
Airports--with paved runways:
total: 12
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 6
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 466
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 124
under 914 m: 332 (1998 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Saint Peter Port, Saint Sampson
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Railways:
total: 1,086 km
standard gauge: 279 km 1.435-m gauge
narrow gauge: 807 km 1.000-m gauge (includes 662 km in common
carrier service from Kankan to Conakry)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25,467 km (1996 est.)
Waterways: 1,295 km navigable by shallow-draft native craft
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none
Airports: 15 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1996 est.)
Waterways: several rivers are accessible to coastal shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none
Airports: 30 (1998 est.)
Airports--with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 27
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 22 (1998 est.)
Railways:
total: 88 km (all dedicated to ore transport)
standard gauge: 40 km 1.435-m gauge
narrow gauge: 48 km 0.914-m gauge
Highways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (1996 est.)
Waterways: 6,000 km total of navigable waterways; Berbice,
Demerara, and Essequibo Rivers are navigable by oceangoing vessels
for 150 km, 100 km, and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden, New Amsterdam,
Parika
Merchant marine:
total: 2 cargo ships (1,000 GRT or over) totaling 2,340 GRT/4,530
DWT (1998 est.)
Airports: 48 (1998 est.)
Airports--with paved runways:
total: 4
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 44
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 35 (1998 est.)
Railways:
total: 40 km (single track; privately owned industrial line)--closed
in early 1990s
narrow gauge: 40 km 0.760-m gauge
Highways:
total: 4,160 km
paved: 1,011 km
unpaved: 3,149 km (1996 est.)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel, Jeremie, Les
Cayes, Miragoane, Port-au-Prince, Port-de-Paix, Saint-Marc
Merchant marine: none
Airports: 13 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 10
914 to 1,523 m: 5
under 914 m: 5 (1998 est.)
Ports and harbors: none; offshore anchorage only
Railways:
total: 862 m; note--connects to Italy''s network at Rome''s Saint
Peter''s station
narrow gauge: 862 m 1.435-m gauge
Highways: none; all city streets
Ports and harbors: none
Airports: none
Heliports: 1 (1998 est.)
Railways:
total: 595 km
narrow gauge: 190 km 1.067-m gauge; 128 km 1.057-m gauge; 277 km
0.914-m gauge
Highways:
total: 14,173 km
paved: 3,126 km
unpaved: 11,047 km (1998 est.)
Waterways: 465 km navigable by small craft
Ports and harbors: La Ceiba, Puerto Castilla, Puerto Cortes, San
Lorenzo, Tela, Puerto Lempira
Merchant marine:
total: 247 ships (1,000 GRT or over) totaling 555,534 GRT/730,602 DWT
ships by type: bulk 21, cargo 157, chemical tanker 4, container 7,
livestock carrier 1, oil tanker 25, passenger 1, passenger-cargo 4,
refrigerated cargo 15, roll-on/roll-off cargo 6, short-sea passenger
5, vehicle carrier 1
note: a flag of convenience registry; Russia owns 6 ships, Vietnam
1, Singapore 3, North Korea 1 (1998 est.)
Airports: 122 (1998 est.)
Airports--with paved runways:
total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 111
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 21
under 914 m: 87 (1998 est.)
Railways:
total: 34 km
standard gauge: 34 km 1.435-m gauge (all electrified) (1996 est.)
Highways:
total: 1,831 km
paved: 1,831 km
unpaved: 0 km (1997)
Ports and harbors: Hong Kong
Merchant marine:
total: 195 ships (1,000 GRT or over) totaling 6,075,304
GRT/10,133,186 DWT
ships by type: barge carrier 1, bulk 117, cargo 18, chemical tanker
2, combination bulk 2, container 40, liquefied gas tanker 1,
multifunction large-load carrier 2, oil tanker 6, refrigerated cargo
1, roll-on/roll-off cargo 1, short-sea passenger 1, vehicle carrier 3
note: a flag of convenience registry; includes ships from 13
countries among which are UK 16, South Africa 3, China 9, Japan 6,
Bermuda 2, Germany 3, Canada 2, Cyprus 1, Belgium 1, and Norway 1
(1998 est.)
Airports: 3 (1998 est.)
Airports--with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m: 1 (1998 est.)
Heliports: 2 (1998 est.)
Ports and harbors: none; offshore anchorage only; note--there is
one boat landing area along the middle of the west coast
Airports: airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia Earhart and Fred
Noonan--they left Lae, New Guinea, for Howland Island, but were never
seen again; the airstrip is no longer serviceable
Transportation--note: Earhart Light is a day beacon near the
middle of the west coast that was partially destroyed during World
War II, but has since been rebuilt; named in memory of famed
aviatrix Amelia Earhart
Railways:
total: 7,606 km
broad gauge: 36 km 1.524-m gauge
standard gauge: 7,394 km 1.435-m gauge (2,207 km electrified; 1,236
km double track)
narrow gauge: 176 km 0.760-m gauge (1996)
note: Hungary and Austria jointly manage the cross-border
standard-gauge railway between Gyor, Sopron, Ebenfurt
(Gyor-Sopron-Ebenfurti Vasut Rt) a distance of about 101 km in
Hungary and 65 km in Austria
Highways:
total: 188,203 km
paved: 81,680 km (including 438 km of expressways)
unpaved: 106,523 km (1997 est.)
Waterways: 1,622 km (1988)
Pipelines: crude oil 1,204 km; natural gas 4,387 km (1991)
Ports and harbors: Budapest, Dunaujvaros
Merchant marine:
total: 3 cargo ships (1,000 GRT or over) totaling 16,210 GRT/19,810
DWT (1998 est.)
Airports: 25 (1998 est.)
Airports--with paved runways:
total: 15
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 10
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 3 (1998 est.)
Railways: 0 km
Highways:
total: 12,691 km
paved: 3,262 km
unpaved: 9,429 km (1997 est.)
Ports and harbors: Akureyri, Hornafjordur, Isafjordhur, Keflavik,
Raufarhofn, Reykjavik, Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 13,085 GRT/16,938 DWT
ships by type: chemical tanker 1, container 1, oil tanker 1 (1998
est.)
Airports: 87 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 77
1,524 to 2,437 m: 3
914 to 1,523 m: 21
under 914 m: 53 (1998 est.)
Railways:
total: 62,915 km (12,307 km electrified; 12,617 km double track)
broad gauge: 40,620 km 1.676-m gauge
narrow gauge: 18,501 km 1.000-m gauge; 3,794 km 0.762-m and 0.610-m
gauge (1998 est.)
Highways:
total: 3,319,644 km
paved: 1,517,077 km
unpaved: 1,802,567 km (1996 est.)
Waterways: 16,180 km; 3,631 km navigable by large vessels
Pipelines: crude oil 3,005 km; petroleum products 2,687 km;
natural gas 1,700 km (1995)
Ports and harbors: Calcutta, Chennai (Madras), Cochin, Jawaharal
Nehru, Kandla, Mumbai (Bombay), Vishakhapatnam
Merchant marine:
total: 311 ships (1,000 GRT or over) totaling 6,627,497
GRT/11,038,723 DWT
ships by type: bulk 126, cargo 63, chemical tanker 11, combination
bulk 2, combination ore/oil 3, container 12, liquefied gas tanker
10, oil tanker 76, passenger-cargo 5, short-sea passenger 1,
specialized tanker 2 (1998 est.)
Airports: 341 (1998 est.)
Airports--with paved runways:
total: 230
over 3,047 m: 11
2,438 to 3,047 m: 48
1,524 to 2,437 m: 82
914 to 1,523 m: 70
under 914 m: 19 (1998 est.)
Airports--with unpaved runways:
total: 111
2,438 to 3,047 m: 2
1,524 to 2,437 m: 8
914 to 1,523 m: 50
under 914 m: 51 (1998 est.)
Heliports: 17 (1998 est.)','f950b527517337ce3ba1e6dd2162d7804befd58cd6279b46d50aecc0afe493ca','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eecd6b5f3688e5de0d7df89d02c0a82c1492dfbbc020c87eeeb43532bcb3058',1999,'FR','France','transportation',231,'Railways: 0 km
Highways:
total: 577 km (1995)
paved: NA km
unpaved: NA km
Ports and harbors: Gorey, Saint Aubin, Saint Helier
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Ports and harbors: Johnston Island
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Railways:
total: 275 km
standard gauge: 275 km 1.435-m gauge (262 km electrified; 178 km
double track) (1995)
Highways:
total: 5,137 km
paved: 5,086 km (including 123 km of expressways)
unpaved: 51 km (1996 est.)
note: one source lists roads 2,863 km; expressways 115 km
Waterways: 37 km; Moselle
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine:
total: 37 ships (1,000 GRT or over) totaling 1,033,045 GRT/1,480,023
DWT
ships by type: bulk 1, chemical tanker 6, liquefied gas tanker 13,
oil tanker 6, passenger 4, roll-on/roll-off cargo 6, vehicle carrier
1 (1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 2,724 km
paved: NA km
unpaved: NA km (1994)
Ports and harbors: Fort-de-France, La Trinite
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 704 km (single track); note--owned and operated by government
mining company
standard gauge: 704 km 1.435-m gauge (1995)
Highways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1996 est.)
Waterways: mostly ferry traffic on the Senegal River
Ports and harbors: Bogue, Kaedi, Nouadhibou, Nouakchott, Rosso
Merchant marine: none
Airports: 26 (1998 est.)
Airports--with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 9
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: 114 km
paved: 69 km
unpaved: 45 km (1994 est.)
Ports and harbors: Saint Pierre
Merchant marine: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
914 to 1,523 m: 2 (1998 est.)','110fd2379746403136c8aa1175360327c6d0518e7181426cb7797745b85d41e0','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('420017a99c8d85f492226cf5f1673bfee0c8d148e5f9e5f82c04cce6d1e3eb9f',1999,'CN','China','transportation',239,'Railways:
total: 677 km
narrow gauge: 677 km 1.050-m gauge; note--an additional 110 km
stretch of the old Hejaz railroad is out of use (1998 est.)
Highways:
total: 8,000 km
paved: 8,000 km
unpaved: 0 km (1998 est.)
Pipelines: crude oil 209 km
Ports and harbors: Al ''Aqabah
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 42,746 GRT/59,100 DWT
ships by type: bulk 2, cargo 2, container 1, livestock carrier 1,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 17 (1998 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 9
2,438 to 3,047 m: 4
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Railways:
total: NA km; short line going to a jetty
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 14,400 km in common carrier service; does not include
industrial lines
broad gauge: 14,400 km 1.520-m gauge (3,299 km electrified) (1997)
Highways:
total: 141,000 km
paved: 104,200 km
unpaved: 36,800 km (1997 est.)
Waterways: 3,900 km on the Syrdariya (Syr Darya) and Ertis
(Irtysh)
Pipelines: crude oil 2,850 km; refined products 1,500 km; natural
gas 3,480 km (1992)
Ports and harbors: Aqtau (Shevchenko), Atyrau (Gur''yev), Oskemen
(Ust-Kamenogorsk), Pavlodar, Semey (Semipalatinsk)
Airports: 10 (1997 est.)
Airports--with paved runways:
total: 9
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2 (1997 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1997 est.)
Railways:
total: 2,652 km
narrow gauge: 2,652 km 1.000-m gauge
Highways:
total: 63,800 km
paved: 8,868 km
unpaved: 54,932 km (1996 est.)
Waterways: part of the Lake Victoria system is within the
boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 4,883 GRT/6,255 DWT
ships by type: oil tanker 1, roll-on/roll-off cargo 1 (1998 est.)
Airports: 232 (1998 est.)
Airports--with paved runways:
total: 21
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 14 (1998 est.)
Airports--with unpaved runways:
total: 211
2,438 to 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 113
under 914 m: 83 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and
1938','29dba48c9f009a19bb22f8086ed002532d417ab13da917024dd0a7fce305daad','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9baf549efe4dacfd4677cda81c96907745767063f25819ecd5b81e2f45489996',1999,'SE','Sweden','transportation',248,'Railways:
total: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways:
total: 55,942 km
paved: 21,426 km
unpaved: 34,516 km (1997 est.)
Waterways: 300 km perennially navigable
Pipelines: crude oil 750 km; refined products 780 km; natural gas
560 km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga, Ventspils
Merchant marine:
total: 11 ships (1,000 GRT or over) totaling 42,429 GRT/44,583 DWT
ships by type: cargo 3, oil tanker 4, refrigerated cargo 3,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 50 (1994 est.)
Airports--with paved runways:
total: 36
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 27 (1994 est.)
Airports--with unpaved runways:
total: 14
2,438 to 3,047 m: 2
914 to 1,523 m: 2
under 914 m: 10 (1994 est.)
Railways:
total: 222 km
standard gauge: 222 km 1.435-m (from Beirut to the Syrian border)
Highways:
total: 6,270 km
paved: 6,270 km
unpaved: 0 km (1998 est.)
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Al Batrun, Al Mina'', An Naqurah, Antilyas, Az
Zahrani, Beirut, Jubayl, Juniyah, Shikka, Sidon, Tripoli, Tyre
Merchant marine:
total: 64 ships (1,000 GRT or over) totaling 267,562 GRT/403,252 DWT
ships by type: bulk 6, cargo 41, chemical tanker 1, combination bulk
1, combination ore/oil 1, container 3, livestock carrier 6,
roll-on/roll-off cargo 2, vehicle carrier 3 (1998 est.)
Airports: 9 (1998 est.)
Airports--with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Railways:
total: 2.6 km; note--owned by, operated by, and included in the
statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge (1995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,068 km (1996 est.)
Ports and harbors: none
Airports: 29 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m: 21 (1998 est.)
Railways:
total: 480 km (328 km single track); note--three rail systems owned
and operated by foreign steel and financial interests in conjunction
with the Liberian Government; one of these, the Lamco Railroad,
closed in 1989 after iron ore production ceased; the other two were
shut down by the civil war; large sections of the rail lines have
been dismantled; approximately 60 km of railroad track was exported
for scrap
standard gauge: NA km 1.435-m gauge
narrow gauge: NA km 1.067-m gauge
Highways:
total: 10,037 km (there is major deterioration on all highways due
to lack of maintenance since the civil war began)
paved: 603 km
unpaved: 9,434 km (1996 est.)
Ports and harbors: Buchanan, Greenville, Harper, Monrovia
Merchant marine:
total: 1,651 ships (1,000 GRT or over) totaling 59,804,012
GRT/96,650,752 DWT
ships by type: barge carrier 4, bulk 408, cargo 106, chemical tanker
176, combination bulk 25, combination ore/oil 50, container 193,
liquefied gas tanker 89, multifunction large-load carrier 2, oil
tanker 413, passenger 37, refrigerated cargo 69, roll-on/roll-off
cargo 19, short-sea passenger 3, specialized tanker 12, vehicle
carrier 45
note: a flag of convenience registry; includes ships from 54
countries among which are Germany 186, US 161, Norway 142, Greece
144, Japan 124, Hong Kong 100, China 53, UK 32, Singapore 39, and
Monaco 38 (1998 est.)
Airports: 45 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 43
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 35 (1998 est.)','cd52e525269a294ef08f008530623629c831ef9b49539e01470beed25927360b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3c56ff275f081daaf498f099c3677b0f9327e5c874a1f2faf2bae2f0684eb03',1999,'EG','Egypt','transportation',258,'Railways:
note: Libya has had no railroad in operation since 1965, all
previous systems having been dismantled; current plans are to
construct a 1.435-m standard gauge line from the Tunisian frontier
to Tripoli and Misratah, then inland to Sabha, center of a
mineral-rich area, but there has been no progress; other plans made
jointly with Egypt would establish a rail line from As Sallum,
Egypt, to Tobruk with completion set for mid-1994; no progress has
been reported
Highways:
total: 83,200 km
paved: 47,590 km
unpaved: 35,610 km (1996 est.)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products 443 km
(includes liquefied petroleum gas or LPG 256 km); natural gas 1,947
km
Ports and harbors: Al Khums, Banghazi, Darnah, Marsa al Burayqah,
Misratah, Ra''s Lanuf, Tobruk, Tripoli, Zuwarah
Merchant marine:
total: 30 ships (1,000 GRT or over) totaling 588,928 GRT/989,662 DWT
ships by type: cargo 9, chemical tanker 1, liquefied gas tanker 3,
oil tanker 9, roll-on/roll-off cargo 4, short-sea passenger 4 (1998
est.)
Airports: 143 (1998 est.)
Airports--with paved runways:
total: 60
over 3,047 m: 24
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 5
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 83
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 42
under 914 m: 19 (1998 est.)
Railways:
total: 18.5 km; note--owned, operated, and included in statistics of
Austrian Federal Railways
standard gauge: 18.5 km 1.435-m gauge (electrified)
Highways:
total: 250 km
paved: 250 km
unpaved: 0 km
Ports and harbors: none
Airports: none
Railways:
total: 2,002 km
broad gauge: 2,002 km 1.524-m gauge (122 km electrified) (1994)
Highways:
total: 68,161 km
paved: 60,527 km (including 410 km of expressways)
unpaved: 7,634 km (1997 est.)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 105 km; natural gas 760 km (1992)
Ports and harbors: Kaunas, Klaipeda
Merchant marine:
total: 54 ships (1,000 GRT or over) totaling 316,616 GRT/353,683 DWT
ships by type: cargo 26, combination bulk 11, oil tanker 2, railcar
carrier 1, refrigerated cargo 10, roll-on/roll-off cargo 1,
short-sea passenger 3 (1998 est.)
Airports: 96 (1994 est.)
Airports--with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 14 (1994 est.)
Airports--with unpaved runways:
total: 71
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 63 (1994 est.)','60a195f7af6ec6d57fdf32c5db8b7e63dd0f537d112acc66b47057634784f913','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de7abd4dbeec9744f367c37a2843c1f9e13ecd4f2d65119d0fac58f70c0666f7',1999,'HK','Hong Kong','transportation',268,'Railways: 0 km
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Macau
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: 922 km
standard gauge: 922 km 1.435-m gauge (232 km electrified) (1997)
Highways:
total: 10,591 km
paved: 5,500 km (including 133 km of expressways)
unpaved: 5,091 km (1997 est.)
Waterways: none, lake transport only
Pipelines: 0 km
Ports and harbors: none
Airports: 16 (1998 est.)
Airports--with paved runways:
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (1998 est.)
Airports--with unpaved runways:
total: 6
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)','181a281954c05319d7abd20d43a9d18c208d7b2d524300e43cac22a4d7f4665d','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46a6f3a3db0984db97645ee317785709b1ed4f4f16b1073e7f836ef3a1ecb50',1999,'TH','Thailand','transportation',275,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km; note--Male has 9.6 km of coral highways within the
city (1988 est.)
Ports and harbors: Gan, Male
Merchant marine:
total: 21 ships (1,000 GRT or over) totaling 75,585 GRT/115,590 DWT
ships by type: cargo 18, container 1, oil tanker 1, short-sea
passenger 1 (1998 est.)
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 3 (1998 est.)','629ced46610b83f04dc06d2243c4b2b908239368974a7ed1513b1052f8fb7d88','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('227433f32cc36b3e59e62dd14c23427a2c3f85dd9a24ef564f02bbc7d4769081',1999,'MT','Malta','transportation',284,'Railways: 0 km
Highways:
total: 1,582 km
paved: 1,471 km
unpaved: 111 km (1993 est.)
Ports and harbors: Marsaxlokk, Valletta
Merchant marine:
total: 1,361 ships (1,000 GRT or over) totaling 24,436,956
GRT/40,706,665 DWT
ships by type: bulk 370, cargo 400, chemical tanker 49, combination
bulk 18, combination ore/oil 17, container 56, liquefied gas tanker
2, livestock carrier 3, multifunction large-load carrier 3, oil
tanker 302, passenger 7, refrigerated cargo 46, roll-on/roll-off
cargo 47, short-sea passenger 19, specialized tanker 4, vehicle
carrier 18
note: a flag of convenience registry; includes ships from 49
countries among which includes Greece 445, Russia 51, Switzerland
45, Italy 44, Norway 40, Croatia 26, Turkey 35, Germany 32, Georgia
23, and Monaco 24 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
over 3,047 m: 1 (1998 est.)
Railways:
total: 52 km (27 km electrified)
Highways:
total: 640 km
paved: 320 km
unpaved: 320 km
Ports and harbors: Castletown, Douglas, Peel, Ramsey
Merchant marine:
total: 148 ships (1,000 GRT or over) totaling 4,161,154
GRT/6,880,170 DWT
ships by type: bulk 28, cargo 7, chemical tanker 14, combination
bulk 3, container 20, liquefied gas tanker 14, oil tanker 43,
refrigerated cargo 3, roll-on/roll-off cargo 14, vehicle carrier 2
note: a flag of convenience registry; UK owns 8 ships, Denmark 1,
Sweden 1, Belgium 1, and Netherlands 1 (1998 est.)
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: paved roads on major islands (Majuro, Kwajalein), otherwise
stone-, coral-, or laterite-surfaced roads and tracks
Ports and harbors: Majuro
Merchant marine:
total: 131 ships (1,000 GRT or over) totaling 6,572,915
GRT/11,208,214 DWT
ships by type: bulk 56, cargo 5, chemical tanker 3, container 20,
liquefied gas tanker 2, oil tanker 42, roll-on/roll-off cargo 2,
vehicle carrier 1
note: a flag of convenience registry; includes the ships of Canada
1, China 1, Germany 1, Japan 1, and US 7 (1998 est.)
Airports: 16 (1998 est.)
Airports--with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 12
914 to 1,523 m: 7
under 914 m: 5 (1998 est.)','5b2a906dbca7d8e24eed8017e3ff75ebf6faa3d79d907870809984249c457aee','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('334be9c4a2e3588853f3aa6186db7ef0d91024ffb76d22df497d75817d5c44ed',1999,'MG','Madagascar','transportation',296,'Railways: 0 km
Highways:
total: 1,860 km
paved: 1,732 km (including 30 km of expressways)
unpaved: 128 km (1996 est.)
Ports and harbors: Port Louis
Merchant marine:
total: 17 ships (1,000 GRT or over) totaling 178,846 GRT/236,308 DWT
ships by type: cargo 6, combination bulk 2, container 6, liquefied
gas tanker 1, refrigerated cargo 2
note: a flag of convenience registry; India owns 1 ship (1998 est.)
Airports: 5 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: 2,784 km
paved: 2,187 km
unpaved: 597 km (1987 est.)
Ports and harbors: Le Port, Pointe des Galets
Merchant marine:
total: 1 chemical tanker (l,000 GRT or over) totaling 28,264
GRT/44,885 DWT (1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Railways:
total: 11,376 km
broad gauge: 60 km 1.524-m gauge
standard gauge: 10,889 km 1.435-m gauge (3,723 km electrified; 3,060
km double track)
narrow gauge: 427 km 0.760-m gauge (1994)
Highways:
total: 153,358 km
paved: 78,213 km (including 113 km of expressways)
unpaved: 75,145 km (1996 est.)
Waterways: 1,724 km (1984)
Pipelines: crude oil 2,800 km; petroleum products 1,429 km;
natural gas 6,400 km (1992)
Ports and harbors: Braila, Constanta, Galati, Mangalia, Sulina,
Tulcea
Merchant marine:
total: 199 ships (1,000 GRT or over) totaling 1,996,157
GRT/2,917,895 DWT
ships by type: bulk 35, cargo 141, container 2, oil tanker 7,
passenger 1, passenger-cargo 1, railcar carrier 2, roll-on/roll-off
cargo 9, specialized tanker 1 (1998 est.)
Airports: 27 (1998 est.)
Airports--with paved runways:
total: 21
over 3,047 m: 4
2,438 to 3,047 m: 6
1,524 to 2,437 m: 11 (1998 est.)
Airports--with unpaved runways:
total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 150,000 km; note--87,000 km in common carrier service; 63,000
km serve specific industries and are not available for common
carrier use
broad gauge: 150,000 km 1.520-m gauge (January 1997 est.)
Highways:
total: 948,000 km (including 416,000 km which serve specific
industries or farms and are not maintained by governmental highway
maintenance departments)
paved: 336,000 km
unpaved: 612,000 km (including 411,000 km of graveled or some other
form of surfacing and 201,000 km of unstabilized earth) (1995 est.)
Waterways: total navigable routes in general use 101,000 km;
routes with navigation guides serving the Russian River Fleet 95,900
km; routes with night navigational aids 60,400 km; man-made
navigable routes 16,900 km (January 1994 est.)
Pipelines: crude oil 48,000 km; petroleum products 15,000 km;
natural gas 140,000 km (June 1993 est.)
Ports and harbors: Arkhangel''sk, Astrakhan'', Kaliningrad, Kazan'',
Khabarovsk, Kholmsk, Krasnoyarsk, Moscow, Murmansk, Nakhodka,
Nevel''sk, Novorossiysk, Petropavlovsk-Kamchatskiy, St. Petersburg,
Rostov, Sochi, Tuapse, Vladivostok, Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 617 ships (1,000 GRT or over) totaling 4,146,329
GRT/5,278,909 DWT
ships by type: barge carrier 1, bulk 19, cargo 309, combination bulk
21, combination ore/oil 6, container 25, multifunction large-load
carrier 1, oil tanker 149, passenger 35, passenger-cargo 3,
refrigerated cargo 16, roll-on/roll-off cargo 25, short-sea
passenger 7 (1998 est.)
Airports: 2,517 (1994 est.)
Airports--with paved runways:
total: 630
over 3,047 m: 54
2,438 to 3,047 m: 202
1,524 to 2,437 m: 108
914 to 1,523 m: 115
under 914 m: 151 (1994 est.)
Airports--with unpaved runways:
total: 1,887
over 3,047 m: 25
2,438 to 3,047 m: 45
1,524 to 2,437 m: 134
914 to 1,523 m: 291
under 914 m: 1,392 (1994 est.)
Railways: 0 km
Highways:
total: 12,000 km
paved: 1,000 km
unpaved: 11,000 km (1997 est.)
Waterways: Lac Kivu navigable by shallow-draft barges and native
craft
Ports and harbors: Cyangugu, Gisenyi, Kibuye
Airports: 7 (1998 est.)
Airports--with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
under 914 m: 1 (1998 est.)
Railways:
total: 2,260 km
standard gauge: 492 km 1.435-m gauge
narrow gauge: 1,758 km 1.000-m gauge
dual gauge: 10 km 1.000-m and 1.435-m gauges (three rails) (1993
est.)
Highways:
total: 23,100 km
paved: 18,226 km
unpaved: 4,874 km (1996 est.)
Pipelines: crude oil 797 km; petroleum products 86 km; natural
gas 742 km
Ports and harbors: Bizerte, Gabes, La Goulette, Sfax, Sousse,
Tunis, Zarzis
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 188,345 GRT/215,749 DWT
ships by type: bulk 4, cargo 5, chemical tanker 3, liquefied gas
tanker 1, oil tanker 3, short-sea passenger 3, specialized tanker 1
(1998 est.)
Airports: 32 (1998 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 7 (1998 est.)
Railways:
total: 10,386 km
standard gauge: 10,386 km 1.435-m gauge (1,088 km electrified)
Highways:
total: 382,397 km
paved: 95,599 km (including 1,560 km of expressways)
unpaved: 286,798 km (1997 est.)
Waterways: about 1,200 km
Pipelines: crude oil 1,738 km; petroleum products 2,321 km;
natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun, Istanbul, Izmir,
Kocaeli (Izmit), Icel (Mersin), Samsun, Trabzon
Merchant marine:
total: 531 ships (1,000 GRT or over) totaling 5,913,171
GRT/9,832,994 DWT
ships by type: bulk 159, cargo 239, chemical tanker 32, combination
bulk 5, combination ore/oil 6, container 12, liquefied gas tanker 5,
oil tanker 36, passenger-cargo 1, refrigerated cargo 3,
roll-on/roll-off cargo 21, short-sea passenger 9, specialized tanker
3 (1998 est.)
Airports: 117 (1998 est.)
Airports--with paved runways:
total: 81
over 3,047 m: 16
2,438 to 3,047 m: 25
1,524 to 2,437 m: 19
914 to 1,523 m: 16
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 26 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 2,187 km
broad gauge: 2,187 km 1.520-m gauge (1996 est.)
Highways:
total: 24,000 km
paved: 19,488 km (note--these roads are said to be hard-surfaced,
meaning that some are paved and some are all-weather gravel surfaced)
unpaved: 4,512 km (1996 est.)
Waterways: the Amu Darya is an important inland waterway
Pipelines: crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbashy
Merchant marine:
total: 1 oil tanker (1,000 GRT or over) totaling 1,896 GRT/3,389 DWT
(1998 est.)
Airports: 64 (1994 est.)
Airports--with paved runways:
total: 22
2,438 to 3,047 m: 13
1,524 to 2,437 m: 8
914 to 1,523 m: 1 (1994 est.)
Airports--with unpaved runways:
total: 42
914 to 1,523 m: 7
under 914 m: 35 (1994 est.)','44bd069716b902dbe34728dae54d3aaf786eea323ba9dfb50740a96b469d0930','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d57fc4e3dfcb72419ff532c57336bc1b331cf24a304984a199a55e3a63a681f7',1999,'HN','Honduras','transportation',305,'Railways: 0 km
Highways:
total: 10,100 km
paved: 798 km
unpaved: 9,302 km (1996 est.)
Waterways: Niger river is navigable 300 km from Niamey to Gaya on
the Benin frontier from mid-December through March
Ports and harbors: none
Airports: 27 (1998 est.)
Airports--with paved runways:
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 2 (1998 est.)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1.067-m gauge
standard gauge: 52 km 1.435-m gauge (1995)
note: years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and utility of the
system; a project to restore Nigeria''s railways is now underway
Highways:
total: 51,000 km
paved: 26,000 km (including 2,044 km of expressways)
unpaved: 25,000 km (1998 est.)
note: many of the roads reported as paved may be graveled; because
of poor maintenance and years of heavy freight traffic (in part the
result of the failure of the railroad system), much of the road
system is barely useable
Waterways: 8,575 km consisting of the Niger and Benue rivers and
smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products 3,000 km;
natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port Harcourt, Sapele,
Warri
Merchant marine:
total: 38 ships (1,000 GRT or over) totaling 371,499 GRT/631,425 DWT
ships by type: bulk 1, cargo 13, chemical tanker 3, oil tanker 20,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 72 (1998 est.)
Airports--with paved runways:
total: 36
over 3,047 m: 6
2,438 to 3,047 m: 10
1,524 to 2,437 m: 10
914 to 1,523 m: 8
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 36
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 16
under 914 m: 18 (1998 est.)
Heliports: 1 (1998 est.)','e5b9a7121afc3add5c14011329fdc1c1f0a789e3e93ae49c4adf63e201eecf51','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc0f59a2d6f5656a73884556ab4eb8509163aa3aadeb3dc819cce20bad1ef52',1999,'TO','Tonga','transportation',312,'Railways: 0 km
Highways:
total: 234 km
paved: 0 km
unpaved: 234 km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)','d6ae765187ed1d8b8f79c324843ad072d1cfdc494f3175512894e22fcb5fdac6','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5db705016918a0921ecbddca35f3dcc58c12a4381b742b1afc08dc062c51ec39',1999,'BR','Brazil','transportation',320,'Railways:
total: 971 km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1.000-m gauge
note: there are 470 km of various gauges that are privately owned
Highways:
total: 29,500 km
paved: 2,803 km
unpaved: 26,697 km (1996 est.)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio, Encarnacion
Merchant marine:
total: 21 ships (1,000 GRT or over) totaling 30,287 GRT/32,510 DWT
ships by type: cargo 15, chemical tanker 1, oil tanker 4,
roll-on/roll-off 1 (1998 est.)
Airports: 941 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 931
over 3,047 m: 1
1,524 to 2,437 m: 29
914 to 1,523 m: 349
under 914 m: 552 (1998 est.)
Railways:
total: 2,041 km
standard gauge: 1,726 km 1.435-m gauge
narrow gauge: 315 km 0.914-m gauge (1997)
Highways:
total: 72,146 km
paved: 7,353 km
unpaved: 64,793 km (1998 est.)
Waterways: 8,600 km of navigable tributaries of Amazon system and
208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural gas liquids
64 km
Ports and harbors: Callao, Chimbote, Ilo, Matarani, Paita, Puerto
Maldonado, Salaverry, San Martin, Talara, Iquitos, Pucallpa,
Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the upper reaches
of the Amazon and its tributaries
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 51,518 GRT/75,018 DWT
ships by type: cargo 6, oil tanker 1 (1998 est.)
Airports: 244 (1998 est.)
Airports--with paved runways:
total: 44
over 3,047 m: 7
2,438 to 3,047 m: 15
1,524 to 2,437 m: 12
914 to 1,523 m: 8
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 200
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 24
914 to 1,523 m: 73
under 914 m: 99 (1998 est.)
Railways:
total: 897 km of which 492 km in operation
narrow gauge: 492 km 1.067-m gauge (1996)
Highways:
total: 161,313 km
paved: 290 km
unpaved: 161,023 km (1997)
Waterways: 3,219 km; limited to shallow-draft (less than 1.5 m)
vessels
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro, Cebu, Davao,
Guimaras Island, Iligan, Iloilo, Jolo, Legaspi, Manila, Masao,
Puerto Princesa, San Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 513 ships (1,000 GRT or over) totaling 6,544,029
GRT/10,052,418 DWT
ships by type: bulk 179, cargo 131, chemical tanker 6, combination
bulk 13, container 9, liquefied gas tanker 12, livestock carrier 10,
oil tanker 48, passenger 4, passenger-cargo 13, refrigerated cargo
19, roll-on/roll-off cargo 17, short-sea passenger 31, specialized
tanker 1, vehicle carrier 20
note: a flag of convenience registry; Japan owns 19 ships, Hong Kong
5, Cyprus 1, Denmark 1, Greece 1, Netherlands 1, Singapore 1, and UK
1 (1998 est.)
Airports: 260 (1998 est.)
Airports--with paved runways:
total: 75
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1,523 m: 30
under 914 m: 10 (1998 est.)
Airports--with unpaved runways:
total: 185
1,524 to 2,437 m: 3
914 to 1,523 m: 61
under 914 m: 121 (1998 est.)
Heliports: 1 (1998 est.)
Railways: 0 km
Highways:
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports and harbors: Bounty Bay
Merchant marine: none
Airports: none
Railways:
total: 24,313 km
broad gauge: 652 km 1.520-m gauge
standard gauge: 22,243 km 1.435-m gauge (11,648 km electrified;
8,978 km double track)
narrow gauge: 1,418 km various gauges including 1.000-m, 0.785-m,
0.750-m, and 0.600-m (1996)
Highways:
total: 377,048 km
paved: 247,721 km (including 264 km of expressways)
unpaved: 129,327 km (1997 est.)
Waterways: 3,812 km navigable rivers and canals (1996)
Pipelines: crude oil and petroleum products 2,280 km; natural gas
17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Gliwice, Kolobrzeg, Szczecin,
Swinoujscie, Ustka, Warsaw, Wrocaw
Merchant marine:
total: 61 ships (1,000 GRT or over) totaling 1,162,954 GRT/1,866,462
DWT
ships by type: bulk 53, cargo 3, chemical tanker 2, roll-on/roll-off
cargo 1, short-sea passenger 2 (1998 est.)
Airports: 92 (1998 est.)
Airports--with paved runways:
total: 74
over 3,047 m: 2
2,438 to 3,047 m: 25
1,524 to 2,437 m: 38
914 to 1,523 m: 6
under 914 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 7 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 3,072 km
broad gauge: 2,769 km 1.668-m gauge (528 km electrified; 426 km
double track)
narrow gauge: 303 km 1.000-m gauge (1996)
Highways:
total: 68,732 km
paved: 59,110 km (including 687 km of expressways)
unpaved: 9,622 km (1995 est.)
Waterways: 820 km navigable; relatively unimportant to national
economy, used by shallow-draft craft limited to 300 metric-ton cargo
capacity
Pipelines: crude oil 22 km; petroleum products 58 km; natural gas
700 km
note: the secondary lines for the natural gas pipeline that will be
300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira Islands), Horta
(Azores), Leixoes, Lisbon, Porto, Ponta Delgada (Azores), Praia da
Vitoria (Azores), Setubal, Viana do Castelo
Merchant marine:
total: 132 ships (1,000 GRT or over) totaling 894,640 GRT/1,366,955
DWT
ships by type: bulk 13, cargo 72, chemical tanker 14, container 7,
liquefied gas tanker 7, oil tanker 9, refrigerated cargo 1,
roll-on/roll-off cargo 3, short-sea passenger 4, vehicle carrier 2
note: Portugal has created a captive register on Madeira for
Portuguese-owned ships; ships on the Madeira Register (MAR) will
have taxation and crewing benefits of a flag of convenience (1998
est.)
Airports: 66 (1998 est.)
Airports--with paved runways:
total: 40
over 3,047 m: 5
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 18
under 914 m: 5 (1998 est.)
Airports--with unpaved runways:
total: 26
914 to 1,523 m: 1
under 914 m: 25 (1998 est.)
Railways:
total: 96 km
narrow gauge: 96 km 1.000-m gauge, rural, narrow-gauge system for
hauling sugarcane; no passenger service
Highways:
total: 14,400 km
paved: 14,400 km
unpaved: 0 km (1996 est.)
Ports and harbors: Guanica, Guayanilla, Guayama, Playa de Ponce,
San Juan
Merchant marine: none
Airports: 30 (1998 est.)
Airports--with paved runways:
total: 21
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 6 (1998 est.)
Airports--with unpaved runways:
total: 9
914 to 1,523 m: 2
under 914 m: 7 (1998 est.)','575382bb65cd769b951774d6313631f97f6498c5c25e3406c495bb195e540711','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f628484789a9efce83701d99b81822de13531ad29f9606df6cc2b1910e9d5471',1999,'SC','Seychelles','transportation',328,'Railways: 0 km
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1996 est.)
Ports and harbors: Victoria
Merchant marine: none
Airports: 14 (1998 est.)
Airports--with paved runways:
total: 6
2,438 to 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 8
914 to 1,523 m: 4
under 914 m: 4 (1998 est.)
Railways:
total: 84 km used on a limited basis because the mine at Marampa is
closed
narrow gauge: 84 km 1.067-m gauge
Highways:
total: 11,700 km
paved: 1,287 km
unpaved: 10,413 km (1996 est.)
Waterways: 800 km; 600 km navigable year round
Ports and harbors: Bonthe, Freetown, Pepel
Merchant marine: none
Airports: 10 (1998 est.)
Airports--with paved runways:
total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 8
914 to 1,523 m: 5
under 914 m: 3 (1998 est.)
Heliports: 1 (1998 est.)','a0ef7d793a565dd78aaf5bde8ff89d4e360d53d9ad75f9e882436ba227c50379','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aecd59bcda38cd509cd39ff3137c9f93cdc233d53d5cb74e12373bb541b7330f',1999,'ID','Indonesia','transportation',336,'Railways:
total: 38.6 km
narrow gauge: 38.6 km 1.000-m gauge
note: there is a 67 km mass transit system with 42 stations
Highways:
total: 3,017 km
paved: 2,936 km (including 148 km of expressways)
unpaved: 81 km (1997 est.)
Ports and harbors: Singapore
Merchant marine:
total: 875 ships (1,000 GRT or over) totaling 19,734,146
GRT/31,442,482 DWT
ships by type: bulk 142, cargo 132, chemical tanker 51, combination
bulk 6, combination ore/oil 6, container 154, liquefied gas tanker
27, livestock carrier 1, multifunction large-load carrier 6, oil
tanker 291, refrigerated cargo 8, roll-on/roll-off cargo 11,
short-sea passenger 1, specialized tanker 9, vehicle carrier 30
note: a flag of convenience registry; includes ships from 22
countries among which are Japan 41, Denmark 35, Sweden 28, Thailand
28, Hong Kong 26, Germany 19, Taiwan 19, and Indonesia 11 (1998 est.)
Airports: 9 (1998 est.)
Airports--with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 3,660 km
broad gauge: 102 km 1.520-m gauge
standard gauge: 3,507 km 1.435-m gauge (1424 km electrified)
narrow gauge: 51 km (46 km 1,000-m gauge; 5 km 0.750-m gauge) (1996)
Highways:
total: 38,000 km
paved: 37,500 km (including 280 km of expressways)
unpaved: 500 km (1998 est.)
Waterways: 172 km on the Danube
Pipelines: petroleum products NA km; natural gas 2,700 km
Ports and harbors: Bratislava, Komarno
Merchant marine:
total: 3 cargo ships (1,000 GRT or over) totaling 15,041 GRT/19,517
DWT (1998 est.)
Airports: 15 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (1998 est.)
Railways:
total: 1,201 km
standard gauge: 1,201 km 1.435-m gauge (electrified 489 km) (1998)
Highways:
total: 14,830 km
paved: 12,309 km (including 251 km of expressways)
unpaved: 2,521 km (1997 est.)
Waterways: NA
Pipelines: crude oil 290 km; natural gas 305 km
Ports and harbors: Izola, Koper, Piran
Airports: 14 (1998 est.)
Airports--with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (1998 est.)
Railways: 0 km
Highways:
total: 1,360 km
paved: 34 km
unpaved: 1,326 km (includes about 800 km of private plantation
roads) (1996 est.)
Ports and harbors: Aola Bay, Honiara, Lofung, Noro, Viru Harbor,
Yandina
Merchant marine: none
Airports: 33 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 21 (1998 est.)
Railways: 0 km
Highways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (1996 est.)
Pipelines: crude oil 15 km
Ports and harbors: Bender Cassim (Boosaaso), Berbera, Chisimayu
(Kismaayo), Merca, Mogadishu
Merchant marine: none
Airports: 61 (1998 est.)
Airports--with paved runways:
total: 7
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 54
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 28
under 914 m: 10 (1998 est.)
Railways:
total: 21,431 km
narrow gauge: 20,995 km 1.067-m gauge (9,087 km electrified); 436 km
0.610-m gauge (1995)
Highways:
total: 331,265 km
paved: 137,475 km (including 1,142 km of expressways)
unpaved: 193,790 km (1995 est.)
Pipelines: crude oil 931 km; petroleum products 1,748 km; natural
gas 322 km
Ports and harbors: Cape Town, Durban, East London, Mosselbaai,
Port Elizabeth, Richards Bay, Saldanha
Merchant marine:
total: 9 ships (1,000 GRT or over) totaling 274,797 GRT/270,837 DWT
ships by type: container 6, oil tanker 2, roll-on/roll-off cargo 1
(1998 est.)
Airports: 749 (1998 est.)
Airports--with paved runways:
total: 144
over 3,047 m: 10
2,438 to 3,047 m: 4
1,524 to 2,437 m: 45
914 to 1,523 m: 75
under 914 m: 10 (1998 est.)
Airports--with unpaved runways:
total: 605
1,524 to 2,437 m: 35
914 to 1,523 m: 304
under 914 m: 266 (1998 est.)
Ports and harbors: Grytviken
Airports: none','72ad31f7e2ffe60bc71a734887eeb5fb1db39f8823a1a6a3cbb74d03e266dc67','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72d7dd0ed02ec7929673abedabfbea1efb4239f9108da6600a244f1478e16bb1',1999,'GI','Gibraltar','transportation',344,'Railways:
total: 15,079 km
broad gauge: 12,781 km 1.668-m gauge (6,355 km electrified; 2,295 km
double track)
standard gauge: 525 km 1.435-m gauge (480 km electrified)
narrow gauge: 1,773 km 1.000-m gauge (594 km electrified) (1996)
Highways:
total: 346,858 km
paved: 343,389 km (including 9,063 km of expressways)
unpaved: 3,469 km (1997 est.)
Waterways: 1,045 km, but of minor economic importance
Pipelines: crude oil 265 km; petroleum products 1,794 km; natural
gas 1,666 km
Ports and harbors: Aviles, Barcelona, Bilbao, Cadiz, Cartagena,
Castellon de la Plana, Ceuta, Huelva, La Coruna, Las Palmas (Canary
Islands), Malaga, Melilla, Pasajes, Gijon, Santa Cruz de Tenerife
(Canary Islands), Santander, Tarragona, Valencia, Vigo
Merchant marine:
total: 137 ships (1,000 GRT or over) totaling 1,094,408
GRT/1,695,708 DWT
ships by type: bulk 11, cargo 29, chemical tanker 10, container 10,
liquefied gas tanker 3, oil tanker 25, passenger 1, refrigerated
cargo 6, roll-on/roll-off cargo 35, short-sea passenger 6,
specialized tanker 1 (1998 est.)
Airports: 99 (1998 est.)
Airports--with paved runways:
total: 66
over 3,047 m: 15
2,438 to 3,047 m: 11
1,524 to 2,437 m: 16
914 to 1,523 m: 15
under 914 m: 9 (1998 est.)
Airports--with unpaved runways:
total: 33
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 21 (1998 est.)
Heliports: 2 (1998 est.)
Ports and harbors: none
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)','4e9e02dd2e48d176397b3b003baf5702f619b1635a97dba23780b19051dcbd0e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56233531bc85fbd4e8f910b72be4be2715c987dca98d81271d33be219a73ca20',1999,'IN','India','transportation',358,'Railways:
total: 1,501 km
broad gauge: 1,442 km 1.676-m gauge
narrow gauge: 59 km 0.762-m gauge (1995)
Highways:
total: 99,200 km
paved: 39,680 km
unpaved: 59,520 km (1996 est.)
Waterways: 430 km; navigable by shallow-draft craft
Pipelines: crude oil and petroleum products 62 km (1987)
Ports and harbors: Colombo, Galle, Jaffna, Trincomalee
Merchant marine:
total: 22 ships (1,000 GRT or over) totaling 178,867 GRT/276,363 DWT
ships by type: bulk 1, cargo 14, container 1, oil tanker 1,
refrigerated cargo 5 (1998 est.)
Airports: 13 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 6 (1998 est.)
Airports--with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Railways:
total: 5,516 km
narrow gauge: 4,800 km 1.067-m gauge; 716 km 1.6096-m gauge
plantation line
Highways:
total: 11,900 km
paved: 4,320 km
unpaved: 7,580 km (1996 est.)
Waterways: 5,310 km navigable
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal, Nimule, Port
Sudan, Sawakin
Merchant marine:
total: 4 ships (1,000 GRT or over) totaling 38,093 GRT/49,727 DWT
ships by type: cargo 2, roll-on/roll-off cargo 2 (1998 est.)
Airports: 63 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 51
1,524 to 2,437 m: 14
914 to 1,523 m: 26
under 914 m: 11 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 166 km (single track)
standard gauge: 80 km 1.435-m gauge
narrow gauge: 86 km 1.000-m gauge
Highways:
total: 4,530 km
paved: 1,178 km
unpaved: 3,352 km (1996 est.)
Waterways: 1,200 km; most important means of transport;
oceangoing vessels with drafts ranging up to 7 m can navigate many
of the principal waterways
Ports and harbors: Albina, Moengo, New Nickerie, Paramaribo,
Paranam, Wageningen
Airports: 46 (1998 est.)
Airports--with paved runways:
total: 5
over 3,047 m: 1
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 41
914 to 1,523 m: 7
under 914 m: 34 (1998 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Barentsburg, Longyearbyen, Ny-Alesund,
Pyramiden
Merchant marine: none
Airports: 4 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
under 914 m: 3 (1998 est.)
Railways:
total: 297 km; note--includes 71 km which are not in use
narrow gauge: 297 km 1.067-m gauge
Highways:
total: 3,810 km
paved: NA km
unpaved: NA km (1996 est.)
Ports and harbors: none
Airports: 18 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 17
914 to 1,523 m: 7
under 914 m: 10 (1998 est.)
Railways:
total: 13,415 km (includes 3,594 km of privately-owned railways)
standard gauge: 13,415 km 1.435-m gauge (7,917 km electrified and
1,152 km double track) (1996)
Highways:
total: 138,000 km
paved: 105,018 km (including 1,330 km of expressways)
unpaved: 32,982 km (1996 est.)
Waterways: 2,052 km navigable for small steamers and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavle, Goteborg, Halmstad, Helsingborg,
Hudiksvall, Kalmar, Karlshamn, Malmo, Solvesborg, Stockholm,
Sundsvall
Merchant marine:
total: 154 ships (1,000 GRT or over) totaling 1,894,783
GRT/1,528,077 DWT
ships by type: bulk 6, cargo 28, chemical tanker 28, combination
ore/oil 4, liquefied gas tanker 1, oil tanker 24, railcar carrier 1,
refrigerated cargo 1, roll-on/roll-off cargo 39, short-sea passenger
5, specialized tanker 4, vehicle carrier 13 (1998 est.)
Airports: 255 (1998 est.)
Airports--with paved runways:
total: 145
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 82
914 to 1,523 m: 27
under 914 m: 24 (1998 est.)
Airports--with unpaved runways:
total: 110
914 to 1,523 m: 5
under 914 m: 105 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 4,479 km (1,564 km double track)
standard gauge: 3,304 km 1.435-m gauge (3,288 km electrified)
narrow gauge: 1,165 km 1.000-m gauge (1,057 km electrified); 10 km
0.750-m or 0.800-m gauge (1996)
Highways:
total: 71,048 km (including 1,613 km of expressways)
paved: NA km
unpaved: NA km (1997 est.)
Waterways: 65 km; Rhine (Basel to Rheinfelden, Schaffhausen to
Bodensee); 12 navigable lakes
Pipelines: crude oil 314 km; natural gas 1,506 km
Ports and harbors: Basel
Merchant marine:
total: 20 ships (1,000 GRT or over) totaling 412,459 GRT/724,995 DWT
ships by type: bulk 13, cargo 1, chemical tanker 5, oil tanker 1
(1998 est.)
Airports: 67 (1998 est.)
Airports--with paved runways:
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 12
914 to 1,523 m: 7
under 914 m: 15 (1998 est.)
Airports--with unpaved runways:
total: 25
under 914 m: 25 (1998 est.)
Railways:
total: 1,998 km
broad gauge: 1,766 km 1.435-m gauge
narrow gauge: 232 km 1.050-m gauge
Highways:
total: 41,451 km
paved: 9,575 km (including 877 km of expressways)
unpaved: 31,876 km (1997 est.)
Waterways: 870 km; minimal economic importance
Pipelines: crude oil 1,304 km; petroleum products 515 km
Ports and harbors: Baniyas, Jablah, Latakia, Tartus
Merchant marine:
total: 131 ships (1,000 GRT or over) totaling 401,407 GRT/578,081 DWT
ships by type: bulk 11, cargo 115, livestock carrier 4,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 104 (1998 est.)
Airports--with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 80
1,524 to 2,437 m: 3
914 to 1,523 m: 14
under 914 m: 63 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 4,600 km (519 km electrified); note--1,108 km belongs to the
Taiwan Railway Administration and the remaining 3,492 km is
dedicated to industrial use
narrow gauge: 4,600 km 1.067-m
Highways:
total: 19,634 km
paved: 17,171 km (including 548 km of expressways)
unpaved: 2,463 km (1997)
Pipelines: petroleum products 615 km; natural gas 97 km
Ports and harbors: Chi-lung (Keelung), Hua-lien, Kao-hsiung,
Su-ao, T''ai-chung
Merchant marine:
total: 180 ships (1,000 GRT or over) totaling 5,106,573
GRT/7,963,834 DWT
ships by type: bulk 47, cargo 30, combination bulk 3, container 72,
oil tanker 17, refrigerated cargo 9, roll-on/roll-off cargo 2 (1998
est.)
Airports: 39 (1998 est.)
Airports--with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 12
1,524 to 2,437 m: 6
914 to 1,523 m: 6
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (1998 est.)
Heliports: 2 (1998 est.)
Railways:
total: 480 km in common carrier service; does not include industrial
lines (1990)
Highways:
total: 13,700 km
paved: 11,330 km (note--these roads are said to be hard-surfaced,
meaning that some are paved and some are all-weather gravel surfaced)
unpaved: 2,370 km (1996 est.)
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports: 59 (1994 est.)
Airports--with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (1994 est.)
Airports--with unpaved runways:
total: 45
914 to 1,523 m: 9
under 914 m: 36 (1994 est.)
Railways:
total: 3,569 km (1995)
narrow gauge: 2,600 km 1.000-m gauge; 969 km 1.067-m gauge
note: the Tanzania-Zambia Railway Authority (TAZARA), which operates
1,860 km of 1.067-m narrow gauge track between Dar es Salaam and
Kapiri Mposhi in Zambia (of which 969 km are in Tanzania and 891 km
are in Zambia) is not a part of Tanzania Railways Corporation;
because of the difference in gauge, this system does not connect to
Tanzania Railways
Highways:
total: 88,200 km
paved: 3,704 km
unpaved: 84,496 km (1996 est.)
Waterways: Lake Tanganyika, Lake Victoria, Lake Nyasa
Pipelines: crude oil 982 km
Ports and harbors: Bukoba, Dar es Salaam, Kigoma, Kilwa Masoko,
Lindi, Mtwara, Mwanza, Pangani, Tanga, Wete, Zanzibar
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 20,618 GRT/26,321 DWT
ships by type: cargo 2, oil tanker 2, passenger-cargo 2,
roll-on/roll-off cargo 1 (1998 est.)
Airports: 129 (1998 est.)
Airports--with paved runways:
total: 10
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 119
over 3,047 m: 1
1,524 to 2,437 m: 18
914 to 1,523 m: 65
under 914 m: 35 (1998 est.)
Railways:
total: 4,623 km
narrow gauge: 4,623 km 1.000-m gauge (99 km double track)
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1,615 km (1996 est.)
Waterways: 3,999 km principal waterways; 3,701 km with navigable
depths of 0.9 m or more throughout the year; numerous minor
waterways navigable by shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas 350 km
Ports and harbors: Bangkok, Laem Chabang, Pattani, Phuket,
Sattahip, Si Racha, Songkhla
Merchant marine:
total: 293 ships (1,000 GRT or over) totaling 1,848,626
GRT/2,989,382 DWT
ships by type: bulk 41, cargo 135, chemical tanker 5, combination
bulk 1, container 13, liquefied gas tanker 17, multifunction
large-load carrier 3, oil tanker 61, passenger 1, refrigerated cargo
11, roll-on/roll-off cargo 2, short-sea passenger 1, specialized
tanker 2 (1998 est.)
Airports: 107 (1998 est.)
Airports--with paved runways:
total: 56
over 3,047 m: 6
2,438 to 3,047 m: 9
1,524 to 2,437 m: 17
914 to 1,523 m: 20
under 914 m: 4 (1998 est.)
Airports--with unpaved runways:
total: 51
1,524 to 2,437 m: 1
914 to 1,523 m: 15
under 914 m: 35 (1998 est.)
Heliports: 3 (1998 est.)
Railways:
total: 525 km (1995)
narrow gauge: 525 km 1.000-m gauge
Highways:
total: 7,520 km
paved: 2,376 km
unpaved: 5,144 km (1996 est.)
Waterways: 50 km Mono river
Ports and harbors: Kpeme, Lome
Merchant marine: none
Airports: 9 (1998 est.)
Airports--with paved runways:
total: 2
2,438 to 3,047 m: 2 (1998 est.)
Airports--with unpaved runways:
total: 7
914 to 1,523 m: 5
under 914 m: 2 (1998 est.)
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; offshore anchorage only
Merchant marine: none
Airports: none; lagoon landings by amphibious aircraft from
Western Samoa
Railways: 0 km
Highways:
total: 680 km
paved: 184 km
unpaved: 496 km (1996 est.)
Ports and harbors: Neiafu, Nuku''alofa, Pangai
Merchant marine:
total: 7 ships (1,000 GRT or over) totaling 17,754 GRT/25,969 DWT
ships by type: bulk 1, cargo 2, chemical tanker 1, liquefied gas
tanker 2, roll-on/roll-off cargo 1 (1998 est.)
Airports: 6 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (1998 est.)
Railways: minimal agricultural railroad system near San Fernando;
railway service was discontinued in 1968
Highways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1996 est.)
Pipelines: crude oil 1,032 km; petroleum products 19 km; natural
gas 904 km
Ports and harbors: Pointe-a-Pierre, Point Fortin, Point Lisas,
Port-of-Spain, Scarborough, Tembladora
Merchant marine:
total: 1 cargo ship (1,000 GRT or over) totaling 1,336 GRT/2,567 DWT
(1998 est.)
Airports: 6 (1998 est.)
Airports--with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 1
under 914 m: 2 (1998 est.)','390c7054da9c48f2dbbdc22ec46b7699c01b0da4994de3571e27d21074cf429c','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b9a7ac9400a5e61d538ac4455ad45607d4259b5b26852c70c76008eb978e76',1999,'TM','Turkmenistan','transportation',368,'Railways: 0 km
Highways:
total: 121 km
paved: 24 km
unpaved: 97 km
Ports and harbors: Grand Turk, Providenciales
Merchant marine: none
Airports: 7 (1998 est.)
Airports--with paved runways:
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)','5550ca036e08a04be383d3074b9c2f98a301bc2439171f506d586039f5103b1f','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c60f83b8d486169ded77672388756e4fc86a21b1ea42f3d28be5116611906d',1999,'TC','Turks and Caicos Islands','transportation',373,'Railways:
total: 16,878 km
broad gauge: 342 km 1.600-m gauge (190 km double track); note--all
1.600-m gauge track, of which 342 km is in common carrier use, is in
Northern Ireland
standard gauge: 16,536 km 1.435-m gauge (4,928 km electrified;
12,591 km double or multiple track) (1996)
Highways:
total: 372,000 km
paved: 372,000 km (including 3,270 km of expressways)
unpaved: 0 km (1996 est.)
Waterways: 3,200 km
Pipelines: crude oil (almost all insignificant) 933 km; petroleum
products 2,993 km; natural gas 12,800 km
Ports and harbors: Aberdeen, Belfast, Bristol, Cardiff, Dover,
Falmouth, Felixstowe, Glasgow, Grangemouth, Hull, Leith, Liverpool,
London, Manchester, Peterhead, Plymouth, Scapa Flow, Sullom Voe,
Tees, Tyne
Merchant marine:
total: 155 ships (1,000 GRT or over) totaling 2,460,361
GRT/2,517,875 DWT
ships by type: bulk 3, cargo 29, chemical tanker 6, combination
ore/oil 1, container 25, liquefied gas tanker 1, oil tanker 51,
passenger 8, passenger-cargo 1, roll-on/roll-off cargo 17, short-sea
passenger 12, specialized tanker 1 (1998 est.)
Airports: 497 (1998 est.)
Airports--with paved runways:
total: 356
over 3,047 m: 10
2,438 to 3,047 m: 32
1,524 to 2,437 m: 169
914 to 1,523 m: 91
under 914 m: 54 (1998 est.)
Airports--with unpaved runways:
total: 141
1,524 to 2,437 m: 1
914 to 1,523 m: 23
under 914 m: 117 (1998 est.)
Heliports: 12 (1998 est.)','afae3149a80ca9a17963614fbb574eeffb624b407fde0ad622113dba6a4db26b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39877dec7954ef54e3189ad62e65632fb1a91d12889c16a3c6e2fa6599f73cde',1999,'ES','Spain','transportation',381,'Railways:
total: 2,994 km
standard gauge: 2,073 km 1.435-m gauge (921 km closed) (1997)
Highways:
total: 8,420 km
paved: 7,578 km
unpaved: 842 km (1996 est.)
Waterways: 1,600 km; used by coastal and shallow-draft river craft
Ports and harbors: Fray Bentos, Montevideo, Nueva Palmira,
Paysandu, Punta del Este, Colonia, Piriapolis
Merchant marine:
total: 2 oil tankers (1,000 GRT or over) totaling 44,042 GRT/83,684
DWT (1998 est.)
Airports: 65 (1998 est.)
Airports--with paved runways:
total: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 50
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 33 (1998 est.)
Railways:
total: 3,380 km in common carrier service; does not include
industrial lines
broad gauge: 3,380 km 1.520-m gauge (300 km electrified) (1993)
Highways:
total: 81,600 km
paved: 71,237 km (note--these roads are said to be hard surfaced,
meaning that some are paved and some are all-weather gravel surfaced)
unpaved: 10,363 km dirt (1996 est.)
Waterways: 1,100 (1990)
Pipelines: crude oil 250 km; petroleum products 40 km; natural
gas 810 km (1992)
Ports and harbors: Termiz (Amu Darya river)
Airports: 3 (1997 est.)
Airports--with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m: 1 (1997 est.)
Railways: 0 km
Highways:
total: 1,070 km
paved: 256 km
unpaved: 814 km (1996 est.)
Ports and harbors: Forari, Port-Vila, Santo (Espiritu Santo)
Merchant marine:
total: 82 ships (1,000 GRT or over) totaling 1,327,078 GRT/1,764,558
DWT
ships by type: bulk 31, cargo 24, chemical tanker 3, combination
bulk 1, liquefied gas tanker 4, oil tanker 2, refrigerated cargo 11,
vehicle carrier 6
note: a flag of convenience registry; includes ships from 15
countries among which are ships of Japan 28, India 10, US 10, Greece
3, Hong Kong 3, Australia 2, Canada 1, China 1, and France 1 (1998
est.)
Airports: 32 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 29
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 17 (1998 est.)','f4a01ce1e5a815e748346852adc08dc7d207fab2de61c5e7930bf958104e4c7a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1256a84a144c1b16647652031e6246d56d5e7a18ae1c082a49def906a7bb4c0e',1999,'NC','New Caledonia','transportation',395,'Railways:
total: 584 km (248 km privately owned)
standard gauge: 584 km 1.435-m gauge
Highways:
total: 84,300 km
paved: 33,214 km
unpaved: 51,086 km (1996 est.)
Waterways: 7,100 km; Rio Orinoco and Lago de Maracaibo accept
oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products 480 km; natural
gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El Tablazo, La Guaira, La
Salina, Maracaibo, Matanzas, Palua, Puerto Cabello, Puerto la Cruz,
Puerto Ordaz, Puerto Sucre, Punta Cardon
Merchant marine:
total: 32 ships (1,000 GRT or over) totaling 535,882 GRT/937,461 DWT
ships by type: bulk 5, cargo 9, combination bulk 1, liquefied gas
tanker 2, oil tanker 8, passenger-cargo 1, roll-on/roll-off cargo 5,
short-sea passenger 1 (1998 est.)
Airports: 371 (1998 est.)
Airports--with paved runways:
total: 122
over 3,047 m: 5
2,438 to 3,047 m: 10
1,524 to 2,437 m: 32
914 to 1,523 m: 59
under 914 m: 16 (1998 est.)
Airports--with unpaved runways:
total: 249
1,524 to 2,437 m: 10
914 to 1,523 m: 94
under 914 m: 145 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 2,835 km (in addition, there are 224 km not restored to
service after war damage)
standard gauge: 151 km 1.435-m gauge
narrow gauge: 2,454 km 1.000-m gauge
dual gauge: 230 km NA-m gauges (three rails)
Highways:
total: 93,300 km
paved: 23,418 km
unpaved: 69,882 km (1996 est.)
Waterways: 17,702 km navigable; more than 5,149 km navigable at
all times by vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang, Haiphong, Ho Chi Minh City,
Hong Gai, Qui Nhon, Nha Trang
Merchant marine:
total: 123 ships (1,000 GRT or over) totaling 527,920 GRT/820,515 DWT
ships by type: bulk 7, cargo 98, chemical tanker 1, combination bulk
1, oil tanker 12, refrigerated cargo 4 (1998 est.)
Airports: 48 (1994 est.)
Airports--with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 7 (1994 est.)
Airports--with unpaved runways:
total: 12
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 5 (1994 est.)
Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports and harbors: Charlotte Amalie, Christiansted, Cruz Bay,
Port Alucroix
Merchant marine: none
Airports: 2
note: international airports on Saint Thomas and Saint Croix; there
is an airfield on St. John (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 2 (1998 est.)
Ports and harbors: none; two offshore anchorages for large ships
Airports: 1 (1998 est.)
Airports--with paved runways:
total: 1
2,438 to 3,047 m: 1 (1998 est.)
Transportation--note: formerly an important commercial aviation
base, now occasionally used by US military, some commercial cargo
planes, and for emergency landings
Railways: 0 km
Highways:
total: 120 km (Ile Uvea 100 km, Ile Futuna 20 km)
paved: 16 km (all on Ile Uvea)
unpaved: 104 km (Ile Uvea 84 km, Ile Futuna 20 km)
Waterways: none
Ports and harbors: Leava, Mata-Utu
Merchant marine:
total: 2 ships (1,000 GRT or over) totaling 44,160 GRT/41,656 DWT
ships by type: oil tanker 1, passenger 1 (1998 est.)
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 1
1,524 to 2,437 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 1
914 to 1,523 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 4,500 km
paved: 2,700 km
unpaved: 1,800 km (1997 est.)
note: Israelis have developed many highways to service Jewish
settlements
Ports and harbors: none
Airports: 2 (1998 est.)
Airports--with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (1998 est.)
Railways: 0 km
Highways:
total: 6,200 km
paved: 1,350 km
unpaved: 4,850 km (1991 est.)
Ports and harbors: Ad Dakhla, Cabo Bojador, Laayoune (El Aaiun)
Airports: 12 (1998 est.)
Airports--with paved runways:
total: 3
2,438 to 3,047 m: 3 (1998 est.)
Airports--with unpaved runways:
total: 9
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 3 (1998 est.)
Heliports: 1 (1998 est.)
Railways:
total: 1,201,337 km includes about 190,000 to 195,000 km of
electrified routes of which 147,760 km are in Europe, 24,509 km in
the Far East, 11,050 km in Africa, 4,223 km in South America, and
4,160 km in North America; note--fastest speed in daily service is
300 km/hr attained by France''s Societe Nationale des Chemins-de-Fer
Francais (SNCF) Le Train a Grande Vitesse (TGV)--Atlantique line
broad gauge: 251,153 km
standard gauge: 710,754 km
narrow gauge: 239,430 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki, Kobe, Marseille,
Mina'' al Ahmadi (Kuwait), New Orleans, New York, Rotterdam, Yokohama
Merchant marine:
total: 28,310 ships (1,000 GRT or over) totaling 495,299,489
GRT/764,129,056 DWT
ships by type: barge carrier 23, bulk 5,745, cargo 8,766, chemical
tanker 1,326, combination bulk 319, combination ore/oil 227,
container 2,615, liquefied gas tanker 802, livestock carrier 60,
multifunction large-load carrier 90, oil tanker 4,521, passenger
392, passenger-cargo 126, railcar carrier 19, refrigerated cargo
1,067, roll-on/roll-off cargo 1,117, short-sea passenger 484,
specialized tanker 118, vehicle carrier 493 (1998 est.)
Railways: 0 km
Highways:
total: 64,725 km
paved: 5,243 km
unpaved: 59,482 km (1996 est.)
Pipelines: crude oil 644 km; petroleum products 32 km
Ports and harbors: Aden, Al Hudaydah, Al Mukalla, As Salif,
Mocha, Nishtun
Merchant marine:
total: 3 ships (1,000 GRT or over) totaling 12,059 GRT/18,563 DWT
ships by type: cargo 1, oil tanker 2 (1998 est.)
Airports: 48 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 10
914 to 1,523 m: 12
under 914 m: 3 (1998 est.)
Railways:
total: 2,164 km (1995)
narrow gauge: 2,164 km 1.067-m gauge (13 km double track)
note: the total includes 891 km of the Tanzania-Zambia Railway
Authority (TAZARA), which operates 1,860 km of 1.067-m narrow gauge
track between Dar es Salaam and Kapiri Mposhi where it connects to
the Zambia Railways system; TAZARA is not a part of Zambia Railways
Highways:
total: 39,700 km
paved: 7,265 km (including 60 km of expressways)
unpaved: 32,435 km (1996 est.)
Waterways: 2,250 km, including Zambezi and Luapula rivers, Lake
Tanganyika
Pipelines: crude oil 1,724 km
Ports and harbors: Mpulungu
Airports: 112 (1998 est.)
Airports--with paved runways:
total: 12
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 2
under 914 m: 1 (1998 est.)
Airports--with unpaved runways:
total: 100
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 66
under 914 m: 31 (1998 est.)
Railways:
total: 2,759 km (1995)
narrow gauge: 2,759 km 1.067-m gauge (313 km electrified; 42 km
double track) (1995 est.)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1996 est.)
Waterways: the Mazoe and Zambezi rivers are used for transporting
chrome ore from Harare to Mozambique
Pipelines: petroleum products 212 km
Ports and harbors: Binga, Kariba
Airports: 467 (1998 est.)
Airports--with paved runways:
total: 18
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 9 (1998 est.)
Airports--with unpaved runways:
total: 449
1,524 to 2,437 m: 4
914 to 1,523 m: 220
under 914 m: 225 (1998 est.)','3aee2884ca4b05ff5666f85a9b48a8cdce1f0272f037c857087296494b829b84','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('457e6dab782ae58ded9c949aa1c89324ab58065de75cfdacf9afad7acc829b49',1999,'AU','Australia','introduction',90,'Background: Australia became a British
commonwealth in 1901. Blessed by rich natural
resources, the country enjoyed rapid gains in herding,
agriculture, and manufacturing and made a major
contribution to the British effort in World Wars I and II.
Australia subsequently developed its minerals,
metals, and fossil fuel markets, all of which have
become key Australian exports. Long-term concerns
include pollution, particularly depletion of the ozone
layer, and management and conservation of coastal
areas, especially the Great Barrier Reef. Sydney will
host the 2000 summer Olympics.
Background: Once the center of power for the large
Austro-Hungarian empire, Austria was reduced to a
small republic after its defeat in World War I. After the
annexation to Nazi Germany in 1938 and subsequent
occupation by the victorious Allied powers, Austria''s
1955 State Treaty declared the country "permanently
neutral" as a condition of the Soviet military
withdrawal. The Soviet collapse relieved the external
pressure to remain unaligned, but neutrality had
evolved into a part of Austrian cultural identity, which
has led to an ongoing public debate over whether
Vienna legitimately can remain outside of European
security structures. A wealthy country, Austria joined
the European Union in 1995 and, like many EU
members, is adjusting to the new European currency
and struggling with high unemployment.','b5df1ff562020c002160d99dd521f51465ebfa9d840ca1a9708f6f72514eee6e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef83ede84df843c9e5b144e1cfe2295d2b6a577d01540e3953d47f1a7e4aabf9',1999,'AZ','Azerbaijan','introduction',99,'Background: In 1 806, Azerbaijan, a region of Turkic
Muslim people, was conquered by the Russians. In
1918, Azerbaijan declared independence from
Russia, but was incorporated into the Soviet Union in
1920. It again declared its independence in 1991 ,
following the collapse of the USSR. The conflict
between Azerbaijan and Armenia over the
Nagorno-Karabakh region is still unresolved after 10
years and Baku has yet to settle disputes with its
neighbors over oil rights in the Caspian Sea. During
the war, Karabakh Armenians declared independence
and seized almost 20% of the country''s territory,
creating some 750,000 Azerbaijani refugees in the
process. Both sides have generally observed a
Russian-mediated cease-fire in place since May
1994.','f3d8487bc63347dfe00853c6e273ad811322079a62ecd3e603aa8ad3ecb0da55','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('046530b1a9caeba39705a0f4dcce735ef8417e382058e5b392f6dd845f29ab3c',1999,'BY','Belarus','introduction',146,'Background: For centuries Byelorussia has been
fought over, devastated, and partitioned among
Russia, Poland, Lithuania, and, in World Wars I and II,
Germany. After seven decades as a Soviet republic,
the newly named Belarus declared its independence
in August 1991 . It has retained closer political and
economic ties to Russia than any of the other former
Soviet republics. On 25 December 1998, Russian
President Boris YELTSIN and Belarusian President
Aleksandr LUKASHENKO signed several agreements
intended to provide greater political, economic, and
social integration while preserving both states''
sovereignty.','9eb9ecebfb783c98de16059257007707f09e1f7184d4a3ca5a8f7b853e2763f3','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c1e1b5ab69da4014afdfb7f9bacc93d249cce2b8ac327a234c6722af5f38406',1999,'DE','Germany','introduction',156,'Background: Belgium became independent from
the Netherlands in 1830 and was occupied by
Germany during World Wars I and II. In the half
century following, it has prospered as a small,
modern, technologically advanced European state
and member of the European Union. Its unique
political circumstance is the long-standing differences
between the wealthier Dutch-speaking Flemings of
the north and the poorer French-speaking Walloons of
the south, differences that are becoming increasingly
acute.
Background: Germany - first united in 1871 -
suffered defeats in successive world wars and was
occupied by the victorious Allied powers of the US,
UK, France, and the Soviet Union in 1945. With the
beginning of the Cold War and increasing tension
between the US and Soviet Union, two German states
were formed in 1 949: the western Federal Republic of
Germany (FRG) and the eastern German Democratic
Republic (GDR). The newly democratic FRG
embedded itself in key Western economic and
security organizations, the EU and NATO, while the
Communist GDR was on the front line of the
Soviet-led Warsaw Pact. The decline of the Soviet
Unionandendofthe Cold War cleared the path for the
fall of the Berlin Wall in 1989 and German
re-unification in 1990. Germany has expended
considerable funds - roughly $100 billion a year - in
subsequent years working to bring eastern
productivity and wages up to western standards, with
mixed results. Unemployment - which in the east is
nearly double that in the west - has grown over the last
several years, primarily as a result of structural
problems like an inflexible labor market. In January
1999, Germany and 10 other members of the EU
formed a common European currency, the euro, and
the German government is now looking toward reform
of the EU budget and enlargement of the Union into
Central Europe.','dc857b10aafb6e8a7d91d783f2ae7fd1d3fcb05345bbcb4c2dc1183597041669','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0896dc6c21bf3ef43138597eadd60f4b6978760fff8fd18a437bf57194591a2a',1999,'BR','Brazil','introduction',197,'Background: On 21 November 1995, in Dayton,
Ohio, the former Yugoslavia''s three warring parties
signed a peace agreement that brought to a halt over
three years of interethnic civil strife in Bosnia and
Herzegovina (the final agreement was signed in Paris
on 14 December 1995). The Dayton Agreement,
signed then by Bosnian President IZETBEGOVIC,
Croatian President TUDJMAN, and Serbian President
MILOSEVIC, divides Bosnia and Herzegovina roughly
equally between the Muslim/Croat Federation and the
Republika Srpska while maintaining Bosnia''s currently
recognized borders. In 1995-96, a NATO-led
international peacekeeping force (IFOR) of 60,000
troops served in Bosnia to implement and monitor the
military aspects of the agreement. IFOR was
succeeded by a smaller, NATO-led Stabilization
Force (SFOR) whose mission is to deter renewed
hostilities. SFOR remains in place. A High
Representative appointed by the UN Security Council
is responsible for civilian implementation of the
accord, including monitoring implementation,
facilitating any difficulties arising in connection with
civilian implementation, and coordinating activities of
the civilian organizations and agencies in Bosnia. The
Bosnian conflict began in the spring of 1 992 when the
government of Bosnia and Herzegovina held a
referendum on independence and the Bosnian Serbs
- supported by neighboring Serbia - responded with
armed resistance aimed at partitioning the republic
along ethnic lines and joining Serb-held areas to form
a “greater Serbia." In March 1994, Bosnia''s Muslims
and Croats reduced the number of warring factions
from three to two by signing an agreement in
Washington creating their joint Muslim/Croat
Federation of Bosnia and Herzegovina. The
Federation, formed by the Muslims and Croats in
March 1 994, is one of two entities (the other being the
Bosnian Serb-led Republika Srpska) that comprise
Bosnia and Herzegovina.','776a837c3ab31e6ccd7b72530ba9e69aa5f575c0bf8cb8c2aaf0ac8fd2ed0377','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb6681d209bea58474e6ded631c9d8c25cc4334233ac7e88b6e0df9d165d2404',1999,'IO','British Indian Ocean Territory','introduction',214,'Background: A Slavic state, Bulgaria achieved
independence in 1908 after 500 years of Ottoman
rule. Bulgaria fought on the losing side in both World
Wars. After World War II it fell within the Soviet sphere
of influence. Communist domination ended in 1991
with the dissolution of the USSR, and Bulgaria began
the contentious process of moving toward political
democracy and a market economy. In addition to the
problems of structural economic reform, particularly
privatization, Bulgaria faces the serious issues of
keeping inflation under control and unemployment,
combatting corruption, and curbing black-market and
mafia-style crime.','cd9443b13cf43b98600929b68db639e39effcce03ecb3d555c775e1c293b11be','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a4640db07f18a18422b51936ada0599af7cbb6333d055236cfae0cb3c3a5283',1999,'CA','Canada','introduction',232,'Background: A land of vast distances and rich
natural resources, from 1867 on Canada has enjoyed
de facto independence while retaining, even to the
present day, certain formal ties to the British crown.
Economically and technologically the nation has
developed in parallel with the US, its neighbor to the
south across an unfortified border. Its paramount
political problem continues to be the relationship of the
province of Quebec, with its French-speaking
residents and unique culture, to the remainder of the
country.','21fa990e92d48dd56c876d093ceec1df8cab15cfb2dabd40c3fd4c401f3be741','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('254b62763873e7b3418d8450afc8f722001f9d4bb0d15233663f636a4155c530',1999,'CN','China','introduction',265,'Background: For most of its 3,500 years of history,
China led the world in agriculture, crafts, and science,
then fell behind in the 1 9th century when the Industrial
Revolution gave the West clear superiority in military
and economic affairs. In the first half of the 20th
century, China continued to suffer from major
famines, civil unrest, military defeat, and foreign
occupation. After World War II , the Communists under
MAO Zedong established a dictatorship that, while
ensuring China''s autonomy, imposed strict controls
over all aspects of life and cost the lives of tens of
millions of people. After 1978, his successor DENG
Xiaoping decentralized economic decision making;
output quadrupled in the next 20 years. Political
controls remain tight at the same time economic
controls have been weakening. Present issues are:
incorporating Hong Kong into the Chinese system;
closing down inefficient state-owned enterprises;
modernizing the military; fighting corruption; and
providing support to tens of millions of displaced
workers.','4afdb523318755a665c6442054646577561f621fef03e86064c1412802820bf4','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eca249be8b06ced89ccac209cc0cef9004be5defa96e89391999d1d1d684100e',1999,'CO','Colombia','introduction',299,'Background: Comoros has had difficulty in
achieving political stability, having endured 18 coups
or attempted coups since receiving independence
from France in 1975. Most recently, in August 1997,
the islands of Anjouan and Moheli declared their
independence from Comoros. An attempt in
September 1997 by the government to reestablish
control over the rebellious islands by force failed, and
presently the Organization of African Unity is
brokering negotiations to effect a reconciliation.','7a8410a7b5c0f98472c353d91f15f5c7d02da9ddb10ca4f10c627dd067e573a1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9de22884057a7a90c4c25d962a1d495fc37606fd4cca6fe421545fe2e4231493',1999,'CK','Cook Islands','introduction',310,'Background: Named after Captain Cook, who
sighted them in 1770, the islands became a British
protectorate in 1888. By 1900, administrative control
was transferred to New Zealand. Residents chose
self-government with free association with New
Zealand in 1965. The emigration of Cook Islanders to
New Zealand in large numbers and resulting loss of
skilled labor and government deficits are continuing
problems.','4fc0449c9f20a176c6a94efb302626507f7aeb0a100795490458c974464068c1','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3634ebc6970a2d35e392dea1cbd60852ad75100a2ee285cedd2ac696461a99f9',1999,'CU','Cuba','introduction',335,'Background: Fidel CASTRO led a rebel army to
victory in 1959, and his guiding vision has defined
Cuba''s Communist revolution while his iron will has
held the country together for more than four decades.
CASTRO brought Cuba onto the world stage by
inviting Soviet support in the 1960s, inciting
revolutionary movements throughout Latin America
and Africa in the 1 970s, and sending his army to fight
in Angola in the 1980s. At home, Havana provided
Cubans with high levels of healthcare, education, and
social security while suppressing the Roman Catholic
Church and arresting political dissidents. Cuba is
slowly recovering from severe economic recession
following the withdrawal of former-Soviet subsidies,
worth $4billion-$6 billion per year, in 1990.','9f793698c64c626796b55a18f32d241a86360507312bf995e97cc2f1514d8698','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb3e4c86f6b0d32abe1dc2f201874377ee943a99464ecb7790eb2bedc366687',1999,'PL','Poland','introduction',353,'Background: Once part of the Holy Roman Empire
and, later, the Austro-Hungarian monarchy,
Czechoslovakia became an independent nation at the
end of World War I. Independence ended with the
German takeover in 1939. After World War II,
Czechoslovakia fell within the Soviet sphere of
influence, and in 1968 an invasion by Warsaw Pact
troops snuffed out anti-communist demonstrations
and riots. With the collapse of Soviet authority in 1 991 ,
Czechoslovakia regained its freedom. On 1 January
1993, the country peacefully split into its two ethnic
components, the Czech Republic and Slovakia. The
Czech Republic, largely by aspiring to become a
NATO and EU member, has moved toward integration
in world markets, a development that poses both
opportunities and risks. But Prague has had a difficult
time convincing the public that membership in NATO
is crucial to Czech security. At the same time, support
for eventual EU membership is waning. Coupled with
the country''s worsening economic situation, Prague''s
political scene, troubled for the past three years, will
remain so for the foreseeable future.','112787370d2cec80cd11b0b87dca11997ea725b93342de36e09260ef72e5469b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0004d207e2402e37167b70ee49b1ea7e4ffcbf63410d97c29422200c5ccc8b0b',1999,'EG','Egypt','introduction',387,'Background: One of the four great ancient
civilizations, Egypt, ruled by powerful pharaohs,
bequeathed to Western civilization numerous
advances in technology, science, and the arts. For the
last two millennia, however, Egypt has served a series
of foreign masters - Persians, Greeks, Romans,
Byzantines, Arabs, Turks, and the British. Formal
independence came in 1922, and the remnants of
British control ended after World War II. The
completion of the Aswan High Dam in 1 981 altered the
time-honored place of the Nile River in the agriculture
and ecology of Egypt. A rapidly growing population will
stress Egyptian society and resources as it enters the
newmillenium.','84ba6132bba22ebc7f64aa9951613008c2607d8b8cbf7260256d93c6a1a9868c','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b666871ff0bb30fe61c56221481e799d8774fec577a83082b8e533bed53c4b0',1999,'GN','Guinea','introduction',402,'Background: On 29 May 1991, ISAIAS Afworki,
secretary general of the People''s Front for Democracy
and Justice (PFDJ), which then served as the
country''s legislative body, announced the formation of
the Provisional Government in Eritrea (PGE) in
preparation for the 23-25 April 1993 referendum on
independence from Ethiopia. The referendum
resulted in a landslide vote for independence, which
became effective on 24 May 1993.','1e02a89705ea010ab595c8032d65167c4f9f2994a641dc27a137fa5bc71a3187','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44bfe29270a66e5ce16e7f6f81fa4f68874943d15e705e8c8eec3b72e43e2eb5',1999,'ET','Ethiopia','introduction',413,'Background: On 28 May 1991 the Ethiopian
People''s Revolutionary Democratic Front (EPRDF)
toppled the authoritarian government of MENGISTU
Haile-Mariam and took control in Addis Ababa. A new
constitution was promulgated in December 1994 and
national and regional popular elections were held in
May and June 1995.','334e00c669aef55e4d018aebb14b584bc443f6ab3f4e453079093f63018ba650','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da16179db913824784e070ea7ca97b1714f1d3372c59bec2b37a5654252062d',1999,'FI','Finland','introduction',442,'Background: Long ruled by foreign powers,
including Sweden and the pre-revolutionary Russian
Empire, Finland finally declared independence in
1917. During World War II, Finland fought the USSR
twice and then the Germans toward the end of the
war. In the following half-century, the Finns made a
remarkable transformation from a farm/forest
economy to a diversified modern industrial economy.
Per capita income has risen to the West European
level; Finland is a member of the European Union and
is the only Nordic state to join the euro system at its
initiation in January 1999.','f8504ee3dc1a579d751b2cb0f2b7531fb582cba6a799c62030643a8ae92d5176','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6553fedcbef23424c9c4b64b11d984ceaa98ea2a69ce3dc3eccdeb3892aa7437',1999,'FR','France','introduction',451,'Background: Although ultimately a victor in World
Wars I and II, France lost many men, much wealth, its
extensive empire, and its rank as a dominant
nation-state. France has struggled since 1958 -
arguably with success - to construct a presidential
democracy resistant to the severe instabilities
inherent in the parliamentary democracy of early 20th
century France. In recent years, its reconciliation and
cooperation with Germany have proved central to the
economic integration of Europe, including the advent
of the euro in January 1999.
Background: Buoyed by victories in World Wars I
and II and the end of the Cold War in 1 991 , the US
remains the world''s most powerful nation-state. The
economy is marked by steady growth, low
unemployment, low inflation, and rapid advances in
technology. The biggest cloud over this affluent
society is the distribution of gains - since 1 975 most of
the increase in national income has gone to the 20%
of people at the top of the income ladder.','e977a1af869f2842d44a2e6c6dfeb02b73b5a1e8fa206c705ac92a35541969cd','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eea8996a21070b7bac6f64ca213ae2daac43ca08cb1bec6c2635828632d4c877',1999,'GA','Gabon','introduction',476,'Background: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
("the DOP"), signed in Washington on 13 September
1993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Permanent status
negotiations began on 5 May 1996, but have not
resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and
responsibilities to the Palestinian Authority, which
includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A
transfer of powers and responsibilities for the Gaza
Strip and Jericho took place pursuant to the
Israel-PLO 4 May 1 994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of
the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO
15 January 1997 Protocol Concerning Redeployment
in Hebron, and the Israel-PLO 23 October 1998 Wye
River Memorandum. The DOP provides that Israel will
retain responsibility during the transitional period for
external security and for internal security and public
order of settlements and Israelis. Permanent status is
to be determined through direct negotiations.','d8835fe1d05dd1a40cf1b1952d1eff47dfbb20e9f47d7fc7c341bc089b43924a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3129f26dd826d9aa46b4f08f2a41d9bb1edf0a231e1029674149ea22631ca407',1999,'NI','Nicaragua','introduction',546,'Background: Pursuant to the agreement signed by
China and the UK on 19 December 1984, Hong Kong
became the Hong Kong Special Administrative
Region (SAR) of China on 1 July 1997. Under the
terms of this agreement, China has promised that
under its "one country, two systems" formula its
socialist economic system will not be practiced in
Hong Kong, and that Hong Kong shall enjoy a high
degree of autonomy in all matters except foreign and
defense affairs.','f4dd4a8658c8881ee667bc18be6c9697b89ab5bf021ef668dd1544fb269a6586','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f4d24af95985b4685ded5d05a3405622f34e95b58bab113105e3f9939a139a5',1999,'IS','Iceland','introduction',564,'Background: Iceland boasts the oldest surviving
parliament in the world, the Althing, established in
930. Subsequently this Nordic island, whose small
population has largely depended on fishing and
sheep-herding for a living, came under the rule of
Norway and then Denmark. It gained home rule in
1874 and full independence in 1944. Literacy,
longevity, and social cohesion are topnotch by world
standards. Tensions continue with Noway, Russia,
and other nearby countries over fishing rights in the
North Atlantic and adjacent seas.','664c421ae9ce4ba5a665956cac1c7296b348ab83874aad97767c1066176de39b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d081c1285d9efca007d7ee901c9b865803e4bd3360d0076fade7d28cf02175',1999,'ID','Indonesia','introduction',575,'Background: Iraq lies in the lower part of the
Tigris-Euphrates valley, the heart of one of the four
great ancient civilizations. The area was overrun by
Arab, Mongol, and Turkish conquerors and became a
British mandate following World War I. Independence
came in 1932. Iraq''s pro-Western stance ended in
1958 with the overthrow of the monarchy. Its
subsequent turbulent history has witnessed the
dictatorship of SADDAM Husayn, civil war with the
Kurds, a bloody conflict with neighboring Iran, and, in
1990, an invasion of Kuwait, swiftly turned back by a
Western coalition led by the US. Noncooperation with
UN Security Council resolution obligations and the
UN''s inspection of Iraq''s nuclear, chemical, biological,
and long-range missile weapons programs remain
major problems.','e643a48e9622b25951828c6e9c4e3d54edb44d866d306d6b3348e89e3dd1b984','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7241cf958d28d1fd788c981dee133c70c9f1c054e3c9e6e40ca1a60a3a660010',1999,'JE','Jersey','introduction',578,'Background: Italy failed to secure political
unification until the 1860s, thus lacking the military
and imperial power of Spain, Britain, and France. The
fascist dictatorship of MUSSOLINI after World War I,
led to the disastrous alliance with HITLER''S Germany
and defeat in World War II. Italy was a founding
member of the European Economic Community
(EEC) and joined in the growing political and
economic unification of Western Europe, including the
introduction of the euro in January 1999. On-going
problems include illegal immigration, the ravages of
organized crime, high unemployment, and the low
incomes and technical standards of Southern Italy
compared with the North.','d202deb8b8edd775e22584d017f2e8115840f58de91fb191c3e4543b16689055','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc0b4d977c13f4f0a8f92c5a8515d13244364a549238d9e1a08b6f1d5b6cab5',1999,'WS','Samoa','introduction',621,'Background: At the end of World War II, the US and
the Soviet Union agreed that US troops would accept
the surrender of Japanese forces south of the 38th
parallel and the Soviet Union would do so in the north.
In 1948, the UN proposed nationwide elections; after
P''yongyang''s refusal to allow UN inspectors in the
north, elections were held in the south and the
Republic of Korea was established. The Democratic
People''s Republic of Korea was established the
following month in the north. Communist North
Korean forces invaded South Korea in 1950. US and
other UN forces intervened to defend the South and
Chinese forces intervened on behalf of the North.
After a bitter three-year war, an armistice was signed
in 1953, establishing a military demarcation line near
the 38th parallel. The North''s heavy investment in
military forces has produced an army of 1 million
troops equipped with thousands of tanks and artillery
pieces. Despite growing economic hardships, North
Korea continues to devote a significant portion of its
scarce resources to the military.
Background: At the end of World War II, the US and
the Soviet Union agreed that US troops would accept
the surrender of Japanese forces south of the 38th
parallel and the Soviet Union would do so in the north.
In 1948, the UN proposed nationwide elections; after
P''yongyang''s refusal to allow UN inspectors in the
north, elections were held in the south and the
Republic of Korea was established. The Democratic
People''s Republic of Korea was established the
following month in the north. Communist North
Korean forces invaded South Korea in 1950. US and
other UN forces intervened to defend the South and
Chinese forces intervened on behalf of the North.
After a bitter three-year war, an armistice was signed
in 1953, establishing a military demarcation line near
the 38th parallel. Thereafter, South Korea achieved
amazing economic growth, with per capita output
rising to 13 times the level in the North. Since late
1997, however, the nation has suffered widespread
financial and organizational difficulties. Continuing
tensions between North and South have raised
concerns of provocative military actions by the North.','c72c6b24216869dba36cc819e4e450b62868b4f05cadcbed12d1e101f50ad640','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5765dd89d540847a918346e0e535a2812602a2ac7a80f05be52fb4a935f36bd0',1999,'LV','Latvia','introduction',631,'Background: Along with most of the other small
nations of Europe, Latvia shares a history of invasion
by a succession of expansionist nations, e.g.,
Sweden, Poland, Germany, and Russia. After a brief
period of independence between the two World Wars,
Latvia was annexed by the USSR in 1 940 under the
Molotov-Ribbentrop Pact. The USSR recaptured
Latvia from its German occupiers in 1944. Latvia
reestablished its independence in August 1 991 , a few
months prior to the collapse of the Soviet Union; the
last Russian troops left in 1994. The status of ethnic
Russians, who make up 30% of the population, is an
issue of concern to Moscow. Unemployment has
become a growing problem and Latvia hopes to
receive an invitation to begin EU accession talks by
the end of 1999.','d91b2ec1d920d14fd0f259f463e2c0636f9e6e525fe9991d92d3df395b6155b8','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac49d6f3244796b24afe63d9777247cb51db5a5e7849be0bd87ed5e4584bb5a',1999,'LB','Lebanon','introduction',640,'Background: Lebanon has made progress toward
rebuilding its political institutions and regaining its
national sovereignty since the end of the devastating
1 6-year civil war, which ended in 1 991 . Linder the Ta''if
Accord - the blueprint for national reconciliation - the
Lebanese have established a more equitable political
system, particularly by giving Muslims a greater say in
the political process while institutionalizing sectarian
divisions in the government. Since the end of the civil
war, the Lebanese have formed six cabinets,
conducted two legislative elections, and held their first
municipal elections in 35 years. Most of the militias
have been weakened or disbanded. The Lebanese
Armed Forces (LAF) has seized vast quantities of
weapons used by the militias during the war and
extended central government authority over about
one-half of the country. Hizballah, the radical Shi''a
party, retains its weapons. Foreign forces still occupy
areas of Lebanon. Israel maintains troops in southern
Lebanon and continues to support a proxy militia, the
Army of South Lebanon (ASL), along a narrow stretch
of territory contiguous to its border. The ASL''s enclave
encompasses this self-declared security zone and
about 20 kilometers north to the strategic town of
Jazzin. Syria maintains about 25,000 troops in
Lebanon based mainly in Beirut, North Lebanon, and
the Bekaa Valley. Syria''s deployment was legitimized
by the Arab League during Lebanon''s civil war and in
the Ta''if Accord. Citing the continued weakness of the
LAF, Beirut''s requests, and failure of the Lebanese
Government to implement all of the constitutional
reforms in the Ta''if Accord, Damascus has so far
refused to withdraw its troops from Lebanon.','8d5a6aa98f91d5a505e0d5198bdaae1ed833287d4219cb58aa8091992d206219','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afae0f2030acc76ad201e873abd862e1a28dff3134c8aad474e7f4b2eb16396b',1999,'ZA','South Africa','introduction',657,'Background: The 1 995 Abuja Peace Accords ended
seven years of civil warfare in Liberia. More than
20,000 of the estimated 33,000 factional fighters gave
up their arms to the Cease-Fire Monitoring Group of
the Economic Community of West African States
(ECOMOG). Free and open presidential and
legislative elections were held 19 July 1997; former
faction leader, Charles TAYLOR, and his National
Patriotic Party won overwhelming victories. The years
of civil strife coupled with the flight of most business
people disrupted formal economic activity. A
short-lived armed clash in September 1998 between
government forces and supporters of factional leader
Roosevelt JOHNSON and continuing uncertainty
about the security situation have slowed the process
of rebuilding the social and economic structure of the
war-torn country. For two centuries the US has had
uniquely close ties to Liberia and today is a major aid
donor.','79325f315e6e219a3300a5b4d9ebfaaed99e1aa560a6c2807a8b7935f89e5564','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b323962c653fa4b1d2a96c6e54220c638b90ca49cd32ec51d4553f1474b963ba',1999,'NO','Norway','introduction',845,'Background: Norway gained its independence from
Sweden in 1 905. As a separate realm, Norway stayed
free of World War I but suffered German occupation in
World War II. Discovery of oil and gas in adjacent
waters in the late 1960s gave a strong boost to
Norway''s economic fortunes. Norway is planning for
the time when its oil and gas reserves are depleted
and is focusing on containing spending on its
extensive welfare system. It has decided at this time
not to join the European Union and the new euro
currency regime.','a8d85e9dcca257896eff26123386bf8b09a13263879484960763030ade262745','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c66a046d001316dc38c506b9d2a9c1519a70481dae25d396ff40c93cc942eed6',1999,'UA','Ukraine','introduction',886,'Background: Russia, a vast Eurasian expanse of
field, forest, desert, and tundra, has endured many
"times of trouble" - the Mongol rule of the 1 3th to 1 5th
century; czarist reigns of terror; massive invasions by
Swedes, French, and Germans; and the deadly
communist period (1917-91) in which Russia
dominated an immense Soviet Union. General
Secretary Mikhail GORBACHEV, in charge during
1985-91, introduced glasnost (openness) and
perestroika (restructuring) in an attempt to modernize
communism, but also inadvertently released forces
that shattered the USSR into 15 independent
republics in December 1991. Russia has struggled in
its efforts to build a democratic political system and
market economy to replace the strict social, political,
and economic controls of the communist period.
These reform efforts have resulted in contradictory
and confusing economic and political regulations and
practices. Industry, agriculture, the military, the central
government, and the ruble have suffered, but Russia
has successfully held one presidential, two legislative,
and numerous regional elections since 1991. The
severe illnesses of President Boris YEL''TSIN have
contributed to a lack of policy focus at the center.
Background: Throughout their colonial rule, first
Germany and then Belgium favored Rwanda''s
minority Tutsi ethnic group in education and
employment. In 1959, the majority ethnic group, the
Hutus, overthrew the ruling Tutsi monarch. The Hutus
killed hundreds of Tutsis and drove tens of thousands
into exile in neighboring countries. The children of
these exiles later formed a rebel group, the Rwandan
Patriotic Front (RPF), and began a civil war in October
1990. The war, along with several political and
economic upheavals, exasperated ethnic tensions
culminating in April 1994 in a genocide in which
roughly 800,000 Tutsis and moderate Hutus were
killed. The Tutsi rebels defeated the Hutu regime and
ended the genocide in July 1 994, but approximately 2
million Hutu refugees - many fearing T utsi retribution -
fled to neighboring Burundi, Tanzania, Uganda, and
Zaire, now called the Democratic Republic of the
Congo (DROC). According to the UN Office of the
High Commissioner for Refugees, in 1996 and early
1997 nearly 1.3 million Hutus returned to Rwanda.
Even with substantial international aid, these civil
dislocations have hindered efforts to foster
reconciliation and to boost investment and agricultural
output. Although much of the country is now at peace,
members of the former regime continue to destabilize
the northwest area of the country through a
low-intensity insurgency. Rwandan troops are
currently involved in a crisis engulfing neighboring
DROC.','fd11ec16926d50a704e1091e8d1ef8c2612e312f36750e3db417617163cde99a','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29aa4616c4b94f1fcc321e5cfeb33595040f2edf68735340a2ff7170812e4838',1999,'ME','Montenegro','introduction',925,'Background: Serbia and Montenegro have asserted
the formation of a joint independent state, but this
entity has not been formally recognized as a state by
the US. The US view is that the Socialist Federal
Republic of Yugoslavia (SFRY) has dissolved and that
none of the successor republics represents its
continuation.','1e504eddaa8943a5f861cfa64ba684812633a828c90bca04dfe4187035eedd4d','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47d8697675878b4b6161173b1baa558754879db8d3536af88b103bf715c80de9',1999,'SB','Solomon Islands','introduction',953,'Background: In 1893, Britain made the southern
Solomon Islands a protectorate. Other islands were
added to the group, including some ceded to Britain by
Germany. The Solomon Islands were occupied by the
Japanese during World War II. Following the war,
internal self-government was established in 1 976, and
independence from the UK came two years later.
Current issues include government deficits,
deforestation, and malaria control.','f45877fcec189f652b8e124a193c116ecf9b4c7f5f628eb5ca4b2a15785f3f21','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94da21ad2f3816cca0f961d1ecab8d70ee58104d496f07919b73fb160fc004e0',1999,'ES','Spain','introduction',970,'Background: A powerful world empire in the 16th
and 1 7th centuries, Spain ultimately yielded command
of the seas to England, beginning with the defeat of
the Armada in 1 588. Spain subsequently failed to
embrace the mercantile and industrial revolutions and
fell behind Britain, France, and Germany in economic
and political power. Spain remained neutral in World
Wars I and II. In the second half of the 20th century
Spain played a catch-up role in the western
international community. Continuing problems are
large-scale unemployment and the Basque separatist
movement.','b874387703af7b0aee9dd6aa7ddcb293c345c193b68d61a2841af8a8efd14e08','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('629887c969c164eba42bd3f1ffc87b7c171f551ff0a4511041cce7361cefd0c0',1999,'CH','Switzerland','introduction',988,'Background: Switzerland''s independence and
neutrality have long been honored by the major
European powers and Switzerland did not participate
in either World War I or II. The political and economic
integration of Europe since World War II may be
rendering obsolete Switzerland''s concern for
neutrality.','6ab2cd6909747961b53dddfef14b90f1f8bd6090b1e3e2958b35d7ede89fcfe2','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d293b25493ea71e94ea45a258d3ce92dfbdfb325546d8a5c122f3a6466a6bc45',1999,'TJ','Tajikistan','introduction',990,'Background: Tajikistan has experienced three
changes of government and a civil war since it gained
independence in September 1991 when the USSR
collapsed. A peace agreement was signed in June
1997, but implementation is progressing slowly.
Russian-led peacekeeping troops are deployed
throughout the country, and Russian-commanded
border guards are stationed along the
Tajikistani-Afghan border.','dfcf1837240b6bec7bf426f379c1224c433c68d05e5431407d82f4549f9ef80e','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34465c6a4127e14b67f6de8e7556e33fb2580f077cf147552e1e385f9f76aa5d',1999,'IE','Ireland','introduction',1038,'Background: Britain, the dominant industrial and
maritime power of the nineteenth century, played a
leading role in developing parliamentary democracy
and in advancing literature and science. The British
Empire covered approximately one-fourth of the
earth''s surface at its zenith. In the first half of the
twentieth century its strength was seriously depleted
by two world wars. Since the end of World War II, the
British Empire has been dismantled, and Britain has
rebuilt itself into a prosperous, modern European
nation with significant international political, cultural,
and economic influence. As the twentieth century
draws to a close, Britain is debating the degree of its
integration with continental Europe. While a member
of the EU, for the time being it is staying out of the euro
system introduced in January 1999. Constitutional
reform, including the House of Lords and the
devolution of power to Scotland, Wales, and Northern
Ireland, is an ongoing issue in Great Britain.','54ee5e947b031c611887db69fc80352251c18cab9201513055e210c1707f0a0b','internet-archive','DTIC_ADA376610','txt','f84ac43a02b8a6e6d6d3f0ba19ae6d0d6f9b8b43774741a0cdc7a1cf0824d615','https://archive.org/download/DTIC_ADA376610/DTIC_ADA376610_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3483f7f99626b8424df879a54033faff5fd8420ade29e6e7a25a77297fe65ca6',1999,'LY','Libya','introduction',23,'Background: A part of the Spanish empire until independence in
1816, Argentina subsequently experienced periods of internal
political conflict between conservatives and liberals and between
civilian and military factions. Meantime, thanks to rich natural
resources and foreign investment, a modern agriculture and a
diversified industry were gradually developed. After World War II, a
long period of Peronist dictatorship was followed by rule by a
military junta. Democratic elections finally came in 1983, but both
the political and economic atmosphere remain susceptible to turmoil.
Background: Armenia was one of the 15 successor republics to the
USSR in December 1991. Its leaders remain preoccupied by the long
conflict with Azerbaijan over the Nagorno-Karabakh enclave. Although
a cease-fire has been in effect since May 1994, the sides have not
made substantial progress toward a peaceful resolution. In January
1998, differences between President TER-PETROSSIAN and members of
his cabinet over the Nagorno-Karabakh peace process came to a head.
With the prime minister, defense minister, and security minister
arrayed against him, an isolated TER-PETROSSIAN resigned the
presidency on 3 February 1998. Prime Minister Robert KOCHARIAN was
elected president in March 1998. Concerns about Armenia''s economic
performance have continued since 1997 with a slowdown in growth and
the serious impact of the 1998 financial crisis in Russia.','2915b5c4cbccde91bae6e47f57e9909d8a2f0b0415589354b04aa43ee7da6a33','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32052cd08ababd1f32deb4eb46ed5eabb355803de74caab5e9f3c11a3df85d64',1999,'AM','Armenia','introduction',32,'Background: Australia became a British commonwealth in 1901.
Blessed by rich natural resources, the country enjoyed rapid gains
in herding, agriculture, and manufacturing and made a major
contribution to the British effort in World Wars I and II. Australia
subsequently developed its minerals, metals, and fossil fuel
markets, all of which have become key Australian exports. Long-term
concerns include pollution, particularly depletion of the ozone
layer, and management and conservation of coastal areas, especially
the Great Barrier Reef. Sydney will host the 2000 summer Olympics.
Background: Once the center of power for the large
Austro-Hungarian empire, Austria was reduced to a small republic
after its defeat in World War I. After the annexation to Nazi
Germany in 1938 and subsequent occupation by the victorious Allied
powers, Austria''s 1955 State Treaty declared the country
"permanently neutral" as a condition of the Soviet military
withdrawal. The Soviet collapse relieved the external pressure to
remain unaligned, but neutrality had evolved into a part of Austrian
cultural identity, which has led to an ongoing public debate over
whether Vienna legitimately can remain outside of European security
structures. A wealthy country, Austria joined the European Union in
1995 and, like many EU members, is adjusting to the new European
currency and struggling with high unemployment.
Background: In 1806, Azerbaijan, a region of Turkic Muslim
people, was conquered by the Russians. In 1918, Azerbaijan declared
independence from Russia, but was incorporated into the Soviet Union
in 1920. It again declared its independence in 1991, following the
collapse of the USSR. The conflict between Azerbaijan and Armenia
over the Nagorno-Karabakh region is still unresolved after 10 years
and Baku has yet to settle disputes with its neighbors over oil
rights in the Caspian Sea. During the war, Karabakh Armenians
declared independence and seized almost 20% of the country''s
territory, creating some 750,000 Azerbaijani refugees in the
process. Both sides have generally observed a Russian-mediated
cease-fire in place since May 1994.','8711726bd18d2a262b44535cc3b19b656ff39399ba095ec8f02a74a2e08711a7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1f9efe479e9785a1e5b5a83223f86b8add9cbd572da1e558558ba4fc517051c',1999,'SA','Saudi Arabia','introduction',43,'Background: For centuries Byelorussia has been fought over,
devastated, and partitioned among Russia, Poland, Lithuania, and, in
World Wars I and II, Germany. After seven decades as a Soviet
republic, the newly named Belarus declared its independence in
August 1991. It has retained closer political and economic ties to
Russia than any of the other former Soviet republics. On 25 December
1998, Russian President Boris YEL''TSIN and Belarusian President
Aleksandr LUKASHENKO signed several agreements intended to provide
greater political, economic, and social integration while preserving
both states'' sovereignty.
Background: Belgium became independent from the Netherlands in
1830 and was occupied by Germany during World Wars I and II. In the
half century following, it has prospered as a small, modern,
technologically advanced European state and member of the European
Union. Its unique political circumstance is the long-standing
differences between the wealthier Dutch-speaking Flemings of the
north and the poorer French-speaking Walloons of the south,
differences that are becoming increasingly acute.
Background: Bolivia broke away from Spanish rule in 1825. Its
subsequent history has been marked by a seemingly endless series of
coups, counter-coups, and abrupt changes in leaders and policies.
Comparatively democratic civilian rule was established in the 1980s,
but the leaders have faced difficult problems of deep-seated
poverty, social unrest, strikes, and drug dealing. Current issues
include encouraging and negotiating the terms for foreign
investment; strengthening the educational system; continuing the
privatization program; pursuing judicial reform and an
anti-corruption campaign.','9b001800250efea72b3f97c0e2347d824d49757c44b7bcf63cbaeadf400632f7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0be25bfefe382cb59b523be1586335b52112a7c9e9237e2900e86f4225f03afa',1999,'PY','Paraguay','introduction',47,'Background: On 21 November 1995, in Dayton, Ohio, the former
Yugoslavia''s three warring parties signed a peace agreement that
brought to a halt over three years of interethnic civil strife in
Bosnia and Herzegovina (the final agreement was signed in Paris on
14 December 1995). The Dayton Agreement, signed then by Bosnian
President IZETBEGOVIC, Croatian President TUDJMAN, and Serbian
President MILOSEVIC, divides Bosnia and Herzegovina roughly equally
between the Muslim/Croat Federation and the Republika Srpska while
maintaining Bosnia''s currently recognized borders. In 1995-96, a
NATO-led international peacekeeping force (IFOR) of 60,000 troops
served in Bosnia to implement and monitor the military aspects of
the agreement. IFOR was succeeded by a smaller, NATO-led
Stabilization Force (SFOR) whose mission is to deter renewed
hostilities. SFOR remains in place. A High Representative appointed
by the UN Security Council is responsible for civilian
implementation of the accord, including monitoring implementation,
facilitating any difficulties arising in connection with civilian
implementation, and coordinating activities of the civilian
organizations and agencies in Bosnia. The Bosnian conflict began in
the spring of 1992 when the government of Bosnia and Herzegovina
held a referendum on independence and the Bosnian Serbs--supported by
neighboring Serbia--responded with armed resistance aimed at
partitioning the republic along ethnic lines and joining Serb-held
areas to form a "greater Serbia." In March 1994, Bosnia''s Muslims
and Croats reduced the number of warring factions from three to two
by signing an agreement in Washington creating their joint
Muslim/Croat Federation of Bosnia and Herzegovina. The Federation,
formed by the Muslims and Croats in March 1994, is one of two
entities (the other being the Bosnian Serb-led Republika Srpska)
that comprise Bosnia and Herzegovina.','14fe25ba52ff08100646a9f360f737024c1b1d07ca07ad3457a72f469fb728eb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eae12e8a252fdf581bba27f0a364a403dbf806ebac393d279e290f25a489fb1',1999,'MY','Malaysia','introduction',76,'Background: A Slavic state, Bulgaria achieved independence in
1908 after 500 years of Ottoman rule. Bulgaria fought on the losing
side in both World Wars. After World War II it fell within the
Soviet sphere of influence. Communist domination ended in 1991 with
the dissolution of the USSR, and Bulgaria began the contentious
process of moving toward political democracy and a market economy.
In addition to the problems of structural economic reform,
particularly privatization, Bulgaria faces the serious issues of
keeping inflation under control and unemployment, combatting
corruption, and curbing black-market and mafia-style crime.
Background: Since the end of the Belgian trusteeship in 1962,
Burundi has suffered from ethnic uprisings, coups, and other
societal dislocations. In a series of waves since October 1993,
hundreds of thousands of refugees have fled the ethnic violence
between the Hutu and Tutsi factions in Burundi and have crossed into
Rwanda, Tanzania, and Zaire (now called the Democratic Republic of
the Congo or DROC). Since October 1996, an estimated 120,000
Burundian Hutu refugees from the DROC have been compelled to return
to Burundi because of insecurity in the region. Continuing ethnic
violence with the Tutsi has caused additional Hutu to flee to
Tanzania, thus raising their numbers in the United Nations Office of
the High Commissioner for Refugees (UNHCR) camps in that country to
about 260,000. Burundian troops have joined armies from Rwanda and
Uganda and Congolese Tutsi in trying to overthrow DROC President
KABILA and restore security to their borders with the Democratic
Republic of the Congo.
Background: A land of vast distances and rich natural resources,
from 1867 on Canada has enjoyed de facto independence while
retaining, even to the present day, certain formal ties to the
British crown. Economically and technologically the nation has
developed in parallel with the US, its neighbor to the south across
an unfortified border. Its paramount political problem continues to
be the relationship of the province of Quebec, with its
French-speaking residents and unique culture, to the remainder of
the country.
Background: In 1996, the country experienced three mutinies by
dissident elements of the armed forces, which demanded back pay as
well as political and military reforms. Subsequent violence between
the government and rebel military groups over pay issues, living
conditions, and lack of opposition party representation in the
government, destroyed many businesses in the capital, reduced tax
revenues, and exacerbated the government''s problems in meeting
expenses. African peacekeepers restored order in 1997; in April 1998
the United Nations Mission in the Central African Republic (MINURCA)
assumed responsibility for peacekeeping operations.','9f5ad996baad576fcaf1119f61f574a8d466eb743d09bdd289bcf8cdfb5a0758','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17dbc69258b37c62f7ff3d64fe6cc0110c73f7b318d92c8a5ca9f23314bc2992',1999,'CG','Congo','introduction',88,'Background: In 1960, Chad gained full independence from France.
In December 1990, after Chad had endured three decades of ethnic
warfare as well as invasions by Libya, former northern guerrilla
leader Idriss DEBY seized control of the government. His
transitional government eventually suppressed or came to terms with
most political-military groups, settled the territorial dispute with
Libya on terms favorable to Chad, drafted a democratic constitution
which was ratified by popular referendum in 1996, held multiparty
national presidential elections in 1996 (DEBY won with 69% of the
vote), and held multiparty elections for the National Assembly in
1997 (DEBY''s Patriotic Salvation Movement won a majority of the
seats). But by the end of 1998, DEBY was beset with numerous
problems including heavy casualties in the Democratic Republic of
the Congo where Chadian troops had been deployed to support
embattled President KABILA, a new rebellion in northern Chad, and
further delays in the Doba Basin oil project in the south.
Background: For most of its 3,500 years of history, China led the
world in agriculture, crafts, and science, then fell behind in the
19th century when the Industrial Revolution gave the West clear
superiority in military and economic affairs. In the first half of
the 20th century, China continued to suffer from major famines,
civil unrest, military defeat, and foreign occupation. After World
War II, the Communists under MAO Zedong established a dictatorship
that, while ensuring China''s autonomy, imposed strict controls over
all aspects of life and cost the lives of tens of millions of
people. After 1978, his successor DENG Xiaoping decentralized
economic decision making; output quadrupled in the next 20 years.
Political controls remain tight at the same time economic controls
have been weakening. Present issues are: incorporating Hong Kong
into the Chinese system; closing down inefficient state-owned
enterprises; modernizing the military; fighting corruption; and
providing support to tens of millions of displaced workers.
Background: Britain, the dominant industrial and maritime power
of the nineteenth century, played a leading role in developing
parliamentary democracy and in advancing literature and science. The
British Empire covered approximately one-fourth of the earth''s
surface at its zenith. In the first half of the twentieth century
its strength was seriously depleted by two world wars. Since the end
of World War II, the British Empire has been dismantled, and Britain
has rebuilt itself into a prosperous, modern European nation with
significant international political, cultural, and economic
influence. As the twentieth century draws to a close, Britain is
debating the degree of its integration with continental Europe.
While a member of the EU, for the time being it is staying out of
the euro system introduced in January 1999. Constitutional reform,
including the House of Lords and the devolution of power to
Scotland, Wales, and Northern Ireland, is an ongoing issue in Great
Britain.','b4403db2a1457de12307e697dd63436d713f66a78c48951000984b46260a6dd7','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('926fe2db535aded2c3fa94b42eb50b7d6362c87400f281de89fd667bc435ad94',1999,'AU','Australia','introduction',118,'Background: Colombia gained its independence from Spain in 1819.
Earlier than most countries in the area, it established traditions
of civilian government with regular, free elections. In recent
years, however, assassinations, widespread guerrilla activities, and
drug trafficking have severely disrupted normal public and private
activities.
Background: Comoros has had difficulty in achieving political
stability, having endured 18 coups or attempted coups since
receiving independence from France in 1975. Most recently, in August
1997, the islands of Anjouan and Moheli declared their independence
from Comoros. An attempt in September 1997 by the government to
reestablish control over the rebellious islands by force failed, and
presently the Organization of African Unity is brokering
negotiations to effect a reconciliation.
Background: Costa Rica declared its independence from Spain in
1821. After a turbulent beginning it inaugurated an era of peaceful
democracy in 1889, subsequently interrupted only twice, by a
dictatorial interlude in 1917-19 and an armed uprising in 1948.
Increasing the role of the private sector while maintaining the
government''s social safety net and keeping under control the budget
deficit, unemployment, and inflation are key current issues.
Background: Fidel CASTRO led a rebel army to victory in 1959, and
his guiding vision has defined Cuba''s Communist revolution while his
iron will has held the country together for more than four decades.
CASTRO brought Cuba onto the world stage by inviting Soviet support
in the 1960s, inciting revolutionary movements throughout Latin
America and Africa in the 1970s, and sending his army to fight in
Angola in the 1980s. At home, Havana provided Cubans with high
levels of healthcare, education, and social security while
suppressing the Roman Catholic Church and arresting political
dissidents. Cuba is slowly recovering from severe economic recession
following the withdrawal of former-Soviet subsidies, worth
$4billion-$6 billion per year, in 1990.
Background: Once part of the Holy Roman Empire and, later, the
Austro-Hungarian monarchy, Czechoslovakia became an independent
nation at the end of World War I. Independence ended with the German
takeover in 1939. After World War II, Czechoslovakia fell within the
Soviet sphere of influence, and in 1968 an invasion by Warsaw Pact
troops snuffed out anti-communist demonstrations and riots. With the
collapse of Soviet authority in 1991, Czechoslovakia regained its
freedom. On 1 January 1993, the country peacefully split into its
two ethnic components, the Czech Republic and Slovakia. The Czech
Republic, largely by aspiring to become a NATO and EU member, has
moved toward integration in world markets, a development that poses
both opportunities and risks. But Prague has had a difficult time
convincing the public that membership in NATO is crucial to Czech
security. At the same time, support for eventual EU membership is
waning. Coupled with the country''s worsening economic situation,
Prague''s political scene, troubled for the past three years, will
remain so for the foreseeable future.
Background: Once the seat of rapacious Viking raiders and later a
major power in northwestern Europe, Denmark has evolved into a
modern, prosperous nation that is participating in the political and
economic integration of Europe. So far, however, they have opted out
of some aspects of the European Union''s Maastricht Treaty including
the new monetary system launched on 1 January 1999.
Background: Indonesia declared its independence in 1945 from the
Netherlands, a claim disputed, then recognized by the Dutch in 1949.
In 1975 Indonesian troops occupied Portuguese East Timor. Current
issues include implementing IMF-mandated reforms (particularly
restructuring and recapitalizing the insolvent banking sector),
effecting a transition to a popularly elected government, addressing
longstanding grievances over the role of the ethnic Chinese business
class and charges of cronyism and corruption, alleged human rights
violations by the military, the role of the military and religion in
politics, and growing pressures for some form of independence or
autonomy by Aceh, Irian Jaya, and East Timor.
Background: Iraq lies in the lower part of the Tigris-Euphrates
valley, the heart of one of the four great ancient civilizations.
The area was overrun by Arab, Mongol, and Turkish conquerors and
became a British mandate following World War I. Independence came in
1932. Iraq''s pro-Western stance ended in 1958 with the overthrow of
the monarchy. Its subsequent turbulent history has witnessed the
dictatorship of SADDAM Husayn, civil war with the Kurds, a bloody
conflict with neighboring Iran, and, in 1990, an invasion of Kuwait,
swiftly turned back by a Western coalition led by the US.
Noncooperation with UN Security Council resolution obligations and
the UN''s inspection of Iraq''s nuclear, chemical, biological, and
long-range missile weapons programs remain major problems.
Background: Growing Irish nationalism resulted in independence
from the United Kingdom in 1921, with six largely Protestant
northern counties remaining within the UK. After World War II bloody
strife between Catholics and Protestants over the status of Northern
Ireland cost thousands of lives. In 1998, substantial steps toward
peace were agreed to by the British and Irish governments and the
Roman Catholics and Protestants of Northern Ireland.
Background: The territories occupied by Israel since the 1967 war
are not included in the data below, unless otherwise noted. In
keeping with the framework established at the Madrid Conference in
October 1991, bilateral negotiations are being conducted between
Israel and Palestinian representatives, and Israel and Syria, to
achieve a permanent settlement between them. On 25 April 1982,
Israel withdrew from the Sinai pursuant to the 1979 Israel-Egypt
Peace treaty. Outstanding territorial and other disputes with Jordan
were resolved in the 26 October 1994 Israel-Jordan Treaty of Peace.
Background: Italy failed to secure political unification until
the 1860s, thus lacking the military and imperial power of Spain,
Britain, and France. The fascist dictatorship of MUSSOLINI after
World War I, led to the disastrous alliance with HITLER''s Germany
and defeat in World War II. Italy was a founding member of the
European Economic Community (EEC) and joined in the growing
political and economic unification of Western Europe, including the
introduction of the euro in January 1999. On-going problems include
illegal immigration, the ravages of organized crime, high
unemployment, and the low incomes and technical standards of
Southern Italy compared with the North.
Background: Norway gained its independence from Sweden in 1905.
As a separate realm, Norway stayed free of World War I but suffered
German occupation in World War II. Discovery of oil and gas in
adjacent waters in the late 1960s gave a strong boost to Norway''s
economic fortunes. Norway is planning for the time when its oil and
gas reserves are depleted and is focusing on containing spending on
its extensive welfare system. It has decided at this time not to
join the European Union and the new euro currency regime.','bbccb7bd7e39abed5027127a3c76d353948c5fa3b724ab92151c35e7a72ae467','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47e45a5e1ac7f5c19edfb6751624fd8c75a364fff32ec523a04061114bc7065',1999,'ET','Ethiopia','introduction',132,'Background: Named after Captain Cook, who sighted them in 1770,
the islands became a British protectorate in 1888. By 1900,
administrative control was transferred to New Zealand. Residents
chose self-government with free association with New Zealand in
1965. The emigration of Cook Islanders to New Zealand in large
numbers and resulting loss of skilled labor and government deficits
are continuing problems.','925b4c155c4ef7952804f416d996f2f9d68cfba7d6a93616949f0ae816efa173','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e6404f924a0c4db25f6464d375aa247338f2b5a9728523bbea152640dbe8a5',1999,'TT','Trinidad and Tobago','introduction',152,'Background: One of the four great ancient civilizations, Egypt,
ruled by powerful pharaohs, bequeathed to Western civilization
numerous advances in technology, science, and the arts. For the last
two millennia, however, Egypt has served a series of foreign
masters--Persians, Greeks, Romans, Byzantines, Arabs, Turks, and the
British. Formal independence came in 1922, and the remnants of
British control ended after World War II. The completion of the
Aswan High Dam in 1981 altered the time-honored place of the Nile
River in the agriculture and ecology of Egypt. A rapidly growing
population will stress Egyptian society and resources as it enters
the new millenium.
Background: Serbia and Montenegro have asserted the formation of
a joint independent state, but this entity has not been formally
recognized as a state by the US. The US view is that the Socialist
Federal Republic of Yugoslavia (SFRY) has dissolved and that none of
the successor republics represents its continuation.','a302282728796cfe9deef7cf590210c8711c92d58589ff41b0e51d79f0e9884b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35f461e42ba310f419f66c8e6d9a4f1d4ca05ae660276cb2c7c807d2ba10c343',1999,'MX','Mexico','introduction',162,'Background: On 29 May 1991, ISAIAS Afworki, secretary general of
the People''s Front for Democracy and Justice (PFDJ), which then
served as the country''s legislative body, announced the formation of
the Provisional Government in Eritrea (PGE) in preparation for the
23-25 April 1993 referendum on independence from Ethiopia. The
referendum resulted in a landslide vote for independence, which
became effective on 24 May 1993.
Background: In and out of Swedish and Russian control over the
centuries, this little Baltic state was re-incorporated into the
USSR after German occupation in World War II. Independence came with
the collapse of the USSR in 1991; the last Russian troops left in
1994. Estonia thus became free to promote economic and political
ties with Western Europe. The position of ethnic Russians (29% of
the population) remains an issue of concern to Moscow. European
Union (EU) membership negotiations, which began in 1998, remain a
domestic issue.
Background: On 28 May 1991 the Ethiopian People''s Revolutionary
Democratic Front (EPRDF) toppled the authoritarian government of
MENGISTU Haile-Mariam and took control in Addis Ababa. A new
constitution was promulgated in December 1994 and national and
regional popular elections were held in May and June 1995.','b0fd29840292c06a6e4c8ce9caafe1de7c1e67b5c27bcaa2627ec8e08a55b59a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9701cb164db7a20d44b4c3236091202edd4c924409ff105473ea23528535ae12',1999,'AR','Argentina','introduction',181,'Background: Long ruled by foreign powers, including Sweden and
the pre-revolutionary Russian Empire, Finland finally declared
independence in 1917. During World War II, Finland fought the USSR
twice and then the Germans toward the end of the war. In the
following half-century, the Finns made a remarkable transformation
from a farm/forest economy to a diversified modern industrial
economy. Per capita income has risen to the West European level;
Finland is a member of the European Union and is the only Nordic
state to join the euro system at its initiation in January 1999.
Background: Although ultimately a victor in World Wars I and II,
France lost many men, much wealth, its extensive empire, and its
rank as a dominant nation-state. France has struggled since
1958--arguably with success--to construct a presidential democracy
resistant to the severe instabilities inherent in the parliamentary
democracy of early 20th century France. In recent years, its
reconciliation and cooperation with Germany have proved central to
the economic integration of Europe, including the advent of the euro
in January 1999.','e8882aa35d43119bfa57e75027150f000c034179cc140e5b3aa77f3161d70483','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d10f089bd390d9750a7efbdf7a0a0887c10ebc29601cffb637ab13a5d19c351',1999,'SN','Senegal','introduction',200,'Background: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the Gaza Strip
and the West Bank. Permanent status negotiations began on 5 May
1996, but have not resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and responsibilities to the
Palestinian Authority, which includes a Palestinian Legislative
Council elected in January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A transfer of powers
and responsibilities for the Gaza Strip and Jericho took place
pursuant to the Israel-PLO 4 May 1994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995 Interim Agreement, the
Israel-PLO 15 January 1997 Protocol Concerning Redeployment in
Hebron, and the Israel-PLO 23 October 1998 Wye River Memorandum. The
DOP provides that Israel will retain responsibility during the
transitional period for external security and for internal security
and public order of settlements and Israelis. Permanent status is to
be determined through direct negotiations.
Background: Beset by ethnic and civil strife since independence
from the Soviet Union in December 1991, Georgia began to stabilize
in 1994. Political settlements for separatist conflicts in South
Ossetia and Abkhazia remain elusive. The conflict in South Ossetia
has been dormant since spring 1994, but sporadic violence continues
between Abkhaz forces and Georgian partisans in western Georgia.
Russian peacekeepers are deployed in both regions and a UN Observer
Mission is operating in Abkhazia. As a result of these conflicts,
Georgia still has about 250,000 internally displaced people. In
1995, Georgia adopted a new constitution and conducted generally
free and fair nationwide presidential and parliamentary elections.
In 1996, the government focused its attention on implementing an
ambitious economic reform program and professionalizing its
parliament. Violence and organized crime were sharply curtailed in
1995 and 1996, but corruption remains rife. Georgia has taken some
steps to reduce its dependence on Russia, acquiring coastal patrol
boats in 1997 to replace Russian border units along the Black Sea
coast. In 1998, Georgia assumed control of its Black Sea coast and
about half of its land border with Turkey in line with a June 1998
agreement with Russia. Since 1997, Georgia''s parliament has
sharpened its rhetoric against Russia''s continued military presence
on Georgian territory. In February 1998 an assassination attempt was
made against President SHEVARDNADZE by supporters of the late former
president Zviad GAMSAKHURDIA. In October 1998, a disaffected
military officer led a failed mutiny in western Georgia; the armed
forces continue to feel the ripple effect of the uprising. Georgia
faces parliamentary elections this fall, and presidential elections
next spring. After two years of robust growth, the economy, hurt by
the financial crisis in Russia, slowed in 1998.
Background: Germany--first united in 1871?suffered defeats in
successive world wars and was occupied by the victorious Allied
powers of the US, UK, France, and the Soviet Union in 1945. With the
beginning of the Cold War and increasing tension between the US and
Soviet Union, two German states were formed in 1949: the western
Federal Republic of Germany (FRG) and the eastern German Democratic
Republic (GDR). The newly democratic FRG embedded itself in key
Western economic and security organizations, the EU and NATO, while
the Communist GDR was on the front line of the Soviet-led Warsaw
Pact. The decline of the Soviet Union and end of the Cold War
cleared the path for the fall of the Berlin Wall in 1989 and German
re-unification in 1990. Germany has expended considerable
funds--roughly $100 billion a year--in subsequent years working to
bring eastern productivity and wages up to western standards, with
mixed results. Unemployment--which in the east is nearly double that
in the west--has grown over the last several years, primarily as a
result of structural problems like an inflexible labor market. In
January 1999, Germany and 10 other members of the EU formed a common
European currency, the euro, and the German government is now
looking toward reform of the EU budget and enlargement of the Union
into Central Europe.','95bad066c217fe40efcd9d0b30e0bdaf54a5cbdecdad9489bd7c8c26824353b8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b945eb3212a065654ac030d22683c001024d357ed3393dc6ee3654d182d259cc',1999,'GT','Guatemala','introduction',228,'Background: Popes in their secular role ruled much of the Italian
peninsula, including Rome, for about a thousand years, until 1870. A
dispute between a series of popes and Italy was settled in 1929 by
treaties that recognized the Vatican City as an independent
sovereignty and gave Roman Catholicism special status in Italy. The
US established formal diplomatic relationships with the Vatican in
1984. Present issues in the Vatican concern the ill health of Pope
John Paul II, who turns 79 on 20 May 1999, inter-religious dialogue
and reconciliation, and the adjustment of church doctrine in an era
of rapid change. About 1 billion people worldwide profess the Roman
Catholic faith.
Background: Pursuant to the agreement signed by China and the UK
on 19 December 1984, Hong Kong became the Hong Kong Special
Administrative Region (SAR) of China on 1 July 1997. Under the terms
of this agreement, China has promised that under its "one country,
two systems" formula its socialist economic system will not be
practiced in Hong Kong, and that Hong Kong shall enjoy a high degree
of autonomy in all matters except foreign and defense affairs.
Background: After World War II Hungary became part of
Soviet-dominated Eastern Europe, and its government and economy were
refashioned on the communist model. Increased nationalist
opposition, which culminated in the government''s announcement of
withdrawal from the Warsaw Pact in 1956, led to massive military
intervention by Moscow and the swift crushing of the revolt. In the
more open GORBACHEV years, Hungary led the movement to dissolve the
Warsaw Pact and steadily moved toward multiparty democracy and a
market-oriented economy. Following the collapse of the USSR in 1991,
Hungary has developed close political and economic relations with
western Europe and is now being considered a possible future member
of the European Union.
Background: Iceland boasts the oldest surviving parliament in the
world, the Althing, established in 930. Subsequently this Nordic
island, whose small population has largely depended on fishing and
sheep-herding for a living, came under the rule of Norway and then
Denmark. It gained home rule in 1874 and full independence in 1944.
Literacy, longevity, and social cohesion are topnotch by world
standards. Tensions continue with Norway, Russia, and other nearby
countries over fishing rights in the North Atlantic and adjacent
seas.','aa82e7c5d4d2e11ca93c18b1fb7368030395efa66b99f0dae1b1f5e863838d9b','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e02743a835914d8ebaef112895f054bd111f674c24291d7024787c25f01e48a',1999,'CN','China','introduction',245,'Background: As a republic within the USSR (1920-91), Kazakhstan
suffered greatly from Stalinist purges, from environmental damage,
and saw the ethnic Russian portion of its population rise to 37%
while other non-Kazakhs made up almost 20%. Current issues include
the pace of market reform and privatization; fair and free elections
and democratic reform; ethnic differences between Russians and
Kazakhs; environmental problems; and how to convert the country''s
abundant energy resources into a better standard of living.','381902191aa17458a4bb45359f99f94f7421f5db83322d17e14dee5b8356fd73','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a41cd2c2cf55b3b8bbf2d04176c10ec6fe79c3b064dc7610dd3811111b984c9',1999,'NR','Nauru','introduction',246,'Background: At the end of World War II, the US and the Soviet
Union agreed that US troops would accept the surrender of Japanese
forces south of the 38th parallel and the Soviet Union would do so
in the north. In 1948, the UN proposed nationwide elections; after
P''yongyang''s refusal to allow UN inspectors in the north, elections
were held in the south and the Republic of Korea was established.
The Democratic People''s Republic of Korea was established the
following month in the north. Communist North Korean forces invaded
South Korea in 1950. US and other UN forces intervened to defend the
South and Chinese forces intervened on behalf of the North. After a
bitter three-year war, an armistice was signed in 1953, establishing
a military demarcation line near the 38th parallel. The North''s
heavy investment in military forces has produced an army of 1
million troops equipped with thousands of tanks and artillery
pieces. Despite growing economic hardships, North Korea continues to
devote a significant portion of its scarce resources to the military.
Background: At the end of World War II, the US and the Soviet
Union agreed that US troops would accept the surrender of Japanese
forces south of the 38th parallel and the Soviet Union would do so
in the north. In 1948, the UN proposed nationwide elections; after
P''yongyang''s refusal to allow UN inspectors in the north, elections
were held in the south and the Republic of Korea was established.
The Democratic People''s Republic of Korea was established the
following month in the north. Communist North Korean forces invaded
South Korea in 1950. US and other UN forces intervened to defend the
South and Chinese forces intervened on behalf of the North. After a
bitter three-year war, an armistice was signed in 1953, establishing
a military demarcation line near the 38th parallel. Thereafter,
South Korea achieved amazing economic growth, with per capita output
rising to 13 times the level in the North. Since late 1997, however,
the nation has suffered widespread financial and organizational
difficulties. Continuing tensions between North and South have
raised concerns of provocative military actions by the North.
Background: A country of incredible natural beauty and proud
nomadic traditions, Kyrgyzstan became part of the Russian empire in
1864. In the Czarist and Soviet periods, Russian managers and
technicians were sent to Kyrgyzstan and have recently made up more
than one-fifth of the population. Many Russians have been returning
home since Kyrgyzstan gained its independence in 1991 when the USSR
collapsed. Privatization of state-owned enterprises, expansion of
democracy and political freedoms, and inter-ethnic relations are
current issues.
Background: Along with most of the other small nations of Europe,
Latvia shares a history of invasion by a succession of expansionist
nations, e.g., Sweden, Poland, Germany, and Russia. After a brief
period of independence between the two World Wars, Latvia was
annexed by the USSR in 1940 under the Molotov-Ribbentrop Pact. The
USSR recaptured Latvia from its German occupiers in 1944. Latvia
reestablished its independence in August 1991, a few months prior to
the collapse of the Soviet Union; the last Russian troops left in
1994. The status of ethnic Russians, who make up 30% of the
population, is an issue of concern to Moscow. Unemployment has
become a growing problem and Latvia hopes to receive an invitation
to begin EU accession talks by the end of 1999.','f78442d37059c938796fb074d64fe8612f04b7382cfa7637709d44eb5571fce8','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('148e0e9d3a0e79580d37d7ea1b51b53395cef5419b49ce3a13f04f4a522df186',1999,'SE','Sweden','introduction',251,'Background: Lebanon has made progress toward rebuilding its
political institutions and regaining its national sovereignty since
the end of the devastating 16-year civil war, which ended in 1991.
Under the Ta''if Accord--the blueprint for national reconciliation--the
Lebanese have established a more equitable political system,
particularly by giving Muslims a greater say in the political
process while institutionalizing sectarian divisions in the
government. Since the end of the civil war, the Lebanese have formed
six cabinets, conducted two legislative elections, and held their
first municipal elections in 35 years. Most of the militias have
been weakened or disbanded. The Lebanese Armed Forces (LAF) has
seized vast quantities of weapons used by the militias during the
war and extended central government authority over about one-half of
the country. Hizballah, the radical Shi''a party, retains its
weapons. Foreign forces still occupy areas of Lebanon. Israel
maintains troops in southern Lebanon and continues to support a
proxy militia, the Army of South Lebanon (ASL), along a narrow
stretch of territory contiguous to its border. The ASL''s enclave
encompasses this self-declared security zone and about 20 kilometers
north to the strategic town of Jazzin. Syria maintains about 25,000
troops in Lebanon based mainly in Beirut, North Lebanon, and the
Bekaa Valley. Syria''s deployment was legitimized by the Arab League
during Lebanon''s civil war and in the Ta''if Accord. Citing the
continued weakness of the LAF, Beirut''s requests, and failure of the
Lebanese Government to implement all of the constitutional reforms
in the Ta''if Accord, Damascus has so far refused to withdraw its
troops from Lebanon.
Background: The 1995 Abuja Peace Accords ended seven years of
civil warfare in Liberia. More than 20,000 of the estimated 33,000
factional fighters gave up their arms to the Cease-Fire Monitoring
Group of the Economic Community of West African States (ECOMOG).
Free and open presidential and legislative elections were held 19
July 1997; former faction leader, Charles TAYLOR, and his National
Patriotic Party won overwhelming victories. The years of civil
strife coupled with the flight of most business people disrupted
formal economic activity. A short-lived armed clash in September
1998 between government forces and supporters of factional leader
Roosevelt JOHNSON and continuing uncertainty about the security
situation have slowed the process of rebuilding the social and
economic structure of the war-torn country. For two centuries the US
has had uniquely close ties to Liberia and today is a major aid
donor.','e36e9d1e2b71dee869eead1f0cee6d49c989fd6121e6111f7c4801c4bcf2f99e','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bfd84a18022d8242c1af608b79edee92a8dec7b6188c1e576f2863bbc81ff31',1999,'MG','Madagascar','introduction',324,'Background: Russia, a vast Eurasian expanse of field, forest,
desert, and tundra, has endured many "times of trouble"--the Mongol
rule of the 13th to 15th century; czarist reigns of terror; massive
invasions by Swedes, French, and Germans; and the deadly communist
period (1917-91) in which Russia dominated an immense Soviet Union.
General Secretary Mikhail GORBACHEV, in charge during 1985-91,
introduced glasnost (openness) and perestroika (restructuring) in an
attempt to modernize communism, but also inadvertently released
forces that shattered the USSR into 15 independent republics in
December 1991. Russia has struggled in its efforts to build a
democratic political system and market economy to replace the strict
social, political, and economic controls of the communist period.
These reform efforts have resulted in contradictory and confusing
economic and political regulations and practices. Industry,
agriculture, the military, the central government, and the ruble
have suffered, but Russia has successfully held one presidential,
two legislative, and numerous regional elections since 1991. The
severe illnesses of President Boris YEL''TSIN have contributed to a
lack of policy focus at the center.
Background: Throughout their colonial rule, first Germany and
then Belgium favored Rwanda''s minority Tutsi ethnic group in
education and employment. In 1959, the majority ethnic group, the
Hutus, overthrew the ruling Tutsi monarch. The Hutus killed hundreds
of Tutsis and drove tens of thousands into exile in neighboring
countries. The children of these exiles later formed a rebel group,
the Rwandan Patriotic Front (RPF), and began a civil war in October
1990. The war, along with several political and economic upheavals,
exasperated ethnic tensions culminating in April 1994 in a genocide
in which roughly 800,000 Tutsis and moderate Hutus were killed. The
Tutsi rebels defeated the Hutu regime and ended the genocide in July
1994, but approximately 2 million Hutu refugees--many fearing Tutsi
retribution--fled to neighboring Burundi, Tanzania, Uganda, and
Zaire, now called the Democratic Republic of the Congo (DROC).
According to the UN Office of the High Commissioner for Refugees, in
1996 and early 1997 nearly 1.3 million Hutus returned to Rwanda.
Even with substantial international aid, these civil dislocations
have hindered efforts to foster reconciliation and to boost
investment and agricultural output. Although much of the country is
now at peace, members of the former regime continue to destabilize
the northwest area of the country through a low-intensity
insurgency. Rwandan troops are currently involved in a crisis
engulfing neighboring DROC.','09ca4033523020155270c74460056e6bf68d4508bd93f34b8b58d71cd6692a7a','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21015bf88ceb75537f3ef0dd5b429b790706daf8cd4ec7356beb7c92003998b0',1999,'SC','Seychelles','introduction',331,'Background: On 25 May 1997, the democratically-elected government
of President Ahmad Tejan KABBAH was overthrown by a disgruntled
coalition of army personnel from the Armed Forces Revolutionary
Council (AFRC) and the Revolutionary United Front (RUF) under the
command of Major Johnny Paul KOROMA; President KABBAH fled to exile
in Guinea. The Economic Community of West African States Cease-Fire
Monitoring Group (ECOMOG) forces, led by a strong Nigerian
contingent, undertook the suppression of the rebellion. They were
initially unsuccessful, but, by October 1997, they forced the rebels
to agree to a cease-fire and to a plan to return the government to
democratic control. President KABBAH returned to office on 10 March
1998 to face the task of restoring order to a demoralized population
and a disorganized and severely damaged economy. Many of the leaders
of the coup were tried and executed in October 1998. In January
1999, the situation had deteriorated even further, with commerce at
a standstill, hundreds of thousands of people driven from their
homes, and bitter fighting between the AFRC/RUF and ECOMOG troops
intensifying by large-scale import of arms.','ea7003d71db60b8cd88be9ea683b208cfcfd87938478d40e79a349ffff37d3a5','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d3ed7af373d7008dfb772aa9dac7b3739435047d8242408807dc0dc20cdcf41',1999,'ID','Indonesia','introduction',339,'Background: After centuries under foreign rule, mainly by
Hungary, the Slovaks joined with their neighbors to form the new
nation of Czechoslovakia in 1918. Following the chaos of World War
II, Czechoslovakia became a communist nation within Soviet-ruled
Eastern Europe. Soviet influence collapsed in 1989, and
Czechoslovakia once more was an independent country turning toward
the West. The Slovaks and the Czechs agreed to separate peacefully
on 1 January 1993. Slovakia has experienced more difficulty than the
Czech Republic in developing a modern market economy.
Background: In 1893, Britain made the southern Solomon Islands a
protectorate. Other islands were added to the group, including some
ceded to Britain by Germany. The Solomon Islands were occupied by
the Japanese during World War II. Following the war, internal
self-government was established in 1976, and independence from the
UK came two years later. Current issues include government deficits,
deforestation, and malaria control.
Background: A powerful world empire in the 16th and 17th
centuries, Spain ultimately yielded command of the seas to England,
beginning with the defeat of the Armada in 1588. Spain subsequently
failed to embrace the mercantile and industrial revolutions and fell
behind Britain, France, and Germany in economic and political power.
Spain remained neutral in World Wars I and II. In the second half of
the 20th century Spain played a catch-up role in the western
international community. Continuing problems are large-scale
unemployment and the Basque separatist movement.','e92bca65d99f24ea57f71af3ef91d7485f1c531b40d46b9ab17052b1ae3897eb','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbf62da144c513d01e0f2fafb58319438bd1a3c1f72bf60d220e3ee11249f525',1999,'IN','India','introduction',361,'Background: Having long lost its military prowess of the 17th
century, Sweden has evolved into a prosperous and peaceful
constitutional monarchy with a capitalist system interlarded with
substantial welfare elements. As the 20th century comes to an end,
this long successful formula is being undermined by high
unemployment; the rising cost of a "cradle to the grave" welfare
state; the decline of Sweden''s competitive position in world
markets; and indecision over the country''s role in the political and
economic integration of Europe. A member of the European Union,
Sweden chose not to participate in the introduction of the euro on 1
January 1999.
Background: Switzerland''s independence and neutrality have long
been honored by the major European powers and Switzerland did not
participate in either World War I or II. The political and economic
integration of Europe since World War II may be rendering obsolete
Switzerland''s concern for neutrality.
Background: In 1895, military defeat forced China to cede Taiwan
to Japan, however it reverted to Chinese control after World War II.
Following the Communist victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a government that over
five decades has gradually democratized and incorporated native
Taiwanese within its structure. Throughout this period, the island
has prospered as one of East Asia''s economic tigers. The dominant
political issue continues to be the relationship between Taiwan and
Mainland China and the question of eventual reunification.
Background: Tajikistan has experienced three changes of
government and a civil war since it gained independence in September
1991 when the USSR collapsed. A peace agreement was signed in June
1997, but implementation is progressing slowly. Russian-led
peacekeeping troops are deployed throughout the country, and
Russian-commanded border guards are stationed along the
Tajikistani-Afghan border.','5c7cec1579b6ccb08f0be1df9f7a16a48ca7e46440f036079769295a9e113ddf','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f31654c818b91297962b0a5438701beaab488e1c91a0f4af9e7c25bbdc6efcc2',1999,'TC','Turks and Caicos Islands','introduction',376,'Background: Buoyed by victories in World Wars I and II and the
end of the Cold War in 1991, the US remains the world''s most
powerful nation-state. The economy is marked by steady growth, low
unemployment, low inflation, and rapid advances in technology. The
biggest cloud over this affluent society is the distribution of
gains--since 1975 most of the increase in national income has gone to
the 20% of people at the top of the income ladder.','3f53b12b343b82e397d04e2296a97652af93afc3ecf37a5ab94979ac87d326e2','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87af388202cefcd7dfd356e50ba7dbcad818d8899c63bccb314368b82f1f1e0d',1999,'NC','New Caledonia','introduction',397,'Background: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the Gaza Strip
and the West Bank. Permanent status negotiations began on 5 May
1996, but have not resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and responsibilities to the
Palestinian Authority, which includes a Palestinian Legislative
Council elected in January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A transfer of powers
and responsibilities for the Gaza Strip and Jericho took place
pursuant to the Israel-PLO 4 May 1994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995 Interim Agreement, the
Israel-PLO 15 January 1997 Protocol Concerning Redeployment in
Hebron, and the Israel-PLO 23 October 1998 Wye River Memorandum. The
DOP provides that Israel will retain responsibility during the
transitional period for external security and for internal security
and public order of settlements and Israelis. Permanent status is to
be determined through direct negotiations.','cff599a0b30ab6155820eefa6f2b52e2550a77ed6db5dfbe3cb47b39e5ded0ad','internet-archive','theciaworldfactb27676gut','txt','fdaf5081e232a2f0d1a7f086fe89634009eac19ac76f03b1c0ec9bf70362e2ae','https://archive.org/download/theciaworldfactb27676gut/27676.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

-- ZZX-Labs Bitnodes MariaDB control file
-- generated_at_utc: 2026-06-05T03:16:27+00:00
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
CREATE DATABASE IF NOT EXISTS `zzx_bitnodes` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `zzx_bitnodes`;

CREATE TABLE IF NOT EXISTS bitnodes_nodes (
  node_id VARCHAR(96) NOT NULL,
  source_name VARCHAR(128) NOT NULL,
  address VARCHAR(512) NOT NULL,
  host VARCHAR(512) NULL,
  port INT NULL,
  network VARCHAR(32) NULL,
  agent TEXT NULL,
  protocol BIGINT NULL,
  services BIGINT NULL,
  height BIGINT NULL,
  city VARCHAR(255) NULL,
  country VARCHAR(64) NULL,
  territory VARCHAR(255) NULL,
  county VARCHAR(255) NULL,
  zip_code VARCHAR(64) NULL,
  timezone VARCHAR(128) NULL,
  latitude DOUBLE NULL,
  longitude DOUBLE NULL,
  asn VARCHAR(64) NULL,
  organization TEXT NULL,
  provider TEXT NULL,
  w3w VARCHAR(255) NULL,
  zzxgcs VARCHAR(255) NULL,
  geohash VARCHAR(64) NULL,
  reachable TINYINT NULL,
  reachable_now TINYINT NULL,
  reachable_24h TINYINT NULL,
  latency_ms DOUBLE NULL,
  last_seen VARCHAR(64) NULL,
  raw_hash CHAR(64) NOT NULL,
  raw_json LONGTEXT NOT NULL,
  updated_at_utc VARCHAR(64) NOT NULL,
  PRIMARY KEY (node_id, source_name),
  KEY idx_address (address),
  KEY idx_source_name (source_name),
  KEY idx_network (network),
  KEY idx_country (country),
  KEY idx_city (city),
  KEY idx_asn (asn),
  KEY idx_geohash (geohash),
  KEY idx_reachable_now (reachable_now),
  KEY idx_reachable_24h (reachable_24h),
  KEY idx_lat_lon (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bitnodes_exports (
  export_id VARCHAR(96) NOT NULL,
  schema_name VARCHAR(128) NOT NULL,
  generated_at_utc VARCHAR(64) NOT NULL,
  source_count INT NOT NULL,
  node_count BIGINT UNSIGNED NOT NULL,
  shard_count INT NOT NULL,
  PRIMARY KEY (export_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO bitnodes_exports (export_id, schema_name, generated_at_utc, source_count, node_count, shard_count) VALUES ('export:7523e90d68c24fddc79c4e7a', 'zzx-bitnodes-export-db-v1', '2026-06-05T03:16:27+00:00', 1, 1271, 1) ON DUPLICATE KEY UPDATE schema_name=VALUES(schema_name), generated_at_utc=VALUES(generated_at_utc), source_count=VALUES(source_count), node_count=VALUES(node_count), shard_count=VALUES(shard_count);
SET FOREIGN_KEY_CHECKS=1;
